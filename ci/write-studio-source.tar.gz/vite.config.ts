import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
// @ts-expect-error type error without @types/node package
import process from "node:process";
const host = process.env.TAURI_DEV_HOST;

// https://vite.dev/config/
export default defineConfig(() => ({
  plugins: [react()],
  build: {
    rolldownOptions: {
      output: {
        codeSplitting: {
          groups: [
            { name: 'react', test: /\/node_modules\/(?:react|react-dom|scheduler)\// },
            { name: 'editor-engine', test: /\/node_modules\/(?:@tiptap|prosemirror-[^/]+|orderedmap|rope-sequence)\// },
          ],
        },
      },
    },
  },

  // Vite options tailored for Tauri development and only applied in `tauri dev` or `tauri build`
  //
  // 1. prevent Vite from obscuring rust errors
  clearScreen: false,
  // 2. tauri expects a fixed port, fail if that port is not available
  server: {
    port: 1420,
    strictPort: true,
    host: host || false,
    // Opt in to live reload only while intentionally editing application code.
    hmr: process.env.WRITE_STUDIO_LIVE_RELOAD === "1" ? (host ? {
      protocol: "ws", host, port: 1421,
    } : true) : false,
    watch: {
      ignored: process.env.WRITE_STUDIO_LIVE_RELOAD === "1"
        ? ["**/src-tauri/**"] : ["**"],
    },
  },
}));
