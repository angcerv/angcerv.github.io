import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const Pending=loadLocal('../src/ProjectPending.tsx').default;
const {IdeaLinkedChoices,default:Editor}=loadLocal('../src/WorldIdeaEditor.tsx');
const MentionChoice=loadLocal('../src/MentionChoiceDialog.tsx').default;
const require=createRequire(import.meta.url),React=require('react');
const saved={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect,useMemo:React.useMemo,useSyncExternalStore:React.useSyncExternalStore};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
const world={templates:[],entries:[]};
const comments=[{id:'a',text:'Check date',quote:'',resolved:false},{id:'b',text:'Check name',quote:'',resolved:false}];
let project={id:'ux',chapters:[{id:'c',title:'Chapter',scenes:[{id:'s',title:'Scene',content:'Ready.',synopsis:'Done.',writingStatus:'finished',reviewComments:comments}]}],worldbuilding:world};
let states=[],refs=[],effects=[],stateIndex=0,refIndex=0,focused='';
const props={project,onOpen(){},onResolveMention(){},onResolveComment:(_scene,id)=>{project={...project,chapters:[{...project.chapters[0],scenes:[{...project.chapters[0].scenes[0],reviewComments:comments.filter(comment=>comment.id!==id)}]}]};}};
function render(){stateIndex=0;refIndex=0;effects=[];return nodes(Pending({...props,project}));}
try{
 React.useState=initial=>{const i=stateIndex++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],v=>states[i]=typeof v==='function'?v(states[i]):v];};
 React.useRef=initial=>{const i=refIndex++;return refs[i]??(refs[i]={current:initial});};React.useEffect=fn=>effects.push(fn);React.useMemo=fn=>fn();React.useSyncExternalStore=()=> 'en';
 let tree=render();
 const dateOptions=['created-newest','created-oldest','updated-newest','updated-oldest'];
 assert(dateOptions.every(value=>tree.find(n=>n.props?.id==='pending-order').props.options.some(option=>option.value===value)));
 tree.find(n=>n.props?.id==='pending-order').props.onChange('updated-newest');
 tree.find(n=>n.type==='button'&&n.props.children==='Ideas and decisions').props.onClick();tree=render();
 assert(dateOptions.every(value=>tree.find(n=>n.props?.id==='pending-order').props.options.some(option=>option.value===value)));
 assert.equal(tree.find(n=>n.props?.id==='pending-order').props.value,'default');
 tree.find(n=>n.props?.id==='pending-order').props.onChange('created-oldest');
 tree.find(n=>n.type==='button'&&n.props.children==='Review').props.onClick();tree=render();
 assert.equal(tree.find(n=>n.props?.id==='pending-order').props.value,'updated-newest');
 tree.find(n=>n.type==='input'&&n.props.type==='search').props.onChange({target:{value:'date'}});tree=render();
 assert.equal(tree.filter(n=>n.type==='button'&&n.props.children==='Clear filters').length,1,'One reset action remains available with filtered results');
 const all=tree.find(n=>n.type==='button'&&n.props['aria-pressed']===true);
 assert.equal(nodes(all).find(n=>n.props?.className==='compact-count').props.children,1);
 tree.find(n=>n.type==='button'&&n.props.children?.includes?.('Review comments')).props.onClick();tree=render();
 assert(!tree.some(n=>n.props?.id==='pending-idea-status'));
 states[2]='';tree=render();
 refs[0].current={querySelectorAll:()=>[{dataset:{pendingId:'comment:b'},querySelector:()=>({focus:()=>focused='next'})}],querySelector:()=>({focus:()=>focused='filters'})};
 tree.find(n=>n.props?.['aria-label']==='Resolve comment').props.onClick();tree=render();effects.forEach(fn=>fn());
 assert.equal(focused,'next');assert(tree.some(n=>n.props?.role==='status'&&n.props.children==='Comment resolved'));
 // Reuse the real expandable text component and verify hidden rich links are inert.
 const Text=tree.find(n=>n.type?.name==='PendingItemText').type;
 states=[];stateIndex=0;let textNodes=nodes(Text({item:{title:'Long comment',detail:'A long detail '.repeat(40)}}));
 assert(textNodes.some(n=>n.props?.className==='pending-text-full'&&n.props.inert===true));
 textNodes.find(n=>n.props?.['aria-expanded']===false).props.onClick();stateIndex=0;
 textNodes=nodes(Text({item:{title:'Long comment',detail:'A long detail '.repeat(40)}}));
 assert(textNodes.some(n=>n.props?.className==='pending-text-full'&&n.props.inert===false));
 // Linked destinations are not duplicated in the choices, and accent-insensitive search stays local.
 states=[];stateIndex=0;let chosen;
 const relationProps={title:'Scenes',options:[{id:'linked',title:'Existing'},{id:'new',title:'Árbol del océano'},{id:'archived',title:'Old',available:false}],selected:['linked','missing'],missingLabel:'Deleted scene',onChange:ids=>chosen=ids,canOpen:true};
 let related=nodes(IdeaLinkedChoices(relationProps));
 assert.equal(related.filter(n=>n.type==='input'&&n.props.type==='checkbox').length,1);
 related.find(n=>n.type==='input'&&n.props.type==='search').props.onChange({target:{value:' arbol  del oceano '}});stateIndex=0;related=nodes(IdeaLinkedChoices(relationProps));
 assert.equal(related.filter(n=>n.type==='input'&&n.props.type==='checkbox').length,1);
 related.find(n=>n.props?.['aria-label']==='Unlink Deleted scene').props.onClick();assert.deepEqual(chosen,['linked']);
 states[0]='nonexistent';stateIndex=0;related=nodes(IdeaLinkedChoices(relationProps));assert(related.some(n=>n.props?.children==='No matching items.'));
 // A failed save preserves the draft and never navigates; successful navigation saves first.
 states=[];refs=[];stateIndex=0;refIndex=0;effects=[];let events=[];
 const editorProps={idea:{id:'idea',title:' Draft ',description:'Keep this',status:'idea',entryIds:['entry']},world:{templates:[],entries:[{id:'entry',title:'Target'}]},onSave:()=>{throw Error('Save failed');},onClose:()=>events.push('close'),onOpenEntry:()=>events.push('open')};
 let editor=nodes(Editor(editorProps));editor.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});
 stateIndex=0;refIndex=0;editor=nodes(Editor(editorProps));
 assert(editor.some(n=>n.props?.role==='alert'&&n.props.children.includes('Save failed')));assert.deepEqual(events,[]);
 assert(editor.some(n=>n.type==='input'&&n.props.value===' Draft '));
 stateIndex=0;refIndex=0;editor=nodes(Editor({...editorProps,onSave:idea=>events.push(['save',idea.title,idea.description])}));
 editor.find(n=>n.type===IdeaLinkedChoices&&n.props.title==='Related entries').props.onOpen('entry');
 assert.deepEqual(events,[['save','Draft','Keep this'],'close','open']);
 // Closing a changed draft requires a decision; keeping it retains all local edits.
 states=[];refs=[];stateIndex=0;refIndex=0;events=[];
 const guardedProps={...editorProps,onSave:item=>events.push(['save',item.title]),onClose:()=>events.push('close')};
 const guarded=()=>{stateIndex=0;refIndex=0;return nodes(Editor(guardedProps));};
 let guardedTree=guarded();guardedTree.find(n=>n.type==='input'&&n.props.maxLength===300).props.onChange({target:{value:'Changed title'}});
 guarded().find(n=>n.type==='button'&&n.props.children==='Cancel').props.onClick();guardedTree=guarded();
 assert(guardedTree.some(n=>n.type?.name==='ProjectModal'&&n.props.variant==='confirmation'));assert.deepEqual(events,[]);
 guardedTree.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.deepEqual(events,[],'Confirmation blocks background saves');
 guardedTree.find(n=>n.type==='button'&&n.props.children==='Keep editing').props.onClick();guardedTree=guarded();
 assert(guardedTree.some(n=>n.type==='input'&&n.props.value==='Changed title'));
 guardedTree.find(n=>n.type==='button'&&n.props.children==='Cancel').props.onClick();guarded().find(n=>n.type==='button'&&n.props.children==='Discard changes').props.onClick();assert.deepEqual(events,['close']);
 const {ideaDraftSignature}=loadLocal('../src/WorldIdeaEditor.tsx');
 assert.equal(ideaDraftSignature(editorProps.idea),ideaDraftSignature({...editorProps.idea,category:'worldbuilding',sceneIds:[],plotIds:[],updates:[]}));
 assert.notEqual(ideaDraftSignature(editorProps.idea),ideaDraftSignature({...editorProps.idea,decision:'Changed'}));

}finally{Object.assign(React,saved);}
const closed={id:'closed',chapters:[],worldbuilding:world,worldIdeas:[{id:'idea',title:'Done',status:'incorporated',description:'',entryIds:[]}]};
const N=loadLocal('../src/workspaceNavigation.ts');N.activateWorkspaceMemory({values:{'pending.section':'ideas'}});
const html=renderToStaticMarkup(createElement(Pending,{...props,project:closed}));N.activateWorkspaceMemory(undefined);
assert(html.includes('You are up to date.'));assert(html.includes('View all ideas'));assert(!html.includes('No pending items match these filters.'));
const mention=renderToStaticMarkup(createElement(MentionChoice,{world,ids:['missing'],label:'Name',onClose(){},onChoose(){}}));
assert(mention.includes('No entries available for this mention.'));assert(mention.includes('aria-label="Close"'));
console.log('Pending UX: query-aware counters, contextual filters, focus after resolution, inert expansion, relationship search/deduplication, missing targets, closed-idea empty state and mention dialog passed without UI.');
