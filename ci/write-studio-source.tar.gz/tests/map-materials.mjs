import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
import {loadLocal} from './load-local.mjs';
const {terrainMaterials,materialDefinitions,materialSwatch,materialSurface,materialScale,isTerrainMaterial,textureIntensity}=loadLocal('../src/mapMaterials.ts');
const {drawingSvg,drawingDataUrl,drawingContent,drawingMaterialDefinitions,seaColor}=loadLocal('../src/mapDrawing.ts');
const {renderTerrainStrokes}=loadLocal('../src/mapTerrain.ts');
const base={width:1600,height:1000,objects:[],strokes:[{kind:'land',color:'#abcdef',width:.1,points:[{x:.1,y:.2},{x:.8,y:.2}]}]};
const legacy=drawingSvg(base);assert(!legacy.includes('<mask'));assert(!legacy.includes('feTurbulence'));assert(legacy.includes('stroke="#abcdef"'));
assert(!isTerrainMaterial('__proto__'));assert(!isTerrainMaterial('url(bad)'));assert(isTerrainMaterial('sea'));
const kinds=Object.keys(terrainMaterials),output=[];
const details={sea:'waves',earth:'soil',sand:'dunes',grass:'blades',rock:'facets',mud:'cracks',pavement:'paving',cityWater:'waves',park:'blades',asphalt:'road-markings',alloy:'panels',canal:'waves',district:'blocks',transit:'transit-lanes',nebula:'cosmic-clouds',spaceRegion:'constellations',deepSpace:'stars'};
for(const kind of kinds){
 const stroke={...base.strokes[0],material:kind,textureIntensity:.4},drawing={...base,strokes:[stroke]};
 const before=JSON.stringify(drawing),svg=drawingSvg(drawing);output.push(svg);
 assert(svg.includes(`data-terrain-material="${kind}" pointer-events="none"`),'Terrain masks must not intercept selection of objects on other layers');assert(svg.includes(`data-material-detail="${kind}" opacity="0.4"`));assert(svg.includes(`data-atlas-detail="${details[kind]}"`));
 assert(svg.includes('maskUnits="userSpaceOnUse"'));assert(svg.includes('patternUnits="userSpaceOnUse"'));assert(!svg.includes('<filter'),'Terrain must not allocate full-map filter buffers during zoom');assert(!svg.includes('feGaussianBlur'));assert(!svg.includes('mix-blend-mode'));
 assert(!svg.includes('href="http'));assert.equal(JSON.stringify(drawing),before);assert.equal(decodeURIComponent(drawingDataUrl(drawing)).split(',').slice(1).join(','),svg);
 assert.equal(drawingSvg(JSON.parse(JSON.stringify(drawing))),svg,'JSON persistence preserves pattern origins/seeds and rendering');
 assert.equal(drawingSvg({...drawing,strokes:[stroke,{...stroke,points:stroke.points.map(p=>({...p}))}]}),svg,'Repeated identical passes produce identical output, not stacked pigment');
 const swatch=decodeURIComponent(materialSwatch(kind,.4)),defs=materialDefinitions([kind]);assert(swatch.includes(defs));assert(swatch.includes(materialSurface(kind,.4,160,96)));
 assert(!defs.includes('feTurbulence'),'Pattern colors are restricted vector ink, never multichannel noise');assert(!defs.includes('feGaussianBlur'));assert(defs.includes('width="448"'));assert(defs.includes('width="577"'));assert(defs.includes('width="733"'));
 const zero=drawingSvg({...drawing,strokes:[{...stroke,textureIntensity:0}]});assert(!zero.includes('data-material-detail='));assert(zero.includes('fill="#abcdef"'),'Zero intensity keeps the opaque, stored base color');
 const hidden=drawingSvg({...drawing,strokes:[{...stroke,layerId:'hidden'}]},true,[{id:'hidden',visible:false}]);assert(!hidden.includes('data-terrain-material'));assert(!hidden.includes('feTurbulence'));
 const locked=drawingSvg({...drawing,strokes:[{...stroke,layerId:'locked'}]},true,[{id:'locked',visible:true,locked:true}]);assert(locked.includes('data-terrain-material'));
 const dot=drawingSvg({...drawing,strokes:[{...stroke,points:[{x:.5,y:.5}]}]});assert(dot.includes('<circle cx="800" cy="500" r="80" fill="white"'));
 const resized=drawingSvg({...drawing,width:3200,height:2000});assert(resized.includes('patternTransform="scale(2)"'));assert(svg.includes('patternTransform="scale(1)"'));
 // No unresolved/duplicate SVG resources, including portable SVG/image export paths.
 const ids=[...svg.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(ids.length,new Set(ids).size);for(const match of svg.matchAll(/url\(#([^)]*)\)/g))assert(ids.includes(match[1]),match[1]);
}
const editorDrawing={...base,strokes:[{...base.strokes[0],material:'earth'}]};
assert.equal(drawingContent(editorDrawing),drawingMaterialDefinitions(editorDrawing)+drawingContent(editorDrawing,true,undefined,false,false),'Editor keeps identical paint output with stable pattern definitions in a separate DOM group');
assert.equal(drawingMaterialDefinitions(editorDrawing),drawingMaterialDefinitions({...editorDrawing,strokes:[...editorDrawing.strokes,{...earthPlaceholder(),material:'earth'}]}));
function earthPlaceholder(){return {...base.strokes[0],points:[{x:.2,y:.4}]};}
assert.equal(new Set(output).size,17);assert.equal((materialDefinitions(['sea','sea']).match(/id="ws-terrain-sea"/g)||[]).length,1);
assert.equal(materialDefinitions(['sea','earth']),materialDefinitions(['earth','sea']));assert.equal(materialSwatch('sea'),materialSwatch('sea'));
assert.notEqual(materialSwatch('sea',0),materialSwatch('sea',1));assert.equal(materialScale(100,100),.5);assert.equal(materialScale(10000,10000),2);assert.equal(textureIntensity(9),1);assert.equal(textureIntensity(-2),0);assert.equal(textureIntensity(NaN),.75);
const earth={...base.strokes[0],material:'earth'},sea={...base.strokes[0],material:'sea',width:.3};
const overlap=drawingSvg({...base,strokes:[earth,sea,earth]});assert.deepEqual([...overlap.matchAll(/data-terrain-material="([^"]+)"/g)].map(m=>m[1]),['earth','sea','earth'],'Other materials keep chronological occlusion');assert(overlap.includes('data-terrain-coast="true"'));
const coast=drawingSvg({...base,background:seaColor,strokes:[earth]});assert(coast.includes('data-terrain-coast="true"'));assert(!drawingSvg({...base,strokes:[earth]}).includes('data-terrain-coast'));
const layered=drawingSvg({...base,strokes:[{...sea,layerId:'water'},{...earth,layerId:'ground'}]},true,[{id:'water',visible:true},{id:'ground',visible:true}]);assert(layered.includes('ws-map-terrain-2-sea'));assert(layered.includes('data-terrain-coast="true"'));
const hiddenWater=drawingSvg({...base,strokes:[{...sea,layerId:'water'},{...earth,layerId:'ground'}]},true,[{id:'water',visible:false},{id:'ground',visible:true}]);assert(!hiddenWater.includes('data-terrain-coast'));
// Independent module initialization must regenerate exactly the same original artwork.
const require=createRequire(import.meta.url),previous=materialDefinitions(kinds);delete require.cache[require.resolve('../src/mapMaterials.ts')];assert.equal(loadLocal('../src/mapMaterials.ts').materialDefinitions(kinds),previous);
// Parse representative complete SVGs with the standard-library XML parser; no rendering/UI.
const xmlCode=`import json,sys,re,xml.etree.ElementTree as ET
for svg in json.load(sys.stdin):
 root=ET.fromstring(svg)
 for pattern in root.iter('{http://www.w3.org/2000/svg}pattern'):
  size=float(pattern.attrib['width'])
  radius=2 if size==577 else 64 if size==733 else 36
  centers=[]
  for child in pattern:
   match=re.match(r'translate\\(([-.0-9]+) ([-.0-9]+)\\)',child.attrib.get('transform',''))
   if match: centers.append(tuple(map(float,match.groups())))
  for x,y in centers:
   if 0<=x<size and 0<=y<size:
    offsets_x=[0]+([size] if x<radius else [])+([-size] if x>size-radius else [])
    offsets_y=[0]+([size] if y<radius else [])+([-size] if y>size-radius else [])
    for dx in offsets_x:
     for dy in offsets_y:
      assert any(abs(cx-x-dx)<.002 and abs(cy-y-dy)<.002 for cx,cy in centers), (pattern.attrib['id'],x,y,dx,dy)
`;
const xml=spawnSync('python3',['-c',xmlCode],{input:JSON.stringify([...output,overlap,coast,layered]),encoding:'utf8'});assert.equal(xml.status,0,xml.stderr);
// Long strokes are cached as geometry and a run uses one surface, not one texture per pass.
const strokes=Array.from({length:500},(_,i)=>({...earth,points:[{x:i/1000,y:.3},{x:.6,y:.4}]}));const bulk=renderTerrainStrokes(strokes,1600,1000,'bulk');assert.equal((bulk.match(/data-material-detail=/g)||[]).length,1);assert.equal((bulk.match(/data-terrain-material=/g)||[]).length,1);
console.log('Atlas materials: seventeen vector identities, seamless wrapped motifs, independent tile periods, shared swatches/intensity, stable map scale, exact repeat-pass idempotence, ordered/layered coastal masks, XML/export integrity, JSON round trips and bounded cached artwork passed without rendering a UI.');
