import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const P=loadLocal('../src/worldBrowserPreferences.ts');
const savedStorage=globalThis.localStorage;const values=new Map();globalThis.localStorage={getItem:key=>values.get(key)??null,setItem:(key,value)=>values.set(key,value)};
try{
 assert.equal(P.readBrowserWidth('a'),280);P.rememberBrowserWidth('a',390);assert.equal(P.readBrowserWidth('a'),390);assert.equal(P.readBrowserWidth('b'),280);
 P.rememberBrowserWidth('a',900);assert.equal(P.readBrowserWidth('a'),460);P.rememberBrowserWidth('a',0);assert.equal(P.readBrowserWidth('a'),220);
 values.set('write-studio.world-browser.a','broken');assert.equal(P.readBrowserWidth('a'),280);
 globalThis.localStorage={getItem(){throw Error('blocked');},setItem(){throw Error('blocked');}};assert.equal(P.readBrowserWidth('a'),280);assert.doesNotThrow(()=>P.rememberBrowserWidth('a',300));
}finally{if(savedStorage===undefined)delete globalThis.localStorage;else globalThis.localStorage=savedStorage;}
const require=createRequire(import.meta.url),React=require('react'),savedRef=React.useRef;
try{
 React.useRef=initial=>({current:initial});const Resize=loadLocal('../src/PanelResize.tsx').default;let changes=[];
 const panel=Resize({side:'left',width:280,minimum:220,maximum:460,label:'World navigation',onChange:value=>changes.push(value)});
 assert.equal(panel.props.role,'separator');assert.equal(panel.props['aria-valuemin'],220);assert.equal(panel.props['aria-label'],'World navigation');
 const key=value=>panel.props.onKeyDown({key:value,preventDefault(){}});key('ArrowRight');key('Home');key('End');key('Escape');assert.deepEqual(changes,[296,220,460]);
 let captured=false;const target={focus(){},setPointerCapture(){captured=true;},hasPointerCapture(){return captured;},releasePointerCapture(){captured=false;}};
 const event=x=>({button:0,clientX:x,pointerId:1,currentTarget:target,preventDefault(){}});
 panel.props.onPointerDown(event(100));panel.props.onPointerMove(event(210));assert.equal(changes.at(-1),390);
 panel.props.onPointerCancel();assert.equal(changes.at(-1),280);
 panel.props.onPointerDown(event(100));panel.props.onPointerMove(event(999));assert.equal(changes.at(-1),460);
 panel.props.onPointerUp(event(999));assert.equal(captured,false);
 // Existing timeline right-hand resizing retains its direction and bounds.
 const right=Resize({side:'right',width:320,onChange:value=>changes.push(value)});right.props.onKeyDown({key:'ArrowRight',preventDefault(){}});assert.equal(changes.at(-1),304);assert.equal(right.props['aria-valuemax'],480);
}finally{React.useRef=savedRef;}
console.log('World browser: per-project width, clamping, invalid/blocked storage, accessible splitter, keyboard, drag/cancel and timeline direction passed.');
// Inspect the real editor controls and exercise template filtering without mounting a UI.
const previous={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
try{
 React.useState=initial=>[typeof initial==='function'?initial():initial,()=>{}];React.useRef=initial=>({current:initial});React.useEffect=()=>{};
 const Editor=loadLocal('../src/WorldbuildingEditor.tsx').default;
 const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
 const world={schemaVersion:10,templates:[{id:'z',title:'Zoología',fields:[]},{id:'a',title:'Armas',fields:[]}],entries:[{id:'e',title:'Sword',templateId:'a',values:{},archived:false},{id:'old',title:'Old sword',templateId:'a',values:{},archived:true}]};
 let selected;
 const tree=nodes(Editor({world,projectId:'test',onChange(){},onReturn(){},tab:'entries',setTab(){},entryId:'',setEntryId:id=>selected=id}));
 const selector=tree.find(n=>n.props?.id==='world-template-filter');assert.equal(selector.props.searchable,true);assert.deepEqual(selector.props.options.slice(1).map(o=>o.label),['Armas · 1','Zoología · 0']);
 selector.props.onChange('a');assert.equal(selected,'');
 const emptyTree=nodes(Editor({world:{schemaVersion:10,templates:[],entries:[]},projectId:'empty-test',onChange(){},onReturn(){},tab:'entries',setTab(){},entryId:'',setEntryId(){}}));assert(emptyTree.some(n=>n.props?.id==='lore-entry-browser'),'Empty projects retain the entry sidebar');assert(emptyTree.some(n=>n.props?.className==='world-browser-resize'));assert(emptyTree.some(n=>n.props?.className==='world-create-entry quick-action primary-button'||n.props?.className==='quick-action primary-button world-create-entry'));assert(emptyTree.some(n=>n.type==='h3'&&n.props.children==='Create your first template'));assert(emptyTree.some(n=>n.props?.['aria-label']==='New template'&&n.props?.className?.includes('world-create-entry')),'The sidebar creates a template until entries can be created');
 const divider=tree.find(n=>n.props?.className==='world-browser-resize');assert.equal(divider.props.minimum,220);assert.equal(divider.props.maximum,460);
}finally{Object.assign(React,previous);}
console.log('World editor controls: searchable alphabetical template choices, active counts and guarded selection passed.');

const {normalizeOptionText}=loadLocal('../src/dropdownNavigation.ts');assert(normalizeOptionText('Organización').includes(normalizeOptionText('organizacion')));
const {matchingOption}=loadLocal('../src/dropdownNavigation.ts');
assert.equal(matchingOption([{value:'o',label:'Organización · 12',searchText:'Organización'}],'12',0),-1);
assert.equal(matchingOption([{value:'o',label:'Organización · 12',searchText:'Organización'}],'organizacion',0),0);
const savedHooks={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
try{
 let values=[],cursor=0;
 React.useState=initial=>{const i=cursor++;if(!(i in values))values[i]=typeof initial==='function'?initial():initial;return[values[i],value=>values[i]=typeof value==='function'?value(values[i]):value];};React.useRef=initial=>({current:initial});React.useEffect=()=>{};
 const Editor=loadLocal('../src/WorldbuildingEditor.tsx').default;
 const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
 const world={schemaVersion:10,templates:[{id:'t',title:'People',fields:[{id:'ref',label:'Friend',fieldType:'reference'}]}],entries:[{id:'target',title:'Target',templateId:'t',archived:false,values:{}},{id:'other',title:'Someone else',templateId:'t',archived:false,linkAliases:['Target alias'],values:{ref:{entryId:'target'}}}]};
 const render=()=>{cursor=0;return nodes(Editor({world,projectId:'test-name',onChange(){},onReturn(){},tab:'entries',setTab(){},entryId:'',setEntryId(){}}));};
 let tree=render();tree.find(n=>n.props?.id==='world-search').props.onChange({target:{value:'Target'}});tree=render();
 assert.deepEqual(tree.filter(n=>n.props?.className==='entry-list-title').map(n=>n.props.children),['Target']);
 assert.equal(tree.find(n=>n.props?.id==='world-template-filter').props.options[1].searchText,'People');
}finally{Object.assign(React,savedHooks);}

const {worldBrowserHeight}=loadLocal('../src/worldBrowserLayout.ts');
assert.equal(worldBrowserHeight({top:140,bottom:720},160,20),548);
assert.equal(worldBrowserHeight({top:220,bottom:720},240,20),468,'Wrapped headers reduce the real available height');
assert.equal(worldBrowserHeight({top:140,bottom:520},160,20),348,'Short windows keep the list above the footer');
assert.equal(worldBrowserHeight({top:140,bottom:720},140,20),548,'Sticky position never consumes the reserved top padding');
assert.equal(worldBrowserHeight({top:0,bottom:0},0,20),undefined,'Ignore retained hidden workspaces');
assert.equal(worldBrowserHeight({top:100,bottom:110},150,20),0);
console.log('World browser bounds: actual workspace/footer geometry, wrapped headers, short windows, sticky offsets and hidden workspaces passed without UI.');
// Template creation stages its name in the shared modal, outside the browser/detail grid.
let creationHooks=[],creationIndex=0,createdWorld;
const creationWorld={schemaVersion:11,templates:[{id:'existing',schemaVersion:11,title:'People',fields:[]}],entries:[]};
const creationProps={world:creationWorld,projectId:'creation',entryId:'',tab:'templates',setEntryId(){},setTab(value){creationProps.tab=value;},onReturn(){},onChange(value){createdWorld=value;creationProps.world=value;}};
try{
 React.useState=initial=>{const i=creationIndex++;if(!(i in creationHooks))creationHooks[i]=typeof initial==='function'?initial():initial;return [creationHooks[i],value=>creationHooks[i]=typeof value==='function'?value(creationHooks[i]):value];};React.useRef=initial=>({current:initial});React.useEffect=()=>{};
 const Editor=loadLocal('../src/WorldbuildingEditor.tsx').default;
 const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
 const render=()=>{creationIndex=0;return nodes(Editor(creationProps));};let tree=render();
 const open=()=>{tree.find(n=>n.props?.className==='world-add-button primary-button').props.onClick();tree=render();};
 const modal=()=>tree.find(n=>n.type?.name==='ProjectModal'&&n.props.title==='New template');
 open();assert(modal());assert.equal(tree.find(n=>n.type==='button'&&n.props.children==='Create').props.disabled,true);
 const workspace=tree.find(n=>n.props?.className?.startsWith('world-scroll world-editor-content'));
 assert(!nodes(workspace).some(n=>n.props?.id==='world-new-name'),'The create form is outside workspace flow');
 modal().props.onClose();tree=render();assert(!modal());assert.equal(createdWorld,undefined);
 open();tree.find(n=>n.props?.id==='world-new-name').props.onChange({target:{value:'  Places  '}});tree=render();
 modal().props.onClose();tree=render();assert(nodes(modal()).find(n=>n.type==='form').props.inert);
 tree.find(n=>n.type?.name==='ProjectModal'&&n.props.variant==='confirmation').props.onClose();tree=render();assert.equal(tree.find(n=>n.props?.id==='world-new-name').props.value,'  Places  ');
 nodes(modal()).find(n=>n.type==='form').props.onSubmit({preventDefault(){}});tree=render();
 assert(!modal());assert.equal(createdWorld.templates.length,2);assert.equal(createdWorld.templates[1].title,'Places');assert.equal(createdWorld.entries,creationWorld.entries);
 assert(tree.some(n=>n.type==='button'&&n.props['aria-pressed']&&nodes(n).some(child=>child.props?.children==='Places')));
}finally{Object.assign(React,previous);}
console.log('Template creation: shared popup outside workspace flow, blank-name validation, safe dismissal, trimmed creation and selection passed without UI.');

// Compact browsers reveal the selected canonical object without changing project data.
{
 const hooks={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect},raf=globalThis.requestAnimationFrame,htmlElement=globalThis.HTMLElement;
 let state=[],refs=[],i=0,r=0,focus=0;
 const world={schemaVersion:11,templates:[{id:'people',title:'People',fields:[]}],entries:[{id:'ada',templateId:'people',title:'Ada',values:{},archived:false}]};
 const before=JSON.stringify(world),props={world,entryId:'',tab:'entries',setEntryId(id){props.entryId=id;},setTab(tab){props.tab=tab;},onReturn(){},onChange(){throw Error('Browsing must not change content');}};
 const Editor=loadLocal('../src/WorldbuildingEditor.tsx').default,Create=loadLocal('../src/EntryCreateDialog.tsx').default;
 const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
 try{
  React.useState=initial=>{const k=i++;if(!(k in state))state[k]=typeof initial==='function'?initial():initial;return[state[k],next=>state[k]=typeof next==='function'?next(state[k]):next];};
  React.useRef=initial=>refs[r++]??(refs[r-1]={current:initial});React.useEffect=()=>{};globalThis.requestAnimationFrame=fn=>{fn();return 1;};
  globalThis.HTMLElement=class {};
  const render=()=>{i=0;r=0;const tree=nodes(Editor(props));tree.find(n=>n.props?.className?.startsWith('world-scroll world-editor-content')).props.ref.current={ownerDocument:{activeElement:null},clientWidth:650,closest:()=>({clientWidth:650}),querySelectorAll:()=>[],querySelector:()=>({focus(){focus++;}})};return tree;};
  let tree=render();tree.find(n=>n.type==='button'&&n.props['aria-label']==='Browse entries').props.onClick();tree=render();assert(tree.some(n=>n.props?.className?.includes(' world-browser-open')));
  tree.find(n=>n.key==='ada').props.onClick();tree=render();assert.equal(props.entryId,'ada');assert(!tree.some(n=>n.props?.className?.includes(' world-browser-open')));assert.equal(focus,1);
  tree.find(n=>n.type?.name==='WorldNavigation').props.onSelect('templates');tree=render();assert(tree.some(n=>n.props?.className?.includes(' world-template-browser-open')));
  tree.find(n=>n.key==='people'&&n.type==='button').props.onClick();tree=render();assert(!tree.some(n=>n.props?.className?.includes(' world-template-browser-open')));assert.equal(focus,2);assert.equal(JSON.stringify(world),before);
  // A changed creation form survives Escape and confirmation cancellation.
  state=[];refs=[];let closed=0;const createProps={world,initialTemplateId:'people',onSave(){},onCancel(){closed++;}};
  const form=()=>{i=0;r=0;return nodes(Create(createProps));};tree=form();tree.find(n=>n.type==='dialog').props.onCancel({preventDefault(){}});assert.equal(closed,1);
  tree.find(n=>n.props?.id==='new-entry-name').props.onChange({target:{value:'Keep this draft'}});tree=form();tree.find(n=>n.type==='dialog').props.onCancel({preventDefault(){}});tree=form();assert.equal(closed,1);assert(tree.find(n=>n.type==='form').props.inert);
  tree.find(n=>n.type?.name==='ProjectModal').props.onClose();tree=form();assert.equal(tree.find(n=>n.props?.id==='new-entry-name').props.value,'Keep this draft');assert.equal(tree.find(n=>n.type==='form').props.inert,false);
 }finally{Object.assign(React,hooks);if(htmlElement===undefined)delete globalThis.HTMLElement;else globalThis.HTMLElement=htmlElement;if(raf===undefined)delete globalThis.requestAnimationFrame;else globalThis.requestAnimationFrame=raf;}
}
console.log('World UX: compact entry/template selection reveals neutral detail focus, filters/content stay intact, and entry creation protects changed drafts.');
