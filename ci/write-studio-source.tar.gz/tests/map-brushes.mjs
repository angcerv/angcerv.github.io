import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
import {loadLocal} from './load-local.mjs';
const B=loadLocal('../src/mapBrush.ts'),D=loadLocal('../src/mapDrawing.ts'),{updateMap}=loadLocal('../src/maps.ts'),{expandMapCanvas}=loadLocal('../src/mapCanvasExpansion.ts');
const points=[{x:.1,y:.2},{x:.8,y:.2}],base={width:1600,height:1000,objects:[],strokes:[]},stroke={kind:'land',width:.1,material:'grass',color:'#567845',textureIntensity:.6,points};
const outputs=[];
for(const settings of [{brushShape:'star'},{brushShape:'irregular'},{softness:.05},{softness:.5},{softness:1}])for(const material of ['grass',undefined]){
 const brush={...stroke,...settings,material},drawing={...base,strokes:[brush]},svg=D.drawingSvg(drawing);outputs.push(svg);
 assert(svg.includes('<use href="#ws-brush-'));assert(!svg.includes('<filter'));assert(!svg.includes('feGaussianBlur'));assert(svg.includes('fill="#567845"'));
 if(settings.softness)assert(svg.includes('<radialGradient'));
 const ids=[...svg.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(ids.length,new Set(ids).size);for(const match of svg.matchAll(/(?:url\(#|href="#)([^)" ]+)/g))assert(ids.includes(match[1]),match[1]);
 assert.equal(D.drawingSvg(JSON.parse(JSON.stringify(drawing))),svg);assert.equal(JSON.stringify(drawing),JSON.stringify({...base,strokes:[brush]}));
 if(material)assert.equal(D.drawingSvg({...drawing,strokes:[brush,{...brush}]}),svg,'Identical material passes retain their existing idempotence');
}
assert.equal(B.starBrushPoints().split(' ').length,10);
const organic=B.irregularBrushPoints().split(' ').map(p=>p.split(',').map(Number));assert.equal(organic.length,96);const radii=organic.map(([x,y])=>Math.hypot(x,y));assert(Math.min(...radii)>.78&&Math.max(...radii)<=1.001,'The irregular footprint stays compact without deep star notches');for(let i=0;i<radii.length;i++)assert(Math.abs(radii[i]-radii[(i+1)%radii.length])<.09,'Many short sides retain a rounded organic contour');assert.equal(B.polygonBrushPoints('irregular'),B.irregularBrushPoints());
const organicMap={id:'organic',imageId:'image',markers:[],drawing:{...base,strokes:[{...stroke,brushShape:'irregular'}]}};assert.equal(updateMap({schemaVersion:23,maps:[organicMap]},organicMap).schemaVersion,24);
assert.equal(B.brushDabs([{x:.5,y:.5}],1600,1000,80).length,1);
assert.deepEqual(B.brushDabs(points,1600,1000,80).map(p=>({x:+p.x.toFixed(6),y:+p.y.toFixed(6)})),B.brushDabs([points[0],{x:.45,y:.2},points[1]],1600,1000,80).map(p=>({x:+p.x.toFixed(6),y:+p.y.toFixed(6)})),'Dab density does not depend on pointer frequency');
const zigzag=Array.from({length:2000},(_,i)=>({x:i%2,y:(i%3)/2}));assert(B.brushDabs(zigzag,4096,4096,.001).length<=4096);
const erased={...base,strokes:[{...stroke,softness:.5},{kind:'land',erase:true,softness:1,width:.05,points},{...stroke,brushShape:'star'}]},erasedSvg=D.drawingSvg(erased);assert(erasedSvg.includes('href="#ws-brush-soft-1000-ink-black"'));assert(erasedSvg.includes('data-terrain-erased="true"'));outputs.push(erasedSvg);
const xml=spawnSync('python3',['-c','import json,sys,xml.etree.ElementTree as E\nfor svg in json.load(sys.stdin): E.fromstring(svg)'],{input:JSON.stringify(outputs),encoding:'utf8'});assert.equal(xml.status,0,xml.stderr);
const map={id:'m',imageId:'i',markers:[],drawing:erased};assert.equal(updateMap({schemaVersion:22,maps:[map]},map).schemaVersion,23);const expanded=expandMapCanvas(map,{left:100,right:100,top:0,bottom:0});assert.equal(expanded.drawing.strokes[0].softness,.5);assert.equal(expanded.drawing.strokes[2].brushShape,'star');assert(Math.abs(expanded.drawing.strokes[0].width*expanded.drawing.width-stroke.width*1600)<1e-8);
const React=createRequire(import.meta.url)('react'),saved={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};const Editor=loadLocal('../src/MapDrawingEditor.tsx').default;
let state=[],refs=[],si=0,ri=0,applied;
const projectMap={id:'m',title:'Map',imageId:'i',markers:[],drawing:base},surface={getBoundingClientRect:()=>({left:0,top:0,width:800,height:500}),focus(){},setPointerCapture(){},hasPointerCapture:()=>true,releasePointerCapture(){}};
function nodes(n){if(n&&typeof n.type==='function'&&n.type.name==='DrawingToolRail')return nodes(n.type(n.props));return Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];}
const event=(x,y)=>({clientX:x,clientY:y,pointerId:1,button:0,isPrimary:true,currentTarget:surface,target:{closest:()=>null},preventDefault(){},stopPropagation(){}});
try{
 React.useState=initial=>{const i=si++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return[state[i],value=>state[i]=typeof value==='function'?value(state[i]):value];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 const render=()=>{si=0;ri=0;return nodes(Editor({map:projectMap,path:'/book',projectId:'p',onCancel(){},onSave:drawing=>applied=drawing}));};
 render();state[3]='image';state[4]=true;refs[1].current=surface;
 const button=label=>render().find(n=>n.type==='button'&&n.props['aria-label']===label),canvas=()=>render().find(n=>n.props?.['aria-label']==='Map drawing canvas'),panel=()=>render().find(n=>n.type?.name==='DrawingOptionsPanel');
 button('Irregular brush').props.onClick();canvas().props.onPointerDown(event(100,100));canvas().props.onPointerMove(event(300,200));canvas().props.onPointerUp(event(300,200));assert.equal(state[0].strokes[0].brushShape,'irregular');assert.equal(panel().props.open,true);assert.equal(panel().props.title,'Terrain');
 const editor=()=>render().find(n=>n.type==='dialog');editor().props.onKeyDown({target:{closest:()=>null},currentTarget:null,key:'z',ctrlKey:true,metaKey:false,altKey:false,shiftKey:false,preventDefault(){},stopPropagation(){}});assert.equal(state[0].strokes.length,0);assert.equal(panel().props.open,true);assert.equal(panel().props.title,'Terrain');assert.equal(button('Irregular brush').props['aria-pressed'],true);
 button('Redo').props.onClick();assert.equal(state[0].strokes.length,1);assert.equal(panel().props.open,true);assert.equal(button('Irregular brush').props['aria-pressed'],true);
 button('Round brush').props.onClick();render().find(n=>n.props?.id==='drawing-brush-softness').props.onChange({target:{value:'.65'}});canvas().props.onPointerDown(event(200,200));canvas().props.onPointerUp(event(200,200));assert.equal(state[0].strokes[1].softness,.65);assert.equal(state[0].strokes[1].brushShape,undefined);
 button('Undo').props.onClick();assert.equal(render().find(n=>n.props?.id==='drawing-brush-softness').props.value,.65);assert.equal(panel().props.open,true);button('Redo').props.onClick();
 const before=state[0].strokes.length;canvas().props.onPointerDown(event(100,100));canvas().props.onPointerMove(event(200,200));canvas().props.onPointerCancel(event(200,200));assert.equal(state[0].strokes.length,before);
 render().find(n=>n.type==='button'&&n.props.className==='primary-button').props.onClick();assert.equal(applied.strokes[1].softness,.65);
}finally{Object.assign(React,saved);}
console.log('Terrain brushes: deterministic organic polygon/legacy star dabs, shared radial softness, bounded geometry, valid vector resources, solid/material/eraser export, expansion and real Ctrl+Z/redo retaining the options panel passed.');
