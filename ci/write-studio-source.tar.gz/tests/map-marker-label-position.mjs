import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const U=loadLocal('../src/mapMarkerLabels.ts'),{layoutMapLabels}=loadLocal('../src/mapLabels.ts'),{updateMap}=loadLocal('../src/maps.ts'),{MapElementHistory}=loadLocal('../src/mapElementHistory.ts'),{expandMapCanvas}=loadLocal('../src/mapCanvasExpansion.ts');
for(const angle of [0,30,45,90,180,270,359])for(const distance of [8,30,96])for(const [w,h] of [[40,24],[240,60]]){
 const center=U.markerLabelCenter({angle,distance},w,h),back=U.markerLabelOffset(center,w,h);assert(Math.abs(back.distance-distance)<1e-5);assert(Math.min(Math.abs(back.angle-angle),360-Math.abs(back.angle-angle))<1e-5);
 assert(Math.abs(Math.hypot(Math.max(0,Math.abs(center.x)-w/2),Math.max(0,Math.abs(center.y)-h/2))-16-distance)<1e-5);
}
assert.equal(U.markerLabelOffset({x:10000,y:0},100,24).distance,96);assert.equal(U.markerLabelOffset({x:0,y:0},100,24).distance,8);
for(const name of ['Hércules','Ixelion','Aethis','Miura','Álvaro','Nueva Cuenca']){
 const box=layoutMapLabels([{id:'a',kind:'marker',text:name,point:{x:.5,y:.5}}],800,600,{measureText:text=>text.length*10}).get('a');assert.equal(box.text,name);assert.equal(box.height,24);assert(box.width>=name.length*10+14);
}
const marker={id:'marker',title:'Hércules',x:.5,y:.5,color:'teal',icon:'planet',labelOffset:{angle:180,distance:40}},item={id:marker.id,text:marker.title,kind:'marker',point:marker,labelOffset:marker.labelOffset};
for(const factor of [1,2,4,8]){const box=layoutMapLabels([item],800*factor,600*factor).get(marker.id);assert(box.visible);const offset=U.markerLabelOffset({x:box.x+box.width/2-marker.x*800*factor,y:box.y+box.height/2-marker.y*600*factor},box.width,box.height);assert(Math.abs(offset.distance-40)<1e-5);assert.equal(offset.angle,180);}
const map={id:'map',imageId:'image',title:'Map',markers:[{...marker,labelOffset:undefined}],drawing:{width:1600,height:1000,objects:[],strokes:[]}},changed={...map,markers:[marker]};
assert.equal(updateMap({schemaVersion:21,maps:[map]},changed).schemaVersion,22);const history=new MapElementHistory();history.record(map,changed);const undo=history.move(changed,'undo');assert.equal(undo.markers[0].labelOffset,undefined);assert.deepEqual(history.move(undo,'redo').markers[0].labelOffset,marker.labelOffset);
assert.deepEqual(expandMapCanvas(changed,{left:100,right:0,top:0,bottom:0}).markers[0].labelOffset,marker.labelOffset);
const React=createRequire(import.meta.url)('react'),saved={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const Label=loadLocal('../src/MapMarkerLabel.tsx').default;let state=[],refs=[],si=0,ri=0,commits=[],busy=[],selected=0;
const target={focus(){},setPointerCapture(){this.captured=true;},hasPointerCapture(){return this.captured;},releasePointerCapture(){this.captured=false;}};
const props={name:marker.title,point:marker,width:800,height:600,placement:layoutMapLabels([item],800,600).get(marker.id),offset:marker.labelOffset,selected:true,editable:true,interactive:true,onSelect:()=>selected++,onChange:offset=>commits.push(offset),onHover(){},onFocus(){},onInteractionChange:value=>busy.push(value)};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
const event=(x=100,y=100)=>({clientX:x,clientY:y,pointerId:1,isPrimary:true,button:0,currentTarget:target,preventDefault(){},stopPropagation(){}});
try{
 React.useState=initial=>{const i=si++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return[state[i],value=>state[i]=typeof value==='function'?value(state[i]):value];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 const button=(extra={})=>{si=0;ri=0;return nodes(Label({...props,...extra})).find(n=>n.type==='button');};
 button().props.onPointerDown(event());button().props.onPointerMove(event(1000,300));assert.equal(commits.length,0);assert.equal(busy.at(-1),true);button().props.onPointerUp(event(1200,500));assert.equal(commits.length,1);assert.equal(commits[0].distance,96);assert.equal(busy.at(-1),false);assert.equal(target.captured,false);
 button().props.onPointerDown(event());button().props.onPointerMove(event(200,200));button().props.onPointerCancel(event(200,200));assert.equal(commits.length,1);
 button().props.onPointerDown(event());button().props.onPointerMove(event(200,200));button().props.onKeyDown({...event(),key:'Escape'});button().props.onPointerUp(event(200,200));assert.equal(commits.length,1);
 button().props.onPointerDown(event());button().props.onPointerUp(event(101,101));assert.equal(commits.length,1,'Clicking never converts automatic placement into a saved offset');
 button({editable:false}).props.onPointerDown(event());assert.equal(target.captured,false);button({editable:false}).props.onKeyDown({...event(),key:'ArrowRight'});assert.equal(commits.length,1);
 button().props.onKeyDown({...event(),key:'ArrowRight',shiftKey:false});assert.equal(commits.length,2);button().props.onKeyDown({...event(),key:'Home'});assert.equal(commits.at(-1),undefined);
 button({selected:false,editable:false}).props.onClick(event());assert.equal(selected,1);
}finally{Object.assign(React,saved);}
console.log('Marker labels: full short names, measured wrapping, radial bounds, zoom-independent offsets, expansion, undo/redo, preview-only dragging, single commit, cancellation, locking and keyboard reset passed.');
