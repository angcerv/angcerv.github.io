import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {sampleDrawingColor}=loadLocal('../src/drawingColorSample.ts');
const {emptyDrawing}=loadLocal('../src/mapDrawing.ts');
const original={Image:globalThis.Image,document:globalThis.document};
let images=[],draws=[],canvases=[],pixel=[18,171,9,255],fail=false,pending;
try{
 globalThis.Image=class{
  naturalWidth=1600;naturalHeight=1000;src='';
  constructor(){images.push(this);}
  async decode(){if(fail)throw Error('Decode failed');if(pending)await pending;}
 };
 globalThis.document={createElement(tag){assert.equal(tag,'canvas');const canvas={width:0,height:0,getContext(){return {drawImage(...args){draws.push(args);},getImageData(){return {data:pixel};}};}};canvases.push(canvas);return canvas;}};
 const drawing=emptyDrawing();delete drawing.background;
 assert.equal(await sampleDrawingColor(drawing,[],'blob:import',{x:.25,y:.75},new AbortController().signal),'#12ab09');
 assert.equal(images.length,2);assert.equal(draws.length,2);
 assert.deepEqual(draws[0].slice(1),[400,750,1,1,0,0,1,1]);
 assert.equal(canvases[0].width,0);assert.equal(canvases[0].height,0);
 assert(images.every(image=>image.src===''),'Release decoded images');
 draws=[];images=[];
 assert.equal(await sampleDrawingColor({...drawing,background:'#112233'},[],'blob:import',{x:1,y:1},new AbortController().signal),'#12ab09');
 assert.equal(images.length,1,'Opaque map background replaces the imported image');
 assert.deepEqual(draws[0].slice(1),[1599,999,1,1,0,0,1,1]);
 pixel=[0,0,0,0];await assert.rejects(()=>sampleDrawingColor(drawing,[],'',{x:0,y:0},new AbortController().signal),/no color/);pixel=[0,0,0,255];
 fail=true;await assert.rejects(()=>sampleDrawingColor(drawing,[],'',{x:0,y:0},new AbortController().signal),/Decode failed/);fail=false;
 const controller=new AbortController();let release;pending=new Promise(resolve=>release=resolve);
 const job=sampleDrawingColor(drawing,[],'',{x:0,y:0},controller.signal);controller.abort();release();assert.equal(await job,undefined);pending=undefined;
 assert(canvases.every(canvas=>canvas.width===0&&canvas.height===0));
}finally{for(const [key,value] of Object.entries(original)){if(value===undefined)delete globalThis[key];else globalThis[key]=value;}}
console.log('Drawing eyedropper: map-space sampling, image/background composition, bounded canvas, hex color, transparent/error handling, cancellation and resource cleanup passed using mocks only.');
