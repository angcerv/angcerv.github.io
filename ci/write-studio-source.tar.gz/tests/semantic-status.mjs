import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import postcss from 'postcss';
import {createElement} from 'react';
import {createRequire} from 'node:module';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const {statusTone}=loadLocal('../src/semanticStatus.ts');
for(const domain of ['plot','arc']){
 assert.equal(statusTone(domain,'planned'),'neutral');assert.equal(statusTone(domain,'active'),'progress');assert.equal(statusTone(domain,'resolved'),'success');
}
assert.equal(statusTone('writing','draft'),statusTone('plot','active'));
assert.equal(statusTone('writing','inReview'),'review');assert.equal(statusTone('idea','deciding'),'attention');
assert.equal(statusTone('idea','incorporated'),'success');assert.equal(statusTone('idea','discarded'),'neutral');
assert.equal(statusTone('relationship','active'),'neutral');assert.notEqual(statusTone('relationship','active'),statusTone('arc','active'));
assert.equal(statusTone('relationship','ended'),'neutral');assert.equal(statusTone('relationship','future'),'neutral');assert.equal(statusTone('relationship','uncertain'),'attention');
assert.equal(statusTone('continuity','broken'),'error');assert.equal(statusTone('continuity','unused'),'info');assert.equal(statusTone('idea','all'),undefined);assert.equal(statusTone('plot','teal'),undefined);
const base=postcss.parse(readFileSync(new URL('../src/App.css',import.meta.url),'utf8'));
const styles=postcss.parse(readFileSync(new URL('../src/styles/semantic-status.css',import.meta.url),'utf8'));
const luminance=hex=>(hex.length===4?hex.slice(1).split('').map(x=>x+x).join(''):hex.slice(1)).match(/../g).map(x=>parseInt(x,16)/255).map(x=>x<=.04045?x/12.92:((x+.055)/1.055)**2.4).reduce((v,x,i)=>v+x*[.2126,.7152,.0722][i],0);
const contrast=(a,b)=>{const x=luminance(a),y=luminance(b);return(Math.max(x,y)+.05)/(Math.min(x,y)+.05);};
for(const theme of ['dark','light']){
 const tokens={};for(const tree of [base,styles]){tree.walkRules(':root',rule=>rule.walkDecls(decl=>tokens[decl.prop]=decl.value));if(theme==='light')tree.walkRules(':root[data-theme=light]',rule=>rule.walkDecls(decl=>tokens[decl.prop]=decl.value));}
 const resolve=value=>value.startsWith('var(')?resolve(tokens[value.slice(4,-1)]):value;
 for(const tone of ['neutral','progress','review','success','attention','error','info']){
  const ink=resolve(tokens[`--semantic-${tone}-text`]);
  for(const background of [`--semantic-${tone}-bg`,'--editor','--surface','--hover'])assert(contrast(ink,resolve(tokens[background]))>=4.5,`${theme} ${tone} on ${background} must meet 4.5:1`);
 }
}
const Dropdown=loadLocal('../src/Dropdown.tsx').default;
const marked=renderToStaticMarkup(createElement(Dropdown,{id:'status',value:'done',options:[{value:'done',label:'Finished',tone:'success'}],onChange(){}}));
assert(marked.includes('class="dropdown-value" data-semantic-tone="success"'));assert(marked.includes('Finished'));assert(marked.includes('role="combobox"'));
const identity=renderToStaticMarkup(createElement(Dropdown,{id:'color',value:'teal',options:[{value:'teal',label:'Teal'}],onChange(){}}));assert(!identity.includes('data-semantic-tone='));
// Exercise the real portal branch without a browser or DOM implementation.
const require=createRequire(import.meta.url),React=require('react'),ReactDOM=require('react-dom');
const hooks={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect,useLayoutEffect:React.useLayoutEffect,useId:React.useId},portal=ReactDOM.createPortal,previousDocument=globalThis.document;
function nodes(n){if(Array.isArray(n))return n.flatMap(nodes);if(!n||typeof n!=='object')return [];return[n,...nodes(n.props?.children)];}
try{
 let index=0;const states=['',true,0,{left:8,width:200,maxHeight:280,top:40,side:'bottom'}];
 React.useState=()=>[states[index++],()=>{}];React.useRef=value=>({current:value});React.useEffect=()=>{};React.useLayoutEffect=()=>{};React.useId=()=> 'semantic-options';ReactDOM.createPortal=children=>children;globalThis.document={body:{}};
 const tree=nodes(Dropdown({id:'portal-status',value:'done',options:[{value:'done',label:'Finished',tone:'success'},{value:'all',label:'All statuses'}],onChange(){}}));
 const options=tree.filter(n=>n.props?.role==='option');assert.equal(options.length,2);assert.equal(options[0].props['aria-selected'],true);
 const label=nodes(options[0]).find(n=>n.props?.className==='semantic-label');assert.equal(label.props['data-semantic-tone'],'success');assert.equal(label.props.children,'Finished');assert(!nodes(options[1]).some(n=>n.props?.['data-semantic-tone']));
}finally{Object.assign(React,hooks);ReactDOM.createPortal=portal;if(previousDocument===undefined)delete globalThis.document;else globalThis.document=previousDocument;}
console.log('Semantic states: domain distinctions, shared equivalents, both theme palettes at 4.5:1 on badge/editor/surface/hover, opt-in dropdown labels and untouched identity selectors passed.');
