import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const Welcome=loadLocal('../src/WelcomeScreen.tsx').default,Recent=loadLocal('../src/RecentProjects.tsx').default,AppMenu=loadLocal('../src/AppMenu.tsx').default,Picker=loadLocal('../src/LocalProjectsDialog.tsx').default;
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
const older={path:'/library/older',title:'Same title',lastOpened:1},newer={path:'/library/newer',title:'Same title',lastOpened:10},projects=[older,newer];
let opened=[];const props={projects,loading:false,error:'',onOpen:(...args)=>opened.push(args),onRetry(){},onNew(){},onBrowse(){}};
let tree=nodes(Welcome(props));tree.find(n=>n.props?.className?.includes('welcome-continue')).props.onClick();assert.deepEqual(opened,[[newer.path,newer.title]]);assert.equal(projects[0],older);
for(const override of [{projects:[]},{loading:true},{error:'Unavailable'}])assert(!nodes(Welcome({...props,...override})).some(n=>n.props?.className?.includes('welcome-continue')));
assert(nodes(Welcome({...props,openingPath:newer.path})).filter(n=>n.type==='button').every(n=>n.props.disabled));
const menu=AppMenu({disabled:false,onNew(){},onOpen(){},onOpenRecent:path=>opened.push(path),recents:projects});
const recentActions=menu.props.actions.filter(a=>a.group==='Recent projects');assert.equal(new Set(recentActions.map(a=>a.id)).size,2);assert.notEqual(recentActions[0].description,recentActions[1].description);recentActions[1].onClick();assert.equal(opened.at(-1),newer.path);
const html=renderToStaticMarkup(createElement(Recent,{...props,local:true,variant:'selector',projects:[],totalCount:10,emptyMessage:'No match'}));assert(html.includes('0 of 10 projects'));assert(html.includes('No match'));
const React=createRequire(import.meta.url)('react'),hooks={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
try{
 let values=[Array.from({length:7},(_,i)=>({...older,path:`/library/book-${i}`,title:i===2?'Target':'Other'})),false,'',0,false,''],si=0,closed=0;
 React.useState=initial=>{const i=si++;return[values[i]??initial,next=>values[i]=typeof next==='function'?next(values[i]):next];};React.useRef=initial=>({current:initial});React.useEffect=()=>{};
 const render=()=>{si=0;return Picker({onOpen(){},onClose(){closed++;}});};
 let picker=render(),search=nodes(picker).find(n=>n.type==='input');search.props.onChange({target:{value:'BOOK-2'}});picker=render();let list=nodes(picker).find(n=>n.type===Recent);assert.equal(list.props.projects.length,1);assert.equal(list.props.projects[0].title,'Target');assert(picker.props.className.includes('filterable'));
 search=nodes(picker).find(n=>n.type==='input');search.props.onKeyDown({key:'Escape',preventDefault(){},stopPropagation(){}});assert.equal(values[5],'');assert.equal(closed,0);search=nodes(render()).find(n=>n.type==='input');search.props.onKeyDown({key:'Escape',preventDefault(){},stopPropagation(){}});assert.equal(closed,1);
}finally{Object.assign(React,hooks);}
console.log('Start experience: latest-project routing, busy/empty/error states, duplicate project titles, folder filtering/counts and Escape cancellation passed without UI.');

const {newProject,newScene}=loadLocal('../src/model.ts'),I=loadLocal('../src/i18n.ts'),language=I.getLanguage();
try{
 for(const lang of ['en','es']){I.setLanguage(lang);const chapterTitle=I.t('Chapter {0}',1),sceneTitle=I.t('Scene {0}',1),project=newProject('A user title',{chapterTitle,sceneTitle});assert.equal(project.title,'A user title');assert.equal(project.chapters[0].title,chapterTitle);assert.equal(project.chapters[0].scenes[0].title,sceneTitle);assert.equal(newScene(sceneTitle).title,sceneTitle);I.setLanguage(lang==='es'?'en':'es');assert.equal(project.chapters[0].title,chapterTitle,'Changing interface language never renames saved content');}
}finally{I.setLanguage(language);}
console.log('New project/chapter defaults accept localized initial names without renaming existing content.');
