import assert from 'node:assert/strict';
import {createElement} from 'react';
import {createRequire} from 'node:module';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const RecentProjects=loadLocal('../src/RecentProjects.tsx').default,ProjectDialogs=loadLocal('../src/ProjectDialogs.tsx').default;
const project={path:'/sandbox/Documents/Projects/story',projectId:'id',title:'Local story',lastOpened:123};
const props={projects:[project],loading:false,error:'',onOpen(){},onRetry(){}};
const local=renderToStaticMarkup(createElement(RecentProjects,{...props,local:true}));
assert(local.includes('Local story'));assert(local.includes('Projects on this device'));assert(!local.includes('Last opened'));assert(!local.includes('recent-menu'));assert(!local.includes('moves the entire folder'));
const selector=renderToStaticMarkup(createElement(RecentProjects,{...props,local:true,variant:'selector',libraryTitle:'Projects'}));
assert(selector.includes('recent-projects-selector'));assert(selector.includes('…/Projects/story'));assert(selector.includes('1 projects'));assert(!selector.includes('Last opened'));
const picker=loadLocal('../src/LocalProjectsDialog.tsx').default;
const pickerHtml=renderToStaticMarkup(createElement(picker,{directory:'/sandbox/WriteStudio/',onOpen(){},onClose(){},onBrowse(){}}));
assert(pickerHtml.includes('>WriteStudio</h2>'));assert(!pickerHtml.includes('Projects in selected folder'));assert(pickerHtml.includes('<footer class="local-projects-footer">'));assert(pickerHtml.includes('Choose another folder'));assert(pickerHtml.includes('Loading projects'));
const opening=renderToStaticMarkup(createElement(RecentProjects,{...props,openingPath:project.path}));
assert(opening.includes('aria-busy="true"'));assert(opening.includes('disabled=""'));assert(opening.includes('ui-loading-spinner'));assert(opening.includes('role="status"'));
const recent=renderToStaticMarkup(createElement(RecentProjects,{...props,onForget(){}}));assert(recent.includes('Recent projects'));assert(recent.includes('Last opened'));assert(recent.includes('recent-menu'));
const empty=renderToStaticMarkup(createElement(RecentProjects,{...props,projects:[],local:true}));assert(empty.includes('No local projects yet.'));
const both=renderToStaticMarkup(createElement('div',null,createElement(RecentProjects,props),createElement(RecentProjects,{...props,local:true})));const ids=[...both.matchAll(/<h2 id="([^"]+)"/g)].map(match=>match[1]);assert.equal(new Set(ids).size,2);
const dialogProps={kind:'new',settings:{schemaVersion:1,projectsDirectory:'/sandbox/Documents/Projects',localProjects:true},busy:false,error:'',name:'Story',folderName:'story',theme:'dark',onName(){},onFolderName(){},onChooseDirectory(){},onCreate(){},onClose(){},onTheme(){}};
const dialog=renderToStaticMarkup(createElement(ProjectDialogs,dialogProps));assert(dialog.includes('On this device'));assert(dialog.includes('Create project'));assert(dialog.includes('>Change</button>'));assert(!dialog.includes('creation-path'));
console.log('Local projects: shared list variant, empty state, separate accessible headings, desktop actions and managed creation location passed without UI.');

const external=renderToStaticMarkup(createElement(ProjectDialogs,{...dialogProps,settings:{schemaVersion:1,projectsDirectory:'/library/stories/',localProjects:false}}));
assert(external.includes('Create in:'));assert(external.includes('/library/stories/story'));assert(!external.includes('creation-path'));assert(external.includes('aria-controls="project-folder-editor"'));assert(external.includes('aria-hidden="true"'));
const windows=renderToStaticMarkup(createElement(ProjectDialogs,{...dialogProps,settings:{schemaVersion:1,projectsDirectory:'C:\\Stories\\',localProjects:false}}));assert(windows.includes('C:\\Stories\\story'));assert(!windows.includes('Stories\\/'));
// Exercise cancellation/failure/success without opening a native picker or UI.
const React=createRequire(import.meta.url)('react'),storage=loadLocal('../src/storage.ts');
const hooks={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect},choose=storage.chooseFolder;
let values=[],refs=[],si=0,ri=0,calls=0,chosen=[],release;
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
const flush=async()=>{for(let i=0;i<8;i++)await Promise.resolve();};
try{
 React.useState=initial=>{const i=si++;if(!(i in values))values[i]=typeof initial==='function'?initial():initial;return[values[i],next=>values[i]=typeof next==='function'?next(values[i]):next];};
 React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 const render=()=>{si=ri=0;return picker({directory:'/library/stories',onOpen(){},onClose(){},onBrowse:path=>chosen.push(path)});};
 const browse=tree=>nodes(tree).find(n=>n.type==='button');
 render();values[0]=[project];values[1]=false;
 storage.chooseFolder=async()=>{calls++;return await new Promise(resolve=>release=resolve);};
 const button=browse(render());button.props.onClick();button.props.onClick();let tree=render();assert.equal(calls,1);assert.equal(tree.props.busy,true);assert.equal(browse(tree).props.disabled,true);assert.equal(nodes(tree).find(n=>n.type===RecentProjects).props.disabled,true);
 release(null);await flush();tree=render();assert.equal(tree.props.busy,false);assert.deepEqual(chosen,[]);assert.deepEqual(nodes(tree).find(n=>n.type===RecentProjects).props.projects,[project]);
 storage.chooseFolder=async()=>{throw Error('Folder unavailable');};browse(tree).props.onClick();await flush();tree=render();assert.equal(tree.props.busy,false);assert.match(nodes(tree).find(n=>n.type===RecentProjects).props.error,/Folder unavailable/);
 storage.chooseFolder=async()=>'/another/story';browse(tree).props.onClick();await flush();assert.deepEqual(chosen,['/another/story']);assert.equal(render().props.busy,false);
}finally{Object.assign(React,hooks);storage.chooseFolder=choose;}
console.log('Project picker: cancellation retains the list, duplicate requests are blocked, errors stay visible and only selection navigates.');

// Collapsed folder fields cannot steal focus or invalidate the creation form.
const savedHooks={useState:React.useState},savedDocument=globalThis.document;
try{
 let expanded=false,valid=true;
 React.useState=initial=>[expanded,next=>{expanded=typeof next==='function'?next(expanded):next;}];
 globalThis.document={getElementById(){return {reportValidity:()=>valid};}};
 const render=()=>nodes(ProjectDialogs(dialogProps));
 const toggle=tree=>tree.find(n=>n.type==='button'&&n.props['aria-controls']==='project-folder-editor');
 let tree=render();assert.equal(tree.find(n=>n.props?.id==='project-folder-name').props.disabled,true);
 toggle(tree).props.onClick();tree=render();assert.equal(tree.find(n=>n.props?.id==='project-folder-name').props.disabled,false);assert.equal(tree.find(n=>n.props?.id==='project-folder-editor').props.inert,false);
 valid=false;toggle(tree).props.onClick();assert.equal(expanded,true);
 valid=true;toggle(render()).props.onClick();tree=render();assert.equal(expanded,false);assert.equal(tree.find(n=>n.props?.id==='project-folder-editor').props.inert,true);assert.equal(tree.find(n=>n.props?.id==='project-folder-name').props.disabled,true);
}finally{Object.assign(React,savedHooks);if(savedDocument===undefined)delete globalThis.document;else globalThis.document=savedDocument;}
console.log('New project: one destination, platform path separators and validated inert folder disclosure passed.');
