import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const React=createRequire(import.meta.url)('react'),N=loadLocal('../src/workspaceNavigation.ts'),L=loadLocal('../src/worldLore.ts');
const {useWorkspaceNavigation}=loadLocal('../src/useWorkspaceNavigation.ts');
const originals=Object.fromEntries(['useState','useRef','useCallback','useEffect','useLayoutEffect'].map(key=>[key,React[key]])),services={capture:N.captureWorkspacePosition,restore:N.restoreWorkspacePosition,prepare:L.prepareLoreNavigation};
const globals={document:globalThis.document,window:globalThis.window,requestAnimationFrame:globalThis.requestAnimationFrame,cancelAnimationFrame:globalThis.cancelAnimationFrame};
const project={schemaVersion:1,id:'project',title:'Story',revision:1,chapters:[{id:'chapter',title:'Chapter',scenes:[{id:'scene',title:'Scene',content:'Current text'}]}],plots:{schemaVersion:2,threads:[{id:'plot',title:'Plot',beats:[],notes:'',status:'planned',color:'teal'}]}};
const base={view:'manuscript',selectedId:'scene',chapterId:'chapter',manuscriptMode:'scene',worldSection:'entries',worldEntryId:'',plotId:'',arcId:'',timelineEventId:'',mapId:'',mapMarkerId:'',pendingIdeaId:'',toolsOpen:false,toolsTab:'context',worldOpen:false,sidebar:true};
let cleanupCurrent=()=>{};
function harness(){
 cleanupCurrent();let states=[],refs=[],memos=[],effects=[],layouts=[],si=0,ri=0,mi=0,ei=0,li=0,queued=[],result,route={...base},session=1,busy=false,ready=true,modal=false,loading=false,canLeave=true,position=10,frameId=0;
 const frames=new Map(),listeners=new Set(),restored=[],selections=[],roots=new Map(['manuscript','plots','timeline'].map(view=>[`${view}-view`,{id:`${view}-view`,querySelector:()=>loading?{}:null}]));
 const editor={isDestroyed:false,state:{selection:{from:3,to:8},doc:{content:{size:20}}},commands:{setTextSelection:value=>selections.push(value)}};
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return [states[i],next=>states[i]=typeof next==='function'?next(states[i]):next];};
 React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};
 React.useCallback=(fn,deps)=>{const i=mi++;if(!memos[i]||deps.some((value,index)=>!Object.is(value,memos[i].deps[index])))memos[i]={deps,fn};return memos[i].fn;};
 function register(store,i,setup,deps){const previous=store[i];if(!previous||!deps||deps.some((value,index)=>!Object.is(value,previous.deps[index])))queued.push(()=>{previous?.cleanup?.();store[i]={deps,cleanup:setup()};});}
 React.useEffect=(setup,deps)=>register(effects,ei++,setup,deps);React.useLayoutEffect=(setup,deps)=>register(layouts,li++,setup,deps);
 globalThis.document={getElementById:id=>roots.get(id)??null,querySelector:()=>modal?{}:null};
 globalThis.window={addEventListener:(_key,fn)=>listeners.add(fn),removeEventListener:(_key,fn)=>listeners.delete(fn)};
 globalThis.requestAnimationFrame=fn=>{frames.set(++frameId,fn);return frameId;};globalThis.cancelAnimationFrame=id=>frames.delete(id);
 N.captureWorkspacePosition=()=>({scroll:[],details:[],testPosition:position});N.restoreWorkspacePosition=(_root,saved,focus)=>restored.push({saved,focus});L.prepareLoreNavigation=()=>canLeave;
 function render(){si=ri=mi=ei=li=0;queued=[];result=useWorkspaceNavigation({project,session,ready,busy,route,sceneId:route.view==='manuscript'?'scene':undefined,sceneEditorRef:{current:editor},onRestoreRoute:value=>{route=value;}});for(const commit of queued)commit();return result;}
 function frame(){const tasks=[...frames.values()];frames.clear();tasks.forEach(fn=>fn());}
 cleanupCurrent=()=>{layouts.forEach(effect=>effect.cleanup?.());effects.forEach(effect=>effect.cleanup?.());layouts=[];effects=[];};
 return {render,get current(){return result;},get route(){return route;},frames,restored,selections,listeners,editor,setRoute(value){route={...base,...value};},setPosition(value){position=value;},setLoading(value){loading=value;},setBusy(value){busy=value;},setReady(value){ready=value;},setModal(value){modal=value;},setCanLeave(value){canLeave=value;},newSession(){session++;},frame,drain(){for(let i=0;i<12&&frames.size;i++)frame();assert.equal(frames.size,0,'Restoration must finish in a bounded number of frames');},key(patch){const event={key:'[',metaKey:true,ctrlKey:false,altKey:false,shiftKey:false,defaultPrevented:false,isComposing:false,repeat:false,target:{closest:()=>null},preventDefault(){this.prevented=true;},...patch};for(const fn of listeners)fn(event);return event;},cleanup:()=>cleanupCurrent()};
}
try{
 const before=JSON.stringify(project);let h=harness(),nav=h.render();const readyCallback=nav.panelReady;
 nav.viewMemory.current.values['plots.query']='original';h.setPosition(42);nav.captureNavigation();
 h.setRoute({view:'plots',plotId:'plot'});nav=h.render();assert.equal(nav.navigationHistory.current.past.length,1);assert.equal(nav.panelReady,readyCallback);assert.match(nav.navigationBackLabel(project),/Scene/);
 nav.navigateWorkspace('back');assert.equal(h.route.view,'manuscript');assert.equal(nav.restoringNavigation.current,true);
 h.setLoading(true);h.render();assert.equal(h.frames.size,0,'Loading destinations defer restoration');
 h.setLoading(false);nav.panelReady();nav=h.render();assert.equal(h.frames.size,1);
 h.frame();nav=h.render();h.drain();assert.equal(nav.restoringNavigation.current,false);assert.equal(h.restored.length,8);assert.equal(h.restored.at(-1).focus,true);assert.equal(h.restored[0].saved.testPosition,42);assert.deepEqual(h.selections.at(-1),{from:3,to:8});
 nav=h.render();nav.navigateWorkspace('forward');h.render();h.drain();assert.equal(h.route.view,'plots');assert.equal(nav.viewMemory.current.values['plots.query'],'original');assert.equal(JSON.stringify(project),before);
 // Navigation guards must leave the history and route unchanged.
 for(const [set,value] of [['setBusy',true],['setReady',false],['setModal',true],['setCanLeave',false]]){
  h[set](value);nav=h.render();const history=JSON.stringify(nav.navigationHistory.current);nav.navigateWorkspace('back');assert.equal(h.route.view,'plots');assert.equal(JSON.stringify(nav.navigationHistory.current),history);h[set](!value);
 }
 // Scroll capture coalesces events, and pending work is cancelled on a new session.
 nav=h.render();nav.captureNavigationScroll();nav.captureNavigationScroll();assert.equal(h.frames.size,1);h.newSession();nav=h.render();assert.equal(h.frames.size,0);assert.equal(nav.navigationHistory.current.past.length,0);assert.deepEqual(nav.viewMemory.current.values,{});
 nav.captureNavigationScroll();assert.equal(h.frames.size,1);h.cleanup();assert.equal(h.frames.size,0);assert.equal(h.listeners.size,0);
 // Route changes interrupt pending restoration without applying stale editor ranges.
 h=harness();nav=h.render();const visit=nav.captureWorkspaceVisit();visit.position.editor={sceneId:'scene',from:-9,to:999};nav.restoreWorkspaceVisit(visit);h.render();h.frame();h.setRoute({view:'plots',plotId:'plot'});h.render();const restoredBefore=h.restored.length;h.drain();assert.equal(h.restored.length,restoredBefore);assert.equal(h.selections.length,0);assert.equal(nav.restoringNavigation.current,false);
 // New sessions and explicit replacement visits cancel an older restoration pass.
 h=harness();nav=h.render();nav.restoreWorkspaceVisit(nav.captureWorkspaceVisit());h.render();h.frame();assert.equal(h.frames.size,1);h.newSession();nav=h.render();assert.equal(h.frames.size,0);assert.equal(nav.restoringNavigation.current,false);assert.equal(h.selections.length,0);
 nav.restoreWorkspaceVisit(nav.captureWorkspaceVisit());h.render();h.frame();const oldFrames=h.restored.length;nav.restoreWorkspaceVisit({route:{...base,view:'plots',plotId:'plot'},memory:{},position:{scroll:[],details:[]}});h.render();h.drain();assert.equal(h.restored.length,oldFrames+8);assert.equal(h.selections.length,0);assert.equal(h.route.view,'plots');
 // Clamp restored editor ranges and preserve chapter fallback for missing scenes.
 h=harness();nav=h.render();const clamped=nav.captureWorkspaceVisit();clamped.position.editor={sceneId:'scene',from:-9,to:999};nav.restoreWorkspaceVisit(clamped);h.render();h.drain();assert.deepEqual(h.selections.at(-1),{from:1,to:20});
 const fallback={...clamped,route:{...base,manuscriptMode:'chapter',selectedId:'deleted'}};nav=h.render();nav.restoreWorkspaceVisit(fallback);assert.equal(h.route.selectedId,'chapter');h.render();h.drain();
 // Keyboard navigation respects text editing, composition and repeat guards.
 h=harness();h.render();h.setRoute({view:'plots',plotId:'plot'});h.render();assert(!h.key({repeat:true}).prevented);assert(!h.key({isComposing:true}).prevented);assert(!h.key({metaKey:false,altKey:true,key:'ArrowLeft',target:{closest:()=>({})}}).prevented);assert.equal(h.route.view,'plots');assert(h.key({}).prevented);assert.equal(h.route.view,'manuscript');h.render();h.drain();
 assert.equal(JSON.stringify(project),before);
}finally{cleanupCurrent();Object.assign(React,originals);Object.assign(N,{captureWorkspacePosition:services.capture,restoreWorkspacePosition:services.restore});L.prepareLoreNavigation=services.prepare;N.activateWorkspaceMemory(undefined);for(const [key,value] of Object.entries(globals)){if(value===undefined)delete globalThis[key];else globalThis[key]=value;}}
console.log('Workspace navigation hook: actual history, loading/readiness, bounded position/editor restoration, live data, guards, session/unmount cancellation, coalesced scroll and keyboard behavior passed without UI.');
