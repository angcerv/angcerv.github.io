import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const C=loadLocal('../src/storyCalendar.ts'),B=loadLocal('../src/calendarBrowse.ts'),P=loadLocal('../src/timelinePreferences.ts'),I=loadLocal('../src/i18n.ts');
const calendar={...C.defaultStoryCalendar(),schemaVersion:2,mode:'fixed',months:[{name:'Dawn',days:10},{name:'Sea',days:10}],seasons:[{name:'Rain',month:1,day:1}],holidays:[{name:'New tide',month:2,day:10,duration:2}]};
const exact=(id,year,month,day,end)=>({id,title:id,dateLabel:'',notes:'',sceneIds:[],entryIds:[],start:{year,month,day},...(end?{end}:{})});
const events=[exact('first',0,1,1),exact('period',0,1,19,{year:0,month:1,day:22}),{id:'partial',title:'Partial',start:{year:0},dateLabel:'',notes:'',sceneIds:[],entryIds:[]},{id:'unknown',title:'Unknown',dateLabel:'',notes:'',sceneIds:[],entryIds:[]}];const before=JSON.stringify({calendar,events});
assert.deepEqual(B.initialCalendarPosition(calendar,events,'period'),{year:0,month:2,day:9,page:0});assert.deepEqual(B.adjacentCalendarMonth(calendar,{year:0,month:1,day:1,page:0},-1),{year:-1,month:2,day:1,page:0});assert.deepEqual(B.adjacentCalendarMonth(calendar,{year:-1,month:2,day:1,page:0},1),{year:0,month:1,day:1,page:0});assert.equal(B.adjacentCalendarMonth(calendar,{year:-999999,month:1,day:1,page:0},-1),null);assert.equal(B.adjacentCalendarMonth(calendar,{year:999999,month:2,day:1,page:0},1),null);
const gregorian=C.defaultStoryCalendar();assert.equal(B.calendarMonthPage(gregorian,{year:0,month:2,day:1,page:0}).days,29);assert.equal(B.calendarMonthPage(gregorian,{year:1,month:2,day:1,page:0}).days,28);
for(const weekdayCount of [1,3,7,20]){
 const large={...calendar,months:Array.from({length:24},(_,i)=>({name:`Month ${i}`,days:1000})),weekdays:Array.from({length:weekdayCount},(_,i)=>`Day ${i}`),epochWeekday:weekdayCount-1};
 let days=[];const first=B.calendarMonthPage(large,{year:-1,month:24,day:1000,page:0});for(let page=0;page<first.pages;page++){const data=B.calendarMonthPage(large,{year:-1,month:24,day:1000,page});assert(data.cells.length<=120);assert.equal(data.cells.length%weekdayCount,0);days.push(...data.cells.filter(Boolean).map(date=>date.day));}
 assert.equal(days.length,1000);assert.equal(new Set(days).size,1000);assert.equal(days[0],1);assert.equal(days.at(-1),1000);
 const target=B.positionForCalendarDate(large,{year:-1,month:24,day:1000});assert(B.calendarMonthPage(large,target).cells.some(date=>date?.day===1000));
}
const ranges=B.calendarEventRanges(events);assert.deepEqual(ranges.uncertain.map(event=>event.id),['partial','unknown']);assert.deepEqual(B.calendarDayEvents({year:1,month:1,day:1},calendar,ranges.exact).map(event=>event.id),['period']);assert.equal(B.calendarDayEvents({year:1,month:1,day:3},calendar,ranges.exact).length,0);
assert.equal(B.storedCalendarDate({year:999999,month:12,day:31},{...gregorian,epochYear:999999}),undefined);assert.equal(C.calendarWorldDateContext({year:0,month:1,day:1},calendar).holidays[0].name,'New tide');assert.equal(JSON.stringify({calendar,events}),before);
globalThis.localStorage={getItem:()=>JSON.stringify({view:'calendar'}),setItem(){}};assert.equal(P.loadTimelinePreferences('p').view,'calendar');delete globalThis.localStorage;
const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useMemo:React.useMemo,useEffect:React.useEffect};
const {CalendarBrowser}=loadLocal('../src/StoryCalendarView.tsx'),View=loadLocal('../src/StoryCalendarView.tsx').default;
let states=[],index=0,selected='first',inspected;const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
try{
 React.useState=initial=>{const i=index++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return [states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useMemo=fn=>fn();React.useEffect=()=>{};
 const render=()=>{index=0;return nodes(CalendarBrowser({calendar,events,selectedId:selected,onSelectEvent:id=>selected=id,onSelectDay:date=>inspected=date}));};
 let tree=render();tree.find(node=>node.type==='button'&&node.props.className==='calendar-browser-day'&&node.props.children[0].props.children===2).props.onClick();assert.deepEqual(Object.keys(states[0]).sort(),['day','month','page','year']);assert.equal(states[0].day,2);assert.deepEqual(inspected,{year:0,month:1,day:2});
 tree=render();tree.find(node=>node.props?.['aria-label']==='Next month').props.onClick();assert.equal(states[0].month,2);tree=render();tree.find(node=>node.props?.id==='calendar-browse-month').props.onChange('1');assert.equal(states[0].month,1);
 tree=render();tree.find(node=>node.type==='input'&&node.props.type==='number').props.onChange({target:{value:'-1'}});tree=render();tree.find(node=>node.type==='form').props.onSubmit({preventDefault(){}});assert.equal(states[0].year,-1);
 tree=render();tree.find(node=>node.type==='input'&&node.props.type==='number').props.onChange({target:{value:'bad'}});tree=render();tree.find(node=>node.type==='form').props.onSubmit({preventDefault(){}});assert(render().some(node=>node.props?.role==='alert'));assert.equal(states[0].year,-1);
 tree=render();tree.find(node=>node.props?.['aria-label']==='Locate selected event').props.onClick();assert.equal(states[0].year,0);assert.equal(states[0].day,1);tree=render();assert(!tree.some(node=>node.props?.className==='calendar-browser-detail'));const EventButton=loadLocal('../src/CalendarEventButton.tsx').default;tree.find(node=>node.type===EventButton).props.onSelect('partial');assert.equal(selected,'partial');assert.equal(JSON.stringify({calendar,events}),before);
 states=[];index=0;const longMonth={...calendar,months:[{name:'Long month',days:1000}],seasons:[],holidays:[]};
 let longTree=nodes(CalendarBrowser({calendar:longMonth,events:[],selectedId:'',onSelectEvent(){}}));longTree.find(node=>node.props?.['aria-label']==='Next weeks').props.onClick();assert.equal(states[0].page,1);assert.equal(states[0].day,B.calendarMonthPage(longMonth,states[0]).first);assert.deepEqual(Object.keys(states[0]).sort(),['day','month','page','year']);
}finally{Object.assign(React,old);}
let configured=false;nodes(View({events,selectedId:'',onSelectEvent(){},onConfigure:()=>configured=true})).find(node=>node.type==='button').props.onClick();assert(configured);
const many=Array.from({length:5000},(_,i)=>exact(`event ${i}`,0,1,1));const markup=renderToStaticMarkup(createElement(CalendarBrowser,{calendar,events:many,selectedId:'',onSelectEvent(){}}));assert((markup.match(/class="calendar-event-button"/g)??[]).length<=50);assert((markup.match(/class="calendar-browser-day"/g)??[]).length<=120);assert(markup.includes('5000 events'));
I.setLanguage('es');assert(renderToStaticMarkup(createElement(CalendarBrowser,{calendar,events:[],selectedId:'',onSelectEvent(){}})).includes('Mes siguiente'));I.setLanguage('en');
console.log('Calendar browsing: bounded pages for 24 months/1000 days/20 weekdays, year zero/negative/leap dates, period overlap, uncertain dates, selection/month/year handlers, numeric-only navigation memory, preserved content, preferences and 5,000-event rendering passed without UI.');
