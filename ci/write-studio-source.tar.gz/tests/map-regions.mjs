import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const R=loadLocal('../src/mapRegions.ts'),M=loadLocal('../src/maps.ts');
const points=[{x:.1,y:.1},{x:.8,y:.1},{x:.8,y:.8},{x:.1,y:.8}];
assert(R.regionStartHit(points,{x:.12,y:.1},1000,200));assert(!R.regionStartHit(points,{x:.12,y:.1},2000,200));assert(R.regionStartHit(points,{x:.1,y:.18},1000,200));assert(!R.regionStartHit(points,{x:.1,y:.18},1000,1000));assert(!R.regionStartHit([],{x:.1,y:.1},1000,1000));
assert(R.validRegionPoints(points));
for(const invalid of [points.slice(0,2),[points[0],points[2],points[1],points[3]],[...points,points[0]],points.map(p=>({...p,y:.1})),[{x:NaN,y:0},...points],Array.from({length:129},(_,i)=>({x:i/129,y:0}))])assert(!R.validRegionPoints(invalid));
const region={id:crypto.randomUUID(),title:'Kingdom',color:'amber',entryId:'entry',layerId:'layer',points};
const hole=[{x:.3,y:.3},{x:.6,y:.3},{x:.6,y:.6},{x:.3,y:.6}];
assert(R.validRegionGeometry({...region,holes:[hole]}));
for(const holes of [[points],[hole,hole],[hole.map(p=>({...p,x:p.x+.4}))],[hole.map(p=>({...p,x:p.x+.2})),hole]])assert(!R.validRegionGeometry({...region,holes}));
assert.equal((R.regionPath({...region,holes:[hole]}).match(/Z/g)||[]).length,2);
let maps={schemaVersion:16,maps:[{id:'map',title:'Atlas',imageId:'asset',notes:'',layers:[{id:'layer',title:'Territories',visible:true}],markers:[]}]};
const world={schemaVersion:1,templates:[{id:'places',title:'Places',fields:[]}],entries:[{id:'entry',title:'Kingdom entry',templateId:'places',values:{},archived:false}]};
const original=JSON.stringify(maps);
maps=R.saveMapRegion(maps,'map',region);
assert.equal(maps.schemaVersion,17);assert.equal(maps.maps[0].regions.length,1);
assert.equal(JSON.parse(original).maps[0].regions,undefined);
assert.equal(R.visibleMapRegions(maps.maps[0],world,'places').length,1);
assert.equal(R.visibleMapRegions(maps.maps[0],world,'__unlinked').length,0);
const hidden=M.setMapLayerVisible(maps,'map','layer',false);
assert.equal(R.visibleMapRegions(hidden.maps[0]).length,0);
const locked=M.setMapLayerLocked(maps,'map','layer',true);
assert.equal(R.saveMapRegion(locked,'map',{...region,title:'Edited'}),locked);
assert.equal(R.removeMapRegion(locked,'map',region.id),locked);
assert.equal(R.saveMapRegion(maps,'map',{...region,points:points.slice(0,2)}),maps);
assert.equal(M.removeMapLayer(maps,'map','layer').maps[0].regions[0].layerId,undefined);
const trashed=M.trashMap(maps,'map',100);assert.equal(trashed.schemaVersion,17);assert.deepEqual(trashed.trash[0].map.regions,[region]);
assert.deepEqual(M.restoreMap(trashed,'map').maps[0].regions,[region]);
assert.equal(R.saveMapRegion(maps,'map',{...region,entryId:'deleted'}).maps[0].regions[0].entryId,'deleted');

// Real vertex handlers: preview, commit, cancellation, keyboard and invalid polygons.
const React=createRequire(import.meta.url)('react'),Overlay=loadLocal('../src/MapRegionsOverlay.tsx').default,Panel=loadLocal('../src/MapRegionsPanel.tsx').default;
const old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect,useContext:React.useContext};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
let states=[],refs=[],si=0,ri=0,changed,invalids=0,opened;
try{
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],next=>states[i]=typeof next==='function'?next(states[i]):next];};
 React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};
 React.useEffect=()=>{};React.useContext=()=>({openEntry:id=>opened=id});
 const image={current:{getBoundingClientRect:()=>({left:100,top:100,width:400,height:200})}};
 const props={editing:true,map:maps.maps[0],regions:[region],selectedId:region.id,onSelect(){},onChange:next=>changed=next,image,drawing:false,onAddPoint(){},points:[],labels:true,onInvalid:()=>invalids++};
 const render=()=>{si=ri=0;return nodes(Overlay(props));};
 let captured=false;const target={focus(){},setPointerCapture(){captured=true;},hasPointerCapture(){return captured;},releasePointerCapture(){captured=false;}};
 const event=(x,y)=>({button:0,pointerId:1,clientX:x,clientY:y,currentTarget:target,preventDefault(){},stopPropagation(){}});
 const vertex=tree=>tree.find(n=>n.type==='ellipse');
 props.editing=false;assert(!render().some(n=>n.type==='ellipse'));props.editing=true;
 let tree=render();vertex(tree).props.onPointerDown(event(140,120));vertex(tree).props.onPointerMove(event(180,140));tree=render();assert.equal(changed,undefined);
 vertex(tree).props.onPointerCancel(event(180,140));tree=render();assert.equal(changed,undefined);
 vertex(tree).props.onPointerDown(event(140,120));vertex(tree).props.onPointerMove(event(180,140));tree=render();vertex(tree).props.onPointerUp(event(180,140));assert.deepEqual(changed.points[0],{x:.2,y:.2});
 changed=undefined;tree=render();vertex(tree).props.onKeyDown({...event(0,0),key:'ArrowRight',shiftKey:false});assert.equal(changed.points[0].x,.10500000000000001);
 changed=undefined;vertex(tree).props.onPointerDown(event(140,120));vertex(tree).props.onPointerMove(event(420,120));tree=render();vertex(tree).props.onPointerUp(event(420,120));assert.equal(changed,undefined);assert.equal(invalids,1);
 // Name gestures preview without changing geometry, commit once, cancel and support keyboard movement.
 props.editing=false;props.screenWidth=400;props.screenHeight=200;changed=undefined;tree=render();
 const label=()=>tree.find(n=>n.props?.className?.startsWith?.('map-region-name'));
 label().props.onPointerDown(event(200,150));label().props.onPointerMove(event(240,170));tree=render();assert.equal(changed,undefined);
 label().props.onPointerCancel(event(240,170));tree=render();assert.equal(changed,undefined);
 label().props.onPointerDown(event(200,150));label().props.onPointerMove(event(240,170));tree=render();label().props.onPointerUp(event(240,170));assert.deepEqual(changed.points,region.points);assert(Math.abs(changed.labelPosition.x-.55)<1e-10);assert(Math.abs(changed.labelPosition.y-.55)<1e-10);
 changed=undefined;tree=render();label().props.onKeyDown({...event(0,0),key:'ArrowRight'});assert(Math.abs(changed.labelPosition.x-.455)<1e-10);assert(Math.abs(changed.labelPosition.y-.45)<1e-10);
 changed=undefined;label().props.onPointerDown(event(200,150));label().props.onPointerMove(event(240,170));tree=render();label().props.onKeyDown({...event(0,0),key:'Escape'});assert.equal(changed,undefined);assert.equal(captured,false);
 // Hole contours use the same preview/commit and keyboard handlers; the exterior stays unchanged.
 props.editing=true;props.contourIndex=0;props.regions=[{...region,holes:[hole]}];changed=undefined;tree=render();
 assert.equal(tree.find(n=>n.type==='path'&&n.props['data-map-region']).props.fillRule,'evenodd');
 vertex(tree).props.onKeyDown({...event(0,0),key:'ArrowRight',shiftKey:false});
 assert.deepEqual(changed.points,region.points);assert.equal(changed.holes[0][0].x,.305);
 props.contourIndex=-1;props.regions=[region];
 props.editing=true;
 props.map=locked.maps[0];tree=render();assert(!tree.some(n=>n.type==='ellipse'));
 // The first-point target has stable screen dimensions and keyboard parity for regions and holes.
 props.map=maps.maps[0];props.editing=false;props.drawing=true;props.points=points;props.screenWidth=400;props.screenHeight=200;
 let finishes=0,cancels=0;props.onFinishDrawing=()=>finishes++;props.onCancelDrawing=()=>cancels++;
 for(const drawingKind of ['region','hole']){props.drawingKind=drawingKind;tree=render();const start=tree.find(n=>n.props?.className==='map-region-start');assert(start);assert.equal(start.props['aria-label'],drawingKind==='hole'?'Close hole':'Close region');const hit=tree.find(n=>n.props?.className==='map-region-start-hit');assert.equal(hit.props.rx,55);assert.equal(hit.props.ry,110);for(const key of ['Enter',' '])start.props.onKeyDown({...event(0,0),key});start.props.onKeyDown({...event(0,0),key:'Escape'});}
 assert.equal(finishes,4);assert.equal(cancels,2);props.points=points.slice(0,2);assert(!render().some(n=>n.props?.className==='map-region-start'));
 states=[];refs=[];si=ri=0;
 const panel=nodes(Panel({maps,map:maps.maps[0],world,selectedId:region.id,onSelect(){},onChange:next=>maps=next}));
 panel.find(n=>n.type==='input'&&n.props.id==='region-title').props.onChange({target:{value:'New name'}});
 assert.equal(maps.maps[0].regions[0].title,'New name');
 panel.find(n=>n.type==='button'&&n.props.children?.[0]==='Consult').props.onClick();assert.equal(opened,'entry');
 const Editor=loadLocal('../src/MapsEditor.tsx').default;
 states=[];refs=[];si=ri=0;
 let selectedMarker='';const editorProps=()=>({maps,world,path:'/project',projectId:'p',mapId:'map',markerId:'',onSelectMap(){},onSelectMarker:id=>selectedMarker=id,onChange:next=>maps=next,async onImport(){},onOpenEntry(){}});
 const renderEditor=()=>{si=ri=0;return nodes(Editor(editorProps()));};tree=renderEditor();
 tree.find(n=>n.type?.name==='MapCanvas').props.onRegionCreate(points,'layer');tree=renderEditor();
 assert.equal(maps.maps[0].regions.length,2);assert.equal(selectedMarker,'');
 assert.equal(tree.find(n=>n.type===Panel).props.selectedId,maps.maps[0].regions[1].id);
 const targetRegion=maps.maps[0].regions[1];
 tree.find(n=>n.type?.name==='MapCanvas').props.onRegionCreate(hole,'layer',targetRegion.id);tree=renderEditor();
 assert.equal(maps.schemaVersion,19);assert.deepEqual(maps.maps[0].regions[1].holes,[hole]);
 tree.find(n=>n.type===Panel).props.onAddHole();tree=renderEditor();
 assert.equal(tree.find(n=>n.type?.name==='MapCanvas').props.regionRequest.holeOf,targetRegion.id);

 const {MapCanvas}=loadLocal('../src/MapsEditor.tsx');
 states=[];refs=[];let polygon;
 const canvasProps={map:maps.maps[0],world,path:'/project',projectId:'p',markerId:'',onSelect(){},onPlace(){},onMove(){},onRegionCreate:next=>polygon=next};
 const renderCanvas=()=>{si=ri=0;return nodes(MapCanvas(canvasProps));};
 renderCanvas();states[0]='image-url';states[3]=true;tree=renderCanvas();
 tree.find(n=>n.props?.['aria-label']==='New region').props.onClick();tree=renderCanvas();
 const viewport=()=>tree.find(n=>n.props?.className?.startsWith?.('map-viewport'));
 const key=(key,extra={})=>{const target={};viewport().props.onKeyDown({key,target,currentTarget:target,preventDefault(){},...extra});tree=renderCanvas();};
 key('Enter');key('ArrowRight');key('Enter');key('ArrowDown');key('Enter');
 key('Enter',{ctrlKey:true});
 assert(R.validRegionPoints(polygon));assert.equal(polygon.length,3);
 tree=renderCanvas();const visibility=()=>tree.find(n=>n.type?.name==='ActionMenu'&&n.props.label==='Label visibility').props.actions;const regionNames=()=>visibility().find(action=>action.label==='Show region labels'),markerNames=()=>visibility().find(action=>action.label==='Show marker labels');
 regionNames().onClick();tree=renderCanvas();assert.equal(regionNames().checked,false);assert.equal(markerNames().checked,true);
 markerNames().onClick();tree=renderCanvas();regionNames().onClick();tree=renderCanvas();assert.equal(regionNames().checked,true);assert.equal(markerNames().checked,false);
 // Drawing a hole keeps its explicit parent identity through the canvas gesture flow.
 const request={token:1,holeOf:region.id};let requested=false,createdHole,requestEffect;
 canvasProps.regionRequest=request;canvasProps.onRegionCreate=(points,layerId,holeOf)=>createdHole={points,layerId,holeOf};
 React.useEffect=(fn,deps)=>{if(!requested&&deps?.length===1&&deps[0]===request){requested=true;requestEffect=fn;}};
 tree=renderCanvas();requestEffect();tree=renderCanvas();key('Enter');key('ArrowRight');key('Enter');key('ArrowDown');key('Enter');
 key('Enter',{ctrlKey:true});
 assert.equal(createdHole.holeOf,region.id);assert(R.validRegionGeometry({...region,holes:[createdHole.points]}));
 React.useEffect=()=>{};



}finally{Object.assign(React,old);}

// PNG export keeps visible polygons and literal names; hidden layers are omitted.
const {renderMapPng}=loadLocal('../src/mapExport.ts');const calls=[];
const ctx=new Proxy({measureText:text=>({width:text.length*6})},{get(target,key){return key in target?target[key]:(...args)=>calls.push([key,...args]);}});
const previousDocument=globalThis.document;globalThis.document={createElement:()=>({getContext:()=>ctx,toBlob:callback=>callback(new Blob(['png']))})};
try{
 await renderMapPng({naturalWidth:1000,naturalHeight:500},maps.maps[0],world,[],[],true,500,new Map());
 assert.equal(calls.filter(call=>call[0]==='closePath').length,3);
 assert(calls.some(call=>call[0]==='fillText'&&call[1]==='New name'));
 calls.length=0;
 await renderMapPng({naturalWidth:1000,naturalHeight:500},{...maps.maps[0],regions:[{...region,holes:[hole]}]},world,[],[],false,500,new Map());
 assert(calls.some(call=>call[0]==='fill'&&call[1]==='evenodd'));assert.equal(calls.filter(call=>call[0]==='closePath').length,2);
 calls.length=0;
 await renderMapPng({naturalWidth:1000,naturalHeight:500},hidden.maps[0],world,[],[],true,500,new Map());
 assert(!calls.some(call=>call[0]==='closePath'));
}finally{globalThis.document=previousDocument;}
console.log('Map regions: simple polygon validation, immutable schema upgrade, layers/locks/filtering, trash, real vertex preview/commit/cancel/keyboard, linked consultation, creation and PNG export passed without UI.');
