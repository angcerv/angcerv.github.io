import assert from 'node:assert/strict';import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const W=loadLocal('../src/worldIdeas.ts'),P=loadLocal('../src/pendingItems.ts');
const {buildProjectSearchIndex,searchProjectIndex}=loadLocal('../src/globalSearch.ts');
const world={templates:[],entries:[{id:'e',title:'Dorian',values:{},archived:false}]};
const original={id:'p',title:'Story',chapters:[],worldbuilding:world,worldIdeas:[]};
const idea={id:'i',title:'Dorian outcome',description:'Review alternatives',status:'deciding',entryIds:['e'],sceneIds:[],plotIds:[],category:'narrative'};
assert.throws(()=>W.saveWorldIdea(original,{...idea,status:'decided'}),/Write the decision/);
let project=W.saveWorldIdea(original,{...idea,status:'decided',decision:'Dorian survives',updates:[{kind:'entry',id:'e',done:false}]});
assert.equal(original.worldIdeas.length,0);assert.equal(P.filterPendingItems(P.projectPendingItems(project),'all','','').length,1);assert.equal(W.relatedIdeas(project.worldIdeas,'entry','e').length,1);
assert.equal(P.filterPendingItems(P.projectPendingItems(project),'all','','survives').length,1);
assert.throws(()=>W.saveWorldIdea(project,{...project.worldIdeas[0],status:'incorporated'}),/Review the required changes/);
project=W.saveWorldIdea(project,{...project.worldIdeas[0],status:'incorporated',updates:[{kind:'entry',id:'e',done:true}]});assert.equal(P.filterPendingItems(P.projectPendingItems(project),'all','','').length,0);assert.equal(P.filterPendingItems(P.projectPendingItems(project),'all','','','all').length,1);
assert.throws(()=>W.saveWorldIdea(project,{...project.worldIdeas[0],decision:''}),/Write the decision/);
assert.equal(searchProjectIndex(buildProjectSearchIndex(project),'survives').some(result=>result.id==='i'),true);
const legacy={...idea,status:'incorporated'};assert.doesNotThrow(()=>W.saveWorldIdea({...original,worldIdeas:[legacy]},legacy));
assert.deepEqual(W.ideaUpdates({...idea,updates:[{kind:'entry',id:'e',done:false},{kind:'entry',id:'e',done:true},{kind:'scene',id:'gone',done:false}]}),[{kind:'entry',id:'e',done:false}]);
// Real editor validation and checklist handlers, without launching a UI.
const require=createRequire(import.meta.url),React=require('react'),saved={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const {default:Editor,IdeaLinkedChoices}=loadLocal('../src/WorldIdeaEditor.tsx');
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
let values=[],cursor=0,commits=[],closed=0;
try{
 React.useState=initial=>{const i=cursor++;if(!(i in values))values[i]=typeof initial==='function'?initial():initial;return[values[i],value=>values[i]=typeof value==='function'?value(values[i]):value];};React.useRef=value=>({current:value});React.useEffect=()=>{};
 const props={idea,world,onSave:item=>commits.push(item),onClose:()=>closed++};const render=()=>{cursor=0;return nodes(Editor(props));};
 let tree=render();tree.find(n=>n.props?.id==='idea-status').props.onChange('decided');tree=render();tree.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.equal(commits.length,0);tree=render();assert(tree.some(n=>n.props?.role==='alert'));
 tree.find(n=>n.props?.id==='world-idea-decision').props.onChange('He survives');tree=render();tree.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.equal(commits[0].status,'decided');assert.equal(commits[0].decision,'He survives');assert.equal(closed,1);
 values=[];cursor=0;let changes;
 const choices={title:'Entries',options:[{id:'e',title:'Dorian'}],selected:['e'],missingLabel:'Deleted entry',canOpen:true,onChange(){},updateKind:'entry',updates:[],onUpdates:value=>changes=value};
 let related=nodes(IdeaLinkedChoices(choices));related.find(n=>n.props?.['aria-label']==='Needs changes: Dorian').props.onChange({target:{checked:true}});assert.deepEqual(changes,[{kind:'entry',id:'e',done:false}]);
 cursor=0;related=nodes(IdeaLinkedChoices({...choices,updates:changes}));related.find(n=>n.props?.['aria-label']==='Changes reviewed: Dorian').props.onChange({target:{checked:true}});assert.equal(changes[0].done,true);
}finally{Object.assign(React,saved);}
console.log('Decisions: separate choice/incorporation, open filters/backlinks/search, validation, legacy closures, pruned updates and actual editor/checklist handlers passed.');
