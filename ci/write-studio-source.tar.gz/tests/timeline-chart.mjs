import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
const require = createRequire(import.meta.url), previous = require.extensions['.ts'];
require.extensions['.ts'] = (module, filename) => module._compile(ts.transpileModule(readFileSync(filename, 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText, filename);
try {
  const { storyDay, dateFromStoryDay, eventRange, chartDomain, chartTicks } = require('../src/timelineChartLayout.ts');
  const { daysInMonth } = require('../src/timeline.ts');
  const base = new Date(0); base.setUTCFullYear(0, 0, 1); base.setUTCHours(0,0,0,0);
  for (const year of [-12000, -400, -100, -4, -1, 0, 1, 4, 99, 100, 400, 1900, 2000, 2024, 12000]) {
    for (const month of [1, 2, 3, 6, 12]) {
      const date = { year, month, day: daysInMonth(year, month) };
      const reference = new Date(0); reference.setUTCFullYear(year, month - 1, date.day); reference.setUTCHours(0,0,0,0);
      assert.equal(storyDay(date), (reference.getTime() - base.getTime()) / 86400000);
      assert.deepEqual(dateFromStoryDay(storyDay(date)), date);
    }
  }
  for (const date of [{year:-999999,month:1,day:1}, {year:999999,month:12,day:31}]) assert.deepEqual(dateFromStoryDay(storyDay(date)), date);
  assert.equal(storyDay({year:2024,month:3,day:1}) - storyDay({year:2024,month:2,day:28}), 2);
  const event = (id, start, end) => ({ id, title:id, notes:'', dateLabel:'', sceneIds:[], entryIds:[], ...(start ? { start } : {}), ...(end ? { end } : {}) });
  const point = event('point', {year:2024,month:2,day:29});
  const partial = event('partial', {year:2024,month:2});
  const period = event('period', {year:2023,month:1,day:1}, {year:2025,month:12,day:31});
  const undated = event('undated');
  assert.equal(eventRange(point).kind, 'point');
  assert.equal(eventRange(point).start, eventRange(point).end);
  assert.equal(eventRange(partial).kind, 'point');
  assert.equal(eventRange(partial).end - eventRange(partial).start, 28);
  assert.equal(eventRange(period).kind, 'period');assert.equal(eventRange(event('year-period',{year:2023},{year:2025})).kind,'period');
  assert.equal(eventRange(undated), null);
  assert.equal(chartDomain([]), null);
  assert.equal(chartDomain([undated]), null);
  const events = [point, partial, period, undated], snapshot = JSON.stringify(events);
  const domain = chartDomain(events);
  assert.ok(domain.start < eventRange(period).start && domain.end > eventRange(period).end);
  assert.ok(chartDomain([point]).end > chartDomain([point]).start, 'A single point has a usable finite extent');
  assert.ok(chartDomain(events,'point').end - chartDomain(events,'point').start < domain.end-domain.start);
  const monthTicks = chartTicks(storyDay({year:2023,month:12,day:1}),storyDay({year:2024,month:4,day:1}));
  assert.ok(monthTicks.every(tick => dateFromStoryDay(tick.day).day === 1), 'Month ticks align to real month boundaries');
  for (const extent of [domain, chartDomain([point]), chartDomain([event('earliest',{year:-999999}),event('latest',{year:999999})])]) {
    const ticks = chartTicks(extent.start,extent.end);
    assert.ok(ticks.length > 0 && ticks.length <= 40);
    assert.ok(ticks.every(tick => Number.isFinite(tick.day) && tick.day>=extent.start && tick.day<=extent.end));
    assert.ok(ticks.every((tick,index)=>!index || tick.day>ticks[index-1].day));
  }
  // Zoom and available width refine the axis from years to months to days.
  const origin=storyDay({year:2024,month:1,day:1});
  const annual=chartTicks(origin,origin+365*20,8),monthly=chartTicks(origin,origin+365,8),daily=chartTicks(origin,origin+7,8);
  assert(annual.every(tick=>!tick.label.includes('-')));assert(monthly.every(tick=>/^202[45]-\d{2}$/.test(tick.label)));assert(daily.every(tick=>/^2024-01-\d{2}$/.test(tick.label)));assert.equal(daily.length,8);
  const narrow=chartTicks(origin,origin+150,3),wide=chartTicks(origin,origin+150,12);
  assert(wide.length>narrow.length,'A wider viewport can show more dates at the same zoom');assert(wide.some(tick=>dateFromStoryDay(tick.day).day!==1),'Day-level ticks are available in a wide multi-month view');
  const leap=chartTicks(storyDay({year:2024,month:2,day:27}),storyDay({year:2024,month:3,day:2}),8);assert(leap.some(tick=>tick.label==='2024-02-29'));
  const zero=chartTicks(storyDay({year:-1,month:12,day:29}),storyDay({year:0,month:1,day:3}),8);assert(zero.some(tick=>tick.label==='-1-12-31'));assert(zero.some(tick=>tick.label==='0-01-01'));
  assert(chartTicks(origin,origin+365*100,100000).length<=40,'Dense requests remain bounded');
  assert.equal(JSON.stringify(events),snapshot, 'Plotting never changes event order, dates, links or notes');
  console.log('Visual timeline: Gregorian day coordinates, negative/extreme years, partial dates, periods, focus extents, ticks and immutable events passed.');
} finally { if (previous) require.extensions['.ts']=previous; else delete require.extensions['.ts']; }
