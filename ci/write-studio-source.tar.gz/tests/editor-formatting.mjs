import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const require=createRequire(import.meta.url),{Editor}=require('@tiptap/core'),StarterKit=require('@tiptap/starter-kit').default,{keymap}=require('@tiptap/pm/keymap');
const F=loadLocal('../src/editorFormatting.ts'),{longTextDocument,longTextMarkdown}=loadLocal('../src/longText.ts'),{toMarkdown}=loadLocal('../src/model.ts');
const disabled={heading:false,blockquote:false,orderedList:false,code:false,codeBlock:false,strike:false,link:false,horizontalRule:false,trailingNode:false};
function editor(manuscript=false){return new Editor({element:null,extensions:[F.EditorFormattingShortcuts,StarterKit.configure({...disabled,...(manuscript?{underline:false,bulletList:false,listItem:false,listKeymap:false}:{})})],content:longTextDocument('Alpha beta')});}
function press(editor,key,modifier='ctrl',shift=false){
 const shortcuts=F.EditorFormattingShortcuts.config.addKeyboardShortcuts.call({editor});
 // Resolve Mod as ProseMirror does on each platform, without launching a browser.
 const bindings=Object.fromEntries(Object.entries(shortcuts).map(([key,run])=>[key.replace(/^Mod-/,modifier==='meta'?'Meta-':'Ctrl-'),run]));
 const event={key,keyCode:key==='*'?56:key.toUpperCase().charCodeAt(0),code:key==='*'?'Digit8':`Key${key.toUpperCase()}`,ctrlKey:modifier==='ctrl',metaKey:modifier==='meta',altKey:modifier==='alt',shiftKey:shift};
 return keymap(bindings).props.handleKeyDown(editor.view,event);
}
for(const modifier of ['ctrl','meta']){
 for(const [key,mark,expected] of [['b','bold','**Alpha** beta'],['i','italic','_Alpha_ beta'],['u','underline','<u>Alpha</u> beta']]){
  const e=editor();e.commands.setTextSelection({from:1,to:6});
  assert.equal(press(e,key,modifier),true);assert.equal(longTextMarkdown(e.getJSON()),expected);
  assert(e.getJSON().content[0].content[0].marks.some(item=>item.type===mark));
  assert.equal(e.state.selection.from,1);assert.equal(e.state.selection.to,6);
  assert.equal(press(e,key,modifier),true);assert.equal(longTextMarkdown(e.getJSON()),'Alpha beta');
  e.destroy();
 }
 const list=editor();list.commands.setTextSelection({from:1,to:6});assert.equal(press(list,'*',modifier,true),true);assert.equal(longTextMarkdown(list.getJSON()),'- Alpha beta');assert.equal(press(list,'*',modifier,true),true);assert.equal(longTextMarkdown(list.getJSON()),'Alpha beta');list.destroy();
 const manuscript=editor(true);manuscript.commands.setTextSelection({from:1,to:6});assert.equal(press(manuscript,'b',modifier),true);assert.equal(toMarkdown(manuscript.getJSON()),'**Alpha** beta');assert.equal(press(manuscript,'u',modifier),false);assert.equal(press(manuscript,'*',modifier,true),false);manuscript.destroy();
}
const e=editor();e.commands.setTextSelection(6);assert.equal(press(e,'b'),true);e.view.dispatch(e.state.tr.insertText('!'));assert.equal(longTextMarkdown(e.getJSON()),'Alpha**!** beta');
assert.equal(press(e,'b','alt'),false);assert.equal(press(e,'k'),false);e.setEditable(false);assert.equal(press(e,'b'),false);e.destroy();
assert.equal(F.formattingShortcut('bold',true),'⌘B');assert.equal(F.formattingShortcut('italic',false),'Ctrl+I');assert.equal(F.formattingShortcut('bulletList',true),'⌘⇧8');assert.equal(F.formattingAriaShortcut('underline',false),'Control+u');
assert.equal(F.formattingAriaShortcut('underline',true),'Meta+u');
console.log('Editor formatting shortcuts: actual Ctrl/Meta keymaps, selected-text toggle, caret typing, bullet lists, persisted Markdown, manuscript schema guards, read-only editors and accessible platform hints passed without UI.');
