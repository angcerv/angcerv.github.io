import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const React=createRequire(import.meta.url)('react');
const original={useState:React.useState,useRef:React.useRef,useMemo:React.useMemo,useEffect:React.useEffect};
const {deferPanel}=loadLocal('../src/DeferredPanel.tsx');
let state=[],refs=[],memos=[],si=0,ri=0,mi=0,loads=0,fail=false,ready=0;
const Value=props=>React.createElement('span',null,props.value);
const load=async()=>{loads++;if(fail)throw Error('Unavailable local chunk');return {default:Value};};
const Panel=deferPanel(load);
const render=props=>{si=ri=mi=0;return Panel(props);};
const content=tree=>tree.props.children.props.children.props.children;
async function initialize(type){type=type.type;try{return type._init(type._payload);}catch(pending){if(!(pending instanceof Promise))throw pending;try{await pending;}catch{}return type._init(type._payload);}}
try{
 React.useEffect=fn=>fn();
 React.useState=initial=>{const i=si++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return[state[i],next=>state[i]=typeof next==='function'?next(state[i]):next];};
 React.useRef=value=>{const i=ri++;return refs[i]??(refs[i]={current:value});};
 React.useMemo=(fn,deps)=>{const i=mi++;if(!memos[i]||deps.some((d,n)=>d!==memos[i].deps[n]))memos[i]={deps,value:fn()};return memos[i].value;};
 assert.equal(render({deferUntil:true,value:'draft'}),null);assert.equal(loads,0,'An unvisited workspace does not import its module');
 let tree=render({value:'draft',onPanelReady:()=>ready++});assert.equal(tree.props.children.props.fallback.props.role,'status');assert.equal(await initialize(content(tree).type),Value);assert.equal(loads,1);assert.equal(content(tree).props.value,'draft');assert(!('deferUntil' in content(tree).props));assert(!('onPanelReady' in content(tree).props));
 const readyNode=tree.props.children.props.children;assert.equal(ready,0);assert.equal(readyNode.type(readyNode.props),content(tree));assert.equal(ready,1,'Readiness is announced when loaded content commits, so pending navigation can resume');
 const firstType=content(tree).type,firstKey=tree.key;
 assert.equal(firstType.compare({active:true},{active:false}),false,'Deactivation renders once to release modal inspectors');
 assert.equal(firstType.compare({active:false,value:'old'},{active:false,value:'new'}),true,'Inactive workspaces avoid background rendering');
 assert.equal(firstType.compare({active:false},{active:true}),false,'Reactivation renders with the latest canonical data');
 assert.equal(firstType.compare({value:'old'},{value:'new'}),false,'Dialogs without activity opt-in continue updating');
 tree=render({deferUntil:true,value:'latest'});assert.equal(content(tree).type,firstType,'Navigating away preserves the loaded component identity');assert.equal(tree.key,firstKey,'Navigation cannot remount a visited workspace and lose its draft');assert.equal(content(tree).props.value,'latest','A hidden visited workspace still receives live project data');
 tree=render({value:'returned'});assert.equal(content(tree).type,firstType);assert.equal(loads,1);
 const Boundary=tree.type,boundary=new Boundary({...tree.props,onSettled:()=>ready++});boundary.state=Boundary.getDerivedStateFromError(Error('failure'));let error=boundary.render();assert.equal(error.props.role,'alert');boundary.componentDidCatch();assert.equal(ready,2,'A failed load also releases navigation; the user can leave or retry');
 // Retry creates a fresh lazy component; React.lazy caches rejected loads.
 error.props.children[1].props.onClick();fail=true;tree=render({value:'retry'});assert.notEqual(tree.key,firstKey);await assert.rejects(initialize(content(tree).type),/Unavailable local chunk/);
 const failedBoundary=new tree.type(tree.props);failedBoundary.state=tree.type.getDerivedStateFromError(Error('failure'));fail=false;failedBoundary.render().props.children[1].props.onClick();tree=render({value:'recovered'});assert.equal(await initialize(content(tree).type),Value);assert.equal(loads,3);assert.equal(content(tree).props.value,'recovered');
}finally{Object.assign(React,original);}
console.log('Deferred panels: no import before first visit, stable mounted identity/live props, accessible loading/error, rejected-load retry and recovery passed without launching a UI.');
// Check the actual shell wiring: a stable deferred component must not sit behind
// a condition that destroys it when leaving its workspace.
const {readFileSync}=await import('node:fs'),{default:ts}=await import('typescript');
const app=ts.createSourceFile('App.tsx',readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
for(const name of ['MapsEditor','PlotsEditor','CharacterArcsEditor','ProjectPending']){
 const found=[];
 function visit(node){if(ts.isJsxSelfClosingElement(node)&&node.tagName.getText(app)===name)found.push(node);ts.forEachChild(node,visit);}
 visit(app);assert.equal(found.length,1);
 const element=found[0],attributes=element.attributes.properties.map(attribute=>attribute.name?.getText(app));
 assert(attributes.includes('active')&&attributes.includes('deferUntil'),`${name} must receive workspace activity and first-visit deferral`);
 for(let parent=element.parent;parent;parent=parent.parent){
  if(ts.isBinaryExpression(parent)&&parent.operatorToken.kind===ts.SyntaxKind.AmpersandAmpersandToken)
   assert(!parent.left.getText(app).includes('activeView'),`${name} must survive a workspace switch`);
 }
}
