// Pure data/geometry checks only: no component rendering, UI or browser.
import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {graphPositions,readableGraphCamera,fitGraph,graphTopInset,saveGraphView}=loadLocal('../src/relationGraph.ts');
const {lineageDraftChanged}=loadLocal('../src/lineageDraft.ts');
const {floatingPanelPosition}=loadLocal('../src/floatingPanelPosition.ts');
const nodes=Array.from({length:500},(_,i)=>({id:`n${String(i).padStart(4,'0')}`}));
const links=nodes.slice(1,20).map((node,i)=>({id:`l${i}`,sourceId:nodes[i].id,targetId:node.id,typeId:'t'}));
const points=graphPositions(nodes,'',{},links);
assert.deepEqual(points,graphPositions([...nodes].reverse(),'',{},[...links].reverse()));
assert.equal(new Set(Object.values(points).map(p=>`${p.x}:${p.y}`)).size,nodes.length);
assert(Math.max(...Object.values(points).map(p=>p.x))-Math.min(...Object.values(points).map(p=>p.x))<7000);
const manual={n0001:{x:-1000,y:812}};assert.deepEqual(graphPositions(nodes,'',manual,links).n0001,manual.n0001);assert.deepEqual(manual,{n0001:{x:-1000,y:812}});
for(const viewport of [{width:1200,height:650},{width:800,height:450},{width:360,height:240}]){
 const camera=readableGraphCamera(points,'n0001',viewport),scale=Math.min(viewport.width/1400,viewport.height/900);
 assert(camera.zoom<=3);assert(camera.zoom*scale>=Math.min(1,3*scale));
 assert.equal(camera.x+points.n0001.x*camera.zoom,700);
 assert.equal(camera.y+points.n0001.y*camera.zoom,450);
 assert(fitGraph(points).zoom<camera.zoom,'Overview and reading are distinct');
 for(const side of ['left','right']){const panel=floatingPanelPosition({left:side==='left'?12:viewport.width-40,right:side==='left'?44:viewport.width-12,top:200,bottom:232},viewport,340,360);assert(panel.left>=12);assert(panel.left+panel.width<=viewport.width-12);assert(panel.maxHeight>=0);}
}
const blank={id:'g',name:'',memberIds:[]};assert(!lineageDraftChanged(blank));assert(!lineageDraftChanged({...blank,name:'  '}));assert(lineageDraftChanged({...blank,memberIds:['a']}));assert(lineageDraftChanged({...blank,name:'Witham'}));
const old={...blank,name:'Witham',memberIds:['a','b']};assert(!lineageDraftChanged({...old,memberIds:['b','a']},old));assert(lineageDraftChanged({...old,memberIds:['a']},old));
const relations={schemaVersion:8,lineages:[old],types:[],links:[]};const view={id:'v',name:'Dated',settings:{at:{year:0}},positions:points,camera:readableGraphCamera(points)};assert.equal(saveGraphView(relations,view).schemaVersion,8);assert.deepEqual(relations.lineages,[old]);
console.log('Relationship data/geometry: compact deterministic layout, manual preservation, readable viewport framing, bounded panels, clean lineage drafts and dated-view schema preservation passed.');

for(const viewport of [{width:1200,height:600},{width:360,height:400}]){
 const inset=graphTopInset(viewport,80);assert(inset>=0&&inset<=450);
 const small={a:{x:400,y:200},b:{x:800,y:500}},camera=fitGraph(small,inset);
 for(const point of Object.values(small))assert(camera.y+(point.y-32)*camera.zoom>=inset,'Fit keeps node bounds below the toolbar');
}
