import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const R=loadLocal('../src/entryRelations.ts'),P=loadLocal('../src/relationshipPresets.ts'),G=loadLocal('../src/genealogyLayout.ts'),T=loadLocal('../src/entryTransfer.ts');
const [a,b,c,templateId]=Array.from({length:4},()=>crypto.randomUUID());
const world={schemaVersion:1,templates:[{schemaVersion:1,id:templateId,title:'People',fields:[]}],entries:[a,b,c].map(id=>({schemaVersion:1,id,templateId,title:id,values:{},archived:false}))};
const presets=['guardian','step-parent','partner','former-partner'].map(preset=>({...P.relationshipPreset(preset),id:crypto.randomUUID()}));
let relations={schemaVersion:2,types:[],links:[]};for(const type of presets)relations=R.updateEntryRelationType(relations,type);assert.equal(relations.schemaVersion,6);
for(const type of presets.slice(0,2)){
 const first=R.saveEntryConnection(relations,world,a,'source',type.id,b),both=R.saveEntryConnection(first,world,a,'source',type.id,c);
 assert.equal(R.entryConnections(both,b)[0].currentRole,type.inverseTitle);assert.equal(R.entryConnections(both,a).length,2);
 assert.equal(R.parentConnections(both).length,0);assert.equal(R.hasAncestryCycle(both),false);
 const graph=G.genealogyGraph(world,both,b,0,0);assert.equal(graph.care.length,1);assert.equal(graph.parents.length,0);assert.equal(graph.siblings(b).length,0,'Care does not imply shared parents');assert.deepEqual(new Set(graph.nodes.map(node=>node.id)),new Set([a,b]));
 const edited=R.saveEntryConnection(both,world,b,'target',type.id,c,both.links[0].id,{start:{year:10}});assert.equal(edited.schemaVersion,6);assert.equal(edited.links[0].sourceId,c);assert.equal(R.removeEntryConnection(edited,edited.links[0].id).links.length,1);
 const packet=T.createEntryPackage(world,[a],both);assert.equal(packet.entryRelations.schemaVersion,6);const imported=T.importEntries({schemaVersion:1,templates:[],entries:[]},packet,[a]);assert.equal(imported.entryRelations.schemaVersion,6);assert.deepEqual(imported.entryRelations.types[0].genealogy,type.genealogy);
}
const partner=presets[2],former=presets[3];let paired=R.saveEntryConnection(relations,world,a,'source',partner.id,b);assert(!R.isFormerPartner(partner,paired.links[0]));paired=R.saveEntryConnection(paired,world,a,'source',partner.id,b,paired.links[0].id,{end:{year:20}});assert(R.isFormerPartner(partner,paired.links[0]));assert(R.isFormerPartner(former,{id:'',typeId:former.id,sourceId:a,targetId:b}));assert(!R.isFormerPartner(presets[0],paired.links[0]));
assert.equal(G.genealogyGraph(world,R.saveEntryConnection(relations,world,a,'source',former.id,b),a,0,0).partners.length,1);
const require=createRequire(import.meta.url),React=require('react'),old={useMemo:React.useMemo,useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const {EntryRelationDialog}=loadLocal('../src/RelationshipLibrary.tsx'),Genealogy=loadLocal('../src/Genealogy.tsx').default;
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
let states=[],index=0,saved;
const render=(Component,props)=>{index=0;return nodes(Component(props));};
try{
 React.useMemo=fn=>fn();React.useState=initial=>{const i=index++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return [states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useRef=value=>({current:value});React.useEffect=()=>{};
 for(const preset of ['guardian','step-parent','partner','former-partner']){states=[];saved=undefined;const all=render(EntryRelationDialog,{world,relations:{schemaVersion:2,types:[],links:[]},preset,onSave:type=>saved=type,onCancel(){}});assert(!all.find(n=>n.props?.id==='relationship-lineage'));all.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.equal(saved.genealogy.kind,P.relationshipPreset(preset).genealogy.kind);}
 states=[];const all=render(Genealogy,{world,relations:paired,onChange(){},onOpenEntry(){},onManage(){}});assert(all.some(n=>n.props?.className==='genealogy-edge partner former'));
}finally{Object.assign(React,old);}
console.log('Family relationships: care/affinity roles, no inferred filiation/siblings, shared edits, former partner status, version/date/import preservation and actual preset/tree controls passed.');
