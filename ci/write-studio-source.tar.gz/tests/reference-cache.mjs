import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {mentionNames,sceneMentions}=loadLocal('../src/mentionDetection.ts');
const {indexProjectTextReferences}=loadLocal('../src/textReferenceIndex.ts');
const {setLanguage}=loadLocal('../src/i18n.ts');
const world={templates:[],entries:[{id:'e',title:'Isabel',values:{},linkAliases:['Isa']}]};
const scene={id:'s',title:'Arrival',content:'Isabel e Isa.'};
const base=sceneMentions(scene,world);
assert.equal(base.length,2);
const editedWorld={...world,entries:[{...world.entries[0],values:{notes:'An unrelated edit'}}]};
assert.equal(mentionNames(world),mentionNames(editedWorld));
assert.equal(sceneMentions({...scene,title:'Renamed scene',entryIds:['e']},editedWorld),base);
const changed=sceneMentions({...scene,content:'Isa'},world);
assert.equal(changed.length,1);assert.notEqual(changed,base);
const ignored={...scene,ignoredMentions:[{from:1,to:7,text:'Isabel'}]};
assert.equal(sceneMentions(ignored,world).length,1);
assert.equal(sceneMentions(ignored,world,true).length,2);
const ambiguous={...world,entries:[...world.entries,{id:'other',title:'Isa',values:{}}]};
assert.deepEqual(sceneMentions(scene,ambiguous)[1].entryIds,['e','other']);
const resolved={...scene,resolvedMentions:[{from:10,to:13,text:'Isa',entryId:'other'}]};
assert.deepEqual(sceneMentions(resolved,ambiguous)[1].entryIds,['other']);
for(const entry of [{...world.entries[0],archived:true},{...world.entries[0],title:'Other',linkAliases:[]}]){
 assert.equal(sceneMentions(scene,{...world,entries:[entry]}).length,0);
}
assert.equal(sceneMentions(scene,{...world,entries:[]}).length,0);
assert.equal(sceneMentions(scene,{...world,entries:[{...world.entries[0],linkAliases:[]}]}).length,1);
// Exceed the bounded ID cache: live scenes must retain results without stale decisions.
const retained=Array.from({length:2100},(_,i)=>({id:`large-${i}`,title:'Scene',content:'Isabel'}));
const retainedResults=retained.map(item=>sceneMentions(item,world));
for(let i=0;i<retained.length;i++)assert.equal(sceneMentions(retained[i],world),retainedResults[i]);
retained[0].content='Nobody';assert.equal(sceneMentions(retained[0],world).length,0);
retained[1].ignoredMentions=[{from:1,to:7,text:'Isabel'}];assert.equal(sceneMentions(retained[1],world).length,0);assert.equal(sceneMentions(retained[1],world,true).length,1);
assert.equal(sceneMentions(retained[2],{...world,entries:[]}).length,0);
const project={id:'p',worldbuilding:world,chapters:[{id:'c',title:'Chapter',scenes:[scene]}]};
setLanguage('en');const index=indexProjectTextReferences(project);
assert.equal(indexProjectTextReferences(project),index);assert.equal(index[0].count,2);
const renamed={...project,chapters:[{...project.chapters[0],title:'New chapter',scenes:[{...scene,title:'New scene'}]}]};
assert.equal(indexProjectTextReferences(renamed)[0].label,'New chapter / New scene');
const removed={...project,chapters:[]};assert.deepEqual(indexProjectTextReferences(removed),[]);
setLanguage('es');assert.notEqual(indexProjectTextReferences(project)[0].field,index[0].field);
setLanguage('en');
console.log('Reference cache: reuse, content/decisions/names/aliases/archive invalidation, ambiguity, labels, deletion and language passed.');
// Many snippet requests must not reparse a long scene for every occurrence.
const model=loadLocal('../src/model.ts'),detection=loadLocal('../src/mentionDetection.ts'),continuity=loadLocal('../src/continuity.ts');
const originalParse=model.fromMarkdown,originalContext=detection.mentionContext;let parses=0,contexts=0;
try{
 model.fromMarkdown=source=>{parses++;return originalParse(source);};
 const snippets={id:'snippet-cache',content:'**Isabel** and Isa.  \nEnd.\n\nNext Isabel.'};
 const detected=sceneMentions(snippets,world);assert.equal(detected.length,3);assert.equal(parses,1);
 for(let repeat=0;repeat<50;repeat++)for(const mention of detected){const value=detection.mentionContext(snippets,mention.from,mention.to);assert(value.includes(mention.label));}
 assert.equal(parses,1,'All excerpts reuse the parsed scene instead of reparsing per mention');
 snippets.ignoredMentions=[{from:detected[0].from,to:detected[0].to,text:detected[0].label}];assert.equal(detection.sceneExcludedMentions(snippets).length,1);assert.equal(parses,1);
 snippets.content='No names.\n\nIsabel';assert.equal(detection.mentionContext(snippets,12,18),'Isabel');assert.equal(parses,2,'Content changes invalidate parsed snippets even for a mutated caller');
 const next=sceneMentions(snippets,world);assert.equal(next.length,1);assert.equal(next[0].from,12);assert.equal(parses,2);
 detection.mentionContext=(...args)=>{contexts++;return originalContext(...args);};
 continuity.reviewContinuity({worldbuilding:world,chapters:[{id:'clean',title:'Chapter',scenes:[{id:'clean-scene',title:'Scene',content:'Isabel and Isa.'}]}]});assert.equal(contexts,0,'Unambiguous valid references never request unused review excerpts');
 const duplicate={...world,entries:[...world.entries,{id:'second-isabel',title:'Isabel',values:{}}]};
 const issues=continuity.reviewContinuity({worldbuilding:duplicate,chapters:[{id:'ambiguous',title:'Chapter',scenes:[{id:'ambiguous-scene',title:'Scene',content:'Isabel'}]}]});assert.equal(contexts,1);assert.equal(issues.find(issue=>issue.kind==='ambiguous').excerpt,'Isabel');
}finally{model.fromMarkdown=originalParse;detection.mentionContext=originalContext;}
console.log('Continuity snippets: shared parsing, formatting/hard-break offsets, exclusions, mutable-content invalidation and excerpts only for actionable warnings passed.');
