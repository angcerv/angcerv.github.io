import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
const require=createRequire(import.meta.url),previous=require.extensions['.ts'];
require.extensions['.ts']=(module,filename)=>module._compile(ts.transpileModule(readFileSync(filename,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText,filename);
try {
 const {backupFilename}=require('../src/projectBackup.ts');
 const date=new Date(2026,9,20,14,3,9);
 assert.equal(backupFilename('Mi historia',date),'mi-historia-backup-2026-10-20-140309.zip');
 assert.equal(backupFilename('Árbol / ../ 世界 🌿',date),'arbol-backup-2026-10-20-140309.zip');
 assert.match(backupFilename('',date),/^project-backup-/);
 assert.ok(backupFilename('Long title '.repeat(100),date).length<100);
 assert.ok(!backupFilename('C:\\folder/name',date).includes('/'));
 console.log('Project backups: portable filenames include project title and local date/time, with safe Unicode/empty/long-title fallbacks.');
}finally{if(previous)require.extensions['.ts']=previous;else delete require.extensions['.ts'];}
