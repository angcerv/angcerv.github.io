import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const {continuityReviewSubject,currentReview,reviewReturnVisit}=loadLocal('../src/reviewWorkflow.ts');
const {reviewContinuity,resolveContinuityMention}=loadLocal('../src/continuity.ts');
const {continuityEvidence,saveContinuityDismissals}=loadLocal('../src/narrativeContinuity.ts');
const {activateWorkspaceMemory,cloneWorkspaceMemory,restoreWorkspaceMemory}=loadLocal('../src/workspaceNavigation.ts');
const require=createRequire(import.meta.url),React=require('react');
const project={schemaVersion:1,id:'review-flow',title:'Story',revision:0,chapters:[{id:'c',title:'Chapter',scenes:[{id:'s',title:'Arrival',content:'Alice arrives. Alice leaves.',synopsis:'Meet Alice',writingStatus:'inReview',reviewComments:[{id:'note',from:1,to:6,quote:'Alice',text:'Check this name',resolved:false}]}]}],worldbuilding:{schemaVersion:11,templates:[{id:'person',title:'People',fields:[]}],entries:[{id:'a',templateId:'person',title:'Alice',values:{},archived:false},{id:'b',templateId:'person',title:'Alice',values:{},archived:false}]}};
const before=JSON.stringify(project),comment={kind:'comment',sceneId:'s',commentId:'note'};
assert.equal(currentReview(project,comment).status,'pending');assert.deepEqual(currentReview(project,comment).range,{from:1,to:6});
const resolved=structuredClone(project);resolved.chapters[0].scenes[0].reviewComments[0].resolved=true;assert.equal(currentReview(resolved,comment).status,'resolved');
const detached=structuredClone(project);detached.chapters[0].scenes[0].reviewComments[0].detached=true;assert.equal(currentReview(detached,comment).range,undefined);assert.equal(currentReview(detached,comment).status,'unavailable');
const stale=structuredClone(project);stale.chapters[0].scenes[0].content='Other arrives.';assert.equal(currentReview(stale,comment).range,undefined);
assert.equal(currentReview(project,{...comment,commentId:'deleted'}).status,'missing');
assert.equal(currentReview(project,{kind:'review',sceneId:'s'}).status,'pending');resolved.chapters[0].scenes[0].writingStatus='draft';assert.equal(currentReview(resolved,{kind:'review',sceneId:'s'}).status,'resolved');
const issue=reviewContinuity(project).find(issue=>issue.kind==='ambiguous'),subject=continuityReviewSubject(project,issue);assert(subject.fragment);assert.equal(currentReview(project,subject).status,'pending');
const shifted=structuredClone(project);shifted.chapters[0].scenes[0].content='Before. '+shifted.chapters[0].scenes[0].content;
const moved=currentReview(shifted,subject);assert.equal(moved.status,'pending');assert.equal(moved.range.from,issue.range.from+8);
// Resolving the first occurrence must not switch the follow-up to the second.
const fixed=resolveContinuityMention(project,'s',issue.range,'a');assert.equal(currentReview(fixed,subject).status,'resolved');assert(reviewContinuity(fixed).some(issue=>issue.kind==='ambiguous'));
const edited=structuredClone(project);edited.chapters[0].scenes[0].content='Someone arrives. Someone leaves.';assert.equal(currentReview(edited,subject).status,'resolved');
const ambiguous=structuredClone(project);ambiguous.chapters[0].scenes[0].content='Different. Alice waits. Alice rests.';assert.equal(currentReview(ambiguous,subject).status,'unavailable');
const deleted=structuredClone(project);deleted.chapters[0].scenes=[];assert.equal(currentReview(deleted,subject).status,'missing');
const oldStorage=globalThis.localStorage;const values=new Map();globalThis.localStorage={getItem:key=>values.get(key)??null,setItem:(key,value)=>values.set(key,value)};
try{saveContinuityDismissals(project.id,{[issue.id]:continuityEvidence(project,issue)});assert.equal(currentReview(project,subject).status,'dismissed');assert.equal(currentReview(shifted,subject).status,'pending');}finally{if(oldStorage===undefined)delete globalThis.localStorage;else globalThis.localStorage=oldStorage;}
const dated=structuredClone(project);dated.worldbuilding.templates[0].fields=[{id:'birth',fieldType:'date',isBirthDate:true}];dated.worldbuilding.entries[0].values.birth={year:100};dated.timeline={schemaVersion:1,events:[{id:'event',title:'Arrival date',start:{year:90},sceneIds:['s'],entryIds:['a'],notes:'',dateLabel:''}]};
const age=reviewContinuity(dated).find(issue=>issue.kind==='age'),ageSubject=continuityReviewSubject(dated,age);assert.equal(currentReview(dated,ageSubject).status,'pending');
const correctedDate=structuredClone(dated);correctedDate.timeline.events[0].start.year=120;assert.equal(currentReview(correctedDate,ageSubject).status,'resolved');assert.equal(currentReview(correctedDate,ageSubject).title,'Alice');
const missingEvent=structuredClone(dated);missingEvent.timeline.events=[];assert.equal(currentReview(missingEvent,ageSubject).status,'missing');
assert.equal(JSON.stringify(project),before,'Reviewing and returning never restore stale project content');
const route={view:'pending',pendingIdeaId:''},position={scroll:[{element:{id:'pending-view',tag:'SECTION',path:[]},top:450,left:0}],details:[]},origin={route,memory:{'pending.query':'Alice','pending.kind':'comment'},position};
assert.equal(reviewReturnVisit(project,origin),origin);assert.equal(reviewReturnVisit(project,origin).position.scroll[0].top,450);assert.equal(reviewReturnVisit(project,{...origin,position:{...position,editor:{sceneId:'s',from:1,to:6}}}).position.editor,undefined,'Returning after edits must not select stale numeric text ranges');
assert.equal(reviewReturnVisit(project,{...origin,route:{view:'manuscript',selectedId:'deleted',manuscriptMode:'scene'}}).route.view,'pending');
// Real continuity controls retain query, grouping and context across remounts.
const Review=loadLocal('../src/ContinuityReview.tsx').default,old={useState:React.useState,useMemo:React.useMemo,useEffect:React.useEffect,useRef:React.useRef,useSyncExternalStore:React.useSyncExternalStore};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
let states=[],index=0;const memory={values:{}};activateWorkspaceMemory(memory);
try{
 React.useState=initial=>{const at=index++;if(!(at in states))states[at]=typeof initial==='function'?initial():initial;return[states[at],next=>states[at]=typeof next==='function'?next(states[at]):next];};React.useMemo=fn=>fn();React.useEffect=()=>{};React.useRef=value=>({current:value});React.useSyncExternalStore=(_subscribe,get)=>get();
 const render=()=>{index=0;return nodes(Review({project,onClose(){},onOpen(){},onResolve(){}}));};let tree=render();const controlIds=tree.filter(n=>n.type==='button'&&n.props.id?.startsWith('continuity-')).map(n=>n.props.id);assert.equal(new Set(controlIds).size,controlIds.length,'Warnings shown in several groups must have unique navigation IDs');tree.find(n=>n.type==='input'&&n.props.type==='search').props.onChange({target:{value:'Alice'}});tree.find(n=>n.props.id==='continuity-grouping'&&n.props.options).props.onChange('scene');tree=render();tree.find(n=>n.props.id==='continuity-context'&&n.props.options).props.onChange('s');
 const saved=cloneWorkspaceMemory(memory);memory.values={};restoreWorkspaceMemory(memory,saved);states=[];tree=render();assert.equal(tree.find(n=>n.type==='input'&&n.props.type==='search').props.value,'Alice');assert.equal(tree.find(n=>n.props.id==='continuity-grouping'&&n.props.options).props.value,'scene');assert.equal(tree.find(n=>n.props.id==='continuity-context'&&n.props.options).props.value,'s');
}finally{Object.assign(React,old);activateWorkspaceMemory(undefined);}
const Followup=loadLocal('../src/ReviewFollowup.tsx').default;let returned=0,resolutions=0;
const tree=nodes(Followup({review:currentReview(project,comment),returnLabel:'Return',onReturn:()=>returned++,onResolve:()=>resolutions++,onClose(){}}));const actions=tree.filter(n=>n.type==='button');actions[0].props.onClick();actions[1].props.onClick();assert.equal(returned,1);assert.equal(resolutions,1);
console.log('Review workflow: live comment resolution, detached/stale anchors, shifted/repeated mentions, evidence dismissals, deleted sources, immutable return positions, real filter remounts and follow-up actions passed.');
