import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const React=createRequire(import.meta.url)('react');
const R=loadLocal('../src/projectResume.ts'),{useProjectResume}=loadLocal('../src/useProjectResume.ts');
const original={useRef:React.useRef,useEffect:React.useEffect},oldStorage=globalThis.localStorage;
const memory=new Map();globalThis.localStorage={getItem:key=>memory.get(key)??null,setItem:(key,value)=>memory.set(key,value),removeItem:key=>memory.delete(key)};
const marker={projectId:'project',path:'/library/story',selectedId:'scene',view:'manuscript'};
let refs=[],effects=[],ri=0,ei=0,resumed=[];
React.useRef=value=>refs[ri++]??(refs[ri-1]={current:value});
React.useEffect=(run,deps)=>{const i=ei++;if(!effects[i]||deps.some((value,index)=>!Object.is(value,effects[i][index]))){effects[i]=deps;run();}};
const defaults={enabled:true,ready:true,blocked:false,path:'',selectedId:'',view:'home',onResume:value=>resumed.push(value)};
function render(props={}){ri=ei=0;useProjectResume({...defaults,...props});}
function restart(){refs=[];effects=[];resumed=[];}
try{
 assert.equal(R.readProjectResume(),null);
 R.rememberProjectResume({...marker,content:'Never persist text',draft:{private:true}});assert.deepEqual(R.readProjectResume(),marker);assert(![...memory.values()][0].includes('Never persist'));
 render({ready:false});render({blocked:true});assert.equal(resumed.length,0);render();assert.deepEqual(resumed,[marker]);render();assert.equal(resumed.length,1,'Ordinary renders do not reopen the project');
 restart();render({enabled:false});assert.equal(resumed.length,0);
 restart();render({projectId:'project',path:marker.path,selectedId:'scene-two',view:'worldbuilding'});assert.equal(resumed.length,0);assert.equal(R.readProjectResume().selectedId,'scene-two');
 render({blocked:true});render();assert.equal(resumed.length,0,'Leaving the background preserves mounted state instead of reopening');
 R.clearProjectResume();render();assert.equal(R.readProjectResume(),null);assert.equal(resumed.length,0,'Explicit closing stays closed');
 restart();render();assert.equal(resumed.length,0);
 R.rememberProjectResume(marker);restart();render();assert.deepEqual(resumed,[marker],'A fresh webview can resume a saved active project');
 for(const invalid of ['{bad',JSON.stringify({...marker,view:'unknown'}),JSON.stringify({...marker,projectId:''})]){memory.set('write-studio.mobile-active-project',invalid);assert.equal(R.readProjectResume(),null);}
 globalThis.localStorage.setItem=()=>{throw Error('unavailable');};R.rememberProjectResume(marker);
}finally{Object.assign(React,original);if(oldStorage===undefined)delete globalThis.localStorage;else globalThis.localStorage=oldStorage;}
console.log('Mobile resume: content-free marker, reload, readiness/recovery blockers, disabled desktop, stable mounted state, explicit close, corrupt/unavailable storage passed without UI.');
