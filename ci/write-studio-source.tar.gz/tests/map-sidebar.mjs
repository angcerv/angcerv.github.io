import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const require=createRequire(import.meta.url),React=require('react'),saved={useState:React.useState,useEffect:React.useEffect,useRef:React.useRef};
const Layers=loadLocal('../src/MapLayersPanel.tsx').default,Editor=loadLocal('../src/MapsEditor.tsx').default;
const world={entries:[],templates:[]};
let maps={schemaVersion:8,maps:[{id:'map',title:'Atlas',imageId:'image',notes:'',markers:[{id:'a',title:'City A',x:.2,y:.2,color:'teal',icon:'city',notes:'',layerId:'cities'},{id:'b',title:'City B',x:.8,y:.8,color:'teal',icon:'city',notes:''}],routes:[{id:'r',title:'Trip',color:'teal',markerIds:['a','b'],notes:'',layerId:'cities'}],layers:[{id:'cities',title:'Cities',visible:false}]}]};
function nodes(n){return Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];}
let states=[],index=0,addedMarker,addedRoute;
try{
 React.useState=initial=>{const i=index++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useEffect=()=>{};React.useRef=initial=>({current:initial});
 const panel=nodes(Layers({maps,map:maps.maps[0],world,markers:maps.maps[0].markers,routes:maps.maps[0].routes,onChange(){},onAddMarker:id=>addedMarker=id,onAddRoute:id=>addedRoute=id}));
 const branches=panel.filter(n=>typeof n.type==='function'&&n.type.name==='LayerBranch');assert.equal(branches.length,2);
 const assigned=nodes(branches.find(n=>n.props.hidden).props.children),unassigned=nodes(branches.find(n=>n.props.base).props.children);
 assert(assigned.some(n=>n.props?.className==='map-tree-marker'));assert(assigned.some(n=>n.props?.className==='map-tree-route'));assert(!unassigned.some(n=>n.props?.className==='map-tree-route'));
 assigned.find(n=>n.props?.label==='Add to Cities').props.actions.find(action=>action.label==='Add marker at center in Cities').onClick();assert.equal(addedMarker,'cities');
 assigned.find(n=>n.props?.label==='Add to Cities').props.actions.find(action=>action.label==='New route in Cities').onClick();assert.equal(addedRoute,'cities');
 states=[];index=0;let selectedMarker='';
 function render(extra={}){index=0;return nodes(Editor({maps,world,path:'/book',projectId:'p',mapId:'map',markerId:selectedMarker,onSelectMap(){},onSelectMarker:id=>selectedMarker=id,onChange:value=>maps=value,async onImport(){},onOpenEntry(){},...extra}));}
 const tree=()=>render().find(n=>n.type===Layers);
 tree().props.onAddMarker('cities');assert.equal(maps.maps[0].markers.length,3);assert.equal(maps.maps[0].markers[2].layerId,'cities');assert.equal(maps.maps[0].layers[0].visible,true);assert.equal(maps.schemaVersion,8);
 tree().props.onAddRoute('cities');const dialog=render().find(n=>typeof n.type==='function'&&n.type.name==='CreateRouteDialog');assert(dialog);dialog.props.onSave('New trip',['a','b']);const created=maps.maps[0].routes.at(-1);assert.equal(created.layerId,'cities');assert.equal(selectedMarker,'');
 const routePanel=render().find(n=>typeof n.type==='function'&&n.type.name==='MapRoutesPanel');assert.equal(routePanel.props.detailsOnly,true);assert.equal(routePanel.props.selectedId,created.id);
 // Explicit selection opens Properties and clears the previous element type.
 tree().props.onSelectMarker('a');
 let workspace=render();
 assert.equal(workspace.find(n=>typeof n.type==='function'&&n.type.name==='MapRoutesPanel').props.selectedId,'');
 assert(!workspace.find(n=>n.props?.className==='map-properties-slot').props.inert,'Selecting an element opens its independent properties');
 assert(workspace.find(n=>n.props?.className==='map-layers-slot'));
 assert(workspace.find(n=>n.props?.className==='map-tool-options-slot'),'Tool options remain a separate left panel');
 const panelOrder=['map-browser-slot','map-panel-rail','map-tool-options-slot','map-main','map-properties-slot','map-layers-slot'];assert.deepEqual(workspace.filter(n=>panelOrder.includes(n.props?.className)).map(n=>n.props.className),panelOrder);
 workspace.find(n=>n.props?.['aria-label']==='Close properties').props.onClick();workspace=render();assert(workspace.find(n=>n.props?.className==='map-properties-slot').props.inert);tree().props.onSelectMarker('a');workspace=render();assert(!workspace.find(n=>n.props?.className==='map-properties-slot').props.inert);
 assert(nodes(workspace.find(n=>n.props?.className==='map-tool-options-slot')).some(n=>n.props?.id==='map-notes'));
 const beforeLocate=JSON.stringify(maps),selectedBeforeLocate=selectedMarker;
 tree().props.onLocate({x:.7,y:.6});workspace=render();
 const canvas=workspace.find(n=>typeof n.type==='function'&&n.type.name==='MapCanvas');
 assert.deepEqual(canvas.props.locateRequest.point,{x:.7,y:.6});
 assert.equal(selectedMarker,selectedBeforeLocate);assert.equal(JSON.stringify(maps),beforeLocate);
 const rail=workspace.find(n=>n.props?.className==='map-panel-rail');
 assert.deepEqual(nodes(rail).filter(n=>n.type==='button').map(n=>n.props['aria-label']),['Elements','Measurement','Notes']);
 nodes(rail).find(n=>n.props?.['aria-label']==='Notes').props.onClick();workspace=render();tree().props.onSelectMarker('a');workspace=render();assert(workspace.find(n=>n.props?.['aria-label']==='Notes').props['aria-pressed'],'Selection preserves the active left tool');assert(!workspace.find(n=>n.props?.className==='map-properties-slot').props.inert);assert(workspace.find(n=>n.props?.className==='map-layers-slot'));
 nodes(rail).find(n=>n.props?.['aria-label']==='Measurement').props.onClick();workspace=render();assert(nodes(workspace.find(n=>n.props?.className==='map-tool-options-slot')).some(n=>n.type?.name==='MapScalePanel'));assert(workspace.find(n=>n.props?.className==='map-layers-slot'));
 nodes(rail).find(n=>n.props?.['aria-label']==='Elements').props.onClick();workspace=render();assert.equal(workspace.filter(n=>n.props?.className==='map-panel-page')[0].props.hidden,false);
 // History controls use the real geographic update path without touching the drawing.
 const drawingBefore=maps.maps[0].drawing;
 const undo=nodes(workspace.find(n=>n.type?.name==='MapCanvas').props.tools).find(n=>n.props?.['aria-label']==='Undo geographic edit');assert.equal(undo.props.disabled,false);undo.props.onClick();
 assert(!maps.maps[0].routes.some(route=>route.id===created.id));assert.equal(maps.maps[0].drawing,drawingBefore);
 workspace=render();const redo=nodes(workspace.find(n=>n.type?.name==='MapCanvas').props.tools).find(n=>n.props?.['aria-label']==='Redo geographic edit');assert.equal(redo.props.disabled,false);redo.props.onClick();assert(maps.maps[0].routes.some(route=>route.id===created.id));
 workspace=render();let prevented=false;const event={defaultPrevented:false,metaKey:true,ctrlKey:false,altKey:false,key:'z',shiftKey:false,target:{closest:()=>({})},preventDefault(){prevented=true;}};
 workspace.find(n=>n.props?.className==='maps-editor').props.onKeyDown(event);assert.equal(prevented,false,'Text fields and dialogs retain their native history');
 event.target={closest:()=>null};workspace.find(n=>n.props?.className==='maps-editor').props.onKeyDown(event);assert(prevented);assert(!maps.maps[0].routes.some(route=>route.id===created.id));
 workspace=render();workspace.find(n=>n.props?.className==='maps-editor').props.onKeyDown({...event,shiftKey:true});assert(maps.maps[0].routes.some(route=>route.id===created.id));
 workspace=render();workspace.find(n=>typeof n.type==='function'&&n.type.name==='MapCanvas').props.onInteractionChange(true);workspace=render();assert.equal(nodes(workspace.find(n=>n.type?.name==='MapCanvas').props.tools).find(n=>n.props?.['aria-label']==='Undo geographic edit').props.disabled,true);
 prevented=false;workspace.find(n=>n.props?.className==='maps-editor').props.onKeyDown(event);assert.equal(prevented,false,'Active gestures block history shortcuts');

 const measurement=workspace.find(n=>n.type?.name==='MapScalePanel');
 const preview=measurement.props.renderCalibration({reference:{from:{x:0,y:0},to:{x:1,y:0},aspectRatio:2},distanceKm:100,onChange(){},onInteractionChange(){}});
 assert.equal(preview.props.calibrationOnly,true);assert.deepEqual(preview.props.markers,[]);assert.deepEqual(preview.props.routes,[]);assert.deepEqual(preview.props.regions,[]);
 // One shared menu owns creation/import; animated panels stay mounted and become inert.
 states=[];let current=render();
 const creation=()=>current.find(n=>n.type?.name==='ActionMenu'&&n.props.label==='New map');
 assert(creation().props.iconOnly);assert.deepEqual(creation().props.actions.map(action=>action.label),['Import image']);
 current=render({path:''});assert(creation().props.actions.every(action=>action.disabled&&action.disabledReason));
 let imports=0;current=render({onImport:async()=>imports++});creation().props.actions.find(action=>action.label==='Import image').onClick();assert.equal(imports,1);
 current=render();current.find(n=>n.type==='button'&&n.props['aria-label']==='Project maps').props.onClick();current=render();
 const browser=current.find(n=>n.props?.className==='map-browser-slot');assert.equal(browser.props.inert,true);assert.equal(browser.props['aria-hidden'],true);assert(nodes(browser).some(n=>n.type==='aside'&&!n.props.hidden));
 const elements=()=>current.find(n=>n.type==='button'&&n.props['aria-label']==='Elements');elements().props.onClick();current=render();elements().props.onClick();current=render();elements().props.onClick();current=render();
 const details=current.find(n=>n.props?.className==='map-tool-options-slot');assert.equal(details.props.inert,true);assert(nodes(details).some(n=>n.type==='aside'&&!n.props.hidden));assert(current.find(n=>n.props?.className==='map-layers-slot'),'Layers stay mounted and available when tool options close');
 let createdMaps=0,finishCreation;const create=()=>{createdMaps++;return new Promise(resolve=>finishCreation=resolve);};
 current=render({onCreate:create});assert.deepEqual(creation().props.actions.map(action=>action.label),['Draw new map','Import image']);
 creation().props.actions[0].onClick();current=render({onCreate:create});assert.equal(creation().props.disabled,true);finishCreation(maps.maps[0].id);await Promise.resolve();current=render({onCreate:create});assert.equal(creation().props.disabled,false);assert.equal(createdMaps,1);
 const pendingEffects=[];React.useEffect=(effect,deps)=>pendingEffects.push({effect,deps});current=render({onCreate:create});React.useEffect=()=>{};
 const drawingRequest=pendingEffects.find(({deps})=>deps?.length===3&&deps[0]===true&&deps[1]===maps.maps[0].id&&deps[2]===maps.maps[0].id);assert(drawingRequest);drawingRequest.effect();current=render({onCreate:create});assert(current.some(n=>n.type?.name==='MapDrawingEditor'&&n.props.embedded));

}finally{Object.assign(React,saved);}
const Scale=loadLocal('../src/MapScalePanel.tsx').default;
const scaleHtml=renderToStaticMarkup(createElement(Scale,{map:maps.maps[0],world,onChange(){}}));assert(!scaleHtml.includes('map-scale-accordion'));assert(scaleHtml.includes('Map scale'));assert(!scaleHtml.includes('id="scale-distance"'));assert(!scaleHtml.includes('Distances use straight segments.'));assert(scaleHtml.includes('aria-label="Set scale"'));
const html=renderToStaticMarkup(createElement(Layers,{maps,map:maps.maps[0],world,onChange(){}}));assert(html.includes('map-layer-contents'));assert(!html.includes('Create layers to group'));
console.log('Map sidebar: nested layer membership, layer-specific marker/route creation, hidden-layer reveal, schema preservation, contextual route details and dedicated measurement passed.');

const artOnly={...maps.maps[0],markers:[],routes:[],regions:[],layers:[{id:'art',title:'Artwork',visible:true}],drawing:{width:1600,height:1000,objects:[],strokes:[{kind:'land',color:'#123456',width:.1,points:[{x:.1,y:.1}],layerId:'art'},{kind:'land',color:'#123456',width:.1,points:[{x:.2,y:.2}]}]}};
const artHtml=renderToStaticMarkup(createElement(Layers,{maps,map:artOnly,world,onChange(){},onOpenDrawing(){}}));
assert(!artHtml.includes('<details'),'Drawing-only layers do not offer empty disclosures');
assert(!artHtml.includes('No layer'),'Unassigned drawing is separate from the Elements tree');
assert(artHtml.includes('View drawing'));assert(artHtml.includes('Unlayered drawing'));assert(artHtml.includes('map-layer-unassigned-link'));assert(!artHtml.includes('Drawing:'));assert(!artHtml.includes('View unlayered drawing (1)'));
