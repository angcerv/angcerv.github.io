import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {readFileSync} from 'node:fs';
import {loadLocal} from './load-local.mjs';
const React=createRequire(import.meta.url)('react'),Hub=loadLocal('../src/ProjectExportDialog.tsx').default,Templates=loadLocal('../src/TemplateExportPanel.tsx').default;
const world={schemaVersion:1,templates:[{id:'a',title:'Alpha',fields:[{id:'ref',label:'Reference',fieldType:'reference',targetTemplateId:'b',archived:false}]},{id:'b',title:'Beta',fields:[]}],entries:[{id:'entry',templateId:'a',title:'Entry',values:{},archived:false}]};
const project={id:'p',title:'Novel',revision:0,schemaVersion:1,worldbuilding:world,chapters:[{id:'chapter',title:'Chapter',scenes:[{id:'scene',title:'Scene',content:'Text'}]}]},before=JSON.stringify(project);
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
const old={useState:React.useState,useEffect:React.useEffect,useMemo:React.useMemo};let states=[],cursor=0,closed=0,cleared=0,exported,busy=[];
try{
 React.useState=initial=>{const i=cursor++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],next=>states[i]=typeof next==='function'?next(states[i]):next];};React.useEffect=()=>{};React.useMemo=fn=>fn();
 let request={};const props={project,path:'/book',onClose:()=>closed++,onClearError:()=>cleared++,onExportEntries:async()=>false,onExportTemplates:async()=>false,onLoadEntries:async()=>null,onImportEntries:async()=>true};
 const render=()=>{cursor=0;return nodes(Hub({...props,request}));};let tree=render();const selector=()=>tree.find(node=>node.props?.id==='project-export-kind');const panels=()=>tree.filter(node=>node.props?.className==='project-export-panel');
 assert.equal(selector().props.options.length,5);assert.equal(panels().length,0);
 selector().props.onChange('entries');tree=render();let entry=tree.find(node=>node.props?.mode==='export');assert.equal(entry.props.embedded,true);assert.equal(entry.props.initialIds,undefined);
 entry.props.onBusyChange(true);tree=render();assert(tree[0].props.busy);assert(selector().props.disabled);selector().props.onChange('templates');tree[0].props.onClose();assert.equal(closed,0);assert.equal(panels().length,1);
 entry.props.onBusyChange(false);tree=render();selector().props.onChange('templates');tree=render();assert.equal(panels().length,2);assert.equal(panels().find(node=>node.key==='entries').props.inert,true);const retainedType=tree.find(node=>node.props?.mode==='export').type;
 selector().props.onChange('entries');tree=render();assert.equal(tree.find(node=>node.props?.mode==='export').type,retainedType);assert.equal(panels().find(node=>node.key==='entries').props.hidden,false);assert(cleared>=3);
 states=[];request={kind:'entries',ids:['entry']};tree=render();assert.deepEqual(tree.find(node=>node.props?.mode==='export').props.initialIds,['entry']);
 states=[];request={kind:'templates',ids:['a']};tree=render();assert.deepEqual(tree.find(node=>node.props?.initialIds&&node.props.onExport).props.initialIds,['a']);
 states=[];request={kind:'entries'};cursor=0;tree=nodes(Hub({...props,path:'',request}));assert.equal(tree.find(node=>node.props?.mode==='export').props.canExport,false);
 states=[];cursor=0;let settingsExports=0;const Settings=loadLocal('../src/ProjectDialogs.tsx').default;
 const settingsProps={kind:'settings',theme:'light',onTheme(){},settings:{projectsDirectory:'/books'},busy:false,error:'',name:'',folderName:'',onName(){},onFolderName(){},onChooseDirectory(){},onCreate(){},onClose(){},onExport:()=>settingsExports++};
 tree=nodes(Settings(settingsProps));tree.find(node=>node.type==='button'&&node.props.children?.includes?.('Export')).props.onClick();assert.equal(settingsExports,1);states=[];cursor=0;assert(!nodes(Settings({...settingsProps,onExport:undefined})).some(node=>node.props?.className==='project-export-setting'));
 // Template roots remain independent from their included dependencies.
 states=[];const templateProps={world,initialIds:['a'],onBusyChange:value=>busy.push(value),onExport:async ids=>{exported=ids;return false;}};const renderTemplates=()=>{cursor=0;return nodes(Templates(templateProps));};tree=renderTemplates();assert(tree.some(node=>node.type==='p'&&String(node.props.children).includes('2 templates')));tree.find(node=>node.props?.className==='primary-button').props.onClick();await new Promise(resolve=>setImmediate(resolve));assert.deepEqual(exported,['a']);assert.deepEqual(busy,[true,false]);tree=renderTemplates();assert(!tree.some(node=>node.type?.name==='ExportSuccess'));
 tree.find(node=>node.props?.id==='export-template-search').props.onChange({target:{value:'Beta'}});tree=renderTemplates();tree.find(node=>node.type==='button'&&node.props.children==='Select all').props.onClick();tree=renderTemplates();tree.find(node=>node.props?.className==='primary-button').props.onClick();await new Promise(resolve=>setImmediate(resolve));assert.deepEqual(exported,['a','b']);
}finally{Object.assign(React,old);}
// Embedded exporters render sections and retain standalone dialog support.
for(const file of ['ExportDialog','PlanningExportDialog','EncyclopediaExportDialog']){
 const Component=loadLocal(`../src/${file}.tsx`).default;
 const html=renderToStaticMarkup(createElement(Component,{project,path:'/book',embedded:true,onClose(){}}));assert(html.startsWith('<section'),file);assert(!html.includes('<dialog'),`${file} cannot open a nested dialog`);assert(html.includes('hidden=""'),file);
 const standalone=renderToStaticMarkup(createElement(Component,{project,path:'/book',onClose(){}}));assert(standalone.startsWith('<dialog'),file);
}
const Entries=loadLocal('../src/EntryTransferDialog.tsx').default;
const html=renderToStaticMarkup(createElement(Entries,{embedded:true,world,initialId:'',initialIds:['entry'],mode:'export',onLoad:async()=>null,onExport:async()=>false,onImport:async()=>true,onClose(){}}));assert(html.startsWith('<section'));assert(!html.includes('<dialog'));assert(html.includes('checked=""'));
const app=readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8');assert(app.includes('<ProjectExportDialog'));assert(!app.includes('ExportChoiceDialog'));assert(app.includes('onExport={project?'));assert(app.includes("openProjectExport({kind:'entries',ids:[id]})"));assert(app.includes("openProjectExport({kind:'templates',ids})"));
const worldSource=readFileSync(new URL('../src/WorldbuildingEditor.tsx',import.meta.url),'utf8');assert(!worldSource.includes("label:t('Export all templates…')"));assert(!worldSource.includes("label:t('Export encyclopedia…')"));assert(worldSource.includes("label:buttonLabel('Export this entry…')"));assert.equal(JSON.stringify(project),before);
console.log('Project exports: five types in one modal, embedded/standalone forms, individual roots, retained panels, busy guards, dependency summaries, cancellation and settings routing passed without UI.');

const Export=loadLocal('../src/ExportDialog.tsx').default,I=loadLocal('../src/i18n.ts'),language=I.getLanguage();
try{for(const lang of ['en','es']){I.setLanguage(lang);const markup=renderToStaticMarkup(createElement(Export,{project,path:'/book',onClose(){}}));assert(markup.includes(`<small>${lang==='es'?'1 escena':'1 scene'}</small>`));}}finally{I.setLanguage(language);}
