import {loadLocal} from './load-local.mjs';
import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
const { deleteField, fieldUsageCount, addTemplate, addField, updateField, moveField, reorderField, updateTemplate, addEntry, updateEntry, searchEntries, deleteEntry, deleteTemplate, templateEntryCount, incomingEntryLinks, referenceLabel } = loadLocal('../src/worldbuilding.ts');
const fixture = JSON.parse(readFileSync(new URL('fixtures/worldbuilding-project.json', import.meta.url), 'utf8')).worldbuilding;
function freeze(value) { if (value && typeof value === 'object') { Object.freeze(value); Object.values(value).forEach(freeze); } return value; }
const original = freeze(structuredClone(fixture));
const template = original.templates[0], name = template.fields[0], notes = template.fields[1];
let world = updateTemplate(original, { ...template, title: 'Renamed template' });
world = updateField(world, template.id, name.id, { label: 'Display name' });
world = moveField(world, template.id, notes.id, -1);
world = updateField(world, template.id, name.id, { archived: true });
assert.equal(world.templates[0].fields[1].archived, true);
assert.deepEqual(world.entries, original.entries, 'Renaming, ordering and archiving fields must preserve every value');
world = updateField(world, template.id, name.id, { archived: false });
world = addField(world, template.id, '  New field  ', 'longText');
assert.equal(world.templates[0].fields.at(-1).label, 'New field');
assert.equal(world.entries[0].values[world.templates[0].fields.at(-1).id], undefined, 'New fields start empty');
assert.equal(world.entries[0].values[name.id], 'Élise');
const orderBefore=world.templates[0].fields.map(field=>field.id);
const reordered=reorderField(freeze(structuredClone(world)),template.id,orderBefore[0],orderBefore.length-1);
assert.deepEqual(reordered.templates[0].fields.map(field=>field.id),[...orderBefore.slice(1),orderBefore[0]]);
assert.deepEqual(reordered.entries,world.entries,'Dragging fields must preserve entry values');
assert.deepEqual(reorderField(reordered,template.id,orderBefore[0],0).templates[0].fields.map(field=>field.id),orderBefore);
for(const invalid of [-1,orderBefore.length,1.5]) assert.equal(reorderField(world,template.id,orderBefore[0],invalid),world);
assert.equal(reorderField(world,template.id,'missing',0),world);

assert.deepEqual(searchEntries(world, 'ÉLISE').map(e => e.id), [original.entries[0].id]);
assert.equal(searchEntries(world, 'Second paragraph', template.id).length, 1);
assert.equal(searchEntries(world, '', original.templates[1].id).length, 1);
assert.equal(searchEntries(world, '', '', true).length, 1);
const entry = world.entries[0];
world = updateEntry(world, { ...entry, archived: true });
assert.equal(searchEntries(world, 'Élise').length, 0);
assert.equal(searchEntries(world, 'Élise', template.id, true).length, 1);
world = updateEntry(world, { ...entry, archived: false, title: 'New display name' });
assert.equal(world.entries[0].templateId, template.id);
assert.equal(world.entries[0].values[name.id], 'Élise');
const createdTemplate = addTemplate(world, '  Any custom category  ');
assert.equal(createdTemplate.world.templates.at(-1).title, 'Any custom category');
const createdEntry = addEntry(createdTemplate.world, createdTemplate.templateId, '  My entry  ');
assert.equal(createdEntry.world.entries.at(-1).templateId, createdTemplate.templateId);
assert.deepEqual(createdEntry.world.entries.at(-1).values, {});
assert.equal(addEntry(world, 'missing', 'Invalid'), null);
assert.deepEqual(original, fixture, 'Worldbuilding edits must not mutate the source');
console.log('Worldbuilding: stable field values, archive/restore, template changes, new fields, Unicode search and immutable entries passed.');

// Deletions preserve unrelated records and dangling references, and include archived usage.
assert.equal(templateEntryCount(original, template.id), 2);
assert.equal(deleteTemplate(original, template.id), original);
let deleted = deleteEntry(original, original.entries[0].id);
assert.equal(deleteTemplate(deleted, template.id), deleted, 'An archived entry still blocks template deletion');
deleted = deleteEntry(deleted, original.entries[2].id);
const removedTemplate = deleteTemplate(deleted, template.id);
assert.equal(removedTemplate.templates.length, original.templates.length - 1);
assert.deepEqual(removedTemplate.entries, [original.entries[1]]);
const references = freeze(JSON.parse(readFileSync(new URL('fixtures/references-project.json', import.meta.url), 'utf8')).worldbuilding);
const linkedId = references.entries[1].id;
assert.ok(incomingEntryLinks(references, linkedId).length > 0);
const removedLinked = deleteEntry(references, linkedId);
assert.deepEqual(removedLinked.entries[0], references.entries[0], 'Incoming reference IDs are kept for explicit repair');
assert.equal(referenceLabel(removedLinked, linkedId), 'Missing entry');
assert.equal(deleteEntry(original, 'absent'), original);
assert.equal(deleteTemplate(original, 'absent'), original);
console.log('Worldbuilding deletion: archived usage guards, immutable removals and retained references passed.');

const removable={schemaVersion:1,templates:[{schemaVersion:1,id:'template',title:'Template',fields:[{id:'used',label:'Used',fieldType:'boolean',archived:false},{id:'unused',label:'Unused',fieldType:'shortText',archived:false}]}],entries:[{schemaVersion:1,id:'entry',templateId:'template',title:'Entry',archived:true,values:{used:false}}]};
const removalSnapshot=JSON.stringify(removable);
assert.equal(fieldUsageCount(removable,'template','used'),1);
assert.equal(deleteField(removable,'template','used'),removable);
const removed=deleteField(removable,'template','unused');
assert.deepEqual(removed.templates[0].fields.map(field=>field.id),['used']);
assert.equal(removed.entries,removable.entries);
assert.equal(JSON.stringify(removable),removalSnapshot);
console.log('Template fields: unused removal is immutable; archived entries and false/zero-like values prevent destructive deletion.');

// Stored empty placeholders must not make an otherwise unused field undeletable.
for(const [fieldType,value] of [['shortText',''],['shortText','  \n '],['longText','\n  \n'],['multiPicklist',[]],['date',null],['reference',null],['number',null]]){
 const empty={schemaVersion:7,templates:[{schemaVersion:7,id:'t',title:'Template',fields:[{id:'empty',label:'Empty',fieldType,archived:true}]}],entries:[{schemaVersion:7,id:'active',templateId:'t',title:'Active',archived:false,values:{empty:value,other:'Keep'}},{schemaVersion:7,id:'archived',templateId:'t',title:'Archived',archived:true,values:{empty:null}},{schemaVersion:7,id:'untouched',templateId:'t',title:'Untouched',archived:false,values:{}}]};
 const snapshot=JSON.stringify(empty);freeze(empty);
 assert.equal(fieldUsageCount(empty,'t','empty'),0,fieldType);
 const removed=deleteField(empty,'t','empty');assert.equal(removed.templates[0].fields.length,0);
 assert(removed.entries.every(entry=>!Object.hasOwn(entry.values,'empty')),'No orphan keys for native storage');
 assert.equal(removed.entries[0].values.other,'Keep');assert.equal(removed.entries[2],empty.entries[2]);assert.equal(JSON.stringify(empty),snapshot);
}
for(const [fieldType,value] of [['number',0],['boolean',false],['shortText','Text'],['longText','**Text**'],['multiPicklist',['option']],['reference',{entryId:'missing'}],['date',{year:0}]]){
 const used={...removable,templates:[{...removable.templates[0],fields:[{id:'filled',label:'Filled',fieldType,archived:true}]}],entries:[{...removable.entries[0],values:{filled:value}}]};
 assert.equal(fieldUsageCount(used,'template','filled'),1,fieldType);assert.equal(deleteField(used,'template','filled'),used);
}
console.log('Empty field deletion: cleared text, whitespace, empty lists/null, active/archived cleanup, immutable data, zero/false/reference/date protection passed.');
