import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const require=createRequire(import.meta.url),{EditorState}=require('@tiptap/pm/state'),{history,undo,redo}=require('@tiptap/pm/history');
const {findManuscript,replaceManuscript,manuscriptSchema,replacementTransaction}=loadLocal('../src/manuscriptSearch.ts');
const {ManuscriptHistory}=loadLocal('../src/manuscriptHistory.ts');
const {getSchema}=require('@tiptap/core'),StarterKit=require('@tiptap/starter-kit').default;
const freshSchema=()=>getSchema([StarterKit]);
const {fromMarkdown,toMarkdown}=loadLocal('../src/model.ts');
const options={query:'café',scope:'project',caseSensitive:false,wholeWord:true};
const project={id:'p',title:'Book',chapters:[{id:'c',title:'Chapter',scenes:[{id:'s',title:'First',content:'**Café** café cafetería. _café_. 😀 café.',reviewComments:[{id:'r',from:25,to:29,quote:'café',text:'Review',resolved:false}]},{id:'s2',title:'Second',content:'café. Literal .* and $&.'}]}]};
assert.equal(findManuscript(project,options).length,5);
assert.equal(findManuscript(project,{...options,caseSensitive:true}).length,4);
assert.equal(findManuscript(project,{...options,scope:'scene',sceneId:'s2'}).length,1);
assert.equal(findManuscript(project,{...options,scope:'chapter',chapterId:'missing'}).length,0);
assert.equal(findManuscript(project,{...options,query:'.*'}).length,1);
assert.equal(findManuscript(project,{...options,query:''}).length,0);
const before=JSON.stringify(project),matches=findManuscript(project,options),cache=new ManuscriptHistory();
const result=replaceManuscript(project,matches,'té',cache);
assert.equal(JSON.stringify(project),before);
assert.deepEqual(fromMarkdown(result.chapters[0].scenes[0].content),fromMarkdown('**té** té cafetería. _té_. 😀 té.'));
assert.deepEqual(fromMarkdown(result.chapters[0].scenes[1].content),fromMarkdown('té. Literal .* and $&.'));
assert.throws(()=>replaceManuscript(result,matches,'other'),/changed/);
const deleted=replaceManuscript(project,[matches[0]],'');assert.ok(deleted.chapters[0].scenes[0].content.startsWith(' café'));
let state=EditorState.create({schema:manuscriptSchema,doc:manuscriptSchema.nodeFromJSON(fromMarkdown('Start')),plugins:[history()]});
state=state.apply(state.tr.insertText(' text',6));cache.remember('s',state);
const newSchema=freshSchema();
let remounted=EditorState.create({schema:newSchema,doc:newSchema.nodeFromJSON(state.doc.toJSON()),plugins:[history()]});remounted=cache.restore('s',remounted);
assert.ok(undo(remounted,tr=>remounted=remounted.apply(tr)));assert.equal(remounted.doc.textContent,'Start');
assert.ok(redo(remounted,tr=>remounted=remounted.apply(tr)));assert.equal(remounted.doc.textContent,'Start text');
// Offscreen replacements retain per-scene undo after remounting.
const offscreenSchema=freshSchema();
let replaced=EditorState.create({schema:offscreenSchema,doc:offscreenSchema.nodeFromJSON(fromMarkdown(result.chapters[0].scenes[1].content)),plugins:[history()]});
replaced=cache.restore('s2',replaced);assert.ok(undo(replaced,tr=>replaced=replaced.apply(tr)));assert.deepEqual(fromMarkdown(toMarkdown(replaced.doc.toJSON())),fromMarkdown(project.chapters[0].scenes[1].content));
// Stale positions never replace an unrelated fragment.
assert.throws(()=>replacementTransaction(state,[{from:1,to:3,quote:'xx'}],'x'),/changed/);
assert.ok(redo(replaced,tr=>replaced=replaced.apply(tr)));assert.equal(replaced.doc.textContent,'té. Literal .* and $&.');
console.log('Manuscript search: scopes, literal matching, Unicode, formatting, deletion, immutable edits, stale results and remounted undo/redo passed.');
// Comments and explicit mention choices move with untouched text, while replaced
// mention text loses the obsolete resolution instead of linking the new name.
const linked={id:'p',chapters:[{id:'c',title:'C',scenes:[{id:'linked',title:'S',content:'Old name and Alice.',ignoredMentions:[{from:14,to:19,text:'Alice'}],resolvedMentions:[{from:1,to:4,text:'Old',entryId:'entry'}],reviewComments:[{id:'note',from:14,to:19,quote:'Alice',text:'Keep this',resolved:false}]}]}]};
const linkedOptions={...options,query:'Old'};
const linkedResult=replaceManuscript(linked,findManuscript(linked,linkedOptions),'Newer name').chapters[0].scenes[0];
assert.deepEqual(linkedResult.ignoredMentions,[{from:21,to:26,text:'Alice'}]);
assert.deepEqual(linkedResult.resolvedMentions,[]);
assert.equal(linkedResult.reviewComments[0].from,21);assert.equal(linkedResult.reviewComments[0].quote,'Alice');
// Redo survives a further remount, and changed documents reject cached history.
undo(remounted,tr=>remounted=remounted.apply(tr));cache.remember('redo',remounted);
const schema3=freshSchema();let again=EditorState.create({schema:schema3,doc:schema3.nodeFromJSON(remounted.doc.toJSON()),plugins:[history()]});again=cache.restore('redo',again);
assert.ok(redo(again,tr=>again=again.apply(tr)));assert.equal(again.doc.textContent,'Start text');
const different=EditorState.create({schema:schema3,doc:schema3.nodeFromJSON(fromMarkdown('Restored version')),plugins:[history()]});assert.equal(cache.restore('redo',different),different);
// Word boundaries inspect full Unicode code points, including astral letters.
const unicodeProject={chapters:[{id:'unicode',title:'C',scenes:[{id:'unicode-scene',title:'S',content:'𐐀café café𐐀 café 😀café'}]}]};
assert.equal(findManuscript(unicodeProject,options).length,2);
// Cached indexes must still reflect edited content and preserve formatted ranges.
const cachedScene={id:'cache',title:'S',content:'**uno** uno'};
const cachedProject={chapters:[{id:'cache-chapter',title:'C',scenes:[cachedScene]}]};
assert.equal(findManuscript(cachedProject,{...options,query:'uno'}).length,2);
cachedScene.content='**dos**';
assert.equal(findManuscript(cachedProject,{...options,query:'uno'}).length,0);
assert.equal(findManuscript(cachedProject,{...options,query:'dos'})[0].from,1);
