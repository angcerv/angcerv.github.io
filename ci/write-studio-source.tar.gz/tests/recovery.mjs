import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
const source = readFileSync(new URL('../src/recovery.ts', import.meta.url), 'utf8')
  .replace("import { invoke } from '@tauri-apps/api/core';", 'const invoke = () => Promise.reject(new Error("Native IPC unavailable in unit test"));')
  .replace("import { fromMarkdown } from './model';", 'const fromMarkdown = () => {};');
const js = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 } }).outputText;
const { RecoveryWriter } = await import(`data:text/javascript;base64,${Buffer.from(js).toString('base64')}`);
let release;
const writes = [];
let active = 0;
const writer = new RecoveryWriter(async snapshot => {
  active++;
  assert.equal(active, 1, 'Recovery writes must never overlap');
  writes.push(snapshot);
  if (writes.length === 1) await new Promise(resolve => { release = resolve; });
  active--;
});
const first = writer.enqueue({ version: 1 });
await Promise.resolve();
const second = writer.enqueue({ version: 2 });
const third = writer.enqueue({ version: 3 });
release();
await Promise.all([first, second, third]);
assert.deepEqual(writes, [{ version: 1 }, { version: 3 }]);
await writer.enqueue(null);
assert.equal(writes.at(-1), null, 'Discard must follow all older writes');
await writer.enqueue({ version: 4 });
assert.equal(writes.at(-1).version, 4, 'A subsequent edit must start a new writer');
let fail = true;
const retry = new RecoveryWriter(async () => { if (fail) throw new Error('Disk full'); });
await assert.rejects(retry.enqueue({ version: 1 }), /Disk full/);
fail = false;
await retry.enqueue({ version: 2 });
console.log('Recovery: serialized writes, coalescing, ordered discard, new edits and failed-write retry passed.');

// A failed in-flight write must not strand a newer background draft or discard.
for (const latest of [{version: 3}, null]) {
 let rejectFirst;
 const attempts=[];
 const queued=new RecoveryWriter(async snapshot=>{
  attempts.push(snapshot);
  if(attempts.length===1)await new Promise((_,reject)=>{rejectFirst=reject;});
 });
 const running=queued.enqueue({version:1});
 await Promise.resolve();
 const pending=queued.enqueue({version:2});
 const final=queued.enqueue(latest);
 rejectFirst(new Error('Provider temporarily unavailable'));
 await Promise.all([running,pending,final]);
 assert.deepEqual(attempts,[{version:1},latest]);
}
let rejectOld;
const failedLatest=new RecoveryWriter(async snapshot=>{
 if(snapshot.version===1)await new Promise((_,reject)=>{rejectOld=reject;});
 throw new Error('Latest draft failed');
});
const oldWrite=failedLatest.enqueue({version:1});await Promise.resolve();
const newWrite=failedLatest.enqueue({version:2});
const failures=Promise.allSettled([oldWrite,newWrite]);rejectOld(new Error('Old draft failed'));
assert((await failures).every(result=>result.status==='rejected'&&/Latest draft failed/.test(result.reason.message)));
console.log('Recovery provider failures: queued latest drafts/discards drain and final failures remain visible.');
