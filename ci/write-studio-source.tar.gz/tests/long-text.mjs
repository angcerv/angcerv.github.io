import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {longTextDocument:parse,longTextMarkdown:serialize}=loadLocal('../src/longText.ts');
const {displayFieldValue,searchEntries,convertToLongText}=loadLocal('../src/worldbuilding.ts');
const {acceptsShortText,SHORT_TEXT_LIMIT}=loadLocal('../src/ShortTextEditor.tsx');
const text=n=>n.type==='text'?n.text:n.type==='hardBreak'?'\n':(n.content??[]).map(text).join('');
for(const source of ['Plain text.\n\nSecond paragraph 🌿','**Bold** _italic_ <u>underline</u>','- First\n- Second','Unmatched **Chris','| Name | Detail |\n| --- | --- |\n| **City** | Port |','<script>alert("hello")</script>','Escaped \\_underscore\\_ and C:\\\\folder','**Nested _italic_**','- Parent\n  - Nested\n  - Other\n- Sibling','- First line\n  continuation\n\n  Second paragraph','Line\n\n\n\nAfter empty paragraph']){
 const doc=parse(source),again=parse(serialize(doc));
 assert.equal(text(again),text(doc),source);
 assert.equal(serialize(again),serialize(doc),'Canonical formatting stabilizes');
}
const formatted=parse('**Bold**\n\n- _Italic_\n- <u>Underlined</u>');
assert.equal(formatted.content[0].content[0].marks[0].type,'bold');
assert.equal(formatted.content[1].type,'bulletList');
assert.equal(formatted.content[1].content[1].content[0].content[0].marks[0].type,'underline');
assert.equal(SHORT_TEXT_LIMIT,200);assert(acceptsShortText('', 'x'.repeat(200)));assert(!acceptsShortText('', 'x'.repeat(201)));assert(acceptsShortText('x'.repeat(400),'x'.repeat(399)));assert(!acceptsShortText('x'.repeat(400),'x'.repeat(401)));
const world={schemaVersion:9,templates:[{schemaVersion:9,id:'t',title:'T',fields:[{id:'f',label:'F',fieldType:'shortText',archived:true,description:'Help',sectionId:'s'},{id:'n',label:'N',fieldType:'number',archived:false}]}],entries:[{schemaVersion:9,id:'e',templateId:'t',title:'E',archived:false,values:{f:'x'.repeat(500),n:3}}]};
const before=structuredClone(world),next=convertToLongText(world,'t','f');
assert.equal(next.templates[0].fields[0].fieldType,'longText');assert.deepEqual({...next.templates[0].fields[0],fieldType:'shortText'},world.templates[0].fields[0]);assert.equal(next.entries,world.entries);assert.deepEqual(world,before);assert.equal(convertToLongText(world,'t','n'),world);assert.equal(convertToLongText(next,'t','f'),next);
assert.equal(displayFieldValue({fieldType:'longText'},'**Bold** _word_ <u>here</u>'),'Bold word here');
assert.equal(searchEntries({...next,entries:[{...next.entries[0],archived:false,values:{f:'**Bold** word'}}]},'Bold word').length,1);
const {LongTextView}=loadLocal('../src/LongTextEditor.tsx');
const rendered=renderToStaticMarkup(createElement(LongTextView,{value:'**Bold** _italic_ <u>underline</u>\n\n- Item\n\n<script>alert(1)</script>'}));
assert(rendered.includes('<strong>Bold</strong>'));assert(rendered.includes('<em>italic</em>'));assert(rendered.includes('<u>underline</u>'));assert(rendered.includes('<ul>'));assert(!rendered.includes('<script>'));assert(rendered.includes('&lt;script&gt;'));
assert.equal(text(parse('C:\\folder')), 'C:\\folder');
const ShortText=loadLocal('../src/ShortTextEditor.tsx').default;
let edited='',converted=false;
const React=loadLocal('react'),previousEffect=React.useEffect;let short;
try {React.useEffect=()=>{};short=ShortText({id:'short',value:'x'.repeat(220),onChange:value=>edited=value,onConvert:()=>converted=true});}finally{React.useEffect=previousEffect;}
const input=short.props.children[0],limit=short.props.children[1];assert.equal(input.props.value.length,220);assert.equal(input.props.maxLength,200);assert.equal(input.props.plain,true);
assert.equal(acceptsShortText('x'.repeat(220),'x'.repeat(221)),false);assert.equal(edited,'');
input.props.onChange('x'.repeat(219));assert.equal(edited.length,219);
limit.props.children[1].props.onClick();assert(converted);
console.log('Long field formatting, safe widening and short text limits passed.');


const {focusEmptyLongText}=loadLocal('../src/LongTextEditor.tsx');
const {getSchema}=loadLocal('@tiptap/core'),{TextSelection,EditorState}=loadLocal('@tiptap/pm/state'),StarterKit=loadLocal('@tiptap/starter-kit').default;
const schema=getSchema([StarterKit]),emptyDoc=schema.nodeFromJSON(parse(''));let prevented=0,nativeFocus=0,viewFocus=0,transactions=[];
const view={state:EditorState.create({schema,doc:emptyDoc}),dom:{isConnected:true,focus:options=>{assert.deepEqual(options,{preventScroll:true});nativeFocus++;}},dispatch(transaction){transactions.push(transaction);this.state=this.state.apply(transaction);},focus(){viewFocus++;}};
const editor={isDestroyed:false,isEditable:true,isEmpty:true,view},pointer={button:0,preventDefault:()=>prevented++};
assert.equal(focusEmptyLongText(editor,pointer),true);assert.equal(prevented,1);assert.equal(nativeFocus,1);assert.equal(viewFocus,1);assert(view.state.selection instanceof TextSelection);assert.equal(view.state.selection.from,1);assert.equal(view.state.selection.to,1);assert(view.state.doc.eq(emptyDoc));assert(!transactions[0].docChanged,'Focusing never inserts placeholder text or changes the field');
for(const candidate of [null,{...editor,isEmpty:false},{...editor,isEditable:false},{...editor,isDestroyed:true},{...editor,view:{...view,dom:{isConnected:false}}}])assert.equal(focusEmptyLongText(candidate,pointer),false);
assert.equal(focusEmptyLongText(editor,{...pointer,button:2}),false);assert.equal(viewFocus,1,'Existing text selections and secondary clicks are left to the native editor');assert.equal(prevented,1);
