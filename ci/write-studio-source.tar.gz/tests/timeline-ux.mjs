import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const {timelineContentSignature}=loadLocal('../src/timelineWorkspace.ts');
const {storedCalendarDate}=loadLocal('../src/calendarBrowse.ts');
const {defaultStoryCalendar}=loadLocal('../src/storyCalendar.ts');
const timeline={schemaVersion:6,events:[{id:'e',title:'Event',notes:'',dateLabel:'',sceneIds:[],entryIds:[],plotIds:[],relations:[],start:{year:12,month:3,day:4}}],tracks:[],relationTypes:[]};
const native=JSON.parse(JSON.stringify(timeline,(_key,value)=>value&&typeof value==='object'&&!Array.isArray(value)?Object.fromEntries(Object.entries(value).reverse().filter(([key,item])=>!(['tracks','relationTypes','plotIds','relations'].includes(key)&&Array.isArray(item)&&!item.length))):value));
assert.equal(timelineContentSignature(native),timelineContentSignature(timeline));
assert.notEqual(timelineContentSignature({...native,events:[{...native.events[0],title:'External change'}]}),timelineContentSignature(timeline));
const calendar={...defaultStoryCalendar(),mode:'fixed',epochYear:2000};
const expected=storedCalendarDate({year:0,month:2,day:4},calendar);assert(expected&&expected.year===2000);
const React=createRequire(import.meta.url)('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
let states=[],refs=[],si=0,ri=0,closed=0;
try{
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};
 React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 const CalendarDialog=loadLocal('../src/StoryCalendarDialog.tsx').default;
 const render=()=>{si=ri=0;return nodes(CalendarDialog({initial:calendar,onClose:()=>closed++,onSave(){}}));};
 let tree=render();tree.find(n=>n.type==='input').props.onChange({target:{value:'Changed calendar'}});tree=render();tree.find(n=>n.type==='button'&&n.props.children==='Cancel').props.onClick();tree=render();assert.equal(closed,0);assert(tree.some(n=>n.props?.variant==='confirmation'));
 tree.find(n=>n.type==='button'&&n.props.children==='Keep editing').props.onClick();tree=render();assert.equal(tree.find(n=>n.type==='input').props.value,'Changed calendar');assert(!tree.some(n=>n.props?.variant==='confirmation'));
 states=[];refs=[];closed=0;
 const Relations=loadLocal('../src/TimelineRelations.tsx').default;
 const relations=()=>{si=ri=0;return nodes(Relations({timeline,world:{templates:[]},onCancel:()=>closed++,onSave(){}}));};
 tree=relations();tree.find(n=>n.type==='input'&&n.props.id==='relation-title').props.onChange({target:{value:'Participants'}});tree=relations();tree.find(n=>n.type==='button'&&n.props.children==='Cancel').props.onClick();tree=relations();assert.equal(closed,0);assert(tree.some(n=>n.props?.role==='alert'));assert(tree.find(n=>n.type==='fieldset').props.disabled);
 tree.find(n=>n.type==='button'&&n.props.children==='Keep editing').props.onClick();tree=relations();assert.equal(tree.find(n=>n.type==='input'&&n.props.id==='relation-title').props.value,'Participants');
}finally{Object.assign(React,old);}
console.log('Chronology UX: native-save-stable undo signatures, external-change guards, canonical calendar conversion and retained calendar/relation drafts passed without UI.');
