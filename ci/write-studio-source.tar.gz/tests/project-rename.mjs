import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const React=createRequire(import.meta.url)('react'),Dialog=loadLocal('../src/ProjectRenameDialog.tsx').default,previous=React.useState;
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
let value='Original',saved,closed=0;
try{
 React.useState=()=>[value,next=>value=next];
 const render=(busy=false)=>nodes(Dialog({title:'Original',busy,onClose:()=>closed++,onSave:name=>saved=name}));
 let tree=render();assert.equal(tree[0].props.variant,'confirmation');assert(tree.some(n=>n.type==='label'&&n.props.htmlFor==='rename-project-title'));assert.equal(tree.find(n=>n.type==='input').props.value,'Original');
 tree.find(n=>n.type==='input').props.onChange({target:{value:'   '}});tree=render();assert(tree.find(n=>n.type==='button'&&n.props.type==='submit').props.disabled);assert(tree.some(n=>n.props?.role==='alert'));tree.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.equal(saved,undefined);
 tree.find(n=>n.type==='input').props.onChange({target:{value:'  New project  '}});tree=render();tree.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.equal(saved,'New project');saved=undefined;
 tree=render(true);assert(tree.filter(n=>n.type==='input'||n.type==='button').every(n=>n.props.disabled));tree.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.equal(saved,undefined);
 tree=render();tree.find(n=>n.type==='button'&&n.props.type==='button').props.onClick();assert.equal(closed,1);assert.equal(saved,undefined,'Cancel preserves the canonical project name');
}finally{React.useState=previous;}
console.log('Project rename: shared compact dialog, visible label, blank validation, trimmed save, busy guards and cancellation passed without UI.');
