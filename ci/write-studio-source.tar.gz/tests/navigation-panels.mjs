import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
const require=createRequire(import.meta.url),React=require('react'),icons=require('lucide-react');
const {entryTemplateGlyph}=loadLocal('../src/entryTemplateGlyph.ts');
for(const [title,icon] of [['Personajes',icons.UserRound],['Characters',icons.UserRound],['Lugares',icons.MapPin],['Objetos',icons.Package],['Custom notes',icons.FileText]])assert.equal(entryTemplateGlyph({title,fields:[]}),icon);
assert.equal(entryTemplateGlyph({title:'Crew',fields:[{isBirthDate:true}]}),icons.UserRound);
const {EntryThumbnail}=loadLocal('../src/EntryImage.tsx');const thumbnail=renderToStaticMarkup(createElement(EntryThumbnail,{title:'Hero',fallback:createElement(icons.UserRound,{size:19})}));assert(thumbnail.includes('lucide-user-round'));assert(!thumbnail.includes('lucide-image'));
const Navigation=loadLocal('../src/ManuscriptNavigation.tsx').default;
const chapters=[{id:'c1',title:'Opening',scenes:[{id:'a',title:'Río azul',content:''},{id:'b',title:'Departure',content:''}]},{id:'c2',title:'Arrival',scenes:[{id:'d',title:'The city',content:''}]}],before=JSON.stringify(chapters);
const old={useState:React.useState,useEffect:React.useEffect};let state=[],index=0,opened,editing;
function nodes(n){return Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];}
try{
 React.useState=initial=>{const i=index++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return[state[i],value=>state[i]=typeof value==='function'?value(state[i]):value];};React.useEffect=()=>{};
 function render(){index=0;return nodes(Navigation({chapters,selectedId:'a',onChapter:id=>opened=id,onScene:id=>opened=id,onSceneTools:id=>editing=id,onAddScene(){}}));}
 let all=render();assert.equal(all.filter(n=>n.props?.className==='scene-item').length,3);
 const edit=all.find(n=>n.props?.label==='Options for scene Departure');assert(edit);edit.props.actions.find(action=>action.label==='Edit details').onClick();assert.equal(editing,'b');assert.equal(opened,undefined,'Editing details is separate from ordinary scene selection');
 all.find(n=>n.props?.id==='manuscript-search').props.onChange({target:{value:'rio'}});all=render();assert.equal(all.filter(n=>n.props?.className==='scene-item').length,1);all.find(n=>n.props?.className==='scene-item').props.onClick();assert.equal(opened,'a');
 all.find(n=>n.props?.id==='manuscript-search').props.onChange({target:{value:'arrival'}});all=render();assert.equal(all.find(n=>n.props?.className==='chapter-number').props.children,2,'Search keeps original chapter numbering');assert.equal(all.filter(n=>n.props?.className==='scene-item').length,1);
 all.find(n=>n.props?.id==='manuscript-search').props.onChange({target:{value:'unknown'}});assert(render().some(n=>n.props?.className==='navigation-empty'));
 assert.equal(JSON.stringify(chapters),before);
}finally{Object.assign(React,old);}
console.log('Navigation panels: template-specific thumbnail fallback, accented title search, chapter context/numbering, scene navigation and unchanged manuscript passed.');

// Execute the real sidebar routing action, including requests for the selected scene.
const appSource=ts.createSourceFile('App.tsx',readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
let inspectNode;function findInspect(node){if(ts.isFunctionDeclaration(node)&&node.name?.text==='inspect')inspectNode=node;ts.forEachChild(node,findInspect);}findInspect(appSource);assert(inspectNode);
for(const selectedId of ['a','b']){
 const state={selectedId,inspectingSelection:{current:false},request:0};
 const scope={selectedId,inspectingSelection:state.inspectingSelection,setFocusMode:value=>state.focus=value,setToolsOpenRequest:fn=>state.request=fn(state.request),setManuscriptMode:value=>state.mode=value,setSelectedId:value=>state.scene=value,setToolsTab:value=>state.tab=value,setWorldOpen:value=>state.world=value,setToolsOpen:value=>state.open=value};
 const script=ts.transpileModule(`const {${Object.keys(scope).join(',')}}=scope;${inspectNode.getText(appSource)};return inspect;`,{compilerOptions:{target:ts.ScriptTarget.ES2022}}).outputText;
 const inspect=new Function('scope',script)(scope);inspect('scene','b');assert.equal(state.scene,'b');assert.equal(state.open,true);assert.equal(state.tab,'scene');assert.equal(state.focus,false);assert.equal(state.world,false);assert.equal(state.request,1);assert.equal(state.inspectingSelection.current,selectedId!=='b');
}
