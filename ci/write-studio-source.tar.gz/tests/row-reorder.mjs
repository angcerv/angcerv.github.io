import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const React=createRequire(import.meta.url)('react'),{default:useRowReorder,orderedSlots}=loadLocal('../src/useRowReorder.tsx');
const items=['a','hidden','b','other','c'].map(id=>({id}));assert.deepEqual(orderedSlots(items,['c','a','b']).map(i=>i.id),['c','hidden','a','other','b']);assert.equal(orderedSlots(items,['a','b','c']),items);assert.equal(orderedSlots(items,['a','a']),items);assert.equal(orderedSlots(items,['missing']),items);
const old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
let states=[],refs=[],si=0,ri=0,commits=[],captured=false,removed=0,moved=0;
let sort;
const rows=()=>sort.order('layers',items.filter(i=>['a','b','c'].includes(i.id))).map((item,index)=>({dataset:{sortGroup:'layers',sortRow:item.id},closest:()=>null,getBoundingClientRect:()=>({top:index*40,height:40})}));
const scope={querySelectorAll:()=>[...rows(),{dataset:{sortGroup:'layers',sortRow:'preview-copy'},closest:()=>copy}],scrollHeight:0,clientHeight:100,parentElement:null};
const copy={style:{},removeAttribute(){},querySelectorAll:()=>[],classList:{remove(){},add(){}},setAttribute(){},showPopover(){moved++;},remove(){removed++;}};
const row={getBoundingClientRect:()=>({left:10,top:0,width:200,height:40}),cloneNode:()=>copy,parentElement:{append(){}},closest:()=>scope};
const handle={focus(){},closest:()=>row,setPointerCapture(){captured=true;},hasPointerCapture:()=>captured,releasePointerCapture(){captured=false;}};
const event=(y,extra={})=>({button:0,isPrimary:true,pointerId:1,clientX:20,clientY:y,currentTarget:handle,preventDefault(){},stopPropagation(){},...extra});
try{
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=initial;return[states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useRef=initial=>refs[ri++]??(refs[ri-1]={current:initial});React.useEffect=()=>{};
 const render=()=>{si=ri=0;return sort=useRowReorder((group,ids)=>commits.push({group,ids}));};
 const grip=()=>sort.handle('layers','a','A',['a','b','c']).props;
 render();grip().onPointerDown(event(20));grip().onPointerMove(event(110));render();assert.deepEqual(sort.order('layers',items.filter(i=>i.id!=='hidden'&&i.id!=='other')).map(i=>i.id),['b','c','a']);assert.equal(commits.length,0,'Preview must not persist');assert.equal(sort.row('layers','a')['data-sort-moving'],true);assert.equal(copy.style.top,'90px');assert.equal(moved,1);
 grip().onPointerUp(event(110));render();assert.deepEqual(commits,[{group:'layers',ids:['b','c','a']}]);assert.equal(captured,false);assert.equal(removed,1);
 grip().onPointerDown(event(20));grip().onPointerMove(event(110));render();grip().onKeyDown(event(110,{key:'Escape'}));render();assert.equal(commits.length,1);assert.equal(sort.row('layers','a')['data-sort-moving'],undefined);assert.equal(captured,false);
 grip().onPointerDown(event(20));grip().onPointerMove(event(110));grip().onPointerCancel(event(110));render();assert.equal(commits.length,1);
 grip().onKeyDown(event(0,{key:'ArrowDown'}));assert.deepEqual(commits.at(-1).ids,['b','a','c']);assert(sort.handle('x','a','A',['a','b'],true).props.disabled);assert(sort.handle('x','a','A',['a']).props.disabled);
}finally{Object.assign(React,old);}
console.log('Row ordering: moving pointer preview, provisional list order, atomic release, Escape/cancel cleanup, keyboard ordering and filtered-slot preservation passed without UI.');
