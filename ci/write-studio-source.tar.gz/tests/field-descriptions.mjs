import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const {addField,addEntry,updateField}=loadLocal('../src/worldbuilding.ts');
const {createTemplatePackage,importTemplates}=loadLocal('../src/templateTransfer.ts');
const {setLanguage}=loadLocal('../src/i18n.ts');
let world={schemaVersion:1,templates:[{schemaVersion:1,id:'t',title:'People',fields:[]}],entries:[]};
world=addField(world,'t','Motivation','shortText');world=addEntry(world,'t','Isabel').world;
const original=JSON.stringify(world),id=world.templates[0].fields[0].id;
const description='What drives this character?\nInclude a concrete example. <not markup>';
const changed=updateField(world,'t',id,{description});
assert.equal(changed.schemaVersion,9);assert.equal(changed.templates[0].schemaVersion,9);assert.equal(changed.entries[0].schemaVersion,9);assert.equal(changed.templates[0].fields[0].description,description);
assert.equal(JSON.stringify(world),original);assert.deepEqual(changed.entries[0].values,{});
assert.equal(updateField(changed,'t',id,{description:'  '}).templates[0].fields[0].description,undefined);
const added=addField(world,'t','Goal','longText',undefined,undefined,false,undefined,'  Explain the goal.  ');assert.equal(added.schemaVersion,9);assert.equal(added.templates[0].fields[1].description,'Explain the goal.');
const copied=importTemplates({schemaVersion:1,templates:[],entries:[]},createTemplatePackage(changed,['t']),['t']);assert.equal(copied.world.templates[0].fields[0].description,description);assert.equal(copied.world.schemaVersion,9);
const Help=loadLocal('../src/FieldHelp.tsx').default;
assert.equal(renderToStaticMarkup(createElement(Help,{label:'Motivation'})),'');assert.equal(renderToStaticMarkup(createElement(Help,{label:'Motivation',description:'  '})),'');
const Editor=loadLocal('../src/WorldbuildingEditor.tsx').default,Panel=loadLocal('../src/WorldPanel.tsx').default,Preview=loadLocal('../src/MapEntryPreview.tsx').default;
for(const markup of [renderToStaticMarkup(createElement(Editor,{world:changed,entryId:changed.entries[0].id,tab:'entries',setTab:()=>{},setEntryId:()=>{},onChange:()=>{},onReturn:()=>{}})),renderToStaticMarkup(createElement(Panel,{world:changed,entryId:changed.entries[0].id,onSelectEntry:()=>{},onOpenEditor:()=>{},onClose:()=>{}})),renderToStaticMarkup(createElement(Preview,{entry:changed.entries[0],world:changed,chapters:[],path:'',projectId:'',onOpenEntry:()=>{}}))]){
 assert.ok(markup.includes('About field Motivation'));assert.ok(markup.includes('field-help-button'));assert.ok(!markup.includes('What drives this character?'));
}
const Create=loadLocal('../src/FieldCreateDialog.tsx').default;assert.ok(renderToStaticMarkup(createElement(Create,{world,onSave:()=>{},onCancel:()=>{}})).includes('new-field-description'));
setLanguage('es');const spanish=renderToStaticMarkup(createElement(Help,{label:'Motivación',description}));assert.ok(spanish.includes('Información sobre el campo Motivación'));setLanguage('en');
console.log('Field descriptions: optional metadata, schema upgrade, immutable field edits/removal, template transfer, creation UI and info icons in all entry views passed.');

// Exercise deletion through the real controls, including a live usage change.
const React=createRequire(import.meta.url)('react'),Fields=loadLocal('../src/TemplateFields.tsx').default;
const savedHooks={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
let hookState=[],hookIndex=0,liveWorld={...world,entries:world.entries.map(entry=>({...entry,values:{[id]:''}}))};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
function renderFields(){hookIndex=0;return nodes(Fields({world:liveWorld,template:liveWorld.templates[0],onChange:next=>liveWorld=next}));}
try{
 React.useState=initial=>{const i=hookIndex++;if(!(i in hookState))hookState[i]=initial;return [hookState[i],value=>hookState[i]=value];};React.useRef=initial=>({current:initial});React.useEffect=()=>{};
 let tree=renderFields(),button=tree.find(n=>n.props?.['aria-label']==='Delete field Motivation');assert.equal(button.props.disabled,false);
 button.props.onClick();tree=renderFields();let dialog=tree.find(n=>n.type?.name==='DeleteFieldDialog');assert.equal(dialog.props.blocked,false);
 const confirmation=dialog.type(dialog.props);assert.equal(confirmation.props.variant,'confirmation');
 dialog.props.onCancel();assert.equal(liveWorld.templates[0].fields.length,1);
 renderFields().find(n=>n.props?.['aria-label']==='Delete field Motivation').props.onClick();
 liveWorld={...liveWorld,entries:liveWorld.entries.map(entry=>({...entry,values:{[id]:'Filled while confirmation was open'}}))};
 dialog=renderFields().find(n=>n.type?.name==='DeleteFieldDialog');assert.equal(dialog.props.blocked,true);
 const blocked=nodes(dialog.type(dialog.props));assert(blocked.some(n=>n.props?.role==='alert'));assert(blocked.find(n=>n.props?.className==='danger-button').props.disabled);
 liveWorld={...liveWorld,entries:liveWorld.entries.map(entry=>({...entry,values:{[id]:''}}))};
 dialog=renderFields().find(n=>n.type?.name==='DeleteFieldDialog');nodes(dialog.type(dialog.props)).find(n=>n.props?.className==='danger-button').props.onClick();
 assert.equal(liveWorld.templates[0].fields.length,0);assert(!Object.hasOwn(liveWorld.entries[0].values,id));
}finally{Object.assign(React,savedHooks);}
console.log('Field deletion controls: empty placeholders enable removal, cancellation preserves fields, live filled values disable confirmation and confirmed cleanup leaves no orphan keys.');
