import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const React=createRequire(import.meta.url)('react');
const Dialog=loadLocal('../src/BooksDialog.tsx').default,Navigation=loadLocal('../src/BookNavigation.tsx').default,Appearances=loadLocal('../src/EntryAppearances.tsx').default,Modal=loadLocal('../src/ProjectModal.tsx').default,ActionMenu=loadLocal('../src/ActionMenu.tsx').default;
const N=loadLocal('../src/workspaceNavigation.ts'),{setLanguage}=loadLocal('../src/i18n.ts');
const project={schemaVersion:1,id:'p',revision:3,title:'Saga',chapters:[{id:'c1',title:'Opening',scenes:[{id:'s1',title:'Opening',content:'Arrow',entryIds:['e']}]},{id:'c2',title:'Opening',scenes:[{id:'s2',title:'Opening',content:'Arrow',entryIds:['e']}]}]};
const snapshot=JSON.stringify(project);
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
const text=n=>Array.isArray(n)?n.map(text).join(''):typeof n==='string'?n:n?.props?text(n.props.children):'';
const old={useState:React.useState,useRef:React.useRef,useContext:React.useContext,useId:React.useId,useMemo:React.useMemo,useEffect:React.useEffect,useLayoutEffect:React.useLayoutEffect};
let states=[],refs=[],si=0,ri=0,effects=[],layouts=[],saved,closed=0;
const reset=()=>{states=[];refs=[];};
const render=(Component,props)=>{si=ri=0;effects=[];layouts=[];return nodes(Component(props));};
const button=(tree,label)=>tree.find(n=>n.type==='button'&&(n.props['aria-label']===label||text(n)===label));
const menu=(tree,label)=>tree.find(n=>n.type===ActionMenu&&n.props.label===label);
const action=(tree,label,name)=>menu(tree,label).props.actions.find(a=>a.label===name);
let committed;
try{
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useMemo=fn=>fn();React.useId=()=> 'book-ui-id';React.useEffect=fn=>effects.push(fn);React.useLayoutEffect=fn=>layouts.push(fn);
 let currentProject=project;const props=()=>({project:currentProject,onSave:next=>{saved=next;},onClose:()=>closed++}),organizer=()=>render(Dialog,props());
 let tree=organizer();const first=tree.find(n=>n.props?.['data-book-id']).props['data-book-id'];assert.equal(saved,undefined);assert(!tree.some(n=>n.props?.id==='organizer-book-title'));assert(!tree.some(n=>n.type==='input'&&n.props.type==='checkbox'),'Single-book organization has no useless move selection');assert(!tree.some(n=>n.props?.id?.startsWith('chapter-book-')));
 assert(action(tree,'Options for book 1: Saga','Remove empty book').disabled);assert(action(tree,'Options for book 1: Saga','Remove empty book').disabledReason);
 button(tree,'New book').props.onClick();tree=organizer();const second=tree.find(n=>n.props?.['data-book-id']&&n.props['data-book-id']!==first).props['data-book-id'];
 tree.find(n=>n.props?.id==='organizer-book-title').props.onChange({target:{value:'Volume II'}});tree=organizer();let stopped=false;tree.find(n=>n.props?.id==='organizer-book-title').props.onKeyDown({key:'Enter',preventDefault(){stopped=true;},stopPropagation(){}});assert(stopped);assert.equal(saved,undefined,'Applying a title is still only a dialog draft');
 tree=organizer();tree.find(n=>n.props?.['data-book-id']===first).props.onClick();tree=organizer();assert.equal(tree.filter(n=>n.type==='input'&&n.props['aria-label']?.startsWith('Select chapter')).length,2,'Repeated titles remain separately selectable by position');
 button(tree,'Options for chapter 1: Opening');
 tree.find(n=>n.type==='input'&&n.props.type==='checkbox'&&!n.props['aria-label']).props.onChange({target:{checked:true}});tree=organizer();button(tree,'Move 2 chapters').props.onClick();tree=organizer();assert(button(tree,'Move chapters').props.disabled);const destination=tree.find(n=>n.props?.id==='book-move-destination');assert.deepEqual(destination.props.options.map(o=>o.value),[second]);destination.props.onChange(second);tree=organizer();button(tree,'Move chapters').props.onClick();tree=organizer();assert(tree.find(n=>n.props?.['data-book-id']===second).props['aria-pressed']);assert.equal(tree.filter(n=>n.type==='input'&&n.props['aria-label']?.startsWith('Select chapter')&&n.props.checked).length,2,'Moved chapters remain selected in their destination');assert(text(tree).includes('2 chapters moved to Volume II.'));assert.equal(saved,undefined);assert.equal(JSON.stringify(project),snapshot);
 action(tree,'Options for book 2: Volume II','Move book up').onClick();tree=organizer();assert.equal(tree.find(n=>n.props?.['data-book-id']).props['data-book-id'],second);
 // Background save acknowledgements and newer scene text must not be overwritten.
 currentProject={...project,revision:4,chapters:project.chapters.map(c=>c.id==='c1'?{...c,scenes:[{...c.scenes[0],content:'Latest Arrow text'}]}:c)};
 tree=organizer();tree.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.equal(saved.revision,4);assert.equal(saved.chapters[0].scenes[0].content,'Latest Arrow text');assert.deepEqual(saved.books.map(b=>b.title),['Volume II','Saga']);assert.deepEqual(saved.books[0].chapterIds,['c1','c2']);committed=saved;
 // An empty book can be removed, but the final book cannot; move controls disappear.
 action(tree,'Options for book 2: Saga','Remove empty book').onClick();tree=organizer();assert(action(tree,'Options for book 1: Volume II','Remove empty book').disabled);assert(!tree.some(n=>n.type==='input'&&n.props.type==='checkbox'));
 button(tree,'Rename book').props.onClick();tree=organizer();tree.find(n=>n.props?.id==='organizer-book-title').props.onChange({target:{value:' '}});tree=organizer();assert(tree.find(n=>n.type==='button'&&n.props.type==='submit').props.disabled);tree.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.strictEqual(saved,committed);
 tree.find(n=>n.props?.id==='organizer-book-title').props.onKeyDown({key:'Escape',preventDefault(){},stopPropagation(){}});assert.equal(closed,0,'Escape in a title cancels only renaming');tree=organizer();button(tree,'Cancel').props.onClick();assert.equal(closed,1);assert.equal(JSON.stringify(project),snapshot);
 reset();tree=render(Dialog,{project:committed,bookId:first,createOnOpen:true,onSave(){throw Error('Unexpected save');},onClose:()=>closed++});assert(tree.some(n=>n.props?.id==='organizer-book-title'));const modalNode=tree.find(n=>n.type===Modal);assert.equal(modalNode.props.titleAccessory.props.variant,'toolbar');
 reset();const actualModal=render(Modal,modalNode.props);actualModal.find(n=>n.type==='dialog').props.onCancel({preventDefault(){}});assert.equal(closed,2,'Native Escape discards all uncommitted organization changes');
 // A changed chapter structure cannot produce a partial organization save.
 reset();let staleSave=false;const staleProps={project,onSave(){staleSave=true;},onClose(){},createOnOpen:true};render(Dialog,staleProps);
 tree=render(Dialog,{...staleProps,project:{...project,chapters:[...project.chapters,{id:'new-chapter',title:'New',scenes:[]}]}});tree.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});tree=render(Dialog,{...staleProps,project:{...project,chapters:[...project.chapters,{id:'new-chapter',title:'New',scenes:[]}]}});assert(!staleSave);assert(tree.some(n=>n.props?.role==='alert'&&text(n).includes('Chapters changed')));
 reset();let declined=0;const declinedProps={project,createOnOpen:true,onSave(){declined++;return false;},onClose(){throw Error('Rejected save must keep the organizer open');}};tree=render(Dialog,declinedProps);tree.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});tree=render(Dialog,declinedProps);assert.equal(declined,1);assert(tree.some(n=>n.props?.role==='alert'&&text(n).includes('Chapters changed')));
 // The active book has one shared selector in sidebar/inline contexts and remembers stable IDs.
 reset();const memory={values:{}};N.activateWorkspaceMemory(memory);let selected,create;
 const navProps={project:committed,bookId:second,selectedId:'s2',onSelect:(id,selection)=>selected={id,selection},onManage:value=>create=value};
 tree=render(Navigation,navProps);effects.forEach(fn=>fn());tree=render(Navigation,navProps);tree.find(n=>n.props?.id==='active-book').props.onChange(first);assert.deepEqual(selected,{id:first,selection:''});assert.equal(memory.values['manuscript.bookSelections'][second],'s2');
 reset();tree=render(Navigation,{...navProps,bookId:first,selectedId:'',inline:true});tree.find(n=>n.props?.id==='active-book-inline').props.onChange(second);assert.deepEqual(selected,{id:second,selection:'s2'});action(tree,'Book options','New book').onClick();assert.equal(create,true);action(tree,'Book options','Manage books').onClick();assert.equal(create,undefined);assert(!JSON.stringify(memory).includes('Latest Arrow text'));
 reset();tree=render(Navigation,{...navProps,project:{...committed,books:[committed.books[0]]}});assert(!tree.some(n=>n.props?.role==='combobox'||n.props?.id==='active-book'));assert(menu(tree,'Book options'));
 N.activateWorkspaceMemory(undefined);
 const world={schemaVersion:1,templates:[{id:'t',schemaVersion:1,title:'People',fields:[]}],entries:[{id:'e',schemaVersion:1,templateId:'t',title:'Arrow',values:{},archived:false}]};
 const forAppearances={...committed,books:[{...committed.books[0],chapterIds:['c1']},{...committed.books[1],chapterIds:['c2']}]};React.useContext=()=>({project:forAppearances});reset();tree=render(Appearances,{chapters:project.chapters,world,entryId:'e'});assert.equal(tree.filter(n=>n.props?.className==='entry-appearance-chapter').length,2);tree.find(n=>n.props?.id==='book-ui-id-book').props.onChange(second);tree=render(Appearances,{chapters:project.chapters,world,entryId:'e'});assert.equal(tree.filter(n=>n.props?.className==='entry-appearance-chapter').length,1);
}finally{Object.assign(React,old);N.activateWorkspaceMemory(undefined);}
setLanguage('es');const html=renderToStaticMarkup(createElement(Dialog,{project:committed,bookId:committed.books[0].id,onSave(){},onClose(){}}));assert(html.includes('Organizar libros')&&html.includes('Nuevo libro')&&html.includes('Los cambios se aplican al guardar.')&&html.includes('Volume II'));assert(!html.includes('chapter-book-'));setLanguage('en');
console.log('Book UI: staged two-pane organization, numbered duplicates, bulk move/selection, contextual order/deletion, pending title validation/cancellation, latest text/revision, native close, compact selector/remount memory, shared appearances and Spanish labels passed without UI launch.');
