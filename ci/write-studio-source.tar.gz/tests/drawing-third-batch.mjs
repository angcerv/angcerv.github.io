import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const {arrangeDrawingObjects,snapDrawingPoint,reorderDrawingObject,moveDrawingObjectsToLayer}=loadLocal('../src/drawingPrecision.ts');
const {drawingObjectBounds,drawingSvg}=loadLocal('../src/mapDrawing.ts');
const layers=[{id:'front',title:'Front',visible:true},{id:'locked',title:'Locked',visible:true,locked:true},{id:'hidden',title:'Hidden',visible:false}];
const objects=[{id:'a',kind:'castle',x:.2,y:.2,size:.1,rotation:30},{id:'b',kind:'forest',x:.55,y:.5,size:.04},{id:'line',kind:'line',x:.1,y:.7,endX:.4,endY:.8,size:.06},{id:'path',kind:'path',x:.4,y:.2,size:.06,points:[{x:.4,y:.2},{x:.5,y:.3}]},{id:'locked',kind:'planet',x:.3,y:.3,size:.1,layerId:'locked'}];
const drawing={width:1000,height:600,strokes:[],objects};
const bounds=o=>drawingObjectBounds(o,1000,600),close=(a,b)=>assert(Math.abs(a-b)<1e-8,`${a} != ${b}`);
const aligned=arrangeDrawingObjects(drawing,['a','b','line','path','locked'],layers,'left');
for(const object of aligned.slice(0,4))close(bounds(object).x,bounds(aligned[0]).x);
assert.equal(aligned[4],objects[4]);close(aligned[2].endX-aligned[2].x,.3);close(aligned[3].points[1].x-aligned[3].points[0].x,.1);assert.equal(objects[0].x,.2);
const distributed=arrangeDrawingObjects(drawing,['a','b','line'],layers,'distribute-x').slice(0,3).map(bounds).sort((a,b)=>a.x-b.x);close(distributed[1].x-distributed[0].x-distributed[0].width,distributed[2].x-distributed[1].x-distributed[1].width);
assert.equal(arrangeDrawingObjects(drawing,['a','b'],layers,'distribute-x'),objects);assert.equal(arrangeDrawingObjects(drawing,['locked','a'],layers,'right'),objects);
assert.deepEqual(snapDrawingPoint({x:.23,y:.42},1000,600,64),{x:.256,y:256/600});assert.deepEqual(snapDrawingPoint({x:1,y:-1},1000,600,64),{x:1,y:0});
assert.equal(moveDrawingObjectsToLayer(objects,['a'],'hidden',layers),objects);assert.equal(moveDrawingObjectsToLayer(objects,['a'],'missing',layers),objects);
const moved=moveDrawingObjectsToLayer(objects,['a','locked'],'front',layers);assert.equal(moved[0].layerId,'front');assert.equal(moved[4],objects[4]);assert.equal(moved[1],objects[1]);
const reordered=reorderDrawingObject(objects,'a','up',layers);assert.deepEqual(reordered.map(o=>o.id),['b','a','line','path','locked']);assert.equal(reorderDrawingObject(objects,'locked','up',layers),objects);

const Editor=loadLocal('../src/MapDrawingEditor.tsx').default;
const map={id:'map',title:'Map',imageId:'image',markers:[],layers,drawing};
const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
let states=[],refs=[],si=0,ri=0,saved;
function nodes(n){if(n&&typeof n.type==='function'&&n.type.name==='DrawingToolRail')return nodes(n.type(n.props));return Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];}
const surface={getBoundingClientRect:()=>({left:0,top:0,width:1000,height:1000}),focus(){},setPointerCapture(){},hasPointerCapture:()=>true,releasePointerCapture(){}};
const event=(x,y,id='',shiftKey=false)=>({clientX:x,clientY:y,pointerId:1,button:0,isPrimary:true,shiftKey,currentTarget:surface,target:{getAttribute:()=>null,closest:()=>id?{getAttribute:()=>id}:null},preventDefault(){}});
try{
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 function render(){si=0;ri=0;return nodes(Editor({map,path:'/book',projectId:'p',onCancel(){},onSave:value=>saved=value}));}
 render();states[3]='image';states[4]=true;refs[1].current=surface;
 const canvas=()=>render().find(n=>n.props?.['aria-label']==='Map drawing canvas');
 const button=text=>render().find(n=>n.type==='button'&&(n.props?.['aria-label']===text||n.props.children===text||n.props.children?.some?.(child=>child===text)));

 const field=id=>render().find(n=>n.props?.id===id),panel=()=>render().find(n=>n.type?.name==='DrawingLayersPanel');
 const choose=(id,additive=false)=>panel().props.onSelectObject(id,additive);
 choose('a');choose('b',true);const before=JSON.stringify(states[0]),history=states[1].length;
 button('Align left').props.onClick();assert.equal(states[1].length,history+1);close(bounds(states[0].objects[0]).x,bounds(states[0].objects[1]).x);
 button('Undo').props.onClick();assert.equal(JSON.stringify(states[0]),before);button('Redo').props.onClick();close(bounds(states[0].objects[0]).x,bounds(states[0].objects[1]).x);button('Undo').props.onClick();
 field('drawing-selection-layer').props.onChange('front');assert(states[0].objects.slice(0,2).every(o=>o.layerId==='front'));button('Undo').props.onClick();assert.equal(JSON.stringify(states[0]),before);
 panel().props.onReorderObject('a','up');assert.equal(states[0].objects[1].id,'a');button('Undo').props.onClick();assert.equal(JSON.stringify(states[0]),before);
 panel().props.onMoveObject('a','front');assert.equal(states[0].objects[0].layerId,'front');button('Undo').props.onClick();
 const svgBefore=drawingSvg(states[0]),oldHistory=states[1].length;field('drawing-grid-size').props.onChange({target:{valueAsNumber:100}});field('drawing-grid-snap').props.onChange({target:{checked:true}});assert(render().some(n=>n.props?.['data-drawing-grid']!==undefined));assert.equal(states[1].length,oldHistory);assert.equal(drawingSvg(states[0]),svgBefore,'Editor grid is absent from exported artwork');
 choose('a');choose('b',true);canvas().props.onPointerDown(event(200,200,'a'));canvas().props.onPointerMove(event(270,260,'a'));canvas().props.onPointerUp(event(270,260,'a'));close(states[0].objects[0].x,.3);close(states[0].objects[1].x-states[0].objects[0].x,.35);assert.equal(states[1].length,oldHistory+1);button('Undo').props.onClick();
 const base=JSON.stringify(states[0]);canvas().props.onPointerDown(event(200,200,'a'));canvas().props.onPointerMove(event(400,300,'a'));canvas().props.onPointerCancel(event(400,300,'a'));assert.equal(JSON.stringify(states[0]),base);
}finally{Object.assign(React,old);}
console.log('Drawing precision: rotated/mixed geometry alignment, equal gaps, layer locks/order/membership, grid-independent exports, snapped group gestures, cancellation and atomic history passed without UI.');
