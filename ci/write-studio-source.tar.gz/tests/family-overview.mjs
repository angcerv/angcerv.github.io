// Pure relationship grouping; no interface is launched or rendered.
import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {familyOverview}=loadLocal('../src/familyOverview.ts');
const relations={schemaVersion:9,types:[{id:'p',genealogy:{kind:'parent',parentRole:'target',lineage:'unknown'}},{id:'couple',genealogy:{kind:'partner'}},{id:'sibling',genealogy:{kind:'sibling'}},{id:'guardian',genealogy:{kind:'guardian',parentRole:'source'}},{id:'legacy',needsRoleReview:true,genealogy:{kind:'parent',parentRole:'source'}}],links:[
 {id:'1',typeId:'p',sourceId:'child',targetId:'mother',start:{year:120}},
 {id:'2',typeId:'p',sourceId:'child',targetId:'father'},
 {id:'3',typeId:'couple',sourceId:'mother',targetId:'father',partnershipStatus:'divorced'},
 {id:'4',typeId:'sibling',sourceId:'child',targetId:'sibling'},
 {id:'5',typeId:'guardian',sourceId:'guardian',targetId:'child'},
 {id:'6',typeId:'legacy',sourceId:'legacy',targetId:'child'},
 {id:'7',typeId:'p',sourceId:'child',targetId:'mother'},
]};
const original=JSON.stringify(relations);
assert.deepEqual(familyOverview(relations,'child'),{parents:['mother','father'],partners:[],children:[]});
assert.deepEqual(familyOverview(relations,'mother'),{parents:[],partners:['father'],children:['child']});
assert.deepEqual(familyOverview(relations,'sibling'),{parents:[],partners:[],children:[]});
assert.deepEqual(familyOverview(relations,'missing'),{parents:[],partners:[],children:[]});
assert.equal(JSON.stringify(relations),original);
console.log('Family overview: explicit inverse roles, unique relatives, dated/former connections, no inferred parents or guardians, immutable data passed.');
