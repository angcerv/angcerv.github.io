import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const {plotChapterTracks}=loadLocal('../src/plotThreads.ts');
const {setLanguage}=loadLocal('../src/i18n.ts');
const Development=loadLocal('../src/PlotDevelopment.tsx').default;
const scene=id=>({id,title:id,content:'Text'});
const project={id:'p',schemaVersion:1,revision:1,title:'Novel',chapters:[{id:'c1',title:'First',scenes:[scene('a'),scene('b'),scene('c')]},{id:'c2',title:'Pause',scenes:[scene('d')]},{id:'empty',title:'Empty',scenes:[]},{id:'c3',title:'Return',scenes:[scene('e'),scene('f')]},{id:'after',title:'After',scenes:[]}]};
const plot={id:'plot',title:'Mystery',color:'violet',status:'active',notes:'Find Thomas',beats:[{sceneId:'f',note:'Resolution'},{sceneId:'b',note:'Clue'},{sceneId:'gone',note:'Preserve'}]},other={...plot,id:'other',title:'Love',color:'rose',beats:[{sceneId:'c',note:'Meet'}]};
const before=JSON.stringify({project,plot,other});
const tracks=plotChapterTracks(project,plot);assert.deepEqual(tracks.map(t=>t.active),[true,true,true,true,false]);assert.deepEqual(tracks.map(t=>t.gap),[false,true,true,false,false]);assert.equal(tracks[0].start,50);assert.equal(tracks[0].end,100);assert.equal(tracks[3].start,0);assert.equal(tracks[3].end,75);assert.deepEqual(tracks[0].slots.map(s=>s.scene.id),['a','b','c']);assert.equal(tracks[0].slots[1].beat.note,'Clue');assert.ok(!tracks.some(t=>t.slots.some(s=>s.scene.id==='gone')));
const one=plotChapterTracks(project,other);assert.equal(one[0].start,one[0].end);assert.ok(one.slice(1).every(t=>!t.active));assert.ok(plotChapterTracks(project,{...plot,beats:[]}).every(t=>!t.active));assert.deepEqual(plotChapterTracks({...project,chapters:[]},plot),[]);
const moved={...project,chapters:[project.chapters[3],project.chapters[1],project.chapters[0]]};assert.equal(plotChapterTracks(moved,plot)[0].slots[1].beat.sceneId,'f');
const require=createRequire(import.meta.url),React=require('react'),oldHooks={useState:React.useState,useRef:React.useRef,useId:React.useId,useEffect:React.useEffect};
let compactState=false,selection=null,refIndex=0,stateIndex=0,effects=[],selected=[],openedPlots=[],opened=[],chapters=[],notes=[],focused=0;
const button={isConnected:true,closest(){return null;},focus(){focused++;}};
const panel={open:false,modal:false,focus(){},show(){this.open=true;this.modal=false;},showModal(){this.open=true;this.modal=true;},close(){this.open=false;},matches(){return this.modal;}};
const refs=[{current:null},{current:button},{current:panel}];
function nodes(n){if(Array.isArray(n))return n.flatMap(nodes);if(!n||typeof n!=='object')return [];return[n,...nodes(n.props?.children)];}
const props={project,plots:[plot,other],selectedId:'plot',onSelect:id=>selected.push(id),onOpenPlot:id=>openedPlots.push(id),onOpenScene:id=>opened.push(id),onOpenChapter:id=>chapters.push(id),onChangeNote:(...args)=>notes.push(args)};
function render(extra={}){refIndex=0;stateIndex=0;effects=[];return nodes(Development({...props,...extra}));}
try{
 React.useState=()=>stateIndex++===0?[selection,value=>{selection=value;}]:[compactState,()=>{}];React.useRef=()=>refs[refIndex++];React.useId=()=> 'development';React.useEffect=fn=>effects.push(fn);
 for(const mode of ['visual','table']){const names=render({mode}).filter(n=>n.type==='button'&&n.props.children&&nodes(n).some(child=>child.props?.className==='plot-color-dot'));names.forEach(n=>n.props.onClick());}
 assert.deepEqual(openedPlots,['plot','other','plot','other','plot','other','plot','other']);assert.deepEqual(selected,[]);
 let all=render();const points=all.filter(n=>n.props?.className==='plot-development-point');assert.equal(points.length,3);assert.deepEqual(points.map(p=>p.props.children),[2,2,3]);assert.ok(points[0].props['aria-label'].includes('Mystery · First · Scene 2: b'));points[0].props.onClick({currentTarget:button});assert.deepEqual(selected,['plot']);assert.deepEqual(selection,{plotId:'plot',chapterId:'c1',sceneId:'b'});
 all=render();assert.ok(all.some(n=>n.props?.id==='development-inspector'));effects[2]();assert.ok(panel.open);assert.equal(panel.modal,false);
 let note=all.find(n=>n.type==='textarea');assert.equal(note.props.value,'Clue');const firstNoteId=note.props.id;note.props.onChange({target:{value:'A new clue'}});assert.deepEqual(notes,[['plot','b','A new clue']]);all.find(n=>n.type==='button'&&n.props?.children?.includes?.('Open scene in manuscript')).props.onClick();assert.deepEqual(opened,['b']);
 all.find(n=>n.props?.className==='plot-development-chapter').props.onClick();assert.deepEqual(chapters,['c1']);
 // Selecting another point reuses the inspector, with a scene-specific reference target.
 all.filter(n=>n.props?.className==='plot-development-point')[1].props.onClick({currentTarget:button});all=render();assert.equal(selection.sceneId,'f');assert.notEqual(all.find(n=>n.type==='textarea').props.id,firstNoteId);
 // Switching to table retains the selected scene. Zero-count cells stay passive.
 all=render({mode:'table'});assert.equal(selection.sceneId,'f');assert.equal(all.find(n=>n.props?.className==='plot-development-scroll').props.hidden,true);const counts=all.filter(n=>n.props?.className==='plot-chapter-present');assert.equal(counts.length,3);assert.ok(all.some(n=>n.type==='td'&&n.props.children.type==='span'));
 counts[0].props.onClick({currentTarget:button});assert.equal(selection.sceneId,'b');
 // Multiple scenes open a chapter list instead of choosing an arbitrary scene.
 const multi={...plot,beats:[...plot.beats,{sceneId:'c',note:'Second clue'}]};all=render({mode:'table',plots:[multi,other]});all.filter(n=>n.props?.className==='plot-chapter-present')[0].props.onClick({currentTarget:button});all=render({mode:'table',plots:[multi,other]});assert.equal(selection.sceneId,null);assert.ok(!all.some(n=>n.type==='textarea'));const list=all.find(n=>n.props?.className==='plot-inspector-scenes');nodes(list).find(n=>n.type==='button').props.onClick();all=render({mode:'table',plots:[multi,other]});assert.equal(all.find(n=>n.type==='textarea').props.value,'Clue');
 // Escape consumed by a reference picker must not close the inspector.
 const workspace=all[0];workspace.props.onKeyDown({key:'Escape',defaultPrevented:true});assert.ok(selection);
 all.find(n=>n.props?.['aria-label']==='Close scene detail').props.onClick();assert.equal(selection,null);assert.equal(focused,1);
 selection={plotId:'plot',chapterId:'c1',sceneId:'b'};all=render({plots:[other]});assert.ok(!all.some(n=>n.type==='textarea'));effects[0]();assert.equal(selection,null);
 selection={plotId:'plot',chapterId:'c1',sceneId:'gone'};all=render();assert.ok(!all.some(n=>n.type==='textarea'));effects[0]();assert.equal(selection,null);
 // Narrow workspace uses the same native inspector as a modal, without losing selection.
 selection={plotId:'plot',chapterId:'c1',sceneId:'b'};compactState=true;all=render();effects[2]();assert.equal(panel.modal,true);compactState=false;all=render();effects[2]();assert.equal(panel.modal,false);
 // Leaving Development closes the native panel but keeps its selection.
 selection={plotId:'plot',chapterId:'c1',sceneId:'b'};all=render({active:false});effects[2]();assert.equal(panel.open,false);assert.equal(selection.sceneId,'b');
}finally{Object.assign(React,oldHooks);}
setLanguage('es');const html=renderToStaticMarkup(createElement(Development,props));assert.ok(html.includes('Desarrollo visual de tramas'));assert.ok(html.includes('Pausa entre apariciones'));assert.ok(html.includes('Capítulo 1'));assert.ok(html.includes('aria-label="Mystery · First · Escena 2: b"'));setLanguage('en');assert.equal(JSON.stringify({project,plot,other}),before);
console.log('Visual plots: chapter/scene alignment, colored spans and intentional pauses, empty/deleted/reordered scenes, point inspection/editing, manuscript/chapter navigation, focus restoration and Spanish labels passed.');
