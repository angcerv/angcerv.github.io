import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect,useLayoutEffect:React.useLayoutEffect,useId:React.useId},previousWindow=globalThis.window,previousDocument=globalThis.document;
const Options=loadLocal('../src/RelationshipOptions.tsx').default,Dialog=loadLocal('../src/RelationDialog.tsx').default,{EntryRelationDialog}=loadLocal('../src/RelationshipLibrary.tsx'),P=loadLocal('../src/relationshipPresets.ts');
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
const text=n=>Array.isArray(n)?n.map(text).join(''):typeof n==='string'?n:n?.props?text(n.props.children):'';
let states=[],refs=[],effects=[],si=0,ri=0;
function reset(){states=[];refs=[];effects=[];}
function render(Component,props){si=0;ri=0;effects=[];return Component(props);}
try{
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],next=>states[i]=typeof next==='function'?next(states[i]):next];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useId=()=> 'options-test';React.useEffect=()=>{};React.useLayoutEffect=fn=>effects.push(fn);
 globalThis.document={body:{nodeType:1}};
 for(const iconOnly of [false,true])for(const width of [360,800,1400])for(const side of ['left','right']){
  reset();globalThis.window={innerWidth:width,innerHeight:600,addEventListener(){},removeEventListener(){}};
  const rect={left:side==='left'?16:width-180,right:side==='left'?180:width-16,top:480,bottom:516};let restored=false;
  let tree=render(Options,{label:'Generations and options',children:'Controls',iconOnly});const trigger=nodes(tree).find(n=>n.type==='button');assert.equal(trigger.props['aria-label'],'Generations and options');if(iconOnly)assert.equal(text(trigger),'');refs[0].current={getBoundingClientRect:()=>rect,closest:()=>null,focus(){restored=true;}};
  nodes(tree).find(n=>n.type==='button').props.onClick();tree=render(Options,{label:'Generations and options',children:'Controls',iconOnly});effects[0]();tree=render(Options,{label:'Generations and options',children:'Controls',iconOnly});
  const portal=tree.props.children.find(child=>child?.containerInfo),style=portal.children.props.style;assert.equal(style.position,'fixed');assert(style.left>=12);assert(style.left+style.width<=width-12);assert(style.maxHeight<=600-24);assert(style.bottom>=12,'Near-bottom controls open upwards');
  assert.equal(portal.containerInfo,globalThis.document.body);assert.equal(portal.children.props.role,'dialog');tree.props.onKeyDown({key:'Escape',preventDefault(){},stopPropagation(){}});assert(restored);assert.equal(nodes(render(Options,{label:'Generations and options',children:'Controls',iconOnly})).find(n=>n.type==='button').props['aria-expanded'],false);
 }
 reset();let materialFocus=false;const materialProps={label:'Choose material',triggerContent:'Grass',closeOnSelect:true,children:'Material choices'};
 let materialTree=render(Options,materialProps);assert(text(nodes(materialTree).find(n=>n.type==='button')).includes('Grass'));
 refs[0].current={getBoundingClientRect:()=>({left:100,right:240,top:40,bottom:72}),closest:()=>null,focus(){materialFocus=true;}};
 nodes(materialTree).find(n=>n.type==='button').props.onClick();render(Options,materialProps);effects[0]();materialTree=render(Options,materialProps);
 const materialPopup=materialTree.props.children.find(n=>n?.containerInfo).children;materialPopup.props.onClick({target:{closest:()=>null}});assert(nodes(render(Options,materialProps)).find(n=>n.type==='button').props['aria-expanded']);
 materialPopup.props.onClick({target:{closest:()=>({})}});assert(materialFocus);assert.equal(nodes(render(Options,materialProps)).find(n=>n.type==='button').props['aria-expanded'],false);
 delete globalThis.document;reset();React.useLayoutEffect=()=>{};const draft=React.createElement('textarea',{defaultValue:'Pending user input'}),dialogProps={title:'New relationship type',dirty:true,onClose(){},children:draft};let tree=render(Dialog,dialogProps);nodes(tree).find(n=>n.type==='dialog').props.onCancel({preventDefault(){}});tree=render(Dialog,dialogProps);assert(tree.props.className.includes('is-confirming-discard'));assert.equal(nodes(tree).find(n=>n.props?.className==='field-create-body').props.children,draft,'Compact confirmation keeps the draft mounted');assert.equal(nodes(tree).find(n=>n.type==='h2').props.children,'Discard unsaved changes?');nodes(tree).find(n=>n.type==='button'&&text(n)==='Continue editing').props.onClick();assert(!render(Dialog,dialogProps).props.className.includes('is-confirming-discard'));
 reset();let saved;const props={world:{schemaVersion:1,templates:[],entries:[]},relations:{schemaVersion:2,types:[],links:[]},preset:'romantic-interest',onSave:value=>saved=value,onCancel(){}};tree=render(EntryRelationDialog,props);let all=nodes(tree),meaning=all.find(n=>n.props?.id==='relationship-meaning');assert.equal(meaning.props.value,'');assert.equal(meaning.props.options[0].label,'No genealogical relationship (network only)');assert(text(all).includes('It does not imply a couple'));all.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.equal(saved.genealogy,undefined);assert.equal(saved.symmetric,false);
 for(const preset of ['guardian','partner','former-partner','step-parent'])assert(P.relationshipPreset(preset).genealogy);assert.equal(P.relationshipPreset('romantic-interest').genealogy,undefined);
}finally{Object.assign(React,old);if(previousWindow===undefined)delete globalThis.window;else globalThis.window=previousWindow;if(previousDocument===undefined)delete globalThis.document;else globalThis.document=previousDocument;}
console.log('Relationship popovers: left/right viewport bounds at three widths, upward placement, portal/Escape, compact discard preserving drafts, and explicit network-only romantic model passed.');
