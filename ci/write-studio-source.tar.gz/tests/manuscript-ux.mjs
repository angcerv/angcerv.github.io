import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const require=createRequire(import.meta.url),React=require('react');
const Navigation=loadLocal('../src/ManuscriptNavigation.tsx').default;
const Goals=loadLocal('../src/WritingGoalsDialog.tsx').default;
const Tools=loadLocal('../src/ManuscriptTools.tsx').default;
const original={useState:React.useState,useEffect:React.useEffect,useRef:React.useRef,useContext:React.useContext};
let states=[],index=0,effects=[];
const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
const scene={id:'s',title:'Arrival',content:'one two'},chapter={id:'c',title:'Opening',scenes:[scene]};
const noop=()=>{};
try{
 React.useState=initial=>{const i=index++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};
 React.useEffect=effect=>effects.push(effect);React.useRef=()=>({current:null});React.useContext=()=>null;
 const render=(Component,props)=>{index=0;effects=[];return nodes(Component(props));};
 const navProps={chapters:[chapter],selectedId:'',onChapter:noop,onScene:noop,onSceneTools:noop,onAddScene:noop};
 const emptyNav=render(Navigation,{...navProps,chapters:[]});assert(emptyNav.some(n=>n.props?.className==='navigation-empty'&&n.props.children==='No chapters yet.'));assert(!emptyNav.some(n=>n.props?.children==='No matching chapters or scenes.'));
 const Empty=loadLocal('../src/ManuscriptEmptyState.tsx').default;let added=0;const empty=nodes(Empty({onAddChapter:()=>added++}));assert(empty[0].props.className.includes('ui-empty-state'));assert(empty.some(n=>n.type==='h2'&&n.props.children==='Add your first chapter.'));empty.find(n=>n.type==='button').props.onClick();assert.equal(added,1);assert(nodes(Empty({hasChapters:true,onAddChapter:noop})).some(n=>n.type==='h2'&&n.props.children==='Choose a chapter'));
 let tree=render(Navigation,navProps);
 tree.find(n=>n.props?.className==='chapter-toggle').props.onClick();
 tree=render(Navigation,navProps);assert.equal(tree.find(n=>n.props?.id==='chapter-scenes-c').props.hidden,true);
 tree.find(n=>n.props?.id==='manuscript-search').props.onChange({target:{value:'arríval'}});
 tree=render(Navigation,navProps);assert.equal(tree.find(n=>n.props?.id==='chapter-scenes-c').props.hidden,false);
 tree.find(n=>n.props?.className==='chapter-toggle').props.onClick();tree=render(Navigation,navProps);assert.equal(tree.find(n=>n.props?.id==='chapter-scenes-c').props.hidden,true,'Search results can still be collapsed');
 tree.find(n=>n.props?.id==='manuscript-search').props.onChange({target:{value:''}});
 tree=render(Navigation,navProps);assert.equal(tree.find(n=>n.props?.id==='chapter-scenes-c').props.hidden,true,'Clearing search restores collapsed chapters');
 states=[];let closed=0,saved;
 let goals={schemaVersion:1,sessions:[],sessionTarget:50};
 const goalProps=()=>({goals,words:100,onChange:value=>{saved=value;goals=value;},onClose:()=>closed++});
 tree=render(Goals,goalProps());tree.find(n=>n.props?.id==='project-word-goal').props.onChange({target:{value:'500'}});
 tree=render(Goals,goalProps());tree.find(n=>n.props?.['aria-label']==='Close writing goals').props.onClick();
 assert.equal(closed,0);tree=render(Goals,goalProps());const confirmation=tree.find(n=>n.type?.name==='ProjectModal');assert(confirmation);
 confirmation.props.onClose();tree=render(Goals,goalProps());assert(!tree.some(n=>n.type?.name==='ProjectModal'));
 tree.find(n=>n.type==='button'&&n.props.children?.[1]==='Start session').props.onClick();assert.equal(saved.projectTarget,500);assert(saved.activeSession);assert.equal(closed,1);
 // Ending a session applies goal edits instead of silently dropping them.
 states=[];tree=render(Goals,goalProps());tree.find(n=>n.props?.id==='project-word-goal').props.onChange({target:{value:'600'}});
 tree=render(Goals,goalProps());tree.find(n=>n.type==='button'&&n.props.children?.[1]==='End session').props.onClick();assert.equal(saved.projectTarget,600);assert.equal(saved.activeSession,undefined);assert.equal(saved.sessions.length,1);
 // Clearing a future session goal can finish the active session without losing its recorded target.
 states=[];goals={schemaVersion:1,sessions:[],sessionTarget:50,activeSession:{id:'active',startedAt:1000,startWords:80,targetWords:50}};
 tree=render(Goals,goalProps());tree.find(n=>n.props?.id==='session-word-goal').props.onChange({target:{value:''}});
 tree=render(Goals,goalProps());tree.find(n=>n.type==='button'&&n.props.children?.[1]==='End session').props.onClick();assert.equal(saved.sessionTarget,undefined);assert.equal(saved.sessions[0].targetWords,50);
 // Grouping retains reordering/transfer/delete callbacks and disabled boundaries.
 states=[];let moved;
 tree=render(Tools,{chapter,scene,chapters:[chapter,{id:'other',title:'Next',scenes:[]}],onClose:noop,onWritingStatus:noop,onSceneSynopsis:noop,onChapterSynopsis:noop,onChapterTitle:noop,onMoveToChapter:id=>moved=id,onMoveChapter:noop,onMoveScene:noop,onDelete:noop});
 const organization=tree.find(n=>n.type?.name==='EntrySection'&&n.props.title==='Organize scene');assert.equal(organization.props.defaultOpen,false);
 assert(!nodes(organization.props.children).some(n=>n.props?.className==='manuscript-delete'),'Deletion must not be hidden inside organization');
 assert.equal(tree.find(n=>n.props?.['aria-label']==='Move scene up').props.disabled,true);
 tree.find(n=>n.props?.id==='scene-chapter').props.onChange('other');assert.equal(moved,'other');
 assert(!tree.some(n=>n.props?.className==='manuscript-delete'));
 states=[];let deleted;tree=render(Navigation,{...navProps,onDeleteScene:id=>deleted=id});const menu=tree.find(n=>n.props?.label==='Options for scene Arrival');assert(menu);const deletion=menu.props.actions.find(action=>action.label==='Delete scene');assert.equal(deletion.danger,true);deletion.onClick();assert.equal(deleted,'s');
}finally{Object.assign(React,original);}
console.log('Manuscript UX: accent search preserves collapse state, goal close protects drafts, session lifecycle retains edits, grouped organization keeps transfer/deletion and boundaries passed without UI.');
