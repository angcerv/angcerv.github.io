import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {Schema} from '@tiptap/pm/model';
import {loadLocal} from './load-local.mjs';
const {entryAppearances}=loadLocal('../src/entryAppearanceIndex.ts');
const {fromMarkdown}=loadLocal('../src/model.ts');
const {setLanguage}=loadLocal('../src/i18n.ts');
const Component=loadLocal('../src/EntryAppearances.tsx').default;
const world={schemaVersion:8,templates:[{schemaVersion:8,id:'t',title:'People',fields:[]}],entries:[{schemaVersion:8,id:'e',title:'Isabel',templateId:'t',archived:false,values:{},linkAliases:['Isa']},{schemaVersion:8,id:'other',title:'Other',templateId:'t',archived:false,values:{},linkAliases:['Isa']}]};
const chapters=[{id:'c1',title:'Opening',scenes:[{id:'s1',title:'Arrival',content:'**Isabel** y Isabel.',entryIds:['e']},{id:'s2',title:'Offstage',content:'Nadie aparece.',entryIds:['e']},{id:'s3',title:'Uncertain',content:'Isa',entryIds:[]}]},{id:'c2',title:'Later',scenes:[{id:'s4',title:'Choice',content:'Isa e Isabel.',resolvedMentions:[{from:1,to:4,text:'Isa',entryId:'e'}],ignoredMentions:[{from:7,to:13,text:'Isabel'}]},{id:'s5',title:'Unrelated',content:'Other'}]},{id:'c3',title:'Empty',scenes:[]}];
const original=JSON.stringify({chapters,world});
const index=entryAppearances(chapters,world,'e');
assert.equal(index.chapterCount,2);assert.equal(index.sceneCount,3);assert.equal(index.mentionCount,3);
assert.deepEqual(index.groups.map(g=>g.chapter.id),['c1','c2']);assert.deepEqual(index.groups[0].scenes.map(s=>s.scene.id),['s1','s2']);
assert.equal(index.groups[0].scenes[0].manual,true);assert.equal(index.groups[0].scenes[0].mentions.length,2);assert.equal(index.groups[0].scenes[1].mentions.length,0);
assert.equal(index.groups[1].scenes[0].mentions[0].resolved,true);
assert.equal(JSON.stringify({chapters,world}),original);
const edited=[{...chapters[0],scenes:[{...chapters[0].scenes[0],content:'Other',entryIds:[]},...chapters[0].scenes.slice(1)]},...chapters.slice(1)];
assert.equal(entryAppearances(edited,world,'e').mentionCount,1);
const archived={...world,entries:world.entries.map(entry=>entry.id==='e'?{...entry,archived:true}:entry)};
assert.equal(entryAppearances(chapters,archived,'e').mentionCount,1);

assert.equal(entryAppearances(chapters,world,'other').mentionCount,1);
const html=renderToStaticMarkup(createElement(Component,{chapters,world,entryId:'e',onOpenScene:()=>{},onOpenMention:()=>{}}));
assert.ok(html.includes('2 chapters · 3 scenes · 3 text mentions'));assert.ok(html.includes('Manual link'));assert.ok(html.includes('Linked manually · no text mentions'));assert.ok(html.includes('Opening'));assert.ok(html.includes('Later'));assert.ok(!html.includes('Uncertain'));assert.ok(!html.includes('Empty'));
setLanguage('es');const es=renderToStaticMarkup(createElement(Component,{chapters:[],world,entryId:'e'}));assert.ok(es.includes('Apariciones en el manuscrito'));assert.ok(es.includes('Todavía no hay apariciones'));setLanguage('en');
// The exact destination ranges emitted by the UI select the right text even across formatting.
const require=createRequire(import.meta.url),React=require('react'),saved={useId:React.useId,useMemo:React.useMemo,useContext:React.useContext,useState:React.useState};
React.useId=()=> 'test-appearances';React.useMemo=fn=>fn();React.useContext=()=>null;React.useState=value=>[value,()=>{}];
let tree,opened=[],mentions=[];
try{tree=Component({chapters,world,entryId:'e',onOpenScene:id=>opened.push(id),onOpenMention:(id,range)=>mentions.push({id,range})});}finally{Object.assign(React,saved);}
function nodes(node){if(Array.isArray(node))return node.flatMap(nodes);if(!node||typeof node!=='object')return [];return [node,...nodes(node.props?.children)];}
const all=nodes(tree);
all.find(n=>n.props?.['aria-label']==='Go to mention 2 of 2 in Arrival').props.onClick();
all.find(n=>n.props?.['aria-label']==='Go to mention 1 of 1 in Choice').props.onClick();
all.filter(n=>n.props?.className==='entry-appearance-scene-heading')[1].props.children[0].props.onClick();
assert.deepEqual(opened,['s2']);assert.deepEqual(mentions.map(m=>m.id),['s1','s4']);
const schema=new Schema({nodes:{doc:{content:'paragraph+'},paragraph:{content:'text*'},text:{}},marks:{bold:{},italic:{}}});
for(const {id,range} of mentions){const scene=chapters.flatMap(c=>c.scenes).find(s=>s.id===id),doc=schema.nodeFromJSON(fromMarkdown(scene.content));assert.ok(['Isabel','Isa'].includes(doc.textBetween(range.from,range.to)));}
const Editor=loadLocal('../src/WorldbuildingEditor.tsx').default;
const edit=renderToStaticMarkup(createElement(Editor,{world,chapters,entryId:'e',tab:'entries',onChange:()=>{},onReturn:()=>{},setTab:()=>{},setEntryId:()=>{},onOpenMention:()=>{}}));assert.ok(edit.includes('Manuscript appearances'));assert.ok(edit.includes('3 text mentions'));
const Panel=loadLocal('../src/WorldPanel.tsx').default;
const panel=renderToStaticMarkup(createElement(Panel,{world,chapters,entryId:'e',onSelectEntry:()=>{},onOpenEditor:()=>{},onClose:()=>{}}));assert.ok(panel.includes('Manuscript appearances'));assert.ok(panel.includes('3 text mentions'));
console.log('Entry appearances: grouped manuscript order, manual/text deduplication, counts, ambiguity/exclusion/resolution, bilingual empty state, exact navigation ranges and both entry views passed.');
