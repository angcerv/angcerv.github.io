import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const N=loadLocal('../src/workspaceNavigation.ts'),{workspaceVisitLabel}=loadLocal('../src/workspaceVisitLabel.ts');
const React=createRequire(import.meta.url)('react'),Network=loadLocal('../src/RelationNetwork.tsx').default,Genealogy=loadLocal('../src/Genealogy.tsx').default;
const layout=loadLocal('../src/genealogyLayout.ts'),originalLayout=layout.genealogyGraph;
const old={useState:React.useState,useMemo:React.useMemo,useRef:React.useRef,useEffect:React.useEffect};
const [a,b,templateId,typeId,linkId]=Array.from({length:5},()=>crypto.randomUUID());
const world={schemaVersion:11,templates:[{schemaVersion:1,id:templateId,title:'PRIVATE template',fields:[]}],entries:[a,b].map((id,index)=>({schemaVersion:11,id,templateId,title:`PRIVATE person ${index}`,values:{},archived:false}))};
const relations={schemaVersion:4,types:[{id:typeId,name:'PRIVATE family',title:'Parent',inverseTitle:'Child',symmetric:false,sourceTemplateIds:[templateId],targetTemplateIds:[templateId],genealogy:{kind:'parent',parentRole:'source',lineage:'biological'}}],links:[{id:linkId,typeId,sourceId:a,targetId:b}]};
const before=JSON.stringify({world,relations}),memory={values:{}};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[],text=n=>Array.isArray(n)?n.map(text).join(''):typeof n==='string'?n:n?.props?text(n.props.children):'';
let states=[],refs=[],memos=[],stateIndex=0,refIndex=0,memoIndex=0,layouts=0;
const reset=()=>{states=[];refs=[];memos=[];};
const render=(Component,props)=>{stateIndex=0;refIndex=0;memoIndex=0;return nodes(Component(props));};
N.activateWorkspaceMemory(memory);
try{
 React.useState=initial=>{const at=stateIndex++;if(!(at in states))states[at]=typeof initial==='function'?initial():initial;return[states[at],next=>states[at]=typeof next==='function'?next(states[at]):next];};
 React.useMemo=(fn,deps)=>{const at=memoIndex++,previous=memos[at];if(!previous||deps.some((value,index)=>value!==previous.deps[index]))memos[at]={deps,value:fn()};return memos[at].value;};
 React.useRef=value=>{const at=refIndex++;return refs[at]??(refs[at]={current:value});};React.useEffect=()=>{};
 layout.genealogyGraph=(...args)=>{layouts++;return originalLayout(...args);};
 const props={world,relations,chapters:[],initialFocusId:a,onChange(){},onWorldChange(){},onOpenEntry(){},onManage(){}};
 let tree=render(Network,props);tree.find(n=>n.props.id==='relationship-template-filter').props.onChange(templateId);tree=render(Network,props);tree.find(n=>n.props['aria-label']==='Zoom in').props.onClick();tree=render(Network,props);tree.find(n=>n.props['data-graph-entry']===b).props.onClick();tree=render(Network,props);
 const transform=tree.find(n=>n.type==='svg').props.children.props.transform,snapshot=N.cloneWorkspaceMemory(memory);assert(tree.some(n=>n.props?.id==='relationship-view-dirty'&&n.props.title==='Modified temporary exploration')); 
 reset();tree=render(Network,props);assert.equal(tree.find(n=>n.props.id==='relationship-template-filter').props.value,templateId);assert.equal(tree.find(n=>n.type==='svg').props.children.props.transform,transform);assert(tree.find(n=>n.props['data-graph-entry']===b).props.className.includes('is-selected'));assert(tree.some(n=>n.props?.id==='relationship-view-dirty'&&n.props.title==='Modified temporary exploration'),'Returning must retain the original exploration baseline');
 // Modal names are drafts, not navigation memory.
 tree.find(n=>n.type?.name==='ActionMenu').props.actions.find(a=>a.label==='Save as new view').onClick();tree=render(Network,props);tree.find(n=>n.props.id==='relationship-view-name').props.onChange({target:{value:'PRIVATE_DRAFT'}});render(Network,props);assert(!JSON.stringify(N.cloneWorkspaceMemory(memory)).includes('PRIVATE'));
 reset();tree=render(Network,props);assert(!tree.some(n=>n.props.id==='relationship-view-name'));
 // Focusing on a different entry has a separate exploration; back restores this one.
 reset();tree=render(Network,{...props,initialFocusId:b});assert.equal(tree.find(n=>n.props.id==='relationship-template-filter').props.value,'');N.restoreWorkspaceMemory(memory,snapshot);reset();tree=render(Network,props);assert.equal(tree.find(n=>n.type==='svg').props.children.props.transform,transform);
 reset();tree=render(Genealogy,props);const initialLayouts=layouts;tree.find(n=>n.props['data-graph-entry']===b).props.onClick();tree=render(Genealogy,props);assert.equal(layouts,initialLayouts,'Selecting an entry must not recalculate genealogical layout');tree.find(n=>n.props['aria-label']==='Zoom in').props.onClick();tree=render(Genealogy,props);const familyTransform=tree.find(n=>n.type==='svg').props.children.props.transform;
 const familySnapshot=N.cloneWorkspaceMemory(memory);reset();tree=render(Genealogy,props);assert.equal(tree.find(n=>n.type==='svg').props.children.props.transform,familyTransform);assert(tree.find(n=>n.props['data-graph-entry']===b).props.className.includes('is-selected'));assert.equal(tree.find(n=>n.type==='aside').props.hidden,false);
 const renamed={...world,entries:world.entries.map(entry=>({...entry,title:'Latest title '+entry.id}))};N.restoreWorkspaceMemory(memory,familySnapshot);reset();tree=render(Genealogy,{...props,world:renamed});assert(tree.find(n=>n.props['data-graph-entry']===b).props['aria-label'].includes('Latest title'));assert(!JSON.stringify(memory.values).includes('Latest title'));assert.equal(JSON.stringify({world,relations}),before);
}finally{Object.assign(React,old);layout.genealogyGraph=originalLayout;N.activateWorkspaceMemory(undefined);}
const base={view:'worldbuilding',worldSection:'entries',worldEntryId:a},graph={...base,worldPane:'network',worldFocusId:a},entry={...base,worldPane:'entries'},project={worldbuilding:world,chapters:[]};
assert.notEqual(N.workspaceRouteKey(graph),N.workspaceRouteKey(entry));assert.notEqual(N.workspaceRouteKey(graph),N.workspaceRouteKey({...graph,worldPane:'genealogy'}));assert.notEqual(N.workspaceRouteKey(entry),N.workspaceRouteKey({...entry,worldPane:'reading'}));
assert.equal(workspaceVisitLabel(project,graph),'Relationship network');assert.equal(workspaceVisitLabel(project,{...graph,worldPane:'resources'}),'Visual resources');assert(N.workspaceRouteExists(project,{...graph,worldEntryId:'deleted'}),'An unrelated deleted entry must not invalidate a graph visit');
assert.equal(N.worldWorkspacePane({'world.relationsOpen':true,'world.relationSection':'genealogy'},'entries'),'genealogy');assert.equal(N.worldWorkspacePane({'world.relationsOpen':true,'world.relationSection':'types'},'entries'),'relationshipTypes');assert.equal(N.worldWorkspacePane({'world.resourcesOpen':true},'entries'),'resources');assert.equal(N.worldWorkspacePane({'world.reading':true},'templates'),'templates');
const graphVisit={route:graph,memory:{'world.relationsOpen':true},position:{scroll:[],details:[]}},entryVisit={...graphVisit,route:entry,memory:{'world.relationsOpen':false}};
const backward=N.stepWorkspaceHistory(N.recordWorkspaceVisit(N.emptyWorkspaceHistory(),graphVisit),entryVisit,'back',project);assert.equal(backward.visit,graphVisit);assert.equal(backward.visit.memory['world.relationsOpen'],true);
// A large synthetic manuscript and SVG must cost only container measurements.
const oldDOM={HTMLElement:globalThis.HTMLElement,HTMLDetailsElement:globalThis.HTMLDetailsElement,HTMLInputElement:globalThis.HTMLInputElement,HTMLTextAreaElement:globalThis.HTMLTextAreaElement};let measurements=0,geometryReads=0;
class Element{
 constructor(tag,id='',flags={}){this.tagName=tag;this.id=id;this.children=[];this.flags=flags;this.scrollTop=0;this.scrollLeft=0;this.clientHeight=100;this.clientWidth=100;}
 get scrollHeight(){measurements++;return 500;}get scrollWidth(){return 100;}
 append(child){this.children.push(child);child.parentElement=this;child.ownerDocument=this.ownerDocument;}
 matches(selector){return selector==='[contenteditable=true]'?!!this.flags.editable:!!(this.flags.hidden||this.flags.inert);}
 contains(node){return node===this||this.children.some(child=>child.contains?.(node));}
 querySelectorAll(selector){return this.children.flatMap(child=>child instanceof Element?[...(selector==='details'&&child instanceof Details?[child]:[]),...child.querySelectorAll(selector)]:[]);}
 closest(){return null;}
 focus(){this.focused=true;}
}
class Details extends Element{open=false;}class Input extends Element{}
try{
 Object.assign(globalThis,{HTMLElement:Element,HTMLDetailsElement:Details,HTMLInputElement:Input,HTMLTextAreaElement:Input});
 const root=new Element('SECTION','workspace'),editor=new Element('DIV','editor',{editable:true}),closed=new Details('DETAILS','closed'),hidden=new Element('DIV','hidden',{hidden:true}),scroller=new Element('DIV','scroll');root.ownerDocument={activeElement:null,getElementById:id=>id==='scroll'?scroller:undefined};root.append(editor);root.append(closed);root.append(hidden);root.append(scroller);
 editor.children=Array.from({length:10000},()=>new Element('P'));hidden.children=Array.from({length:5000},()=>new Element('DIV'));
 const nested=new Details('DETAILS','nested');nested.open=true;closed.append(nested);
 const svg={tagName:'svg',get children(){geometryReads++;throw Error('SVG geometry must not be traversed');}};root.append(svg);scroller.scrollTop=230;
 const position=N.captureWorkspacePosition(root);assert(measurements<=5);assert.equal(geometryReads,0);assert(position.details.some(item=>item.element.id==='closed'&&!item.open));assert(position.details.some(item=>item.element.id==='nested'&&item.open));assert.equal(position.scroll.find(item=>item.element.id==='scroll').top,230);
 assert.equal(N.locateElement(root,{id:'removed',path:[4],tag:'DIV'}),undefined,'A removed named control must not resolve to a different element at its old path');
}finally{for(const [key,value]of Object.entries(oldDOM)){if(value===undefined)delete globalThis[key];else globalThis[key]=value;}}
console.log('Navigation consolidation: graph/genealogy remounts, live content, draft exclusion, exploration baselines, pane history, memoized selection and bounded capture across 15,000 hidden/editor nodes and SVG passed.');
