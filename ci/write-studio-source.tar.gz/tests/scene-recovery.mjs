import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const {recoverScene}=loadLocal('../src/sceneRecovery.ts');
const {setLanguage}=loadLocal('../src/i18n.ts');
const old={id:'b',title:'Original scene',content:'Old text',synopsis:'Old notes',writingStatus:'draft',entryIds:['kept','deleted'],ignoredMentions:[{from:0,to:3,text:'Old'}],resolvedMentions:[{from:0,to:3,text:'Old',entryId:'kept'},{from:4,to:8,text:'text',entryId:'deleted'}]};
const source={schemaVersion:1,id:'project',revision:1,title:'Novel',chapters:[{id:'c',title:'Original chapter',synopsis:'Chapter synopsis',scenes:[{id:'a',title:'A',content:'a'},old,{id:'d',title:'D',content:'d'}]}]};
const current=structuredClone(source);current.revision=9;current.chapters[0].scenes[1]={...old,title:'New title',content:'Current text',synopsis:'New notes',writingStatus:'finished',entryIds:['manual'],ignoredMentions:[],resolvedMentions:[]};current.worldbuilding={schemaVersion:9,templates:[],entries:[{id:'kept'}]};current.maps={schemaVersion:1,maps:[]};current.timeline={schemaVersion:1,events:[]};
const baseline=JSON.stringify(current),history=JSON.stringify(source);
const request={source,sceneId:'b',mode:'text',chapterId:'c'};
const restored=recoverScene(current,request);const text=restored.project.chapters[0].scenes[1];
assert.equal(text.content,'Old text');assert.equal(text.title,'New title');assert.equal(text.synopsis,'New notes');assert.equal(text.writingStatus,'finished');assert.deepEqual(text.entryIds,['manual']);assert.equal(text.resolvedMentions.length,1);assert.equal(text.ignoredMentions.length,1);assert.equal(restored.project.chapters[0].scenes[0],current.chapters[0].scenes[0]);assert.equal(restored.project.maps,current.maps);assert.equal(restored.project.timeline,current.timeline);assert.equal(restored.project.worldbuilding,current.worldbuilding);
const copied=recoverScene(current,{...request,mode:'copy'});assert.notEqual(copied.sceneId,'b');assert.equal(copied.project.chapters[0].scenes[2].id,copied.sceneId);assert.deepEqual(copied.project.chapters[0].scenes[2].entryIds,['kept']);copied.project.chapters[0].scenes[2].ignoredMentions[0].text='Changed';assert.equal(old.ignoredMentions[0].text,'Old');const second=recoverScene(copied.project,{...request,mode:'copy'});assert.notEqual(second.project.chapters[0].scenes[2].title,copied.project.chapters[0].scenes[2].title);
const deleted=structuredClone(current);deleted.chapters[0].scenes.splice(1,1);const recovered=recoverScene(deleted,{...request,mode:'deleted'});assert.deepEqual(recovered.project.chapters[0].scenes.map(s=>s.id),['a','b','d']);assert.equal(recovered.sceneId,'b');
const noChapter={...current,chapters:[]};const recreated=recoverScene(noChapter,{...request,mode:'deleted',chapterId:'original'});assert.equal(recreated.project.chapters[0].id,'c');assert.equal(recreated.project.chapters[0].scenes.length,1);assert.equal(recreated.project.chapters[0].synopsis,'Chapter synopsis');
const other={...deleted,chapters:[...deleted.chapters,{id:'other',title:'Other',scenes:[]}]};assert.equal(recoverScene(other,{...request,mode:'deleted',chapterId:'other'}).project.chapters[1].scenes[0].id,'b');
assert.throws(()=>recoverScene(current,{...request,mode:'deleted'}));assert.throws(()=>recoverScene(deleted,request));assert.throws(()=>recoverScene(current,{...request,source:{...source,id:'foreign'}}));assert.throws(()=>recoverScene(current,{...request,mode:'copy',chapterId:'missing'}));assert.equal(JSON.stringify(current),baseline);assert.equal(JSON.stringify(source),history);
// Exercise the actual App workflow: safety checkpoint must finish before any recovery save.
const app=readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8');
const fn=app.slice(app.indexOf('  async function recoverHistoricalScene('),app.indexOf('  async function restoreHistoricalVersion('));
const compiled=ts.transpileModule(fn,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.None}}).outputText;
const events=[],state={current:{project:current,path:'/saved',dirty:true}};let safetyFails=false;
const context={state,recoverScene,t:(text,...args)=>text.replace('{0}',args[0]??''),async createRevisionCheckpoint(){events.push('safety');if(safetyFails)throw Error('Safety failed');state.current.project={...state.current.project,revision:10};},async run(work){try{return await work();}catch{return undefined;}},async saveProject(path,project){events.push('save');assert.equal(path,'/saved');assert.equal(project.revision,10);return{...project,revision:11};},setProject(){events.push('apply');},setDirty(){},setAutosaveError(){},setSession(){},async clearDraft(){},remember(){},setHistoryOpen(){},goToScene(id){events.push(id);}};
const workflow=new Function('context',`const {${Object.keys(context).join(',')}}=context;${compiled};return recoverHistoricalScene;`)(context);
await workflow(request);assert.deepEqual(events,['safety','save','apply','b']);assert.equal(state.current.project.chapters[0].scenes[1].content,'Old text');events.length=0;safetyFails=true;await assert.rejects(workflow(request));assert.deepEqual(events,['safety']);
// Confirm/retry interactions and bilingual actions.
const Actions=loadLocal('../src/SceneRecoveryActions.tsx').default;
const require=createRequire(import.meta.url),React=require('react'),savedHooks={useState:React.useState,useId:React.useId};
let hooks=[null,'',false,''],index=0,calls=[];
function nodes(n){if(Array.isArray(n))return n.flatMap(nodes);if(!n||typeof n!=='object')return [];return[n,...nodes(n.props?.children)];}
const props={source,scene:old,current,disabled:false,async onRecover(value){calls.push(value);throw Error('Retry');}};
function render(){index=0;return nodes(Actions(props));}
try{React.useId=()=> 'destination';React.useState=()=>{const i=index++;return[hooks[i],v=>{hooks[i]=v;}];};let all=render();all.find(n=>n.type==='button'&&n.props.children==='Recover as a copy').props.onClick();all=render();assert.ok(all.some(n=>n.props?.children==='A named safety checkpoint of the current project will be saved before recovering this scene.'));all.find(n=>n.type==='button'&&n.props.children==='Confirm scene recovery').props.onClick();await new Promise(r=>setImmediate(r));assert.equal(calls[0].mode,'copy');assert.equal(hooks[0],'copy');assert.equal(hooks[2],false);assert.ok(hooks[3].includes('Retry'));}finally{Object.assign(React,savedHooks);}
setLanguage('es');const html=renderToStaticMarkup(createElement(Actions,props));assert.ok(html.includes('Restaurar el texto de esta escena'));assert.ok(html.includes('Recuperar como copia'));setLanguage('en');
console.log('Scene recovery: text-only restoration, independent copies, deleted scenes and chapters, live-link filtering, destination/order, safety-before-save workflow, failed checkpoint protection, retry controls and Spanish UI passed.');
