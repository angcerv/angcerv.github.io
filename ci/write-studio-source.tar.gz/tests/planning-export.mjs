import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const {planningMarkdown,planningFilename}=loadLocal('../src/planningExport.ts');
const {setLanguage}=loadLocal('../src/i18n.ts');
const project={id:'p',title:'Novela Árbol 世界',schemaVersion:1,revision:2,chapters:[{id:'c',title:'First\n# Heading',synopsis:'Una pista\n\n<script>literal</script>',scenes:[{id:'s',title:'Scene *one*',content:'DO NOT EXPORT MANUSCRIPT TEXT',synopsis:'Decide dónde buscar.',writingStatus:'inReview',reviewComments:[{text:'PRIVATE COMMENT'}]},{id:'s2',title:'Second',content:'',synopsis:''}]}],worldbuilding:{entries:[{title:'PRIVATE ENTRY'}]},plots:{schemaVersion:1,threads:[{id:'plot',title:'The mystery',status:'active',color:'teal',notes:'Find Thomas\n- not a list',beats:[{sceneId:'s2',note:'Later note'},{sceneId:'s',note:'First clue'},{sceneId:'missing',note:'Preserve deleted note'}]}]}};
const before=JSON.stringify(project);
let md=planningMarkdown(project);assert.ok(md.startsWith('# Novela Árbol 世界'));assert.ok(md.includes('First \\# Heading'));assert.ok(md.includes('Scene \\*one\\*'));assert.ok(md.includes('> Una pista\n> \n> \\<script\\>literal\\</script\\>'));assert.ok(md.includes('In review'));assert.ok(md.indexOf('First clue')<md.indexOf('Later note'));assert.ok(md.includes('Preserve deleted note'));assert.ok(md.includes('Deleted scene'));for(const privateText of ['DO NOT EXPORT MANUSCRIPT TEXT','PRIVATE ENTRY','PRIVATE COMMENT'])assert.ok(!md.includes(privateText));assert.equal(JSON.stringify(project),before);
assert.ok(!planningMarkdown(project,{chapters:true,plots:false}).includes('Find Thomas'));assert.ok(!planningMarkdown(project,{chapters:false,plots:true}).includes('Decide dónde buscar'));assert.throws(()=>planningMarkdown(project,{chapters:false,plots:false}));assert.ok(planningMarkdown({...project,chapters:[],plots:undefined}).includes('No chapters yet.'));assert.equal(planningFilename(project.title),'novela-arbol-planning.md');
const require=createRequire(import.meta.url),React=require('react');const Dialog=loadLocal('../src/PlanningExportDialog.tsx').default,storage=loadLocal('../src/storage.ts');
const oldHooks={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect,useMemo:React.useMemo,useSyncExternalStore:React.useSyncExternalStore},oldExport=storage.saveManuscriptExport;
let hooks=['',true,true,true,false,'',''],index=0,exports=[];
function nodes(n){if(Array.isArray(n))return n.flatMap(nodes);if(!n||typeof n!=='object')return [];return[n,...nodes(n.props?.children)];}
function render(){index=0;return nodes(Dialog({project,onClose(){}}));}
try{
 React.useState=()=>{const i=index++;return[hooks[i],v=>{hooks[i]=typeof v==='function'?v(hooks[i]):v;}];};React.useRef=()=>({current:null});React.useEffect=()=>{};React.useMemo=fn=>fn();React.useSyncExternalStore=()=> 'en';
 storage.saveManuscriptExport=async(name,format,bytes)=>{exports.push({name,format,text:new TextDecoder().decode(bytes)});return '/export/plan.md';};
 let all=render();all.find(n=>n.type==='button'&&n.props.children==='Export Markdown').props.onClick();await new Promise(r=>setImmediate(r));assert.equal(exports[0].format,'md');assert.equal(exports[0].text,md);assert.equal(hooks[6],'/export/plan.md');
 all=render();all.filter(n=>n.type==='input')[0].props.onChange({target:{checked:false}});all=render();all.filter(n=>n.type==='input')[1].props.onChange({target:{checked:false}});all=render();all.filter(n=>n.type==='input')[2].props.onChange({target:{checked:false}});all=render();assert.equal(all.find(n=>n.type==='button'&&n.props.children==='Export Markdown').props.disabled,true);
 hooks=['',true,true,true,false,'',''];storage.saveManuscriptExport=async()=>{throw Error('disk full');};all=render();all.find(n=>n.type==='button'&&n.props.children==='Export Markdown').props.onClick();await new Promise(r=>setImmediate(r));assert.ok(hooks[5].includes('disk full'));assert.equal(hooks[4],false);
}finally{Object.assign(React,oldHooks);storage.saveManuscriptExport=oldExport;}
setLanguage('es');md=planningMarkdown(project);assert.ok(md.includes('Planificación de la historia'));assert.ok(md.includes('En revisión'));assert.equal(planningFilename(project.title),'novela-arbol-planificacion.md');const html=renderToStaticMarkup(createElement(Dialog,{project,onClose(){}}));assert.ok(html.includes('Exportar planificación'));assert.ok(html.includes('Vista previa de Markdown'));setLanguage('en');assert.equal(JSON.stringify(project),before);
console.log('Planning export: manuscript-ordered chapters/scenes/plots, notes and status, section options, Unicode/Markdown safety, deleted-scene notes, private-content exclusion, UTF-8 save/retry and Spanish preview passed.');
