import assert from 'node:assert/strict';
import {Schema} from '@tiptap/pm/model';
import {EditorState,TextSelection} from '@tiptap/pm/state';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const {createCommentPlugin,commentKey}=loadLocal('../src/reviewComments.ts');
const {fromMarkdown,toMarkdown}=loadLocal('../src/model.ts');
const {setLanguage}=loadLocal('../src/i18n.ts');
const schema=new Schema({nodes:{doc:{content:'paragraph+'},paragraph:{content:'inline*',group:'block'},text:{group:'inline'},hardBreak:{inline:true,group:'inline'}},marks:{bold:{},italic:{}}});
let opened;
const plugin=createCommentPlugin([],draft=>{opened=draft;});
let state=EditorState.create({doc:schema.nodeFromJSON(fromMarkdown('Hola **mundo** 👩🏽‍💻.\n\nOtra línea.')),plugins:[plugin]});
state=state.apply(state.tr.setSelection(TextSelection.create(state.doc,6,11)).setMeta(commentKey,{kind:'compose'}));assert.equal(opened.quote,'mundo');
const comment={id:'comment',...opened,text:'Revisar fecha',resolved:false};
const markdown=toMarkdown(state.doc.toJSON());state=state.apply(state.tr.setMeta(commentKey,{kind:'upsert',comment}));assert.equal(toMarkdown(state.doc.toJSON()),markdown);assert.equal(commentKey.getState(state).decorations.find().length,1);
state=state.apply(state.tr.insertText('Antes ',1));let current=commentKey.getState(state).comments[0];assert.equal(current.from,12);assert.equal(current.quote,'mundo');
state=state.apply(state.tr.insertText('nuevo ',current.from+2));current=commentKey.getState(state).comments[0];assert.equal(current.quote,'munuevo ndo');
state=state.apply(state.tr.setMeta(commentKey,{kind:'sync',comments:[{...current,resolved:true}]}));assert.equal(commentKey.getState(state).decorations.find().length,0);
state=state.apply(state.tr.setMeta(commentKey,{kind:'sync',comments:[{...current,resolved:false}]}));assert.equal(commentKey.getState(state).decorations.find().length,1);
let prevented=false;assert.equal(plugin.props.handleDOMEvents.click({state},{target:{closest:()=>({getAttribute:()=> 'comment'})},preventDefault(){prevented=true;}}),true);assert.ok(prevented);assert.equal(opened.comment.text,'Revisar fecha');
state=state.apply(state.tr.delete(current.from,current.to));current=commentKey.getState(state).comments[0];assert.equal(current.detached,true);assert.equal(current.text,'Revisar fecha');assert.equal(commentKey.getState(state).decorations.find().length,0);
state=state.apply(state.tr.insertText('x',1));assert.equal(commentKey.getState(state).comments[0].detached,true);
const Panel=loadLocal('../src/ReviewCommentsPanel.tsx').default;
const scenes=[{id:'s1',title:'One',content:'',reviewComments:[{...comment,id:'one'}]},{id:'s2',title:'Two',content:'',reviewComments:[{...current,id:'two'},{...comment,id:'three',resolved:true}]}];
const require=createRequire(import.meta.url),React=require('react'),savedHooks={useState:React.useState};let hooks=[false,'',''],index=0,updates=[],jumps=[];
function nodes(n){if(Array.isArray(n))return n.flatMap(nodes);if(!n||typeof n!=='object')return [];return[n,...nodes(n.props?.children)];}
const props={scenes,onChange:(id,comments)=>updates.push({id,comments}),onJump:(id,c)=>jumps.push([id,c.id])};
function render(){index=0;return nodes(Panel(props));}
try{React.useState=()=>{const i=index++;return[hooks[i],v=>{hooks[i]=v;}];};let all=render();assert.equal(all.filter(n=>n.type==='article').length,2);const quotes=all.filter(n=>n.props?.className==='review-comment-quote');assert.equal(quotes[1].props.disabled,true);quotes[0].props.onClick();assert.deepEqual(jumps,[['s1','one']]);all.find(n=>n.type==='button'&&n.props['aria-label']==='Resolve comment').props.onClick();assert.equal(updates[0].comments[0].resolved,true);assert.equal(scenes[0].reviewComments[0].resolved,false);all.find(n=>n.props?.['aria-label']==='Show resolved comments').props.onClick();assert.equal(render().filter(n=>n.type==='article').length,3);}finally{Object.assign(React,savedHooks);}
setLanguage('es');const html=renderToStaticMarkup(createElement(Panel,props));assert.ok(html.includes('Comentarios de revisión'));assert.ok(html.includes('Resolver comentario'));setLanguage('en');
const {recoverScene}=loadLocal('../src/sceneRecovery.ts');const project={id:'p',revision:1,chapters:[{id:'c',title:'C',scenes}]};const copy=recoverScene(project,{source:project,sceneId:'s1',mode:'copy',chapterId:'c'});assert.notEqual(copy.project.chapters[0].scenes[1].reviewComments[0].id,'one');
console.log('Review comments: selected-text composition, Unicode anchors, edit mapping, unchanged Markdown, resolution, detached fragments, click navigation, scene/chapter list, immutable updates and independent recovered copies passed.');
// Compact editing and deletion controls must not mix viewing/editing actions.
let actionHooks=[false,'','', ''],actionIndex=0,deleted;
const originalUseState=React.useState;
try{
 React.useState=()=>{const i=actionIndex++;return[actionHooks[i],v=>{actionHooks[i]=typeof v==='function'?v(actionHooks[i]):v;}];};
 const actionProps={...props,onChange:(id,comments)=>{deleted={id,comments};}};
 const actionRender=()=>{actionIndex=0;return nodes(Panel(actionProps));};
 let controls=actionRender();controls.find(n=>n.props?.['aria-label']==='Edit comment').props.onClick();controls=actionRender();assert.ok(controls.some(n=>n.props?.['aria-label']==='Save comment'));assert.equal(controls.filter(n=>n.props?.['aria-label']==='Edit comment').length,1,'Other cards retain their view actions');
 controls.find(n=>n.props?.['aria-label']==='Cancel').props.onClick();controls=actionRender();controls.find(n=>n.props?.['aria-label']==='Delete comment').props.onClick();controls=actionRender();assert.equal(deleted,undefined);controls.find(n=>n.props?.['aria-label']==='Confirm deletion').props.onClick();assert.equal(deleted.id,'s1');assert.equal(deleted.comments.length,0);
}finally{React.useState=originalUseState;}
