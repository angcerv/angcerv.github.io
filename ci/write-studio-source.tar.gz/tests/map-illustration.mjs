import assert from 'node:assert/strict';
import {spawnSync} from 'node:child_process';
import {loadLocal} from './load-local.mjs';
const {mapThemes,defaultThemeMaterial,materialBrushKind}=loadLocal('../src/mapThemes.ts');
const {drawingSvg,symbolArtwork}=loadLocal('../src/mapDrawing.ts');
const {materialDefinitions,materialSurface,materialSwatch}=loadLocal('../src/mapMaterials.ts');
const documents=[];
for(const [themeId,theme] of Object.entries(mapThemes)){
 const material=defaultThemeMaterial(themeId);assert.equal(materialBrushKind[material]??'land',theme.brushes[0].kind);
 const drawing={width:1600,height:1000,theme:themeId,strokes:[{kind:theme.brushes[0].kind,material,width:.2,color:'#557788',points:[{x:.2,y:.3},{x:.8,y:.7}]}],objects:theme.symbols.map((kind,i)=>({id:`${themeId}-${i}`,kind,x:.1+(i%4)*.22,y:.2+Math.floor(i/4)*.25,size:.08,rotation:23}))};
 const before=JSON.stringify(drawing),svg=drawingSvg(drawing);documents.push(svg);
 assert.equal(JSON.stringify(drawing),before);assert.equal(drawingSvg(JSON.parse(before)),svg);
 assert.equal((svg.match(/data-map-illustration="painted"/g)||[]).length,theme.symbols.length);
 assert(svg.includes('fill="#557788"'),'Stored material colors remain authoritative');
 assert(!/undefined|NaN|Infinity|<filter|<script|https?:\/\//.test(svg.replace('http://www.w3.org/2000/svg','')));
 for(const kind of theme.symbols){assert(symbolArtwork[kind].length<6000,'Keep original vector stamps bounded');assert(!/\bid=|url\(#/.test(symbolArtwork[kind]),'Repeating a symbol must never duplicate SVG resources');}
 const swatch=decodeURIComponent(materialSwatch(material,.75));assert(swatch.includes(materialDefinitions([material])));assert(swatch.includes(materialSurface(material,.75,160,96)));assert(swatch.includes('data-atlas-paint="wash"'));
}
const solid={width:1600,height:1000,objects:[],strokes:[{kind:'land',color:'#123456',width:.05,points:[{x:.5,y:.5}]}]};assert(!drawingSvg(solid).includes('data-material-detail'));assert(drawingSvg(solid).includes('fill="#123456"'),'Legacy solid dots stay solid');
const parsed=spawnSync('python3',['-c','import json,sys,xml.etree.ElementTree as ET\nfor svg in json.load(sys.stdin): ET.fromstring(svg)'],{input:JSON.stringify(documents),encoding:'utf8'});assert.equal(parsed.status,0,parsed.stderr);
console.log('Painted maps: all four cenital symbol sets, matching initial materials, shared editor/swatch/export artwork, repeated-resource safety, valid SVG and unchanged canonical data passed without UI.');
