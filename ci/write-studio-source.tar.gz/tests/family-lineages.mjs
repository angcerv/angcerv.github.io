import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {genealogyGraph}=loadLocal('../src/genealogyLayout.ts');
const {createEntryPackage,importEntries}=loadLocal('../src/entryTransfer.ts');
const {removeDeletedEntryRelations}=loadLocal('../src/entryRelations.ts');
const [template,a,b,c,group,type]=Array.from({length:6},()=>crypto.randomUUID());
const world={schemaVersion:1,templates:[{schemaVersion:1,id:template,title:'People',fields:[]}],entries:[a,b,c].map((id,index)=>({schemaVersion:1,id,templateId:template,title:`Person ${index}`,values:{},archived:false}))};
const relations={schemaVersion:8,types:[],links:[],lineages:[{id:group,name:'Witham',memberIds:[a,b]}]};
const before=JSON.stringify({world,relations});
let graph=genealogyGraph(world,relations,'',2,2,false,true,undefined,false,[a,b]);
assert.deepEqual(new Set(graph.nodes.map(n=>n.id)),new Set([a,b]),'Isolated members remain visible without relationship types');assert.equal(graph.parents.length,0);
const packet=createEntryPackage(world,[a],relations);assert.equal(packet.entryRelations.schemaVersion,8);assert.deepEqual(packet.entryRelations.lineages[0].memberIds,[a]);assert.equal(packet.worldbuilding.entries.length,1,'Lineage membership does not pull every member into entry packages');
const imported=importEntries(world,packet,[a],relations);assert.equal(imported.entryRelations.lineages.length,2);const copy=imported.entryRelations.lineages[1];assert.notEqual(copy.id,group);assert.notEqual(copy.name,'Witham');assert.deepEqual(copy.memberIds,[imported.entryId]);assert.equal(imported.entryRelations.links.length,0);
const linked={...relations,types:[{id:type,name:'Parentage',title:'Parent',inverseTitle:'Child',symmetric:false,sourceTemplateIds:[template],targetTemplateIds:[template],genealogy:{kind:'parent',parentRole:'source',lineage:'biological'}}],links:[{id:crypto.randomUUID(),typeId:type,sourceId:a,targetId:c}]};
graph=genealogyGraph(world,linked,'',2,2,false,true,undefined,false,[a,b]);assert.equal(graph.parents.length,0);
graph=genealogyGraph(world,linked,'',2,2,false,true,undefined,false,[a,b,c]);assert.equal(graph.parents.length,1);
assert.deepEqual(removeDeletedEntryRelations(relations,world,{...world,entries:world.entries.filter(entry=>entry.id!==a)}).lineages[0].memberIds,[b]);
assert.equal(JSON.stringify({world,relations}),before,'Queries and transfers leave source snapshots unchanged');
console.log('Family lineages: explicit isolated members, scoped genealogy, no inferred parentage, partial export and collision-safe import passed.');
// Exercise the real membership controls and manager draft/save behavior without a UI.
const {createRequire}=await import('node:module');
const React=createRequire(import.meta.url)('react'),oldState=React.useState;
const {default:Manager,LineageMembership}=loadLocal('../src/FamilyLineages.tsx');
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children),...nodes(n.props?.headerActions)]:[];
let changed,opened;
let controls=nodes(LineageMembership({relations,entryId:a,onChange:next=>changed=next,onOpen:id=>opened=id}));
controls.find(n=>n.props?.className==='entry-connection-link').props.onClick();assert.equal(opened,group);
controls.find(n=>n.props?.className==='relation-unlink-action').props.onClick();assert.deepEqual(changed.lineages[0].memberIds,[b]);assert.equal(changed.links.length,0);
controls=nodes(LineageMembership({relations,entryId:c,onChange:next=>changed=next}));controls.find(n=>n.type?.name==='Dropdown').props.onChange(group);assert.deepEqual(changed.lineages[0].memberIds,[a,b,c]);
let state=[],index=0;
try{
 React.useState=initial=>{const i=index++;if(!(i in state))state[i]=initial;return[state[i],value=>{state[i]=typeof value==='function'?value(state[i]):value;}];};
 const render=()=>{index=0;return nodes(Manager({world,relations,onChange:next=>changed=next,onClose(){}}));};
 controls=render();controls.find(n=>n.props?.className==='primary-button').props.onClick();
 controls=render();controls.find(n=>n.props?.id==='lineage-name').props.onChange({target:{value:'Other house'}});
 controls=render();controls.find(n=>n.props?.type==='checkbox'&&!n.props['aria-label']).props.onChange({target:{checked:true}});
 controls=render();controls.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.equal(changed.schemaVersion,8);assert.deepEqual(changed.lineages[1].memberIds,[a]);assert.equal(changed.lineages[1].name,'Other house');assert.equal(changed.links.length,0);
 controls=render();controls.find(n=>n.props?.className==='primary-button').props.onClick();controls=render();controls.find(n=>n.props?.id==='lineage-name').props.onChange({target:{value:' witham '}});assert.equal(render().find(n=>n.props?.type==='submit').props.disabled,true);
 state=[];controls=render();controls.find(n=>n.props?.className==='relation-icon-action').props.onClick();controls=render();controls.find(n=>n.props?.className?.split(' ').includes('danger-button')).props.onClick();controls=render();const destructive=controls.filter(n=>n.props?.className==='danger-button');destructive[0].props.onClick();assert.equal(changed.lineages.length,0);assert.deepEqual(changed.links,relations.links);assert.equal(world.entries.length,3);
 // Bulk changes affect filtered results only and remain draft-only until saved.
 state=[];controls=render();controls.find(n=>n.props?.className==='relation-icon-action').props.onClick();
 const bulk=()=>render().find(n=>n.type==='input'&&n.props['aria-label']==='Select filtered results');
 render().find(n=>n.props?.id==='lineage-member-search').props.onChange({target:{value:'Person 2'}});
 assert.equal(bulk().props.checked,false);bulk().props.onChange({target:{checked:true}});assert.deepEqual(state[0].memberIds,[a,b,c]);assert.equal(bulk().props.checked,true);
 bulk().props.onChange({target:{checked:false}});assert.deepEqual(state[0].memberIds,[a,b]);
 render().find(n=>n.props?.id==='lineage-member-search').props.onChange({target:{value:'no matches'}});assert.equal(bulk().props.disabled,true);
 render().find(n=>n.props?.id==='lineage-member-search').props.onChange({target:{value:''}});assert.equal(bulk().props['aria-checked'],'mixed');bulk().props.onChange({target:{checked:true}});assert.deepEqual(state[0].memberIds,[a,b,c]);bulk().props.onChange({target:{checked:false}});assert.deepEqual(state[0].memberIds,[]);assert.deepEqual(relations.lineages[0].memberIds,[a,b]);

}finally{React.useState=oldState;}
console.log('Family lineage controls: open from entry, add/remove membership, explicit member selection, draft save and duplicate-name guard passed.');
