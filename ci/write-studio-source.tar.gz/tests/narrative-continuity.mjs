import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const {projectPendingItems}=loadLocal('../src/pendingItems.ts');
const N=loadLocal('../src/narrativeContinuity.ts'),{reviewContinuity}=loadLocal('../src/continuity.ts'),{setLanguage}=loadLocal('../src/i18n.ts');
const event=(id,year,sceneIds=[],extra={})=>({id,title:id,start:{year},notes:'',dateLabel:'',sceneIds,entryIds:[],...extra});
let project={schemaVersion:1,id:'review-test',title:'Novel',revision:0,worldbuilding:{templates:[{id:'person',title:'People',fields:[{id:'birth',fieldType:'date',isBirthDate:true}]}],entries:[{id:'person',templateId:'person',title:'Ada',values:{birth:{year:0}}}]},chapters:[{id:'chapter',title:'Chapter',scenes:[{id:'first',title:'First',content:''},{id:'next',title:'Next',content:''}]}],timeline:{schemaVersion:1,events:[event('past',-2,[],{entryIds:['person']}),event('late',10,['first']),event('early',0,['next'])]}};
const snapshot=JSON.stringify(project),issues=N.reviewNarrativeContinuity(project),birth=issues.find(issue=>issue.kind==='age'),sequence=issues.find(issue=>issue.kind==='chronology');
assert(birth);assert(sequence);assert.equal(JSON.stringify(project),snapshot);assert(reviewContinuity(project).some(issue=>issue.id===birth.id));
// Partial dates and periods must establish certainty, not an arbitrary Jan 1.
for(const extra of [{start:{year:0}},{start:{year:-2},end:{year:0}}])assert(!N.reviewNarrativeContinuity({...project,timeline:{events:[event('uncertain',0,[],{entryIds:['person'],...extra})]}}).some(issue=>issue.kind==='age'));
assert(N.reviewNarrativeContinuity({...project,timeline:{events:[event('roles',-2,[],{relations:[{relationId:'participant',entryIds:['person']}]})]}}).some(issue=>issue.kind==='age'));
assert.equal(N.reviewNarrativeContinuity({...project,timeline:{events:[event('a',0,['first']),event('b',0,['next'])]}}).length,0);
assert.equal(N.reviewNarrativeContinuity({...project,timeline:{events:[event('a',0,['first'],{end:{year:20}}),event('b',10,['next'])]}}).length,0);
assert.equal(N.reviewNarrativeContinuity({...project,chapters:[{id:'c',scenes:[project.chapters[0].scenes[0],{id:'undated'},project.chapters[0].scenes[1]]}]}).filter(issue=>issue.kind==='chronology').length,0);
const fingerprint=N.continuityEvidence(project,birth);assert.equal(fingerprint,N.continuityEvidence({...project,title:'Renamed',revision:99},birth));
setLanguage('es');assert.equal(fingerprint,N.continuityEvidence(project,N.reviewNarrativeContinuity(project).find(issue=>issue.id===birth.id)));setLanguage('en');
const changed=structuredClone(project);changed.worldbuilding.entries[0].values.birth={year:1};assert.notEqual(fingerprint,N.continuityEvidence(changed,birth));
const storage=new Map(),previousStorage=globalThis.localStorage;
try{
 globalThis.localStorage={getItem:key=>storage.get(key)??null,setItem:(key,value)=>storage.set(key,value)};
 let notifications=0;const unsubscribe=N.subscribeContinuityReview(()=>notifications++);N.saveContinuityDismissals(project.id,{[birth.id]:fingerprint});assert.equal(notifications,1);N.saveContinuityDismissals(project.id,{[birth.id]:fingerprint});assert.equal(notifications,1);unsubscribe();
 assert(!projectPendingItems(project).some(item=>item.issue?.id===birth.id));assert(projectPendingItems(changed).some(item=>item.issue?.id===birth.id));
 assert.equal(N.loadContinuityDismissals(project.id)[birth.id],fingerprint);assert.deepEqual(N.loadContinuityDismissals('other'),{});
 storage.set('write-studio.continuity.dismissed.bad','null');assert.deepEqual(N.loadContinuityDismissals('bad'),{});storage.set('write-studio.continuity.dismissed.bad','corrupt');assert.deepEqual(N.loadContinuityDismissals('bad'),{});
 // Exercise the real panel handlers without opening an app or browser.
 const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useRef:React.useRef,useMemo:React.useMemo,useEffect:React.useEffect,useSyncExternalStore:React.useSyncExternalStore};
 const Review=loadLocal('../src/ContinuityReview.tsx').default;let states=[],index=0,opened;
 const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
 try{
  React.useState=initial=>{const i=index++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useRef=value=>({current:value});React.useMemo=fn=>fn();React.useEffect=()=>{};React.useSyncExternalStore=(_subscribe,snapshot)=>snapshot();
  const render=()=>{index=0;return nodes(Review({project,onOpen:issue=>opened=issue,onClose(){},onResolve(){}}));};
  let tree=render();assert(!tree.some(node=>node.type==='article'&&node.props.className.includes('continuity-age')));
  tree.find(node=>node.type==='button'&&node.props.children==='Dismissed warnings (1)').props.onClick();tree=render();tree.find(node=>node.type==='button'&&node.props.children==='Restore warning').props.onClick();tree=render();assert(!tree.some(node=>node.type==='article'));
  tree.find(node=>node.type==='button'&&node.props.children==='Show pending warnings').props.onClick();tree=render();let article=tree.find(node=>node.type==='article'&&node.props.className.includes('continuity-age'));nodes(article).find(node=>node.type==='button'&&Array.isArray(node.props.children)&&node.props.children.includes('Open event')).props.onClick();assert.equal(opened.eventId,'past');assert.equal(opened.entryId,undefined);
  nodes(article).find(node=>node.type==='button'&&node.props.children==='Dismiss as intentional').props.onClick();assert(!render().some(node=>node.type==='article'&&node.props.className.includes('continuity-age')));
  project=changed;assert(render().some(node=>node.type==='article'&&node.props.className.includes('continuity-age')),'Editing evidence restores the warning');
 }finally{Object.assign(React,old);}
}finally{if(previousStorage===undefined)delete globalThis.localStorage;else globalThis.localStorage=previousStorage;}
console.log('Narrative continuity: conservative birth/scene date checks, periods and uncertainty, year zero, immutable sources, per-project dismissals, language stability, restore/edit resurfacing and event navigation passed.');
