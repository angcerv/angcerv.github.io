import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const require=createRequire(import.meta.url),React=require('react');
const storage=loadLocal('../src/storage.ts');
const History=loadLocal('../src/VersionHistory.tsx').default;
const Actions=loadLocal('../src/ManuscriptActions.tsx').default;
const {setLanguage}=loadLocal('../src/i18n.ts');
const savedHooks={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const savedStorage={listVersions:storage.listVersions,readVersion:storage.readVersion};
const project={id:'p',title:'Novel',revision:2,chapters:[]};
const versions=[{revision:2,title:'Novel',savedAt:1,checkpointName:'Before rewriting chapter 3'},{revision:1,title:'Novel',savedAt:0}];
let state=[versions,null,'',false,false,'Before rewriting chapter 3',false,false],index=0,refIndex=0,created=[],restored=[];
const refs=[{current:null},{current:0}];
React.useState=()=>{const i=index++;return[state[i],value=>{state[i]=typeof value==='function'?value(state[i]):value;}];};
React.useRef=()=>refs[refIndex++];React.useEffect=()=>{};
storage.listVersions=async path=>{assert.equal(path,'/saved');return versions;};
storage.readVersion=async(path,revision)=>{assert.equal(path,'/saved');return {...project,revision};};
function nodes(node){if(Array.isArray(node))return node.flatMap(nodes);if(!node||typeof node!=='object')return [];return[node,...nodes(node.props?.children)];}
const props={path:'/saved',currentRevision:3,busy:false,onClose(){},async onCreate(name){created.push(name);return{path:'/saved',revision:2};},async onRestore(revision){restored.push(revision);}};
function render(){index=0;refIndex=0;return nodes(History(props));}
const settle=()=>new Promise(resolve=>setImmediate(resolve));
try{
 let all=render();
 all.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});await settle();
 assert.deepEqual(created,['Before rewriting chapter 3']);assert.equal(state[5],'');assert.equal(state[1].revision,2);assert.equal(state[6],false);
 all=render();all.find(n=>n.type==='input'&&n.props.type==='checkbox').props.onChange({target:{checked:true}});
 all=render();const nav=all.find(n=>n.type==='nav');assert.equal(nodes(nav).filter(n=>n.type==='button').length,1);
 const restoreButton=all.find(n=>n.type==='button'&&n.props.children==='Restore this version');restoreButton.props.onClick();
 all=render();all.find(n=>n.type==='button'&&n.props.children==='Confirm restore').props.onClick();await settle();assert.deepEqual(restored,[2]);
 state[5]='Retry name';props.onCreate=async()=>{throw Error('disk failure');};all=render();all.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});await settle();assert.equal(state[5],'Retry name');assert.ok(state[2].includes('disk failure'));assert.equal(state[6],false);
}finally{Object.assign(React,savedHooks);Object.assign(storage,savedStorage);}
setLanguage('es');
const html=renderToStaticMarkup(createElement(History,props));assert.ok(html.includes('Guardar un punto de revisión'));assert.ok(html.includes('Antes de reescribir el capítulo 3'));
const actions=renderToStaticMarkup(createElement(Actions,{hasChapter:true,hasScene:true,toolsOpen:false,worldOpen:false,toolsTrigger:null,onCheckpoints(){},onAddScene(){},onToggleTools(){},onFocus(){},onToggleWorld(){}}));assert.ok(actions.includes('Herramientas de revisión'));
setLanguage('en');
console.log('Revision checkpoints: named creation, refreshed preview, named-only filtering, restoration, failure retry and Spanish manuscript controls passed.');
// The compact review menu retains both actions and the pending-comment badge.
let commentOpened=0,checkpointsOpened=0;
const compact=nodes(Actions({hasChapter:true,hasScene:true,toolsOpen:false,worldOpen:false,toolsTrigger:null,mode:'scene',commentCount:3,onComments(){commentOpened++;},onCheckpoints(){checkpointsOpened++;},onAddScene(){},onToggleTools(){},onFocus(){},onToggleWorld(){}}));
const menu=compact.find(n=>Array.isArray(n.props?.actions));assert.equal(menu.props.actions.length,2);assert.ok(menu.props.label.includes('3'));menu.props.actions[0].onClick();menu.props.actions[1].onClick();assert.equal(commentOpened,1);assert.equal(checkpointsOpened,1);
