import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {readFileSync} from 'node:fs';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import ts from 'typescript';
const require=createRequire(import.meta.url),oldTs=require.extensions['.ts'],oldTsx=require.extensions['.tsx'];
const compile=(module,filename)=>module._compile(ts.transpileModule(readFileSync(filename,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS,jsx:ts.JsxEmit.ReactJSX}}).outputText,filename);
try {
 require.extensions['.ts']=compile;require.extensions['.tsx']=compile;
 const {mapPoint,markerLabel,entryMapLocations,updateMap}=require('../src/maps.ts');
 assert.deepEqual(mapPoint(350,200,{left:100,top:50,width:1000,height:300}),{x:.25,y:.5});
 // A scaled or scrolled image resolves to the same stored position.
 assert.deepEqual(mapPoint(400,250,{left:-100,top:-50,width:2000,height:600}),{x:.25,y:.5});
 assert.deepEqual(mapPoint(-1,1000,{left:0,top:0,width:100,height:100}),{x:0,y:1});
 assert.equal(mapPoint(0,0,{left:0,top:0,width:0,height:10}),null);
 const marker={id:'marker',title:'',notes:'',x:.25,y:.5,color:'teal',icon:'city',entryId:'entry'};
 const maps={schemaVersion:1,maps:[{id:'map',title:'Coast',notes:'',imageId:'image',markers:[marker]},{id:'map-2',title:'City',notes:'',imageId:'image-2',markers:[]}]};
 const world={schemaVersion:1,templates:[{schemaVersion:1,id:'place',title:'Places',fields:[]}],entries:[{id:'entry',title:'Port 世界',templateId:'place',archived:false,values:{},schemaVersion:1}]};
 const before=JSON.stringify(maps);
 assert.equal(markerLabel(marker,world),'Port 世界');
 assert.equal(markerLabel({...marker,title:'Custom name'},world),'Custom name');
 assert.equal(markerLabel(marker,{...world,entries:[]}),'Untitled marker');
 assert.deepEqual(entryMapLocations(maps,'entry').map(item=>[item.map.id,item.marker.id]),[['map','marker']]);
 assert.deepEqual(entryMapLocations(undefined,'entry'),[]);
 for(const icon of ['planet','star','moon','satellite','spaceship']) {
  const upgraded=updateMap(maps,{...maps.maps[0],markers:[{...marker,icon}]});
  assert.equal(upgraded.schemaVersion,18);
  assert.equal(upgraded.maps[0].markers[0].icon,icon);
  assert.equal(updateMap(upgraded,{...upgraded.maps[0],title:'Renamed'}).schemaVersion,18);
 }
 const replaced=updateMap(maps,{...maps.maps[0],imageId:'new-image'});
 assert.deepEqual(replaced.maps[0].markers,maps.maps[0].markers);
 assert.equal(replaced.maps[1],maps.maps[1]);assert.equal(JSON.stringify(maps),before);
 const MapsEditor=require('../src/MapsEditor.tsx').default;
 const props={maps,world,path:'/project',projectId:'id',mapId:'map',markerId:'marker',onSelectMap:()=>{},onSelectMarker:()=>{},onChange:()=>{},onImport:async()=>{},onOpenEntry:()=>{}};
 const view=renderToStaticMarkup(createElement(MapsEditor,props));
 for(const text of ['Map title','Map navigation','Add to No layer','Linked worldbuilding entry','Port 世界','Horizontal','Vertical','Marker notes','Map notes'])assert.ok(view.includes(text),text);
 const missing=renderToStaticMarkup(createElement(MapsEditor,{...props,world:{...world,entries:[]}}));
 assert.ok(missing.includes('Missing entry'));
 const WorldbuildingEditor=require('../src/WorldbuildingEditor.tsx').default;
 const element=createElement(WorldbuildingEditor,{maps,world,onOpenMap:()=>{},onChange:()=>{},onReturn:()=>{},tab:'entries',setTab:()=>{},entryId:'entry',setEntryId:()=>{}});
 const {TextReferenceContext}=require('../src/textReferenceContext.ts');const {indexProjectTextReferences}=require('../src/textReferenceIndex.ts');const usageProject={id:'maps-test',title:'Story',worldbuilding:world,maps,chapters:[]};
 const entryView=renderToStaticMarkup(createElement(TextReferenceContext.Provider,{value:{project:usageProject,world,index:indexProjectTextReferences(usageProject),openEntry(){},openSource(){}}},element));
 assert.ok(entryView.includes('Where this entry is used'));assert.ok(entryView.includes('Maps'));
 assert.ok(entryView.includes('Coast'));
 const WorldDeletionDialog=require('../src/WorldDeletionDialog.tsx').default;
 const deletion=renderToStaticMarkup(createElement(WorldDeletionDialog,{maps,world,target:{kind:'entry',id:'entry'},onCancel:()=>{},onConfirm:()=>{}}));
 assert.ok(deletion.includes('These map markers will keep a Missing entry link'));
 const empty=renderToStaticMarkup(createElement(MapsEditor,{...props,maps:{schemaVersion:1,maps:[]}}));
 assert.ok(empty.includes('Import your first map'));
 assert.equal(JSON.stringify(maps),before);
 console.log('Maps: scale-independent positions, bounds, entry backlinks, missing links, immutable image replacement and editor/empty states passed.');
} finally { require.extensions['.ts']=oldTs;require.extensions['.tsx']=oldTsx; }
