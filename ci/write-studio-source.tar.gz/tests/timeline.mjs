import assert from 'node:assert/strict';
import { createRequire } from 'node:module';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
const require=createRequire(import.meta.url),previous=require.extensions['.ts'];
require.extensions['.ts']=(module,filename)=>module._compile(ts.transpileModule(readFileSync(filename,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText,filename);
try {
 const {parseStoryDate,formatStoryDate,validatePeriod,sortedEvents,moveEvent,eventDateLabel,filterTimelineEvents,emptyTimelineFilters}=require('../src/timeline.ts');
 assert.equal(parseStoryDate(''),undefined);
 for(const text of ['-400-02-29','0-02-29','12','2024-02','2024-02-29','999999-12-31']) assert.equal(formatStoryDate(parseStoryDate(text)),text);
 for(const text of ['2023-02-29','1900-02-29','2024-13','2024-04-31','1000000','2024-2-3','year 12']) assert.throws(()=>parseStoryDate(text));
 assert.throws(()=>validatePeriod(undefined,{year:12}));
 assert.throws(()=>validatePeriod({year:12},{year:11}));
 validatePeriod({year:12,month:12},{year:12});
 const event=(id,start)=>({id,title:id,notes:'',dateLabel:'',...(start?{start}:{}),sceneIds:[],entryIds:[]});
 const timeline={schemaVersion:1,events:[event('undated'),event('later',{year:20}),event('earlier',{year:-2}),event('same',{year:20})]};
 const snapshot=JSON.stringify(timeline);
 assert.deepEqual(sortedEvents(timeline,'date').map(e=>e.id),['earlier','later','same','undated']);
 assert.deepEqual(sortedEvents(timeline,'manual').map(e=>e.id),timeline.events.map(e=>e.id));
 assert.equal(moveEvent(timeline,'undated',-1),timeline);
 assert.equal(moveEvent(timeline,'later',-1).events[0].id,'later');
 assert.equal(JSON.stringify(timeline),snapshot);
 assert.equal(eventDateLabel({...event('label'),dateLabel:'Before the war'}),'Before the war');
 assert.equal(sortedEvents({...timeline,events:[{...event('label'),dateLabel:'Before the war'}]},'date','war').length,1);
 const linked = [
  {...event('period',{year:-10}),end:{year:10},sceneIds:['s1'],entryIds:['person']},
  {...event('partial',{year:20}),sceneIds:['s2'],entryIds:['place']},
  {...event('unknown'),dateLabel:'Winter',sceneIds:['s1'],entryIds:['person']},
  event('late',{year:30})
 ];
 const chapters=[{id:'c1',scenes:[{id:'s1'}]},{id:'c2',scenes:[{id:'s2'}]}];
 const filtered = overrides=>filterTimelineEvents(linked,{...emptyTimelineFilters,...overrides},chapters).map(e=>e.id);
 const before=JSON.stringify(linked);
 assert.deepEqual(filtered({}),['period','partial','unknown','late']);
 assert.deepEqual(filtered({entryId:'person',chapterId:'c1',sceneId:'s1'}),['period','unknown']);
 assert.deepEqual(filtered({entryId:'person',chapterId:'c2'}),[]);
 assert.deepEqual(filtered({chapterId:'deleted'}),[]);
 assert.deepEqual(filtered({from:{year:0},to:{year:0},includeUndated:false}),['period']);
 assert.deepEqual(filtered({from:{year:20,month:12,day:31},to:{year:20,month:12,day:31},includeUndated:false}),['partial']);
 assert.deepEqual(filtered({to:{year:-11},includeUndated:false}),[]);
 assert.deepEqual(filtered({from:{year:31}}),['unknown']);
 assert.deepEqual(filtered({includeUndated:false}),['period','partial','late']);
 assert.equal(JSON.stringify(linked),before);
 const {searchProject}=require('../src/globalSearch.ts');
 assert.equal(searchProject({chapters:[],timeline},'later')[0].kind,'event');
 console.log('Timeline: partial/negative dates, leap years, periods, stable sorting, manual order, free labels and search passed.');
} finally {if(previous)require.extensions['.ts']=previous;else delete require.extensions['.ts'];}
