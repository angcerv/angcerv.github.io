import assert from 'node:assert/strict';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const C=loadLocal('../src/storyCalendar.ts'),I=loadLocal('../src/i18n.ts');
const calendar={...C.defaultStoryCalendar(),schemaVersion:2,mode:'fixed',months:[{name:'Dawn',days:10},{name:'Sea',days:10}],seasons:[{name:'Rain',month:1,day:3,description:'Storms'},{name:'Dry',month:2,day:3}],holidays:[{name:'New tide',month:2,day:9,duration:4,description:'Crosses the year'},{name:'Second celebration',month:2,day:9,duration:1}]};
C.validateStoryCalendar(calendar);const before=JSON.stringify(calendar);
const at=(year,month,day)=>C.calendarDateContext(C.storyDateFromCalendar({year,month,day},calendar),calendar);
assert.equal(at(0,1,1).season.name,'Dry');assert.equal(at(0,1,3).season.name,'Rain');assert.equal(at(0,2,3).season.name,'Dry');assert.equal(at(-1,1,1).season.name,'Dry');
assert.deepEqual(at(0,2,9).holidays.map(item=>item.name),['New tide','Second celebration']);assert.equal(at(0,2,10).holidays.length,1);assert.equal(at(1,1,1).holidays[0].name,'New tide');assert.equal(at(1,1,2).holidays.length,1);assert.equal(at(1,1,3).holidays.length,0);assert.equal(at(0,1,1).holidays[0].name,'New tide');
assert.deepEqual(C.calendarDateContext({year:0,month:1},calendar),{holidays:[]});assert.deepEqual(C.calendarDateContext({year:0},calendar),{holidays:[]});assert.deepEqual(C.calendarDateContext({year:0,month:1,day:1}),{holidays:[]});
assert.equal(at(999999,1,1).holidays.length,1);assert.equal(at(-999999,1,1).holidays.length,1);
const leap={...C.defaultStoryCalendar(),schemaVersion:2,holidays:[{name:'Leap festival',month:2,day:29,duration:2}],seasons:[{name:'Winter',month:12,day:1},{name:'Summer',month:6,day:1}]};C.validateStoryCalendar(leap);
for(const year of [-400,-4,0,4,400,2024]){assert.equal(C.calendarDateContext({year,month:2,day:29},leap).holidays.length,1);assert.equal(C.calendarDateContext({year,month:3,day:1},leap).holidays.length,1);assert.equal(C.calendarDateContext({year,month:3,day:2},leap).holidays.length,0);}
for(const year of [-100,-1,1,100,2023])assert.equal(C.calendarDateContext({year,month:3,day:1},leap).holidays.length,0);
assert.throws(()=>C.validateStoryCalendar({...leap,seasons:[{name:'Invalid start',month:2,day:29}]}));
for(const patch of [{schemaVersion:1},{seasons:[...calendar.seasons,{name:'Duplicate start',month:1,day:3}]},{seasons:[{name:'bad',month:1,day:11}]},{holidays:[{name:'bad',month:0,day:1,duration:1}]},{holidays:[{name:'bad',month:1,day:1,duration:21}]},{holidays:[{name:'bad',month:1,day:1,duration:0}]},{holidays:[{name:'bad',month:1,day:1,duration:1,description:'a'.repeat(4001)}]}])assert.throws(()=>C.validateStoryCalendar({...calendar,...patch}));
const removed={...calendar,...C.removeCalendarMonth(calendar,0)};assert.equal(removed.seasons[0].month,0);assert.equal(removed.seasons[1].month,1);assert.equal(removed.holidays[0].month,1);assert.throws(()=>C.validateStoryCalendar(removed));assert.equal(JSON.stringify(calendar),before);
assert.equal(C.calendarDateContext({year:0,month:1,day:1},C.defaultStoryCalendar()).holidays.length,0);
// Recurring dates remain explicit settings and never create or change timeline events.
const Editor=loadLocal('../src/CalendarRecurrences.tsx').default;let patch,request;
const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
let tree=nodes(Editor({calendar,onChange:value=>patch=value,onEdit:value=>request=value}));tree.find(node=>node.type==='button'&&node.props.children?.includes?.('Add holiday')).props.onClick();assert.deepEqual(request,{kind:'holidays'});assert.equal(patch,undefined);assert.equal(JSON.stringify(calendar),before);
const List=loadLocal('../src/CalendarElementList.tsx').default;const lists=tree.filter(node=>node.type===List);lists[1].props.onEdit(0);assert.deepEqual(request,{kind:'holidays',index:0});lists[0].props.onRemove(0);assert.equal(patch.seasons.length,1);assert(!tree.some(node=>node.type==='input'||node.type==='textarea'));
const {CalendarEventContext}=loadLocal('../src/CalendarDateContext.tsx');const event={start:C.storyDateFromCalendar({year:0,month:2,day:9},calendar),end:C.storyDateFromCalendar({year:1,month:1,day:3},calendar)};
let markup=renderToStaticMarkup(createElement(CalendarEventContext,{calendar,event}));assert(markup.includes('At the start'));assert(markup.includes('At the end'));assert(markup.includes('New tide'));assert(markup.includes('Rain'));assert(markup.includes('About Rain'));assert((markup.match(/New tide/g)??[]).length>=2); // name + optional-help accessible label
assert.equal(renderToStaticMarkup(createElement(CalendarEventContext,{calendar,event:{start:{year:0}}})), '');
I.setLanguage('es');markup=renderToStaticMarkup(createElement(Editor,{calendar,onChange(){}}));assert(markup.includes('Festividades'));assert(markup.includes('Estaciones'));I.setLanguage('en');
console.log('Calendar recurrence: seasons across years, negative/year-zero bounds, overlapping and multi-day holidays, leap-only dates, exact endpoints, partial-date honesty, invalidated month references, immutable editing handlers and Spanish UI passed without UI.');
