import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {searchEntries}=loadLocal('../src/worldbuilding.ts');
const world={templates:[{id:'places',fields:[{id:'text',fieldType:'longText'},{id:'reference',fieldType:'reference'},{id:'status',fieldType:'picklist',options:[{id:'option',label:'En revisión'}]}]},{id:'people',fields:[]}],entries:[
 {id:'island',title:'Isla Púrpura',templateId:'places',archived:false,linkAliases:['Puerto del Océano'],values:{text:'**Ciudad** de\n\nlos árboles.',status:'option',reference:{entryId:'person'}}},
 {id:'person',title:'Ángela',templateId:'people',archived:false,values:{}},
 {id:'old',title:'Isla Púrpura antigua',templateId:'places',archived:true,values:{}}
]};
const ids=(text,category='',archived=false)=>searchEntries(world,text,category,archived).map(entry=>entry.id);
const before=JSON.stringify(world);
for(const query of ['PURPURA','pu\u0301rpura','  Isla   Púrpura  ','isla\u00a0purpura','oceano','ciudad de los arboles','EN REVISION'])assert.deepEqual(ids(query),['island'],query);
assert.deepEqual(ids('angela'),['island','person']); // References use their visible target title.
assert.deepEqual(ids('angela','people'),['person']);
assert.deepEqual(ids('purpura','people'),[]);
assert.deepEqual(ids('purpura','places',true),['old']);
assert.deepEqual(ids(' \n\t '),['island','person']);
assert.deepEqual(ids('missing'),[]);
assert.equal(JSON.stringify(world),before);
const edited={...world,entries:world.entries.map(entry=>entry.id==='island'?{...entry,title:'Nueva isla',linkAliases:[],values:{text:'Otro contenido'}}:entry)};
assert.deepEqual(searchEntries(edited,'purpura'),[]);
assert.deepEqual(searchEntries(edited,'otro contenido').map(entry=>entry.id),['island']);
console.log('Entry search: accents, Unicode, case, whitespace, rich text, aliases, visible options/references, category/archive scope and fresh edits passed.');
// The World sidebar opts into names only; general content search remains available elsewhere.
const names=(query,category='',archived=false)=>searchEntries(world,query,category,archived,'name').map(entry=>entry.id);
assert.deepEqual(names('angela'),['person']);
for(const query of ['oceano','ciudad','revision'])assert.deepEqual(names(query),[]);
assert.deepEqual(names('PURPURA'),['island']);assert.deepEqual(names('purpura','places',true),['old']);assert.deepEqual(names('purpura','people'),[]);
