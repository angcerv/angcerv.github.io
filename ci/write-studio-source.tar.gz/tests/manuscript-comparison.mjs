import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const {compareManuscripts,diffText,manuscriptText}=loadLocal('../src/manuscriptDiff.ts');
const {toMarkdown}=loadLocal('../src/model.ts');
const {setLanguage}=loadLocal('../src/i18n.ts');
const scene=(id,content=id)=>({id,title:'Same title',content});
const chapter=(id,scenes)=>({id,title:id,scenes});
const project=chapters=>({id:'p',schemaVersion:1,title:'Novel',revision:1,chapters});
const original=project([chapter('c1',[scene('a'),scene('b'),scene('c')]),chapter('c2',[scene('d')])]);
const snapshot=JSON.stringify(original);
let next=structuredClone(original);next.chapters[0].scenes.unshift(scene('new'));
let diff=compareManuscripts(original,next);assert.deepEqual(diff.scenes.map(s=>[s.id,s.added,s.moved]),[['new',true,false]]);
next=structuredClone(original);next.chapters[0].scenes.splice(1,1);diff=compareManuscripts(original,next);assert.deepEqual(diff.scenes.map(s=>[s.id,s.removed,s.moved]),[['b',true,false]]);
next=structuredClone(original);next.chapters[1].scenes.push(next.chapters[0].scenes.splice(1,1)[0]);diff=compareManuscripts(original,next);assert.equal(diff.scenes.length,1);assert.equal(diff.scenes[0].id,'b');assert.equal(diff.scenes[0].moved,true);
next=structuredClone(original);next.chapters[0].scenes.reverse();diff=compareManuscripts(original,next);assert.equal(diff.scenes.filter(s=>s.moved).length,2);assert.ok(diff.scenes.every(s=>!s.edited));
next=structuredClone(original);next.chapters.reverse();diff=compareManuscripts(original,next);assert.equal(diff.chapters.filter(c=>c.moved).length,1);assert.equal(diff.scenes.length,0);
next=structuredClone(original);next.chapters[0].title='Renamed';next.chapters[0].synopsis='New synopsis';next.chapters[0].scenes[0].title='New title';next.chapters[0].scenes[0].synopsis='Notes';next.chapters[0].scenes[0].writingStatus='finished';next.chapters[0].scenes[1].content='New words';diff=compareManuscripts(original,next);assert.equal(diff.chapters.length,1);assert.equal(diff.scenes.filter(s=>s.edited).length,2);
assert.equal(compareManuscripts(original,structuredClone(original)).scenes.length,0);assert.equal(JSON.stringify(original),snapshot);
function reconstruct(a,b){const parts=diffText(a,b);assert.equal(parts.filter(p=>p.kind!=='added').map(p=>p.text).join(''),a);assert.equal(parts.filter(p=>p.kind!=='removed').map(p=>p.text).join(''),b);return parts;}
for(const [a,b] of [['',''],['','New'],['Old',''],['El puerto estaba vacío.','El puerto estaba lleno.'],['café 👩🏽‍💻 世界\n\n','CAFÉ 👩🏽‍💻 世界\n'],['repeated repeated end','repeated start repeated end'],['a '.repeat(1600),'b '.repeat(1600)],['word '.repeat(25000),'x']])reconstruct(a,b);
const parts=reconstruct('El puerto estaba vacío.','El puerto estaba lleno.');assert.ok(parts.some(p=>p.kind==='removed'&&p.text==='vacío'));assert.ok(parts.some(p=>p.kind==='added'&&p.text==='lleno'));
let seed=17;const random=()=>{seed=(seed*1664525+1013904223)>>>0;return seed;};const words=['á','世界',' ','\n','👩🏽‍💻','x','.',"'",'<'];for(let i=0;i<100;i++){const sample=()=>Array.from({length:random()%30},()=>words[random()%words.length]).join('');reconstruct(sample(),sample());}
assert.equal(manuscriptText('**Hola** _mundo_\\!\n\nFin  \naquí'),'Hola mundo!\n\nFin\naquí');
const {TextDiff,ManuscriptChanges}=loadLocal('../src/ManuscriptComparison.tsx');
const html=renderToStaticMarkup(createElement(TextDiff,{before:'<script>old</script>',after:'<script>new</script>'}));assert.ok(html.includes('<del'));assert.ok(html.includes('<ins'));assert.ok(!html.includes('<script>'));
setLanguage('es');const comparison=renderToStaticMarkup(createElement(ManuscriptChanges,{before:original,after:next}));assert.ok(comparison.includes('Escena editada'));assert.ok(comparison.includes('Cambios en los capítulos'));setLanguage('en');
// Open a scene's actual diff and verify formatting-only edits remain visible.
const require=createRequire(import.meta.url),React=require('react');
const savedHooks={useState:React.useState,useMemo:React.useMemo,useEffect:React.useEffect};
const storage=loadLocal('../src/storage.ts'),oldRead=storage.readVersion;
function nodes(node){if(Array.isArray(node))return node.flatMap(nodes);if(!node||typeof node!=='object')return [];return[node,...nodes(node.props?.children)];}
try{
 React.useMemo=fn=>fn();React.useState=()=>[true,()=>{}];
 const bold=structuredClone(original);bold.chapters[0].scenes[0].content=toMarkdown({content:[{type:'paragraph',content:[{type:'text',text:'a',marks:[{type:'bold'}]}]}]});
 const tree=ManuscriptChanges({before:original,after:bold});const row=nodes(tree).find(n=>typeof n.type==='function'&&n.type.name==='SceneDifference');const opened=row.type(row.props);
 Object.assign(React,savedHooks);assert.ok(renderToStaticMarkup(opened).includes('Only text formatting changed.'));
 // Changing comparison targets while reads are pending must not show a stale version.
 const Comparison=loadLocal('../src/ManuscriptComparison.tsx').default;
 let state=['2',null,'',false],index=0,effect,cleanup,pending={};
 React.useState=()=>{const i=index++;return[state[i],v=>{state[i]=v;}];};React.useEffect=fn=>{effect=fn;};
 storage.readVersion=(path,revision)=>new Promise(resolve=>{assert.equal(path,'/saved');pending[revision]=resolve;});
 const props={before:original,current:next,path:'/saved',versions:[{revision:2},{revision:3}],disabled:false};
 function render(){index=0;return nodes(Comparison(props));}
 render();cleanup=effect();state[0]='3';cleanup();render();cleanup=effect();pending[2]({...original,revision:2});await new Promise(r=>setImmediate(r));assert.equal(state[1],null);pending[3]({...original,revision:3});await new Promise(r=>setImmediate(r));assert.equal(state[1].revision,3);cleanup();
 state[0]='current';const currentView=render();const current= currentView.find(n=>n.type===ManuscriptChanges);assert.equal(current.props.after,next);assert.equal(current.props.after.chapters[0].scenes[1].content,'New words');
}finally{Object.assign(React,savedHooks);storage.readVersion=oldRead;}
console.log('Manuscript comparison: stable-ID additions/removals/moves, chapter/scene edits, bounded Unicode word diffs, exact reconstruction, formatting-only edits, safe rendering, live unsaved target and stale-read guards passed.');
