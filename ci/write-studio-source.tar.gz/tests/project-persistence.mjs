import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const React=createRequire(import.meta.url)('react'),storage=loadLocal('../src/storage.ts'),recovery=loadLocal('../src/recovery.ts');
const {useProjectPersistence}=loadLocal('../src/useProjectPersistence.ts');
const original={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect},services={saveProject:storage.saveProject,chooseFolder:storage.chooseFolder,readDraft:recovery.readDraft,enqueue:recovery.recoveryWriter.enqueue},oldWindow=globalThis.window,oldDocument=globalThis.document;
const deferred=()=>{let resolve,reject;const promise=new Promise((yes,no)=>{resolve=yes;reject=no;});return {promise,resolve,reject};};
const flush=async()=>{for(let i=0;i<8;i++)await Promise.resolve();};
const project={schemaVersion:1,id:'project',title:'Draft',revision:1,chapters:[{id:'chapter',title:'Chapter',scenes:[{id:'scene',title:'Scene',content:'Text'}]}]};
let cleanupCurrent=()=>{};
function harness({read=async()=>null,path='/project'}={}){
 cleanupCurrent();
 let values=[],refs=[],effects=[],si=0,ri=0,ei=0,currentProject=project,currentPath=path,blocked=false,session=1,result,timerId=0,updates=0;
 const timers=new Map(),writes=[],remembers=[],documentEvents=new Map(),windowEvents=new Map();
 globalThis.document={visibilityState:"visible",addEventListener:(name,fn)=>documentEvents.set(name,fn),removeEventListener:(name)=>documentEvents.delete(name)};
 React.useState=initial=>{const i=si++;if(!(i in values))values[i]=typeof initial==='function'?initial():initial;return [values[i],next=>{updates++;values[i]=typeof next==='function'?next(values[i]):next;}];};
 React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};
 React.useEffect=(setup,deps)=>{const i=ei++,previous=effects[i];if(!previous||deps.some((value,index)=>!Object.is(value,previous.deps[index]))){previous?.cleanup?.();effects[i]={deps,cleanup:setup()};}};
 globalThis.window={addEventListener:(name,fn)=>windowEvents.set(name,fn),removeEventListener:(name)=>windowEvents.delete(name),setInterval(fn,ms){assert.equal(ms,30000);timers.set(++timerId,fn);return timerId;},clearInterval(id){timers.delete(id);}};
 recovery.readDraft=read;recovery.recoveryWriter.enqueue=async draft=>{writes.push(draft);};
 storage.chooseFolder=async()=>'/chosen';storage.saveProject=async(_path,value)=>({...value,revision:value.revision+1});
 function render(){si=ri=ei=0;result=useProjectPersistence({project:currentProject,path:currentPath,selectedId:'scene',session,setProject:value=>{currentProject=typeof value==='function'?value(currentProject):value;},setPath:value=>{currentPath=typeof value==='function'?value(currentPath):value;},remember:async(...args)=>remembers.push(args),isAutosaveBlocked:()=>blocked});return result;}
 cleanupCurrent=()=>{effects.forEach(effect=>effect.cleanup?.());effects=[];};
 return {background(){globalThis.document.visibilityState='hidden';documentEvents.get('visibilitychange')?.();windowEvents.get('pagehide')?.();},resume(){globalThis.document.visibilityState='visible';documentEvents.get('visibilitychange')?.();},pagehide(){windowEvents.get('pagehide')?.();},pageEvents:windowEvents,documentEvents,render,get current(){return result;},timers,writes,remembers,tick(){for(const fn of timers.values())fn();},block(value){blocked=value;},edit(title){currentProject={...currentProject,title};result.state.current.project=currentProject;result.state.current.dirty=true;result.setDirty(true);},setPath(value){currentPath=value;},newSession(){session++;},get timerId(){return timerId;},get updates(){return updates;}};
}
try{
 let h=harness();let p=h.render();assert.equal(p.ready,false);await flush();p=h.render();assert.equal(p.ready,true);
 assert.equal(h.timers.size,1);h.tick();await flush();assert.equal(h.remembers.length,0);
 const firstTimer=h.timerId;
 for(let i=0;i<20;i++){h.edit(`Edit ${i}`);h.render();}assert.equal(h.timerId,firstTimer,'Typing must not restart the interval');
 h.block(true);h.render();h.tick();await flush();assert.equal(h.remembers.length,0);
 h.block(false);h.render();h.tick();await flush();p=h.render();assert.equal(h.remembers.length,1);assert.equal(p.dirty,false);assert.equal(p.saveProgress,null,'Autosave must not open the manual progress dialog');assert.equal(p.state.current.project.title,'Edit 19');
 h.tick();await flush();assert.equal(h.remembers.length,1);h.setPath('');h.render();assert.equal(h.timers.size,0);h.setPath('/project');h.render();h.newSession();h.render();assert.equal(h.timers.size,1);
 // Background protects the latest draft once, without saving project files or resetting timers.
 h=harness();h.render();await flush();h.edit('Before suspension');p=h.render();const stableTimer=h.timerId;
 h.background();await flush();assert.equal(h.writes.length,1);assert.equal(h.writes[0].project.title,'Before suspension');assert.equal(h.remembers.length,0);assert.equal(h.timerId,stableTimer);
 h.resume();await flush();p=h.render();assert.equal(p.dirty,false);assert.equal(h.remembers.length,1);
 // Resume respects existing autosave blockers; pagehide alone still protects unsaved text.
 h=harness({path:''});h.render();await flush();h.edit('No path yet');p=h.render();h.pagehide();await flush();assert.equal(h.writes.at(-1).path,'');assert.equal(h.writes.at(-1).project.title,'No path yet');
 h=harness();h.render();await flush();h.edit('Modal draft');h.block(true);h.render();h.background();await flush();h.resume();await flush();assert.equal(h.remembers.length,0);assert.equal(h.writes.at(-1).project.title,'Modal draft');
 // Recovery prompts and locked operations must not be overwritten by lifecycle callbacks.
 h=harness({read:async()=>({project,path:'/project',selectedId:'scene'})});h.render();await flush();h.edit('Do not replace recovery');p=h.render();h.background();await flush();assert.equal(h.writes.length,0);
 h=harness();h.render();await flush();h.edit('Busy');p=h.render();p.locked.current=true;h.background();await flush();assert.equal(h.writes.length,0);p.locked.current=false;
 cleanupCurrent();assert.equal(h.documentEvents.size,0);assert.equal(h.pageEvents.size,0);
 // Actual manual save phases, shared lock and recovery-clear ordering.
 h=harness({path:''});h.render();await flush();h.render();h.edit('Manual draft');p=h.render();
 const saveGate=deferred(),clearGate=deferred();let saveCalls=0;
 storage.saveProject=async(path,value)=>{saveCalls++;assert.equal(path,'/chosen');await saveGate.promise;return {...value,revision:2};};
 recovery.recoveryWriter.enqueue=async value=>{assert.equal(value,null);await clearGate.promise;};
 const saving=p.save();await flush();p=h.render();assert.equal(p.saveProgress.phase,'saving');assert.equal(p.busy,true);assert.equal(await p.run(async()=>99),undefined);assert.equal(await p.save(),false);assert.equal(saveCalls,1);
 saveGate.resolve();await flush();p=h.render();assert.equal(p.saveProgress.phase,'finishing');assert.equal(p.state.current.project.revision,1);
 clearGate.resolve();assert.equal(await saving,true);p=h.render();assert.equal(p.saveProgress,null);assert.equal(p.state.current.path,'/chosen');assert.equal(p.state.current.project.revision,2);assert.equal(p.dirty,false);assert.equal(p.locked.current,false);
 // Manual save must keep edits arriving during I/O and prevent close/switch continuations.
 h=harness();h.render();await flush();h.edit('Manual snapshot');p=h.render();const manualGate=deferred();
 storage.saveProject=async(_path,value)=>{await manualGate.promise;return {...value,revision:2};};
 const manualSaving=p.save();await flush();h.edit('Typed during manual save');h.render();manualGate.resolve();
 assert.equal(await manualSaving,false);p=h.render();assert.equal(p.state.current.project.title,'Typed during manual save');assert.equal(p.state.current.project.revision,2);assert.equal(p.dirty,true);assert.equal(h.writes.at(-1).project.title,'Typed during manual save');assert.equal(p.saveProgress,null);assert.equal(p.locked.current,false);
 storage.saveProject=async(_path,value)=>({...value,revision:3});assert.equal(await p.save(),true);p=h.render();assert.equal(p.dirty,false);assert.equal(p.state.current.project.title,'Typed during manual save');assert.equal(p.state.current.project.revision,3);
 // Manual recovery deletion must not discard newer edits, including a new destination.
 h=harness({path:''});h.render();await flush();h.edit('Before manual cleanup');p=h.render();const manualDeletion=deferred();
 recovery.recoveryWriter.enqueue=async value=>{h.writes.push(value);if(value===null)await manualDeletion.promise;};
 const manualClearing=p.save();await flush();assert.equal(h.render().saveProgress.phase,'finishing');h.edit('Typed during manual cleanup');h.render();manualDeletion.resolve();
 assert.equal(await manualClearing,false);p=h.render();assert.equal(p.dirty,true);assert.equal(p.state.current.path,'/chosen');assert.equal(h.writes.at(-1).path,'/chosen');assert.equal(h.writes.at(-1).project.title,'Typed during manual cleanup');assert.equal(h.writes.at(-1).project.revision,2);
 // Cancellation leaves the draft and does not write.
 h=harness({path:''});h.render();await flush();h.edit('Keep draft');p=h.render();storage.chooseFolder=async()=>null;storage.saveProject=async()=>{throw Error('Must not save');};assert.equal(await p.save(),false);p=h.render();assert.equal(p.dirty,true);assert.equal(p.saveProgress,null);
 // Write failures keep text, release the lock and expose the existing progress error.
 h=harness();h.render();await flush();h.edit('Keep on failure');p=h.render();storage.saveProject=async()=>{throw Error('Disk full');};assert.equal(await p.save(),false);p=h.render();assert.match(p.error,/Disk full/);assert.match(p.autosaveError,/Disk full/);assert.match(p.saveProgress.error,/Disk full/);assert.equal(p.dirty,true);assert.equal(p.state.current.project.title,'Keep on failure');assert.equal(p.locked.current,false);
 // Recovery cleanup failure is a finishing error; the current draft remains available.
 h=harness();h.render();await flush();h.edit('Keep after cleanup failure');p=h.render();recovery.recoveryWriter.enqueue=async()=>{throw Error('Recovery cleanup failed');};assert.equal(await p.save(),false);p=h.render();assert.equal(p.saveProgress.phase,'finishing');assert.match(p.saveProgress.error,/Recovery cleanup failed/);assert.equal(p.dirty,true);assert.equal(p.locked.current,false);
 // Edits during autosave win; only their revision is rebased, then protected.
 h=harness();h.render();await flush();h.edit('Snapshot');p=h.render();const autoGate=deferred();storage.saveProject=async(_path,value)=>{await autoGate.promise;return {...value,revision:2};};h.tick();h.edit('Typed during save');h.render();autoGate.resolve();await flush();p=h.render();assert.equal(p.state.current.project.title,'Typed during save');assert.equal(p.state.current.project.revision,2);assert.equal(p.dirty,true);assert.equal(h.writes.at(-1).project.title,'Typed during save');
 // Typing while recovery deletion finishes must enqueue a fresh protected draft.
 h=harness();h.render();await flush();h.edit('Before clearing');p=h.render();const deletion=deferred();recovery.recoveryWriter.enqueue=async value=>{h.writes.push(value);if(value===null)await deletion.promise;};h.tick();await flush();h.edit('Typed during cleanup');h.render();deletion.resolve();await flush();p=h.render();assert.equal(p.dirty,true);assert.equal(h.writes.at(-1).project.title,'Typed during cleanup');
 // Recovery status ignores acknowledgements from superseded writes.
 h=harness();h.render();await flush();p=h.render();const first=deferred(),second=deferred();let calls=0;recovery.recoveryWriter.enqueue=()=>++calls===1?first.promise:second.promise;p.protectDraft(project);p.protectDraft({...project,title:'Newer'});first.reject(Error('Old failure'));await flush();p=h.render();assert.equal(p.recoveryStatus,'Updating recovery copy…');second.resolve();await flush();assert.equal(h.render().recoveryStatus,'Recovery copy updated');
 // Reading failures and unmounting preserve the initial recovery guard.
 h=harness({read:async()=>{throw Error('Unreadable recovery');}});h.render();await flush();p=h.render();assert.equal(p.ready,true);assert.equal(p.recoveryReadError,true);assert.match(p.error,/Unreadable recovery/);
 h=harness({read:async()=>({project,path:'/project',selectedId:'scene'})});h.render();await flush();h.edit('Blocked by recovery');p=h.render();assert.equal(p.recoverable.project,project);h.tick();await flush();assert.equal(h.remembers.length,0);
 const readGate=deferred();h=harness({read:()=>readGate.promise});h.render();cleanupCurrent();const updatesBefore=h.updates;readGate.resolve({project,path:'/project',selectedId:'scene'});await flush();assert.equal(h.updates,updatesBefore,'Disposed recovery reads must not set state');
}finally{cleanupCurrent();Object.assign(React,original);Object.assign(storage,{saveProject:services.saveProject,chooseFolder:services.chooseFolder});recovery.readDraft=services.readDraft;recovery.recoveryWriter.enqueue=services.enqueue;if(oldWindow===undefined)delete globalThis.window;else globalThis.window=oldWindow;if(oldDocument===undefined)delete globalThis.document;else globalThis.document=oldDocument;}
console.log('Project persistence hook: interval stability, blocking, clean saves, manual phases/cancellation/errors, lock deduplication, concurrent edits, recovery ordering/read failures and cleanup passed without UI.');
