import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const R=loadLocal('../src/entryRelations.ts'),G=loadLocal('../src/genealogyLayout.ts'),V=loadLocal('../src/relationGraph.ts'),T=loadLocal('../src/entryTransfer.ts');
const [templateId,parentType,partnerType,a,b,c,d,e]=Array.from({length:8},()=>crypto.randomUUID());
const world={schemaVersion:1,templates:[{schemaVersion:1,id:templateId,title:'People',fields:[]}],entries:[a,b,c,d,e].map((id,i)=>({schemaVersion:1,id,templateId,title:'Person '+i,values:{},archived:false}))};
const type={id:parentType,name:'Family',title:'Parent',inverseTitle:'Child',symmetric:false,sourceTemplateIds:[templateId],targetTemplateIds:[templateId],genealogy:{kind:'parent',parentRole:'source',lineage:'adoptive'}};
const partner={...type,id:partnerType,name:'Partners',title:'Partner',inverseTitle:'Partner',symmetric:true,genealogy:{kind:'partner'}};
let relations=R.updateEntryRelationType({schemaVersion:2,types:[],links:[]},type);assert.equal(relations.schemaVersion,4);
relations=R.updateEntryRelationType(relations,partner);
relations=R.saveEntryConnection(relations,world,a,'source',parentType,b);
relations=R.saveEntryConnection(relations,world,c,'target',parentType,b);
relations=R.saveEntryConnection(relations,world,b,'source',parentType,d);
relations=R.saveEntryConnection(relations,world,a,'source',partnerType,e);
assert.equal(relations.links.length,4);
assert.equal(R.connectionProblem(relations,world,R.connectionFromEntry(parentType,c,a,'source')),'ancestry');
assert.equal(R.saveEntryConnection(relations,world,c,'source',parentType,a),relations);
const graph=G.genealogyGraph(world,relations,b,1,0);
assert.deepEqual(new Set(graph.nodes.map(n=>n.id)),new Set([a,b,e]));assert.deepEqual(graph.siblings(c).map(n=>n.id),[d]);
assert(graph.positions[a].y<graph.positions[b].y);assert.equal(graph.parents[0].lineage,'adoptive');
assert.equal(G.genealogyGraph(world,relations,a,0,2).nodes.length,5);
assert.equal(G.genealogyGraph(world,relations,'',1,1).hasCycle,false);
const reverse={...type,genealogy:{kind:'parent',parentRole:'target',lineage:'biological'}};
assert.equal(R.parentConnections({...relations,types:[reverse]}).find(edge=>edge.link.sourceId===a).parentId,b);
const generic={...type,genealogy:undefined};assert.equal(R.parentConnections({...relations,types:[generic]}).length,0,'Names never classify genealogy');
const cyclic={...relations,links:[...relations.links,{id:crypto.randomUUID(),typeId:parentType,sourceId:c,targetId:a}]};
assert.equal(R.hasAncestryCycle(cyclic),true);assert.equal(R.typeUpdateProblem({...cyclic,types:[generic]},type),'ancestry');
const edited=R.saveEntryConnection(relations,world,b,'target',parentType,e,relations.links[0].id);assert.equal(R.parentConnections(edited)[0].parentId,e);
assert.equal(R.removeEntryConnection(edited,edited.links[0].id).links.length,3);
const legacy={schemaVersion:1,types:[generic],links:relations.links.filter(link=>link.typeId===parentType)};assert.equal(R.normalizeEntryRelations(legacy).types[0].genealogy,undefined);
const packet=T.createEntryPackage(world,[a],relations);assert.equal(packet.entryRelations.schemaVersion,4);assert.equal(packet.entryRelations.types[0].genealogy.lineage,'adoptive');
const view={id:crypto.randomUUID(),name:'Network',settings:V.defaultGraphSettings,positions:{},camera:V.defaultGraphCamera};assert.equal(V.saveGraphView(relations,view).schemaVersion,4);
const archived={...world,entries:world.entries.map(entry=>entry.id===a?{...entry,archived:true}:entry)};assert(!G.genealogyGraph(archived,relations,'',1,1).nodes.some(node=>node.id===a));assert(G.genealogyGraph(archived,relations,'',1,1,true).nodes.some(node=>node.id===a));
console.log('Genealogy: explicit meanings, role directions, family focus, siblings, cycles, shared editing, legacy and portable metadata passed.');
const imported=T.importEntries({schemaVersion:1,templates:[],entries:[]},packet,[a]);assert.equal(imported.entryRelations.schemaVersion,4);assert.deepEqual(imported.entryRelations.types[0].genealogy,type.genealogy);assert.equal(R.hasAncestryCycle(imported.entryRelations),false);
const {createRequire}=await import('node:module'),require=createRequire(import.meta.url),React=require('react'),original={useMemo:React.useMemo,useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const Genealogy=loadLocal('../src/Genealogy.tsx').default,{EntryRelationDialog}=loadLocal('../src/RelationshipLibrary.tsx'),I=loadLocal('../src/i18n.ts');
const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
let states=[],index=0,saved,opened;
const render=(Component,props)=>{index=0;return nodes(Component(props));};
try{
 React.useMemo=fn=>fn();React.useState=initial=>{const i=index++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return [states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useRef=value=>({current:value});React.useEffect=()=>{};
 const props={world,relations,onChange(){},onOpenEntry:id=>opened=id,onManage(){}};
 let all=render(Genealogy,props);assert.equal(all.filter(node=>node.props?.className?.startsWith('relation-graph-node')).length,5);
 all.find(node=>node.props?.id==='genealogy-focus').props.onChange(b);all=render(Genealogy,props);
 all.find(node=>node.props?.['aria-label']==='Fewer descendants').props.onClick();all=render(Genealogy,props);all.find(node=>node.props?.['aria-label']==='Fewer descendants').props.onClick();all=render(Genealogy,props);assert.equal(all.filter(node=>node.props?.className?.startsWith('relation-graph-node')).length,3);
 all.find(node=>node.props?.className?.startsWith('relation-graph-node')&&node.props['aria-label']==='Select entry Person 1').props.onClick();all=render(Genealogy,props);all.find(node=>node.type==='button'&&node.props['aria-label']==='Open entry').props.onClick();assert.equal(opened,b);
 states=[];const formProps={world,relations:{schemaVersion:2,types:[{...type,genealogy:undefined}],links:[]},type:{...type,genealogy:undefined},onSave:value=>saved=value,onCancel(){}};
 all=render(EntryRelationDialog,formProps);all.find(node=>node.props?.id==='relationship-meaning').props.onChange('parent');all=render(EntryRelationDialog,formProps);all.find(node=>node.props?.id==='relationship-parent-role').props.onChange('target');all=render(EntryRelationDialog,formProps);all.find(node=>node.props?.id==='relationship-lineage').props.onChange('biological');render(EntryRelationDialog,formProps).find(node=>node.type==='form').props.onSubmit({preventDefault(){}});assert.deepEqual(saved.genealogy,{kind:'parent',parentRole:'target',lineage:'biological'});
 I.setLanguage('es');states=[];all=render(Genealogy,props);assert.equal(all.find(node=>node.type==='svg').props['aria-label'],'Genealogía');assert.equal(all.find(node=>node.props?.id==='genealogy-focus').props.options[0].label,'Sin centrar');
}finally{Object.assign(React,original);I.setLanguage('en');}
console.log('Genealogy UI: focus/depth, node inspection/opening, explicit parent-role/lineage configuration, import and Spanish labels passed.');
// Explicit siblings work without parents and never invent parents or transitive kinship.
const siblingType={...partner,id:crypto.randomUUID(),name:'Siblings',title:'Sibling',inverseTitle:'Sibling',genealogy:{kind:'sibling'}};
let siblingRelations=R.updateEntryRelationType({schemaVersion:2,types:[],links:[]},siblingType);
siblingRelations=R.saveEntryConnection(siblingRelations,world,a,'source',siblingType.id,b);
siblingRelations=R.saveEntryConnection(siblingRelations,world,b,'source',siblingType.id,c);
assert.equal(R.saveEntryConnection(siblingRelations,world,b,'source',siblingType.id,a),siblingRelations);
let family=G.genealogyGraph(world,siblingRelations,a,0,0);
assert.deepEqual(new Set(family.nodes.map(node=>node.id)),new Set([a,b,c]));assert.equal(family.parents.length,0);assert.equal(family.siblingEdges.length,2);assert.equal(family.positions[a].y,family.positions[b].y);assert.deepEqual(family.siblings(a).map(node=>node.id),[b]);
assert.deepEqual(G.genealogyGraph(world,siblingRelations,b,0,0).siblings(b).map(node=>node.id),[a,c]);
const shared=R.saveEntryConnection(R.updateEntryRelationType(relations,siblingType),world,c,'source',siblingType.id,d);
family=G.genealogyGraph(world,shared,c,0,0);assert.deepEqual(new Set(family.nodes.map(node=>node.id)),new Set([c,d]));assert.equal(family.siblingEdges.length,1,'Explicit and inferred siblings share one connector');assert.equal(family.siblings(c).length,1);
assert.equal(G.genealogyGraph(world,relations,c,0,0).siblingEdges.length,1,'Inferred sibling connector is visible when parents are outside the view');
const siblingPacket=T.createEntryPackage(world,[a],siblingRelations),siblingImport=T.importEntries({schemaVersion:1,templates:[],entries:[]},siblingPacket,[a]);assert.equal(siblingImport.entryRelations.types[0].genealogy.kind,'sibling');assert.equal(siblingImport.entryRelations.links.length,2);
const removed=R.removeEntryConnection(siblingRelations,siblingRelations.links[0].id);assert.equal(G.genealogyGraph(world,removed,a,0,0).siblings(a).length,0);
try{
 React.useMemo=fn=>fn();React.useState=initial=>{const i=index++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return [states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useRef=value=>({current:value});React.useEffect=()=>{};states=[];saved=undefined;
 const props={world,relations:siblingRelations,type:siblingType,onSave:value=>saved=value,onCancel(){}};
 let all=render(EntryRelationDialog,props);assert.equal(all.find(node=>node.props?.id==='relationship-meaning').props.value,'sibling');render(EntryRelationDialog,props).find(node=>node.type==='form').props.onSubmit({preventDefault(){}});assert.equal(saved.genealogy.kind,'sibling');
 states=[];all=render(Genealogy,{world,relations:siblingRelations,initialFocusId:a,onChange(){},onOpenEntry(){},onManage(){}});assert.equal(all.filter(node=>node.props?.className==='genealogy-edge sibling').length,2);
}finally{Object.assign(React,original);}
console.log('Explicit siblings: no parents, bidirectional connections, focused tree, no transitive assumptions, inferred deduplication, removal, portable metadata and actual UI passed.');

// Three siblings of the same entry, including links created from the opposite end.
let multiple=siblingRelations;
multiple=R.saveEntryConnection(multiple,world,c,'source',siblingType.id,a);
multiple=R.saveEntryConnection(multiple,world,d,'source',siblingType.id,a);
for(const focus of [a,b,c,d]){
 const group=G.genealogyGraph(world,multiple,focus,0,0);
 assert.deepEqual(new Set(group.nodes.map(node=>node.id)),new Set([a,b,c,d]));
 assert.equal(group.siblingEdges.length,4);
 assert.equal(new Set(Object.values(group.positions).map(point=>JSON.stringify(point))).size,4);
 assert(!group.nodes.some(node=>node.id===e));
}
assert.deepEqual(new Set(G.genealogyGraph(world,multiple,a,0,0).siblings(a).map(node=>node.id)),new Set([b,c,d]));
assert.deepEqual(G.genealogyGraph(world,multiple,d,0,0).siblings(d).map(node=>node.id),[a],'Visible group does not invent sibling connections');
const chain=R.saveEntryConnection(siblingRelations,world,c,'source',siblingType.id,d);
assert.deepEqual(new Set(G.genealogyGraph(world,chain,a,0,0).nodes.map(node=>node.id)),new Set([a,b,c,d]));
assert.deepEqual(G.genealogyGraph(world,chain,a,0,0).siblings(a).map(node=>node.id),[b]);
assert.equal(chain.links.length,3,'Layout does not mutate stored connections');
console.log('Sibling groups: all three siblings and chained connections remain visible from every endpoint without invented kinship.');
