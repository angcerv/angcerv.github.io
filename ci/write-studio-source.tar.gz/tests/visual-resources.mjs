import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
import {createElement} from 'react';import {renderToStaticMarkup} from 'react-dom/server';
const V=loadLocal('../src/visualResources.ts');
const {createEntryPackage,importEntries}=loadLocal('../src/entryTransfer.ts');
const Library=loadLocal('../src/VisualLibrary.tsx').default;
const id=n=>`00000000-0000-0000-0000-${String(n).padStart(12,'0')}`;
const original={schemaVersion:10,templates:[{schemaVersion:10,id:id(1),title:'People',fields:[]}],entries:[{schemaVersion:10,id:id(2),templateId:id(1),title:'First',archived:false,values:{},imageId:id(10)},{schemaVersion:10,id:id(3),templateId:id(1),title:'Second',archived:false,values:{}}]};
const before=JSON.stringify(original);assert.deepEqual(V.entryImageIds(original.entries[0]),[id(10)]);
let world=V.saveVisualResource(original,{id:id(11),title:'  Uniform  ',notes:'A note'});
assert.equal(world.schemaVersion,11);assert.equal(world.templates[0].schemaVersion,11);assert.equal(V.visualResources(world).length,2);assert.equal(JSON.stringify(original),before);
world=V.attachEntryImage(world,id(2),id(11));world=V.attachEntryImage(world,id(3),id(11));world=V.attachEntryImage(world,id(2),id(11));
assert.deepEqual(V.entryImageIds(world.entries[0]),[id(10),id(11)]);assert.equal(world.entries[0].imageId,id(10));assert.throws(()=>V.removeVisualResource(world,id(11)));
world=V.mainEntryImage(world,id(2),id(11));assert.equal(world.entries[0].imageId,id(11));
world=V.detachEntryImage(world,id(2),id(11));assert.equal(world.entries[0].imageId,id(10));assert.equal(V.visualResources(world).length,2);assert.throws(()=>V.removeVisualResource(world,id(11)));
world=V.detachEntryImage(world,id(3),id(11));world=V.removeVisualResource(world,id(11));assert.equal(V.visualResources(world).length,1);
world=V.saveVisualResource(world,{id:id(11),title:'Uniform',notes:'A note'});world=V.attachEntryImage(world,id(2),id(11));world=V.saveVisualResource(world,{id:id(12),title:'Unlinked sheet',notes:''});
const packet=createEntryPackage(world,[id(2)]);assert.equal(packet.worldbuilding.visualResources.length,2);assert(!packet.worldbuilding.visualResources.some(resource=>resource.id===id(12)));
packet.images=[10,11].map(n=>({id:id(n),image:[1],thumbnail:[2]}));
const imported=importEntries(original,packet,[id(2)]);assert.equal(imported.images.length,2);const entry=imported.world.entries.find(e=>e.id===imported.entryId);assert.equal(V.entryImageIds(entry).length,2);assert(!V.entryImageIds(entry).includes(id(10)));assert(imported.world.visualResources.some(resource=>resource.title==='Uniform'&&V.entryImageIds(entry).includes(resource.id)));
const html=renderToStaticMarkup(createElement(Library,{world,onChange(){}}));assert(html.includes('Unlinked sheet'));assert(html.includes('Used by: First'));assert(html.includes('Visual resources'));
const E=loadLocal('../src/encyclopediaExport.ts');const project={id:'p',title:'Story',worldbuilding:world,chapters:[]};const options=E.defaultEncyclopediaOptions(project);const exported=E.exportEncyclopedia(project,options,'html',{[id(10)]:'data:image/png;base64,YQ==',[id(11)]:'data:image/png;base64,Yg=='});assert(exported.includes('gallery-image'));assert(exported.includes('A note'));
let reads=[];await E.encyclopediaImageData(project,options,async imageId=>{reads.push(imageId);return new Blob(['x']);});assert.deepEqual(new Set(reads),new Set([id(10),id(11)]));
console.log('Visual resources: legacy images, schema upgrade, shared galleries, main/fallback/unlink, protected removal, standalone library, portable subset/remapping, HTML and image collection passed.');
// Actual gallery controls update the same shared world and preserve the library on unlink.
const {createRequire}=await import('node:module');const require=createRequire(import.meta.url),React=require('react');const saved={useState:React.useState,useEffect:React.useEffect,useRef:React.useRef};
try{
 React.useState=initial=>[typeof initial==='function'?initial():initial,()=>{}];React.useEffect=()=>{};React.useRef=initial=>({current:initial});
 const {EntryGallery}=loadLocal('../src/VisualLibrary.tsx');const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
 let changed;let tree=nodes(EntryGallery({world,entry:world.entries[0],onChange:next=>changed=next}));
 tree.find(n=>n.props?.['aria-label']==='Set as main image: Uniform').props.onClick();assert.equal(changed.entries[0].imageId,id(11));
 tree=nodes(EntryGallery({world:changed,entry:changed.entries[0],onChange:next=>changed=next}));tree.find(n=>n.props?.['aria-label']==='Unlink image: Uniform').props.onClick();assert.equal(changed.entries[0].imageId,id(10));assert(V.visualResources(changed).some(resource=>resource.id===id(11)));
 // Collapsing retains content but removes it from keyboard and assistive navigation.
 let galleryStates=[],galleryIndex=0;
 React.useState=initial=>{const i=galleryIndex++;if(!(i in galleryStates))galleryStates[i]=typeof initial==='function'?initial():initial;return[galleryStates[i],value=>galleryStates[i]=value];};
 const renderGallery=()=>{galleryIndex=0;return nodes(EntryGallery({world,entry:world.entries[0]}));};
 tree=renderGallery();let toggle=tree.find(n=>n.props?.className==='entry-gallery-toggle');
 assert.equal(toggle.props['aria-expanded'],false);
 assert.equal(tree.find(n=>n.props?.id===toggle.props['aria-controls']).props.inert,true);
 toggle.props.onClick();tree=renderGallery();toggle=tree.find(n=>n.props?.className==='entry-gallery-toggle');
 assert.equal(toggle.props['aria-expanded'],true);assert.equal(tree.find(n=>n.props?.id===toggle.props['aria-controls']).props.inert,false);
 toggle.props.onClick();tree=renderGallery();assert.equal(tree.find(n=>n.props?.className==='entry-gallery-toggle').props['aria-expanded'],false);

 // Unlink through the gallery, then re-render the library against the same live world.
 React.useState=initial=>[typeof initial==='function'?initial():initial,()=>{}];
 let live=V.attachEntryImage(V.attachEntryImage(V.saveVisualResource(original,{id:id(20),title:'Shared portrait',notes:''}),id(2),id(20)),id(3),id(20));
 live={...live,entries:live.entries.map(entry=>entry.id===id(3)?{...entry,archived:true}:entry)};
 const library=()=>nodes(Library({world:live,onChange:next=>live=next}));
 const trashButton=()=>library().find(n=>n.props?.['aria-label']==='Move to trash: Shared portrait');
 const unlink=entryId=>nodes(EntryGallery({world:live,entry:live.entries.find(entry=>entry.id===entryId),onChange:next=>live=next})).find(n=>n.props?.['aria-label']==='Unlink image: Shared portrait').props.onClick();
 assert.equal(trashButton().props.disabled,true);
 unlink(id(2));assert.equal(trashButton().props.disabled,true,'A second, archived entry still protects the image');
 let resourceCard=library().find(n=>n.type==='article'&&nodes(n).some(child=>child.type==='h3'&&child.props.children==='Shared portrait'));
 assert(nodes(resourceCard).some(n=>n.type==='small'&&n.props.children==='Used by: Second'));
 unlink(id(3));assert.equal(trashButton().props.disabled,false,'Last unlink immediately enables trash');
 resourceCard=library().find(n=>n.type==='article'&&nodes(n).some(child=>child.type==='h3'&&child.props.children==='Shared portrait'));
 assert(nodes(resourceCard).some(n=>n.type==='small'&&n.props.children==='No current links'));
 assert(!live.entries.some(entry=>V.entryImageIds(entry).includes(id(20))));
 assert.equal(live.entries[0].imageId,id(10),'Unlink preserves the remaining main portrait');
 trashButton().props.onClick();assert(!V.visualResources(live).some(resource=>resource.id===id(20)));
 assert(V.visualResources(live,true).find(resource=>resource.id===id(20)).deletedAt);
 // A legacy main-only image is retained as a library resource before its last unlink.
 live=structuredClone(original);
 nodes(EntryGallery({world:live,entry:live.entries[0],onChange:next=>live=next})).find(n=>n.props?.['aria-label']==='Unlink image: First').props.onClick();
 assert.equal(live.entries[0].imageId,undefined);assert.deepEqual(live.entries[0].imageIds,[]);
 const legacyDelete=library().find(n=>n.props?.['aria-label']==='Move to trash: First');assert(legacyDelete);assert.equal(legacyDelete.props.disabled,false);
 // Unused originals with variants remain protected for that separate dependency.
 live=V.saveVisualResource(live,{id:id(21),title:'Variant',notes:'',variantOf:id(10)});
 const protectedBase=library().find(n=>n.props?.['aria-label']==='Move to trash: First');assert.equal(protectedBase.props.disabled,true);assert.equal(protectedBase.props.title,'Unlink this image’s variants before removing it.');
 console.log('Gallery/library unlink lifecycle: current usage labels, archived/shared guards, last-unlink deletion, main fallback, legacy main-only images and separate variant protection passed without UI.');
}finally{Object.assign(React,saved);}
