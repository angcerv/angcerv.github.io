import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const React=createRequire(import.meta.url)('react'),Menu=loadLocal('../src/ActionMenu.tsx').default;
const old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect,useLayoutEffect:React.useLayoutEffect,useId:React.useId},oldDocument=globalThis.document,oldWindow=globalThis.window;
let state=[],refs=[],si=0,ri=0,layouts=[],effects=[];
const render=props=>{si=ri=0;layouts=[];effects=[];return Menu(props);};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[],text=n=>Array.isArray(n)?n.map(text).join(''):typeof n==='string'?n:n?.props?text(n.props.children):'';
try{
 React.useState=initial=>{const i=si++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return[state[i],next=>state[i]=typeof next==='function'?next(state[i]):next];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=fn=>effects.push(fn);React.useLayoutEffect=fn=>layouts.push(fn);React.useId=()=> 'books-menu';
 const body={nodeType:1},dialog={nodeType:1};globalThis.document={body};globalThis.window={innerWidth:640,innerHeight:360,addEventListener(){},removeEventListener(){}};
 const props={iconOnly:true,label:'Book options',children:'…',actions:[{label:'Remove empty book',disabled:true,disabledReason:'Move chapters before removing this book.',danger:true,onClick(){throw Error('Disabled action');}}]};
 let tree=render(props),trigger=nodes(tree).find(n=>n.type==='button');trigger.props.ref.current={closest:()=>dialog,getBoundingClientRect:()=>({left:580,right:612,top:280,bottom:312}),focus(){},matches:()=>false};trigger.props.onClick();tree=render(props);layouts.forEach(fn=>fn());tree=render(props);
 const portal=tree.props.children.find(n=>n?.containerInfo);assert.strictEqual(portal.containerInfo,dialog,'A menu in a native dialog must remain in its top layer');const popup=portal.children;assert.equal(popup.props.role,'menu');assert(popup.props.style.width<=616);assert(popup.props.style.maxHeight<=336);assert(popup.props.style.bottom!==undefined,'Menus near the bottom open upwards');const item=nodes(popup).find(n=>n.props?.role==='menuitem');assert(item.props.disabled);assert(text(item).includes('Move chapters before removing this book.'));
 let prevented=false,stopped=false;tree.props.onKeyDown({key:'Escape',preventDefault(){prevented=true;},stopPropagation(){stopped=true;}});assert(prevented&&stopped,'Escape closes the menu before the dialog can discard edits');tree=render(props);assert(!tree.props.children.some(n=>n?.containerInfo));prevented=stopped=false;tree.props.onKeyDown({key:'Escape',preventDefault(){prevented=true;},stopPropagation(){stopped=true;}});assert(!prevented&&!stopped,'Escape on a closed trigger remains available to the native dialog');
 // A short row menu fits below the trigger even when the generic menu height would flip it.
 const rowProps={...props,variant:'row',actions:[props.actions[0],{label:'Edit details',onClick(){}}]};
 tree=render(rowProps);trigger=nodes(tree).find(n=>n.type==='button');trigger.props.ref.current.getBoundingClientRect=()=>({left:180,right:208,top:200,bottom:228});trigger.props.onClick();tree=render(rowProps);layouts.forEach(fn=>fn());tree=render(rowProps);
 const rowPopup=tree.props.children.find(n=>n?.containerInfo).children;assert.equal(rowPopup.props.style.width,200);assert.equal(rowPopup.props.style.top,234);assert(rowPopup.props.className.includes('action-menu-popup-row'));assert(nodes(tree).find(n=>n.type==='button').props.className.includes('action-menu-row'));
 // Pointer restoration is neutral; keyboard input restores the visible focus treatment.
 let pointerMarked=false,keyboard;
 globalThis.document.addEventListener=(name,fn)=>{if(name==='keydown')keyboard=fn;};globalThis.document.removeEventListener=()=>{};
 trigger=nodes(tree).find(n=>n.type==='button');trigger.props.ref.current.toggleAttribute=(_name,value)=>pointerMarked=value;
 trigger.props.onPointerDown();assert(pointerMarked);tree=render(rowProps);effects.at(-1)();assert(keyboard);keyboard();assert(!pointerMarked);

 // Checkbox actions toggle independently, stay open and participate in keyboard movement.
 state=[];refs=[];let restored=0;
 const checkProps={iconOnly:true,label:'Label visibility',children:'Eye',actions:[{label:'Markers',checked:true,onClick(){checkProps.actions[0].checked=!checkProps.actions[0].checked;}},{label:'Regions',checked:false,onClick(){checkProps.actions[1].checked=!checkProps.actions[1].checked;}}]};
 tree=render(checkProps);trigger=nodes(tree).find(n=>n.type==='button');trigger.props.ref.current={closest:selector=>selector.startsWith('dialog')?dialog:null,getBoundingClientRect:()=>({left:200,right:232,top:50,bottom:82}),focus(){restored++;},matches:()=>false};trigger.props.onClick();tree=render(checkProps);layouts.forEach(fn=>fn());tree=render(checkProps);
 const checkPopup=()=>tree.props.children.find(n=>n?.containerInfo)?.children;
 let checks=nodes(checkPopup()).filter(n=>n.props?.role==='menuitemcheckbox');assert.equal(checks.length,2);assert.deepEqual(checks.map(n=>n.props['aria-checked']),[true,false]);
 checks[0].props.onClick({detail:0});tree=render(checkProps);assert(checkPopup(),'Toggling keeps the popup open');checks=nodes(checkPopup()).filter(n=>n.props?.role==='menuitemcheckbox');assert.deepEqual(checks.map(n=>n.props['aria-checked']),[false,false]);assert.equal(restored,0,'Toggling retains focus on the option');
 let focused=-1;const menuItems=[{focus(){focused=0;}},{focus(){focused=1;}}];globalThis.document.activeElement=menuItems[0];checkPopup().props.ref.current={querySelectorAll:selector=>{assert(selector.includes('menuitemcheckbox'));return menuItems;}};
 tree.props.onKeyDown({key:'ArrowDown',preventDefault(){}});assert.equal(focused,1);
 tree.props.onKeyDown({key:'Escape',preventDefault(){},stopPropagation(){}});tree=render(checkProps);assert(!checkPopup());assert.equal(restored,1);
 let ordinaryCalls=0;const ordinaryProps={...checkProps,actions:[{label:'Ordinary action',onClick(){ordinaryCalls++;}}]};tree=render(ordinaryProps);nodes(tree).find(n=>n.type==='button').props.onClick();tree=render(ordinaryProps);nodes(checkPopup()).find(n=>n.props?.role==='menuitem').props.onClick({detail:0});tree=render(ordinaryProps);assert(!checkPopup());assert.equal(ordinaryCalls,1,'Ordinary actions retain their closing behavior');

}finally{Object.assign(React,old);if(oldDocument===undefined)delete globalThis.document;else globalThis.document=oldDocument;if(oldWindow===undefined)delete globalThis.window;else globalThis.window=oldWindow;}
console.log('Book menus: native-dialog portal, readable disabled reason, bounded upward placement and nested Escape handling passed without launching a UI.');
