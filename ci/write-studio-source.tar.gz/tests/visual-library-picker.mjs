import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const React=createRequire(import.meta.url)('react');
const saved={useState:React.useState,useId:React.useId,useRef:React.useRef};
const world={schemaVersion:12,templates:[],entries:[],visualResources:[
 {id:'one',title:'Uniform',notes:'',category:'wardrobe'},
 {id:'two',title:'Emblem',notes:'',category:'emblem'},
 {id:'three',title:'Existing',notes:''},
 {id:'four',title:'Trashed',notes:'',deletedAt:1}
]};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
let state=[],index=0,chosen,closed=false;
try{
 React.useId=()=> 'picker';
 React.useRef=()=>({current:null});
 React.useState=initial=>{const i=index++;if(!(i in state))state[i]=initial;return[state[i],value=>state[i]=typeof value==='function'?value(state[i]):value];};
 const Picker=loadLocal('../src/VisualLibraryPicker.tsx').default;
 const render=()=>{index=0;return nodes(Picker({world,excluded:['three'],onClose:()=>closed=true,onChoose:ids=>chosen=ids}));};
 const cards=tree=>tree.filter(n=>n.props?.className==='visual-picker-card');
 let tree=render();assert.deepEqual(cards(tree).map(n=>n.props.title),['Uniform','Emblem']);
 assert(tree.find(n=>n.props?.className==='primary-button').props.disabled);
 cards(tree)[0].props.onClick({currentTarget:null});tree=render();assert.equal(cards(tree)[0].props['aria-pressed'],true);assert.equal(chosen,undefined);
 tree.find(n=>n.props?.type==='search').props.onChange({target:{value:'Emblem'}});
 tree=render();assert.equal(cards(tree).length,1);
 tree.find(n=>n.props?.children==='Select visible images').props.onClick();tree=render();
 tree.find(n=>n.props?.className==='primary-button').props.onClick();assert.deepEqual(chosen,['one','two']);
 cards(tree)[0].props.onClick({currentTarget:null});tree=render();assert.equal(cards(tree)[0].props['aria-pressed'],false);
 tree.find(n=>n.props?.children==='Clear selection').props.onClick();tree=render();assert(tree.find(n=>n.props?.className==='primary-button').props.disabled);
 tree.find(n=>n.props?.children==='Cancel').props.onClick();assert(closed);
 // Commit errors remain visible and preserve the staged selection.
 state=[];index=0;
 const failed=()=>{index=0;return nodes(Picker({world,excluded:[],onClose(){},onChoose(){throw new Error('A gallery can contain up to 256 images.');}}));};
 tree=failed();cards(tree)[0].props.onClick({currentTarget:null});tree=failed();tree.find(n=>n.props?.className==='primary-button').props.onClick();tree=failed();assert(tree.some(n=>n.props?.role==='alert'));assert.equal(cards(tree)[0].props['aria-pressed'],true);
}finally{Object.assign(React,saved);}
console.log('Library picker: exclusions/trash, staged multi-selection across filtering, bulk selection, deselection, cancel and commit error retention passed.');
