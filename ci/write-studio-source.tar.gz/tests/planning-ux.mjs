import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const require=createRequire(import.meta.url),React=require('react');
require.extensions['.css']=()=>{};
const Actions=loadLocal('../src/ManuscriptActions.tsx').default;
const Plots=loadLocal('../src/PlotsEditor.tsx').default,Arcs=loadLocal('../src/CharacterArcsEditor.tsx').default,Canvas=loadLocal('../src/IdeaCanvasEditor.tsx').default;
const old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect,useMemo:React.useMemo,useContext:React.useContext};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
const noop=()=>{};
const project={id:'p',title:'Story',chapters:[],worldbuilding:{templates:[],entries:[]},plots:{schemaVersion:2,threads:[],arcs:[]},ideaCanvases:{schemaVersion:2,boards:[{id:'board',title:'Ideas',nodes:[],edges:[]}]}};
const toolbar=nodes(Actions({hasChapter:true,hasScene:true,mode:'planning',commentCount:12,onComments:noop,onCheckpoints:noop,onAddScene:noop,onToggleTools:noop,onToggleWorld:noop,onFocus:noop,toolsTrigger:null,toolsOpen:false,worldOpen:false}));
assert(!toolbar.some(n=>n.props?.className==='manuscript-view-actions'));assert.equal(toolbar.find(n=>n.type?.name==='ActionMenu').props.actions.length,1);assert.equal(toolbar.find(n=>n.props?.className==='compact-count').props['data-empty'],true);
const stores=new Map();let state=[],index=0;
function render(Component,props){state=stores.get(Component)??[];stores.set(Component,state);index=0;return nodes(Component(props));}
try{
 React.useState=initial=>{const i=index++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return[state[i],next=>state[i]=typeof next==='function'?next(state[i]):next];};
 React.useRef=initial=>({current:initial});React.useEffect=noop;React.useMemo=fn=>fn();React.useContext=()=>null;
 for(const [Editor,label,input] of [[Plots,'New plot','new-plot-title'],[Arcs,'New arc','arc-create-title']]){
  let tree=render(Editor,{project,plotId:'',arcId:'',onSelect:noop,onChange:noop,onOpenScene:noop,onOpenEntry:noop});
  tree.find(n=>n.type==='button'&&n.props.children?.includes(label)).props.onClick();tree=render(Editor,{project,plotId:'',arcId:'',onSelect:noop,onChange:noop,onOpenScene:noop,onOpenEntry:noop});
  const dialog=tree.find(n=>['PlotDialog','ArcDialog'].includes(n.type?.name));assert(dialog);
  let closes=0;const props={...dialog.props,onCancel:()=>closes++,onClose:()=>closes++};
  tree=render(dialog.type,props);tree.find(n=>n.type==='dialog').props.onCancel({preventDefault(){}});assert.equal(closes,1,'Untouched forms close without confirmation');
  tree.find(n=>n.props?.id===input).props.onChange({target:{value:'Keep my draft'}});
  tree=render(dialog.type,props);tree.find(n=>n.type==='dialog').props.onCancel({preventDefault(){}});tree=render(dialog.type,props);assert.equal(closes,1);assert.equal(tree.find(n=>n.type==='form').props.hidden,true);
  const confirmation=tree.find(n=>n.type?.name==='ProjectModal');assert(confirmation);confirmation.props.onClose();tree=render(dialog.type,props);assert.equal(tree.find(n=>n.props?.id===input).props.value,'Keep my draft');
  tree.find(n=>n.type==='dialog').props.onCancel({preventDefault(){}});tree=render(dialog.type,props);tree.find(n=>n.type==='button'&&n.props.children==='Discard changes').props.onClick();assert.equal(closes,2);
 }
 const props={project,path:'',onChange:noop};let tree=render(Canvas,props);tree.find(n=>n.type==='button'&&n.props.children?.includes('Add note')).props.onClick();tree=render(Canvas,props);
 tree.find(n=>n.props?.id==='canvas-note-title').props.onChange({target:{value:'Keep note'}});tree=render(Canvas,props);tree.find(n=>n.type?.name==='ProjectModal'&&n.props.className==='idea-canvas-dialog').props.onClose();tree=render(Canvas,props);
 let confirmation=tree.find(n=>n.type?.name==='ProjectModal'&&n.props.variant==='confirmation');assert(confirmation);assert.equal(tree.find(n=>n.type==='form').props.inert,true);confirmation.props.onClose();tree=render(Canvas,props);assert.equal(tree.find(n=>n.props?.id==='canvas-note-title').props.value,'Keep note');
 tree.find(n=>n.type?.name==='ProjectModal'&&n.props.className==='idea-canvas-dialog').props.onClose();tree=render(Canvas,props);tree.find(n=>n.type==='button'&&n.props.children==='Discard changes').props.onClick();tree=render(Canvas,props);assert(!tree.some(n=>n.type?.name==='ProjectModal'));
 assert(!render(Canvas,{...props,active:false}).some(n=>n.type?.name==='ProjectModal'),'Inactive workspaces never leave native dialogs open');
}finally{Object.assign(React,old);}
console.log('Planning UX: clean close, guarded plot/arc creation drafts, retained hidden forms, explicit discard, canvas draft retention/cancellation and inactive modal release passed without UI.');
