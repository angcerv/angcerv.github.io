import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
import {loadLocal} from './load-local.mjs';
const {drawingSvg}=loadLocal('../src/mapDrawing.ts'),{previewTerrainStroke,terrainOpacity}=loadLocal('../src/mapTerrain.ts'),{updateMap}=loadLocal('../src/maps.ts'),{expandMapCanvas}=loadLocal('../src/mapCanvasExpansion.ts');
const {recentMaterialPresets,drawingObjectStyle}=loadLocal('../src/drawingToolPresets.ts');
const stroke={kind:'land',material:'grass',color:'#819565',textureIntensity:.3,width:.08,softness:.6,opacity:.4,points:[{x:.2,y:.2},{x:.5,y:.4}]},base={width:1600,height:1000,strokes:[],objects:[]};
const legacy={...stroke};delete legacy.opacity;
assert.equal(drawingSvg({...base,strokes:[legacy]}),drawingSvg({...base,strokes:[{...legacy,opacity:1}]}),'Opaque legacy artwork remains byte-identical');
const translucent=drawingSvg({...base,strokes:[stroke,{...stroke}]}),opaque=drawingSvg({...base,strokes:[legacy,{...legacy}]});
assert.equal((translucent.match(/data-terrain-material="grass"/g)??[]).length,2,'Separate translucent passes accumulate rather than being merged');
assert.equal((opaque.match(/data-terrain-material="grass"/g)??[]).length,1,'Opaque material passes retain their existing idempotence');
assert.equal((translucent.match(/pointer-events="none" opacity="0.4"/g)??[]).length,2);
assert(previewTerrainStroke(stroke,1600,1000).includes('opacity="0.4"'));
const solid={...stroke,material:undefined,softness:undefined},erase={kind:'land',erase:true,width:.1,opacity:.5,points:[{x:.2,y:.2}]};
const solidSvg=drawingSvg({...base,strokes:[solid,{...solid}]}),eraseSvg=drawingSvg({...base,strokes:[stroke,erase,{...stroke,opacity:.6}]}),contourSvg=drawingSvg({...base,strokes:[{...stroke,softness:undefined,closed:true,points:[{x:.1,y:.1},{x:.8,y:.1},{x:.5,y:.8}]}]});
assert.equal((solidSvg.match(/<g opacity="0.4">/g)??[]).length,2);assert(eraseSvg.includes('<g opacity="0.5">'));assert(eraseSvg.includes('data-terrain-erased="true"'));assert(contourSvg.includes('opacity="0.4"'));
assert.equal(terrainOpacity(Number.NaN),1);assert.equal(terrainOpacity(-1),0);
const ids=[...eraseSvg.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(ids.length,new Set(ids).size);for(const match of eraseSvg.matchAll(/(?:url\(#|href="#)([^)" ]+)/g))assert(ids.includes(match[1]),match[1]);
const xml=spawnSync('python3',['-c','import json,sys,xml.etree.ElementTree as E\nfor svg in json.load(sys.stdin): E.fromstring(svg)'],{input:JSON.stringify([translucent,solidSvg,eraseSvg,contourSvg]),encoding:'utf8'});assert.equal(xml.status,0,xml.stderr);
const savedMap={id:'m',imageId:'i',markers:[],drawing:{...base,strokes:[stroke]}};assert.equal(updateMap({schemaVersion:24,maps:[savedMap]},savedMap).schemaVersion,25);assert.equal(expandMapCanvas(savedMap,{left:100,right:100,top:0,bottom:0}).drawing.strokes[0].opacity,.4);assert.equal(JSON.parse(JSON.stringify(savedMap)).drawing.strokes[0].opacity,.4);
const recipes=recentMaterialPresets([stroke,{...stroke,points:[{x:.8,y:.8}]},{...stroke,erase:true},{...stroke,material:'mud'}],['grass']);assert.equal(recipes.length,1);assert.equal(recipes[0].opacity,.4);assert.equal(recipes[0].softness,.6);assert(!('points' in recipes[0]));
assert.equal(recentMaterialPresets(Array.from({length:100},(_,index)=>({...stroke,opacity:index/100})),['grass']).length,6);
assert.equal(drawingObjectStyle({kind:'label',size:.04}).color,'#303c35');assert.equal(drawingObjectStyle({kind:'label',size:.04}).halo,'#f5efd6');assert.equal(drawingObjectStyle({kind:'line',size:.04}).color,'#465648');
const source={id:'label',kind:'label',text:'SOURCE TEXT',color:'#123456',halo:'#c0ffee',size:.04,x:.2,y:.2,layerId:'source-layer'};const style=drawingObjectStyle(source);for(const key of ['id','text','x','y','points','layerId'])assert(!(key in style));
const React=createRequire(import.meta.url)('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect},Editor=loadLocal('../src/MapDrawingEditor.tsx').default;
let state=[],refs=[],si=0,ri=0;
const objects=[{...source,layerId:undefined},{id:'symbol',kind:'castle',color:'#cc8844',rotation:45,size:.08,x:.6,y:.6},{id:'ellipse',kind:'ellipse',color:'#2468ab',fill:'#ffcc99',lineWidth:.007,size:.065,x:.4,y:.4,endX:.6,endY:.6},{id:'path',kind:'path',color:'#222222',lineWidth:.004,smooth:true,dashed:true,size:.065,x:.2,y:.2,points:[{x:.2,y:.2},{x:.5,y:.7}]}];
const projectMap={id:'m',title:'Map',imageId:'i',markers:[],drawing:{...base,strokes:[stroke],objects}},surface={getBoundingClientRect:()=>({left:0,top:0,width:800,height:500}),focus(){},setPointerCapture(){},hasPointerCapture:()=>true,releasePointerCapture(){}};
const nodes=n=>{if(n&&typeof n.type==='function'&&n.type.name==='DrawingToolRail')return nodes(n.type(n.props));return Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];};
const event=(x,y)=>({clientX:x,clientY:y,pointerId:1,button:0,isPrimary:true,currentTarget:surface,target:{closest:()=>null},preventDefault(){},stopPropagation(){}});
try{
 React.useState=initial=>{const i=si++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return[state[i],value=>state[i]=typeof value==='function'?value(state[i]):value];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 const render=()=>{si=ri=0;return nodes(Editor({map:projectMap,path:'/project',projectId:'p',onCancel(){},onSave(){}}));};
 const field=id=>render().find(n=>n.props?.id===id),canvas=()=>render().find(n=>n.props?.['aria-label']==='Map drawing canvas'),button=label=>render().find(n=>n.type==='button'&&(n.props['aria-label']===label||n.props.children?.includes?.(label)));
 render();state[3]='image';state[4]=true;refs[1].current=surface;
 const select=id=>render().find(n=>n.type?.name==='DrawingLayersPanel').props.onSelectObject(id);
 for(const id of ['label','symbol','ellipse','path']){
  select(id);const before=JSON.stringify(state[0]),history=state[1].length;button('Copy style').props.onClick();render();assert.equal(JSON.stringify(state[0]),before);assert.equal(state[1].length,history,'Copying appearance is tool state, not a content edit');
  if(id==='label'){assert.equal(field('drawing-label').props.value,'');field('drawing-label').props.onChange({target:{value:'New label'}});}
  canvas().props.onPointerDown(event(100,100));if(id==='ellipse'||id==='path'){canvas().props.onPointerMove(event(200,150));canvas().props.onPointerUp(event(300,200));}
  const created=state[0].objects.at(-1),original=objects.find(o=>o.id===id);assert.notEqual(created.id,original.id);assert.equal(created.color,original.color);assert.equal(created.layerId,undefined);assert.notEqual(created.x,original.x);
  if(id==='label'){assert.equal(created.text,'New label');assert.equal(created.halo,original.halo);assert.equal(created.size,original.size);}
  if(id==='symbol'){assert.equal(created.kind,'castle');assert.equal(created.rotation,45);assert.equal(created.size,.08);}
  if(id==='ellipse'){assert.equal(created.fill,original.fill);assert.equal(created.lineWidth,original.lineWidth);}
  if(id==='path'){assert.equal(created.smooth,true);assert.equal(created.dashed,true);assert.equal(created.lineWidth,.004);assert.notDeepEqual(created.points,original.points);}
 }
 button('Terrain').props.onClick();const beforeRecipe=JSON.stringify(state[0]);button('Reuse Grass material settings').props.onClick();assert.equal(JSON.stringify(state[0]),beforeRecipe);assert.equal(field('drawing-brush-opacity').props.value,.4);assert.equal(field('drawing-brush-size').props.value,.08);assert.equal(field('drawing-brush-softness').props.value,.6);assert.equal(field('drawing-texture-intensity').props.value,.3);assert(button('Reuse Grass material settings').props['aria-pressed']);
 canvas().props.onPointerDown(event(100,100));canvas().props.onPointerMove(event(200,150));canvas().props.onPointerUp(event(300,200));assert.equal(state[0].strokes.length,2);assert.equal(state[0].strokes[1].opacity,.4);assert.equal(state[0].strokes[1].textureIntensity,.3);
 button('Undo').props.onClick();assert.equal(state[0].strokes.length,1);assert.equal(field('drawing-brush-opacity').props.value,.4);button('Redo').props.onClick();assert.equal(state[0].strokes.length,2);
 field('drawing-brush-opacity').props.onChange({target:{value:'.7'}});const beforeCancel=JSON.stringify(state[0]);canvas().props.onPointerDown(event(100,100));canvas().props.onPointerMove(event(200,150));canvas().props.onPointerCancel(event(200,150));assert.equal(JSON.stringify(state[0]),beforeCancel);assert(!recentMaterialPresets(state[0].strokes,['grass']).some(preset=>preset.opacity===.7));
 field('drawing-brush-opacity').props.onChange({target:{value:'0'}});canvas().props.onPointerDown(event(100,100));assert.equal(JSON.stringify(state[0]),beforeCancel,'Zero opacity does not leave an invisible stroke');
}finally{Object.assign(React,old);}
console.log('Drawing tools: visual material recipes, bounded/theme-scoped recents, style-only copying for text/symbols/shapes/paths, non-destructive tool changes, per-stroke alpha accumulation, soft/solid/contour/eraser SVG integrity, schema retention, expansion, cancel and undo/redo passed without UI.');
