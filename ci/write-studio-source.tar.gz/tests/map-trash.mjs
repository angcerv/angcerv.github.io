// Pure map state checks, without rendering or launching the app.
import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const M=loadLocal('../src/maps.ts');
const map={id:'map',title:'Darhaek',notes:'Notes',imageId:'image',markers:[{id:'a',entryId:'place',title:'Port',notes:'',x:.2,y:.3,color:'teal',icon:'city',layerId:'layer'},{id:'b',title:'Forest',notes:'',x:.5,y:.6,color:'teal',icon:'forest'}],routes:[{id:'route',title:'Journey',notes:'',color:'teal',markerIds:['a','b'],sceneIds:['scene'],chapterIds:['chapter']}],layers:[{id:'layer',title:'Places',visible:true}],drawing:{width:100,height:100,strokes:[],objects:[]},scale:{from:{x:0,y:0},to:{x:1,y:1},aspectRatio:1,distanceKm:100,travelKmPerDay:10}};
const original={schemaVersion:15,maps:[map]};const snapshot=JSON.stringify(original);
const trash=M.trashMap(original,'map',123);assert.equal(trash.schemaVersion,16);assert.deepEqual(trash.maps,[]);assert.deepEqual(trash.trash,[{map,deletedAt:123}]);assert.equal(JSON.stringify(original),snapshot);
assert.equal(M.trashMap(trash,'map'),trash);assert.deepEqual(M.entryMapLocations(trash,'place'),[]);
const restored=M.restoreMap(trash,'map');assert.deepEqual(restored.maps,[map]);assert.deepEqual(restored.trash,[]);assert.equal(restored.schemaVersion,16);
assert.deepEqual(M.permanentlyRemoveMap(trash,'map').trash,[]);assert.equal(M.permanentlyRemoveMap(restored,'map'),restored);
const changed=M.updateMap(trash,{...map,title:'Unrelated'});assert.deepEqual(changed.trash,trash.trash);
console.log('Map trash: complete snapshots, stable IDs, scene/entry links, drawings/layers/scale, restoration, permanent deletion and immutability passed.');

// Confirmation mode changes dimensions without discarding the underlying list.
const {createRequire}=await import('node:module');
const React=createRequire(import.meta.url)('react'),Trash=loadLocal('../src/VisualLibrary.tsx').ProjectTrash;
const oldHooks={useState:React.useState,useRef:React.useRef,useLayoutEffect:React.useLayoutEffect};
let state=[],index=0;
const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
try{
 React.useState=initial=>{const i=index++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return[state[i],next=>state[i]=typeof next==='function'?next(state[i]):next];};
 React.useRef=()=>({current:null});React.useLayoutEffect=()=>{};
 const render=()=>{index=0;return Trash({world:{templates:[],entries:[],visualResources:[]},maps:trash,onMapsChange(){},onChange(){},onClose(){}});};
 let tree=render();assert.equal(tree.props.variant,undefined);
 nodes(tree).find(node=>node.props?.['aria-label']==='Permanently delete Darhaek').props.onClick({currentTarget:{isConnected:true,focus(){}}});
 tree=render();assert.equal(tree.props.variant,'confirmation');
 assert.equal(nodes(tree).find(node=>node.props?.className==='visual-trash-content').props.hidden,true);
 nodes(tree).find(node=>node.type==='button'&&node.props.children==='Cancel').props.onClick();
 tree=render();assert.equal(tree.props.variant,undefined);
 assert.equal(nodes(tree).find(node=>node.props?.className==='visual-trash-content').props.hidden,false);
}finally{Object.assign(React,oldHooks);}
console.log('Trash confirmation: content-sized modal variant and return to the retained list passed without UI.');
