import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const C=loadLocal('../src/mapWorkCamera.ts');
for(const image of [{width:1600,height:1000},{width:600,height:1800}]){
 const fit={width:640,height:640*image.height/image.width},view={zoom:2.3,x:123,y:-48};
 const shared=C.elementsWorkCamera(view,fit,image),drawViewport={width:1100,height:720};
 const drawing=C.workDrawingCamera(shared,drawViewport,image),back=C.drawingWorkCamera(drawing,1,drawViewport,image),restored=C.workElementsCamera(back,fit,image);
 for(const key of ['zoom','x','y'])assert(Math.abs(view[key]-restored[key])<1e-9);
 const narrow={width:350,height:480};const moved=C.workDrawingCamera(back,narrow,image);
 assert.deepEqual(C.drawingWorkCamera(moved,1,narrow,image),back,'Changing pane size retains the same map centre and physical scale');
}
const React=createRequire(import.meta.url)('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const oldWindow=globalThis.window;globalThis.window={matchMedia:()=>({matches:false,addEventListener(){},removeEventListener(){}})};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
let states=[],refs=[],si=0,ri=0;
const drawing={width:1600,height:1000,objects:[],strokes:[]},map={id:'map',title:'Atlas',notes:'',imageId:'asset',markers:[],drawing};
try{
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],next=>states[i]=typeof next==='function'?next(states[i]):next];};
 React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 const Editor=loadLocal('../src/MapsEditor.tsx').default,Drawing=loadLocal('../src/MapDrawingEditor.tsx').default;
 let maps={schemaVersion:20,maps:[map]},tree;
 const render=()=>{si=ri=0;tree=nodes(Editor({maps,world:{templates:[],entries:[],schemaVersion:1},path:'/project',projectId:'p',mapId:'map',markerId:'',onChange:next=>maps=next,onSelectMap(){},onSelectMarker(){},onImport(){},onOpenEntry(){}}));return tree;};
 render();
 const mapMenu=()=>tree.find(n=>n.props?.label==='Map actions'&&n.props.actions);
 const exportAction=()=>mapMenu().props.actions.find(action=>action.label==='Export map as PNG');
 assert(exportAction().disabled,'Export waits for the map image');
 const canvasNode=()=>tree.find(n=>n.type?.name==='MapCanvas');
 assert(!nodes(canvasNode().props.tools).some(n=>n.type?.name==='FieldHelp'),'History no longer has the explanatory help icon');
 canvasNode().props.onExportState({mapId:'map',ready:true,busy:false,status:''});render();assert.equal(exportAction().disabled,false);
 exportAction().onClick();render();assert.equal(canvasNode().props.exportRequest.mapId,'map','Settings queues export on the canonical map canvas');
 canvasNode().props.onExportState({mapId:'map',ready:true,busy:true,status:''});render();assert(exportAction().disabled,'Repeated exports are blocked while busy');
 canvasNode().props.onExportState({mapId:'map',ready:true,busy:false,status:''});render();
 const expand=tree.find(n=>n.type==='button'&&n.props.children?.[1]==='Edit map');assert(expand);expand.props.onClick();render();assert(tree[0].props.className.includes('maps-expanded'));
 assert.equal(tree.find(n=>n.props?.className==='maps-layout maps-workbench').props['data-browser'],false);
 tree.find(n=>n.props?.id==='map-expanded-drawing').props.onClick();render();
 const embedded=tree.find(n=>n.type===Drawing);assert(embedded.props.embedded);assert(embedded.props.active);assert(!tree.some(n=>n.props?.className==='map-expanded-tools'),'Geographic tools stay in their own left toolbar');
 let pending;embedded.props.transitionRef.current=action=>pending=action;
 tree.find(n=>n.type==='button'&&n.props.children?.[1]==='Back to map').props.onClick();render();assert(tree[0].props.className.includes('maps-expanded'),'Returning to map waits for the drawing decision');
 const beforeExport=canvasNode().props.exportRequest;exportAction().onClick();render();assert.equal(canvasNode().props.exportRequest,beforeExport,'Export waits for the drawing decision');pending();render();assert.notEqual(canvasNode().props.exportRequest,beforeExport);
 const menu=tree.find(n=>n.props?.label==='Map actions'&&n.props.actions);menu.props.actions.find(action=>action.label==='Expand canvas').onClick();render();assert(!tree.some(n=>n.type?.name==='MapCanvasExpansionDialog'),'Map actions also wait for the drawing decision');
 tree.find(n=>n.props?.id==='map-expanded-elements').props.onClick();render();assert(tree.find(n=>n.type===Drawing).props.active,'Switch waits for the staged drawing decision');
 pending();render();assert.equal(tree.find(n=>n.type===Drawing).props.active,false);assert(tree.find(n=>n.type===Drawing),'Visited drawing editor stays mounted');
 tree.find(n=>n.type==='button'&&n.props.children?.[1]==='Back to map').props.onClick();render();assert(!tree[0].props.className.includes('maps-expanded'));assert.equal(tree.find(n=>n.props?.className==='maps-layout maps-workbench').props['data-browser'],true);
 render();assert(!tree.some(n=>n.props?.className==='map-open-drawing'));tree.find(n=>n.type==='button'&&n.props.children?.[1]==='Edit map').props.onClick();render();assert.equal(tree.find(n=>n.props?.id==='map-expanded-elements').props['aria-current'],'page');assert(!tree.some(n=>n.type==='button'&&n.props.children?.[1]==='Edit map'));
 // The actual embedded editor protects drafts and completes only the chosen transition.
 states=[];refs=[];const transitionRef={current:null};let transitioned=0,saved=0,cancelled=0;
 const renderDrawing=()=>{si=ri=0;tree=nodes(Drawing({map,path:'/project',projectId:'p',embedded:true,transitionRef,onCancel:()=>cancelled++,onSave:()=>saved++}));};
 renderDrawing();assert.equal(tree[0].props.role,'region');assert.equal(tree[0].props.open,true);assert(!tree.some(n=>n.type==='button'&&n.props['aria-label']==='Close'));
 states[4]=true;renderDrawing();tree.find(n=>n.props?.id==='drawing-theme').props.onChange('space');renderDrawing();
 transitionRef.current(()=>transitioned++);renderDrawing();let prompt=tree.find(n=>n.type?.name==='ProjectModal');assert(prompt);assert.equal(transitioned,0);
 tree.find(n=>n.type==='button'&&n.props.children==='Keep editing').props.onClick();renderDrawing();assert.equal(states[0].theme,'space');assert.equal(transitioned,0);
 transitionRef.current(()=>transitioned++);renderDrawing();tree.find(n=>n.type==='button'&&n.props.children==='Apply drawing'&&n.props.className==='primary-button'&&n!==tree.find(n=>n.type==='button'&&n.props.children==='Apply drawing')).props.onClick();renderDrawing();assert.equal(saved,1);assert.equal(transitioned,1);assert.equal(cancelled,0);assert.equal(states[0].theme,'space');
 transitionRef.current(()=>transitioned++);assert.equal(transitioned,2,'Clean transitions proceed without a prompt');
 tree.find(n=>n.props?.id==='drawing-theme').props.onChange('modern');renderDrawing();transitionRef.current(()=>transitioned++);renderDrawing();tree.find(n=>n.type==='button'&&n.props.children==='Discard changes').props.onClick();renderDrawing();assert.equal(states[0].theme,'space');assert.equal(transitioned,3);assert.equal(saved,1);
 assert(!loadLocal('../src/drawingEditorView.ts').drawingDraftChanged({...drawing,objects:[],strokes:[]},[{id:'a',title:'Layer',visible:true}],{drawing:{objects:[],strokes:[],height:1000,width:1600},layers:[{visible:true,title:'Layer',id:'a',locked:false}]}),'Native key order/defaults do not create phantom drafts');
}finally{Object.assign(React,old);globalThis.window=oldWindow;}
// Background isolation restores pre-existing inert values and leaves body portals available.
const oldHTMLElement=globalThis.HTMLElement,oldDocument=globalThis.document;
class NodeMock{constructor(name){this.name=name;this.inert=false;this.children=[];this.parentElement=null;this.classList={contains:value=>name===value};}append(...nodes){this.children.push(...nodes);for(const node of nodes)node.parentElement=this;}}
try{
 globalThis.HTMLElement=NodeMock;const body=new NodeMock('body'),shell=new NodeMock('app-shell'),pane=new NodeMock('pane'),root=new NodeMock('map'),header=new NodeMock('header'),otherWorkspace=new NodeMock('other'),portal=new NodeMock('portal');
 body.append(shell,portal);shell.append(header,pane);pane.append(root,otherWorkspace);otherWorkspace.inert=true;globalThis.document={body};
 const restore=C.isolateMapWorkspace(root);assert(header.inert);assert(otherWorkspace.inert);assert(!portal.inert);assert(!root.inert);restore();assert(!header.inert);assert(otherWorkspace.inert);
}finally{globalThis.HTMLElement=oldHTMLElement;globalThis.document=oldDocument;}
console.log('Expanded maps: shared camera round trips, retained panes, restored sidebar, protected apply/discard/continue transitions and native-save draft normalization passed without UI.');
