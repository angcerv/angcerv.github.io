import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {layoutMapLabels,regionLabelPoint}=loadLocal('../src/mapLabels.ts');
const {saveMapRegion}=loadLocal('../src/mapRegions.ts');
const {MapElementHistory}=loadLocal('../src/mapElementHistory.ts');
const overlap=(a,b)=>a.x<b.x+b.width&&a.x+a.width>b.x&&a.y<b.y+b.height&&a.y+a.height>b.y;
const items=[{id:'marker',kind:'marker',text:'Aethis',point:{x:.5,y:.5}},{id:'region',kind:'region',text:'Aethor',point:{x:.5,y:.5}}];
for(const [width,height] of [[400,800],[800,400],[1600,800]]){
 const layout=layoutMapLabels(items,width,height),a=layout.get('marker'),b=layout.get('region');
 assert(a.visible&&b.visible);assert(!overlap(a,b));
 for(const box of layout.values()){assert(box.x>=0&&box.y>=0);assert(box.x+box.width<=width);assert(box.y+box.height<=height);}
 assert.deepEqual(layoutMapLabels(items.slice().reverse(),width,height),layout);
}
const crowded=Array.from({length:60},(_,i)=>({...items[1],id:String(i)}));crowded[59].selected=true;
const dense=layoutMapLabels(crowded,320,200);assert(dense.get('59').visible);assert([...dense.values()].some(p=>!p.visible));
const visible=[...dense.values()].filter(p=>p.visible);for(let i=0;i<visible.length;i++)for(let j=i+1;j<visible.length;j++)assert(!overlap(visible[i],visible[j]));
const fixed=layoutMapLabels([{...items[1],fixed:true,point:{x:.3,y:.4}}],1000,500).get('region');assert.equal(fixed.x+fixed.width/2,300);assert.equal(fixed.y+fixed.height/2,200);
const long=layoutMapLabels([{...items[1],text:'W'.repeat(100)}],500,500).get('region');assert(long.text.endsWith('…'));assert(long.width<=190);
const region={id:'r',title:'Region',color:'teal',points:[{x:.1,y:.1},{x:.8,y:.1},{x:.8,y:.8}]};
const maps={schemaVersion:17,maps:[{id:'map',imageId:'image',markers:[],regions:[region]}]},moved={...region,labelPosition:{x:.3,y:.4}};
const next=saveMapRegion(maps,'map',moved);assert.deepEqual(regionLabelPoint(next.maps[0].regions[0]),moved.labelPosition);assert.equal(next.maps[0].regions[0].points,region.points);
for(const point of [{x:NaN,y:0},{x:1.1,y:.2},{x:.2,y:-.1}])assert.equal(saveMapRegion(maps,'map',{...region,labelPosition:point}),maps);
const history=new MapElementHistory();history.record(maps.maps[0],next.maps[0]);const undo=history.move(next.maps[0],'undo');assert.equal(undo.regions[0].labelPosition,undefined);assert.deepEqual(history.move(undo,'redo').regions[0].labelPosition,moved.labelPosition);
assert.equal(saveMapRegion(next,'map',{...moved,labelPosition:undefined}).maps[0].regions[0].labelPosition,undefined);
console.log('Map labels: collision avoidance, crowded priority, proportions, bounds, manual anchors, validation and undo/redo passed without UI.');

const noMarkerNames=layoutMapLabels([{...items[0],show:false},items[1]],800,400);assert(!noMarkerNames.has('marker'));const regionBox=noMarkerNames.get('region');assert(regionBox.visible);assert(!overlap(regionBox,{x:381,y:181,width:38,height:38}));

// Marker names remain close, centered and independent of the map's zoom scale.
const three=[{id:'a',kind:'marker',text:'Ixelion',point:{x:.3,y:.3}},{id:'b',kind:'marker',text:'Hércules',point:{x:.4,y:.5}},{id:'c',kind:'marker',text:'Aethis',point:{x:.6,y:.6}}];
const overview=layoutMapLabels(three,800,600);assert([...overview.values()].every(box=>box.visible));
for(const marker of three){const box=overview.get(marker.id);assert.equal(box.anchor,0);assert(Math.abs(box.x+box.width/2-marker.point.x*800)<.001);assert.equal(box.y-marker.point.y*600,25);}
const remembered=new Map([['a',{...overview.get('a'),anchor:2}]]),snapshot=JSON.stringify([...remembered]);
let previous=remembered;
for(const factor of [1,1.1,1.25,1.5,2,4,8]){const next=layoutMapLabels([three[0]],800*factor,600*factor,{previous});assert.equal(next.get('a').anchor,2,'Keep the chosen side while it remains free');assert.equal(next.get('a').width,overview.get('a').width);assert.equal(next.get('a').height,24);previous=next;}
assert.equal(JSON.stringify([...remembered]),snapshot);
const grid=Array.from({length:30},(_,i)=>({id:'grid-'+i,kind:'marker',text:'Point '+i,point:{x:.2+(i%6)*.1,y:.2+Math.floor(i/6)*.1}}));
const distant=layoutMapLabels(grid,220,180),close=layoutMapLabels(grid,1760,1440,{previous:distant});assert([...close.values()].filter(p=>p.visible).length>[...distant.values()].filter(p=>p.visible).length,'Zoom reveals names as screen-space becomes available');
const hiddenSelected=layoutMapLabels([{...three[0],show:false,selected:true},{...three[1],show:false}],800,600);assert(hiddenSelected.get('a').visible);assert(!hiddenSelected.has('b'));
const diagonal=layoutMapLabels([three[0]],800,600,{previous:new Map([['a',{...overview.get('a'),anchor:4}]])}).get('a');assert(diagonal.leader);assert(Math.abs(Math.hypot(diagonal.leader.x1,diagonal.leader.y1)-18)<1e-8);assert(diagonal.leader.x2>diagonal.leader.x1);
const selectedLong=layoutMapLabels([{...three[0],selected:true,text:'Very long linked place name '.repeat(10)}],800,600).get('a');assert(selectedLong.visible);assert(selectedLong.height<=60);assert(selectedLong.width<=240);assert(selectedLong.text.replace(/\s+/g,' ').includes('Very long linked place name'));
const viewport={x:300,y:200,width:200,height:200},viewportLayout=layoutMapLabels([{...three[0],selected:true,point:{x:.4,y:.5}},{...three[1],point:{x:.9,y:.5}},{...items[1],fixed:true,point:{x:.1,y:.1}}],1000,600,{viewport});
const inside=viewportLayout.get('a');assert(inside.visible);assert(inside.x>=300&&inside.x+inside.width<=500);assert(inside.y>=200&&inside.y+inside.height<=400);assert(!viewportLayout.get('b').visible);assert.equal(viewportLayout.get('region').x+viewportLayout.get('region').width/2,100,'Manual region anchors never follow the viewport');
console.log('Adaptive markers: close centered names, constant screen size, stable anchors, progressive density, selected/hidden names, leaders, long names and viewport bounds passed.');

const boundary=layoutMapLabels([{...three[0],point:{x:0,y:.5},text:"Name near the viewport edge"}],800,600).get("a");assert(boundary.leader,"A name shifted by the viewport boundary retains a visible connection");
