import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {orderedMapElements,reorderMapElements,mapElementStack}=loadLocal('../src/mapElementOrder.ts');
const {updateMap,trashMap,restoreMap}=loadLocal('../src/maps.ts'),{MapElementHistory}=loadLocal('../src/mapElementHistory.ts');
const marker=(id,layerId)=>({id,layerId,title:id,x:.5,y:.5,color:'teal',icon:'city'});
const map={id:'map',imageId:'image',layers:[{id:'back',visible:true},{id:'front',visible:true}],markers:[marker('a','back'),marker('hidden','back'),marker('b','front')],routes:[{id:'route',layerId:'back',markerIds:['a','b'],color:'amber'}],regions:[{id:'region',layerId:'back',color:'teal',points:[{x:0,y:0},{x:1,y:0},{x:1,y:1}]}]};
assert.deepEqual(orderedMapElements(map).map(item=>item.id),['region','route','a','hidden','b']);
const reordered=reorderMapElements(map,['region','a','route']);assert.deepEqual(reordered.elementOrder,['route','a','region','hidden','b']);assert.equal(map.elementOrder,undefined);assert.equal(reordered.markers,map.markers);assert.equal(reordered.routes,map.routes);
assert.deepEqual(orderedMapElements(reordered).map(item=>item.id),reordered.elementOrder);assert(mapElementStack(reordered).get('region')>mapElementStack(reordered).get('a'));
assert.deepEqual(orderedMapElements({...reordered,layers:[...map.layers].reverse()}).map(item=>item.id),['b','route','a','region','hidden']);
assert.equal(reorderMapElements(map,['a','b']),map);assert.equal(reorderMapElements(map,['a','missing']),map);assert.equal(reorderMapElements(map,['a','a']),map);const locked={...map,layers:[{id:'back',visible:true,locked:true}]};assert.equal(reorderMapElements(locked,['region','a']),locked);
const maps=updateMap({schemaVersion:28,maps:[map]},reordered);assert.equal(maps.schemaVersion,29);assert.deepEqual(restoreMap(trashMap(maps,'map',100),'map').maps[0].elementOrder,reordered.elementOrder);
const history=new MapElementHistory();history.record(map,reordered);const undone=history.move(reordered,'undo');assert.equal(undone.elementOrder,undefined);assert.deepEqual(history.move(undone,'redo').elementOrder,reordered.elementOrder);
// The same cross-type order is used by the actual PNG renderer.
const {renderMapPng}=loadLocal('../src/mapExport.ts');const calls=[];const ctx=new Proxy({measureText:()=>({width:0})},{get:(target,key)=>target[key]??((...args)=>calls.push([key,...args]))});
const old=globalThis.document;globalThis.document={createElement:()=>({getContext:()=>ctx,toBlob:callback=>callback(new Blob(['png']))})};
try{await renderMapPng({naturalWidth:100,naturalHeight:100},reordered,{entries:[]},map.markers,map.routes,false,100,new Map(),map.regions);assert.deepEqual(calls.filter(call=>['arc','fill','stroke'].includes(call[0])).map(call=>call[0]),['stroke','stroke','arc','fill','stroke','fill','stroke','arc','fill','stroke','arc','fill','stroke']);}finally{globalThis.document=old;}
console.log('Mixed map order: cross-type stacking, layer precedence, filtered slots, locks, schema/trash/history and actual PNG paint order passed without UI.');
