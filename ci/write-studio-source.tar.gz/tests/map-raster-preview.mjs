import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {rasterPreviewSize,previewSvgSource,rasterizeSvgPreview}=loadLocal('../src/mapRasterPreview.ts');
for(const [width,height] of [[1600,1000],[10000,10000],[90000,500],[500,90000]]){
 const size=rasterPreviewSize(width,height);assert(size.width<=2048&&size.height<=2048);assert(size.width*size.height<=2_000_000);assert(size.width>0&&size.height>0);
}
const source=previewSvgSource('<rect width="1600" height="1000" fill="#408599"/>',1600,1000);assert(decodeURIComponent(source).includes('viewBox="0 0 1600 1000"'));
const originals={Image:globalThis.Image,document:globalThis.document,create:URL.createObjectURL,revoke:URL.revokeObjectURL};
let images=[],canvases=[],urls=0,draws=0;
const tick=()=>new Promise(resolve=>setTimeout(resolve,5));
try{
 globalThis.Image=class{onload=null;onerror=null;value='';set src(value){this.value=value;if(value)images.push(this);}get src(){return this.value;}};
 globalThis.document={createElement(name){assert.equal(name,'canvas');const canvas={width:0,height:0,getContext(){return{drawImage(image,x,y,width,height){assert(width*height<=2_000_000);draws++;}};},toBlob(callback,type){assert.equal(type,'image/png');callback(new Blob(['png']));}};canvases.push(canvas);return canvas;}};
 URL.createObjectURL=()=>`blob:preview-${++urls}`;URL.revokeObjectURL=()=>{};
 const first=new AbortController(),queued=new AbortController(),third=new AbortController();
 const a=rasterizeSvgPreview(source,12000,8000,first.signal),b=rasterizeSvgPreview(source,3000,3000,queued.signal);queued.abort();assert.equal(await b,undefined);await tick();assert.equal(images.length,1,'Large preview decoding is serialized, never concurrent per layer');
 const c=rasterizeSvgPreview(source,4000,4000,third.signal);await tick();assert.equal(images.length,1);assert(/width="1732" height="1154"/.test(decodeURIComponent(images[0].src)));images[0].onload();assert.equal(await a,'blob:preview-1');await tick();assert.equal(images.length,2);assert.equal(draws,1);assert.equal(canvases[0].width,0,'Release temporary canvas memory after encoding');
 third.abort();assert.equal(await c,undefined);assert.equal(canvases[1].width,0);assert.equal(images[1].src,'');
 const failed=new AbortController(),d=rasterizeSvgPreview(source,1600,1000,failed.signal);await tick();images.at(-1).onerror();assert.equal(await d,undefined,'Decode failure permits SVG fallback and does not block later work');
 const done=new AbortController(),e=rasterizeSvgPreview(source,1600,1000,done.signal);await tick();images.at(-1).onload();assert.equal(await e,'blob:preview-2');
}finally{if(originals.Image===undefined)delete globalThis.Image;else globalThis.Image=originals.Image;if(originals.document===undefined)delete globalThis.document;else globalThis.document=originals.document;URL.createObjectURL=originals.create;URL.revokeObjectURL=originals.revoke;}
console.log('Map zoom previews: bounded pixel/edge budgets, stable map coordinates, serialized decoding, queued/active cancellation, released buffers and error recovery passed using mocks only.');
