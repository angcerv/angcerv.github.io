// File/data checks only. No UI, component rendering or browser.
import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {loreModeTarget,loreOverviewId,revealLoreSection,loreArticleGroups,loreIntroduction,hasLoreValue}=loadLocal('../src/worldLore.ts');
assert.equal(loreModeTarget(true,'lore-section-basic'),loreOverviewId);
assert.equal(loreModeTarget(false,loreOverviewId),'');
assert.equal(loreModeTarget(false,'lore-section-history'),'lore-section-history');
let scroll;assert(revealLoreSection({scrollTo:options=>scroll=options},loreOverviewId));assert.deepEqual(scroll,{top:0,behavior:'instant'});
const template={id:'t',fields:[{id:'description',label:'Descripción',fieldType:'longText'},{id:'zero',label:'Count',fieldType:'number'},{id:'flag',label:'Known',fieldType:'boolean'}]};
const entry={id:'a',values:{description:'Short introduction',zero:0,flag:false}};
const before=JSON.stringify({template,entry});assert.equal(loreIntroduction(template,entry).id,'description');
const fields=loreArticleGroups(template,entry).flatMap(group=>group.fields);assert(!fields.some(field=>field.id==='description'));assert(fields.some(field=>field.id==='zero'));assert(fields.some(field=>field.id==='flag'));
assert(hasLoreValue(template.fields[1],0));assert(hasLoreValue(template.fields[2],false));assert.equal(JSON.stringify({template,entry}),before);
console.log('Encyclopedia navigation: reading starts at the article top, edit section context survives, introduction is unique and zero/false values and source data are preserved.');
