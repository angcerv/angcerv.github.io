import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import ts from 'typescript';
import postcss from 'postcss';
const source=readFileSync(new URL('../src/floatingPanelPosition.ts',import.meta.url),'utf8');
const js=ts.transpileModule(source,{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.ES2022}}).outputText;
const {floatingPanelPosition}=await import(`data:text/javascript;base64,${Buffer.from(js).toString('base64')}`);
for(const [width,height] of [[480,360],[760,600],[1024,768],[1440,900]]) {
 for(const rect of [{left:12,right:44,top:12,bottom:44},{left:width-44,right:width-12,top:height-44,bottom:height-12},{left:width/2,right:width/2+32,top:height/2,bottom:height/2+32}]) {
  for(const [preferredWidth,preferredHeight] of [[280,360],[440,560]]) {
   const result=floatingPanelPosition(rect,{width,height},preferredWidth,preferredHeight);
   assert.ok(result.left>=12);assert.ok(result.left+result.width<=width-12);
   assert.ok(result.maxHeight>=0);
   if('top' in result) {assert.ok(result.top>=12);assert.ok(result.top+result.maxHeight<=height-12);}
   else {assert.ok(result.bottom>=12);assert.ok(height-result.bottom-result.maxHeight>=12);}
  }
 }
}
assert.ok('bottom' in floatingPanelPosition({left:400,right:440,top:540,bottom:572},{width:480,height:600}));
assert.ok('top' in floatingPanelPosition({left:12,right:44,top:12,bottom:44},{width:480,height:600}));
// Parse the real CSS tokens, so changing either palette also checks small-label contrast.
const styles=postcss.parse(readFileSync(new URL('../src/styles/semantic-status.css',import.meta.url),'utf8'));
const hex=text=>text.replace('#','').match(/../g).map(value=>parseInt(value,16));
const luminance=rgb=>rgb.map(value=>value/255).map(value=>value<=.04045 ? value/12.92 : ((value+.055)/1.055)**2.4).reduce((sum,value,index)=>sum+value*[.2126,.7152,.0722][index],0);
for(const [selector,ink] of [[':root','#ececed'],[':root[data-theme=light]','#25292b']]) {
 const tokens={};styles.walkRules(':root',rule=>rule.walkDecls(decl=>tokens[decl.prop]=decl.value));styles.walkRules(selector,rule=>rule.walkDecls(decl=>tokens[decl.prop]=decl.value));
 const resolve=value=>value.startsWith('var(')?resolve(tokens[value.slice(4,-1)]):value;
 for(const status of ['notStarted','draft','inReview','finished']) {
  const fg=hex(resolve(tokens[`--writing-${status}-fg`])), bg=hex(resolve(tokens[`--writing-${status}-bg`]));
  const mixed=fg.map((channel,index)=>channel*.65+hex(ink)[index]*.35);
  const light=Math.max(luminance(mixed),luminance(bg)),dark=Math.min(luminance(mixed),luminance(bg));
  assert.ok((light+.05)/(dark+.05)>=4.5,`${selector} ${status} text must remain readable`);
 }
}
const entry=postcss.parse(readFileSync(new URL('../src/workspace.css',import.meta.url),'utf8'));
let imports=0;entry.walkAtRules('import',rule=>{imports++;const path=rule.params.slice(1,-1);postcss.parse(readFileSync(new URL('../src/'+path,import.meta.url),'utf8'));});assert.equal(imports,14);
// Resolve the competing legacy/new declarations: the filter row moved from a
// wrapping horizontal toolbar into a vertical workspace. A 100% basis here
// hides the entire grid, even with no active filters and valid event data.
const timelineStyles=postcss.parse(readFileSync(new URL('../src/styles/timeline.css',import.meta.url),'utf8'));
function classProperty(classes,property){
 const declarations=[];
 timelineStyles.walkRules(rule=>{
  if(rule.parent.type!=='root')return;
  for(const selector of rule.selector.split(',')){
   const parts=selector.trim().split(/\s+/);
   if(!parts.every(part=>/^(\.[\w-]+)+$/.test(part)))continue;
   const required=selector.match(/[\w-]+/g)??[];
   if(!required.every(name=>classes.includes(name)))continue;
   rule.walkDecls(property,decl=>declarations.push({value:decl.value,specificity:required.length}));
  }
 });
 return declarations.sort((a,b)=>a.specificity-b.specificity).at(-1)?.value;
}
for(const view of ['timeline-visual-view','timeline-list-view']){
 assert.equal(classProperty(['timeline-workspace','timeline-active-filters',view],'flex-basis'),'auto','Filter chips must occupy their content height, leaving space for events and both side panels');
 assert.equal(classProperty(['timeline-workspace','timeline-chart','timeline-comparison',view],'align-self'),'stretch','Chart must fill the center column rather than inherit legacy start alignment');
}
console.log('UI layout: floating panels stay within small/medium/large windows; both status palettes meet 4.5:1 text contrast; stylesheet modules parse.');

// Native modal dialogs have opposing block insets: auto height stretches them.
const controlsCss=postcss.parse(readFileSync(new URL('../src/styles/controls.css',import.meta.url),'utf8'));
let confirmationHeight;
controlsCss.walkRules('.project-modal.ui-confirmation-dialog[open]',rule=>rule.walkDecls('height',decl=>confirmationHeight=decl.value));
assert.equal(confirmationHeight,'fit-content','Brief confirmations must use intrinsic height rather than fill the modal viewport');
