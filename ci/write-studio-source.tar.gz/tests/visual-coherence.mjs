import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import ts from 'typescript';
import postcss from 'postcss';
import {loadLocal} from './load-local.mjs';
const src=new URL('../src/',import.meta.url),controls=postcss.parse(readFileSync(new URL('styles/controls.css',src),'utf8')),dropdown=postcss.parse(readFileSync(new URL('Dropdown.css',src),'utf8'));
const declarations=(tree,selector)=>{const values={};tree.walkRules(selector,rule=>{if(rule.parent===tree)rule.walkDecls(decl=>values[decl.prop]=decl.value);});return values;};
const tokens=declarations(controls,':root');for(const token of ['--ui-control-font','--ui-control-size','--ui-control-line','--ui-control-radius'])assert(tokens[token],token);
// Shared form typography outranks the legacy `input {font:inherit}` rule.
const dialogTypography=declarations(controls,':root :where(dialog)');assert.equal(dialogTypography['font-family'],'var(--ui-control-font)');assert.equal(dialogTypography['font-size'],'var(--ui-body-size)');
const fieldSelector=':root :where(dialog,.ui-form-field) :is(input:not([type]),input[type=text],input[type=search],input[type=number],textarea):not(:where(.long-text-editor textarea))';
let fieldTypography;controls.walkRules(rule=>{if(rule.selector.split(',\n').includes(fieldSelector))fieldTypography=Object.fromEntries(rule.nodes.filter(node=>node.type==='decl').map(node=>[node.prop,node.value]));});assert(fieldTypography);assert.equal(fieldTypography['font-family'],'var(--ui-control-font)');assert.equal(fieldTypography['font-size'],'var(--ui-field-size)');assert.equal(fieldTypography['font-weight'],'var(--ui-control-weight)');
const trigger=declarations(dropdown,'.dropdown > button.dropdown-trigger'),menu=declarations(dropdown,'.dropdown-menu');for(const property of ['font-family','font-size','line-height']){assert(trigger[property].includes('--ui-control-'));assert.equal(trigger[property],menu[property]);}assert.equal(trigger['text-transform'],'none');
// Every semantic action shares a geometry-stable press treatment, including portals.
let pressed;controls.walkRules(rule=>{if(rule.nodes.some(node=>node.type==='decl'&&node.prop==='opacity'&&node.value==='var(--ui-press-opacity)'))pressed=rule;});assert(pressed);for(const selector of ['button','summary','a[href]','[role=button]','[role=tab]','[role=option]','[role=menuitem]','[role=treeitem]',':not(:disabled)',':not([aria-disabled=true])',':not([inert])',':not(:has('])assert(pressed.selector.includes(selector),selector);assert(!pressed.nodes.some(node=>['transform','translate','scale','width','height'].includes(node.prop)));assert(Number(tokens['--ui-press-opacity'])>.7&&Number(tokens['--ui-press-opacity'])<.95);let staticPress=false;controls.walkAtRules('media',media=>{if(media.params.includes('prefers-reduced-motion:reduce'))media.walkDecls('transition-duration',decl=>{if(decl.value==='0s')staticPress=true;});});assert(staticPress);
const closeStyle=declarations(controls,':root button.ui-close-button');assert.equal(closeStyle.width,'32px');assert.equal(closeStyle.height,'32px');assert.equal(closeStyle.padding,'0');assert.equal(closeStyle['flex'],'0 0 32px');assert(controls.toString().includes(':focus-visible'));
const touch=controls.nodes.find(node=>node.type==='atrule'&&node.name==='media'&&node.params==='(pointer:coarse)');assert(touch);const touchClose=declarations(touch,':root button.ui-close-button');assert.equal(touchClose['min-width'],'44px');assert.equal(touchClose['min-height'],'44px');assert.equal(touchClose['max-width'],'44px');
// Cross-module custom properties must resolve, including portalled controls.
const styleFiles=['App.css','WorldPanel.css','Dropdown.css','interactions.css',...readdirSync(new URL('styles/',src)).filter(name=>name.endsWith('.css')).map(name=>`styles/${name}`)];
const defined=new Set(),referenced=new Set();
for(const name of styleFiles){const stylesheet=postcss.parse(readFileSync(new URL(name,src),'utf8'));stylesheet.walkDecls(decl=>{if(decl.prop.startsWith('--ui-'))defined.add(decl.prop);for(const match of decl.value.matchAll(/var\((--ui-[\w-]+)/g))referenced.add(match[1]);});}
for(const name of referenced)assert(defined.has(name),`Undefined shared UI token: ${name}`);
const visited=new Set(),visiting=new Set();
function visit(name){if(visited.has(name))return;assert(!visiting.has(name),`Cyclic shared UI token: ${name}`);visiting.add(name);for(const match of (tokens[name]??'').matchAll(/var\((--ui-[\w-]+)/g))visit(match[1]);visiting.delete(name);visited.add(name);}
for(const name of Object.keys(tokens))visit(name);
assert.equal(declarations(controls,':root .primary-button').background,'var(--accent)');
assert.equal(declarations(controls,':root .danger-button').color,'var(--danger)');
for(const token of ['--ui-field-height','--ui-field-size','--ui-panel-radius','--ui-shadow-menu','--ui-shadow-dialog','--ui-motion-feedback','--ui-motion-expand'])assert(tokens[token],token);
let closes=0;
for(const name of readdirSync(src).filter(name=>name.endsWith('.tsx'))){
 const text=readFileSync(new URL(name,src),'utf8'),file=ts.createSourceFile(name,text,ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 function walk(node){
  if(ts.isJsxOpeningElement(node)&&node.tagName.getText(file)==='select')assert.fail(`${name} must use the shared Dropdown`);
  if(ts.isJsxElement(node)&&node.openingElement.tagName.getText(file)==='button'){
   const opening=node.openingElement.getText(file),label=node.openingElement.attributes.properties.find(attr=>ts.isJsxAttribute(attr)&&attr.name.getText(file)==='aria-label');
   if(label&&/t\(['"]Close(?: [^'"]*)?['"]\)/.test(label.getText(file))&&/<X\s/.test(node.getText(file))){assert(opening.includes('ui-close-button'),name);assert(opening.includes('title='),name);closes++;}
  }
  ts.forEachChild(node,walk);
 }
 walk(file);
}
assert(closes>=15);
// Real shared dropdown handlers in the idea editor, preserving local drafts.
const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const Idea=loadLocal('../src/WorldIdeaEditor.tsx').default,Export=loadLocal('../src/ExportDialog.tsx').default;
const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
const idea={id:'idea',title:'Plan',description:'Keep text',status:'idea',category:'worldbuilding',entryIds:[]},props={idea,world:{entries:[],templates:[]},onSave:value=>committed=value,onClose:()=>closed++};let states=[],i=0,closed=0,committed;
try{React.useState=initial=>{const index=i++;if(!(index in states))states[index]=typeof initial==='function'?initial():initial;return[states[index],value=>states[index]=typeof value==='function'?value(states[index]):value];};React.useEffect=()=>{};React.useRef=value=>({current:value});const render=()=>{i=0;return nodes(Idea(props));};let tree=render();tree.find(node=>node.props?.id==='idea-category').props.onChange('narrative');tree=render();tree.find(node=>node.props?.id==='idea-status').props.onChange('deciding');tree=render();tree.find(node=>node.type==='form').props.onSubmit({preventDefault(){}});assert.equal(committed.category,'narrative');assert.equal(committed.status,'deciding');assert.equal(committed.description,'Keep text');assert.equal(idea.category,'worldbuilding');states=[];tree=render();tree.find(node=>node.props?.['aria-label']==='Close').props.onClick();assert.equal(closed,2);}finally{Object.assign(React,old);}
const html=renderToStaticMarkup(createElement(Export,{project:{title:'Novel',chapters:[]},onClose(){}}));assert(html.includes('ui-dialog-heading'));assert(html.includes('ui-close-button'));assert(html.includes('aria-label="Close"'));assert(!html.includes('>Close</button>'));
console.log(`Visual coherence: shared selector typography, ${closes} accessible X controls, keyboard focus styles, native selectors removed, draft-preserving idea dropdown handlers and manuscript export header passed without launching a UI.`);
