import assert from 'node:assert/strict';
import {Worker as NodeWorker} from 'node:worker_threads';
import {createRequire,Module} from 'node:module';
import {readFileSync} from 'node:fs';
import {fileURLToPath} from 'node:url';
import ts from 'typescript';
import {loadLocal} from './load-local.mjs';
const require=createRequire(import.meta.url),E=loadLocal('../src/encyclopediaExport.ts');
const clientUrl=new URL('../src/encyclopediaWorkerClient.ts',import.meta.url),filename=fileURLToPath(clientUrl);
const module=new Module(filename);module.filename=filename;module.paths=require.resolve.paths('typescript');
module._compile(ts.transpileModule(readFileSync(clientUrl,'utf8').replaceAll('import.meta.url',JSON.stringify(clientUrl.href)),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText,filename);
const {runEncyclopediaWorker}=module.exports;
let terminated=0,posted;
// Run the actual worker entry and its dependencies in a Node background thread.
// This exercises scheduling/termination without starting a browser or application.
globalThis.Worker=class {
 constructor(url){
  this.worker=new NodeWorker(`const {parentPort}=require('node:worker_threads');const fs=require('node:fs');const ts=require(${JSON.stringify(require.resolve('typescript'))});require.extensions['.ts']=(module,filename)=>module._compile(ts.transpileModule(fs.readFileSync(filename,'utf8'),{compilerOptions:{target:ts.ScriptTarget.ES2022,module:ts.ModuleKind.CommonJS}}).outputText,filename);globalThis.self={postMessage:data=>parentPort.postMessage(data)};require(${JSON.stringify(fileURLToPath(new URL('../src/encyclopediaExport.worker.ts',import.meta.url)))});parentPort.on('message',data=>self.onmessage({data}));`,{eval:true});
  assert(url.href.endsWith('/encyclopediaExport.worker.ts'));
  this.worker.on('message',data=>this.onmessage?.({data}));
  this.worker.on('error',error=>this.onerror?.({preventDefault(){},message:error.message}));
 }
 postMessage(data){posted=data;this.worker.postMessage(data);}
 terminate(){terminated++;void this.worker.terminate();}
};
const project={id:'p',title:'World 🌿',chapters:[{content:'PRIVATE MANUSCRIPT'}],worldbuilding:{schemaVersion:1,templates:[{id:'t',title:'People',fields:[{id:'text',label:'Notes',fieldType:'longText',archived:false}]}],entries:Array.from({length:1200},(_,i)=>({id:String(i),title:`Person ${i}`,templateId:'t',values:{text:'**Rich text** and _description_. '.repeat(30)},archived:false}))}};
const optimize=loadLocal('../src/encyclopediaExportImage.ts').encyclopediaExportImage;
let closedBitmaps=0,encodedType,drawSize;
globalThis.createImageBitmap=async()=>({width:2048,height:1024,close(){closedBitmaps++;}});
globalThis.document={createElement:()=>({getContext:()=>({drawImage:(_image,_x,_y,width,height)=>{drawSize=[width,height];}}),toBlob:(done,type)=>{encodedType=type;done(new Blob(['optimized'],{type}));}})};
try{
 const original=new Blob(['a'.repeat(200*1024)],{type:'image/png'});
 const optimized=await optimize(original,new AbortController().signal);
 assert.equal(optimized.type,'image/webp');assert.equal(encodedType,'image/webp');assert.deepEqual(drawSize,[1600,800]);assert.equal(closedBitmaps,1);assert.equal(original.size,200*1024);
 const small=new Blob(['small'],{type:'image/png'});assert.equal(await optimize(small,new AbortController().signal),small);assert.equal(closedBitmaps,1);
 globalThis.document.createElement=()=>({getContext:()=>null});await assert.rejects(()=>optimize(original,new AbortController().signal),/unavailable/);assert.equal(closedBitmaps,2);
}finally{delete globalThis.createImageBitmap;delete globalThis.document;}
const options={...E.defaultEncyclopediaOptions(project),images:false};
let ticks=0;const heartbeat=setInterval(()=>ticks++,1);
try{
 const result=await runEncyclopediaWorker(project,options,'html','/unused',new AbortController().signal);
 assert(result.includes('Person 1199'));assert(result.includes('<strong>Rich text</strong>'));assert(!result.includes('PRIVATE MANUSCRIPT'));assert.equal(posted.project.chapters,undefined);assert(ticks>0,'the calling thread remains available while generating');assert.equal(terminated,1);
 const controller=new AbortController();const pending=runEncyclopediaWorker(project,options,'md','/unused',controller.signal);controller.abort();await assert.rejects(pending,{name:'AbortError'});assert.equal(terminated,2);
 const stopped=new AbortController();stopped.abort();await assert.rejects(()=>runEncyclopediaWorker(project,options,'html','/unused',stopped.signal),{name:'AbortError'});assert.equal(terminated,2);
 loadLocal('../src/i18n.ts').setLanguage('es');
 const spanish=await runEncyclopediaWorker({...project,worldbuilding:{...project.worldbuilding,entries:project.worldbuilding.entries.slice(0,1)}},options,'html','/unused',new AbortController().signal);
 assert(spanish.includes('lang="es"'));assert(spanish.includes('Enciclopedia'));
 loadLocal('../src/i18n.ts').setLanguage('en');
 await assert.rejects(()=>runEncyclopediaWorker(project,{...options,templateIds:[]},'html','/unused',new AbortController().signal),/Select at least/);
 const withImage={...project,worldbuilding:{...project.worldbuilding,entries:[{...project.worldbuilding.entries[0],imageId:'picture'}]}};
 await assert.rejects(()=>E.encyclopediaImageData(withImage,{...options,images:true},async()=>({size:E.encyclopediaExportLimit,arrayBuffer(){throw Error('must reject before allocation');}})),/too large/);
 const reader=loadLocal('../src/entryImages.ts'),oldRead=reader.readEntryImage;
 try{
  reader.readEntryImage=async()=>new Blob([Uint8Array.of(137,80,78,71)],{type:'image/png'});
  const illustrated=await runEncyclopediaWorker(withImage,{...options,images:true},'html','/project',new AbortController().signal);
  assert(illustrated.includes('data:image/png;base64,iVBORw=='));
  let finishRead;reader.readEntryImage=()=>new Promise(resolve=>{finishRead=resolve;});
  const reading=new AbortController(),before=terminated;
  const loading=runEncyclopediaWorker(withImage,{...options,images:true},'html','/project',reading.signal);
  reading.abort();await assert.rejects(loading,{name:'AbortError'});assert.equal(terminated,before);
  finishRead(new Blob(['late result']));
 }finally{reader.readEntryImage=oldRead;}
 const storage=loadLocal('../src/storage.ts');let invocation;
 globalThis.window={__TAURI_INTERNALS__:{invoke:async(command,args)=>{invocation={command,args};return '/out/file.html';}}};
 try{await storage.saveTextExport('file.html','html','<h1>Océano 🌿</h1>');assert.equal(invocation.command,'export_manuscript');assert.equal(invocation.args.text,'<h1>Océano 🌿</h1>');assert(!('bytes' in invocation.args));}finally{delete globalThis.window;}
 const zipReader=loadLocal('../src/entryImages.ts'),zipOldRead=zipReader.readEntryImage;
 try{
  zipReader.readEntryImage=async()=>{throw Error('ZIP must never load or serialize images in the frontend');};
  const zipped=await runEncyclopediaWorker(withImage,{...options,images:true},'zip','/project',new AbortController().signal);
  assert(zipped.includes('src="images/image-1.png"'));assert.deepEqual(posted.images,{});assert(!zipped.includes('data:image'));
  const archiveStorage=loadLocal('../src/storage.ts');let call;
  globalThis.window={__TAURI_INTERNALS__:{invoke:async(command,args)=>{call={command,args};return '/out/file.zip';}}};
  try{await archiveStorage.saveEncyclopediaPackage('file.zip','/project','p',zipped,['picture']);assert.equal(call.command,'export_encyclopedia');assert.deepEqual(call.args.imageIds,['picture']);assert.equal(call.args.html,zipped);assert(!('bytes' in call.args));}finally{delete globalThis.window;}
 }finally{zipReader.readEntryImage=zipOldRead;}
 const repeated={...project,worldbuilding:{...project.worldbuilding,entries:project.worldbuilding.entries.slice(0,40).map(entry=>({...entry,imageId:'picture'}))}};
 assert.throws(()=>E.exportEncyclopedia(repeated,{...options,images:true},'html',{picture:'data:image/png;base64,'+'a'.repeat(1024*1024)}),/too large/);
 console.log('Encyclopedia background generation: 1,200 entries, rich text, responsive calling thread, worker cleanup/cancellation, minimal snapshot and bounded images/repeated output passed.');
}finally{clearInterval(heartbeat);delete globalThis.Worker;}
