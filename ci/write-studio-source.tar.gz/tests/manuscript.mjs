import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
const source = readFileSync(new URL('../src/manuscript.ts', import.meta.url), 'utf8');
const js = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 } }).outputText;
const { moveChapter, moveScene, transferScene } = await import(`data:text/javascript;base64,${Buffer.from(js).toString('base64')}`);
const fixture = name => JSON.parse(readFileSync(new URL(`fixtures/manuscript-${name}.json`, import.meta.url), 'utf8'));
function freeze(value) { if (value && typeof value === 'object') { Object.freeze(value); Object.values(value).forEach(freeze); } return value; }
const original = freeze(fixture('original'));
const [arrival, departure, interlude] = original.chapters;
const [before, after] = arrival.scenes;
const ending = departure.scenes[0];
// Move the last scene out of a chapter, populate an empty chapter, reorder it,
// and move the chapter as a whole. IDs and contents must survive the workflow.
let result = moveChapter(original, interlude.id, -1);
result = moveScene(result, after.id, -1);
result = transferScene(result, after.id, interlude.id);
result = transferScene(result, before.id, interlude.id);
result = moveScene(result, before.id, -1);
result = transferScene(result, ending.id, interlude.id);
result = moveChapter(result, interlude.id, -1);
assert.deepEqual(result, fixture('reordered'));
assert.deepEqual(original, fixture('original'), 'Structural edits must not mutate the existing project');
const contents = project => project.chapters.flatMap(c => c.scenes).sort((a, b) => a.id.localeCompare(b.id));
assert.deepEqual(contents(result), contents(original), 'No scene can be duplicated, lost, renamed or rewritten');
assert.strictEqual(moveChapter(original, arrival.id, -1), original);
assert.strictEqual(moveChapter(original, interlude.id, 1), original);
assert.strictEqual(moveScene(original, before.id, -1), original);
assert.strictEqual(moveScene(original, after.id, 1), original);
assert.strictEqual(transferScene(original, before.id, arrival.id), original);
assert.strictEqual(transferScene(original, before.id, 'missing'), original);
assert.strictEqual(transferScene(original, 'missing', interlude.id), original);
assert.strictEqual(moveScene(original, 'missing', 1), original);
assert.strictEqual(moveChapter(original, 'missing', 1), original);
// A user can move the same scene back and restore its former position.
let returned = transferScene(result, after.id, arrival.id);
returned = transferScene(returned, before.id, arrival.id);
returned = moveScene(returned, before.id, -1);
assert.deepEqual(returned.chapters.find(c => c.id === arrival.id).scenes, arrival.scenes);
console.log('Manuscript: reorder/transfer workflow, empty chapters, reversibility, immutable content and boundary actions passed.');
