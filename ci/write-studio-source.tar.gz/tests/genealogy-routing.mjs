// Pure geometry and stylesheet checks. No interface or browser is launched.
import assert from 'node:assert/strict';
import {readFileSync} from 'node:fs';
import postcss from 'postcss';
import {loadLocal} from './load-local.mjs';
const {createGenealogyRouter,segmentHitsBox,labelWidth}=loadLocal('../src/genealogyRouting.ts');
const {buildGenealogyScene}=loadLocal('../src/genealogyScene.ts');
const {genealogyFamilies,orderCoupleMembers}=loadLocal('../src/genealogyFamilies.ts');
function clear(route,positions){assert(!route.blocked);assert(route.points.length>=2);for(let i=1;i<route.points.length;i++)for(const p of Object.values(positions))assert(!segmentHitsBox(route.points[i-1],route.points[i],{left:p.x-100,right:p.x+100,top:p.y-32,bottom:p.y+32}),`Route crosses a card: ${JSON.stringify(route.points)}`);}
const positions={a:{x:100,y:120},b:{x:340,y:120},c:{x:580,y:120},d:{x:340,y:320},e:{x:580,y:520}};
const original=JSON.stringify(positions),router=createGenealogyRouter(positions);
const pair=router.betweenNodes('a','c','Matrimonio','partner',true);clear(pair,positions);assert(pair.label,'Couple has one anchored label');
const second=router.betweenNodes('a','b','Noviazgo','partner',true);clear(second,positions);assert(second.label);
assert(Math.abs(pair.label.x-second.label.x)>(labelWidth('Matrimonio',true)+labelWidth('Noviazgo',true))/2||Math.abs(pair.label.y-second.label.y)>40,'Labels do not overlap');
clear(router.betweenNodes('a','e','Cuidados','care'),positions);
assert.equal(JSON.stringify(positions),original);
const edge=(parentId,childId,id)=>({parentId,childId,lineage:'biological',link:{id}});
const familyPositions={p:{x:100,y:120},q:{x:340,y:120},c:{x:100,y:520},d:{x:340,y:520},obstacle:{x:100,y:320}};
const parents=[edge('p','c','pc'),edge('q','c','qc'),edge('p','d','pd'),edge('q','d','qd')],families=genealogyFamilies(parents,familyPositions);
const scene=buildGenealogyScene(familyPositions,[],families,()=> 'Filiación');assert.equal(scene.branches.length,1);assert(scene.branches[0].shared);assert.equal(scene.branches[0].connections.size,4);for(const route of scene.branches[0].childrenRoutes.values())clear(route,familyPositions);assert.equal(scene.unrouted.length,0);
const nested={a:{x:100,y:100},b:{x:100,y:100}};assert(createGenealogyRouter(nested).betweenNodes('a','b','Pareja','partner').blocked,'Fully coincident cards report an unavailable path rather than draw through them');
const ordered=orderCoupleMembers(['d','b','a','c'],[{sourceId:'a',targetId:'c'},{sourceId:'c',targetId:'b'},{sourceId:'b',targetId:'d'}]);for(const [a,b] of [['a','c'],['c','b'],['b','d']])assert.equal(Math.abs(ordered.indexOf(a)-ordered.indexOf(b)),1);
const css=postcss.parse(readFileSync(new URL('../src/styles/relation-network.css',import.meta.url),'utf8'));let transparent=false;css.walkRules(rule=>{if(rule.selector.includes(':root .genealogy-canvas')&&rule.selector.includes('.relation-graph-edge-hit')){const declarations=Object.fromEntries(rule.nodes.filter(n=>n.type==='decl').map(n=>[n.prop,n.value]));assert.equal(declarations.stroke,'transparent');assert.equal(declarations['stroke-dasharray'],'none');assert.equal(declarations['vector-effect'],'non-scaling-stroke');transparent=true;}});assert(transparent);
console.log('Genealogy routing: obstacle-free border anchors, multiple/cross-generation couples, non-overlapping labels, shared parent rails, blocked-card fallback, immutable inputs and transparent non-scaling hit areas passed.');

const {genealogyGraph}=loadLocal('../src/genealogyLayout.ts');
const world={templates:[{id:'t'}],entries:['a','b','c','d'].map(id=>({id,templateId:'t',title:id,values:{}}))};
const type={id:'pair',title:'Pair',inverseTitle:'Pair',symmetric:true,sourceTemplateIds:[],targetTemplateIds:[],genealogy:{kind:'partner'}};
const relations={schemaVersion:4,types:[type],links:[['a','c'],['c','b'],['b','d']].map(([sourceId,targetId],i)=>({id:String(i),sourceId,targetId,typeId:'pair'}))};
const layout=genealogyGraph(world,relations,'',2,2);assert.equal(layout.manualBasePositions.b.x,460);assert.equal(layout.manualBasePositions.b.x+40,500);assert.notEqual(layout.positions.b.x,layout.manualBasePositions.b.x,'Improved ordering preserves an independent legacy manual anchor');
assert(labelWidth('WWW')>=60);assert.equal(layout.positions.a.y,layout.positions.d.y);
