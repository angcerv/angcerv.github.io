import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const P=loadLocal('../src/worldBrowserPreferences.ts');
const React=createRequire(import.meta.url)('react'),Editor=loadLocal('../src/MapsEditor.tsx').default,Resize=loadLocal('../src/PanelResize.tsx').default;
const saved={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect},oldStorage=globalThis.localStorage,oldObserver=globalThis.ResizeObserver;
const values=new Map();globalThis.localStorage={getItem:key=>values.get(key)??null,setItem:(key,value)=>values.set(key,value)};
let states=[],refs=[],si=0,ri=0,effects=[],measure,imports=0;
const projectMap={id:'map',title:'A long map title',imageId:'image',markers:[],notes:''},maps={schemaVersion:1,maps:[projectMap]},world={templates:[],entries:[]};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
const body={preventDefault(){},currentTarget:{focus(){},setPointerCapture(){},hasPointerCapture:()=>true,releasePointerCapture(){}}};
try{
 P.rememberBrowserWidth('p',390);assert.equal(P.readBrowserWidth('p','maps'),240);P.rememberBrowserWidth('p',350,'maps');assert.equal(P.readBrowserWidth('p'),390);assert.equal(P.readBrowserWidth('p','maps'),350);assert.equal(P.readBrowserWidth('other','maps'),240);
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],next=>states[i]=typeof next==='function'?next(states[i]):next];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=fn=>effects.push(fn);
 const render=(extra={})=>{si=ri=0;effects=[];return nodes(Editor({maps,world,path:'/project',projectId:'p',mapId:'map',markerId:'',onSelectMap(){},onSelectMarker(){},onChange(){throw Error('Layout must not change project data');},onImport(){imports++;},onCreate:async()=>undefined,onOpenEntry(){},...extra}));};
 let tree=render(),aside=tree.find(n=>n.type==='aside'&&n.props.className==='maps-browser');
 const newMenus=tree.filter(n=>n.type?.name==='ActionMenu'&&n.props.label==='New map');assert.equal(newMenus.length,1);assert(nodes(aside).includes(newMenus[0]));assert(!nodes(tree.find(n=>n.props?.className==='map-titlebar')).includes(newMenus[0]));
 assert.deepEqual(newMenus[0].props.actions.map(action=>action.label),['Draw new map','Import image']);newMenus[0].props.actions[1].onClick();assert.equal(imports,1);
 const divider=()=>render().find(n=>n.type===Resize),grid=()=>render().find(n=>n.props?.className==='maps-layout maps-workbench');
 assert.equal(divider().props.width,350);divider().props.onChange(380);assert.equal(grid().props.style['--map-browser-open-width'],'380px');assert.equal(P.readBrowserWidth('p','maps'),380);assert.equal(P.readBrowserWidth('p'),390);
 let separator=Resize(divider().props);assert.equal(separator.props.role,'separator');separator.props.onKeyDown({...body,key:'ArrowLeft'});assert.equal(divider().props.width,364);
 separator=Resize(divider().props);separator.props.onPointerDown({...body,button:0,pointerId:1,clientX:100});separator.props.onPointerMove({...body,pointerId:1,clientX:500});assert.equal(divider().props.width,460);separator.props.onPointerCancel();assert.equal(divider().props.width,364);
 tree=render();tree.find(n=>n.props?.id==='map-browser-toggle').props.onClick();tree=render();assert.equal(tree.find(n=>n.props?.className==='map-browser-slot').props.inert,true);assert.equal(grid().props['data-browser'],false);
 tree.find(n=>n.props?.id==='map-browser-toggle').props.onClick();assert.equal(grid().props['data-browser'],true);assert.equal(divider().props.width,364);
 // Screen constraints affect the rendered width, retaining the user's stored preference.
 globalThis.ResizeObserver=class{constructor(callback){measure=callback;}observe(){}disconnect(){}};
 tree=render();const root=tree[0].props.ref.current={clientWidth:820};effects.find(fn=>fn.toString().includes('new ResizeObserver'))();assert.equal(divider().props.maximum,220);assert.equal(divider().props.width,220);assert.equal(P.readBrowserWidth('p','maps'),364);
 root.clientWidth=1200;measure();assert.equal(divider().props.width,364);
 tree=render({projectId:'other'});effects.find(fn=>fn.toString().includes('setBrowserWidth')&&fn.toString().includes('readBrowserWidth'))();assert.equal(render({projectId:'other'}).find(n=>n.type===Resize).props.width,240);
 const empty=render({maps:{schemaVersion:1,maps:[]}});assert(empty.some(n=>n.props?.id==='map-browser-toggle'));assert.equal(empty.filter(n=>n.type?.name==='ActionMenu'&&n.props.label==='New map').length,1);
}finally{Object.assign(React,saved);if(oldStorage===undefined)delete globalThis.localStorage;else globalThis.localStorage=oldStorage;if(oldObserver===undefined)delete globalThis.ResizeObserver;else globalThis.ResizeObserver=oldObserver;}
console.log('Map browser: one creation menu in the aside, independent per-project width, keyboard/pointer resize, cancellation, collapsed retention, responsive limits and empty-list access passed without UI.');
