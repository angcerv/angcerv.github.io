import assert from 'node:assert/strict';
import {createBenchmarkProject} from '../scripts/benchmark-fixture.mjs';
import {withBenchmarkAssets} from '../scripts/benchmark-assets.mjs';
import {loadLocal} from './load-local.mjs';
const {encyclopediaPackageImages,defaultEncyclopediaOptions}=loadLocal('../src/encyclopediaExport.ts');
const {validRegionPoints}=loadLocal('../src/mapRegions.ts');
const original=createBenchmarkProject(17),before=JSON.stringify(original),{project,assets}=withBenchmarkAssets(original,['existing-a.png','existing-b.png']);
assert.equal(JSON.stringify(original),before);assert.equal(assets.length,200);assert.equal(new Set(assets.map(asset=>asset.id)).size,200);
const selected=encyclopediaPackageImages(project,defaultEncyclopediaOptions(project));
assert.equal(selected.length,200,'Shared portraits, galleries and maps must not duplicate exported assets');
const ids=new Set(assets.map(asset=>asset.id)),scenes=new Set(project.chapters.flatMap(chapter=>chapter.scenes.map(scene=>scene.id))),entries=new Set(project.worldbuilding.entries.map(entry=>entry.id)),globalIds=new Set();
for(const map of project.maps.maps){
 assert(ids.has(map.imageId));const markers=new Set(map.markers.map(marker=>marker.id)),layers=new Set(map.layers.map(layer=>layer.id));
 for(const element of [map,...map.layers,...map.markers,...map.routes,...map.regions]){assert(!globalIds.has(element.id));globalIds.add(element.id);}
 for(const marker of map.markers){assert(entries.has(marker.entryId));assert(layers.has(marker.layerId));assert(marker.x>=0&&marker.x<=1&&marker.y>=0&&marker.y<=1);}
 for(const route of map.routes){assert(route.markerIds.every(id=>markers.has(id)));assert(route.sceneIds.every(id=>scenes.has(id)));assert(layers.has(route.layerId));}
 for(const region of map.regions){assert(validRegionPoints(region.points));assert(entries.has(region.entryId));assert(layers.has(region.layerId));}
}
assert.throws(()=>withBenchmarkAssets(original,[]));
console.log('Benchmark fixtures: immutable source project, shared asset deduplication, unique map IDs, valid polygons and explicit scene/entry/layer references passed without images or UI.');
