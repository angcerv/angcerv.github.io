import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const C=loadLocal('../src/storyCalendar.ts'),T=loadLocal('../src/timeline.ts'),I=loadLocal('../src/i18n.ts');
const gregorian=C.defaultStoryCalendar();C.validateStoryCalendar(gregorian);
for(const year of [-999999,-400,-100,-4,-1,0,1,4,100,400,2024,999999])for(const month of [1,2,6,12])for(const day of [1,T.daysInMonth(year,month)]){const date={year,month,day};assert.deepEqual(C.calendarFromStoryDate(date,gregorian),date);assert.deepEqual(C.storyDateFromCalendar(date,gregorian),date);}
assert.equal(C.calendarDateLabel({year:0,month:1,day:1},gregorian),'Saturday, 1 January · 0');
const fixed={...gregorian,name:'Tides',mode:'fixed',months:[{name:'Dawn',days:10},{name:'Sea',days:10}],weekdays:['Red','Blue','Green'],epochWeekday:0,eras:[{name:'Founding',startYear:0}]};C.validateStoryCalendar(fixed);
assert.deepEqual(C.calendarFromStoryDate({year:0,month:1,day:21},fixed),{year:1,month:1,day:1});
assert.deepEqual(C.calendarFromStoryDate({year:-1,month:12,day:31},fixed),{year:-1,month:2,day:10});
assert.equal(C.calendarDateLabel({year:0,month:1,day:21},fixed),'Green, 1 Dawn · 2 Founding');
assert.equal(C.calendarDateLabel({year:-1,month:12,day:31},fixed),'Green, 10 Sea · -1');
assert.equal(C.calendarDateLabel({year:0},fixed),'');assert.equal(C.calendarEventDateLabel({start:{year:0},end:{year:1}},fixed),'');
assert.equal(C.calendarEventDateLabel({start:{year:0,month:1,day:1},end:{year:1}},fixed),'');
for(let year=-400;year<=400;year+=7)for(const month of [1,2,7,12]){const date={year,month,day:15},custom=C.calendarFromStoryDate(date,fixed);assert.deepEqual(C.storyDateFromCalendar(custom,fixed),date);}
const shifted={...fixed,epochYear:2024};assert.deepEqual(C.storyDateFromCalendar({year:0,month:1,day:1},shifted),{year:2024,month:1,day:1});
const manyMonths={...fixed,months:Array.from({length:24},(_,i)=>({name:`M${i}`,days:1000}))};C.validateStoryCalendar(manyMonths);assert.deepEqual(C.parseCalendarDate('-12-24-1000',manyMonths),{year:-12,month:24,day:1000});assert.deepEqual(C.calendarFromStoryDate(C.storyDateFromCalendar({year:-12,month:24,day:1000},manyMonths),manyMonths),{year:-12,month:24,day:1000});
for(const patch of [{months:[]},{weekdays:[]},{months:[{name:'x',days:0}]},{months:[{name:'x',days:1},{name:' X ',days:2}]},{epochWeekday:3},{epochYear:1000000},{eras:[{name:'a',startYear:0},{name:'b',startYear:0}]},{eras:[{name:'',startYear:0}]}])assert.throws(()=>C.validateStoryCalendar({...fixed,...patch}));
assert.throws(()=>C.validateStoryCalendar({...gregorian,months:fixed.months}));assert.throws(()=>C.parseCalendarDate('0-02-11',fixed));assert.throws(()=>C.parseCalendarDate('0',fixed));assert.throws(()=>C.storyDateFromCalendar({year:999999,month:24,day:1000},manyMonths));
// Calendar edits never change canonical dates, their precision or period validation.
assert.deepEqual(T.parseStoryDate('0-02-29'),{year:0,month:2,day:29});assert.throws(()=>T.parseStoryDate('1-02-29'));T.validatePeriod({year:-1},{year:0});
const require=createRequire(import.meta.url),React=require('react'),original={useState:React.useState,useId:React.useId,useRef:React.useRef};
let states=[],index=0;const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
try{
 React.useState=initial=>{const i=index++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return [states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useId=()=> 'calendar-test';React.useRef=value=>{const i=index++;if(!(i in states))states[i]={current:value};return states[i];};
 const Converter=loadLocal('../src/CalendarDateConverter.tsx').default;let start,end;
 const render=()=>{index=0;return nodes(Converter({calendar:fixed,onStart:date=>start=date,onEnd:date=>end=date}));};
 let tree=render();tree.find(node=>node.type==='input').props.onChange({target:{value:'1-01-01'}});tree=render();tree.find(node=>node.props?.children==='Use as start date').props.onClick();tree.find(node=>node.props?.children==='Use as end date').props.onClick();assert.deepEqual(start,{year:0,month:1,day:21});assert.deepEqual(end,start);
 tree.find(node=>node.type==='input').props.onChange({target:{value:'1-03-01'}});assert(render().some(node=>node.props?.role==='alert'));assert(!render().some(node=>node.props?.children==='Use as start date'));
 states=[];const Dialog=loadLocal('../src/StoryCalendarDialog.tsx').default;let saved,closed=0;const before=JSON.stringify(fixed);index=0;tree=nodes(Dialog({initial:fixed,onSave:value=>saved=value,onClose:()=>closed++}));tree.find(node=>node.type==='input'&&node.props.value==='Tides').props.onChange({target:{value:'New tides'}});assert.equal(JSON.stringify(fixed),before);index=0;tree=nodes(Dialog({initial:fixed,onSave:value=>saved=value,onClose:()=>closed++}));tree.find(node=>node.type==='form').props.onSubmit({preventDefault(){}});assert.equal(saved.name,'New tides');assert.equal(closed,0);
 tree.find(node=>node.props?.id==='calendar-year-mode').props.onChange('gregorian');index=0;tree=nodes(Dialog({initial:fixed,onSave:value=>saved=value,onClose:()=>closed++}));tree.find(node=>node.props?.id==='calendar-year-mode').props.onChange('fixed');index=0;tree=nodes(Dialog({initial:fixed,onSave:value=>saved=value,onClose:()=>closed++}));tree.find(node=>node.type==='form').props.onSubmit({preventDefault(){}});assert.deepEqual(saved.months,fixed.months);
 tree.find(node=>typeof node.type==='function'&&node.type.name==='CalendarRecurrences').props.onChange({seasons:[{name:' Rains ',month:1,day:1,description:' Wet season '}],holidays:[{name:' Tides ',month:2,day:10,duration:2}]});
 index=0;tree=nodes(Dialog({initial:fixed,onSave:value=>saved=value,onClose:()=>closed++}));tree.find(node=>node.type==='form').props.onSubmit({preventDefault(){}});assert.equal(saved.schemaVersion,2);assert.equal(saved.seasons[0].name,'Rains');assert.equal(saved.seasons[0].description,'Wet season');assert.equal(saved.holidays[0].duration,2);
 tree.find(node=>node.type==='button'&&node.props.children==='Cancel').props.onClick();assert.equal(closed,0,'Changed calendar drafts require an explicit discard');index=0;tree=nodes(Dialog({initial:fixed,onSave:value=>saved=value,onClose:()=>closed++}));assert(tree.some(node=>node.props?.variant==='confirmation'));tree.find(node=>node.type==='button'&&node.props.children==='Discard changes').props.onClick();assert.equal(closed,1);assert.equal(JSON.stringify(fixed),before);
}finally{Object.assign(React,original);}
I.setLanguage('es');assert.equal(C.defaultStoryCalendar().months[0].name,'Enero');assert.equal(C.defaultStoryCalendar().weekdays[0],'Lunes');I.setLanguage('en');
console.log('World calendar: Gregorian compatibility, fixed years, 24 months/1000-day months, negative/year-zero boundaries, eras/weeks, bidirectional conversion, partial-date honesty, validation, staged edits and real conversion handlers passed without UI.');
