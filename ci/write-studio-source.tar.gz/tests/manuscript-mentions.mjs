import assert from 'node:assert/strict';
import {Schema} from '@tiptap/pm/model';
import {EditorState,TextSelection} from '@tiptap/pm/state';
import {loadLocal} from './load-local.mjs';
const {mentionNames,findMentions,createMentionPlugin,mentionPluginKey}=loadLocal('../src/manuscriptMentions.ts');
const {fromMarkdown,toMarkdown}=loadLocal('../src/model.ts');
const world={schemaVersion:8,templates:[{id:'people',title:'People',fields:[]}],entries:[
 {id:'isabel',title:'Isabel de Valcárcel',templateId:'people',linkAliases:['Isa','la capitana','A+B','María','𐐀na'],archived:false,values:{}},
 {id:'other',title:'Isadora',templateId:'people',linkAliases:['Isa'],archived:false,values:{}},
 {id:'short',title:'Isabel',templateId:'people',archived:false,values:{}},
 {id:'archived',title:'Ghost',templateId:'people',linkAliases:['Gone'],archived:true,values:{}},
]};
const names=mentionNames(world);
const text='Isa vio a Isabel de Valcárcel, Isadora y María. la capitana: A+B. Ghost Gone. Isaías misa';
const matches=findMentions(text,names);
assert.deepEqual(matches.map(m=>m.label),['Isa','Isabel de Valcárcel','Isadora','María','la capitana','A+B']);
assert.deepEqual(matches[0].entryIds,['isabel','other']);assert.deepEqual(matches[1].entryIds,['isabel']);
assert.equal(findMentions('𐐀na e Isa',names)[1].from,7);
assert.equal(findMentions('xIsa Isa_2 Isa2 Isa\u0301',names).length,0);
const schema=new Schema({nodes:{doc:{content:'paragraph+'},paragraph:{content:'inline*',group:'block'},text:{group:'inline'},hardBreak:{inline:true,group:'inline'}},marks:{bold:{},italic:{}}});
const content='**Isabel** de _Valcárcel_ vio a Isa.  \nMaría llegó.';
const doc=schema.nodeFromJSON(fromMarkdown(content));
let opened;
const plugin=createMentionPlugin(world,(ids,label)=>{opened={ids,label};});
let state=EditorState.create({doc,plugins:[plugin]});
const decorations=()=>mentionPluginKey.getState(state).decorations.find();
assert.equal(decorations().length,3);assert.equal(decorations()[0].spec.label,'Isabel de Valcárcel');
assert.equal(toMarkdown(state.doc.toJSON()),toMarkdown(doc.toJSON()));
// Keyboard activation opens the ambiguous choice without editing text.
state=state.apply(state.tr.setSelection(TextSelection.create(state.doc,decorations()[1].from+1)));
let prevented=false;assert.equal(plugin.props.handleKeyDown({state},{key:'Enter',altKey:true,isComposing:false,preventDefault(){prevented=true;}}),true);
assert.equal(prevented,true);assert.deepEqual(opened.ids,['isabel','other']);
assert.equal(plugin.props.handleKeyDown({state},{key:'Enter',altKey:false}),false);
// Clicking a decorated name opens its entry through the same callback.
const previousElement=globalThis.Element;
class MentionElement {
 dataset={entryIds:JSON.stringify(['isabel'])};textContent='María';
 closest(){return this;}
}
globalThis.Element=MentionElement;
try{
 const target=new MentionElement();
 assert.equal(plugin.props.handleClick({state,posAtDOM:()=>decorations().find(d=>d.spec.label==='María').from,dom:{contains:element=>element===target}},0,{target}),true);
 assert.deepEqual(opened,{ids:['isabel'],label:'María'});
 assert.equal(plugin.props.handleClick({dom:{contains:()=>false}},0,{target}),false);
}finally{if(previousElement===undefined)delete globalThis.Element;else globalThis.Element=previousElement;}
// Recompute on typing, including mentions spanning text nodes with distinct marks.
const before=JSON.stringify(state.doc.toJSON());state=state.apply(state.tr.insertText(' Isa',state.doc.content.size-1));assert.equal(decorations().length,4);
assert.equal(toMarkdown(state.doc.toJSON()).includes('data-entry'),false);
state=state.apply(state.tr.delete(state.doc.content.size-5,state.doc.content.size-1));assert.equal(JSON.stringify(state.doc.toJSON()),before);
// Live world changes remove deleted aliases/archived entries.
const changed={...world,entries:world.entries.map(entry=>entry.id==='isabel'?{...entry,archived:true}:entry)};
const replaced=state.reconfigure({plugins:[createMentionPlugin(changed,()=>{})]});
// Re-registering uses a fresh state just as editor unregister/register does.
const refreshed=EditorState.create({doc:replaced.doc,plugins:[createMentionPlugin(changed,()=>{})]});
assert.deepEqual(mentionPluginKey.getState(refreshed).decorations.find().map(d=>d.spec.label),['Isabel','Isa']);
console.log('Manuscript mentions: names/aliases, boundaries, Unicode offsets, longest matches, ambiguity, formatting, keyboard opening, typing updates and unchanged Markdown passed.');

// Case matters: a common noun should not become a character mention.
const caseWorld={...world,entries:[{...world.entries[0],title:'Luz',linkAliases:['La Capitana']}]};
assert.deepEqual(findMentions('Luz luz LUZ La Capitana la capitana',mentionNames(caseWorld)).map(m=>m.label),['Luz','La Capitana']);
const {sceneReferenceSummary,sceneMentions}=loadLocal('../src/mentionDetection.ts');
const {scenesForEntry}=loadLocal('../src/sceneLinks.ts');
const {createElement}=await import('react');const {renderToStaticMarkup}=await import('react-dom/server');
const References=loadLocal('../src/SceneReferences.tsx').default;
const combinedWorld={...caseWorld,entries:[...caseWorld.entries,{...world.entries[1],title:'Other',linkAliases:[]}]};
let ignoredState=EditorState.create({doc:schema.nodeFromJSON(fromMarkdown('Luz y **Luz**. luz.')),plugins:[createMentionPlugin(combinedWorld,()=>{})]});
let first=mentionPluginKey.getState(ignoredState).decorations.find()[0];
ignoredState=ignoredState.apply(ignoredState.tr.setMeta(mentionPluginKey,{from:first.from,to:first.to,text:'Luz',ignored:false}));
assert.equal(mentionPluginKey.getState(ignoredState).ignored.length,1);
assert.equal(mentionPluginKey.getState(ignoredState).decorations.find().filter(d=>!d.spec.ignored).length,1);
let scene={id:'scene',title:'Scene',content:toMarkdown(ignoredState.doc.toJSON()),entryIds:['isabel','other'],ignoredMentions:mentionPluginKey.getState(ignoredState).ignored};
let summary=sceneReferenceSummary(scene,combinedWorld);
assert.equal(summary.references.length,2);assert.equal(summary.mentionCount,1);assert.deepEqual(summary.references.find(r=>r.id==='isabel'),{id:'isabel',manual:true,count:1});assert.equal(summary.references.find(r=>r.id==='other').count,0);
// Editing before an excluded occurrence moves its range, without excluding the other occurrence.
ignoredState=ignoredState.apply(ignoredState.tr.insertText('Antes: ',1));
const moved=mentionPluginKey.getState(ignoredState).ignored[0];assert.equal(moved.from,first.from+7);
scene={...scene,content:toMarkdown(ignoredState.doc.toJSON()),ignoredMentions:[moved]};assert.equal(sceneMentions(scene,combinedWorld).length,1);
const restoredState=EditorState.create({doc:ignoredState.doc,plugins:[createMentionPlugin(combinedWorld,()=>{},JSON.parse(JSON.stringify(scene.ignoredMentions)))]});
assert.equal(mentionPluginKey.getState(restoredState).decorations.find().filter(d=>d.spec.ignored).length,1);
ignoredState=ignoredState.apply(ignoredState.tr.setMeta(mentionPluginKey,{...moved,ignored:true}));assert.equal(mentionPluginKey.getState(ignoredState).ignored.length,0);
ignoredState=ignoredState.apply(ignoredState.tr.setMeta(mentionPluginKey,{...moved,ignored:false}));
ignoredState=ignoredState.apply(ignoredState.tr.insertText('Mar',moved.from,moved.to));assert.equal(mentionPluginKey.getState(ignoredState).ignored.length,0);
assert.equal(sceneReferenceSummary({...scene,entryIds:[]},combinedWorld).references.length,1);
assert.equal(scenesForEntry([{id:'chapter',scenes:[{...scene,entryIds:[]}]}],'isabel',combinedWorld).length,1);
const html=renderToStaticMarkup(createElement(References,{scene,world:combinedWorld,onOpen:()=>{},onLink:()=>{},onChange:()=>{}}));
assert.equal((html.match(/class="scene-reference-row"/g)??[]).length,2);assert.ok(html.includes('Manual link'));assert.ok(html.includes('2 entries · 1 text mentions'));
const ambiguousScene={...scene,content:'Isa',entryIds:[],ignoredMentions:[]};assert.equal(sceneReferenceSummary(ambiguousScene,world).references.length,0);assert.equal(sceneReferenceSummary(ambiguousScene,world).ambiguous.length,1);
console.log('Unified references: case-sensitive matching, per-occurrence exclusions/restoration, edit mapping/reload, unique manual/text rows, counters, ambiguity and backlinks passed.');
