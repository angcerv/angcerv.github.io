import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {expandMapCanvas}=loadLocal('../src/mapCanvasExpansion.ts');
const {scaledDistance,updateMap}=loadLocal('../src/maps.ts');
const {MapElementHistory}=loadLocal('../src/mapElementHistory.ts');
const {validRegionGeometry}=loadLocal('../src/mapRegions.ts');
const ring=[{x:.1,y:.1},{x:.9,y:.1},{x:.9,y:.9},{x:.1,y:.9}],hole=[{x:.3,y:.3},{x:.7,y:.3},{x:.7,y:.7},{x:.3,y:.7}];
const map={id:'map',imageId:'asset',title:'Space',notes:'',markers:[{id:'a',x:.2,y:.4,icon:'planet'},{id:'b',x:.8,y:.6,icon:'star'}],routes:[{id:'route',markerIds:['a','b']}],regions:[{id:'region',points:ring,holes:[hole],labelPosition:{x:.2,y:.2}}],scale:{from:{x:0,y:0},to:{x:1,y:0},aspectRatio:1.6,distanceKm:100,travelKmPerDay:20},drawing:{width:1600,height:1000,background:'#112233',strokes:[{width:.05,points:[{x:.2,y:.3}]}],objects:[{id:'symbol',kind:'planet',x:.5,y:.6,size:.1},{id:'ellipse',kind:'ellipse',x:.1,y:.2,endX:.7,endY:.8,size:.01,lineWidth:.001}]}};
const original=JSON.stringify(map),margins={top:100,right:200,bottom:300,left:400};
const expanded=expandMapCanvas(map,margins);
assert.equal(JSON.stringify(map),original);
assert.equal(expanded.drawing.width,2200);assert.equal(expanded.drawing.height,1400);
const close=(a,b)=>assert(Math.abs(a-b)<1e-9,`${a} != ${b}`);
for(let i=0;i<2;i++){close(expanded.markers[i].x*2200,map.markers[i].x*1600+400);close(expanded.markers[i].y*1400,map.markers[i].y*1000+100);}
close(expanded.drawing.objects[0].size*2200,160);
close(expanded.drawing.objects[1].lineWidth*2200,1.6);
close(expanded.drawing.objects[1].endY*1400,900);
close(expanded.drawing.strokes[0].width*2200,80);
assert(validRegionGeometry(expanded.regions[0]));assert.deepEqual(expanded.routes,map.routes);
close(scaledDistance(map.scale,...map.markers),scaledDistance(expanded.scale,...expanded.markers));
const calibrated={...map,scale:{...map.scale,aspectRatio:2.3}};const adjusted=expandMapCanvas(calibrated,margins);close(scaledDistance(calibrated.scale,...map.markers),scaledDistance(adjusted.scale,...adjusted.markers));
const again=expandMapCanvas(expanded,{top:20,right:0,bottom:0,left:30});
close(again.imageFrame.x*2230,430);close(again.imageFrame.width*2230,1600);close(again.imageFrame.y*1420,120);
assert.equal(expandMapCanvas(map,{top:0,right:0,bottom:0,left:0}),null);
for(const bad of [-1,NaN,Infinity,.5,4096])assert.equal(expandMapCanvas(map,{...margins,left:bad}),null);
assert.equal(updateMap({schemaVersion:20,maps:[map]},expanded).schemaVersion,20);
const history=new MapElementHistory(),edited={...map,markers:[{...map.markers[0],title:'Renamed'},map.markers[1]]};history.record(map,edited);assert(history.canUndo);history.sync(expandMapCanvas(edited,margins));assert(!history.canUndo,'Expansion invalidates old normalized coordinate history');
console.log('Canvas expansion: immutable geometry, repeated expansion, symbol/stroke sizes, holes, image frame, route links, calibration, bounds and history passed.');
const {drawingMaterialDefinitions}=loadLocal('../src/mapDrawing.ts');
const textured={...map,drawing:{...map.drawing,strokes:[{kind:'land',material:'grass',width:.05,points:[{x:.5,y:.5}]}]}};
const textureExpanded=expandMapCanvas(textured,margins),textureAgain=expandMapCanvas(textureExpanded,{top:20,right:0,bottom:0,left:30});
assert.deepEqual(textureAgain.drawing.textureFrame,{x:430,y:120,width:1600,height:1000});
assert(drawingMaterialDefinitions(textureAgain.drawing).includes('translate(430 120) scale(1)'),'Texture size and origin follow the original artwork');
// Image framing preserves the original asset and uses actual expanded dimensions.
const {framedMapImage}=loadLocal('../src/mapCanvasExpansion.ts'),oldImage=globalThis.Image,oldDocument=globalThis.document;
const draws=[];let imageBlob;
globalThis.Image=class{async decode(){}};
globalThis.document={createElement(){return {width:0,height:0,getContext(){return {drawImage(...args){draws.push(args.slice(1));}};},toBlob(callback){imageBlob=new Blob(['framed']);callback(imageBlob);}};}};
try{const source=new Blob(['original']);assert.equal(await framedMapImage(source,map),source);assert.equal(await framedMapImage(source,expanded),imageBlob);assert.deepEqual(draws[0],[400,100,1600,1000]);}finally{globalThis.Image=oldImage;globalThis.document=oldDocument;}
