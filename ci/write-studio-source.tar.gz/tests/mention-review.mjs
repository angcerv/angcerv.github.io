import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {Schema} from '@tiptap/pm/model';
import {EditorState} from '@tiptap/pm/state';
import {loadLocal} from './load-local.mjs';
const {createMentionPlugin,mentionPluginKey}=loadLocal('../src/manuscriptMentions.ts');
const {sceneMentions,sceneReferenceSummary,nextMention,sceneExcludedMentions}=loadLocal('../src/mentionDetection.ts');
const {fromMarkdown,toMarkdown}=loadLocal('../src/model.ts');
const schema=new Schema({nodes:{doc:{content:'paragraph+'},paragraph:{content:'inline*',group:'block'},text:{group:'inline'},hardBreak:{inline:true,group:'inline'}},marks:{bold:{},italic:{}}});
const world={schemaVersion:8,templates:[{id:'t',title:'People',fields:[]}],entries:[{id:'one',title:'First',templateId:'t',archived:false,values:{},linkAliases:['Isa']},{id:'two',title:'Second',templateId:'t',archived:false,values:{},linkAliases:['Isa']}]};
let state=EditorState.create({doc:schema.nodeFromJSON(fromMarkdown('**Isa** y Isa.\n\nIsa.')),plugins:[createMentionPlugin(world,()=>{})]});
const data=()=>mentionPluginKey.getState(state),command=action=>{state=state.apply(state.tr.setMeta(mentionPluginKey,action));};
const scene=()=>({id:'scene',title:'Scene',content:toMarkdown(state.doc.toJSON()),ignoredMentions:data().ignored,resolvedMentions:data().resolved});
let first=data().decorations.find()[0];
command({kind:'resolve',from:first.from,to:first.to,text:'Isa',entryId:'two'});
assert.deepEqual(data().resolved,[{from:1,to:4,text:'Isa',entryId:'two'}]);
assert.equal(sceneReferenceSummary(scene(),world).ambiguous.length,2);
assert.equal(sceneReferenceSummary(scene(),world).references[0].id,'two');
assert.equal(sceneReferenceSummary(scene(),world).mentionCount,1);
// A different occurrence can refer to another entry and keeps its own decision.
let second=data().decorations.find()[1];command({kind:'resolve',from:second.from,to:second.to,text:'Isa',entryId:'one'});
assert.equal(sceneReferenceSummary(scene(),world).references.length,2);
const saved=JSON.parse(JSON.stringify(scene()));
state=EditorState.create({doc:schema.nodeFromJSON(fromMarkdown(saved.content)),plugins:[createMentionPlugin(world,()=>{},saved.ignoredMentions,undefined,saved.resolvedMentions)]});
assert.equal(data().resolved.length,2);
const renamed={...world,entries:world.entries.map(entry=>({...entry,title:'Renamed',linkAliases:[]}))};
assert.deepEqual(sceneMentions(scene(),renamed).map(m=>m.entryIds[0]),['two','one']);
const deleted={...world,entries:world.entries.filter(entry=>entry.id!=='two')};
assert.equal(sceneMentions(scene(),deleted)[0].entryIds[0],'two','A saved choice never silently retargets after deletion');
// Exclusions can be reviewed/restored without losing the saved target.
command({from:1,to:4,text:'Isa',ignored:false});assert.equal(sceneReferenceSummary(scene(),world).excluded.length,1);
assert.equal(sceneExcludedMentions(scene()).length,1);assert.equal(sceneReferenceSummary(scene(),renamed).excluded.length,1);
command({from:1,to:4,text:'Isa',ignored:true});assert.equal(sceneReferenceSummary(scene(),world).excluded.length,0);
assert.equal(sceneMentions(scene(),world)[0].entryIds[0],'two');
// Prefix edits remap choices; editing the chosen word drops only that choice.
state=state.apply(state.tr.insertText('Antes: ',1));assert.equal(data().resolved[0].from,8);
command({kind:'clearResolution',from:8,to:11});assert.equal(data().resolved.length,1);
assert.equal(sceneReferenceSummary(scene(),world).ambiguous.length,2);
const remaining=data().resolved[0];state=state.apply(state.tr.insertText('Otra',remaining.from,remaining.to));assert.equal(data().resolved.length,0);
// Highlight is temporary metadata and leaves saved text and references unchanged.
const original=toMarkdown(state.doc.toJSON());command({kind:'flash',from:8,to:11});assert.equal(data().decorations.find().filter(d=>d.spec.flash).length,1);assert.equal(toMarkdown(state.doc.toJSON()),original);
command({kind:'clearFlash'});assert.equal(data().decorations.find().some(d=>d.spec.flash),false);
const ranges=[{from:1,to:4},{from:8,to:11},{from:15,to:18}];assert.equal(nextMention(ranges),ranges[0]);assert.equal(nextMention(ranges,ranges[0]),ranges[1]);assert.equal(nextMention(ranges,ranges[2]),ranges[0]);assert.equal(nextMention([]),undefined);
// Exercise the actual panel handlers, retaining hook state between renders.
const require=createRequire(import.meta.url),React=require('react'),savedUseState=React.useState;
const Component=loadLocal('../src/SceneReferences.tsx').default;
let hooks=[],hookIndex=0,jumps=[],commands=[];
React.useState=value=>{const index=hookIndex++;if(!(index in hooks))hooks[index]=value;return [hooks[index],next=>{hooks[index]=typeof next==='function'?next(hooks[index]):next;}];};
const panelWorld={...world,entries:[world.entries[0]]};
const panelScene={id:'panel',title:'Scene',content:'Isa y Isa. Isa',ignoredMentions:[{from:7,to:10,text:'Isa'}]};
function nodes(node){if(Array.isArray(node))return node.flatMap(nodes);if(!node||typeof node!=='object')return [];return [node,...nodes(node.props?.children)];}
function render(){hookIndex=0;return nodes(Component({scene:panelScene,world:panelWorld,onChange:()=>{},onOpen:()=>{},onLink:()=>{},onJump:range=>jumps.push(range),onCommand:action=>commands.push(action)}));}
try{
 for(let i=0;i<3;i++)render().find(n=>n.props?.className==='scene-mention-counter').props.onClick();
 assert.deepEqual(jumps.map(j=>j.from),[1,12,1]);
 render().find(n=>n.props?.['aria-label']==='Restore link for “Isa”').props.onClick();assert.equal(commands[0].ignored,true);assert.equal(commands[0].from,7);
}finally{React.useState=savedUseState;}
console.log('Mention review: saved per-occurrence targets, reloading/remapping/reset, no silent retargeting, exclusions/restoration, wrapping navigation, panel handlers and transient highlights passed.');
