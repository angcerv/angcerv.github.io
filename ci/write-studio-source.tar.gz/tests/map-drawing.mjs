import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
const {emptyDrawing,drawingSvg,drawingPoint,drawingSymbols,symbolArtwork}=loadLocal('../src/mapDrawing.ts');
const {mapThemes}=loadLocal('../src/mapThemes.ts');
for(const theme of Object.values(mapThemes))for(const kind of theme.symbols)assert(symbolArtwork[kind],`Missing symbol ${kind}`);
const {addMapLayer,addMapRoute,linkRouteTarget}=loadLocal('../src/maps.ts');
const initial=emptyDrawing(),map={id:'map',title:'My atlas',imageId:'image',notes:'',markers:[],drawing:initial};
assert.equal(drawingPoint(10,20,{left:0,top:0,width:0,height:0}),null);
assert.deepEqual(drawingPoint(400,-10,{left:0,top:0,width:200,height:100}),{x:1,y:0});
const sample={...initial,strokes:[{kind:'land',width:.1,points:[{x:.2,y:.3}]},{kind:'water',width:.02,points:[{x:.2,y:.3},{x:.4,y:.3}]}],objects:[...drawingSymbols.map((kind,index)=>({id:`symbol${index}`,kind,x:.1+index*.15,y:.5,size:.07})),{id:'label',kind:'label',x:.5,y:.8,size:.02,text:'Sea <script> & "island"'}]};
const svg=drawingSvg(sample);assert(svg.indexOf('#d9d0a4')<svg.indexOf('#b9d9df'));assert(!svg.includes('<script>'));assert(svg.includes('&lt;script&gt;'));assert(!drawingSvg(sample,false).includes('<text'));assert.equal((svg.match(/data-art-id=/g)||[]).length,6);
const maps={schemaVersion:7,maps:[{...map,markers:['a','b'].map((id,i)=>({id,title:id,x:i,y:.5,icon:'pin',color:'teal',notes:''}))}]};
assert.equal(addMapLayer(maps,'map','Places').maps.schemaVersion,7);assert.equal(addMapRoute(maps,'map','Trip',['a','b']).maps.schemaVersion,7);
const routed=addMapRoute(maps,'map','Trip',['a','b']);assert.equal(linkRouteTarget(routed.maps,'map',routed.routeId,'scene','scene',true).schemaVersion,7);
// Exercise real drawing gestures and the local undo/redo history without a browser.
const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const Editor=loadLocal('../src/MapDrawingEditor.tsx').default;
let states=[],refs=[],si=0,ri=0,saved,cancelled=0,deferUpdates=false,pendingUpdates=[],renderMap=map;
const surface={getBoundingClientRect:()=>({left:0,top:0,width:800,height:500}),focus(){},setPointerCapture(){},hasPointerCapture:()=>true,releasePointerCapture(){}};
function nodes(n){if(n&&typeof n.type==='function'&&['DrawingColorPicker','DrawingToolRail'].includes(n.type.name))return nodes(n.type(n.props));return Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];}
const text=n=>Array.isArray(n)?n.map(text).join(''):typeof n==='string'?n:n?.props?text(n.props.children):'';
try{
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],next=>{if(deferUpdates&&typeof next==='function')pendingUpdates.push(()=>states[i]=next(states[i]));else states[i]=typeof next==='function'?next(states[i]):next;}];};
 React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 function render(){si=0;ri=0;return nodes(Editor({map:renderMap,path:'/book',projectId:'p',onCancel:()=>cancelled++,onSave:value=>saved=value}));}
 let all=render();states[3]='image';renderMap={...map,drawing:undefined};
 const loaded=render().find(n=>n.type==='img'&&n.props.onLoad),loadEvent={currentTarget:{naturalWidth:1280,naturalHeight:720}};
 deferUpdates=true;loaded.props.onLoad(loadEvent);loadEvent.currentTarget=null;deferUpdates=false;
 assert.doesNotThrow(()=>pendingUpdates.forEach(update=>update()),'Image dimensions must be captured before React clears currentTarget');
 assert.equal(states[0].width,1280);assert.equal(states[0].height,720);assert.equal(states[4],true);
 renderMap=map;states[0]=initial;refs[1].current=surface;
 assert(render().find(n=>n.type==='button'&&text(n)==='Material').props['aria-pressed'],'New painting defaults to the illustrated material');
 render().find(n=>n.type==='button'&&text(n)==='Solid color').props.onClick();
 const event=(x,y,id='')=>({button:0,isPrimary:true,pointerId:1,clientX:x,clientY:y,currentTarget:surface,target:{closest:()=>id?{getAttribute:()=>id}:null},preventDefault(){}});
 const canvas=()=>render().find(n=>n.props?.['aria-label']==='Map drawing canvas');
 canvas().props.onPointerDown(event(80,100));canvas().props.onPointerMove(event(160,120));canvas().props.onPointerUp(event(160,120));
 assert.equal(states[0].strokes.length,1);assert.equal(states[0].strokes[0].points.length,2);assert.equal(states[1].length,1);
 all=render();all.find(n=>n.props?.['aria-label']==='Undo').props.onClick();assert.equal(states[0].strokes.length,0);
 render().find(n=>n.props?.['aria-label']==='Redo').props.onClick();assert.equal(states[0].strokes.length,1);
 render().find(n=>n.type==='button'&&text(n).includes('Water')).props.onClick();canvas().props.onPointerDown(event(130,110));canvas().props.onPointerUp(event(130,110));assert.equal(states[0].strokes[1].kind,'water');
 render().find(n=>n.props?.['aria-label']==='mountain').props.onClick();
 const touchBaseline=JSON.stringify(states[0]),touchHistory=states[1].length;
 canvas().props.onPointerDown({...event(400,250),pointerType:'touch'});assert.equal(states[1].length,touchHistory,'Touch placement remains a preview until release');
 canvas().props.onPointerCancel(event(400,250));assert.equal(JSON.stringify(states[0]),touchBaseline);assert.equal(states[1].length,touchHistory,'Pinch takeover must not add a symbol or undo step');
 canvas().props.onPointerDown(event(400,250));assert.equal(states[0].objects[0].kind,'mountain');const id=states[0].objects[0].id;
 render().find(n=>n.type==='button'&&n.props['aria-label']==='Select and move').props.onClick();canvas().props.onPointerDown(event(400,250,id));canvas().props.onPointerMove(event(480,300,id));canvas().props.onPointerUp(event(480,300,id));assert.equal(states[0].objects[0].x,.6);assert.equal(states[0].objects[0].y,.6);
 // Cancellation restores the exact pre-gesture state and adds no history entry.
 const before=JSON.stringify(states[0]),history=states[1].length;
 canvas().props.onPointerDown(event(480,300,id));canvas().props.onPointerMove(event(700,400,id));canvas().props.onPointerCancel(event(700,400,id));assert.equal(JSON.stringify(states[0]),before);assert.equal(states[1].length,history);
 render().find(n=>n.type==='button'&&text(n)==='Apply drawing').props.onClick();assert.equal(saved.objects.length,1);assert.equal(saved.strokes.length,2);assert.equal(initial.strokes.length,0);
 // Switching palettes keeps old colors and elements; backgrounds are explicit and undoable.
 render().find(n=>n.type==='button'&&n.props?.['aria-label']==='Terrain').props.onClick();
 const oldStrokes=JSON.stringify(states[0].strokes),oldObjects=JSON.stringify(states[0].objects);
 render().find(n=>n.props?.id==='drawing-theme').props.onChange('space');assert.equal(states[0].theme,'space');assert.equal(states[0].background,undefined);assert.equal(JSON.stringify(states[0].strokes),oldStrokes);assert.equal(JSON.stringify(states[0].objects),oldObjects);
 assert(render().some(n=>n.props?.['aria-label']==='planet'));assert(!render().some(n=>n.props?.['aria-label']==='tower'));
 render().find(n=>n.type==='button'&&text(n)==='Use theme background').props.onClick();assert.equal(states[0].background,'#101629');
 render().find(n=>n.props?.['aria-label']==='planet').props.onClick();canvas().props.onPointerDown(event(320,200));assert.equal(states[0].objects[1].kind,'planet');
 render().find(n=>n.props?.id==='drawing-label').props.onChange({target:{value:'Aurora'}});render().find(n=>n.type==='button'&&text(n)==='Place label').props.onClick();canvas().props.onPointerDown(event(500,300));assert.equal(states[0].objects[2].color,'#e3e9ff');assert.equal(states[0].objects[2].halo,'#101629');
 render().find(n=>n.props?.id==='drawing-theme').props.onChange('modern');assert.equal(states[0].background,'#101629');
 render().find(n=>n.props?.['aria-label']==='Undo').props.onClick();assert.equal(states[0].theme,'space');assert.equal(states[6],'nebula','Undoing a theme keeps a compatible terrain tool instead of closing its panel');
 render().find(n=>n.props?.['aria-label']==='Redo').props.onClick();assert.equal(states[0].theme,'modern');
 render().find(n=>n.type==='button'&&text(n)==='Material').props.onClick();render().find(n=>n.props?.['aria-label']==='Paint with Streets').props.onClick();canvas().props.onPointerDown(event(100,300));canvas().props.onPointerUp(event(100,300));assert.equal(states[0].strokes[2].kind,'road');assert.equal(states[0].strokes[2].color,'#717b85');
 const themedSvg=drawingSvg(states[0]);assert(themedSvg.includes('fill="#101629"')&&themedSvg.includes('#717b85')&&themedSvg.includes('Aurora'));assert(!drawingSvg(states[0],false).includes('Aurora'));
 render().find(n=>n.type==='button'&&text(n)==='Show imported image').props.onClick();assert.equal(states[0].background,undefined);assert.equal(states[0].objects.length,3);
 // Materials capture their own intensity/color and work in every thematic palette.
 render().find(n=>n.props?.['aria-label']==='planet')?.props.onClick();
 render().find(n=>n.type==='button'&&text(n)==='Material').props.onClick();
 render().find(n=>n.props?.id==='drawing-theme').props.onChange('medieval');
 const materialStart=states[0].strokes.length;
 for(const name of ['Sea','Earth','Sand','Grass','Rock','Mud']){
  render().find(n=>n.props?.['aria-label']===`Paint with ${name}`).props.onClick();
  canvas().props.onPointerDown(event(200,200));canvas().props.onPointerMove(event(300,200));canvas().props.onPointerUp(event(300,200));
  const stroke=states[0].strokes.at(-1);assert.equal(stroke.material,name.toLowerCase());assert.equal(stroke.textureIntensity,.75);
 }
 assert.equal(states[0].strokes.length,materialStart+6);
 const painted=JSON.stringify(states[0]);
 render().find(n=>n.props?.['aria-label']==='Undo').props.onClick();assert.equal(states[0].strokes.length,materialStart+5);
 render().find(n=>n.props?.['aria-label']==='Redo').props.onClick();assert.equal(JSON.stringify(states[0]),painted);
 const beforeSwatch=render().find(n=>n.type?.name==='RelationshipOptions'&&n.props.triggerClassName==='drawing-material-trigger').props.icon.props.src;
 render().find(n=>n.props?.id==='drawing-texture-intensity').props.onChange({target:{value:'0.35'}});
 const afterSwatch=render().find(n=>n.type?.name==='RelationshipOptions'&&n.props.triggerClassName==='drawing-material-trigger').props.icon.props.src;assert.notEqual(beforeSwatch,afterSwatch);assert(decodeURIComponent(afterSwatch).includes('opacity="0.35"'));
 render().find(n=>n.props?.['aria-label']==='Paint with Mud').props.onClick();
 canvas().props.onPointerDown(event(200,200));canvas().props.onPointerUp(event(200,200));
 assert.equal(states[0].strokes.at(-1).textureIntensity,.35);assert.equal(states[0].strokes.at(-2).textureIntensity,.75);
 render().find(n=>n.type==='button'&&text(n)==='Solid color').props.onClick();
 canvas().props.onPointerDown(event(200,200));canvas().props.onPointerUp(event(200,200));assert.equal(states[0].strokes.at(-1).material,undefined);
 render().find(n=>n.type==='button'&&text(n)==='Apply drawing').props.onClick();assert.equal(saved.strokes.at(-2).material,'mud');
 // Each theme moves its terrain identities into the material picker, with real textured strokes.
 for(const [theme,names,ids] of [['modern',['Ground','Water','Parks','Streets'],['pavement','cityWater','park','asphalt']],['futuristic',['Ground','Water','Urban zones','Transit ways'],['alloy','canal','district','transit']],['space',['Nebulae','Space regions','Deep space'],['nebula','spaceRegion','deepSpace']]]){
  render().find(n=>n.props?.id==='drawing-theme').props.onChange(theme);render().find(n=>n.type==='button'&&text(n)==='Material').props.onClick();
  const materialButtons=render().filter(n=>n.props?.['aria-label']?.startsWith('Paint with '));assert.deepEqual(materialButtons.map(n=>n.props['aria-label']),names.map(name=>`Paint with ${name}`));
  for(let i=0;i<names.length;i++){render().find(n=>n.props?.['aria-label']===`Paint with ${names[i]}`).props.onClick();canvas().props.onPointerDown(event(200,200));canvas().props.onPointerUp(event(250,200));assert.equal(states[0].strokes.at(-1).material,ids[i]);assert.equal(states[0].strokes.at(-1).textureIntensity,.35);}
  render().find(n=>n.type==='button'&&text(n)==='Solid color').props.onClick();assert(!render().some(n=>n.props?.className==='drawing-tool-pair'),'Theme terrains are not duplicated as solid tools');
 }
 render().find(n=>n.props?.['aria-label']==='Close').props.onClick();assert.equal(cancelled,0);assert.equal(states[11],true);render().find(n=>n.type==='button'&&text(n)==='Discard changes').props.onClick();assert.equal(cancelled,1);
 // Importing an image and drawing a new map are independent entry points.
 const MapsEditor=loadLocal('../src/MapsEditor.tsx').default;states=[];refs=[];si=0;ri=0;let imports=0,created=0;
 const mapNodes=nodes(MapsEditor({maps:{schemaVersion:1,maps:[]},world:{entries:[],templates:[]},path:'/book',projectId:'p',mapId:'',markerId:'',onSelectMap(){},onSelectMarker(){},onChange(){},onOpenEntry(){},async onImport(){imports++;},async onCreate(){created++;return 'new-map';}}));
 const creationMenu=mapNodes.find(n=>n.type?.name==='ActionMenu'&&n.props.label==='New map');creationMenu.props.actions.find(action=>action.label==='Import image').onClick();assert.equal(imports,1);assert.equal(created,0);
 await creationMenu.props.actions.find(action=>action.label==='Draw new map').onClick();assert.equal(created,1);assert.equal(imports,1);si=0;ri=0;const creationEffects=[];React.useEffect=(effect,deps)=>creationEffects.push({effect,deps});const createdProps={maps:{schemaVersion:1,maps:[{...map,id:'new-map'}]},world:{entries:[],templates:[]},path:'/book',projectId:'p',mapId:'new-map',markerId:'',onSelectMap(){},onSelectMarker(){},onChange(){},onOpenEntry(){},async onImport(){}};nodes(MapsEditor(createdProps));React.useEffect=()=>{};creationEffects.find(({deps})=>deps?.length===3&&deps[0]===true&&deps[1]==='new-map'&&deps[2]==='new-map').effect();si=0;ri=0;const createdNodes=nodes(MapsEditor(createdProps));assert(createdNodes.find(n=>n.type===Editor)?.props.embedded);assert.equal(createdNodes.find(n=>n.type===Editor)?.props.map.id,'new-map','Creation opens the returned map in the drawing editor');
}finally{Object.assign(React,old);}
loadLocal('../src/i18n.ts').setLanguage('es');
const html=renderToStaticMarkup(createElement(Editor,{map,path:'/book',projectId:'p',onCancel(){},onSave(){}}));assert(html.includes('Dibujar mapa')&&html.includes('Tierra')&&html.includes('Montañas')&&html.includes('Aplicar dibujo'));
console.log('Map drawing: terrain ordering, original SVG symbols, safe labels, coordinates, actual paint/move/cancel gestures, undo/redo, discard, deferred image loading, independent image import, themed palettes/backgrounds, mixed symbols/colors and schema preservation passed.');
