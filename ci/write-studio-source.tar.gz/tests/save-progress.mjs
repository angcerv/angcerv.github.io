import assert from 'node:assert/strict';
import {createElement} from 'react';
import {createRequire} from 'node:module';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const Dialog=loadLocal('../src/SaveProgressDialog.tsx').default;
const I=loadLocal('../src/i18n.ts');I.setLanguage('es');
for(const phase of ['saving','finishing']){
 const html=renderToStaticMarkup(createElement(Dialog,{phase,error:'',onClose(){}}));
 assert(html.includes('role="status"'));assert(html.includes('aria-busy="true"'));assert(!html.includes('<progress'));assert(html.includes('save-progress-spinner'));assert(!html.includes('value='));assert(!html.includes('ui-close-button'));
 assert(html.includes(phase==='saving'?'Guardando proyecto':'Finalizando guardado'));
}
for(const [phase,label] of [['opening','Abriendo proyecto'],['creating','Creando proyecto'],['restoring','Restaurando copia'],['downloading','Descargando proyecto desde iCloud']]){
 const html=renderToStaticMarkup(createElement(Dialog,{phase,error:'',onClose(){}}));
 assert(html.includes(label));assert.equal((html.match(/save-progress-spinner/g)??[]).length,1);assert(html.includes('role="status"'));assert(html.includes('aria-busy="true"'));assert(html.includes('save-progress-spinner'));assert(html.includes('ui-confirmation-dialog'));assert(!html.includes('ui-close-button'));
}
for(const [phase,status] of [['opening','Leyendo los datos del proyecto…'],['downloading','Descargando proyecto desde iCloud…'],['preparing','Preparando el espacio de escritura…']]){
 const html=renderToStaticMarkup(createElement(Dialog,{phase,projectName:'The Guard',error:'',onClose(){}}));
 assert(html.includes('Abriendo The Guard'));assert(html.includes(status));
 assert.equal((html.match(/save-progress-spinner/g)??[]).length,1);
}
// No modal on quick opens; phase updates do not restart the delay; unmount clears it.
const React=createRequire(import.meta.url)('react'),{ProjectLoadingDialog}=loadLocal('../src/SaveProgressDialog.tsx');
const originals={useState:React.useState,useEffect:React.useEffect},oldWindow=globalThis.window;
let visible=false,runTimer,cleanup,delay,cleared=false,effectRegistered=false;
try{
 React.useState=()=>[visible,value=>visible=value];
 React.useEffect=setup=>{if(!effectRegistered){effectRegistered=true;cleanup=setup();}};
 globalThis.window={setTimeout(fn,ms){runTimer=fn;delay=ms;return 7;},clearTimeout(id){assert.equal(id,7);cleared=true;}};
 assert.equal(ProjectLoadingDialog({phase:'opening'}),null);assert.equal(delay,900);
 assert.equal(ProjectLoadingDialog({phase:'downloading'}),null);runTimer();
 const panel=ProjectLoadingDialog({phase:'preparing',projectName:'The Guard'});
 assert.equal(panel.props.phase,'preparing');assert.equal(panel.props.projectName,'The Guard');
 cleanup();assert(cleared);
 visible=false;effectRegistered=false;cleared=false;
 assert.equal(ProjectLoadingDialog({phase:'opening'}),null);cleanup();assert(cleared);assert(!visible);
}finally{Object.assign(React,originals);if(oldWindow===undefined)delete globalThis.window;else globalThis.window=oldWindow;}
let retried=0;
const retryTree=Dialog({phase:'opening',error:'Download timed out',onClose(){},onRetry(){retried++;}});
assert.equal(retryTree.props.busy,false);
const retryHtml=renderToStaticMarkup(createElement(Dialog,{phase:'opening',error:'Download timed out',onClose(){},onRetry(){}}));
assert(retryHtml.includes('Reintentar'));assert(retryHtml.includes('No se pudo abrir el proyecto'));assert(retryHtml.includes('role="alert"'));
let closed=0;const tree=Dialog({phase:'saving',error:'Disk full',onClose(){closed++;}});assert.equal(tree.props.busy,false);tree.props.onClose();assert.equal(closed,1);
const html=renderToStaticMarkup(createElement(Dialog,{phase:'saving',error:'Disk full',onClose(){}}));assert(html.includes('role="alert"'));assert(html.includes('Disk full'));assert(html.includes('Cerrar'));assert(!html.includes('<progress'));
I.setLanguage('en');console.log('Save popup: localized phases, single spinner, busy close guard, dismissible error and manual-only integration passed without UI.');
