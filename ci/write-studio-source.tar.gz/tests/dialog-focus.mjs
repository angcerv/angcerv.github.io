import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const {focusDialog}=loadLocal('../src/dialogFocus.ts');
class Target{
 constructor(name,{disabled=false,hidden=false,autofocus=false,initial=false,field=false,visible=true}={}){Object.assign(this,{name,disabled,hidden,autofocus,initial,field,visible,attributes:{},isConnected:true});}
 matches(){return this.disabled;}
 closest(){return this.hidden?{}:null;}
 getClientRects(){return this.visible?[{}]:[];}
 setAttribute(key,value){this.attributes[key]=value;}
 focus(options){this.focused=options??true;}
}
const title=new Target('Title'),selected=new Target('Selected book'),close=new Target('Close'),checkbox=new Target('First checkbox');
function dialog(children=[close,selected,checkbox]){return {querySelectorAll:selector=>children.filter(e=>selector==='[autofocus]'?e.autofocus:selector==='[data-initial-focus]'?e.initial:e.field),querySelector:()=>title,focus(){throw Error('A labelled dialog should focus its title');}};}
focusDialog(dialog(),true);assert.deepEqual(title.focused,{preventScroll:true});assert.equal(selected.focused,undefined);assert.equal(close.focused,undefined);assert.equal(checkbox.focused,undefined);assert.equal(title.attributes.tabindex,'-1');
const field=new Target('Name',{field:true}),invisible=new Target('Hidden search',{field:true,visible:false}),disabled=new Target('Unavailable',{field:true,disabled:true});focusDialog(dialog([invisible,disabled,field]),true);assert(!field.focused);assert(!invisible.focused&&!disabled.focused);assert(title.focused);
field.focused=undefined;focusDialog(dialog([field]),false);assert.equal(field.focused,undefined,'Consultation/list dialogs do not automatically select a filter');
const cancel=new Target('Safe cancellation',{autofocus:true}),explicit=new Target('Progress',{initial:true});focusDialog(dialog([explicit,cancel,field]),true);assert(!cancel.focused&&!explicit.focused);assert(title.focused,'Actions and initial markers never override the neutral title');
focusDialog(dialog([explicit]),false);assert(!explicit.focused,'Opening a popup never preselects a control');
const hidden=new Target('Hidden initial',{autofocus:true,hidden:true});title.focused=undefined;focusDialog(dialog([hidden]),false);assert(title.focused&&!hidden.focused);focusDialog(null);
// Exercise the real shared modal lifecycle, including focus restoration and repeat mounting.
const React=createRequire(import.meta.url)('react'),Modal=loadLocal('../src/ProjectModal.tsx').default,original={useRef:React.useRef,useId:React.useId,useEffect:React.useEffect},oldDocument=globalThis.document;
let setup,shown=0,closed=0,restored=0;
const native={...dialog(),showModal(){shown++;},close(){closed++;}},previous={isConnected:true,focus(){restored++;}};
try{
 globalThis.document={activeElement:previous};React.useRef=()=>({current:native});React.useId=()=> 'dialog-title';React.useEffect=fn=>{setup=fn;};
 Modal({title:'Books',children:null,onClose(){}});let cleanup=setup();assert.equal(shown,1);assert(title.focused);assert(!selected.focused&&!close.focused);cleanup();assert.equal(closed,1);assert.equal(restored,1);
 cleanup=setup();assert.equal(shown,2);assert(!selected.focused);cleanup();assert.equal(restored,2,'Repeated/Strict Mode setup retains predictable initial and return focus');
}finally{Object.assign(React,original);if(oldDocument===undefined)delete globalThis.document;else globalThis.document=oldDocument;}
// Actual import dialog lifecycle: the X and first source action must not become initial targets.
const DOM=createRequire(import.meta.url)('react-dom'),ImportDialog=loadLocal('../src/EntryTransferDialog.tsx').default;
const saved={useRef:React.useRef,useEffect:React.useEffect,useState:React.useState,createPortal:DOM.createPortal},previousDocument=globalThis.document;
try{
 const effects=[];let restoredOptions;
 const opener={isConnected:true,focus(options){restoredOptions=options;}};
 globalThis.document={activeElement:opener,body:{}};
 React.useRef=value=>({current:value===null?native:value});React.useState=value=>[typeof value==='function'?value():value,()=>{}];React.useEffect=effect=>effects.push(effect);DOM.createPortal=content=>content;
 title.focused=undefined;close.focused=undefined;
 ImportDialog({world:{entries:[],templates:[]},initialId:'',mode:'import',onLoad:async()=>null,onExport:async()=>false,onImport:async()=>false,onClose(){}});
 const cleanup=effects[0]();assert.deepEqual(title.focused,{preventScroll:true});assert.equal(close.focused,undefined);cleanup();assert.deepEqual(restoredOptions,{preventScroll:true});
}finally{React.useRef=saved.useRef;React.useEffect=saved.useEffect;React.useState=saved.useState;DOM.createPortal=saved.createPortal;if(previousDocument===undefined)delete globalThis.document;else globalThis.document=previousDocument;}
console.log('Dialog focus: neutral titles for lists, forms and confirmations, ignoring autofocus/initial control markers, no automatic selected-book/button/checkbox focus, repeat setup and focus restoration passed without UI.');
// Regression: deleting an entry must start at its title, never Cancel/Delete.
const WorldDeletion=loadLocal('../src/WorldDeletionDialog.tsx').default;
const deletionHooks={useRef:React.useRef,useEffect:React.useEffect};
const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
try{
 let effect;title.focused=undefined;
 React.useRef=()=>({current:native});React.useEffect=fn=>{effect=fn;};
 const tree=WorldDeletion({world:{templates:[],entries:[{id:'entry',title:'Place',values:{}}]},target:{kind:'entry',id:'entry'},onCancel(){},onConfirm(){}});
 assert(nodes(tree).filter(node=>node.type==='button').every(node=>!node.props.autoFocus));
 const cleanup=effect();assert.deepEqual(title.focused,{preventScroll:true});cleanup();
}finally{Object.assign(React,deletionHooks);}
console.log('Entry deletion: neutral title focus and no preselected actions passed.');
