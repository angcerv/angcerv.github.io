import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const {addMapLayer,setMapLayerVisible,removeMapLayer,filterMapMarkers,visibleLayerMarkers,visibleMapRoutes,addMapRoute,mapLayerVisible}=loadLocal('../src/maps.ts');
const {setLanguage}=loadLocal('../src/i18n.ts');
const marker=(id,entryId)=>({id,title:id,notes:'',x:.5,y:.5,color:'teal',icon:'city',entryId});
const original={schemaVersion:1,maps:[{id:'map',title:'Atlas',imageId:'image',notes:'',markers:[marker('a','entryA'),marker('b','entryB'),marker('c')]}]},world={templates:[{id:'place',title:'Places',fields:[]},{id:'person',title:'People',fields:[]}],entries:[{id:'entryA',title:'City',templateId:'place'},{id:'entryB',title:'Person',templateId:'person'}]};
const before=JSON.stringify(original);
let added=addMapLayer(original,'map',' Cities ');assert.equal(added.maps.schemaVersion,3);let maps=added.maps,cities=added.layerId;assert.equal(maps.maps[0].layers[0].title,'Cities');assert.equal(addMapLayer(maps,'map',' '),null);
added=addMapLayer(maps,'map','Journey');maps=added.maps;const journey=added.layerId;maps={...maps,maps:[{...maps.maps[0],markers:maps.maps[0].markers.map(m=>({...m,layerId:m.id==='c'?undefined:cities}))}]};
const routed=addMapRoute(maps,'map','Trip',['a','b']);assert.equal(routed.maps.schemaVersion,3,'Creating a route must never downgrade layer schema');maps=routed.maps;maps.maps[0].routes[0]={...maps.maps[0].routes[0],layerId:journey};
maps=setMapLayerVisible(maps,'map',cities,false);let map=maps.maps[0],template=filterMapMarkers(map,world,'');assert.deepEqual(visibleLayerMarkers(map,template).map(m=>m.id),['c']);assert.equal(visibleMapRoutes(map,template).length,1,'Visible route layers are independent of hidden marker layers');assert.equal(visibleMapRoutes(map,filterMapMarkers(map,world,'place')).length,0,'Template filters still apply to route stops');
const hidden=setMapLayerVisible(maps,'map',journey,false);assert.equal(visibleMapRoutes(hidden.maps[0],template).length,0);assert.equal(mapLayerVisible(map),true);
const removed=removeMapLayer(maps,'map',cities);assert.equal(removed.maps[0].markers.length,3);assert.equal(removed.maps[0].routes.length,1);assert.equal(removed.maps[0].markers[0].layerId,undefined);assert.equal(removed.maps[0].routes[0].layerId,journey);assert.equal(visibleLayerMarkers(removed.maps[0],template).length,3);assert.equal(JSON.stringify(original),before);
const removedRouteLayer=removeMapLayer(maps,'map',journey);assert.equal(removedRouteLayer.maps[0].routes[0].layerId,undefined);assert.equal(removedRouteLayer.maps[0].routes[0].markerIds.length,2);
const Panel=loadLocal('../src/MapLayersPanel.tsx').default;
const require=createRequire(import.meta.url),React=require('react'),oldState=React.useState,oldRef=React.useRef,oldEffect=React.useEffect;let state=null,changes=[];
function nodes(n){if(Array.isArray(n))return n.flatMap(nodes);if(!n||typeof n!=='object')return [];return[n,...nodes(n.props?.children)];}
const props={maps,map:maps.maps[0],onChange:next=>changes.push(next)};
try{
 React.useRef=initial=>({current:initial});React.useEffect=()=>{};
 React.useState=initial=>initial===null?[state,value=>{state=value;}]:[initial,()=>{}];let all=nodes(Panel(props));
 all.find(n=>n.props?.['aria-label']==='Reorder a').props.onKeyDown({key:'ArrowDown',preventDefault(){},stopPropagation(){}});assert.deepEqual(changes.at(-1).maps[0].markers.map(item=>item.id),['b','a','c'],'Geographic order changes only peers in the same layer');
 all.find(n=>n.props?.['aria-label']==='Reorder Journey').props.onKeyDown({key:'ArrowDown',preventDefault(){},stopPropagation(){}});assert.deepEqual(changes.at(-1).maps[0].layers.map(item=>item.id),[journey,cities],'Displayed layer order maps back to canvas stacking');
 all.find(n=>n.props?.['aria-label']==='Show layer Cities').props.onClick();assert.equal(changes.at(-1).maps[0].layers[0].visible,true);
 all.find(n=>n.props?.['aria-label']==='Show all layers').props.onClick();assert.ok(changes.at(-1).maps[0].layers.every(l=>l.visible));
 assert(!all.some(n=>n.type==='button'&&n.props?.['aria-label']?.startsWith('Lock layer')));all.find(n=>n.props?.label==='Layer options for Cities').props.actions.find(action=>action.label==='Lock layer Cities').onClick();const locked=changes.at(-1);assert(locked.maps[0].layers.find(layer=>layer.id===cities).locked);const lockedTree=nodes(Panel({...props,maps:locked,map:locked.maps[0]}));assert(lockedTree.some(n=>n.type?.name==='LockKeyhole'||n.props?.['aria-label']==='Locked'));lockedTree.find(n=>n.props?.label==='Layer options for Cities').props.actions.find(action=>action.label==='Unlock layer Cities').onClick();assert(!changes.at(-1).maps[0].layers.find(layer=>layer.id===cities).locked);
 all.find(n=>n.props?.label==='Layer options for Cities').props.actions.find(action=>action.label==='Delete layer').onClick();all=nodes(Panel(props));let dialog=all.find(n=>typeof n.type==='function'&&n.type.name==='LayerDialog');assert.equal(dialog.props.deleting,true);dialog.props.onDelete();assert.equal(changes.at(-1).maps[0].markers.length,3);assert.equal(changes.at(-1).maps[0].layers.length,1);
 state=null;all=nodes(Panel(props));all.find(n=>n.props?.label==='Layer options for Journey').props.actions.find(action=>action.label==='Rename layer').onClick();all=nodes(Panel(props));dialog=all.find(n=>typeof n.type==='function'&&n.type.name==='LayerDialog');dialog.props.onSave('Thomas journey');assert.equal(changes.at(-1).maps[0].layers[1].title,'Thomas journey');
}finally{React.useState=oldState;React.useRef=oldRef;React.useEffect=oldEffect;}
setLanguage('es');let html=renderToStaticMarkup(createElement(Panel,props));assert.ok(html.includes('Capas'));assert.ok(html.includes('Mostrar capa Cities'));assert.ok(html.includes('Sin capa'));
const Editor=loadLocal('../src/MapsEditor.tsx').default;html=renderToStaticMarkup(createElement(Editor,{maps,world,path:'/project',projectId:'p',mapId:'map',markerId:'c',onSelectMap(){},onSelectMarker(){},onChange(){},async onImport(){},onOpenEntry(){}}));assert.ok(html.includes('marker-layer'));setLanguage('en');
// The real editor reveals a hidden marker layer when navigated to from a world entry/route stop.
const oldHooks={useState:React.useState,useEffect:React.useEffect,useRef:React.useRef};let hookIndex=0,effects=[],navigationChanges=[];const editorHooks=['person','','',null];
try{
 React.useRef=initial=>({current:initial});React.useEffect=()=>{};
 React.useState=initial=>{const i=hookIndex++;if(!(i in editorHooks))editorHooks[i]=typeof initial==='function'?initial():initial;return[editorHooks[i],value=>{editorHooks[i]=value;}];};React.useEffect=fn=>effects.push(fn);React.useRef=initial=>({current:initial});
 Editor({maps,world,path:'/project',projectId:'p',mapId:'map',markerId:'a',onSelectMap(){},onSelectMarker(){},onChange:next=>navigationChanges.push(next),async onImport(){},onOpenEntry(){}});
 effects[1]();assert.equal(editorHooks[0],'');assert.equal(navigationChanges[0].maps[0].layers.find(l=>l.id===cities).visible,true);assert.equal(navigationChanges[0].schemaVersion,3);
}finally{Object.assign(React,oldHooks);}
console.log('Map layers: schema upgrade, independent route/marker visibility, template composition, no-layer defaults, safe layer removal, rename/toggle controls and Spanish editor passed.');

const {drawingSvg,drawingContent,drawingDataUrl,drawingLayerEditable}=loadLocal('../src/mapDrawing.ts');
const {setMapLayerLocked}=loadLocal('../src/maps.ts');
const artwork={width:1600,height:1000,strokes:[{kind:'land',width:.1,points:[{x:.2,y:.3}],layerId:cities}],objects:[{id:'visible-art',kind:'label',text:'Visible city',x:.2,y:.3,size:.03,layerId:journey},{id:'hidden-art',kind:'label',text:'Hidden city',x:.4,y:.3,size:.03,layerId:cities}]};
const layered={...maps,maps:[{...maps.maps[0],drawing:artwork}]};
const locked=setMapLayerLocked(layered,'map',journey,true);assert.equal(locked.schemaVersion,11);assert.equal(drawingLayerEditable(locked.maps[0].layers,journey),false);
let svg=drawingSvg(artwork,true,locked.maps[0].layers);assert(svg.includes('Visible city'));assert(!svg.includes('Hidden city'));
assert(drawingContent(artwork,true,locked.maps[0].layers,true).includes('data-art-id="visible-art" pointer-events="none"'));
const first=drawingDataUrl(artwork,true,locked.maps[0].layers),revealed=setMapLayerVisible(locked,'map',cities,true);assert.notEqual(drawingDataUrl(artwork,true,revealed.maps[0].layers),first,'Layer changes invalidate the SVG image cache');
const reassigned=removeMapLayer(locked,'map',cities).maps[0].drawing;assert.equal(reassigned.strokes.length,1);assert.equal(reassigned.objects.length,2);assert.equal(reassigned.strokes[0].layerId,undefined);assert.equal(reassigned.objects[1].layerId,undefined);assert.equal(reassigned.objects[0].layerId,journey);assert.equal(artwork.strokes[0].layerId,cities);
console.log('Drawing layers: shared visibility, locked hit testing, cache invalidation and safe layer removal passed.');

const {reorderMapLayers}=loadLocal('../src/maps.ts');
const originalLayers=locked.maps[0].layers,raised=reorderMapLayers(originalLayers,cities,'up');
assert.deepEqual(raised.map(l=>l.id),[journey,cities]);assert.equal(originalLayers[0].id,cities,'Reorder must not mutate saved layers');
assert.equal(reorderMapLayers(raised,cities,'up'),raised);assert.equal(reorderMapLayers(originalLayers,cities,'down'),originalLayers);assert.equal(reorderMapLayers(originalLayers,'missing','up'),originalLayers);
assert.deepEqual(reorderMapLayers(raised,cities,'down'),originalLayers);assert.equal(raised[0].locked,true,'Reordering preserves locks');
const orderedSvg=drawingSvg(artwork,true,raised.map(l=>({...l,visible:true})));assert(orderedSvg.indexOf('Visible city')<orderedSvg.indexOf('Hidden city'),'Raised artwork is painted last, on top');
const Controls=loadLocal('../src/LayerOrderControls.tsx').default;let reordered;
let buttons=nodes(Controls({layers:originalLayers,id:cities,onChange:next=>reordered=next})).filter(n=>n.type==='button');assert.equal(buttons[1].props.disabled,true);buttons[0].props.onClick();assert.deepEqual(reordered,raised);
buttons=nodes(Controls({layers:raised,id:cities,onChange(){}})).filter(n=>n.type==='button');assert.equal(buttons[0].props.disabled,true);
console.log('Layer stacking: immutable reorder, boundaries, preserved locks, actual controls and shared SVG export order passed.');
// Type filters show matching elements, rather than empty repeated type groups.
let viewState=[],viewIndex=0,created=[],selectedRegion='';
const regionMap={...map,layers:[{id:'names',title:'Nombres',visible:true},{id:'regions',title:'Regiones',visible:true}],markers:[],routes:[],regions:[{id:'north',title:'North coast',layerId:'names',color:'teal',points:[{x:0,y:0},{x:1,y:0},{x:0,y:1}]}],drawing:{width:1600,height:1000,strokes:[],objects:[{id:'name',kind:'label',text:'North',x:.5,y:.5,size:.02,layerId:'names'},{id:'outline',kind:'label',text:'South',x:.5,y:.5,size:.02,layerId:'regions'}]}};
const filteredProps={maps:{schemaVersion:17,maps:[regionMap]},map:regionMap,onChange(){},onAddRegion:layerId=>created.push(layerId),onSelectRegion:id=>selectedRegion=id};
function renderLayerView(){viewIndex=0;return nodes(Panel(filteredProps));}
try{
 React.useRef=initial=>({current:initial});React.useEffect=()=>{};
 React.useState=initial=>{const i=viewIndex++;if(!(i in viewState))viewState[i]=initial;return [viewState[i],value=>viewState[i]=value];};
 let tree=renderLayerView();
 assert(nodes(tree.find(n=>n.type==='header')).some(n=>n.props?.['aria-label']==='New layer'),'Layer creation stays with its heading');
 assert(!nodes(tree.find(n=>n.type==='header')).some(n=>n.type?.name==='FieldHelp'));assert(nodes(tree.find(n=>n.type?.name==='RelationshipOptions')).some(n=>n.type?.name==='FieldHelp'),'Optional layer help stays with filters');
 for(const branch of tree.filter(n=>n.type?.name==='LayerBranch'))assert(!nodes(branch).find(n=>n.props?.className==='map-layer-heading').props.children.some(n=>n?.props?.className==='map-layer-art-count'));

 assert(!tree.some(n=>n.type==='button'&&n.props?.['aria-label']?.startsWith('Rename layer')));assert(!tree.some(n=>n.type==='button'&&n.props?.['aria-label']?.startsWith('Delete layer')));assert(tree.some(n=>n.type?.name==='RelationshipOptions'&&n.props.label==='Layer filters'));
 for(const branch of tree.filter(n=>n.type?.name==='LayerBranch')){const heading=nodes(branch).find(n=>n.props?.className==='map-layer-heading');assert(nodes(heading).some(n=>n.type?.name==='ActionMenu'&&n.props.label.startsWith('Add to ')),'Each layer adds elements from its own heading');}assert(!tree.some(n=>n.props?.className==='map-layer-order'));
 assert(tree.some(n=>n.type==='strong'&&n.props.title==='Nombres'));
 assert(tree.some(n=>n.type==='strong'&&n.props.title==='Regiones'));
 tree.find(n=>n.props?.id==='map-element-kind').props.onChange('regions');tree=renderLayerView();
 const branches=tree.filter(n=>n.type?.name==='LayerBranch');assert.equal(branches.length,1);assert.equal(branches[0].props.base,true);
 assert(tree.some(n=>n.type==='strong'&&n.props.title==='Nombres'));
 assert(!tree.some(n=>n.type==='strong'&&n.props.title==='Regiones'),'An empty layer named Regions is not a region');
 assert(!tree.some(n=>n.props?.className==='map-layer-art-count'),'Drawing counts do not masquerade as geographic regions');
 assert(tree.filter(n=>n.props?.className==='map-layer-subheading').every(n=>n.props.hidden));
 tree.find(n=>n.props?.className==='map-tree-region').props.onClick();assert.equal(selectedRegion,'north');
 const add=tree.find(n=>n.type==='button'&&nodes(n).some(child=>child===n&&Array.isArray(child.props.children)&&child.props.children.includes('New region')));
 assert(add);assert.equal(add.props.disabled,false);add.props.onClick();assert.deepEqual(created,[undefined]);
 tree.find(n=>n.props?.id==='map-element-search').props.onChange({target:{value:'missing'}});tree=renderLayerView();
 assert.equal(tree.filter(n=>n.type?.name==='LayerBranch').length,0);
 assert(tree.some(n=>Array.isArray(n.props?.children)&&n.props.children.includes('No elements match these filters.')));
 assert(tree.some(n=>n.type==='button'&&Array.isArray(n.props.children)&&n.props.children.includes('New region')),'Creation remains available in an empty filtered view');
 tree.find(n=>n.type==='button'&&n.props.children==='Clear filters').props.onClick();tree=renderLayerView();assert.equal(tree.filter(n=>n.type?.name==='LayerBranch').length,2);const creation=tree.find(n=>n.props?.label==='Add to Nombres');assert(creation);creation.props.actions.find(action=>action.label==='New region in Nombres').onClick();assert.deepEqual(created,[undefined,'names']);
 let clearedExternal=0;viewIndex=0;const externallyFiltered=nodes(Panel({...filteredProps,filterSummary:'Places',filters:createElement('div',{id:'template-filter-content'},'Templates'),onClearFilters:()=>clearedExternal++}));const filterPopover=externallyFiltered.find(n=>n.type?.name==='RelationshipOptions');assert(nodes(filterPopover).some(n=>n.props?.id==='template-filter-content'));assert(nodes(filterPopover).some(n=>n.props?.id==='map-element-kind'));assert(externallyFiltered.some(n=>n.props?.className==='map-layer-filter-summary'));externallyFiltered.find(n=>n.props?.['aria-label']==='Clear filters').props.onClick();assert.equal(clearedExternal,1);

}finally{React.useState=oldState;React.useRef=oldRef;React.useEffect=oldEffect;}
console.log('Layer browsing: explicit layer labels, type-specific counts, matching groups only, no duplicate type headings, empty state, selection and creation passed without UI.');

const DrawingLayerBrowser=loadLocal('../src/DrawingLayersPanel.tsx').default;
try{
 React.useRef=initial=>({current:initial});React.useEffect=()=>{};
 React.useState=initial=>[initial,()=>{}];
 let picked='',changedLayers;const drawingLayers=[{id:'front',title:'Front',visible:true},{id:'locked',title:'Locked',visible:true,locked:true}];
 const layeredDrawing={width:1600,height:1000,strokes:[{kind:'land',width:.1,points:[{x:.2,y:.2}],layerId:'front'}],objects:[{id:'label',kind:'label',text:'Harbor',x:.2,y:.2,size:.02,layerId:'front'},{id:'castle',kind:'castle',x:.5,y:.5,size:.05,layerId:'locked'}]};
 const browser=nodes(DrawingLayerBrowser({layers:drawingLayers,drawing:layeredDrawing,activeId:'front',selectedId:'label',onActive(){},onChange:value=>changedLayers=value,onMoveTerrain(){},onSelectObject:id=>picked=id}));
 const groups=browser.filter(node=>node.props?.className==='drawing-layer-group');assert.equal(groups.length,2);
 const front=groups.find(group=>nodes(group).some(node=>node.props?.className?.includes('drawing-layer-name')&&node.props['aria-pressed']));
 const item=nodes(front).find(node=>node.props?.className==='quick-action quick-action-text');assert(item.props['aria-pressed']);item.props.onClick();assert.equal(picked,'label');
 assert(nodes(front).some(node=>node.props?.children==='Terrain strokes: 1'));
 const actions=nodes(front).find(node=>node.type?.name==='ActionMenu'&&node.props.label==='Layer options for Front').props.actions;actions.find(action=>action.label==='Lock layer Front').onClick();assert(changedLayers[0].locked);actions.find(action=>action.label==='Raise layer Front').onClick();assert.deepEqual(changedLayers.map(layer=>layer.id),['locked','front']);assert(actions.find(action=>action.label==='Lower layer Front').disabled);
 let orderedObjects;const orderedBrowser=nodes(DrawingLayerBrowser({layers:drawingLayers,drawing:{...layeredDrawing,objects:[...layeredDrawing.objects,{...layeredDrawing.objects[0],id:'second',text:'Second'}]},activeId:'front',onActive(){},onChange(){},onMoveTerrain(){},onOrderObjects:ids=>orderedObjects=ids}));orderedBrowser.find(node=>node.props?.['aria-label']==='Reorder Second').props.onKeyDown({key:'ArrowDown',preventDefault(){},stopPropagation(){}});assert.deepEqual(orderedObjects,['second','label'],'Drawing display order maps back to paint order without other layers');
 const locked=groups.find(group=>group!==front);assert(nodes(locked).find(node=>node.props?.className==='quick-action quick-action-text').props.disabled);
}finally{React.useState=oldState;React.useRef=oldRef;React.useEffect=oldEffect;}
console.log('Drawing layer browser: grouped objects, terrain counts, selected state, canonical selection and lock guards passed without UI.');
