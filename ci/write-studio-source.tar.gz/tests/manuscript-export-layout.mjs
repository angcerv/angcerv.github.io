import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {spawnSync} from 'node:child_process';
import {loadLocal} from './load-local.mjs';
const {exportManuscript}=loadLocal('../src/manuscriptExport.ts');
const P=loadLocal('../src/manuscriptExportPreferences.ts');
const project={id:'export-layout',title:'Title <&> 世界',schemaVersion:1,revision:0,chapters:[{id:'one',title:'One',scenes:[{id:'s',title:'First',content:'A **bold** _line_.\n\nAnother paragraph.'}]},{id:'two',title:'Two',scenes:[]},{id:'three',title:'Three',scenes:[{id:'last',title:'Last',content:'End.'}]}]};
const original=JSON.stringify(project),ids=project.chapters.map(c=>c.id);
const cases=[{coverPage:true,chapterPageBreaks:false,author:'Author <&> 🌿',font:'times',fontSize:14,lineSpacing:2,paperSize:'letter',margins:'wide',sceneTitles:false},{coverPage:true,chapterPageBreaks:true,font:'arial',fontSize:11,lineSpacing:1,margins:'compact'},{coverPage:false,chapterPageBreaks:false,author:'MUST_NOT_LEAK'},{coverPage:false,chapterPageBreaks:true}];
const bytes=cases.map(options=>Buffer.from(exportManuscript(project,ids,'docx',options)).toString('base64'));
const checked=spawnSync('python3',['-c',`
import sys,json,base64,io,zipfile,xml.etree.ElementTree as E
n={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
w='{'+n['w']+'}'
for index,encoded in enumerate(json.load(sys.stdin)):
 z=zipfile.ZipFile(io.BytesIO(base64.b64decode(encoded)))
 assert z.testzip() is None
 for name in z.namelist(): E.fromstring(z.read(name))
 doc=E.fromstring(z.read('word/document.xml'));styles=E.fromstring(z.read('word/styles.xml'))
 body=doc.find('w:body',n);paragraphs=body.findall('w:p',n)
 text=[''.join(p.itertext()) for p in paragraphs]
 breaks=doc.findall('.//w:pageBreakBefore',n)
 assert len(breaks)==[1,3,0,2][index],(index,len(breaks))
 assert paragraphs[0].find('w:pPr/w:pStyle',n).get(w+'val')==('CoverTitle' if index<2 else 'Title')
 assert text.count('Title <&> 世界')==1
 assert text.index('One')<text.index('Two')<text.index('Three')
 if index==0:
  assert 'Author <&> 🌿' in text
  assert 'First' not in text and 'Last' not in text
  assert doc.find('.//w:pgSz',n).get(w+'w')=='12240'
  assert doc.find('.//w:pgSz',n).get(w+'h')=='15840'
  assert doc.find('.//w:pgMar',n).get(w+'left')=='1701'
  assert styles.find('.//w:rFonts',n).get(w+'ascii')=='Times New Roman'
  assert styles.find('.//w:docDefaults/w:rPrDefault/w:rPr/w:sz',n).get(w+'val')=='28'
  assert styles.find('.//w:docDefaults/w:pPrDefault/w:pPr/w:spacing',n).get(w+'line')=='480'
 if index==1:
  assert not any(p.find('w:pPr/w:pStyle',n) is not None and p.find('w:pPr/w:pStyle',n).get(w+'val')=='CoverAuthor' for p in paragraphs)
  assert doc.find('.//w:pgSz',n).get(w+'w')=='11906'
  assert doc.find('.//w:pgMar',n).get(w+'top')=='1134'
  assert styles.find('.//w:rFonts',n).get(w+'ascii')=='Arial'
  assert styles.find('.//w:docDefaults/w:rPrDefault/w:rPr/w:sz',n).get(w+'val')=='22'
  assert styles.find('.//w:docDefaults/w:pPrDefault/w:pPr/w:spacing',n).get(w+'line')=='240'
 assert all('MUST_NOT_LEAK' not in value for value in text)
 for style_id,level in [('Heading1','0'),('Heading2','1')]:
  style=next(s for s in styles.findall('w:style',n) if s.get(w+'styleId')==style_id)
  assert style.find('w:pPr/w:outlineLvl',n).get(w+'val')==level
 cover=next(s for s in styles.findall('w:style',n) if s.get(w+'styleId')=='CoverTitle')
 assert cover.find('w:pPr/w:jc',n).get(w+'val')=='center'
 assert cover.find('w:pPr/w:keepNext',n) is None,'Cover must not keep with a chapter on the following page'
print('Word layouts: cover isolation, optional author, chapter breaks, paper, margins, fonts, spacing and heading outline passed.')
`],{input:JSON.stringify(bytes),encoding:'utf8'});
assert.equal(checked.status,0,checked.stderr);process.stdout.write(checked.stdout);
const baseline=exportManuscript(project,ids,'md',false),styled=exportManuscript(project,ids,'md',{...cases[0],sceneTitles:false});assert.deepEqual(styled,baseline,'Word-only options must leave Markdown untouched');
assert.equal(JSON.stringify(project),original);
assert.throws(()=>exportManuscript(project,ids,'docx',{coverPage:true,author:'Invalid\u0000'}),/unsupported by Word/);
const oldStorage=globalThis.localStorage,stored=new Map();globalThis.localStorage={getItem:key=>stored.get(key)??null,setItem:(key,value)=>stored.set(key,value)};
try{
 assert.deepEqual(P.loadManuscriptExportPreferences('new'),P.defaultManuscriptExportPreferences);stored.set('write-studio.manuscript-export.reload',JSON.stringify({version:1,options:{...P.defaultManuscriptExportPreferences,font:'times',paperSize:'letter'}}));assert.equal(P.loadManuscriptExportPreferences('reload').font,'times');assert.equal(P.loadManuscriptExportPreferences('reload').paperSize,'letter');
 stored.set('write-studio.manuscript-export.corrupt','{broken');assert.deepEqual(P.loadManuscriptExportPreferences('corrupt'),P.defaultManuscriptExportPreferences);
 stored.set('write-studio.manuscript-export.future',JSON.stringify({version:99,options:cases[0]}));assert.deepEqual(P.loadManuscriptExportPreferences('future'),P.defaultManuscriptExportPreferences);
 const normalized=P.normalizeManuscriptExportPreferences({font:'<unsafe>',fontSize:NaN,lineSpacing:-1,coverPage:'true',paperSize:'giant',margins:'negative'});assert.deepEqual(normalized,P.defaultManuscriptExportPreferences);
 P.storeManuscriptExportPreferences('book',{...P.defaultManuscriptExportPreferences,...cases[0],author:'PRIVATE AUTHOR',selected:['one'],title:'PRIVATE TITLE'});
 assert.equal(P.loadManuscriptExportPreferences('book').font,'times');assert.equal(P.loadManuscriptExportPreferences('other').font,'georgia');
 const saved=stored.get('write-studio.manuscript-export.book');assert(!saved.includes('PRIVATE'));assert(!saved.includes('selected'));assert.equal(P.loadManuscriptExportPreferences('book').fontSize,14);
 globalThis.localStorage={getItem(){throw Error('blocked');},setItem(){throw Error('blocked');}};P.storeManuscriptExportPreferences('blocked',{...P.defaultManuscriptExportPreferences,font:'arial'});assert.equal(P.loadManuscriptExportPreferences('blocked').font,'arial');
}finally{if(oldStorage===undefined)delete globalThis.localStorage;else globalThis.localStorage=oldStorage;}
// Exercise the real dialog's controls and asynchronous save guards without a UI.
const React=createRequire(import.meta.url)('react'),old={useState:React.useState,useMemo:React.useMemo,useEffect:React.useEffect,useRef:React.useRef},storage=loadLocal('../src/storage.ts'),saveOriginal=storage.saveManuscriptExport;
const ExportSuccess=loadLocal('../src/ExportSuccess.tsx').default;
const Dialog=loadLocal('../src/ExportDialog.tsx').default,nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?(n.type===ExportSuccess?nodes(ExportSuccess(n.props)):[n,...nodes(n.props?.children)]):[];
let states=[],refs=[],index=0,refIndex=0,calls=[],fail=false;
try{
 React.useState=initial=>{const at=index++;if(!(at in states))states[at]=typeof initial==='function'?initial():initial;return[states[at],next=>states[at]=typeof next==='function'?next(states[at]):next];};React.useMemo=fn=>fn();React.useEffect=()=>{};React.useRef=value=>{const at=refIndex++;return refs[at]??(refs[at]={current:value});};
 storage.saveManuscriptExport=async(...args)=>{calls.push(args);if(fail)throw Error('Disk unavailable');return '/tmp/manuscript.docx';};
 const render=()=>{index=0;refIndex=0;return nodes(Dialog({project,onClose(){}}));};let tree=render();
 tree.find(n=>n.props.id==='export-font').props.onChange('arial');tree=render();assert.equal(tree.find(n=>n.props.id==='export-font').props.value,'arial');
 tree.find(n=>n.type==='input'&&n.props.type==='checkbox'&&n.props.checked===false).props.onChange({target:{checked:true}});tree=render();assert(tree.some(n=>n.props.id==='export-author'));tree.find(n=>n.props.id==='export-author').props.onChange({target:{value:'Author'}});
 tree=render();const save=tree.find(n=>n.type==='button'&&n.props.className==='primary-button');save.props.onClick();save.props.onClick();tree=render();assert(tree.find(n=>n.type==='fieldset').props.disabled);assert(tree.find(n=>n.props.className==='ui-dialog-heading'));await new Promise(resolve=>setTimeout(resolve,20));assert.equal(calls.length,1);tree=render();assert(tree.some(n=>n.props.role==='status'));
 tree.find(n=>n.props.id==='export-font').props.onChange('times');tree=render();assert(!tree.some(n=>n.props.role==='status'),'Changing settings must clear the previous export confirmation');
 const md=tree.find(n=>n.type==='input'&&n.props.type==='radio'&&!n.props.checked);md.props.onChange();tree=render();assert(!tree.some(n=>n.props.id==='export-font'));assert(!tree.some(n=>n.props.id==='export-author'));
 const word=tree.find(n=>n.type==='input'&&n.props.type==='radio'&&!n.props.checked);word.props.onChange();tree=render();assert.equal(tree.find(n=>n.props.id==='export-author').props.value,'Author');
 fail=true;tree.find(n=>n.type==='button'&&n.props.className==='primary-button').props.onClick();await new Promise(resolve=>setTimeout(resolve,20));tree=render();assert(tree.some(n=>n.props.role==='alert'));assert.equal(tree.find(n=>n.type==='fieldset').props.disabled,false);
}finally{Object.assign(React,old);storage.saveManuscriptExport=saveOriginal;}
console.log('Export preferences: validation, project isolation, content privacy, storage fallback and actual dialog controls, busy/error states and save deduplication passed.');
