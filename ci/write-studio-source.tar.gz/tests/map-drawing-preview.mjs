import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const {createDrawingPreview}=loadLocal('../src/mapDrawingPreview.ts');
const {drawingParts,drawingSvg}=loadLocal('../src/mapDrawing.ts');
const {previewTerrainStroke}=loadLocal('../src/mapTerrain.ts');
let queue=[],cancelled=[],published=[],sequence=0;
const scheduler=createDrawingPreview(value=>published.push(value),callback=>{queue.push({id:++sequence,callback});return sequence;},id=>cancelled.push(id));
const base={width:1600,height:1000,background:'#b9d9df',strokes:[],objects:[]};
for(let i=0;i<1000;i++)scheduler.schedule({...base,width:i+1});assert.equal(queue.length,1);assert.equal(published.length,0);queue.shift().callback();assert.equal(published[0].width,1000);
scheduler.schedule(base);const stale=queue.shift();scheduler.cancel();assert(cancelled.includes(stale.id));stale.callback();assert.equal(published.length,1,'Cancelled pointer frames cannot overwrite a completed or reverted gesture');
scheduler.schedule({...base,width:42});queue.shift().callback();assert.equal(published.at(-1).width,42);
const stroke={kind:'land',material:'earth',textureIntensity:.75,width:.1,points:[{x:.2,y:.2},{x:.4,y:.2}]};
const preview=previewTerrainStroke(stroke,1600,1000);assert(preview.includes('data-live-terrain="earth"'));assert(!/feTurbulence|feDisplacementMap|feMorphology|data-terrain-coast/.test(preview));assert(preview.includes('data-material-detail="earth" opacity="0.75"'));assert(preview.includes('x="232" y="112" width="496" height="176"'),'Live paint is bounded to its footprint instead of the whole map');
const parts=drawingParts(base,true,undefined,true);assert.equal(drawingParts(base,true,undefined,true),parts);assert.equal(drawingParts(base).layers[0].terrain,'');
// Real editor handlers: several pointer moves in one frame, immediate completion,
// correct layer order, final endpoint capture, and cancellation without late writes.
const Editor=loadLocal('../src/MapDrawingEditor.tsx').default,require=createRequire(import.meta.url),React=require('react');
const hooks={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const oldRaf=globalThis.requestAnimationFrame,oldCancel=globalThis.cancelAnimationFrame;
let states=[],refs=[],si=0,ri=0,frames=[],nextFrame=0;
const map={id:'m',title:'Map',imageId:'image',layers:[{id:'lower',title:'Lower',visible:true},{id:'paint',title:'Paint',visible:true},{id:'upper',title:'Upper',visible:true}],drawing:base};
const surface={getBoundingClientRect:()=>({left:0,top:0,width:800,height:500}),focus(){},setPointerCapture(){},hasPointerCapture:()=>true,releasePointerCapture(){}};
function nodes(n){return Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];}
const text=n=>typeof n==='string'?n:Array.isArray(n)?n.map(text).join(''):n?.props?text(n.props.children):'';
const event=(x,y)=>({pointerId:7,isPrimary:true,button:0,clientX:x,clientY:y,currentTarget:surface,target:{closest:()=>null},preventDefault(){}});
try{
 globalThis.requestAnimationFrame=callback=>{frames.push({id:++nextFrame,callback});return nextFrame;};globalThis.cancelAnimationFrame=id=>{frames=frames.filter(frame=>frame.id!==id);};
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],value=>{states[i]=typeof value==='function'?value(states[i]):value;}];};React.useRef=value=>{const i=ri++;return refs[i]??(refs[i]={current:value});};React.useEffect=()=>{};
 const render=()=>{si=0;ri=0;return nodes(Editor({map,path:'/project',projectId:'p',onSave(){},onCancel(){}}));};
 let tree=render();states[4]=true;refs[1].current=surface;tree=render();tree.find(n=>typeof n.type==='function'&&n.type.name==='DrawingLayersPanel').props.onActive('paint');tree=render();tree.find(n=>n.type==='button'&&text(n)==='Material').props.onClick();tree=render();
 const canvas=()=>render().find(n=>n.type==='svg'&&n.props['aria-label']==='Map drawing canvas');
 canvas().props.onPointerDown(event(160,100));const first=states[0];assert.equal(first.strokes.length,1,'Pointer down creates the live stroke');assert(refs[3].current?.stroke);const firstTree=render();
 const stableTerrain=firstTree.filter(n=>n.props?.dangerouslySetInnerHTML).map(n=>n.props.dangerouslySetInnerHTML.__html);
 for(let i=1;i<=20;i++)canvas().props.onPointerMove(event(160+i*8,100));assert.equal(frames.length,1);assert.equal(states[0],first,'Pointer moves queue one frame instead of twenty React renders');
 frames.shift().callback();assert(states[0].strokes[0].points.length>1);tree=render();const layerNodes=tree.filter(n=>n.props?.['data-drawing-layer']!==undefined);assert.deepEqual(layerNodes.map(n=>n.props['data-drawing-layer']),['','lower','paint','upper']);
 assert(nodes(layerNodes[2]).some(n=>n.props?.['data-live-stroke']!==undefined));assert(!nodes(layerNodes[3]).some(n=>n.props?.['data-live-stroke']!==undefined));
 assert(tree.filter(n=>n.props?.dangerouslySetInnerHTML&&!n.props['data-live-stroke']).some(n=>stableTerrain.includes(n.props.dangerouslySetInnerHTML.__html)));
 canvas().props.onPointerMove(event(400,100));const pendingFrame=frames[0];canvas().props.onPointerUp(event(440,100));assert.equal(frames.length,0);assert.equal(states[0].strokes[0].points.at(-1).x,.55);assert.equal(states[1].length,1,'One completed gesture creates one undo entry');const completed=states[0];pendingFrame.callback();assert.equal(states[0],completed);assert(drawingSvg(completed).includes('data-terrain-coast=')&&!drawingSvg(completed).includes('<filter'),'Completed terrain keeps vector coasts without expensive filter buffers');
 canvas().props.onPointerDown(event(100,200));canvas().props.onPointerMove(event(200,200));const cancelledFrame=frames[0];canvas().props.onPointerCancel(event(200,200));assert.equal(states[0],completed);cancelledFrame.callback();assert.equal(states[0],completed);
 // The final point also respects the existing 2,000-point gesture limit.
 canvas().props.onPointerDown(event(100,200));refs[3].current.stroke={...refs[3].current.stroke,points:Array.from({length:2000},()=>({x:.2,y:.2}))};canvas().props.onPointerUp(event(240,200));assert.equal(states[0].strokes.at(-1).points.length,2000);assert.equal(states[0].strokes.at(-1).points.at(-1).x,.3);
}finally{Object.assign(React,hooks);if(oldRaf===undefined)delete globalThis.requestAnimationFrame;else globalThis.requestAnimationFrame=oldRaf;if(oldCancel===undefined)delete globalThis.cancelAnimationFrame;else globalThis.cancelAnimationFrame=oldCancel;}
console.log('Brush preview: latest-only frames, no live finishing filters, cached committed layers, correct overlay order, pointer-up endpoint/undo, cancelled frames and unchanged committed finish passed without launching a UI.');
