import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const React=createRequire(import.meta.url)('react'),Preview=loadLocal('../src/MapPointerPreview.tsx').default;
const hooks={useState:React.useState,useEffect:React.useEffect},globals={window:globalThis.window,requestAnimationFrame:globalThis.requestAnimationFrame,cancelAnimationFrame:globalThis.cancelAnimationFrame};
let position=null,effect,frames=new Map(),sequence=0,cancelled=[];
const listeners=new Map(),windowListeners=new Map();
const surface={current:{addEventListener:(name,fn)=>listeners.set(name,fn),removeEventListener:name=>listeners.delete(name)}};
const bounds={current:{getBoundingClientRect:()=>({left:100,top:50,width:800,height:400})}};
const props={surface,bounds,enabled:true,width:1600,height:800,radiusX:80,from:{x:.1,y:.2},standalone:true};
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
try{
 React.useState=()=>[position,value=>position=value];React.useEffect=fn=>effect=fn;
 globalThis.window={addEventListener:(name,fn)=>windowListeners.set(name,fn),removeEventListener:name=>windowListeners.delete(name)};
 globalThis.requestAnimationFrame=fn=>{frames.set(++sequence,fn);return sequence;};globalThis.cancelAnimationFrame=id=>{cancelled.push(id);frames.delete(id);};
 const render=()=>nodes(Preview(props)),move=(x,y,type='mouse')=>listeners.get('pointermove')({clientX:x,clientY:y,pointerType:type,isPrimary:true});
 render();let cleanup=effect();move(300,150);move(500,250);assert.equal(frames.size,1);assert.equal(position,null);
 const flush=()=>{const callbacks=[...frames.values()];frames.clear();callbacks.forEach(fn=>fn());};flush();assert.deepEqual(position,{x:.5,y:.5});
 let tree=render();const ellipses=tree.filter(n=>n.type==='ellipse');assert.equal(ellipses.length,2);for(const ellipse of ellipses){assert.equal(ellipse.props.cx,800);assert.equal(ellipse.props.cy,400);assert.equal(ellipse.props.rx,80);assert.equal(ellipse.props.ry,80);assert.equal(ellipse.props.vectorEffect,'non-scaling-stroke');}
 const guide=tree.find(n=>n.type==='line');assert.equal(guide.props.x1,160);assert.equal(guide.props.y1,160);assert.equal(guide.props.x2,800);
 assert.equal(tree[0].props['aria-hidden'],'true');assert.equal(tree[0].props.pointerEvents,'none');
 move(600,250);listeners.get('pointerleave')();assert.equal(frames.size,0);assert.equal(position,null);assert(cancelled.length);
 move(300,150,'touch');assert.equal(position,null);assert.equal(frames.size,0);
 move(300,150,'pen');flush();assert(position);listeners.get('pointercancel')();assert.equal(position,null);
 move(300,150);flush();windowListeners.get('blur')();assert.equal(position,null);
 move(50,250);flush();assert.equal(position,null,'Outside bounds never shows an inaccurate placement');
 move(300,150);const stale=[...frames.values()][0];cleanup();stale();assert.equal(position,null);assert.equal(listeners.size,0);assert.equal(windowListeners.size,0);
 props.enabled=false;assert.equal(render().length,0);cleanup=effect();assert.equal(listeners.size,0);
}finally{Object.assign(React,hooks);for(const [key,value] of Object.entries(globals)){if(value===undefined)delete globalThis[key];else globalThis[key]=value;}}
const {drawingResizeCursor}=loadLocal('../src/drawingEditorView.ts');
assert.equal(drawingResizeCursor(1,1),'nwse-resize');assert.equal(drawingResizeCursor(-1,1),'nesw-resize');assert.equal(drawingResizeCursor(0,1),'ns-resize');assert.equal(drawingResizeCursor(1,0),'ew-resize');assert.equal(drawingResizeCursor(1,1,45),'ns-resize');assert.equal(drawingResizeCursor(1,1,90),'nesw-resize');
console.log('Pointer previews: bounded latest-frame hover, actual brush radius, vertex guide, native resize directions, touch exclusion, leave/cancel/blur cleanup and noninteractive rendering passed without UI.');
