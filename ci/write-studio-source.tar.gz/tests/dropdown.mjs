import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
const source = readFileSync(new URL('../src/dropdownNavigation.ts', import.meta.url), 'utf8');
const js = ts.transpileModule(source, { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 } }).outputText;
const { nextEnabled, initialOption, matchingOption } = await import(`data:text/javascript;base64,${Buffer.from(js).toString('base64')}`);
const options = [
  { value: '', label: 'All templates' },
  { value: 'archived', label: 'Archived', disabled: true },
  { value: 'people', label: 'People' },
  { value: 'places', label: 'Places' },
  { value: 'elise', label: 'Élise 世界' },
];
assert.equal(initialOption(options, ''), 0, 'Empty string is a valid filter value');
assert.equal(initialOption(options, 'places'), 3);
assert.equal(initialOption(options, 'missing'), 0);
assert.equal(initialOption(options, 'missing', true), 4);
assert.equal(initialOption(options, 'archived'), 0, 'A disabled selection cannot become active');
assert.equal(nextEnabled(options, 0, 1), 2, 'Arrow navigation skips disabled options');
assert.equal(nextEnabled(options, 2, -1), 0);
assert.equal(nextEnabled(options, 4, 1), 0, 'Down wraps to the first option');
assert.equal(nextEnabled(options, 0, -1), 4, 'Up wraps to the last option');
assert.equal(matchingOption(options, 'p', 0), 2);
assert.equal(matchingOption(options, 'p', 3), 3, 'Repeated typing cycles through matching options');
assert.equal(matchingOption(options, 'plac', 2), 3);
assert.equal(matchingOption(options, 'eli', 0), 4, 'Typeahead handles accented names');
assert.equal(matchingOption(options, 'arch', 0), -1, 'Typeahead skips disabled options');
assert.equal(matchingOption(options, 'unknown', 0), -1);
for (const empty of [[], [{ value: 'disabled', label: 'Disabled', disabled: true }]]) {
  assert.equal(initialOption(empty, ''), -1);
  assert.equal(nextEnabled(empty, -1, 1), -1);
  assert.equal(nextEnabled(empty, 0, -1), -1);
  assert.equal(matchingOption(empty, 'd', 0), -1);
}
assert.equal(options[0].value, '', 'Navigation must not change option values');
console.log('Dropdown: selection, wrapping, disabled options, empty menus and accented/repeated typeahead passed.');
