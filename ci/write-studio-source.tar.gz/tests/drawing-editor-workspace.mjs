import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const V=loadLocal('../src/drawingEditorView.ts');
for(const drawing of [{width:1600,height:1000},{width:500,height:1800}])for(const viewport of [{width:900,height:600},{width:300,height:400}]){
 const camera=V.fitDrawingCamera(viewport,drawing);
 assert(drawing.width*camera.scale<=viewport.width&&drawing.height*camera.scale<=viewport.height);
 assert(Math.abs(drawing.width*camera.scale/(drawing.height*camera.scale)-drawing.width/drawing.height)<1e-12);
}
const camera={scale:.4,x:120,y:45},anchor={x:320,y:175},zoomed=V.zoomDrawingCamera(camera,1,2,anchor);
assert.equal((anchor.x-camera.x)/camera.scale,(anchor.x-zoomed.x)/(camera.scale*2));
assert.equal((anchor.y-camera.y)/camera.scale,(anchor.y-zoomed.y)/(camera.scale*2));
const shifted=V.preserveDrawingCamera(camera,{left:300,top:70},{left:48,top:60});
assert.equal(300+camera.x,48+shifted.x);assert.equal(70+camera.y,60+shifted.y);
const drawing={width:1600,height:1000,strokes:[],objects:[{id:'label',kind:'label',text:'Original',x:.3,y:.3,size:.023},{id:'symbol',kind:'castle',x:.6,y:.6,size:.08}]};
assert(!V.drawingDraftChanged(structuredClone(drawing),[],{drawing,layers:[]}));
assert(V.drawingDraftChanged({...drawing,background:'#123456'},[],{drawing,layers:[]}));
assert(V.drawingDraftChanged(drawing,[{id:'new',title:'Layer',visible:true}],{drawing,layers:[]}));
const React=createRequire(import.meta.url)('react'),Editor=loadLocal('../src/MapDrawingEditor.tsx').default;
const oldHooks={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const globals={Element:globalThis.Element,window:globalThis.window,ResizeObserver:globalThis.ResizeObserver};
const expand=['DrawingToolRail','DrawingOptionsPanel','DrawingSelectionInspector','DrawingSection','DrawingColorPicker'];
const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(typeof node.type==='function'&&expand.includes(node.type.name)?node.type(node.props):node.props?.children)]:[];
let state=[],refs=[],si=0,ri=0,effects=[],cancelled=0,saved,resize,liveDialog,tree,compact=false;
let mobile=false;
let rect={left:300,top:80,width:1000,height:650};
class ElementMock{
 constructor(kind='surface',id=''){this.kind=kind;this.id=id;this.captured=false;}
 closest(selector){if(selector==='dialog')return this.kind==='nested'?{}:liveDialog;if(selector.startsWith('input,'))return this.kind==='input'?this:null;if(selector.startsWith('button,'))return this.kind==='button'?this:null;if(selector==='[data-art-id]')return this.id?{getAttribute:()=>this.id}:null;return null;}
 getAttribute(){return null;}
 focus(){}
 setPointerCapture(){this.captured=true;}hasPointerCapture(){return this.captured;}releasePointerCapture(){this.captured=false;}
 getBoundingClientRect(){const paper=tree.find(node=>node.props?.className==='drawing-paper').props.style;return {left:rect.left+paper.left,top:rect.top+paper.top,width:paper.width,height:paper.height};}
}
const surface=new ElementMock(),viewport={clientWidth:1000,clientHeight:650,getBoundingClientRect:()=>rect,addEventListener(){},removeEventListener(){}};
try{
 globalThis.Element=ElementMock;
 globalThis.window={matchMedia:query=>({matches:query.includes('700px')?mobile:compact,addEventListener(){},removeEventListener(){}}),addEventListener(){},removeEventListener(){}};
 globalThis.ResizeObserver=class{constructor(callback){resize=callback;}observe(){}disconnect(){}};
 React.useState=initial=>{const i=si++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return[state[i],next=>state[i]=typeof next==='function'?next(state[i]):next];};
 React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};
 React.useEffect=effect=>effects.push(effect);
 const map={id:'map',title:'Atlas',imageId:'image',markers:[],drawing};
 const render=()=>{si=ri=0;effects=[];tree=nodes(Editor({map,path:'/project',projectId:'p',onCancel:()=>cancelled++,onSave:(value,layers)=>saved={drawing:value,layers}}));liveDialog=tree.find(node=>node.type==='dialog');return tree;};
 const button=label=>tree.find(node=>node.type==='button'&&node.props['aria-label']===label);
 const field=id=>tree.find(node=>node.type==='input'&&node.props.id===id);
 const canvas=()=>tree.find(node=>node.props?.['aria-label']==='Map drawing canvas');
 const paper=()=>tree.find(node=>node.props?.className==='drawing-paper').props.style;
 const event=(x,y,id='')=>({clientX:x,clientY:y,pointerId:1,isPrimary:true,button:0,shiftKey:false,currentTarget:surface,target:new ElementMock('surface',id),preventDefault(){}});
 render();state[3]='image';state[4]=true;render();canvas().props.ref.current=surface;
 // Shared controls sit horizontally above the canvas; creation stays left and layers/details stay right.
 const toolbar=tree.find(node=>node.props?.role==='toolbar'&&node.props['aria-label']==='Interaction tools');assert(toolbar);
 assert.deepEqual(nodes(toolbar).filter(node=>node.props?.role==='group').map(node=>node.props['aria-label']),['Interaction tools','Map navigation','Drawing history']);
 const rail=tree.find(node=>node.props?.className==='drawing-tool-rail');
 const common=tree.find(node=>node.props?.className==='map-common-toolbar');assert(common);
 const sharedLabels=['Select and move','Pan','Tool options','Zoom out','Zoom in','Fit map','Undo','Redo'];
 assert.deepEqual(nodes(common).filter(node=>node.type==='button').map(node=>node.props['aria-label']),sharedLabels);
 assert(!nodes(rail).some(node=>sharedLabels.includes(node.props?.['aria-label'])));assert(nodes(rail).some(node=>node.props?.['aria-label']==='Appearance'));const appearance=nodes(rail).find(node=>node.type==='button'&&node.props?.['aria-label']==='Appearance');assert(appearance.props.className.includes('map-tool-rail-button'));assert(nodes(appearance).some(node=>node.type==='span'&&node.props.children==='Appearance'),'Appearance has a visible label like other rail categories');
 const inspector=tree.find(node=>node.type?.name==='DrawingSelectionInspector'&&node.props.variant!=='layers');assert(!inspector.props.open);
 const layersPane=tree.find(node=>node.type?.name==='DrawingSelectionInspector'&&node.props.variant==='layers');assert(layersPane.props.open);assert(!layersPane.props.onClose);assert(nodes(layersPane).some(node=>node.type?.name==='DrawingLayersPanel'));
 assert.deepEqual(nodes(tree.find(node=>node.props?.className==='drawing-quickbar drawing-view-group')).filter(node=>node.type==='button').map(node=>node.props['aria-label']),['Zoom out','Zoom in','Fit map']);

 tree.find(node=>node.props?.className==='drawing-scroll').props.ref.current=viewport;
 effects.find(effect=>String(effect).includes('new ResizeObserver'))();render();
 assert(paper().width<=viewport.clientWidth&&paper().height<=viewport.clientHeight);
 const originalCamera={...paper()},screenX=rect.left+paper().left,screenY=rect.top+paper().top;
 button('Tool options').props.onClick();rect={...rect,left:48};viewport.clientWidth=1252;resize();render();
 assert.equal(rect.left+paper().left,screenX);assert.equal(rect.top+paper().top,screenY);assert.equal(paper().width,originalCamera.width);
 // All categories stay reachable while an element is inspected.
 button('Select and move').props.onClick();render();
 let screen=surface.getBoundingClientRect(),x=screen.left+drawing.objects[0].x*screen.width,y=screen.top+drawing.objects[0].y*screen.height;
 canvas().props.onPointerDown(event(x,y,'label'));canvas().props.onPointerUp(event(x,y,'label'));render();
 const propertiesPane=()=>tree.find(node=>node.type?.name==='DrawingSelectionInspector'&&node.props.variant!=='layers');
 const persistentLayers=()=>tree.find(node=>node.type?.name==='DrawingSelectionInspector'&&node.props.variant==='layers');
 assert(propertiesPane().props.open);assert(persistentLayers().props.open);propertiesPane().props.onClose();render();assert(!propertiesPane().props.open);assert(persistentLayers().props.open);
 nodes(persistentLayers()).find(node=>node.type?.name==='DrawingLayersPanel').props.onSelectObject('label');render();assert(propertiesPane().props.open,'Selecting from Layers reopens the independent properties pane');
 assert(field('drawing-selected-text'));assert(button('Terrain')&&button('Symbols')&&button('Labels'));
 assert(!tree.some(node=>node.type==='button'&&node.props.children?.includes?.('Create elements')));
 field('drawing-object-size-number').props.onChange({target:{valueAsNumber:4}});render();assert.equal(state[0].objects[0].size,.04);
 field('drawing-selected-text').props.onChange({target:{value:'Changed'}});render();assert.equal(state[0].objects[0].text,'Changed');
 // History keys share Windows Ctrl+Y and Mac/iPad Cmd+Shift+Z, retaining field guards.
 const historyKey=(key,flags={},target=surface)=>({key,target,currentTarget:liveDialog,ctrlKey:false,metaKey:false,shiftKey:false,altKey:false,preventDefault(){},...flags});
 const afterEdit=JSON.stringify(state[0]);
 liveDialog.props.onKeyDown(historyKey('z',{ctrlKey:true}));render();
 assert.notEqual(JSON.stringify(state[0]),afterEdit);
 liveDialog.props.onKeyDown(historyKey('y',{ctrlKey:true}));render();
 assert.equal(JSON.stringify(state[0]),afterEdit);
 liveDialog.props.onKeyDown(historyKey('z',{metaKey:true}));render();
 liveDialog.props.onKeyDown(historyKey('Z',{metaKey:true,shiftKey:true}));render();
 assert.equal(JSON.stringify(state[0]),afterEdit);
 for(const flags of [{ctrlKey:true,altKey:true},{ctrlKey:true,isComposing:true},{ctrlKey:true,nativeEvent:{isComposing:true}},{ctrlKey:true,defaultPrevented:true}]){
  liveDialog.props.onKeyDown(historyKey('z',flags));render();assert.equal(JSON.stringify(state[0]),afterEdit);
 }
 for(const target of [new ElementMock('input'),new ElementMock('nested')]){
  liveDialog.props.onKeyDown(historyKey('z',{ctrlKey:true},target));render();assert.equal(JSON.stringify(state[0]),afterEdit);
 }
 button('Undo').props.onClick();render();button('Undo').props.onClick();render();assert.deepEqual(state[0],drawing);
 // Category switching retains values and exposes only the relevant controls.
 button('Lines and shapes').props.onClick();render();field('drawing-line-width-number').props.onChange({target:{valueAsNumber:.7}});render();
 button('Labels').props.onClick();render();field('drawing-label').props.onChange({target:{value:'New label'}});render();
 button('Terrain').props.onClick();render();button('Lines and shapes').props.onClick();render();assert(Math.abs(field('drawing-line-width').props.value-.007)<1e-12);
 const sections=tree.filter(node=>node.type?.name==='DrawingSection');
 assert(sections.find(node=>node.props.title==='Symbols').props.hidden);
 assert(!sections.find(node=>node.props.title==='Lines and shapes').props.hidden);
 button('Labels').props.onClick();render();assert.equal(field('drawing-label').props.value,'New label');
 // Pan and selection must never appear active at the same time.
 button('Select and move').props.onClick();render();
 button('Pan').props.onClick();render();
 assert.equal(button('Pan').props['aria-pressed'],true);
 assert.equal(button('Select and move').props['aria-pressed'],false);
 const cameraBeforeSelection={...paper()};
 button('Select and move').props.onClick();render();
 assert.equal(button('Pan').props['aria-pressed'],false);
 assert.equal(button('Select and move').props['aria-pressed'],true);
 assert.deepEqual(paper(),cameraBeforeSelection,'Returning to selection preserves the camera');
 screen=surface.getBoundingClientRect();x=screen.left+drawing.objects[0].x*screen.width;y=screen.top+drawing.objects[0].y*screen.height;
 canvas().props.onPointerDown(event(x,y,'label'));canvas().props.onPointerUp(event(x,y,'label'));render();
 assert(field('drawing-selected-text'),'Selection works immediately after leaving Pan');
 button('Pan').props.onClick();render();button('Lines and shapes').props.onClick();render();
 assert.equal(button('Pan').props['aria-pressed'],false);
 button('Labels').props.onClick();render();
 // Editing fields, nested confirmations and ordinary buttons keep their own Space/Z behavior.
 const input=new ElementMock('input'),nested=new ElementMock('nested'),ordinaryButton=new ElementMock('button');let prevented=0;
 for(const target of [input,nested,ordinaryButton])liveDialog.props.onKeyDown({key:' ',code:'Space',target,currentTarget:liveDialog,preventDefault(){prevented++;}});
 assert.equal(prevented,0);
 const history=state[1].length,data=JSON.stringify(state[0]),beforePan={...paper()};
 liveDialog.props.onKeyDown({key:' ',code:'Space',target:surface,currentTarget:liveDialog,preventDefault(){}});
 render();canvas().props.onPointerDown(event(100,100));canvas().props.onPointerMove(event(180,140));render();assert.equal(paper().left,beforePan.left+80);
 canvas().props.onPointerCancel(event(180,140));render();assert.equal(paper().left,beforePan.left);
 assert.equal(JSON.stringify(state[0]),data);assert.equal(state[1].length,history);
 liveDialog.props.onKeyUp({code:'Space',target:surface,preventDefault(){}});render();
 // Returning to the original drawing after edits/undo must not request discard.
 button('Close').props.onClick();assert.equal(cancelled,1);
 const settingsData=JSON.stringify(state[0]),settingsCamera={...paper()};
 button('Appearance').props.onClick();render();
 assert.equal(button('Appearance').props['aria-expanded'],true);
 assert.equal(tree.find(node=>node.type?.name==='DrawingOptionsPanel').props.title,'Appearance');
 assert.equal(tree.find(node=>node.props?.id==='drawing-theme').props.value,'medieval');
 button('Appearance').props.onClick();render();
 assert.equal(button('Appearance').props['aria-expanded'],false);
 assert.equal(tree.find(node=>node.type?.name==='DrawingOptionsPanel').props.open,false);
 assert.equal(JSON.stringify(state[0]),settingsData);assert.deepEqual(paper(),settingsCamera);
 button('Appearance').props.onClick();render();
 assert.equal(button('Appearance').props['aria-expanded'],true);
 tree.find(node=>node.props?.id==='drawing-theme').props.onChange('space');render();button('Close').props.onClick();render();
 const confirmation=tree.find(node=>node.type?.name==='ProjectModal');assert(confirmation);assert.equal(confirmation.props.variant,'confirmation');
 const retainedDraft=JSON.stringify(state[0]);const keep=tree.find(node=>node.type==='button'&&node.props.children==='Keep editing');assert.equal(keep.props['data-initial-focus'],undefined);confirmation.props.onClose();render();assert.equal(JSON.stringify(state[0]),retainedDraft);button('Close').props.onClick();render();tree.find(node=>node.type==='button'&&node.props.children==='Keep editing').props.onClick();render();assert.equal(JSON.stringify(state[0]),retainedDraft);
 tree.find(node=>node.props?.className==='primary-button').props.onClick();assert(saved);assert.equal(saved.drawing.width,1600);assert.equal(saved.drawing.height,1000);
 assert.deepEqual(map.drawing,drawing);
 // The same color control starts a transient sampler and resumes without drawing.
 render();const sampleModule=loadLocal('../src/drawingColorSample.ts'),originalSample=sampleModule.sampleDrawingColor;
 let focusRestored=0,samplePoint;
 const trigger={focus(){focusRestored++;}};
 const colorControl=()=>tree.find(node=>node.type?.name==='DrawingColorPicker'&&node.props.id==='drawing-line-color');
 try{
  sampleModule.sampleDrawingColor=async(_drawing,_layers,_source,point)=>{samplePoint=point;return '#123abc';};
  colorControl().props.onPick(colorControl().props.onChange,trigger);render();
  assert(canvas().props.className.includes('is-picking-color'));
  const beforeCancel=cancelled;
  liveDialog.props.onCancel({target:liveDialog,currentTarget:liveDialog,preventDefault(){}});render();
  assert.equal(cancelled,beforeCancel);assert(!canvas().props.className.includes('is-picking-color'));assert.equal(focusRestored,1);
  colorControl().props.onPick(colorControl().props.onChange,trigger);render();
  let stopped=0;const key=key=>({key,target:surface,currentTarget:surface,preventDefault(){},stopPropagation(){stopped++;}});
  canvas().props.onKeyDown(key('ArrowRight'));render();
  const beforeSampling=JSON.stringify(state[0]);
  canvas().props.onKeyDown(key('Enter'));await Promise.resolve();await Promise.resolve();render();
  assert.deepEqual(samplePoint,{x:.51,y:.5});assert.equal(field('drawing-line-color').props.value,'#123abc');
  assert.equal(JSON.stringify(state[0]),beforeSampling,'Sampling a tool color does not paint or change the drawing');
  assert(!canvas().props.className.includes('is-picking-color'));assert.equal(focusRestored,2);assert.equal(stopped,2);
  colorControl().props.onPick(colorControl().props.onChange,trigger);render();
  const bounds=surface.getBoundingClientRect();
  canvas().props.onPointerDown({...event(bounds.left+bounds.width*.25,bounds.top+bounds.height*.75),stopPropagation(){}});
  await Promise.resolve();await Promise.resolve();render();
  assert(Math.abs(samplePoint.x-.25)<1e-9);assert(Math.abs(samplePoint.y-.75)<1e-9);
  assert.equal(JSON.stringify(state[0]),beforeSampling,'Pointer sampling does not start a drawing gesture');
  assert.equal(focusRestored,3);

 }finally{sampleModule.sampleDrawingColor=originalSample;}

 // Management panes never retain the paint gesture from the preceding tool.
 for(const control of ['Appearance']){
  button('Terrain').props.onClick();render();button(control).props.onClick();render();
  const before=JSON.stringify(state[0]);canvas().props.onPointerDown(event(50,50));canvas().props.onPointerMove(event(80,80));canvas().props.onPointerUp(event(80,80));render();
  assert.equal(JSON.stringify(state[0]),before,control+' must not paint');
 }
 // Compact panes are mutually exclusive and hidden controls are inert.
 state=[];refs=[];compact=true;render();button('Labels').props.onClick();render();
 assert.equal(tree.find(node=>node.type?.name==='DrawingOptionsPanel').props.open,true);
 assert.equal(tree.find(node=>node.type?.name==='DrawingSelectionInspector').props.open,false);
 assert(tree.find(node=>node.type?.name==='DrawingSelectionInspector'&&node.props.variant==='layers').props.open,'Layers stay available independently of tool options');
 button('Appearance').props.onClick();render();
 assert.equal(tree.find(node=>node.type?.name==='DrawingOptionsPanel').props.open,true);
 assert.equal(tree.find(node=>node.type?.name==='DrawingSelectionInspector').props.open,false);
 button('Appearance').props.onClick();render();assert.equal(button('Appearance').props['aria-expanded'],false);
 // Narrow workspaces dedicate the area to the canvas until Layers is explicitly requested.
 state=[];refs=[];mobile=true;render();button('Labels').props.onClick();render();
 const labelField=()=>tree.find(node=>node.props?.id==='drawing-label');labelField().props.onChange({target:{value:'Retained label'}});render();
 const layerPane=()=>tree.find(node=>node.type?.name==='DrawingSelectionInspector'&&node.props.variant==='layers');
 assert.equal(layerPane().props.open,false);button('Layers').props.onClick();render();assert(layerPane().props.open);assert.equal(tree.find(node=>node.type?.name==='DrawingOptionsPanel').props.open,false);
 button('Tool options').props.onClick();render();assert.equal(layerPane().props.open,false);assert(tree.find(node=>node.type?.name==='DrawingOptionsPanel').props.open);assert.equal(labelField().props.value,'Retained label');
 // Reusing the options panel must reveal the beginning of the chosen category.
 const panel=loadLocal('../src/DrawingEditorPanels.tsx').DrawingOptionsPanel;
 const scroll={scrollTop:460};React.useRef=()=>({current:scroll});let reveal;
 React.useEffect=effect=>{reveal=effect;};
 panel({open:true,title:'Appearance',onClose(){},children:null});reveal();assert.equal(scroll.scrollTop,0);


}finally{Object.assign(React,oldHooks);for(const [key,value] of Object.entries(globals)){if(value===undefined)delete globalThis[key];else globalThis[key]=value;}}
console.log('Drawing workspace: aspect fit, cursor/resize anchors, persistent categories, independent inspector, numeric sizes, text-safe shortcuts, reversible pan, real discard checks, atomic apply and inert compact panes passed without UI.');
