import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const {placeScene}=loadLocal('../src/manuscript.ts');
const {setLanguage}=loadLocal('../src/i18n.ts');
const Board=loadLocal('../src/SceneBoard.tsx').default;
const scene=(id)=>({id,title:id,content:'**Dos** palabras',synopsis:'Synopsis',reviewComments:[{id:'comment'+id,from:1,to:4,quote:'Dos',text:'Check',resolved:false}],entryIds:['entry'],ignoredMentions:[],resolvedMentions:[]});
const a=scene('a'),b={...scene('b'),content:'',synopsis:'',reviewComments:[],writingStatus:'notStarted'},c={...scene('c'),writingStatus:'finished',reviewComments:[]};
const project={id:'p',schemaVersion:1,revision:4,title:'Novel',chapters:[{id:'one',title:'First',scenes:[a,b,c]},{id:'two',title:'Empty',scenes:[]}]};const before=JSON.stringify(project);
assert.deepEqual(placeScene(project,'c','one','a').chapters[0].scenes.map(s=>s.id),['c','a','b']);
assert.deepEqual(placeScene(project,'a','one').chapters[0].scenes.map(s=>s.id),['b','c','a']);
const transfer=placeScene(project,'a','two');assert.deepEqual(transfer.chapters.map(c=>c.scenes.map(s=>s.id)),[['b','c'],['a']]);assert.equal(transfer.chapters[1].scenes[0],a);assert.equal(transfer.revision,4);
for(const args of [['a','one','a'],['a','missing',''],['missing','two',''],['a','one','missing'],['a','one','b']])assert.equal(placeScene(project,...args),project);
assert.equal(JSON.stringify(project),before);
const require=createRequire(import.meta.url),React=require('react'),saved={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect,useMemo:React.useMemo},oldDocument=globalThis.document;
let hooks=['all','',null,''],index=0,refIndex=0,changes=[],opened=[],added=[];
const refs=[{current:{contains:()=>true,getBoundingClientRect:()=>({left:0,right:800,top:0,bottom:600}),scrollLeft:0,scrollTop:0}},{current:null}];
function nodes(n){if(Array.isArray(n))return n.flatMap(nodes);if(!n||typeof n!=='object')return [];return[n,...nodes(n.props?.children)];}
const props={project,onChange:p=>changes.push(p),onOpenScene:id=>opened.push(id),onAddScene:id=>added.push(id),onAddChapter(){}};
function render(){index=0;refIndex=0;return nodes(Board(props));}
try{
 React.useState=()=>{const i=index++;return[hooks[i],v=>{hooks[i]=typeof v==='function'?v(hooks[i]):v;}];};React.useRef=()=>refs[refIndex++];React.useEffect=()=>{};React.useMemo=fn=>fn();
 let all=render();all.find(n=>n.props?.className==='scene-board-open').props.onClick();assert.deepEqual(opened,['a']);all.filter(n=>n.props?.className==='scene-board-add')[1].props.onClick();assert.deepEqual(added,['two']);
 all.find(n=>n.props?.id==='board-move-a').props.onChange('two');assert.equal(changes.at(-1).chapters[1].scenes[0],a);
 const filter=()=>render().find(n=>n.props?.id==='board-filter');filter().props.onChange('unfinished');assert.equal(render().filter(n=>n.type==='article').length,2);filter().props.onChange('review');assert.equal(render().filter(n=>n.type==='article').length,1);filter().props.onChange('undeveloped');assert.equal(render().filter(n=>n.type==='article').length,1);filter().props.onChange('all');
 // Exercise actual pointer handlers; no native HTML drag/drop or file attachment is involved.
 let captured=false;const handle={setPointerCapture(){captured=true;},hasPointerCapture(){return captured;},releasePointerCapture(){captured=false;}};
 let hit={dataset:{boardChapter:'two',boardBefore:''}};globalThis.document={elementFromPoint:()=>({closest:()=>hit})};
 const event={button:0,isPrimary:true,pointerId:7,clientX:100,clientY:100,currentTarget:handle,preventDefault(){}};
 const grip=()=>render().find(n=>n.props?.className==='scene-board-grip');
 changes=[];grip().props.onPointerDown(event);grip().props.onPointerMove({...event,clientX:103});grip().props.onPointerUp({...event,clientX:103});assert.equal(changes.length,0);
 grip().props.onPointerDown(event);grip().props.onPointerMove({...event,clientX:200});assert.equal(hooks[1],'a');grip().props.onPointerUp({...event,clientX:200});assert.equal(captured,false);assert.equal(changes.length,1);assert.equal(changes[0].chapters[1].scenes[0],a);
 hit={dataset:{boardChapter:'one',boardBefore:'c'}};grip().props.onPointerDown(event);grip().props.onPointerMove({...event,clientX:200});grip().props.onPointerUp({...event,clientX:200});assert.deepEqual(changes.at(-1).chapters[0].scenes.map(s=>s.id),['b','a','c']);
 const count=changes.length;grip().props.onPointerDown(event);grip().props.onPointerMove({...event,clientX:200});grip().props.onPointerCancel();assert.equal(changes.length,count);assert.equal(hooks[1],'');
}finally{Object.assign(React,saved);globalThis.document=oldDocument;}
setLanguage('es');const html=renderToStaticMarkup(createElement(Board,props));for(const text of ['Tablero de escenas','2 palabras','1 comentario pendiente','Sin sinopsis','Final del capítulo'])assert.ok(html.includes(text),text);assert.ok(!html.includes('draggable="true"'));setLanguage('en');assert.equal(JSON.stringify(project),before);
console.log('Scene board: stable-ID placement and transfers, metadata preservation, filters, card navigation, chapter creation, actual pointer thresholds/drops/cancellation, keyboard alternatives and Spanish summaries passed.');
