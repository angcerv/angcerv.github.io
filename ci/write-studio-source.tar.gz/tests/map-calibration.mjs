import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const C=loadLocal('../src/mapCalibration.ts'),{scaledDistance}=loadLocal('../src/maps.ts');
const original={from:{x:.25,y:.5},to:{x:.75,y:.5},aspectRatio:2,distanceKm:100,travelKmPerDay:30};
assert.deepEqual(C.initialCalibration(original,4),{from:original.from,to:original.to,aspectRatio:2});assert.notEqual(C.initialCalibration(original).from,original.from);
assert(C.validCalibration(C.initialCalibration(undefined,2)));assert(!C.validCalibration({...original,to:original.from}));assert(!C.validCalibration({...original,aspectRatio:NaN}));assert(!C.validCalibration({...original,from:{x:-.1,y:0}}));
const short=C.moveCalibrationEnd(original,'to',{x:.5,y:.5});assert.equal(scaledDistance({...short,distanceKm:100,travelKmPerDay:30},{x:0,y:0},{x:1,y:0}),400);assert.equal(original.to.x,.75);assert.deepEqual(C.moveCalibrationEnd(original,'to',{x:2,y:-1}).to,{x:1,y:0});
const React=createRequire(import.meta.url)('react'),old={useRef:React.useRef,useEffect:React.useEffect},Overlay=loadLocal('../src/MapCalibrationOverlay.tsx').default;
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
let refs=[],ri=0,effects=[],reference=C.initialCalibration(original),busy=false,traced=0,captured=false;
const target={focus(){},setPointerCapture(){captured=true;},hasPointerCapture(){return captured;},releasePointerCapture(){captured=false;}};
const event=(x,y)=>({button:0,isPrimary:true,pointerId:1,clientX:x,clientY:y,currentTarget:target,preventDefault(){},stopPropagation(){}});
const props={image:{current:{getBoundingClientRect:()=>({left:100,top:50,width:400,height:200})}},screenWidth:400,screenHeight:200,onChange:value=>reference=value,onTraceEnd:()=>traced++,onInteractionChange:value=>busy=value};
try{
 React.useRef=initial=>refs[ri++]??(refs[ri-1]={current:initial});React.useEffect=effect=>effects.push(effect);
 const render=(extra={})=>{ri=0;effects=[];return nodes(Overlay({...props,reference,...extra}));};
 let tree=render();const end=()=>tree.find(n=>n.props?.['aria-label']==='Reference line end');const root=()=>tree[0];
 end().props.onPointerDown(event(400,150));assert(busy);root().props.onPointerMove(event(300,200));assert.deepEqual(reference.to,{x:.5,y:.75});root().props.onPointerCancel(event(300,200));assert.deepEqual(reference.to,original.to);assert(!busy&&!captured);
 tree=render();end().props.onPointerDown(event(400,150));root().props.onPointerMove(event(300,150));root().props.onPointerUp(event(280,150));assert.deepEqual(reference.to,{x:.45,y:.5});assert(!busy);
 tree=render();end().props.onKeyDown({...event(0,0),key:'ArrowRight',shiftKey:false});assert.equal(reference.to.x,.455);
 tree=render();const before=structuredClone(reference);end().props.onPointerDown(event(280,150));root().props.onPointerMove(event(350,150));root().props.onKeyDown({...event(0,0),key:'Escape'});assert.deepEqual(reference,before);
 tree=render({drawing:true});root().props.onPointerDown(event(140,90));root().props.onPointerMove(event(400,190));root().props.onPointerUp(event(420,210));assert.deepEqual(reference.from,{x:.1,y:.2});assert.deepEqual(reference.to,{x:.8,y:.8});assert.equal(traced,1);
 tree=render();end().props.onPointerDown(event(420,210));root().props.onPointerMove(event(300,100));tree=render({screenWidth:800});effects[0]();assert.deepEqual(reference.to,{x:.8,y:.8});assert(!busy);
 tree=render({drawing:true});root().props.onPointerDown(event(180,110));root().props.onPointerUp(event(380,190));assert.deepEqual(reference.from,{x:.2,y:.3});assert.deepEqual(reference.to,{x:.7,y:.7});
 tree=render({onChange:undefined});assert(!tree.some(node=>node.type==='ellipse'),'Read-only reference has no handles or focus targets');
}finally{Object.assign(React,old);}
// Modal camera state must never overwrite the main workspace camera.
const N=loadLocal('../src/workspaceNavigation.ts'),{useWorkspaceState}=loadLocal('../src/useWorkspaceState.ts'),oldState=React.useState;
const memory={values:{camera:{zoom:4,x:5,y:6}}};N.activateWorkspaceMemory(memory);
try{React.useState=initial=>[typeof initial==='function'?initial():initial,()=>{}];const [camera]=useWorkspaceState('camera',{zoom:1,x:0,y:0},false);assert.equal(camera.zoom,1);assert.equal(memory.values.camera.zoom,4);assert.deepEqual(Object.keys(memory.values),['camera']);}finally{React.useState=oldState;N.activateWorkspaceMemory(undefined);}
console.log('Reference calibration: legacy compatibility, bounded independent endpoints, real drag/trace/keyboard/cancel/resize handlers, read-only overlay and isolated modal camera passed without UI.');
