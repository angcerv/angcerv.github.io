import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const require=createRequire(import.meta.url),React=require('react');
const Fields=loadLocal('../src/TemplateFields.tsx').default;
const world={schemaVersion:7,templates:[{id:'template',title:'Test',sections:[{id:'other',title:'Other'}],fields:['a','b','c'].map(id=>({id,label:id,fieldType:'shortText'}))}],entries:[]};
const saved={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
let refs=[],changed,hit;
React.useEffect=()=>{};
React.useState=value=>[value,()=>{}];React.useRef=value=>{const ref={current:value};refs.push(ref);return ref;};
let tree;
try{tree=Fields({world,template:world.templates[0],onChange:value=>{changed=value;}});}finally{Object.assign(React,saved);}
function nodes(node){if(Array.isArray(node))return node.flatMap(nodes);if(!node||typeof node!=='object')return [];return [node,...nodes(node.props?.children)];}
const all=nodes(tree),list=all.find(node=>node.props?.className==='world-template-fields');
list.props.ref.current={contains:()=>true};
const handle=id=>all.find(node=>node.props?.['data-field-id']===id).props.children[0].props.children[0];
const group={dataset:{fieldGroup:''},scrollHeight:0,clientHeight:0,parentElement:null};
function target(id,section=''){
 group.dataset.fieldGroup=section;
 const row=id?{dataset:{fieldId:id},getBoundingClientRect:()=>({top:100,height:40})}:null;
 hit={closest:selector=>selector==='[data-field-group]'?group:row};
}
globalThis.document={elementFromPoint:()=>hit,getElementById:()=>null};globalThis.requestAnimationFrame=fn=>fn();
let captured=false;
const control={focus(){},setPointerCapture(){captured=true;},hasPointerCapture:()=>captured,releasePointerCapture(){captured=false;}};
const event=y=>({pointerId:1,button:0,isPrimary:true,clientX:20,clientY:y,currentTarget:control,preventDefault(){}});
function drag(id,destination,y,section=''){
 changed=undefined;const button=handle(id);button.props.onPointerDown(event(10));target(destination,section);button.props.onPointerMove(event(y));button.props.onPointerUp(event(y));assert.equal(captured,false);return changed;
}
assert.equal(handle('a').props.draggable,false);
assert.deepEqual(drag('a','b',135).templates[0].fields.map(field=>field.id),['b','a','c']);
assert.deepEqual(drag('c','a',105).templates[0].fields.map(field=>field.id),['c','a','b']);
assert.deepEqual(drag('a','c',135).templates[0].fields.map(field=>field.id),['b','c','a']);
assert.equal(drag('a',null,135,'other').templates[0].fields.find(field=>field.id==='a').sectionId,'other');
assert.equal(drag('a','a',135),undefined);
changed=undefined;handle('a').props.onPointerDown(event(10));target('c');handle('a').props.onPointerMove(event(135));handle('a').props.onPointerCancel();handle('a').props.onPointerUp(event(135));assert.equal(changed,undefined);
changed=undefined;handle('a').props.onPointerDown(event(10));handle('a').props.onPointerUp(event(12));assert.equal(changed,undefined);
console.log('Field pointer reorder: native drag disabled, upward/downward/end/section drops, cancellation and click threshold passed.');
