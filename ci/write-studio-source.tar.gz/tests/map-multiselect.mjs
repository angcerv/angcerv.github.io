import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const {moveDrawingObjects,drawingObjectsInRect}=loadLocal('../src/mapDrawing.ts');
const Editor=loadLocal('../src/MapDrawingEditor.tsx').default;
const objects=[{id:'a',kind:'castle',x:.2,y:.2,size:.1,rotation:30},{id:'b',kind:'spaceship',x:.5,y:.5,size:.1},{id:'line',kind:'line',x:.1,y:.7,endX:.4,endY:.8,size:.06},{id:'locked',kind:'planet',x:.3,y:.3,size:.1,layerId:'locked'},{id:'hidden',kind:'planet',x:.4,y:.4,size:.1,layerId:'hidden'}];
const map={id:'map',title:'Map',imageId:'image',markers:[],layers:[{id:'locked',title:'Locked',visible:true,locked:true},{id:'hidden',title:'Hidden',visible:false}],drawing:{width:1000,height:1000,strokes:[],objects}};
const bounded=moveDrawingObjects(objects,['a','line'],{x:1,y:1});assert.equal(bounded[2].endY,1);assert(Math.abs((bounded[0].y-bounded[2].y)-(.2-.7))<1e-9);assert.equal(bounded[3],objects[3]);assert.equal(bounded[0].rotation,30);
assert.deepEqual(drawingObjectsInRect(map.drawing,{x:.6,y:.6},{x:.1,y:.1},map.layers),['a','b']);
const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
let states=[],refs=[],si=0,ri=0,saved;
function nodes(n){if(n&&typeof n.type==='function'&&n.type.name==='DrawingToolRail')return nodes(n.type(n.props));return Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];}
const surface={getBoundingClientRect:()=>({left:0,top:0,width:1000,height:1000}),focus(){},setPointerCapture(){},hasPointerCapture:()=>true,releasePointerCapture(){}};
const event=(x,y,id='',shiftKey=false)=>({clientX:x,clientY:y,pointerId:1,button:0,isPrimary:true,shiftKey,currentTarget:surface,target:{getAttribute:()=>null,closest:()=>id?{getAttribute:()=>id}:null},preventDefault(){}});
try{
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 function render(){si=0;ri=0;return nodes(Editor({map,path:'/book',projectId:'p',onCancel(){},onSave:value=>saved=value}));}
 render();states[3]='image';states[4]=true;refs[1].current=surface;
 const canvas=()=>render().find(n=>n.props?.['aria-label']==='Map drawing canvas');
 const button=text=>render().find(n=>n.type==='button'&&(n.props?.['aria-label']===text||n.props.children?.some?.(child=>child===text)));
 button('Select and move').props.onClick();
 const click=(id,shift=false)=>{const o=states[0].objects.find(o=>o.id===id);canvas().props.onPointerDown(event(o.x*1000,o.y*1000,id,shift));canvas().props.onPointerUp(event(o.x*1000,o.y*1000,id,shift));};
 const group=()=>render().find(n=>n.props?.title==='2 elements selected');
 click('a');click('b',true);assert(group());assert(!render().some(n=>n.props?.['data-resize-handle']));
 const selectionHistory=states[1].length;click('a');assert(group());assert.equal(states[1].length,selectionHistory,'Clicking an existing group does not create an edit');
 click('locked',true);assert(group(),'Locked objects cannot enter the selection');click('hidden',true);assert(group());
 canvas().props.onPointerDown(event(200,200,'a'));canvas().props.onPointerMove(event(300,250,'a'));canvas().props.onPointerUp(event(300,250,'a'));
 assert(Math.abs(states[0].objects[0].x-.3)<1e-9);assert(Math.abs(states[0].objects[1].x-.6)<1e-9);assert(Math.abs(states[0].objects[1].y-states[0].objects[0].y-.3)<1e-9);assert.equal(states[0].objects[3],objects[3]);
 button('Undo').props.onClick();assert.equal(states[0].objects[0].x,.2);assert.equal(states[0].objects[1].x,.5);button('Redo').props.onClick();assert(Math.abs(states[0].objects[0].x-.3)<1e-9);button('Undo').props.onClick();
 // Reverse-direction marquee selects editable objects and does not change history.
 const history=states[1].length;
 canvas().props.onPointerDown(event(600,600));canvas().props.onPointerMove(event(100,100));assert(render().some(n=>n.props?.className==='drawing-marquee'));canvas().props.onPointerUp(event(100,100));assert(group());assert.equal(states[1].length,history);
 click('b',true);assert(!group());assert(render().some(n=>n.props?.id==='drawing-object-rotation'),'Removing one element restores individual properties');
 // Add to a selection using Shift + marquee.
 canvas().props.onPointerDown(event(440,440,'',true));canvas().props.onPointerUp(event(560,560,'',true));assert(group());
 const before=states[0];canvas().props.onPointerDown(event(200,200,'a'));canvas().props.onPointerMove(event(900,900,'a'));canvas().props.onPointerCancel(event(900,900,'a'));assert.equal(states[0],before);assert(group());
 // Cancelling a replacement marquee restores the previous selection.
 canvas().props.onPointerDown(event(800,100));canvas().props.onPointerMove(event(900,200));canvas().props.onPointerCancel(event(900,200));assert(group());
 // Pointer-up alone applies the final group delta, with one shared boundary clamp.
 canvas().props.onPointerDown(event(200,200,'a'));canvas().props.onPointerUp(event(1000,1000,'a'));assert.equal(states[0].objects[1].x,1);assert(Math.abs(states[0].objects[1].x-states[0].objects[0].x-.3)<1e-9);
 const drawing=states[0];canvas().props.onPointerDown(event(10,10));canvas().props.onPointerUp(event(10,10));assert(!group());assert.equal(states[0],drawing);
 render().find(n=>n.props?.className==='primary-button').props.onClick();assert.equal(saved,drawing);assert.deepEqual(map.drawing.objects,objects,'Original map stays unchanged until Apply');
}finally{Object.assign(React,old);}
console.log('Map multi-selection: Shift toggles, forward/reverse/additive marquee, locked/hidden exclusions, group translation, shared bounds, undo/redo, cancellation, final pointer position and atomic Apply passed.');
