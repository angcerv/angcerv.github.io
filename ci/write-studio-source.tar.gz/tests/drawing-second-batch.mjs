import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
import {spawnSync} from 'node:child_process';
const {beginSymbolPlacement,extendSymbolPlacement}=loadLocal('../src/symbolPlacement.ts');
const {drawingSvg}=loadLocal('../src/mapDrawing.ts');
const {recentMaterialPresets,recentSymbolPresets}=loadLocal('../src/drawingToolPresets.ts');
const {updateMap}=loadLocal('../src/maps.ts'),{expandMapCanvas}=loadLocal('../src/mapCanvasExpansion.ts');
const brush={kind:'forest',size:.05,rotation:30,density:.8,sizeVariation:.3,rotationVariation:60};
function gesture(parts,capacity=500,settings=brush){let id=0;const g=beginSymbolPlacement(settings,{x:.1,y:.3},1600,1000,capacity,42,()=>`symbol-${id++}`);for(let i=1;i<=parts;i++)extendSymbolPlacement(g,{x:.1+.8*i/parts,y:.3});return g;}
const long=gesture(1),short=gesture(80);assert.equal(long.objects.length,short.objects.length);long.objects.forEach((o,i)=>{assert(Math.abs(o.x-short.objects[i].x)<1e-10);assert.equal(o.size,short.objects[i].size);assert.equal(o.rotation,short.objects[i].rotation);assert.equal(o.id,short.objects[i].id);assert(o.rotation>=0&&o.rotation<360);assert(o.size>0&&o.size<=.25);});
assert(gesture(1,500,{...brush,density:1}).objects.length>gesture(1,500,{...brush,density:.1}).objects.length);
const bounded=gesture(1,3);assert.equal(bounded.objects.length,3);assert(bounded.truncated);assert.equal(gesture(1,0).objects.length,0);
const plain=gesture(1,500,{...brush,sizeVariation:0,rotationVariation:0});assert(plain.objects.every(o=>o.size===.05&&o.rotation===30));
const stable=beginSymbolPlacement(brush,{x:.1,y:.3},1600,1000,500,42,()=> 'stable');const first=JSON.stringify(stable.objects[0]);extendSymbolPlacement(stable,{x:.5,y:.3});assert.equal(JSON.stringify(stable.objects[0]),first);
const recipes=recentSymbolPresets(long.objects,['forest']);assert.equal(recipes.length,1);assert.equal(recentSymbolPresets([{...long.objects[0],stamp:undefined,size:.12},...long.objects],['forest']).length,1,'Recent symbols keep only their newest recipe');assert.equal(recipes[0].size,.05);assert.equal(recipes[0].rotation,30);assert.deepEqual(recipes[0].placement,{continuous:true,density:.8,sizeVariation:.3,rotationVariation:60});assert.equal(recentSymbolPresets(long.objects,['castle']).length,0);
const stroke={kind:'land',material:'grass',width:.08,color:'#819565',points:[{x:.2,y:.2},{x:.6,y:.4}]},base={width:1600,height:1000,strokes:[stroke],objects:[]};
assert.equal(drawingSvg(base),drawingSvg({...base,strokes:[{...stroke,textureScale:1,textureRotation:0}]}));
const transformed={...stroke,textureScale:1.5,textureRotation:45},svg=drawingSvg({...base,strokes:[stroke,transformed]});assert(svg.includes('rotate(45)'));assert.equal((svg.match(/data-terrain-material="grass"/g)??[]).length,2);assert.equal((drawingSvg({...base,strokes:[transformed,{...transformed}]}).match(/data-terrain-material="grass"/g)??[]).length,1);
const ids=[...svg.matchAll(/\bid="([^"]+)"/g)].map(m=>m[1]);assert.equal(ids.length,new Set(ids).size);for(const match of svg.matchAll(/(?:url\(#|href="#)([^)" ]+)/g))assert(ids.includes(match[1]),match[1]);
const xml=spawnSync('python3',['-c','import sys,xml.etree.ElementTree as E; E.fromstring(sys.stdin.read())'],{input:svg,encoding:'utf8'});assert.equal(xml.status,0,xml.stderr);
assert.equal(recentMaterialPresets([stroke,transformed],['grass']).length,2);assert.equal(recentMaterialPresets([transformed],['grass'])[0].textureRotation,45);
const map={id:'m',imageId:'i',markers:[],drawing:{...base,strokes:[transformed],objects:long.objects}};assert.equal(updateMap({schemaVersion:25,maps:[map]},map).schemaVersion,26);assert.equal(updateMap({schemaVersion:26,maps:[map]},map).schemaVersion,26);
const expanded=expandMapCanvas(map,{left:100,right:100,top:0,bottom:0});assert.equal(expanded.drawing.strokes[0].textureScale,1.5);assert.equal(expanded.drawing.strokes[0].textureRotation,45);assert.equal(expanded.drawing.objects[0].stamp.baseSize,.05*1600/1800);assert.equal(map.drawing.objects[0].stamp.baseSize,.05);
console.log('Second drawing batch: texture transforms, SVG references, legacy rendering, arc-length symbol placement, deterministic variation, capacity, immutable previews, recent recipes and schema/expansion retention passed without UI.');

const source={id:"label",kind:"label",size:.04,x:.2,y:.2};
const React=createRequire(import.meta.url)('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect},Editor=loadLocal('../src/MapDrawingEditor.tsx').default;
let state=[],refs=[],si=0,ri=0;
const objects=[{...source,layerId:undefined},{id:'symbol',kind:'castle',color:'#cc8844',rotation:45,size:.08,x:.6,y:.6},{id:'ellipse',kind:'ellipse',color:'#2468ab',fill:'#ffcc99',lineWidth:.007,size:.065,x:.4,y:.4,endX:.6,endY:.6},{id:'path',kind:'path',color:'#222222',lineWidth:.004,smooth:true,dashed:true,size:.065,x:.2,y:.2,points:[{x:.2,y:.2},{x:.5,y:.7}]}];
const projectMap={id:'m',title:'Map',imageId:'i',markers:[],drawing:{...base,strokes:[stroke],objects}},surface={getBoundingClientRect:()=>({left:0,top:0,width:800,height:500}),focus(){},setPointerCapture(){},hasPointerCapture:()=>true,releasePointerCapture(){}};
const nodes=n=>{if(n&&typeof n.type==='function'&&n.type.name==='DrawingToolRail')return nodes(n.type(n.props));return Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];};
const event=(x,y)=>({clientX:x,clientY:y,pointerId:1,button:0,isPrimary:true,currentTarget:surface,target:{closest:()=>null},preventDefault(){},stopPropagation(){}});
try{
 React.useState=initial=>{const i=si++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return[state[i],value=>state[i]=typeof value==='function'?value(state[i]):value];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 const render=()=>{si=ri=0;return nodes(Editor({map:projectMap,path:'/project',projectId:'p',onCancel(){},onSave(){}}));};
 const field=id=>render().find(n=>n.props?.id===id),canvas=()=>render().find(n=>n.props?.['aria-label']==='Map drawing canvas'),button=label=>render().find(n=>n.type==='button'&&(n.props['aria-label']===label||n.props.children?.includes?.(label)));
 render();state[3]='image';state[4]=true;refs[1].current=surface;
 const select=id=>render().find(n=>n.type?.name==='DrawingLayersPanel').props.onSelectObject(id);

 button('Symbols').props.onClick();button('forest').props.onClick();
 field('drawing-symbol-continuous').props.onChange({target:{checked:true}});
 field('drawing-symbol-density').props.onChange({target:{value:'.8'}});
 field('drawing-symbol-size-variation').props.onChange({target:{value:'.3'}});
 field('drawing-symbol-rotation-variation').props.onChange({target:{value:'60'}});
 const original=JSON.stringify(state[0]),count=state[0].objects.length,past=state[1].length;
 canvas().props.onPointerDown(event(100,100));assert.equal(state[1].length,past);
 canvas().props.onPointerMove(event(300,100));canvas().props.onPointerUp(event(600,100));
 assert(state[0].objects.length>count+1);assert.equal(state[1].length,past+1);assert(state[0].objects.slice(count).every(o=>o.stamp.continuous&&o.stamp.density===.8));
 assert(!button('forest'),'A recent symbol is absent from the catalogue');assert(button('Reuse forest symbol settings'));
 const committed=JSON.stringify(state[0]);button('Undo').props.onClick();assert.equal(JSON.stringify(state[0]),original);button('Redo').props.onClick();assert.equal(JSON.stringify(state[0]),committed);
 canvas().props.onPointerDown(event(100,100));canvas().props.onPointerMove(event(400,100));canvas().props.onPointerCancel(event(400,100));assert.equal(JSON.stringify(state[0]),committed);
 field('drawing-symbol-density').props.onChange({target:{value:'.1'}});button('Reuse forest symbol settings').props.onClick();assert.equal(field('drawing-symbol-density').props.value,.8);
}finally{Object.assign(React,old);}
console.log('Continuous symbol editor gestures commit once, cancel completely, undo/redo atomically and restore recent settings without UI.');
