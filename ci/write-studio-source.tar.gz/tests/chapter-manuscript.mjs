import assert from 'node:assert/strict';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const {patchScene}=loadLocal('../src/manuscript.ts');
const Chapter=loadLocal('../src/ChapterManuscript.tsx').default;
const Actions=loadLocal('../src/ManuscriptActions.tsx').default;
const {setLanguage}=loadLocal('../src/i18n.ts');
const project={schemaVersion:1,id:'project',title:'Novel',revision:0,chapters:[{id:'chapter',title:'Opening',synopsis:'Keep chapter outline',scenes:[{id:'a',title:'Arrival',content:'**First** scene',entryIds:['entry'],ignoredMentions:[{from:1,to:6,text:'First'}]},{id:'b',title:'Departure',content:'_Second_ scene',resolvedMentions:[{from:1,to:7,text:'Second',entryId:'entry'}]}]},{id:'other',title:'Later',scenes:[{id:'c',title:'Other',content:'Untouched'}]}]};
const original=JSON.stringify(project);
// Updates from independent editors are merged into the latest project by scene ID.
let latest=patchScene(project,'b',{content:'Rewritten second scene'});latest=patchScene(latest,'a',{content:'Rewritten first scene'});
assert.equal(latest.chapters[0].scenes[0].content,'Rewritten first scene');assert.equal(latest.chapters[0].scenes[1].content,'Rewritten second scene');
assert.deepEqual(latest.chapters[0].scenes[0].entryIds,['entry']);assert.deepEqual(latest.chapters[0].scenes[1].resolvedMentions,project.chapters[0].scenes[1].resolvedMentions);
assert.equal(latest.chapters[1],project.chapters[1]);assert.equal(JSON.stringify(project),original);assert.equal(patchScene(project,'missing',{content:'x'}),project);
const html=renderToStaticMarkup(createElement(Chapter,{chapter:project.chapters[0],activeSceneId:'b',onActivate:()=>{},onAddScene:()=>{},renderScene:scene=>createElement('div',{'data-editor':scene.id},scene.content)}));
assert.ok(html.includes('Complete chapter text'));assert.ok(html.includes('Opening'));assert.ok(html.indexOf('Arrival')<html.indexOf('Departure'));assert.equal((html.match(/data-editor=/g)??[]).length,2);assert.match(html,/class="chapter-manuscript-scene active"[^>]*data-chapter-scene="b"/);
let active=[],added=0,modes=[];
const tree=Chapter({chapter:project.chapters[0],activeSceneId:'a',onActivate:id=>active.push(id),onAddScene:()=>added++,renderScene:scene=>createElement('div',null,scene.content)});
function nodes(node){if(Array.isArray(node))return node.flatMap(nodes);if(!node||typeof node!=='object')return [];return [node,...nodes(node.props?.children)];}
const all=nodes(tree);all.find(n=>n.props?.['data-chapter-scene']==='b').props.onFocusCapture();all.find(n=>n.props?.className==='chapter-add-scene').props.onClick();assert.deepEqual(active,['b']);assert.equal(added,1);
const actions=Actions({mode:'chapter',onMode:mode=>modes.push(mode),hasChapter:true,hasScene:true,toolsOpen:false,worldOpen:false,toolsTrigger:null,onAddScene:()=>{},onToggleTools:()=>{},onFocus:()=>{},onToggleWorld:()=>{}});
const toggle=nodes(actions).find(n=>n.props?.className==='manuscript-reading-mode');const buttons=nodes(toggle).filter(n=>n.type==='button');assert.equal(buttons[1].props['aria-pressed'],true);buttons[0].props.onClick();assert.deepEqual(modes,['scene']);
const empty=renderToStaticMarkup(createElement(Chapter,{chapter:{id:'empty',title:'Empty',scenes:[]},onActivate:()=>{},onAddScene:()=>{},renderScene:()=>null}));assert.ok(empty.includes('0 scenes'));assert.ok(empty.includes('New scene'));
setLanguage('es');assert.ok(renderToStaticMarkup(createElement(Chapter,{chapter:project.chapters[0],onActivate:()=>{},onAddScene:()=>{},renderScene:()=>null})).includes('Texto del capítulo completo'));setLanguage('en');
console.log('Complete chapter: ordered editable scene slots, active-scene routing, latest-project edits by stable ID, preserved metadata, view toggle and empty/bilingual layouts passed.');

const {visibleChapterScene}=loadLocal('../src/chapterScroll.ts');
assert.equal(visibleChapterScene([{id:'a',top:-200,bottom:180},{id:'b',top:220,bottom:900}],{top:0,height:500,atEnd:false}),'a');
assert.equal(visibleChapterScene([{id:'a',top:-400,bottom:50},{id:'b',top:90,bottom:700}],{top:0,height:500,atEnd:false}),'b');
assert.equal(visibleChapterScene([{id:'a',top:-100,bottom:200},{id:'b',top:240,bottom:320}],{top:0,height:500,atEnd:true}),'b');
assert.equal(visibleChapterScene([],{top:0,height:500,atEnd:false}),undefined);
// Exercise scrolling on the rendered chapter container without changing editor focus.
active=[];
tree.props.onScroll({currentTarget:{clientHeight:500,scrollHeight:1500,scrollTop:400,getBoundingClientRect:()=>({top:0}),querySelectorAll:()=>[{dataset:{chapterScene:'a'},getBoundingClientRect:()=>({top:-400,bottom:50})},{dataset:{chapterScene:'b'},getBoundingClientRect:()=>({top:90,bottom:700})}]}});
assert.deepEqual(active,['b']);
console.log('Chapter scroll: reading-position selection, reverse geometry, last short scene and actual scroll handler passed.');

// View selection must change availability, not toolbar structure or control order.
const toolbarShapes={};
for(const mode of ['scene','chapter','board','planning']){
 const toolbar=Actions({hasChapter:true,hasScene:true,mode,onMode(){},onAddScene(){},onComments(){},onCheckpoints(){},onToggleTools(){},onFocus(){},onToggleWorld(){},toolsOpen:false,worldOpen:false,toolsTrigger:null,commentCount:mode==='scene'?125:0});
 const elements=nodes(toolbar),segments=elements.find(node=>node.props?.className==='manuscript-reading-mode');
 const options=nodes(segments).filter(node=>node.type==='button');assert.equal(options.length,2);const reading=mode==='scene'||mode==='chapter';assert.deepEqual(options.map(node=>node.props['aria-label']),reading?['Scene','Complete chapter']:['Outline','Scene board']);assert.equal(options.filter(node=>node.props['aria-pressed']).length,1);assert.equal(options[(reading?['scene','chapter']:['planning','board']).indexOf(mode)].props['aria-pressed'],true);assert.equal(elements.some(node=>node.type==='button'&&node.props['aria-label']==='Plan this chapter'),reading);
 assert(!nodes(segments).some(node=>typeof node.type==='function'&&node.type.name==='FieldHelp'));
 assert(!elements.some(node=>typeof node.type==='function'&&node.type.name==='FieldHelp'));
 const utilities=nodes(elements.find(node=>node.props?.className==='manuscript-view-actions')).filter(node=>node.type==='button');assert.equal(utilities.length,reading?3:0,'Planning omits manuscript-only actions');assert(utilities.every(node=>!node.props.disabled));
 const review=elements.find(node=>typeof node.type==='function'&&node.type.name==='ActionMenu');assert.equal(review.props.actions.length,reading?2:1);assert.equal(review.props.actions.some(action=>action.label.startsWith('Review comments')),reading);
 const shape=elements.filter(node=>typeof node.type==='string').map(node=>[node.type,node.props.className??'',node.type==='button'?node.props['aria-label']??'':'']);const key=reading?'reading':'planning';if(toolbarShapes[key])assert.deepEqual(shape,toolbarShapes[key]);else toolbarShapes[key]=shape;
}
console.log('Manuscript toolbar: separate reading/planning controls and stable structure within each task, selected semantics, omitted manuscript-only planning actions, stable review menu and no redundant view help passed.');
