import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const E=loadLocal('../src/entryEditorial.ts'),O=loadLocal('../src/entryOrdering.ts'),S=loadLocal('../src/worldSavedAccess.ts');
const world={schemaVersion:11,templates:[],entries:[{schemaVersion:11,id:'e',title:'Name',values:{},archived:false}]};
assert(E.matchesEditorial(world.entries[0],'unclassified'));assert(!E.matchesEditorial(world.entries[0],'defined'));
const next={...world,entries:[{...world.entries[0],editorialStatus:'defined'}]};assert(E.matchesEditorial(next.entries[0],'defined'));assert.equal(O.stampEntryModifications(world,next,undefined,undefined,100).entries[0].modifiedAt,100);assert.equal(world.entries[0].editorialStatus,undefined);
const {sameWorldView}=loadLocal('../src/WorldSavedShortcuts.tsx');
assert(sameWorldView({query:'',templateId:'',archived:false,editorial:'',order:'alphabetical'},{query:'',templateId:'',archived:false,editorial:'',canon:'',order:'alphabetical'}));
assert(!sameWorldView({query:'',templateId:'',archived:false,editorial:'',order:'alphabetical'},{query:'',templateId:'',archived:true,editorial:'',order:'alphabetical'}));
const original=globalThis.localStorage;const memory=new Map();globalThis.localStorage={getItem:key=>memory.get(key)??null,setItem:(key,value)=>memory.set(key,value)};
const view={query:'Árbol',templateId:'t',archived:true,editorial:'inReview',order:'recentlyModified'};
try{
 assert.deepEqual(S.readWorldAccess('one'),{entries:[],views:[]});assert(S.rememberWorldAccess('one',{entries:['e'],views:[{id:'v',name:'Review',view}]}));assert.equal(S.readWorldAccess('two').entries.length,0);assert.deepEqual(S.readWorldAccess('one').views[0].view,view);
 memory.set('write-studio.world-access.bad','{');assert.deepEqual(S.readWorldAccess('bad'),{entries:[],views:[]});memory.set('write-studio.world-access.bad',JSON.stringify({entries:['e','e',3],views:[{},null,{id:'v',name:'No',view:{...view,order:'wrong'}}]}));assert.deepEqual(S.readWorldAccess('bad'),{entries:['e'],views:[]});
 const require=createRequire(import.meta.url),React=require('react'),old={useRef:React.useRef,useState:React.useState},Control=loadLocal('../src/EntryEditorialControl.tsx').default,Shortcuts=loadLocal('../src/WorldSavedShortcuts.tsx').default;let hooks=[],index=0,changed;
 const nodes=n=>n&&typeof n.type==='function'&&['EntryStatuses','EntryStatus'].includes(n.type.name)?nodes(n.type(n.props)):Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
 React.useRef=()=>({current:null});React.useState=initial=>{const i=index++;if(!(i in hooks))hooks[i]=typeof initial==='function'?initial():initial;return[hooks[i],value=>hooks[i]=value];};
 try{
  let tree=nodes(Control({entry:world.entries[0],onChange:value=>changed=value}));tree.find(n=>n.props?.id==='entry-editorial-status'&&n.props.options).props.onChange('inReview');assert.equal(changed.editorialStatus,'inReview');
  let applied;const props={access:{saved:S.readWorldAccess('one'),error:'',save(value){props.access.saved=value;S.rememberWorldAccess('one',value);}},entries:next.entries,entry:next.entries[0],view,onApply:value=>applied=value};hooks=[];const render=()=>{index=0;return nodes(Shortcuts(props));};tree=render();
  const menu=()=>tree.find(n=>n.type?.name==='ActionMenu');
  assert(!tree.some(n=>n.props?.className==='world-pinned-entries'));
  menu().props.actions.find(action=>action.label==='Saved views').onClick();tree=render();
  const savedButton=tree.find(n=>n.type==='button'&&n.props['aria-label']==='Review');assert.equal(savedButton.props['aria-pressed'],true);assert(tree.some(n=>n.type==='small'&&n.props.children.includes('Recently modified')));
  savedButton.props.onClick();assert.deepEqual(applied,view);tree=render();
  menu().props.actions.find(action=>action.label==='Save current view').onClick();tree=render();tree.find(n=>n.props?.id==='world-shortcut-name').props.onChange({target:{value:'Draft'}});tree=render();tree.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.equal(S.readWorldAccess('one').views.length,2);tree=render();
  menu().props.actions.find(action=>action.label==='Saved views').onClick();tree=render();tree.find(n=>n.props?.['aria-label']==='Delete saved view: Draft').props.onClick();assert.equal(S.readWorldAccess('one').views.length,1);
  assert.deepEqual(props.access.saved.entries,['e'],'Managing views preserves favorite IDs');
  const withFavorites={...view,favoritesOnly:true};assert(!sameWorldView(view,withFavorites));S.rememberWorldAccess('favorites',{entries:['e'],views:[{id:'f',name:'Favorites',view:withFavorites}]});assert.equal(S.readWorldAccess('favorites').views[0].view.favoritesOnly,true);
  globalThis.localStorage.setItem=()=>{throw Error('blocked');};assert.equal(S.rememberWorldAccess('one',{entries:[],views:[]}),false);
 }finally{Object.assign(React,old);}
}finally{globalThis.localStorage=original;}
console.log('Editorial and shortcuts: explicit states, immutable stamping, per-project views, corrupt/blocked storage, deleted targets and actual selector/navigation handlers passed.');
