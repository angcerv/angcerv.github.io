import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const O=loadLocal('../src/entryOrdering.ts'),I=loadLocal('../src/i18n.ts'),Editor=loadLocal('../src/WorldbuildingEditor.tsx').default;
const entries=[['z','Zeta',200],['a','Árbol',100],['n','Nota 10',undefined],['m','Nota 2',undefined]].map(([id,title,modifiedAt])=>({schemaVersion:9,id,title,templateId:'t',values:{},archived:false,...(modifiedAt===undefined?{}:{modifiedAt})}));
const world={schemaVersion:9,templates:[{schemaVersion:9,id:'t',title:'Custom',fields:[]}],entries},original=JSON.stringify(world);
assert.deepEqual(O.sortEntries(entries,'alphabetical').map(entry=>entry.id),['a','m','n','z']);assert.deepEqual(O.sortEntries(entries,'reverseAlphabetical').map(entry=>entry.id),['z','n','m','a']);assert.deepEqual(O.sortEntries(entries,'recentlyModified').map(entry=>entry.id),['z','a','m','n']);assert.deepEqual(O.sortEntries(entries,'oldestModified').map(entry=>entry.id),['a','z','m','n']);
assert.equal(O.stampEntryModifications(world,world),world);
const cloned={...world,entries:entries.map(entry=>({...entry,values:{}}))};assert.equal(O.stampEntryModifications(world,cloned),cloned);
const updated={...world,entries:entries.map(entry=>entry.id==='a'?{...entry,title:'Updated',values:{nested:{year:0}}}:entry)};const stamped=O.stampEntryModifications(world,updated,undefined,undefined,1000);assert.equal(stamped.schemaVersion,10);assert.equal(stamped.entries[1].modifiedAt,1000);assert.equal(stamped.entries[0].modifiedAt,200);assert.equal(stamped.entries[2].modifiedAt,undefined);assert(stamped.templates.every(template=>template.schemaVersion===10));assert(stamped.entries.every(entry=>entry.schemaVersion===10));
const created={...world,entries:[...entries,{...entries[0],id:'new'}]};assert.equal(O.stampEntryModifications(world,created,undefined,undefined,1234).entries.at(-1).modifiedAt,1234,'New/duplicated entries get their own timestamp');
const beforeRelations={schemaVersion:2,types:[],links:[]},afterRelations={...beforeRelations,links:[{id:'link',typeId:'type',sourceId:'a',targetId:'z'}]};const linked=O.stampEntryModifications(world,world,beforeRelations,afterRelations,2000);assert.equal(linked.entries[0].modifiedAt,2000);assert.equal(linked.entries[1].modifiedAt,2000);assert.equal(linked.entries[2].modifiedAt,undefined);assert.equal(O.stampEntryModifications(world,world,beforeRelations,{...beforeRelations,views:[]}),world,'View-only changes do not modify entries');assert.equal(O.stampEntryModifications(world,world,afterRelations,{...afterRelations,links:structuredClone(afterRelations.links)}),world,'Equivalent links do not modify entries');
const removed=O.stampEntryModifications(linked,linked,afterRelations,beforeRelations,3000);assert.equal(removed.entries[0].modifiedAt,3000);assert.equal(JSON.stringify(world),original);
const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect},previousStorage=globalThis.localStorage;let state=[],index=0,preference='',mutations=0;
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
try{
 globalThis.localStorage={getItem:()=>preference,setItem:(_,value)=>preference=value};React.useState=initial=>{const i=index++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return[state[i],value=>state[i]=typeof value==='function'?value(state[i]):value];};React.useRef=value=>({current:value});React.useEffect=()=>{};
 const props={world,entryId:'a',tab:'entries',setEntryId(id){props.entryId=id;},setTab(tab){props.tab=tab;},onReturn(){},onChange(){mutations++;}};const render=()=>{index=0;return nodes(Editor(props));};let tree=render();const list=()=>render().find(n=>n.props?.className==='world-entry-list').props.children[0].map(n=>n.key);assert.deepEqual(list(),['a','m','n','z']);tree.find(n=>n.type?.name==='ActionMenu'&&n.props.label.startsWith('Sort entries:')).props.actions.find(action=>action.label==='Recently modified').onClick();assert.deepEqual(list(),['z','a','m','n']);assert.equal(preference,'recentlyModified');assert.equal(mutations,0);assert.equal(O.readEntryOrder(),'recentlyModified');preference='invalid';assert.equal(O.readEntryOrder(),'alphabetical');// Selecting a result must preserve the browser's template and text filters.
 props.world={...world,templates:[...world.templates,{schemaVersion:9,id:'other',title:'Other',fields:[]}],entries:[...entries,{schemaVersion:9,id:'other-entry',title:'Another',templateId:'other',values:{},archived:false}]};
 tree=render();tree.find(n=>n.props?.id==='world-template-filter').props.onChange('t');
 tree=render();tree.find(n=>n.props?.id==='world-search').props.onChange({target:{value:'Ár'}});
 tree=render();const filtered=tree.find(n=>n.props?.className==='world-entry-list');assert.equal(filtered.props.children[0].length,1);filtered.props.children[0][0].props.onClick();
 tree=render();assert.equal(props.entryId,'a');assert.equal(tree.find(n=>n.props?.id==='world-template-filter').props.value,'t');assert.equal(tree.find(n=>n.props?.id==='world-search').props.value,'Ár');assert.equal(tree.find(n=>n.type?.name==='ActionMenu'&&n.props.label.startsWith('Sort entries:')).props.actions.find(action=>action.selected).label,'Recently modified');
 // Following an explicit reference still reveals a destination outside the list.
 tree.find(n=>n.type?.name==='EntryFields').props.onNavigate('other-entry');tree=render();assert.equal(props.entryId,'other-entry');assert.equal(tree.find(n=>n.props?.id==='world-template-filter').props.value,'');assert.equal(tree.find(n=>n.props?.id==='world-search').props.value,'');assert.equal(mutations,0);
 I.setLanguage('es');tree=render();assert.equal(tree.find(n=>n.type?.name==='ActionMenu'&&n.props.label.startsWith('Ordenar fichas:')).props.actions[0].label,'Nombre: A–Z');
}finally{Object.assign(React,old);I.setLanguage('en');if(previousStorage===undefined)delete globalThis.localStorage;else globalThis.localStorage=previousStorage;}
console.log('Entry ordering: locale/numeric alphabetization, modification directions, unknown dates, immutable timestamp upgrades, connection edits, preference persistence and actual list controls passed.');

const V=loadLocal('../src/visualResources.ts');
const gallery=V.saveVisualResource(world,{id:'image',title:'Reference',notes:'Keep'});
const attached=V.attachEntryImage(gallery,'a','image');
const galleryStamped=O.stampEntryModifications(world,attached,undefined,undefined,4000);
assert.equal(galleryStamped.schemaVersion,11);assert(galleryStamped.entries.every(e=>e.schemaVersion===11));assert(galleryStamped.templates.every(t=>t.schemaVersion===11));
assert.deepEqual(galleryStamped.visualResources,attached.visualResources);assert.deepEqual(galleryStamped.entries[1].imageIds,['image']);
const broken={...galleryStamped,schemaVersion:10,templates:galleryStamped.templates.map(t=>({...t,schemaVersion:10})),entries:galleryStamped.entries.map(e=>({...e,schemaVersion:10}))};
const repaired=O.stampEntryModifications(broken,broken);assert.equal(repaired.schemaVersion,11);assert.deepEqual(repaired.entries[1].imageIds,['image']);assert.equal(repaired.entries[1].modifiedAt,4000);assert.equal(broken.schemaVersion,10);
const edited=O.stampEntryModifications(galleryStamped,{...galleryStamped,entries:galleryStamped.entries.map(e=>e.id==='a'?{...e,title:'Edited'}:e)},undefined,undefined,5000);assert.equal(edited.schemaVersion,11);assert.equal(edited.entries[1].modifiedAt,5000);
console.log('Gallery schemas: imports and later edits preserve version 11; affected in-memory worlds repair without changing content or timestamps.');

assert.equal(V.ensureVisualResourceSchema(galleryStamped),galleryStamped);assert.equal(V.ensureVisualResourceSchema(world),world);assert.equal(V.ensureVisualResourceSchema(broken).schemaVersion,11);
