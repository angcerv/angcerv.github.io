import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const T=loadLocal('../src/timeline.ts'),W=loadLocal('../src/timelineWorkspace.ts'),C=loadLocal('../src/storyCalendar.ts'),P=loadLocal('../src/timelinePreferences.ts');
const {storyDay}=loadLocal('../src/timelineChartLayout.ts'),Chart=loadLocal('../src/TimelineChart.tsx').default,List=loadLocal('../src/TimelineEventList.tsx').default,Member=loadLocal('../src/CalendarEventButton.tsx').default;
const event=(id,start,end)=>({id,title:id,notes:'',dateLabel:'',sceneIds:[],entryIds:[],start,...(end?{end}:{})});
const events=[event('later',{year:2}),event('long',{year:0},{year:10}),event('middle',{year:1}),event('same-start',{year:0},{year:1})],before=JSON.stringify(events);
const window={start:storyDay({year:-1}),end:storyDay({year:11})};
const layout=W.layoutTrack(events,window,800,'',true);
assert.deepEqual(layout.items.map(item=>item.key),['long','same-start','middle','later']);
assert.deepEqual(layout.items.map(item=>item.lane),[0,1,2,3]);assert(layout.items.every((item,index)=>!index||item.y>=layout.items[index-1].y+layout.items[index-1].height));
assert.equal(layout.items[0].x,(storyDay({year:0})-window.start)/(window.end-window.start)*800);assert(layout.items[0].period);assert.equal(JSON.stringify(events),before);
const points=[1,2,3,4].map(day=>event(`day-${day}`,{year:2024,month:1,day})),near={start:storyDay({year:2024,month:1,day:1}),end:storyDay({year:2024,month:1,day:11})};
const small=W.layoutTrack(points,near,80,'',false),large=W.layoutTrack(points,near,1600,'',false);assert.equal(small.items.length,1);assert.equal(large.items.length,4);
assert.deepEqual(small.items[0].events.map(item=>item.id),points.map(item=>item.id));assert(W.layoutTrack(points,near,80,'day-2',false).items.some(item=>item.events.length===1&&item.key==='day-2'));
assert(W.layoutTrack(points,near,1600,'',true).items.every(item=>item.labelX>=0&&item.labelX+item.labelWidth<=1600));
const grouped=W.timelineGroups(T.sortedEvents({schemaVersion:1,events:[event('partial',{year:-1}),event('jan',{year:0,month:1,day:1}),event('feb',{year:0,month:2}),event('undated',undefined)]},'date'));
assert.deepEqual(grouped.map(group=>group.label),['-1','0-01','0-02','undated']);
const calendar={...C.defaultStoryCalendar(),mode:'fixed',months:[{name:'Dawn',days:10},{name:'Sea',days:10}],epochYear:0};
const worldDate={year:-2,month:2,day:3},canonical=C.storyDateFromCalendar(worldDate,calendar),worldGroup=W.timelineGroups([event('world',canonical)],calendar);
assert(worldGroup[0].label.includes('Sea'));assert.equal(W.timelineGroups([event('partial',{year:0,month:1})],calendar)[0].label,'0-01','Never invent a world-calendar equivalent for a partial date');
const long=event('long-title',{year:2024,month:1,day:1});long.title='A complete title that must wrap '.repeat(20);
const html=renderToStaticMarkup(createElement(List,{events:[long],tracks:[{id:'track',title:'Recorded track',eventIds:[long.id]}],selectedId:long.id,selectedIds:[],onSelect(){},onToggle(){},onEdit(){}}));assert(html.includes(long.title));assert(html.includes('Recorded track'));assert(html.includes('aria-pressed="true"'));
const React=createRequire(import.meta.url)('react'),original=Object.fromEntries(['useState','useRef','useMemo','useEffect'].map(key=>[key,React[key]])),oldResize=globalThis.ResizeObserver;
let states=[],refs=[],effects=[],si=0,ri=0,selected='';
const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
function reset(){states=[];refs=[];effects=[];si=ri=0;}
try{
 React.useState=initial=>{const index=si++;if(!(index in states))states[index]=typeof initial==='function'?initial():initial;return[states[index],value=>states[index]=typeof value==='function'?value(states[index]):value];};React.useRef=initial=>{const index=ri++;return refs[index]??(refs[index]={current:initial});};React.useMemo=fn=>fn();React.useEffect=fn=>effects.push(fn);
 const same=Array.from({length:1000},(_,index)=>event(`same-${index}`,{year:0,month:1,day:1})),props={events:same,selectedId:'',onSelectEvent:id=>selected=id,tracks:[{id:'one',title:'One',eventIds:same.slice(0,500).map(event=>event.id)},{id:'two',title:'Two',eventIds:same.slice(500).map(event=>event.id)}]};
 const chart=()=>{si=ri=0;effects=[];return nodes(Chart(props));};let tree=chart();const clusters=tree.filter(node=>node.props?.className?.includes?.('track-cluster'));assert.equal(clusters.length,2,'Coincident events in different tracks never merge');clusters[0].props.onClick();tree=chart();assert(tree.some(node=>node.props?.className==='timeline-cluster-dialog'));const members=tree.filter(node=>node.type===Member);assert.equal(members.length,100);assert(members.every(node=>node.props.event.id.startsWith('same-')));members[0].props.onSelect('same-0');assert.equal(selected,'same-0');assert(!chart().some(node=>node.props?.className==='timeline-cluster-dialog'));
 props.selectedId='same-0';tree=chart();assert(tree.some(node=>node.props?.className==='timeline-selection-guide'));tree.find(node=>node.props?.className?.startsWith?.('track-event ')&&node.props['aria-pressed']).props.onKeyDown({key:'ArrowDown',preventDefault(){}});assert.equal(selected,'same-1');
 reset();const many=Array.from({length:5000},(_,index)=>event(`event-${index}`,{year:2024,month:1,day:1}));selected='';
 const list=()=>{si=ri=0;effects=[];return nodes(List({events:many,selectedId:selected,selectedIds:[],onSelect:id=>selected=id,onToggle(){},onEdit(){}}));};tree=list();assert(tree.filter(node=>node.props?.className==='timeline-table-row').length<30);tree.find(node=>node.props?.className==='timeline-table-title').props.onKeyDown({key:'End',preventDefault(){}});assert.equal(selected,'event-4999');
 const viewport={scrollTop:0,clientHeight:500,clientWidth:700,querySelectorAll:()=>[],querySelector:()=>null};refs[0].current=viewport;tree=list();effects[3]();tree=list();assert(viewport.scrollTop>100000);assert(tree.some(node=>node.props?.['data-event-id']==='event-4999'));
 // A measured wrapped row shifts following rows instead of clipping its content.
 reset();selected='';const shortList=()=>{si=ri=0;effects=[];return nodes(List({events:points,selectedId:'',selectedIds:[],onSelect(){},onToggle(){},onEdit(){}}));};tree=shortList();const initialTop=tree.find(node=>node.props?.['data-event-id']==='day-2').props.style.top;refs[0].current={...viewport,scrollTop:0};const callbacks=[];let disconnected=0;globalThis.ResizeObserver=class{constructor(callback){callbacks.push(callback);}observe(){}unobserve(){}disconnect(){disconnected++;}};tree=shortList();const cleanup=effects[0]();callbacks[1]([{target:{dataset:{eventId:'day-1'},getBoundingClientRect:()=>({height:240})}}]);tree=shortList();assert(tree.find(node=>node.props?.['data-event-id']==='day-2').props.style.top>initialTop);cleanup();assert.equal(disconnected,2);
 assert.equal(P.defaultTimelinePreferences.view,'list');
}finally{Object.assign(React,original);if(oldResize===undefined)delete globalThis.ResizeObserver;else globalThis.ResizeObserver=oldResize;}
console.log('Chronology: stable chronological rows/ties, actual date coordinates, screen-space clusters and isolated tracks, accessible coincident members, date guide/keyboard selection, complete titles/memberships, canonical/partial/world dates, virtual navigation to 5,000 rows and measured wrapping passed without UI.');
