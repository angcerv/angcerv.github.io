import assert from 'node:assert/strict';
import {loadLocal} from './load-local.mjs';
const {MapElementHistory}=loadLocal('../src/mapElementHistory.ts');
const map={id:'map',imageId:'image',title:'Map',notes:'Original notes',markers:[{id:'a',x:.2,y:.3,title:'A',notes:''}],routes:[{id:'r',markerIds:['a','b']}],regions:[],drawing:{width:100,height:100,objects:[],strokes:[]}};
const h=new MapElementHistory();h.sync(map);assert(!h.canUndo&&!h.canRedo);
const moved={...map,markers:[{...map.markers[0],x:.7}]};h.record(map,moved);assert(h.canUndo);
const current={...moved,title:'New title',notes:'New notes',drawing:{...map.drawing,background:'#fff'}};
const undo=h.move(current,'undo');assert.equal(undo.markers[0].x,.2);assert.equal(undo.drawing,current.drawing);assert.equal(undo.notes,'New notes');assert.equal(undo.title,'New title');
const redo=h.move(undo,'redo');assert.equal(redo.markers[0].x,.7);
const removed={...redo,markers:[],routes:[]};h.record(redo,removed);const recovered=h.move(removed,'undo');assert.deepEqual(recovered.markers,redo.markers);assert.deepEqual(recovered.routes,redo.routes);
const renamed={...recovered,markers:[{...recovered.markers[0],title:'First'}]};h.record(recovered,renamed,1000);
const typed={...renamed,markers:[{...renamed.markers[0],title:'First name'}]};h.record(renamed,typed,1200);assert.equal(h.move(typed,'undo').markers[0].title,'A');assert(h.canRedo);
const branched={...recovered,regions:[{id:'region',points:[{x:0,y:0},{x:1,y:0},{x:0,y:1}]}]};h.record(recovered,branched);assert(!h.canRedo);
h.sync({...branched,layers:[{id:'l',visible:true}]});assert(!h.canUndo&&!h.canRedo);
h.record(map,moved);h.sync({...moved,markers:[]});assert(!h.canUndo,'External content changes invalidate stale history');
h.record(map,moved);h.sync({...moved,id:'other'});assert(!h.canUndo);
h.record(map,moved);h.sync({...moved,imageId:'replacement'});assert(!h.canUndo);
let value=map;for(let i=0;i<60;i++){const next={...value,markers:[{...value.markers[0],x:i/100}]};h.record(value,next);value=next;}let count=0;while(h.canUndo){value=h.move(value,'undo');count++;}assert.equal(count,50);
console.log('Map element history: atomic move/delete with route restoration, text grouping, redo branching, independent drawing/metadata, stale-context invalidation and bounded retention passed.');

// Saving through native storage omits empty collections/defaults and reorders fields.
const fresh={...map,routes:[],regions:[],layers:[{id:'l',title:'Layer',visible:true,locked:false}]};
const change={...fresh,markers:[{...fresh.markers[0],x:.6}]};
const saved={...change,routes:undefined,regions:undefined,layers:[{visible:true,title:'Layer',id:'l'}],markers:change.markers.map(marker=>Object.fromEntries(Object.entries(marker).reverse()))};
const retained=new MapElementHistory();retained.record(fresh,change);retained.sync(saved);assert(retained.canUndo,'Saving equivalent native data retains Undo');
const restored=retained.move(saved,'undo');assert.equal(restored.markers[0].x,.2);retained.sync({...restored,routes:undefined,regions:undefined});assert(retained.canRedo,'Saving after Undo retains Redo');assert.equal(retained.move(restored,'redo').markers[0].x,.6);
console.log('Geographic history survives native save normalization and object-key ordering.');
