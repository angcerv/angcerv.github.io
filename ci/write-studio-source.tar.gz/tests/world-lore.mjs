import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const H=loadLocal('../src/worldLore.ts'),{default:Article,LoreIndex}=loadLocal('../src/LoreArticle.tsx'),Editor=loadLocal('../src/WorldbuildingEditor.tsx').default,I=loadLocal('../src/i18n.ts');
const template={schemaVersion:9,id:'custom',title:'Starships',sections:[{id:'second',title:'Engine'},{id:'first',title:'Origins'},{id:'empty',title:'Unused'}],fields:[{id:'n',label:'Crew',fieldType:'number',sectionId:'second'},{id:'b',label:'Armed',fieldType:'boolean',sectionId:'second'},{id:'story',label:'Voyages',fieldType:'longText',sectionId:'first'},{id:'blank',label:'Blank',fieldType:'shortText',sectionId:'empty'},{id:'ref',label:'Home port',fieldType:'reference'},{id:'url',label:'Source',fieldType:'shortText'}]};
const entry={schemaVersion:9,id:'ship',templateId:template.id,title:'Ocean',linkAliases:['O-1'],archived:false,values:{n:0,b:false,story:'**Built at sea**\n\n_Quiet_ <u>journeys</u>\n\n- North\n- South',ref:{entryId:'port'},url:'https://example.com',blank:'  '}};
const world={schemaVersion:9,templates:[template,{schemaVersion:9,id:'places',title:'Ports',fields:[]}],entries:[entry,{schemaVersion:9,id:'port',templateId:'places',title:'Darhaek',archived:false,values:{}}]};
const relations={schemaVersion:2,types:[{id:'trade',name:'Trade',title:'Supplier',inverseTitle:'Customer',symmetric:false,sourceTemplateIds:[],targetTemplateIds:[]}],links:[{id:'link',typeId:'trade',sourceId:'port',targetId:'ship'}]};const original=JSON.stringify({world,relations});
assert.deepEqual(H.loreGroups(template,entry,true).map(group=>group.id),['second','first','']);assert.equal(H.hasLoreValue(template.fields[0],0),true);assert.equal(H.hasLoreValue(template.fields[1],false),true);assert.equal(H.hasLoreValue(template.fields[3],'  '),false);
const props={world,entry,relations,chapters:[],onNavigate(){},onEdit(){},onBack(){},canBack:true};
const html=renderToStaticMarkup(createElement(Article,props));assert(!/<input|<textarea|contenteditable|long-text-toolbar/.test(html));assert(!html.includes('Unused'));assert(html.indexOf('Engine')<html.indexOf('Origins'));assert(html.includes('>0<'));assert(html.includes('No'));assert(html.includes('<strong>Built at sea</strong>'));assert(html.includes('<em>Quiet</em>'));assert(html.includes('<u>journeys</u>'));assert(html.includes('<ul>'));assert(html.includes('Darhaek'));assert(html.includes('Customer'));assert(html.includes('Supplier'));assert(html.includes('noopener noreferrer'));assert(html.includes('O-1'));assert(!/id="lore-appearances"[^>]*open/.test(html));
const empty=renderToStaticMarkup(createElement(Article,{...props,entry:{...entry,values:{}}}));assert(empty.includes('This entry has no filled fields yet.'));assert(empty.includes('Edit entry'));
const broken=renderToStaticMarkup(createElement(Article,{...props,entry:{...entry,values:{ref:{entryId:'missing'}}}}));assert(broken.includes('Missing entry'));
const indexHtml=renderToStaticMarkup(createElement(LoreIndex,{world,entries:world.entries,onNavigate(){}}));assert(indexHtml.includes('Starships'));assert(indexHtml.includes('Ports'));assert(indexHtml.includes('World index'));
// Real mode, article navigation, back, editing, and retry callbacks share one live world.
const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
let states=[],refs=[],si=0,ri=0,worldChanges=0,retries=0;
const SectionIndex=loadLocal('../src/SectionIndex.tsx').default;
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?n.type===SectionIndex?nodes(SectionIndex(n.props)):[n,...nodes(n.props?.children)]:[];
const text=n=>Array.isArray(n)?n.map(text).join(''):typeof n==='string'?n:n?.props?text(n.props.children):'';
let editorProps={world,entryId:'ship',tab:'entries',entryRelations:relations,setEntryId:id=>editorProps.entryId=id,setTab:tab=>editorProps.tab=tab,onChange:next=>{worldChanges++;editorProps.world=next;},onReturn(){}};
function render(){si=0;ri=0;return nodes(Editor(editorProps));}
try{
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 let all=render();const fields=all.find(n=>typeof n.type==='function'&&n.type.name==='EntryFields');assert(fields);assert(all.indexOf(fields)<all.findIndex(n=>n.type?.name==='EntryRelationsPanel'));
 const title=all.find(n=>n.props?.['aria-label']==='Entry title');title.props.onChange({target:{value:'Ocean II'}});assert.equal(editorProps.world.entries[0].title,'Ocean II');
 all=render();all.find(n=>n.type==='button'&&text(n)==='Read').props.onClick();all=render();let article=all.find(n=>n.type===Article);assert(article);assert.equal(article.props.entry.title,'Ocean II');assert.equal(worldChanges,1,'Switching mode never mutates or duplicates data');
 article.props.onNavigate('port');all=render();article=all.find(n=>n.type===Article);assert.equal(article.props.entry.id,'port');assert(article.props.canBack);article.props.onBack();assert.equal(editorProps.entryId,'ship');
 all=render();all.find(n=>n.type==='button'&&text(n)==='Edit').props.onClick();all=render();assert.equal(all.find(n=>n.props?.['aria-label']==='Entry title').props.value,'Ocean II');
 all.find(n=>n.type?.name==='WorldNavigation').props.onSelect('relations');assert(render().some(n=>n.type?.name==='RelationNetwork'));render().find(n=>n.type==='button'&&text(n)==='Read world entries').props.onClick();assert.equal(editorProps.tab,'entries');assert(render().some(n=>n.type===Article));
 editorProps={...editorProps,saveState:{dirty:true,busy:false,error:'disk full'},onRetrySave:async()=>{retries++;return true;}};all=render();assert(all.some(n=>n.props?.role==='alert'&&text(n).includes('disk full')));all.find(n=>n.type==='button'&&text(n)==='Retry save').props.onClick();assert.equal(retries,1);
 I.setLanguage('es');all=render();assert(all.some(n=>n.type==='button'&&text(n)==='Leer'));
}finally{Object.assign(React,old);I.setLanguage('en');}
assert.equal(JSON.stringify({world,relations}),original);
// Geometry-based scroll tracking and disclosure opening never move focus while typing.
const globals={HTMLElement:globalThis.HTMLElement,HTMLDetailsElement:globalThis.HTMLDetailsElement};
class Element{constructor(id,top){this.id=id;this.top=top;this.parentElement=null;}getBoundingClientRect(){return{top:this.top};}focus(){this.focused=true;}blur(){this.blurred=true;}}
class Details extends Element{}
try{
 globalThis.HTMLElement=Element;globalThis.HTMLDetailsElement=Details;
 const first=new Details('first',30),second=new Details('second',300),root=new Element('root',20);root.scrollTop=80;root.querySelectorAll=()=>[first,second];root.scrollTo=options=>root.scrolled=options.top;first.parentElement=root;second.parentElement=root;
 assert.equal(H.visibleLoreSection(root),'first');assert(H.revealLoreSection(root,'second'));assert(second.open);assert.equal(root.scrolled,342);assert(!second.focused);
 const input=new Element('date');input.value='2024-02-30';root.querySelectorAll=()=>[input];root.ownerDocument={activeElement:input};root.contains=()=>true;assert.equal(H.prepareLoreNavigation(root),false);assert(input.focused);input.value='2024-02-29';assert(H.prepareLoreNavigation(root));assert(input.blurred);
}finally{for(const[key,value]of Object.entries(globals)){if(value===undefined)delete globalThis[key];else globalThis[key]=value;}}
console.log('World lore: arbitrary ordered templates, empty/false/zero/rich fields, read-only articles, explicit/broken links, categories, live edits across modes, history, save retry, date drafts and non-focusing scroll navigation passed.');
// The real outline action opens a collapsed section and keeps focus in the index.
const Outline=loadLocal('../src/LoreOutline.tsx').default;
const detailsGlobals={HTMLElement:globalThis.HTMLElement,HTMLDetailsElement:globalThis.HTMLDetailsElement};
try{
 globalThis.HTMLElement=Element;globalThis.HTMLDetailsElement=Details;
 const target=new Details('lore-section-engine',260),root=new Element('root',20);target.parentElement=root;root.scrollTop=0;root.querySelectorAll=()=>[target];root.scrollTo=options=>root.scrolled=options.top;
 React.useState=initial=>[typeof initial==='function'?initial():initial,()=>{}];React.useEffect=()=>{};
 let visible;const all=nodes(Outline({sections:[{id:target.id,title:'Engine'}],root:{current:root},context:'ship:read',onVisible:id=>visible=id}));all.find(n=>n.type==='button'&&text(n)==='Engine').props.onClick();assert(target.open);assert.equal(root.scrolled,222);assert.equal(visible,target.id);assert(!target.focused);
}finally{Object.assign(React,old);for(const[key,value]of Object.entries(detailsGlobals)){if(value===undefined)delete globalThis[key];else globalThis[key]=value;}}
// A closed off-canvas index stays mounted for animation but cannot receive focus.
try{
 let outlineStates=[],outlineIndex=0;
 React.useState=initial=>{const i=outlineIndex++;if(!(i in outlineStates))outlineStates[i]=typeof initial==='function'?initial():initial;return[outlineStates[i],value=>outlineStates[i]=value];};React.useEffect=()=>{};
 const renderOutline=()=>{outlineIndex=0;return nodes(Outline({sections:[{id:'engine',title:'Engine'}],root:{current:null},context:'ship',onVisible(){}}));};
 let all=renderOutline();assert.equal(all.find(n=>n.type==='nav').props.inert,true);assert.equal(all.find(n=>n.type==='nav').props.hidden,undefined);
 all.find(n=>n.props?.className==='lore-outline-toggle').props.onClick();all=renderOutline();assert.equal(all.find(n=>n.type==='nav').props.inert,false);assert.equal(all.find(n=>n.type==='aside').props['data-open'],true);
 let restored=false;all.find(n=>n.type==='aside').props.onKeyDown({key:'Escape',preventDefault(){},currentTarget:{querySelector:()=>({focus(){restored=true;}})}});assert(restored);assert.equal(renderOutline().find(n=>n.type==='nav').props.inert,true);
}finally{Object.assign(React,old);}

// Editorial presentation respects arbitrary templates, source order and data types.
const editorialTemplate={...template,fields:[{id:'intro',label:'Descripción',fieldType:'longText',sectionId:'empty'},...template.fields,{id:'large',label:'Custom log',fieldType:'shortText',sectionId:'first'},{id:'invalid',label:'Broken internal data',fieldType:'shortText',sectionId:'empty'}]};
const editorialEntry={...entry,imageId:'image',values:{...entry.values,intro:'A **brief introduction**.',large:'Long text '.repeat(35),invalid:{internal:true}}};
const editorialWorld={...world,templates:[editorialTemplate,...world.templates.slice(1)],entries:[editorialEntry,...world.entries.slice(1)]};
const sourceBefore=JSON.stringify(editorialWorld);
assert.equal(H.loreIntroduction(editorialTemplate,editorialEntry).id,'intro');
assert.deepEqual(H.loreArticleGroups(editorialTemplate,editorialEntry).map(g=>g.id),['second','first','']);
assert.equal(H.hasLoreValue(editorialTemplate.fields.at(-1),{internal:true}),false);
assert.equal(H.loreFieldLayout(template.fields[0],0),'fact');assert.equal(H.loreFieldLayout(template.fields[1],false),'fact');assert.equal(H.loreFieldLayout(template.fields[3],'lengthy '.repeat(30)),'prose');
assert.equal(H.loreIntroduction(editorialTemplate,{...editorialEntry,values:{intro:'Text '.repeat(100)}}),undefined);
const editorialHtml=renderToStaticMarkup(createElement(Article,{...props,world:editorialWorld,entry:editorialEntry}));
assert.equal((editorialHtml.match(/brief introduction/g)??[]).length,1);assert(editorialHtml.includes('lore-hero-image'));assert(editorialHtml.includes('editorial-portrait'));assert(editorialHtml.includes('lore-prose'));assert(!editorialHtml.includes('[object Object]'));assert(!editorialHtml.includes('Broken internal data'));assert(!editorialHtml.includes('Unused'));assert.equal(JSON.stringify(editorialWorld),sourceBefore);
assert(!renderToStaticMarkup(createElement(Article,props)).includes('lore-hero-image'),'No image means no empty illustration frame');
// Outline is a real, expandable reading navigation, not an off-canvas panel.
const editorialOutline=renderToStaticMarkup(createElement(Outline,{reading:true,sections:[{id:'engine',title:'Engine'}],root:{current:null},context:'ship',onVisible(){}}));assert(editorialOutline.includes('lore-outline-editorial'));assert(editorialOutline.includes('aria-expanded="true"'));assert(editorialOutline.includes('aria-label="Entry sections"'));
console.log('Editorial encyclopedia: explicit introductions without duplication, ordered dynamic sections, compact facts/prose, invalid structures, image/no-image composition, expanded reading outline and immutable source passed.');

// Reading contents include every entry independently of editing filters, in locale order.
const Contents=loadLocal('../src/LoreContents.tsx').default;
const contentsWorld={...world,templates:[{...template,id:'z',title:'Zonas'},{...template,id:'a',title:'Árboles'}],entries:[{...entry,id:'zeta',templateId:'a',title:'Zeta'},{...entry,id:'alamo',templateId:'a',title:'Álamo',archived:true},{...entry,id:'zona',templateId:'z',title:'Zona'},{...entry,id:'orphan',templateId:'removed',title:'Lost'}]};
const contentsBefore=JSON.stringify(contentsWorld);
const contentsHtml=renderToStaticMarkup(createElement(Contents,{world:contentsWorld,selectedId:'alamo',onNavigate(){}}));
assert(contentsHtml.indexOf('Árboles')<contentsHtml.indexOf('Zonas'));
assert(contentsHtml.indexOf('Álamo')<contentsHtml.indexOf('Zeta'));
assert(contentsHtml.includes('Lost'));assert(contentsHtml.includes('Missing template'));
assert(contentsHtml.includes('aria-current="page"'));assert(contentsHtml.includes('aria-expanded="false"'));assert(contentsHtml.includes('inert=""'));
assert(!/<input|<select/.test(contentsHtml));assert.equal(JSON.stringify(contentsWorld),contentsBefore);
console.log('Reading contents: alphabetic template/entry ordering, archived and missing-template entries, collapsed inaccessible panels and selected entry passed.');
