import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const {fitMapSize,zoomMapView,focusMapPoint,constrainMapView,fittedMapView}=loadLocal('../src/mapNavigation.ts');
for(const viewport of [{width:600,height:450},{width:1000,height:600},{width:220,height:200}]){
 for(const image of [{width:2000,height:1000},{width:1000,height:3000},{width:4000,height:200}]){
  const fit=fitMapSize(viewport,image);assert.ok(fit.width<=viewport.width-64+.001);assert.ok(fit.height<=viewport.height-64+.001);assert.ok(Math.abs(fit.width/fit.height-image.width/image.height)<1e-9);
  for(const anchor of [{x:0,y:0},{x:20,y:-10},{x:-30,y:20}]){
   const before={zoom:2,x:15,y:-5},after=zoomMapView(before,3,anchor,viewport,fit);
   assert.ok(Math.abs((anchor.x-before.x)/before.zoom-(anchor.x-after.x)/after.zoom)<1e-9);
   assert.ok(Math.abs((anchor.y-before.y)/before.zoom-(anchor.y-after.y)/after.zoom)<1e-9);
  }
  const marker={x:.75,y:.25},focused=focusMapPoint({zoom:4,x:0,y:0},marker,viewport,fit);
  assert.ok(Math.abs(focused.x+(marker.x-.5)*fit.width*focused.zoom)<1e-9);assert.ok(Math.abs(focused.y+(marker.y-.5)*fit.height*focused.zoom)<1e-9);
  const limited=constrainMapView({zoom:99,x:999999,y:-999999},viewport,fit);assert.equal(limited.zoom,8);assert.ok(limited.x<999999&&limited.y>-999999);
 }
}
const world={schemaVersion:8,templates:[{schemaVersion:8,id:'t',title:'Places',fields:[{id:'description',label:'Description',fieldType:'shortText',archived:false}]}],entries:[{schemaVersion:8,id:'place',templateId:'t',title:'Harbor',values:{description:'Coastal city'},archived:false}]};
const map={id:'map',title:'Coast',imageId:'img',notes:'',markers:[{id:'marker',title:'Harbor',entryId:'place',notes:'',x:.25,y:.5,icon:'city',color:'teal'}]};
// Exercise the actual wheel, pointer, fit and placement handlers with a loaded image.
const require=createRequire(import.meta.url),React=require('react'),saved={useRef:React.useRef,useState:React.useState,useEffect:React.useEffect};
const {MapCanvas}=loadLocal('../src/MapsEditor.tsx');
const hooks=['image-url','',0,true,{width:800,height:400},{width:600,height:450},{zoom:1,x:0,y:0},'pan',true,false];
let stateIndex=0,refIndex=0,effects=[],wheel,captured=false,placed,cleared=0,selectedId='',movedMarker,interaction=false,createdRegion;
const node={clientWidth:600,clientHeight:450,getBoundingClientRect:()=>({left:10,top:20}),getClientRects:()=>node.clientWidth>0?[{}]:[],addEventListener(type,handler,options){if(type==='wheel'){wheel=handler;assert.equal(options.passive,false);}},removeEventListener(){},focus(){},setPointerCapture(){captured=true;},hasPointerCapture:()=>captured,releasePointerCapture(){captured=false;}};
const refs=[{current:node},{current:{getBoundingClientRect:()=>({left:100,top:100,width:400,height:200})}},{current:null}];
React.useRef=initial=>{const i=refIndex++;return refs[i]??(refs[i]={current:initial});};React.useState=initial=>{const index=stateIndex++;if(!(index in hooks))hooks[index]=typeof initial==='function'?initial():initial;return [hooks[index],next=>{hooks[index]=typeof next==='function'?next(hooks[index]):next;}];};React.useEffect=fn=>effects.push(fn);
function nodes(node){if(Array.isArray(node))return node.flatMap(nodes);if(!node||typeof node!=='object')return [];return [node,...nodes(node.props?.children)];}
function render(extra={}){stateIndex=0;refIndex=0;effects=[];return nodes(MapCanvas({map,world,path:'/project',projectId:'project',markerId:selectedId,onRegionCreate:points=>createdRegion=points,onInteractionChange:active=>interaction=active,onClearSelection:()=>cleared++,onSelect:()=>{},onPlace:point=>{placed=point;},onMove:point=>movedMarker=point,...extra}));}
try{
 let all=render();const common=all.find(n=>n.props?.className==='map-common-toolbar');assert(common);assert(!nodes(common).some(n=>n.type?.name==='FieldHelp'));assert.deepEqual(nodes(common).filter(n=>n.type==='button').slice(0,5).map(n=>n.props['aria-label']),['Select and move','Pan','Zoom out','Zoom in','Fit map']);const creationTools=all.find(n=>n.props?.className==='map-canvas-toolbar');assert(!nodes(creationTools).some(n=>['Select and move','Pan','Zoom out','Zoom in','Fit map'].includes(n.props?.['aria-label'])));assert(!all.some(n=>n.type==='button'&&n.props?.['aria-label']==='Export map as PNG'),'Export lives in Settings');const selectTool=all.find(n=>n.props?.['aria-label']==='Select and move');assert(selectTool&&!selectTool.props.disabled);selectTool.props.onClick();assert.equal(hooks[7],'select');effects[3]();let prevented=false;wheel({clientX:360,clientY:195,deltaY:-60,deltaMode:0,preventDefault(){prevented=true;}});assert.equal(prevented,true);
 assert.ok(Math.abs(50-hooks[6].x-50*hooks[6].zoom)<1e-9);assert.ok(Math.abs(-50-hooks[6].y+50*hooks[6].zoom)<1e-9);
 all=render();all.find(n=>n.props?.title==='Fit the whole map (0)').props.onClick();assert.deepEqual(hooks[6],fittedMapView);
 all=render();const canvas=all.find(n=>n.props?.className?.startsWith('map-viewport'));
 const event={button:0,isPrimary:true,pointerId:7,clientX:100,clientY:100,target:{closest:()=>null},currentTarget:node,preventDefault(){}};
 canvas.props.onPointerDown(event);assert.equal(captured,true);assert.equal(interaction,true);canvas.props.onPointerMove({...event,clientX:130,clientY:120});assert.equal(hooks[6].x,30);assert.equal(hooks[6].y,20);canvas.props.onPointerUp(event);assert.equal(captured,false);assert.equal(interaction,false);assert.equal(cleared,0,'Panning must retain the selection');
 canvas.props.onPointerDown(event);canvas.props.onPointerUp({...event,clientX:101,clientY:101});assert.equal(cleared,1,'A background click clears selection');
 canvas.props.onPointerDown(event);canvas.props.onPointerMove({...event,clientX:140});canvas.props.onPointerMove(event);canvas.props.onPointerUp(event);assert.equal(cleared,1,'Dragging back to the starting point remains a drag');
 canvas.props.onPointerDown(event);canvas.props.onPointerCancel(event);assert.equal(cleared,1,'Cancellation must retain selection');
 canvas.props.onPointerDown({...event,target:{closest:()=>({})}});canvas.props.onPointerUp(event);assert.equal(cleared,1,'Element interactions must not clear selection');
 all.find(n=>n.type==='button'&&n.props?.['aria-label']==='Add marker').props.onClick();all=render();all.find(n=>n.type==='img').props.onPointerUp({...event,clientX:200,clientY:200});assert.deepEqual(placed,{x:.25,y:.5});assert.equal(hooks[7],'pan');
 // Dragging the selected marker commits map coordinates once and leaves the camera intact.
 map.routes=[{id:'preview-route',title:'Preview route',color:'teal',markerIds:['marker','end'],notes:''}];map.markers.push({...map.markers[0],id:'end',x:.8,y:.8});
 selectedId='marker';hooks[7]='pan';all=render();
 const pin=all.find(n=>n.props?.['data-map-marker']==='marker'),cameraBefore={...hooks[6]};
 pin.props.onPointerDown({...event,stopPropagation(){}});assert.equal(interaction,true);
 pin.props.onPointerMove({...event,clientX:140,clientY:120});assert.equal(movedMarker,undefined);
 const previewLines=render().filter(n=>n.type==='polyline');assert(previewLines.length>=2);assert(previewLines.every(n=>n.props.points==='350,600 800,800'));assert.equal(map.markers[0].x,.25,'Route preview must not mutate project coordinates');
 pin.props.onPointerUp({...event,clientX:140,clientY:120,stopPropagation(){}});
 assert.equal(interaction,false);assert.deepEqual(movedMarker,{x:.35,y:.6});assert.deepEqual(hooks[6],cameraBefore);
 movedMarker=undefined;pin.props.onPointerDown({...event,stopPropagation(){}});pin.props.onPointerMove({...event,clientX:150});pin.props.onPointerCancel(event);assert.equal(movedMarker,undefined);assert(render().filter(n=>n.type==='polyline').every(n=>n.props.points==='250,500 800,800'));
 pin.props.onPointerDown({...event,stopPropagation(){}});pin.props.onKeyDown({...event,key:'Escape',stopPropagation(){}});pin.props.onPointerUp({...event,clientX:150,stopPropagation(){}});assert.equal(movedMarker,undefined);
 // Hidden names remain available through focus/selection without changing camera state.
 hooks[6]={...fittedMapView};selectedId='';all=render();
 const visibilityMenu=()=>render().find(n=>n.type?.name==='ActionMenu'&&n.props.label==='Label visibility');
 const namesToggle=()=>visibilityMenu().props.actions.find(action=>action.label==='Show marker labels');
 assert.deepEqual(visibilityMenu().props.actions.map(action=>action.label),['Show marker labels','Show region labels']);assert(visibilityMenu().props.actions.every(action=>typeof action.checked==='boolean'));assert(!render().some(n=>['Marker names','Region names'].includes(n.props?.['aria-label'])));
 const markerNode=()=>render().find(n=>n.props?.['data-map-marker']==='marker');
 const markerName=()=>render().find(n=>n.type?.name==='MapMarkerLabel'&&n.props.name==='Harbor');
 namesToggle().onClick();assert.equal(markerName().props.placement?.visible??false,false);
 const nameCamera={...hooks[6]};markerNode().props.onFocus();assert.equal(markerName().props.placement?.visible,true);assert.equal(markerName().props.placement.height,24);
 markerNode().props.onPointerLeave();assert.equal(markerName().props.placement?.visible,true,'Pointer leave must not hide keyboard-focused names');
 markerNode().props.onBlur();assert.equal(markerName().props.placement?.visible??false,false);
 markerNode().props.onPointerEnter({pointerType:'touch'});assert.equal(markerName().props.placement?.visible??false,false,'Touch does not depend on hover');
 markerNode().props.onPointerEnter({pointerType:'mouse'});assert.equal(markerName().props.placement?.visible,true);markerNode().props.onPointerLeave();
 selectedId='marker';assert.equal(markerName().props.placement?.visible,true);assert.deepEqual(hooks[6],nameCamera);
 hooks[6]={zoom:8,x:0,y:0};assert.equal(markerName().props.placement?.visible??false,false,'An offscreen selection must not leave a detached label at the viewport edge');hooks[6]={...nameCamera};
 namesToggle().onClick();
 // Region navigation keeps the draft and owns pointer release (the overlay only renders it).
 all=render();all.find(n=>n.type==='button'&&n.props['aria-label']==='New region').props.onClick();
 const regionViewport=()=>all.find(n=>n.props?.className?.startsWith('map-viewport'));
 const draft=()=>all.find(n=>n.type?.name==='MapRegionsOverlay').props.points;
 const refresh=()=>{all=render();};refresh();
 const tap=(x,y)=>{const click={...event,clientX:x,clientY:y};regionViewport().props.onPointerDown(click);regionViewport().props.onPointerUp(click);refresh();};
 tap(140,120);assert.deepEqual(draft(),[{x:.1,y:.1}]);assert.equal(cleared,1);
 const initialDraft=draft(),initialCamera={...hooks[6]};
 regionViewport().props.onPointerDown(event);regionViewport().props.onPointerMove({...event,clientX:140,clientY:130});regionViewport().props.onPointerUp({...event,clientX:140,clientY:130});refresh();
 assert.notDeepEqual(hooks[6],initialCamera);assert.equal(draft(),initialDraft);assert.equal(hooks[7],'region');assert.equal(captured,false);
 // A drag remains a drag after returning to its start, including touch/pen pointer streams.
 for(const pointerType of ['mouse','touch','pen']){const start={...event,pointerType};regionViewport().props.onPointerDown(start);regionViewport().props.onPointerMove({...start,clientX:150});regionViewport().props.onPointerMove(start);regionViewport().props.onPointerUp(start);refresh();assert.equal(draft(),initialDraft);}
 const beforeCancel={...hooks[6]};regionViewport().props.onPointerDown(event);regionViewport().props.onPointerMove({...event,clientX:160});regionViewport().props.onPointerCancel(event);refresh();assert.deepEqual(hooks[6],beforeCancel);assert.equal(draft(),initialDraft);
 regionViewport().props.onPointerDown(event);regionViewport().props.onPointerMove({...event,clientX:160});regionViewport().props.onLostPointerCapture(event);refresh();assert.deepEqual(hooks[6],beforeCancel);assert.equal(draft(),initialDraft);
 regionViewport().props.onPointerDown(event);regionViewport().props.onPointerMove({...event,clientX:160});regionViewport().props.onKeyDown({...event,target:node,key:'Escape'});refresh();assert.deepEqual(hooks[6],beforeCancel);assert.deepEqual(draft(),[]);assert.equal(hooks[7],'pan');assert.equal(captured,false);
 // Restart after cancellation. Temporary hand mode resumes creation on release.
 all.find(n=>n.type==='button'&&n.props['aria-label']==='New region').props.onClick();refresh();tap(140,120);const resumedDraft=draft();
 all.find(n=>n.type==='button'&&n.props['aria-label']==='Pan').props.onClick();refresh();assert.equal(all.find(n=>n.type==='button'&&n.props['aria-label']==='Pan').props['aria-pressed'],true);
 tap(180,140);assert.equal(draft(),resumedDraft);assert.equal(all.find(n=>n.type==='button'&&n.props['aria-label']==='Pan').props['aria-pressed'],false);
 tap(420,120);assert.equal(draft().length,2);
 all.find(n=>n.type==='button'&&n.props['aria-label']==='Fit map').props.onClick();refresh();assert.equal(hooks[7],'region');assert.equal(draft().length,2);
 all.find(n=>n.type==='button'&&n.props['aria-label']==='Zoom in').props.onClick();refresh();assert.equal(hooks[7],'region');assert.equal(draft().length,2);
 tap(420,260);assert.equal(draft().length,3);const completed=draft();regionViewport().props.onPointerMove({...event,clientX:140,clientY:120});refresh();assert(all.find(n=>n.type?.name==='MapRegionsOverlay').props.closing,'The first point highlights within its screen-pixel hit target');
 // Dragging from the close target pans instead of finishing, even when returning to it.
 const closePress={...event,clientX:140,clientY:120};regionViewport().props.onPointerDown(closePress);regionViewport().props.onPointerMove({...closePress,clientX:190});regionViewport().props.onPointerMove(closePress);regionViewport().props.onPointerUp(closePress);refresh();assert.equal(createdRegion,undefined);assert.equal(draft(),completed);assert.equal(hooks[7],'region');
 assert(!all.some(n=>n.props?.className==='map-region-creation'),'Creation no longer needs a button menu');tap(140,120);assert.deepEqual(createdRegion,completed);assert.equal(hooks[7],'pan');
 // Hidden workspaces must not replace their measured space or camera with zero sizes.
 const oldObserver=globalThis.ResizeObserver;let measure;
 globalThis.ResizeObserver=class{constructor(callback){measure=callback;}observe(){}disconnect(){}};
 try{
  render();const cleanup=effects[1](),spaceBefore={...hooks[5]},cameraBeforeHide={...hooks[6]};
  node.clientWidth=0;node.clientHeight=0;measure();render();effects[2]();
  assert.deepEqual(hooks[5],spaceBefore);assert.deepEqual(hooks[6],cameraBeforeHide);
  node.clientWidth=600;node.clientHeight=450;measure();cleanup();
 }finally{if(oldObserver===undefined)delete globalThis.ResizeObserver;else globalThis.ResizeObserver=oldObserver;}
 // Panel resizing preserves image pixel scale and screen position.
 render();effects[2]();
 const before={...hooks[6]},oldWidth=fitMapSize(hooks[5],hooks[4]).width,oldCenter=hooks[5].width/2;
 hooks[5]={width:420,height:450};render();effects[2]();
 assert(Math.abs(oldWidth*before.zoom-fitMapSize(hooks[5],hooks[4]).width*hooks[6].zoom)<1e-9);
 assert.equal(oldCenter+before.x,hooks[5].width/2+hooks[6].x);

 // The left options host owns the same live creation controls without duplicating gestures.
 const creationHost={nodeType:1},portalView=render({creationTarget:creationHost,onAddRoute(){}}),creationPortal=portalView.find(n=>n.containerInfo===creationHost);assert(creationPortal);
 const creationButtons=nodes(creationPortal.children).filter(n=>n.type==='button');assert.deepEqual(creationButtons.map(n=>n.props['aria-label']),['Add marker','New region','New route']);
 const beforeCreationCamera={...hooks[6]},beforeCreationMap=JSON.stringify(map);creationButtons[0].props.onClick();assert.equal(hooks[7],'add');assert.deepEqual(hooks[6],beforeCreationCamera);assert.equal(JSON.stringify(map),beforeCreationMap);

}finally{Object.assign(React,saved);}
const Editor=loadLocal('../src/MapsEditor.tsx').default;
const html=renderToStaticMarkup(createElement(Editor,{maps:{schemaVersion:1,maps:[map]},world,path:'/project',projectId:'project',mapId:'map',markerId:'marker',chapters:[{id:'c',title:'Opening',scenes:[{id:'s',title:'Arrival',content:'Harbor'}]}],onSelectMap:()=>{},onSelectMarker:()=>{},onChange:()=>{},onImport:async()=>{},onOpenEntry:()=>{},onOpenScene:()=>{},onOpenMention:()=>{}}));
for(const text of ['Linked entry preview','Coastal city','Manuscript appearances','1 chapters · 1 scenes · 1 text mentions','Fit map','Label visibility'])assert.ok(html.includes(text),text);
console.log('Map navigation: aspect-aware fit, cursor-anchored zoom, pan bounds, marker centering, actual wheel/pointer/placement handlers and entry/manuscript preview passed.');
