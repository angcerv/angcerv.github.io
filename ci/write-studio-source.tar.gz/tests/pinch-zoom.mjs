import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const {pinchGeometry,pinchCamera}=loadLocal('../src/pinchGesture.ts');
const start={x:90,y:110},center={x:130,y:150},camera={x:10,y:-20,zoom:1.5};
for(const ratio of [.01,.5,2,100]){const next=pinchCamera(camera,ratio,start,center,.4,3);assert(next.zoom>=.4&&next.zoom<=3);assert(Math.abs((center.x-next.x)/next.zoom-(start.x-camera.x)/camera.zoom)<1e-8);assert(Math.abs((center.y-next.y)/next.zoom-(start.y-camera.y)/camera.zoom)<1e-8);}
assert.equal(pinchGeometry({x:1,y:1},{x:1,y:1}).distance,1);
const React=createRequire(import.meta.url)('react'),{usePinchZoom}=loadLocal('../src/usePinchZoom.ts');
const original={useRef:React.useRef,useEffect:React.useEffect},oldElement=globalThis.Element,oldPointer=globalThis.PointerEvent;
let setup;
class Surface{
 listeners=new Map();cancels=0;
 addEventListener(type,fn){this.listeners.set(type,fn);}removeEventListener(type){this.listeners.delete(type);}
 dispatchEvent(event){event.target=this;this.listeners.get(event.type)?.(event);if(!event.stopped&&event.type==='pointercancel')this.cancels++;return true;}
 closest(){return null;}
}
function event(type,props={}){return {type,cancelable:true,preventDefault(){this.prevented=true;},stopImmediatePropagation(){this.stopped=true;},...props};}
const touch=(identifier,x,y)=>({identifier,clientX:x,clientY:y});
try{
 globalThis.Element=Surface;globalThis.PointerEvent=class{constructor(type,props){Object.assign(this,event(type,props));}};
 React.useRef=value=>({current:value});React.useEffect=fn=>{setup=fn;};
 const node=new Surface();let current={x:0,y:0,zoom:1},updates=0,cancelled=0;const active=[];
 usePinchZoom({current:node},{start:()=>({...current}),update:(snapshot,motion)=>{updates++;current=pinchCamera(snapshot,motion.ratio,motion.start,motion.center,.4,3);},cancel:snapshot=>{cancelled++;current=snapshot;},onActive:value=>active.push(value)});
 let cleanup=setup();const emit=(type,props={})=>{const e=event(type,props);e.target=node;node.listeners.get(type)?.(e);return e;};
 assert(!emit('pointerdown',{pointerType:'mouse',pointerId:9}).stopped);
 assert(!emit('pointerdown',{pointerType:'touch',pointerId:1}).stopped);
 assert(emit('pointerdown',{pointerType:'touch',pointerId:2}).stopped);
 assert(emit('touchstart',{touches:[touch(1,0,0),touch(2,100,0)]}).prevented);assert.equal(node.cancels,2,'Child-owned previews receive cancellation');
 emit('touchmove',{touches:[touch(1,0,0),touch(2,200,0)]});assert.equal(current.zoom,2);assert.equal(updates,1);
 assert(emit('pointerup',{pointerType:'touch',pointerId:1}).stopped,'Pinching must not commit a drag or a marker');
 emit('touchend',{touches:[touch(2,200,0)]});emit('touchmove',{touches:[touch(2,220,0)]});assert.equal(updates,1,'One remaining finger must not resume an edit');
 emit('touchend',{touches:[]});assert.deepEqual(active,[true,false]);assert(emit('click',{detail:1}).stopped);assert(!emit('click',{detail:0}).stopped,'Keyboard activation stays available');
 emit('pointerdown',{pointerType:'touch',pointerId:3});emit('pointerdown',{pointerType:'touch',pointerId:4});emit('touchstart',{touches:[touch(3,0,0),touch(4,100,0)]});
 const before={...current};emit('touchmove',{touches:[touch(3,0,0),touch(4,50,0)]});assert.notEqual(current.zoom,before.zoom);emit('touchcancel',{touches:[]});assert.deepEqual(current,before);assert.equal(cancelled,1);
 cleanup();assert.equal(node.listeners.size,0);
}finally{Object.assign(React,original);if(oldElement===undefined)delete globalThis.Element;else globalThis.Element=oldElement;if(oldPointer===undefined)delete globalThis.PointerEvent;else globalThis.PointerEvent=oldPointer;}
console.log('Pinch zoom: midpoint anchoring, bounds, mouse/keyboard preservation, child cancellation, release suppression, cancellation rollback and cleanup passed without UI.');
