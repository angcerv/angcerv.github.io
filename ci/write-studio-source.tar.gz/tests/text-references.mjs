import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {readFileSync} from 'node:fs';
import {loadLocal} from './load-local.mjs';
const Tokens=loadLocal('../src/textReferenceTokens.ts'),L=loadLocal('../src/longText.ts');
const {indexProjectTextReferences}=loadLocal('../src/textReferenceIndex.ts');
const {createEntryPackage,importEntries}=loadLocal('../src/entryTransfer.ts');
const {TextReferenceContext}=loadLocal('../src/textReferenceContext.ts');
const UI=loadLocal('../src/TextReferenceUI.tsx');
const {LongTextView}=loadLocal('../src/LongTextEditor.tsx');
const {incomingEntryLinks}=loadLocal('../src/worldbuilding.ts');
const id='00000000-0000-0000-0000-000000000001',target='00000000-0000-0000-0000-000000000002',other='00000000-0000-0000-0000-000000000003';
for(const label of ['Darhaek','Alias | uno','Literal [x] y ] y \\','<script>x</script>','**doble** _nombre_ 🌿']){
 const token=Tokens.encodeTextReference(target,label),refs=Tokens.textReferences('Antes '+token+' después');assert.equal(refs.length,1);assert.equal(refs[0].label,label);assert.equal(Tokens.textReferencePlainText(token),label);
 for(const source of [token,`**${token}**`,`- ${token}\n- Fin`,`_Antes ${token} después_`]){const doc=L.longTextDocument(source);assert.deepEqual(L.longTextDocument(L.longTextMarkdown(doc)),doc);assert.ok(L.longTextPlainText(source).includes(label));}
}
const token=Tokens.encodeTextReference(target,'Puerto');assert.equal(Tokens.textReferences('\\'+token).length,0);assert.equal(Tokens.textReferences('[[entry:invalid|Name]]').length,0);assert.equal(Tokens.textReferences('[[entry:'+target+'|bad\nlabel]]').length,0);
const literal=L.longTextDocument('\\'+token);assert.deepEqual(L.longTextDocument(L.longTextMarkdown(literal)),literal);assert.equal(Tokens.textReferences(Tokens.remapTextReferences(token,()=>other))[0].entryId,other);
assert.equal(Tokens.insertTextReference('Hola puerto.',5,11,target,'puerto').value,'Hola '+Tokens.encodeTextReference(target,'puerto')+'.');
const template={schemaVersion:10,id:'00000000-0000-0000-0000-000000000010',title:'Custom',fields:[{id:'00000000-0000-0000-0000-000000000011',label:'Notes',fieldType:'longText',archived:false}]};
const field=template.fields[0].id,world={schemaVersion:10,templates:[template],entries:[{schemaVersion:10,id,templateId:template.id,title:'First',archived:false,values:{[field]:token}},{schemaVersion:10,id:target,templateId:template.id,title:'Renamed port',archived:true,values:{}}]};
const project={schemaVersion:1,id:'p',title:'Story',revision:1,worldbuilding:world,chapters:[{id:'c',title:'Chapter',synopsis:token,scenes:[{id:'s',title:'Scene',content:'No references.',synopsis:token,reviewComments:[{text:token}]}]}],plots:{schemaVersion:1,threads:[{id:'plot',title:'Mystery',notes:token,beats:[{sceneId:'s',note:token}]}]},timeline:{schemaVersion:1,events:[{id:'event',title:'Event',notes:token}]},worldIdeas:[{id:'idea',title:'Idea',description:token}],maps:{schemaVersion:1,maps:[{id:'map',title:'Map',notes:token,markers:[{title:'Marker',notes:token}],routes:[{title:'Route',notes:token}]}]}};
const before=JSON.stringify(project),index=indexProjectTextReferences(project);
for(const kind of ['entry','chapter','scene','plot','event','idea','map'])assert.ok(index.some(item=>item.kind===kind&&item.entryId===target),kind);assert.equal(JSON.stringify(project),before);assert.equal(incomingEntryLinks(world,target).length,1);
let opened;
const context={project,world,index,openEntry:value=>opened=value,openSource(){}};
const render=element=>renderToStaticMarkup(createElement(TextReferenceContext.Provider,{value:context},element));
const html=render(createElement(LongTextView,{value:'**Linked '+token+'**'}));assert.ok(html.includes('text-entry-link'));assert.ok(html.includes('Renamed port'));assert.ok(!html.includes('[[entry:'));assert.ok(html.includes('<strong>'));
const broken=render(createElement(LongTextView,{value:Tokens.encodeTextReference(other,'Gone')}));assert.ok(broken.includes('text-reference-missing'));assert.ok(broken.includes('Gone'));assert.ok(!broken.includes('[[entry:'));
const unsafe=render(createElement(LongTextView,{value:Tokens.encodeTextReference(target,'<script>alert(1)</script>')}));assert.ok(!unsafe.includes('<script>'));assert.ok(unsafe.includes('&lt;script&gt;'));
const packet=createEntryPackage(world,[id]);assert.equal(packet.worldbuilding.entries.length,2,'Inline links include their dependency, including archived destinations');const imported=importEntries({schemaVersion:10,templates:[],entries:[]},packet,[id]);const copy=imported.world.entries.find(entry=>entry.id===imported.entryId),destination=imported.world.entries.find(entry=>entry.id!==imported.entryId);assert.equal(Tokens.textReferences(copy.values[Object.keys(copy.values)[0]])[0].entryId,destination.id);assert.notEqual(destination.id,target);assert.equal(JSON.stringify(project),before);
// Drive actual picker, insertion/unlink and reference callbacks with hook stubs, without a browser.
const require=createRequire(import.meta.url),React=require('react'),saved={useContext:React.useContext,useState:React.useState,useRef:React.useRef},originalDocument=globalThis.document,originalFrame=globalThis.requestAnimationFrame;
let states=[],cursor=0,refs=[],refCursor=0,changed;
const nodes=n=>Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];
try{
 React.useContext=()=>context;React.useState=initial=>{const i=cursor++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useRef=initial=>{const i=refCursor++;return refs[i]??(refs[i]={current:initial});};
 const link=UI.TextEntryLink({entryId:target,label:'Puerto'});link.props.onClick();assert.equal(opened,target);
 let element={selectionStart:5,selectionEnd:11,focus(){},setSelectionRange(from){this.caret=from;}};globalThis.document={getElementById:()=>element};globalThis.requestAnimationFrame=callback=>callback();
 function renderTools(value='Hola puerto.',maxLength){cursor=0;refCursor=0;return nodes(UI.TextReferenceTools({targetId:'field',value,onChange:event=>changed=event.target.value,maxLength}));}
 let tree=renderTools();tree.find(n=>n.type==='button'&&n.props['aria-expanded']!==undefined).props.onClick();tree=renderTools();tree.find(n=>n.type===UI.TextReferencePicker).props.onChoose(target,'Renamed port');assert.equal(changed,'Hola '+Tokens.encodeTextReference(target,'puerto')+'.');
 tree=renderTools(changed);tree.find(n=>n.props?.className==='text-reference-unlink').props.onClick();assert.equal(changed,'Hola puerto.');
 tree=renderTools();tree.find(n=>n.type==='button'&&n.props['aria-expanded']!==undefined).props.onClick();tree=renderTools('Hola puerto.',12);changed=undefined;tree.find(n=>n.type===UI.TextReferencePicker).props.onChoose(target,'Port');assert.equal(changed,undefined);assert.ok(renderTools('Hola puerto.',12).some(n=>n.props?.role==='alert'));
 states=[];cursor=0;let picked;const picker=nodes(UI.TextReferencePicker({onChoose:(...args)=>picked=args,onClose(){}}));assert.equal(picker.filter(n=>n.type==='button'&&n.props.children?.some?.(child=>child?.type==='strong')).length,1,'Archived entries stay readable but are excluded from new selections');
}finally{Object.assign(React,saved);if(originalDocument===undefined)delete globalThis.document;else globalThis.document=originalDocument;if(originalFrame===undefined)delete globalThis.requestAnimationFrame;else globalThis.requestAnimationFrame=originalFrame;}
const app=readFileSync(new URL('../src/App.tsx',import.meta.url),'utf8');assert.ok(app.includes('<TextReferenceProvider project={project}'));for(const path of ['ManuscriptTools','ReviewCommentDialog','MapsEditor','ShortTextEditor','PlotsEditor','TemplateFields','MapRoutesPanel','TimelineDialogs','PlotDevelopment','ReviewCommentsPanel'])assert.ok(/TextReferenceTools|LongTextEditor/.test(readFileSync(new URL(`../src/${path}.tsx`,import.meta.url),'utf8')),path);
console.log('Text references: UUID/label codecs, format/escape round trips, missing/renamed/archived targets, safe rendering, picker insertion/unlink/limits, all-source backlinks, portable dependency remapping and live source wiring passed.');
// Validate references against the actual editor schema without launching an app or browser.
const {getSchema}=require('@tiptap/react'),StarterKit=require('@tiptap/starter-kit').default,{EntryMentionNode}=loadLocal('../src/entryMentionNode.ts');
const {EditorState,NodeSelection}=require('@tiptap/pm/state');
const schema=getSchema([StarterKit,EntryMentionNode]);
const richDoc=schema.nodeFromJSON(L.longTextDocument(`Before **${token}** after.`));let referencePosition;
richDoc.descendants((node,pos)=>{if(node.type.name==='entryMention'){referencePosition=pos;assert.equal(node.attrs.entryId,target);assert.equal(node.attrs.label,'Puerto');assert(node.isAtom);assert(node.marks.some(mark=>mark.type.name==='bold'));}});
let editorState=EditorState.create({schema,doc:richDoc});editorState=editorState.apply(editorState.tr.setSelection(NodeSelection.create(richDoc,referencePosition)));assert.equal(editorState.selection.node.type.name,'entryMention');
const originalText=editorState.selection.node.attrs.label;editorState=editorState.apply(editorState.tr.replaceSelectionWith(schema.text(originalText)));assert.equal(Tokens.textReferences(L.longTextMarkdown(editorState.doc.toJSON())).length,0);assert.ok(L.longTextPlainText(L.longTextMarkdown(editorState.doc.toJSON())).includes('Puerto'));
const {searchProject}=loadLocal('../src/globalSearch.ts'),{planningMarkdown}=loadLocal('../src/planningExport.ts');
const searchable={...project,timeline:{...project.timeline,events:project.timeline.events.map(event=>({...event,dateLabel:'',entryIds:[],sceneIds:[]}))},worldIdeas:project.worldIdeas.map(idea=>({...idea,status:'idea',entryIds:[]})),chapters:[{id:'c',title:'Chapter',synopsis:'Visit '+token,scenes:[{id:'s',title:'Scene',content:'Text.',synopsis:'Visit '+token}]}],plots:{schemaVersion:1,threads:[]}};
assert.ok(searchProject(searchable,'Visit Puerto').some(result=>result.kind==='chapter'));const readableExport=planningMarkdown(searchable);assert.ok(readableExport.includes('Visit Puerto'));assert.ok(!readableExport.includes('[[entry:'));
console.log('Reference editor schema: atomic selection, marks and unlink preserving text; readable synopsis search and planning exports passed.');
// Short-text fields display atomic names while retaining the exact plain-text codec.
const P=loadLocal('../src/plainTextReferences.ts');
for(const value of [token,'Before '+token+' after','**literal** _text_ <u>literal</u>','First\n\nLast\n','\n'+token]){
 const doc=P.plainReferenceDocument(value);assert.equal(P.plainReferenceText(doc),value);
 const index=P.plainReferenceIndex(doc);assert.equal(index.text,value);assert.equal(index.positions.length,value.length);
}
const shortDoc=P.plainReferenceDocument('Before '+token+' after');assert.equal(shortDoc.content[0].content[1].type,'entryMention');assert.equal(shortDoc.content[0].content[1].attrs.label,'Puerto');assert(!P.plainReferenceText(shortDoc,true).includes('[[entry:'));
const plainSchema=getSchema([StarterKit.configure({heading:false,blockquote:false,orderedList:false,bulletList:false,listItem:false,code:false,codeBlock:false,strike:false,underline:false,bold:false,italic:false,link:false,horizontalRule:false}),EntryMentionNode]);
let rejections=0;const limitExtension=P.plainReferenceLimit(12,()=>rejections++),plugins=limitExtension.config.addProseMirrorPlugins.call({});
let shortState=EditorState.create({schema:plainSchema,doc:plainSchema.nodeFromJSON(P.plainReferenceDocument('Puerto')),plugins});
const linked=plainSchema.nodes.entryMention.create({entryId:target,label:'Puerto'});
shortState=shortState.apply(shortState.tr.replaceWith(1,7,linked));assert.equal(P.plainReferenceText(shortState.doc.toJSON()),token,'UUID overhead does not consume the visible limit');
const rejected=shortState.applyTransaction(shortState.tr.insertText('x'.repeat(20),2));assert.equal(rejected.transactions.length,0);assert.equal(rejections,1);assert.equal(P.plainReferenceText(rejected.state.doc.toJSON()),token);
const overlong=EditorState.create({schema:plainSchema,doc:plainSchema.nodeFromJSON(P.plainReferenceDocument('x'.repeat(20))),plugins});assert.equal(overlong.applyTransaction(overlong.tr.delete(1,2)).transactions.length,1);assert.equal(overlong.applyTransaction(overlong.tr.insertText('x',1)).transactions.length,0);
const {acceptsShortText}=loadLocal('../src/ShortTextEditor.tsx');assert(acceptsShortText('',Tokens.encodeTextReference(target,'x'.repeat(200))));assert(!acceptsShortText('',Tokens.encodeTextReference(target,'x'.repeat(201))));
console.log('Plain field references: visible atomic names, exact literal/newline round trips, legacy fragment positions, visible character limits, rejected overflow and preserved overlong values passed without UI.');

const {history,undo,redo}=require('@tiptap/pm/history');
let undoState=EditorState.create({schema:plainSchema,doc:plainSchema.nodeFromJSON(P.plainReferenceDocument('x'.repeat(20))),plugins:[history(),...plugins]});
undoState=undoState.apply(undoState.tr.delete(1,2));assert(undo(undoState,tr=>undoState=undoState.apply(tr)));assert.equal(P.plainReferenceText(undoState.doc.toJSON()).length,20,'Undo can restore legacy overlong content');assert(redo(undoState,tr=>undoState=undoState.apply(tr)));assert.equal(P.plainReferenceText(undoState.doc.toJSON()).length,19);
