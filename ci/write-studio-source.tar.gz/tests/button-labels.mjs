import assert from 'node:assert/strict';
import {readFileSync,readdirSync} from 'node:fs';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import ts from 'typescript';
import postcss from 'postcss';
import {loadLocal} from './load-local.mjs';
const I=loadLocal('../src/i18n.ts'),originalLanguage=I.getLanguage(),catalogue=JSON.parse(readFileSync(new URL('../src/locales/es.json',import.meta.url),'utf8'));
try{
 for(const language of ['en','es']){
  I.setLanguage(language);
  for(const [key,translation] of Object.entries(catalogue))if(/…|\.\.\./.test(key+translation))assert(!/…|\.\.\./.test(I.buttonLabel(key)),key);
  const title='A story... and a secret…';assert(I.buttonLabel('Edit scene: {0}',title).includes(title));assert.equal(I.buttonLabel(title),title,'Untranslated project content is preserved');assert(I.t('Loading…').includes('…'),'Status and literary text keep their punctuation');
  const project={id:'p',schemaVersion:1,revision:0,title,chapters:[],worldbuilding:{templates:[],entries:[]}};
  for(const file of ['ExportDialog','PlanningExportDialog','EncyclopediaExportDialog']){
   const Component=loadLocal(`../src/${file}.tsx`).default,html=renderToStaticMarkup(createElement(Component,{project,path:'/book',onClose(){}}));
   for(const [,content] of html.matchAll(/<button\b[^>]*>([\s\S]*?)<\/button>/g))assert(!/…|\.\.\./.test(content),`${file}: ${content}`);
  }
 }
}finally{I.setLanguage(originalLanguage);}
// Catch untranslated action suffixes at their render sites, leaving placeholders/status text alone.
const actionTags=new Set(['button','IconButton','ActionMenu','Dropdown','FieldHelp']);
for(const name of readdirSync(new URL('../src/',import.meta.url)).filter(name=>name.endsWith('.tsx'))){
 const file=ts.createSourceFile(name,readFileSync(new URL('../src/'+name,import.meta.url),'utf8'),ts.ScriptTarget.Latest,true,ts.ScriptKind.TSX);
 function actionContext(node){for(let p=node.parent;p;p=p.parent){if(ts.isJsxAttribute(p)){const attr=p.name.getText(file),tag=p.parent.parent;if(/^on[A-Z]/.test(attr))return false;if(ts.isJsxOpeningLikeElement(tag)&&actionTags.has(tag.tagName.getText(file))&&['label','title','aria-label','placeholder'].includes(attr))return true;}if(ts.isPropertyAssignment(p)){if(p.name.getText(file)==='disabledReason')return false;if(p.name.getText(file)==='label')return true;if(/^on[A-Z]/.test(p.name.getText(file)))return false;}if(ts.isJsxElement(p)&&['button','IconButton','ActionMenu'].includes(p.openingElement.tagName.getText(file)))return true;}return false;}
 function walk(node){if(ts.isCallExpression(node)&&node.expression.getText(file)==='buttonLabel'&&ts.isStringLiteralLike(node.arguments[0])&&/…|\.\.\./.test(node.arguments[0].text))assert(Object.hasOwn(catalogue,node.arguments[0].text),`${name}: action keys must be localized before removing suffixes`);if(ts.isCallExpression(node)&&node.expression.getText(file)==='t'&&actionContext(node)){const key=node.arguments[0];if(key&&ts.isStringLiteralLike(key))assert(!/…|\.\.\./.test(key.text+(catalogue[key.text]??'')),`${name} uses an action suffix without buttonLabel: ${key.text}`);}ts.forEachChild(node,walk);}walk(file);
}
const css=postcss.parse(readFileSync(new URL('../src/styles/controls.css',import.meta.url),'utf8'));let typography;
css.walkRules(rule=>{if(rule.selector.startsWith(':root button,:root input[type=button]')){typography={};rule.walkDecls(decl=>typography[decl.prop]=decl.value);}});
assert.equal(typography['font-family'],'var(--ui-control-font)');assert.equal(typography['font-size'],'var(--ui-control-size)');assert.equal(typography['font-weight'],'var(--ui-control-weight)');assert.equal(typography['line-height'],'var(--ui-control-line)');assert.equal(typography['text-transform'],'none');
console.log('Button consistency: action labels in both languages, unchanged project titles/statuses, export controls, shared typography and source-wide suffix guards passed without UI.');
