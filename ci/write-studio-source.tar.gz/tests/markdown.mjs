import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import ts from 'typescript';
const js = ts.transpileModule(readFileSync(new URL('../src/model.ts', import.meta.url), 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.ES2022 } }).outputText;
const { toMarkdown, fromMarkdown } = await import(`data:text/javascript;base64,${Buffer.from(js).toString('base64')}`);
function normalized(doc) {
  return doc.content.map(p => (p.content ?? []).flatMap(n => n.type === 'hardBreak' ? [{ break: true }] : Array.from(n.text).map(text => ({ text, marks: (n.marks ?? []).map(m => m.type).sort() }))));
}
const marks = [[], [{ type: 'bold' }], [{ type: 'italic' }], [{ type: 'bold' }, { type: 'italic' }]];
for (const a of marks) for (const b of marks) {
  const doc = { type: 'doc', content: [
    { type: 'paragraph', content: [{ type: 'text', text: 'Érase 世界 🌿 * _ \\ [link](x) <tag> # 1.', marks: a }, { type: 'text', text: 'Next', marks: b }, { type: 'hardBreak' }, { type: 'text', text: 'After break' }] },
    { type: 'paragraph', content: [] }, { type: 'paragraph', content: [{ type: 'text', text: 'Last paragraph' }] }, { type: 'paragraph' },
  ] };
  assert.deepEqual(normalized(fromMarkdown(toMarkdown(doc))), normalized(doc));
}
assert.throws(() => fromMarkdown('**unclosed'));
assert.throws(() => fromMarkdown('line\nbreak'));
console.log('Markdown: 16 formatting combinations, Unicode, escapes, empty paragraphs and hard breaks passed.');
