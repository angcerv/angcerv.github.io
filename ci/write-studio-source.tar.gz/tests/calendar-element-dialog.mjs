import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const C=loadLocal('../src/storyCalendar.ts'),E=loadLocal('../src/calendarElementDraft.ts');
const calendar={...C.defaultStoryCalendar(),schemaVersion:2,mode:'fixed',months:[{name:'Dawn',days:10},{name:'Sea',days:10}],weekdays:['Sun','Moon'],epochWeekday:1,eras:[],seasons:[{name:'Rain',month:1,day:1}],holidays:[]},before=JSON.stringify(calendar);
for(const [kind,changes] of Object.entries({months:{name:' Third ',days:'17'},weekdays:{name:'Lastday'},eras:{name:'Founding',startYear:'0'},seasons:{name:'Dry',month:'2',day:'1'},holidays:{name:'New tide',month:'2',day:'10',duration:'2',description:' Celebration '}})){
 const request={kind},draft={...E.newCalendarElementDraft(calendar,request),...changes},patch=E.calendarElementPatch(calendar,request,draft);assert.equal(patch[kind].length,calendar[kind].length+1);const updated={...calendar,...patch};C.validateStoryCalendar(updated);assert.equal(JSON.stringify(calendar),before);
}
const eraRequest={kind:'eras'},eraDraft={...E.newCalendarElementDraft(calendar,eraRequest),name:'Founding',description:' Foundation history '};
const eraCalendar={...calendar,...E.calendarElementPatch(calendar,eraRequest,eraDraft)};
assert.equal(eraCalendar.eras[0].description,'Foundation history');
assert.equal(E.newCalendarElementDraft(eraCalendar,{kind:'eras',index:0}).description,'Foundation history');
assert.equal(E.calendarElementPatch(eraCalendar,{kind:'eras',index:0},{...eraDraft,description:' '}).eras[0].description,undefined);
assert.throws(()=>E.calendarElementPatch(calendar,eraRequest,{...eraDraft,description:'x'.repeat(4001)}));
assert.throws(()=>C.validateStoryCalendar({...eraCalendar,eras:[{...eraCalendar.eras[0],description:'x'.repeat(4001)}]}));
const edit={kind:'months',index:0},month=E.newCalendarElementDraft(calendar,edit);assert.equal(month.days,'10');assert.equal(E.calendarElementPatch(calendar,edit,{...month,name:'Changed'}).months.length,2);assert.throws(()=>E.calendarElementPatch(calendar,{kind:'weekdays'},{...month,name:' sun '}),/already exists/);
for(const days of ['','0','1001','2.5'])assert.throws(()=>E.calendarElementPatch(calendar,{kind:'months'},{...month,name:'Third',days}));
assert.throws(()=>E.calendarElementPatch(calendar,{kind:'eras'},{...month,name:'Era',startYear:''}));assert.equal(E.calendarElementPatch(calendar,{kind:'eras'},{...month,name:'Era',startYear:'-12'}).eras[0].startYear,-12);
assert.throws(()=>E.calendarElementPatch(calendar,{kind:'seasons'},{...month,name:'Dry',month:'1',day:'1'}),/already begins/);assert.throws(()=>E.calendarElementPatch(calendar,{kind:'holidays'},{...month,name:'Festival',month:'2',day:'11'}));
const gregorian=C.defaultStoryCalendar();assert.throws(()=>E.calendarElementPatch(gregorian,{kind:'months'},{...month,name:'Thirteenth'}));assert.equal(E.calendarElementPatch(gregorian,{kind:'months',index:1},{...month,name:'Second',days:'1000'}).months[1].days,28);
const holiday={...month,name:'Leap day',month:'2',day:'29',duration:'1'};assert.equal(E.calendarElementPatch(gregorian,{kind:'holidays'},holiday).holidays[0].day,29);assert.throws(()=>E.calendarElementPatch(gregorian,{kind:'seasons'},holiday));
const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useRef:React.useRef,useId:React.useId};
const Dialog=loadLocal('../src/CalendarElementDialog.tsx').default,Parent=loadLocal('../src/StoryCalendarDialog.tsx').default,List=loadLocal('../src/CalendarElementList.tsx').default,ProjectModal=loadLocal('../src/ProjectModal.tsx').default;
let state=[],index=0,applied,closed=0;const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
try{
 React.useState=initial=>{const i=index++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return [state[i],value=>state[i]=typeof value==='function'?value(state[i]):value];};React.useRef=value=>{const i=index++;return state[i]??(state[i]={current:value});};React.useId=()=> 'element-test';
 const render=()=>{index=0;return nodes(Dialog({calendar,request:{kind:'months'},onSave:value=>applied=value,onClose:()=>closed++}));};let tree=render();const submit=()=>render().find(node=>node.type==='form').props.onSubmit({preventDefault(){},stopPropagation(){}});
 submit();assert.equal(applied,undefined);assert(render().some(node=>node.props?.role==='alert'));
 tree=render();tree.find(node=>node.type==='input'&&node.props.id==='element-test-name').props.onChange({target:{value:'Third'}});tree=render();tree.find(node=>node.type==='input'&&node.props.type==='number').props.onChange({target:{value:'17'}});submit();assert.equal(applied.months[2].days,17);assert.equal(JSON.stringify(calendar),before);
 render().find(node=>node.type==='button'&&node.props.children==='Cancel').props.onClick();assert.equal(closed,1);
 state=[];let committed;const parent=()=>{index=0;return nodes(Parent({initial:calendar,onSave:value=>committed=value,onClose(){}}));};tree=parent();tree.find(node=>node.type==='button'&&node.props.children?.includes?.('Add month')).props.onClick();tree=parent();let popup=tree.find(node=>node.type===Dialog);assert.equal(popup.props.calendar.months.length,2);assert.equal(tree.find(node=>node.type===ProjectModal).props.busy,true);assert(!nodes(tree.find(node=>node.type==='form')).some(node=>node.type===Dialog));assert.equal(committed,undefined);
 popup.props.onClose();assert(!parent().some(node=>node.type===Dialog));assert.equal(parent().find(node=>node.type===List).props.items.length,2);
 tree=parent();tree.find(node=>node.type==='button'&&node.props.children?.includes?.('Add month')).props.onClick();tree=parent();popup=tree.find(node=>node.type===Dialog);popup.props.onSave(applied);tree=parent();assert.equal(tree.find(node=>node.type===List).props.items.length,3);assert.equal(committed,undefined);tree.find(node=>node.type==='form').props.onSubmit({preventDefault(){}});assert.equal(committed.months[2].name,'Third');assert.equal(JSON.stringify(calendar),before);
}finally{Object.assign(React,old);}
console.log('Calendar element dialogs: all five kinds, staged creation/editing, cancellation without empty rows, separate forms/guarded parent, duplicate/date validation, zero/negative eras, fixed Gregorian lengths and immutable final calendar commit passed without UI.');
