import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const {saveWorldIdea}=loadLocal('../src/worldIdeas.ts');
const {projectPendingItems,filterPendingItems}=loadLocal('../src/pendingItems.ts');
const {setLanguage}=loadLocal('../src/i18n.ts');
const Editor=loadLocal('../src/WorldIdeaEditor.tsx').default;
const project={schemaVersion:1,id:'p',title:'World',revision:0,chapters:[],worldbuilding:{schemaVersion:10,templates:[],entries:[{id:'entry',title:'Manantial',templateId:'t',values:{},archived:false}]}};
const idea={id:'idea',title:'  El despertar  ',description:'¿Qué coste tiene?',status:'idea',entryIds:['entry','entry','deleted']};
const updated=saveWorldIdea(project,idea);
assert.equal(project.worldIdeas,undefined);assert.equal(updated.worldIdeas[0].title,'El despertar');assert.deepEqual(updated.worldIdeas[0].entryIds,['entry','deleted']);
let items=projectPendingItems(updated);assert.equal(filterPendingItems(items,'idea','__project','manantial').length,1);assert.ok(items[0].context.includes('Deleted entry'));assert.equal(filterPendingItems(items,'idea','chapter','').length,0);
const done=saveWorldIdea(updated,{...updated.worldIdeas[0],decision:'Conservar el coste previsto.',status:'incorporated'});items=projectPendingItems(done);assert.equal(filterPendingItems(items,'all','','').length,0);assert.equal(filterPendingItems(items,'idea','','','all').length,1);assert.equal(filterPendingItems(items,'idea','','','incorporated').length,1);
assert.equal(saveWorldIdea(done,{...done.worldIdeas[0],status:'deciding'}).worldIdeas.length,1);
assert.throws(()=>saveWorldIdea(project,{...idea,title:'  '}));assert.throws(()=>saveWorldIdea(project,{...idea,status:'oops'}));
// Exercise draft editing, links, statuses, submit and cancel without mutating source data.
const require=createRequire(import.meta.url),React=require('react'),saved={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
let hooks=[],index=0,committed=[],closed=0;
function nodes(n){if(Array.isArray(n))return n.flatMap(nodes);if(!n||typeof n!=='object')return [];return[n,...nodes(n.props?.children)];}
const props={idea:updated.worldIdeas[0],world:project.worldbuilding,onSave:i=>committed.push(i),onClose:()=>closed++};
function render(){index=0;return nodes(Editor(props));}
try{
 React.useState=initial=>{const i=index++;if(!(i in hooks))hooks[i]=typeof initial==='function'?initial():initial;return[hooks[i],v=>{hooks[i]=typeof v==='function'?v(hooks[i]):v;}];};React.useRef=()=>({current:null});React.useEffect=()=>{};
 let all=render();all.find(n=>n.type?.name==='LongTextEditor').props.onChange('Necesita **preparación**');all=render();all.find(n=>n.props?.['aria-label']==='Idea status').props.onChange('deciding');all=render();all.find(n=>n.type?.name==='IdeaLinkedChoices'&&n.props.title==='Related entries').props.onChange(['deleted']);all=render();
 all.find(n=>n.type==='form').props.onSubmit({preventDefault(){}});assert.equal(committed[0].description,'Necesita **preparación**');assert.equal(committed[0].status,'deciding');assert.deepEqual(committed[0].entryIds,['deleted']);assert.equal(closed,1);assert.equal(updated.worldIdeas[0].description,'¿Qué coste tiene?');
 // A new editor instance starts clean; cancelling it must not ask to discard.
 hooks=[];all=render();all.find(n=>n.type==='button'&&n.props.children==='Cancel').props.onClick();assert.equal(closed,2);assert.equal(committed.length,1);
}finally{Object.assign(React,saved);}
setLanguage('es');const html=renderToStaticMarkup(createElement(Editor,props));assert.ok(html.includes('Idea o decisión'));assert.ok(html.includes('Estado de la idea'));assert.ok(html.includes('Guardar idea'));setLanguage('en');
const rich=saveWorldIdea(project,{...idea,description:'Necesita **preparación** y _tiempo_.\n\n- Una prueba\n- Otra prueba'});
assert.equal(filterPendingItems(projectPendingItems(rich),'idea','','Necesita preparación').length,1);
const Pending=loadLocal('../src/ProjectPending.tsx').default;
const N=loadLocal('../src/workspaceNavigation.ts');N.activateWorkspaceMemory({values:{'pending.section':'ideas'}});
const formatted=renderToStaticMarkup(createElement(Pending,{project:rich,onOpen(){},onResolveComment(){},onResolveMention(){}}));
N.activateWorkspaceMemory(undefined);assert.ok(formatted.includes('<strong>'));assert.ok(formatted.includes('<em>'));assert.ok(formatted.includes('<ul>'));assert.ok(!formatted.includes('**preparación**'));
console.log('World ideas: immutable creation/editing, related/deleted entries, active/archive filters, search, editor submit/cancel, statuses and Spanish passed.');

const {relatedIdeas}=loadLocal('../src/worldIdeas.ts');
const narrativeProject={...project,chapters:[{id:'c1',title:'First',scenes:[{id:'s1',title:'Arrival',content:'A story.',synopsis:'Done',writingStatus:'finished'}]},{id:'c2',title:'Second',scenes:[{id:'s2',title:'Departure',content:'A story.',synopsis:'Done',writingStatus:'finished'}]}],plots:{schemaVersion:1,threads:[{id:'plot1',title:'The mystery',color:'teal',status:'planned',notes:'',beats:[{sceneId:'s2',note:''}]}]}};
const narrative=saveWorldIdea(narrativeProject,{...idea,category:'narrative',sceneIds:['s1','s1','deleted-scene'],plotIds:['plot1','plot1','deleted-plot']});
assert.deepEqual(narrative.worldIdeas[0].sceneIds,['s1','deleted-scene']);assert.deepEqual(narrative.worldIdeas[0].plotIds,['plot1','deleted-plot']);
const narrativeItems=projectPendingItems(narrative);assert.equal(narrativeItems.filter(i=>i.kind==='narrative').length,1);assert.equal(filterPendingItems(narrativeItems,'idea','','').length,0);assert.equal(filterPendingItems(narrativeItems,'narrative','c1','').length,1);assert.equal(filterPendingItems(narrativeItems,'narrative','c2','mystery').length,1);assert.ok(narrativeItems.some(i=>i.context.includes('Deleted scene')&&i.context.includes('Deleted plot')));
assert.equal(relatedIdeas(narrative.worldIdeas,'entry','entry').length,1);assert.equal(relatedIdeas(narrative.worldIdeas,'scene','s1').length,1);assert.equal(relatedIdeas(narrative.worldIdeas,'plot','plot1').length,1);assert.equal(relatedIdeas([{...narrative.worldIdeas[0],status:'discarded'}],'scene','s1').length,0);assert.throws(()=>saveWorldIdea(project,{...idea,category:'wrong'}));
const Related=loadLocal('../src/RelatedIdeas.tsx').default;
const relatedHtml=renderToStaticMarkup(createElement(Related,{ideas:narrative.worldIdeas,kind:'scene',id:'s1',onOpen(){}}));assert.ok(relatedHtml.includes('El despertar'));assert.ok(relatedHtml.includes('Narrative ideas'));
const {IdeaLinkedChoices}=loadLocal('../src/WorldIdeaEditor.tsx');let chosen,openedLink;
try{
 React.useState=initial=>[initial,()=>{}];
 const tree=nodes(IdeaLinkedChoices({title:'Scenes',options:[{id:'s1',title:'Arrival'},{id:'s2',title:'Departure'}],selected:['s1','missing'],onChange:ids=>chosen=ids,missingLabel:'Deleted scene',onOpen:id=>openedLink=id,canOpen:true}));
 tree.find(n=>n.type==='button'&&n.props.children==='Save and open').props.onClick();assert.equal(openedLink,'s1');
 tree.find(n=>n.type==='input'&&n.props.type==='checkbox'&&!n.props.checked).props.onChange({target:{checked:true}});assert.deepEqual(chosen,['s1','missing','s2']);assert.ok(tree.some(n=>n.type==='span'&&n.props.children==='Deleted scene'));
}finally{Object.assign(React,saved);}
console.log('Narrative decisions: legacy categories, cross-chapter and plot filters, deleted destinations, deduplicated links, contextual backlinks, related selectors and navigation passed.');

let relatedDestination;
const contextButtons=nodes(Related({ideas:narrative.worldIdeas,kind:'plot',id:'plot1',onOpen:id=>relatedDestination=id}));contextButtons.find(n=>n.type==='button').props.onClick();assert.equal(relatedDestination,'idea');
assert.equal(Related({ideas:[{...narrative.worldIdeas[0],status:'incorporated'}],kind:'entry',id:'entry'}),null);
