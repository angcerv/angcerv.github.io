import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import ts from 'typescript';
const require = createRequire(import.meta.url), old = require.extensions['.ts'];
require.extensions['.ts'] = (module, filename) => module._compile(ts.transpileModule(readFileSync(filename, 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText, filename);
try {
  const { getSceneStatus, writingStatusLabels } = require('../src/model.ts');
  const { transferScene, moveScene } = require('../src/manuscript.ts');
  const project = JSON.parse(readFileSync(new URL('fixtures/manuscript-original.json', import.meta.url), 'utf8'));
  const scene = project.chapters[0].scenes[0];
  assert.equal(getSceneStatus({ ...scene, content: '' }), 'notStarted');
  assert.equal(getSceneStatus({ ...scene, content: 'Written text' }), 'draft');
  for (const status of Object.keys(writingStatusLabels)) {
    assert.equal(getSceneStatus({ ...scene, content: 'Edited text', writingStatus: status }), status);
  }
  const planned = structuredClone(project);
  planned.chapters[0].scenes[0].writingStatus = 'finished';
  const snapshot = JSON.stringify(planned);
  const moved = transferScene(planned, scene.id, planned.chapters[1].id);
  const transferred = moved.chapters[1].scenes.find(item => item.id === scene.id);
  assert.equal(transferred.writingStatus, 'finished');
  assert.equal(transferred.content, scene.content);
  const reordered = moveScene(moved, scene.id, -1);
  assert.equal(reordered.chapters.flatMap(chapter => chapter.scenes).find(item => item.id === scene.id).writingStatus, 'finished');
  assert.equal(JSON.stringify(planned), snapshot);
  console.log('Writing status: legacy defaults, explicit progress, text independence and immutable transfers/reordering passed.');
} finally { if (old) require.extensions['.ts'] = old; else delete require.extensions['.ts']; }
