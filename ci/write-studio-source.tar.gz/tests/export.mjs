import assert from 'node:assert/strict';
import { readFileSync } from 'node:fs';
import { createRequire } from 'node:module';
import { spawnSync } from 'node:child_process';
import ts from 'typescript';
const require = createRequire(import.meta.url), previous = require.extensions['.ts'];
require.extensions['.ts'] = (module, filename) => module._compile(ts.transpileModule(readFileSync(filename, 'utf8'), { compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS } }).outputText, filename);
try {
  const { exportManuscript } = require('../src/manuscriptExport.ts');
  const project = JSON.parse(readFileSync(new URL('fixtures/worldbuilding-project.json', import.meta.url), 'utf8'));
  project.title = 'Novel <&> 🌿';
  project.chapters = [
    { id: 'first', title: 'First chapter', scenes: [{ id: 's1', title: 'Arrival', content: 'Hello **bold** and _italic_ and **_both_**.  \nNext line\n\n\n\nUnicode 世界 🌿 & < >' }, { id: 's2', title: 'Empty scene', content: '' }] },
    { id: 'second', title: 'Second chapter', scenes: [{ id: 's3', title: 'Departure', content: 'Last scene' }] },
  ];
  project.chapters[0].synopsis = 'PRIVATE_CHAPTER_SYNOPSIS';
  project.chapters[0].scenes[0].synopsis = 'PRIVATE_SCENE_SYNOPSIS';
  project.chapters[0].scenes[0].writingStatus = 'inReview';
  project.timeline = { schemaVersion: 1, events: [{ id: 'event', title: 'PRIVATE_TIMELINE_EVENT', notes: '', dateLabel: '', sceneIds: [], entryIds: [] }] };
  const snapshot = JSON.stringify(project);
  const markdown = new TextDecoder().decode(exportManuscript(project, ['second','first'], 'md'));
  assert.ok(markdown.indexOf('First chapter') < markdown.indexOf('Second chapter'));
  assert.ok(markdown.includes('**bold** and _italic_ and **_both_**'));
  assert.ok(markdown.includes('  \nNext line'));
  assert.ok(!markdown.includes('worldbuilding'));
  assert.ok(!markdown.includes('PRIVATE_TIMELINE_EVENT'));
  assert.ok(!markdown.includes('PRIVATE_CHAPTER_SYNOPSIS'));
  assert.ok(!markdown.includes('PRIVATE_SCENE_SYNOPSIS'));
  assert.ok(!markdown.includes('inReview'));
  const selected = new TextDecoder().decode(exportManuscript(project, ['second'], 'md'));
  assert.ok(!selected.includes('First chapter')); assert.ok(selected.includes('Departure'));
  const untitled = new TextDecoder().decode(exportManuscript(project, ['first'], 'md', false));
  assert.ok(!untitled.includes('### Arrival')); assert.ok(untitled.includes('***'));
  assert.throws(() => exportManuscript(project, [], 'docx'), /Select at least/);
  const docx = exportManuscript(project, ['second','first'], 'docx');
  const check = spawnSync('python3', ['-c', `
import sys,io,base64,zipfile,xml.etree.ElementTree as E
z=zipfile.ZipFile(io.BytesIO(base64.b64decode(sys.stdin.read())))
assert z.testzip() is None
assert all(b'PRIVATE_TIMELINE_EVENT' not in z.read(name) for name in z.namelist())
assert all(b'inReview' not in z.read(name) for name in z.namelist())
assert all(b'PRIVATE_CHAPTER_SYNOPSIS' not in z.read(name) and b'PRIVATE_SCENE_SYNOPSIS' not in z.read(name) for name in z.namelist())
for name in z.namelist(): E.fromstring(z.read(name))
rels=E.fromstring(z.read('word/_rels/document.xml.rels'))
assert any(r.get('Target')=='styles.xml' for r in rels)
n={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main'}
d=E.fromstring(z.read('word/document.xml'))
texts=[p.text for p in d.findall('.//w:t',n)]
assert texts.index('First chapter') < texts.index('Second chapter')
assert 'Unicode 世界 🌿 & < >' in texts
assert len(d.findall('.//w:br',n))==1
assert len(d.findall('.//w:pageBreakBefore',n))==1
runs=d.findall('.//w:r',n)
assert any(r.find('w:rPr/w:b',n) is not None and r.find('w:rPr/w:i',n) is not None for r in runs)
assert any(len(p)==0 for p in d.findall('.//w:body/w:p',n)), 'Empty paragraphs survive'
assert b'Normal' in z.read('word/styles.xml')
print('DOCX ZIP checksums, XML parts, formatting, breaks, Unicode and chapter order passed.')
`], { input: Buffer.from(docx).toString('base64'), encoding: 'utf8' });
  assert.equal(check.status, 0, check.stderr); process.stdout.write(check.stdout);
  assert.equal(JSON.stringify(project), snapshot, 'Export leaves source project unchanged');
  console.log('Markdown selection, scene separators, formatting and non-mutating export passed.');
} finally { if (previous) require.extensions['.ts'] = previous; else delete require.extensions['.ts']; }
