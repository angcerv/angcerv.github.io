import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const {emptyDrawing,shapeEnd,moveDrawingObject,validDrawingShape,drawingSvg}=loadLocal('../src/mapDrawing.ts');
const circle=shapeEnd({x:.2,y:.2},{x:.6,y:.3},1600,1000,true);assert(Math.abs((circle.x-.2)*1600-(circle.y-.2)*1000)<1e-9);
const edge=shapeEnd({x:.9,y:.9},{x:1,y:1},1600,1000,true);assert(edge.x<=1&&edge.y<=1);assert(Math.abs((edge.x-.9)*1600-(edge.y-.9)*1000)<1e-9);
const negative=shapeEnd({x:.7,y:.7},{x:.1,y:.2},1600,1000,true);assert(negative.x>=0&&negative.y>=0);assert(Math.abs((.7-negative.x)*1600-(.7-negative.y)*1000)<1e-9);
const model={id:'line',kind:'line',x:.1,y:.2,endX:.6,endY:.7,size:.065,color:'#123456',lineWidth:.003};
const {resizeDrawingObject,duplicateDrawingObject,symbolArtwork,rotateDrawingObject,normalizeRotation}=loadLocal('../src/mapDrawing.ts');
const moved=moveDrawingObject(model,{x:1,y:1});assert.equal(moved.endX,1);assert.equal(moved.endY,1);assert(Math.abs((moved.endX-moved.x)-.5)<1e-9);assert.equal(model.x,.1);
assert(!validDrawingShape({...model,endX:model.x,endY:model.y}));assert(!validDrawingShape({...model,kind:'ellipse',endX:model.x}));
const bounded=duplicateDrawingObject({...model,x:.9,y:.9,endX:1,endY:1});assert(bounded.endX<=1&&bounded.endY<=1);assert(bounded.x<.9);assert.notEqual(bounded.id,model.id);
const minimum=resizeDrawingObject({id:'s',kind:'castle',x:.5,y:.5,size:.1},{x:.5,y:.5},'end',1600,1000);assert.equal(minimum.size,.005);
assert.equal(resizeDrawingObject(minimum,{x:1,y:1},'end',1600,1000).size,.25);
assert.equal(resizeDrawingObject(model,{x:model.x,y:model.y},'end',1600,1000),model,'Degenerate shapes are rejected');
assert.equal(normalizeRotation(-90),270);assert.equal(normalizeRotation(360),0);
const symbol={id:'rotation',kind:'spaceship',x:.5,y:.5,size:.1,rotation:0};
const snapped=rotateDrawingObject(symbol,{x:.7,y:.6},0,1600,1000,true);assert.equal(snapped.rotation%15,0);
const rotatedResize=resizeDrawingObject({...symbol,rotation:45},{x:.5+Math.SQRT2*.05,y:.5},'end',1600,1000);assert(Math.abs(rotatedResize.size-.1)<1e-9,'Resize uses the rotated local coordinate system');
assert(drawingSvg({width:1600,height:1000,strokes:[],objects:[{...symbol,rotation:90}]}).includes('rotate(90 800 500)'));
assert.equal(duplicateDrawingObject({...symbol,rotation:78}).rotation,78);
const {mapThemes}=loadLocal('../src/mapThemes.ts');
for(const theme of Object.values(mapThemes))for(const kind of theme.symbols){assert(symbolArtwork[kind]?.includes('<'));const svg=drawingSvg({width:1600,height:1000,strokes:[],objects:[{id:kind,kind,x:.5,y:.5,size:.1}]});assert(!svg.includes('undefined'));assert(svg.includes(`data-art-id="${kind}"`));}
const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect};
const Editor=loadLocal('../src/MapDrawingEditor.tsx').default;
let states=[],refs=[],si=0,ri=0,exported;
const map={id:'m',title:'Map',imageId:'i',markers:[],drawing:emptyDrawing()};
function nodes(n){if(n&&typeof n.type==='function'&&['DrawingColorPicker','DrawingToolRail'].includes(n.type.name))return nodes(n.type(n.props));return Array.isArray(n)?n.flatMap(nodes):n&&typeof n==='object'?[n,...nodes(n.props?.children)]:[];}
const node={getBoundingClientRect:()=>({left:0,top:0,width:800,height:500}),focus(){},setPointerCapture(){},hasPointerCapture:()=>true,releasePointerCapture(){}};
const event=(x,y,id='',shiftKey=false)=>({clientX:x,clientY:y,pointerId:1,button:0,isPrimary:true,shiftKey,currentTarget:node,target:{closest:()=>id?{getAttribute:()=>id}:null},preventDefault(){}});
try{
 React.useState=initial=>{const i=si++;if(!(i in states))states[i]=typeof initial==='function'?initial():initial;return[states[i],value=>states[i]=typeof value==='function'?value(states[i]):value];};React.useRef=initial=>{const i=ri++;return refs[i]??(refs[i]={current:initial});};React.useEffect=()=>{};
 function render(){si=0;ri=0;return nodes(Editor({map,path:'/book',projectId:'p',onCancel(){},onSave:value=>exported=value}));}
 render();states[3]='image';states[4]=true;refs[1].current=node;
 const canvas=()=>render().find(n=>n.props?.['aria-label']==='Map drawing canvas');
 const tool=name=>{if(['Line','Circle','Ellipse'].includes(name)){const back=render().find(n=>n.type==='button'&&n.props?.['aria-label']==='Lines and shapes');back?.props.onClick();}render().find(n=>n.type==='button'&&n.props?.['aria-label']===name).props.onClick();};
 function draw(name,start,end){tool(name);canvas().props.onPointerDown(event(...start));canvas().props.onPointerMove(event(...end));canvas().props.onPointerUp(event(...end));}
 render().find(n=>n.props?.id==='drawing-line-color').props.onChange({target:{value:'#e23866'}});
 render().find(n=>n.props?.id==='drawing-line-width').props.onChange({target:{value:'.007'}});
 draw('Line',[80,100],[480,300]);assert.equal(states[0].objects.length,1);let line=states[0].objects[0];assert.equal(line.color,'#e23866');assert.equal(line.lineWidth,.007);assert.equal(line.endX,.6);assert.equal(line.endY,.6);
 tool('Undo');assert.equal(states[0].objects.length,0);tool('Redo');assert.equal(states[0].objects[0].id,line.id);
 tool('Select and move');canvas().props.onPointerDown(event(80,100,line.id));canvas().props.onPointerMove(event(1000,1000,line.id));canvas().props.onPointerUp(event(1000,1000,line.id));line=states[0].objects[0];assert.equal(line.endX,1);assert.equal(line.endY,1);
 render().find(n=>n.props?.id==='drawing-shape-color').props.onChange({target:{value:'#11aacc'}});assert.equal(states[0].objects[0].color,'#11aacc');
 render().find(n=>n.props?.id==='art-x').props.onChange({target:{valueAsNumber:20}});assert(Math.abs(states[0].objects[0].endX-.7)<1e-9);
 draw('Ellipse',[100,100],[500,300]);const ellipse=states[0].objects[1];assert.equal(ellipse.kind,'ellipse');assert(Math.abs(ellipse.endX-ellipse.x)>Math.abs(ellipse.endY-ellipse.y));
 draw('Circle',[200,100],[400,200]);const round=states[0].objects[2];assert(Math.abs((round.endX-round.x)*1600-(round.endY-round.y)*1000)<1e-9);
 const count=states[0].objects.length,history=states[1].length;
 tool('Line');canvas().props.onPointerDown(event(200,200));canvas().props.onPointerUp(event(200,200));assert.equal(states[0].objects.length,count);assert.equal(states[1].length,history,'Clicks do not create zero-length shapes');
 tool('Ellipse');canvas().props.onPointerDown(event(200,200));canvas().props.onPointerMove(event(500,300));canvas().props.onPointerCancel(event(500,300));assert.equal(states[0].objects.length,count);
 render().find(n=>n.type==='button'&&n.props?.className==='primary-button').props.onClick();assert.equal(exported.objects.length,3);
 const svg=drawingSvg(exported,false);assert(svg.includes('<line ')&&svg.includes('<ellipse ')&&svg.includes('stroke="#11aacc"'));assert(!svg.includes('NaN'));
 // Creation defaults and selected-element edits are separate contexts.
 render().find(n=>n.props?.id==='drawing-fill-enabled').props.onChange({target:{checked:true}});
 const pick=(label,colorName)=>{const tree=render(),inspector=tree.find(n=>n.type?.name==='DrawingSelectionInspector'),scope=nodes(inspector);const group=scope.find(n=>n.props?.role==='group'&&n.props?.['aria-label']===label)??tree.find(n=>n.props?.role==='group'&&n.props?.['aria-label']===label);nodes(group).find(n=>n.props?.['aria-label']===`Use ${colorName} color`).props.onClick();};
 pick('Fill color','Water');draw('Circle',[160,100],[280,180]);const filled=states[0].objects[3];assert.equal(filled.fill,'#b9d9df');
 render().find(n=>n.type==='button'&&n.props?.['aria-label']==='Select and move').props.onClick();canvas().props.onPointerDown(event(160,100,filled.id));canvas().props.onPointerUp(event(160,100,filled.id));
 assert(render().some(n=>n.type?.name==='DrawingOptionsPanel'));assert(render().some(n=>n.type?.name==='DrawingSelectionInspector'));
 assert.equal(render().filter(n=>n.props?.id==='drawing-shape-color').length,1);
 pick('Fill color','Land');assert.equal(states[0].objects[3].fill,'#d9d0a4');
 render().find(n=>n.props?.id==='drawing-shape-fill-enabled').props.onChange({target:{checked:false}});assert.equal(states[0].objects[3].fill,undefined);
 render().find(n=>n.props?.id==='drawing-shape-fill-enabled').props.onChange({target:{checked:true}});assert.equal(states[0].objects[3].fill,'#d9d0a4');
 render().find(n=>n.type==='button'&&n.props?.['aria-label']==='Lines and shapes').props.onClick();tool('Circle');assert.equal(render().find(n=>n.props?.id==='drawing-fill-color').props.value,'#b9d9df','Selected edits do not change creation fill defaults');
 // Change the active solid terrain color, then reuse its exact value in a filled figure.
 render().find(n=>n.props?.['aria-label']==='Terrain').props.onClick();
 render().find(n=>n.type==='button'&&n.props.children==='Solid color').props.onClick();
 render().find(n=>n.type==='button'&&n.props.children?.some?.(child=>child==='Land')).props.onClick();
 render().find(n=>n.props?.id==='drawing-terrain-color').props.onChange({target:{value:'#112233'}});assert.equal(states[0].terrainColors,undefined,'Tool color changes stay local until paint commits');
 canvas().props.onPointerDown(event(30,30));canvas().props.onPointerCancel(event(30,30));assert.equal(states[0].terrainColors,undefined);
 canvas().props.onPointerDown(event(30,30));canvas().props.onPointerMove(event(60,60));canvas().props.onPointerUp(event(60,60));assert.equal(states[0].strokes[0].color,'#112233');
 tool('Ellipse');pick('Fill color','Land');draw('Ellipse',[400,100],[600,300]);assert.equal(states[0].objects[4].fill,'#112233');
 render().find(n=>n.type==='button'&&n.props?.className==='primary-button').props.onClick();assert.equal(exported.terrainColors.land,'#112233');assert(drawingSvg(exported,false).includes('fill="#112233"'));

 // Real editor gestures respect the active drawing layer; undo includes layer edits.
 const layersPanel=()=>render().find(n=>typeof n.type==='function'&&n.type.name==='DrawingLayersPanel');
 layersPanel().props.onChange([{id:'terrain',title:'Terrain',visible:true}]);layersPanel().props.onActive('terrain');
 draw('Line',[80,80],[200,200]);assert.equal(states[0].objects.at(-1).layerId,'terrain');
 const beforeLock=states[0].objects.length;
 layersPanel().props.onChange([{id:'terrain',title:'Terrain',visible:true,locked:true}]);
 draw('Line',[300,80],[500,200]);assert.equal(states[0].objects.length,beforeLock,'Locked active layers reject drawing gestures');
 tool('Undo');assert.equal(states[14][0].locked,undefined,'Undo restores the layer properties alongside artwork');
 tool('Redo');assert.equal(states[14][0].locked,true);
 tool('Undo');layersPanel().props.onMoveTerrain('terrain');assert.equal(states[0].strokes[0].layerId,'terrain');
 assert.equal(map.drawing.strokes.length,0,'Unapplied layer edits leave the original map untouched');
 const beforeOrder=[...states[14],{id:'labels',title:'Labels',visible:true}];layersPanel().props.onChange(beforeOrder);
 layersPanel().props.onChange([...beforeOrder].reverse());assert.equal(states[14][0].id,'labels');
 tool('Undo');assert.equal(states[14][0].id,'terrain');tool('Redo');assert.equal(states[14][0].id,'labels');

 // Resize through the real canvas handlers, duplicate, cancel and undo.
 const resizeEvent=(x,y,id,handle)=>({...event(x,y,id),target:{getAttribute:name=>name==='data-resize-handle'?handle:null,closest:()=>({getAttribute:()=>id})}});
 tool('castle');canvas().props.onPointerDown(event(320,250));const castle=states[0].objects.at(-1);assert.equal(castle.kind,'castle');
 render().find(n=>n.type==='button'&&n.props?.['aria-label']==='Select and move').props.onClick();
 canvas().props.onPointerDown(event(320,250,castle.id));canvas().props.onPointerUp(event(320,250,castle.id));
 assert.equal(render().filter(n=>n.props?.['data-resize-handle']).length,4);
 const sizeBefore=states[0].objects.at(-1).size;
 canvas().props.onPointerDown(resizeEvent(350,280,castle.id,'end'));canvas().props.onPointerMove(resizeEvent(400,300,castle.id,'end'));canvas().props.onPointerUp(resizeEvent(400,300,castle.id,'end'));
 assert(Math.abs(states[0].objects.at(-1).size-.2)<1e-9);assert.equal(states[0].objects.at(-1).x,castle.x);
 const duplicateButton=()=>render().find(n=>n.type==='button'&&n.props?.['aria-label']==='Duplicate element');
 duplicateButton().props.onClick();const copy=states[0].objects.at(-1);assert.notEqual(copy.id,castle.id);assert.equal(copy.kind,'castle');assert(Math.abs(copy.size-.2)<1e-9);assert.equal(copy.layerId,castle.layerId);assert.notEqual(copy.x,castle.x);
 canvas().props.onPointerDown(resizeEvent(400,300,copy.id,'end'));canvas().props.onPointerMove(resizeEvent(600,350,copy.id,'end'));canvas().props.onPointerCancel(resizeEvent(600,350,copy.id,'end'));assert(Math.abs(states[0].objects.at(-1).size-.2)<1e-9);
 tool('Undo');assert.equal(states[0].objects.at(-1).id,castle.id);tool('Undo');assert.equal(states[0].objects.at(-1).size,sizeBefore);tool('Redo');assert(Math.abs(states[0].objects.at(-1).size-.2)<1e-9);
 // Endpoint handles resize shapes without moving the other endpoint.
 draw('Line',[80,100],[400,300]);const resizedLine=states[0].objects.at(-1);
 render().find(n=>n.type==='button'&&n.props?.['aria-label']==='Select and move').props.onClick();canvas().props.onPointerDown(event(80,100,resizedLine.id));canvas().props.onPointerUp(event(80,100,resizedLine.id));
 assert.equal(render().filter(n=>n.props?.['data-resize-handle']).length,2);
 canvas().props.onPointerDown(resizeEvent(400,300,resizedLine.id,'end'));canvas().props.onPointerUp(resizeEvent(600,400,resizedLine.id,'end'));assert.equal(states[0].objects.at(-1).endX,.75);assert.equal(states[0].objects.at(-1).x,.1);
 duplicateButton().props.onClick();assert(Math.abs((states[0].objects.at(-1).endX-states[0].objects.at(-1).x)-.65)<1e-9);

 // Rotate a symbol with the actual pointer handlers and numeric input.
 canvas().props.onPointerDown(event(320,250,castle.id));canvas().props.onPointerUp(event(320,250,castle.id));
 assert(render().find(n=>n.props?.['data-rotate-handle']==='true'));
 const rotationEvent=(x,y)=>({...event(x,y,castle.id),target:{getAttribute:name=>name==='data-rotate-handle'?'true':null,closest:()=>({getAttribute:()=>castle.id})}});
 canvas().props.onPointerDown(rotationEvent(320,200));canvas().props.onPointerMove(rotationEvent(400,250));canvas().props.onPointerUp(rotationEvent(400,250));
 assert.equal(states[0].objects.find(o=>o.id===castle.id).rotation,90);
 tool('Undo');assert.equal(states[0].objects.find(o=>o.id===castle.id).rotation,undefined);tool('Redo');assert.equal(states[0].objects.find(o=>o.id===castle.id).rotation,90);
 canvas().props.onPointerDown(event(320,250,castle.id));canvas().props.onPointerUp(event(320,250,castle.id));
 render().find(n=>n.props?.id==='drawing-object-rotation').props.onChange({target:{valueAsNumber:135}});assert.equal(states[0].objects.find(o=>o.id===castle.id).rotation,135);
 canvas().props.onPointerDown(rotationEvent(400,250));canvas().props.onPointerMove(rotationEvent(320,200));canvas().props.onPointerCancel(rotationEvent(320,200));assert.equal(states[0].objects.find(o=>o.id===castle.id).rotation,135);
 duplicateButton().props.onClick();assert.equal(states[0].objects.at(-1).rotation,135);
 // Labels and shapes remain unrotated and have no rotation control.
 canvas().props.onPointerDown(event(80,100,resizedLine.id));canvas().props.onPointerUp(event(80,100,resizedLine.id));assert(!render().some(n=>n.props?.id==='drawing-object-rotation'||n.props?.['data-rotate-handle']));

}finally{Object.assign(React,old);}
console.log('Map shapes: real line/ellipse/circle gestures, proportions, clamping, color/width editing, movement, undo/redo, zero-size/cancel handling, contextual controls, terrain palette reuse, solid/transparent fills, resize/duplicate gestures, layer preservation, cancellation, undo/redo and expanded theme SVG export passed.');
