import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {createElement} from 'react';
import {renderToStaticMarkup} from 'react-dom/server';
import {loadLocal} from './load-local.mjs';
const Index=loadLocal('../src/SectionIndex.tsx').default,Dialog=loadLocal('../src/StoryCalendarDialog.tsx').default,C=loadLocal('../src/storyCalendar.ts');
const nodes=node=>Array.isArray(node)?node.flatMap(nodes):node&&typeof node==='object'?[node,...nodes(node.props?.children)]:[];
let selected;let index=Index({sections:[{id:'test',title:'Heading'}],active:'test',onSelect:id=>selected=id,label:'Sections'});
const button=nodes(index).find(node=>node.type==='button');assert.equal(button.props.type,'button');assert.equal(button.props['aria-current'],'location');assert.equal(button.props['aria-controls'],'test');button.props.onClick();assert.equal(selected,'test');assert.equal(Index({sections:[],active:'',onSelect(){},label:'Sections',hidden:true}).props.inert,true);
const require=createRequire(import.meta.url),React=require('react'),old={useState:React.useState,useRef:React.useRef};let state=[],cursor=0,refs=[],refCursor=0;
try{
 React.useState=initial=>{const i=cursor++;if(!(i in state))state[i]=typeof initial==='function'?initial():initial;return [state[i],value=>state[i]=typeof value==='function'?value(state[i]):value];};
 React.useRef=value=>{const i=refCursor++;return refs[i]??(refs[i]={current:value});};
 let saved;const initial=C.defaultStoryCalendar(),before=JSON.stringify(initial);
 const render=()=>{cursor=0;refCursor=0;return nodes(Dialog({initial,onSave:value=>saved=value,onClose(){}}));};
 let tree=render(),nav=tree.find(node=>node.type===Index);assert.equal(nav.props.sections.length,8);assert.equal(nav.props.active,'calendar-general');
 const recurrence=tree.find(node=>typeof node.type==='function'&&node.type.name==='CalendarRecurrences');
 const expand=node=>Array.isArray(node)?node.flatMap(expand):node&&typeof node==='object'?node.type===recurrence.type?expand(node.type(node.props)):[node,...expand(node.props?.children)]:[];const ids=expand(tree[0]).filter(node=>node.type==='section').map(node=>node.props.id);assert.deepEqual(nav.props.sections.map(section=>section.id),ids);
 let scroll;const root={scrollTop:100,clientHeight:200,scrollHeight:2000,getBoundingClientRect:()=>({top:20}),querySelector:selector=>selector==='#calendar-holidays'?{getBoundingClientRect:()=>({top:520})}:null,scrollTo:options=>{scroll=options;}};
 refs[0].current=root;tree.find(node=>node.type==='input'&&node.props.value===initial.name).props.onChange({target:{value:'Retained draft'}});
 nav.props.onSelect('calendar-holidays');assert.deepEqual(scroll,{top:584,behavior:'instant'});tree=render();nav=tree.find(node=>node.type===Index);assert.equal(nav.props.active,'calendar-holidays');assert(tree.some(node=>node.type==='input'&&node.props.value==='Retained draft'));
 root.querySelectorAll=()=>[{id:'calendar-general',getBoundingClientRect:()=>({top:-100})},{id:'calendar-months',getBoundingClientRect:()=>({top:30})},{id:'calendar-conversion',getBoundingClientRect:()=>({top:400})}];tree.find(node=>node.props?.className==='story-calendar-content').props.onScroll();assert.equal(render().find(node=>node.type===Index).props.active,'calendar-months');
 root.scrollTop=1800;tree.find(node=>node.props?.className==='story-calendar-content').props.onScroll();assert.equal(render().find(node=>node.type===Index).props.active,'calendar-conversion');
 tree=render();tree.find(node=>node.type==='form').props.onSubmit({preventDefault(){}});assert.equal(saved.name,'Retained draft');assert.equal(JSON.stringify(initial),before);
}finally{Object.assign(React,old);}
const markup=renderToStaticMarkup(createElement(Dialog,{onSave(){},onClose(){}}));assert(markup.includes('aria-label="Calendar sections"'));assert(markup.includes('story-calendar-index'));assert(markup.includes('calendar-seasons'));assert(markup.includes('calendar-holidays'));
console.log('Calendar index: all eight targets, shared accessible controls, non-submitting navigation, independent scrolling/active tracking, last-section selection and retained drafts passed without UI.');
