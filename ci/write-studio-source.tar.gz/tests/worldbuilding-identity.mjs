import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {loadLocal} from './load-local.mjs';
const require=createRequire(import.meta.url),React=require('react');
const Editor=loadLocal('../src/WorldbuildingEditor.tsx').default;
const saved={useState:React.useState,useRef:React.useRef,useEffect:React.useEffect,useLayoutEffect:React.useLayoutEffect};
// Inspect the actual component tree, including keys that server-rendered HTML omits.
React.useState=initial=>[typeof initial==='function'?initial():initial,()=>{}];React.useRef=value=>({current:value});React.useEffect=()=>{};React.useLayoutEffect=()=>{};
const world={schemaVersion:1,templates:[{schemaVersion:1,id:'people',title:'People',fields:[]},{schemaVersion:1,id:'places',title:'Places',fields:[]}],entries:[{schemaVersion:1,id:'isabel',title:'Isabel',templateId:'people',archived:false,values:{}},{schemaVersion:1,id:'harbor',title:'Harbor',templateId:'places',archived:false,values:{}}]};
const original=JSON.stringify(world);
function check(node,found=[]){
 if(Array.isArray(node)){
  const keys=new Set();for(const child of node)if(child&&typeof child==='object'&&child.key!=null){assert.ok(!keys.has(child.key),`Duplicate sibling key: ${child.key}`);keys.add(child.key);}
  for(const child of node)check(child,found);return found;
 }
 if(!node||typeof node!=='object')return found;
 found.push(node);check(node.props?.children,found);return found;
}
try{
 for(let pass=0;pass<10;pass++)for(const entryId of ['isabel','harbor'])for(const tab of ['entries','templates','entries']){
  const tree=Editor({world,entryId,tab,setTab:()=>{},setEntryId:()=>{},onChange:()=>{},onReturn:()=>{}}),nodes=check(tree);
  const images=nodes.filter(node=>typeof node.type==='function'&&node.type.name==='EntryGallery');
  assert.equal(images.length,tab==='entries'?1:0);
  if(tab==='entries'){
   assert.equal(images[0].key,`gallery-${entryId}`);
   assert.equal(nodes.find(node=>node.props?.className==='world-entry-detail').key,`entry-${entryId}`);
   assert.notEqual(images[0].key,nodes.find(node=>typeof node.type==='function'&&node.type.name==='EntryFields').key);
  }else assert.equal(nodes.find(node=>node.props?.className==='world-template-detail').key,'template-people');
 }
 assert.equal(JSON.stringify(world),original);
}finally{Object.assign(React,saved);}
console.log('Worldbuilding identity: unique sibling keys, distinct entry/template subtrees and one image editor per entry (none in templates) passed.');
