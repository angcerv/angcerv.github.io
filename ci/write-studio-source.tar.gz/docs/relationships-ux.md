# Relationship workspace UI

The workspace retains its existing SVG renderer, deterministic layout helpers,
shared dropdown and action menu, and project relationship schema. No graph library,
dependency, data migration, or name-based relationship classification is introduced.

## Controls and navigation

Relationship dropdowns opt into `density="relationship"`. The trigger and its
portalled menu receive the same typography tokens; other controls keep their
existing styling. Large option sets enable search automatically. Full option
names remain accessible through the selected value, option text, and titles.
The existing keyboard, popup placement, and focus handling are reused.

The network entry control filters a neighbourhood, not a camera destination.
Template/type/plot/archive filters apply before neighbourhood expansion. Only
links with both endpoints visible are drawn. Counts expose visible and total
records, and active filter chips can be cleared individually.

Reading is explicitly labelled as opening the entry encyclopedia while viewing
relationships. The entry editing/reading control remains separate from graph
navigation.

## Camera, selection, and saved views

Network positions are materialized and retained across filtering and entry edits.
Fitting, centering, and resetting layout are separate explicit actions. Opening
selection details overlays the canvas instead of resizing its coordinate system.
A selected point may receive a minimal pan to keep it outside the overlay; zoom
and node positions remain unchanged. Narrow workspaces use a bottom details panel.
Both graph views also expose an equivalent keyboard-operable entry/connection list.

Saved view updates remain explicit. Renaming only changes the stored name, even
when the current exploration has different filters or positions. Switching away
from modified saved views or temporary explorations requires confirmation. View
removal never removes connections.

## Genealogy

Generations use explicit parent roles. Disconnected components receive separate
layout regions, and a common entry retains its position when changing the focus
or generation depth. Names never determine component membership or ordering.
Direct sibling, partner, guardian, and step-parent connections retain their existing
meaning. Shared-parent siblings remain derived, never stored as duplicate links.
Isolated eligible entries can be revealed through the options panel.

Unknown lineage is a missing biological/adoptive classification, not an unknown
relationship type. It is described in the legend, accessible edge text, and
connection inspector rather than repeated on every unselected connector. Cyclic
input produces a review warning while retaining entries and connections.

## Forms and data safety

Types expose both naming modes, role previews, genealogy configuration, and actual
per-side template restrictions. Existing usage and proposed incompatibilities are
counted separately. Changing restrictions retains existing connections for review.
Dirty type and connection dialogs guard closing, Cancel, and Escape. Destructive
operations name their scope: unlink entries, delete a type, or delete a view.
Connection dates describe start/end explicitly; a missing end is not labelled as
the present day.

Behavior tests are in `tests/relationship-ux.mjs` and the existing relationship,
genealogy, transfer, and World suites. Browser-computed styles and visual layout
still require an authorized interactive browser; automated tests do not substitute
for that visual check.

## Historical date queries

Both views expose an independent story-date query and an option to include ended
connections. Dates use the existing proleptic Gregorian story calendar, including
year zero, negative years, and year/month precision.

Each partial date is an inclusive earliest/latest range. A connection is definitely
future when its earliest start is later than the entire query range, and definitely
ended when its latest end precedes the query range. It is definitely active only
when both bounds establish coverage of the entire query range. Otherwise its
validity remains uncertain. Missing bounds never imply an infinite interval or
the present day. Uncertain connections stay visible; future connections are hidden.
Ended connections are optional and use a dashed historical style.

Historical queries only filter the rendered graph. The original relation collection
continues to supply editing and creation dialogs so a filtered edit cannot erase
hidden connections. Sibling derivation uses the filtered parent connections, and
genealogical positions are retained from the unfiltered layout. Returning to all
relationships removes only the date query; other explicitly chosen filters remain.

Network saved views persist settings.at and settings.showEnded with relationship
schema version 7. Existing projects need no eager migration; old views have no date
query and keep their prior interpretation. No connection dates or roles are rewritten.
Genealogy date queries remain transient, matching its existing view settings.
