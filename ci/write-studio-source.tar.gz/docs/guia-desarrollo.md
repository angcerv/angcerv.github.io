# Guía del código de Write Studio

Guía para localizar responsabilidades y ampliar el proyecto siguiendo sus patrones actuales. Las rutas parten de la raíz del repositorio. Consultar también [AGENTS.md](../AGENTS.md) para las instrucciones de trabajo y [README.md](../README.md) para instalación, formato de proyecto y protocolos de guardado. Esta guía describe la organización actual; no propone reorganizar el código.

## 1. Por dónde empezar

| Necesidad | Punto de entrada |
| --- | --- |
| Arranque de React | `src/main.tsx`, que importa `src/App.tsx` |
| Composición de espacios, proyecto activo, coordinación del editor y operaciones globales | `src/App.tsx` |
| Tipos principales de proyecto, capítulos y escenas; conversión Markdown | `src/model.ts` |
| Coordinación del guardado y recuperación | `src/useProjectPersistence.ts`: estado de operación/bloqueo, guardado manual, intervalo automático y cola de recuperación. `App.tsx` conserva navegación y decisiones de restauración. |
| Llamadas frontend a operaciones nativas | `src/storage.ts`; recuperación en `src/recovery.ts` |
| Comandos Tauri y registro de comandos | `src-tauri/src/lib.rs` |
| Lectura, validación y escritura del proyecto | `src-tauri/src/storage.rs` y módulos Rust de cada dominio |
| Navegación entre espacios y restauración del contexto | `src/workspaceStructure.ts`, `src/useWorkspaceNavigation.ts`, `src/workspaceNavigation.ts`, `src/useWorkspaceState.ts` |
| Componentes y estilos comunes | `src/styles/controls.css`, `src/Dropdown.tsx`, `src/ActionMenu.tsx`, `src/ProjectModal.tsx` |
| Traducciones | `src/i18n.ts`, `src/locales/es.json` |
| Comandos de comprobación | `package.json`, `src-tauri/Cargo.toml`, `tests/` |

El punto de entrada usa `App.tsx`, no `App 2.tsx`. Existen archivos con el sufijo ` 2` en `src/`; no tomarlos como implementación activa por su nombre ni mantener dos versiones de una funcionalidad. Seguir las importaciones reales.

### Estilo de interfaz compartido

La paleta de marca y los temas claro/oscuro viven en `App.css`. `styles/controls.css` concentra tipografía de interfaz, espaciado, radios, alturas, sombras, movimiento y variantes de acciones. Los módulos consumen `--ui-*` y conservan estructura, dimensiones de trabajo y estados del dominio; no redeclaran la paleta de botones primarios o destructivos. `ui-workspace-heading` unifica la jerarquía de las cabeceras. Las acciones secundarias con texto reutilizan `quick-action quick-action-text`.

Los selectores y sus paneles usan `Dropdown`; los menús, `ActionMenu`. Formularios y diálogos conservan sus componentes actuales, navegación por teclado y foco. Los párrafos vacíos breves usan `ui-empty-state-compact`; los errores visibles conservan `prompt-error`. Los controles táctiles y los campos de entrada se amplían mediante las variables y reglas de puntero grueso, incluidos los paneles en portales. El manuscrito, los artículos de lectura, los colores semánticos y las coordenadas de lienzos mantienen sus reglas propias.

## 2. Capas y flujo de una modificación

El flujo habitual de contenido es:

```text
Componente React → función del dominio / callback de actualización
                 → estado del proyecto coordinado por App
                 → guardado y reconciliación / recuperación
                 → invoke de Tauri → validación y persistencia Rust
```

- **UI (`.tsx`)**: presentación, interacción, foco y borradores locales. Actualiza los datos mediante los callbacks existentes; no escribe archivos directamente.
- **Dominio (`.ts`)**: tipos específicos, validación, transformaciones y cálculos reutilizables. Preferir funciones comprobables sin montar la interfaz. No duplicar una regla en dos pantallas.
- **Integración nativa**: usar los adaptadores existentes de `storage.ts` y `recovery.ts`. Hay llamadas directas a `invoke` en el código actual; antes de añadir otra, buscar si ya existe una operación equivalente.
- **Rust**: los comandos se exponen en `lib.rs`; el trabajo de almacenamiento, importación o exportación pertenece a su módulo de dominio. Validar de nuevo en esta frontera: TypeScript no valida datos externos en tiempo de ejecución.

El hook `useProjectPersistence` comparte su ref `state` y su bloqueo con las operaciones del shell para conservar una sola exclusión de I/O. Los bloqueos de autoguardado propios de pantallas llegan mediante un callback; el intervalo de 30 segundos depende de identidad/ruta/sesión, nunca de cada edición. Las pruebas del hook están en `tests/project-persistence.mjs`; `autosave.ts` conserva la reconciliación pura y `recovery.ts` la cola serializada.

### Guardado y preparación para alternar dispositivos

Revisión de código y pruebas locales: 1 de noviembre de 2026. No constituye una validación de iCloud ni de iPad.

- Guardado manual y automático conservan las ediciones recibidas durante la escritura; el manual también las protege si llegan mientras se elimina la recuperación anterior. Actualizan la revisión y mantienen pendientes las ediciones posteriores. El manual devuelve `false` si quedan cambios, para impedir que una continuación cierre o cambie el proyecto sin guardarlos.
- `storage.rs` escribe primero un diario completo, aplica archivos con reemplazo atómico y publica `project.json` al final. Al abrir, reproduce el diario pendiente. Las pruebas locales cubren interrupciones, archivos dañados/ausentes y rechazo de revisiones distintas.
- La comprobación de conflictos compara identidad y número de revisión; no es un protocolo entre dispositivos. Dos copias desconectadas pueden producir el mismo número con contenidos distintos. Cambios externos en escenas/fichas que no avanzan la revisión tampoco quedan protegidos por esa comprobación.
- El proyecto comprende varios archivos. Su publicación local no garantiza una entrega conjunta por un servicio de sincronización. Un diario recibido parcialmente puede reproducirse al abrir; el protocolo actual no acredita que ese diario pertenezca a la última versión remota. Los mutex de `lib.rs` solo serializan operaciones dentro de la instancia de la app.
- La recuperación de borradores se guarda en el directorio de datos de la aplicación (`read_draft`/`write_draft`), separada del proyecto. No debe darse por compartida entre dispositivos.

Antes de habilitar el flujo con iCloud: definir coordinación y detección de versiones divergentes, comprobar disponibilidad/descarga de todos los archivos y recursos, y resolver explícitamente los conflictos sin sobrescribir ninguna copia. Después, probar con copias desechables entregas parciales o desordenadas, trabajo sin conexión y dos dispositivos editando desde una misma revisión. No mover proyectos de trabajo para estas pruebas.

### Frontera nativa y adaptación a iPad

Revisión actualizada: 12 de noviembre de 2026. La entrada móvil está declarada en `lib.rs` mediante `tauri::mobile_entry_point`. Las comprobaciones de compilación no acreditan validación funcional en un iPad.

| Área | Código actual | Reutilización y adaptación pendiente |
| --- | --- | --- |
| Interfaz y dominio | React/Tiptap y módulos TypeScript | Candidatos a reutilizar; la usabilidad táctil y el comportamiento en WebKit requieren su propia validación. |
| Proyecto e historial | `storage.rs`, `worldbuilding.rs`, `history.rs` | Conservar formatos, validaciones y lógica de persistencia; proporcionar acceso válido a los archivos antes de ejecutar operaciones. No equivalen a coordinación con iCloud. |
| Selección de archivos/carpetas | `platform::FileDialog` en `lib.rs`; adaptador de escritorio `rfd` 0.15.4 en `platform.rs` | Escritorio usa `rfd`; iPad usa `ios_directory` para carpetas y el plugin de diálogo para importar copias. Los selectores generales de archivos/imágenes y destinos de exportación siguen pendientes en móvil. |
| Ubicación de proyectos | `settings.rs`, `recents.rs`, `storage.ts` | `ios_directory.rs` y `native/project_directory.m` conservan acceso mediante bookmarks y coordinan operaciones con proveedores. Las rutas recientes y la recuperación son locales a cada dispositivo; validar proveedores y conflictos en un iPad real. |
| Imágenes | `entryImages.ts`, `entry_images.rs` | Reutilizar IDs, validación PNG y almacenamiento; sustituir el selector. Probar decodificación, canvas y memoria en iPad. |
| Exportaciones e importaciones | `export.rs`, `entry_transfer.rs`, `template_transfer.rs`; adaptadores en `storage.ts` | Conservar generación/validación de contenido; adaptar cómo se elige y entrega el archivo. `App.tsx` usa los adaptadores, sin llamadas directas a `invoke`. |
| Copias de seguridad | `backup.rs` y comandos en `lib.rs` | Conservar ZIP, comprobación y restauración; adaptar selección del archivo/directorio y acceso durante toda la operación. |
| Papelera de proyectos | `project_deletion.rs`, dependencia `trash` | Aislar la integración de papelera del sistema; no sustituirla por borrado definitivo en móvil. Las papeleras internas de imágenes/mapas son otro mecanismo. |
| Ciclo de vida | `exit_app`, `CloseRequested`, `ExitRequested`, `request-exit`, `beforeunload` | Escritorio conserva su cierre guardado. `useProjectPersistence.ts` protege recuperación en `visibilitychange`/`pagehide` y revisa autoguardado al reanudar; probar suspensión real, ya que el sistema puede interrumpir I/O pendiente. |
| Compilación | Cargo, configuración Tauri y capacidades | CI comprueba macOS/Windows e iOS con `cargo check`, sin iniciar aplicaciones. La compilación para simulador no sustituye la instalación y prueba en dispositivo. |

Siguientes verificaciones: ejecutar el intercambio macOS/Windows de `.github/workflows/platform-compatibility.yml`; completar selectores generales y entrega de exportaciones en iPad; después validar instalación, abrir/editar/guardar, suspensión, pantalla dividida y proveedores externos cuando se autoricen pruebas de UI. Conservar el mismo formato y motor del proyecto. Los ZIP de CI contienen únicamente datos sintéticos y verifican también calendarios recurrentes, regiones y lienzos.

Fuentes técnicas: [plataformas admitidas por rfd 0.15.4](https://docs.rs/rfd/0.15.4/rfd/) y [plugins móviles de Tauri con Swift](https://v2.tauri.app/develop/plugins/develop-mobile/). Los adaptadores móviles restantes y la usabilidad en dispositivo siguen pendientes; estas fuentes no validan la app actual.

### Preparación de compilación iOS

La frontera de selectores vive ahora en `src-tauri/src/platform.rs`. Los comandos conservan sus contratos, filtros, cancelación y validación: escritorio delega en `rfd`, mientras móvil devuelve errores explícitos hasta incorporar sus selectores. `rfd` y `trash` se declaran solo para destinos de escritorio en Cargo; `project_deletion.rs` rechaza la papelera del sistema en móvil. Los callbacks de cierre/exit son exclusivos de escritorio. La protección al suspender vive en `useProjectPersistence.ts` y guarda la recuperación, sin sustituir la validación en dispositivo.

El proyecto Xcode está en `src-tauri/gen/apple/`, con soporte para familias iPhone/iPad y orientaciones de iPad. `project.yml` usa el script del repositorio `scripts/tauri.mjs` desde la raíz, en lugar del comando incompleto `node tauri` que produjo la inicialización. Regenerar el `.xcodeproj` con `xcodegen generate --spec project.yml` desde esa carpeta conserva esa corrección; repetir `ios init` puede sobrescribirla. Los binarios/builds quedan ignorados por su `.gitignore`.

Herramientas preparadas: destinos Rust `aarch64-apple-ios` y `aarch64-apple-ios-sim`, XcodeGen, libimobiledevice y CocoaPods. No se cambió el directorio global seleccionado por `xcode-select`. Para usar el Xcode instalado sin ese cambio, anteponer `/Applications/Xcode.app/Contents/Developer/usr/bin` al PATH y definir `DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer` al invocar el CLI.

La comprobación `cargo check --manifest-path src-tauri/Cargo.toml --lib --target aarch64-apple-ios-sim` pasa con ese `DEVELOPER_DIR`. Los 108 tests nativos de escritorio pasan (benchmark optativo ignorado). No se abrió Xcode, la app ni el simulador. Una compilación no valida UI ni acceso a documentos: abrir/crear proyectos desde el selector, importar imágenes, exportar y usar iCloud siguen pendientes en móvil. No se configuró cuenta, firma ni distribución.

Resultado de empaquetado: compilación Debug para dispositivo `aarch64` completada sin firma. Artefacto local (ignorado): `src-tauri/gen/apple/build/arm64/Write Studio.ipa`, 20.022.727 bytes. Inspección del ZIP/Info.plist: ejecutable presente, identificador `com.angy.writestudio`, familias `[1, 2]` (iPhone/iPad), mínimo iOS 15.0. No es una distribución instalable validada y no se ejecutó.

Comando que completó la compilación en este Mac:

```sh
PATH=/Applications/Xcode.app/Contents/Developer/usr/bin:$PATH DEVELOPER_DIR=/Applications/Xcode.app/Contents/Developer node scripts/tauri.mjs ios build --debug --target aarch64 --no-sign --ci
```

El intento equivalente para `aarch64-sim` sigue bloqueado: Tauri informa que falta el SDK de simulador 27.1 aunque `xcodebuild -showsdks` lo enumera; las alternativas de simulador que Xcode muestra son 27.0. No se instaló otro runtime ni se abrió Xcode para resolverlo. La comprobación Rust para simulador sí pasa.

Trabajo funcional tras la primera compilación: biblioteca local y protección adicional de recuperación implementadas en la sección siguiente; siguen pendientes selectores externos y validación en dispositivo de abrir/editar/guardar/reabrir. Después abordar documentos externos e iCloud. La firma para instalar en dispositivo y las pruebas de interfaz son pasos separados.

### Biblioteca local móvil y protección al ocultarse

En móvil, `read_settings` y `create_project` preparan `Documents/Projects` dentro del contenedor de la aplicación mediante `settings::ensure_local`. La ubicación se resuelve de nuevo en cada arranque; no se confía en la ruta absoluta conservada de un contenedor anterior. `localProjects` indica a la interfaz que la ubicación es administrada y no ofrece cambiarla con el selector de escritorio. No se activa iCloud ni acceso externo.

`list_local_projects` enumera los metadatos de esa biblioteca, sin abrir proyectos, reproducir diarios ni expirar papeleras. Omite enlaces/directorios ajenos, conserva visibles proyectos con índice dañado para que la apertura informe del problema y no depende del historial de recientes. `LocalProjectsDialog` reutiliza `ProjectModal` y la variante local de `RecentProjects` (sin fechas ni acciones de recientes). Elegir un proyecto pasa por la misma protección de cambios pendientes de `App.request`; el selector abierto bloquea autoguardado. Crear, guardar y abrir mantienen los formatos y validaciones existentes.

`useProjectPersistence` escucha `visibilitychange` y `pagehide` para volver a proteger la instantánea canónica pendiente en la cola de recuperación, sin escribir el proyecto ni reiniciar el intervalo de 30 segundos. Evita duplicar el aviso ocultar/pagehide y respeta operaciones bloqueadas y recuperaciones sin decidir. Al volver mediante visibilidad/pageshow reintenta el autoguardado con sus guardas existentes. Las ediciones continúan protegiéndose también desde `App.update`, sin esperar al evento de ocultación.

La escritura asíncrona al ocultarse es una protección adicional de mejor esfuerzo: no garantiza completar antes de que iOS suspenda o termine el proceso. No se solicita ejecución en segundo plano ni se implementa todavía un coordinador nativo de suspensión. Las pruebas del hook simulan los eventos sin iniciar UI; cubren deduplicación, último texto, bloqueo, ausencia de ruta, recuperación pendiente, reanudación y retirada de listeners. La biblioteca nativa se prueba con creación/reapertura, contenedor reubicado, índices dañados y enlaces; `tests/local-projects.mjs` comprueba las variantes compartidas mediante renderizado estático.

Comprobaciones de esta ampliación: build frontend, comprobación Rust para iOS, pruebas de biblioteca/configuración nativa, persistencia/recuperación, foco de diálogos, variantes locales y consultas de fichas. El IPA Debug para dispositivo se ha recompilado sin firma, sin abrir ni ejecutar la app.

Pendiente en iPad real: validar el ciclo crear/editar/guardar/cerrar/reabrir y la recuperación tras suspensión/terminación, firmar para instalación y revisar teclado/gestos. La biblioteca local no importa aún proyectos desde Mac o iCloud. Las rutas absolutas antiguas de recientes/borradores pueden requerir resolver de nuevo el destino si el contenedor cambia; el explorador local permite reencontrar los proyectos guardados.

### Adaptación táctil: primera revisión

Revisión de código: 1 de noviembre de 2026, sin abrir la interfaz. `FieldHelp` admite pulsación, foco y hover; `navigation.css` hace visibles las acciones laterales cuando no hay hover. `PanelResize` usa captura de puntero y cancelación, y los diálogos compartidos conservan Escape y restauración de foco.

`styles/controls.css` amplía a 44px los controles compartidos de cierre, acciones rápidas y desplegables/opciones con puntero principal grueso (`pointer:coarse`). Mantiene los tamaños compactos de escritorio, el ancho por contenido de las variantes y las opciones portalladas. Es una mejora inicial; no acredita que todos los controles específicos de cada herramienta tengan ese tamaño.

Pendiente de validación en iPad: distribución vertical/horizontal y ventanas estrechas (el body aún declara un mínimo de 480px), espacio visible con el teclado abierto, paneles y diálogos largos, menús posicionados con `window.innerHeight` en vez del viewport visual, áreas seguras, selección de texto en Tiptap y gestos táctiles/cancelación en mapas, genealogía y canvas. No ampliar indiscriminadamente controles dentro de gráficos ni cambiar sus coordenadas antes de comprobar esas interacciones. Las reglas responsive existentes son un punto de partida, no una verificación visual.

El hook `useWorkspaceNavigation` coordina historial Atrás/Adelante, memoria de sesión, captura de visitas y posiciones, atajos y restauración acotada en frames. `workspaceNavigation.ts` conserva las reglas de rutas/historial y las utilidades DOM; `App.tsx` aplica los IDs restaurados a sus selecciones y conserva los destinos contextuales de cada dominio. `panelReady` reanuda la restauración al terminar la carga diferida. Los frames pendientes se cancelan al reemplazar una restauración, cambiar de sesión o desmontar; los renders normales mantienen el pase de restauración en curso. Las pruebas del hook están en `tests/workspace-navigation-hook.mjs`, sin lanzar UI.

Mantener inmutables las instantáneas del proyecto. Un diálogo con edición por etapas guarda su borrador local y aplica una actualización al confirmar; cancelar no debe modificar contenido canónico. Los editores que ya actualizan en vivo deben conservar ese comportamiento.

## 3. Mapa por funcionalidad

En esta tabla los nombres sin directorio están dentro de `src/`, salvo las rutas Rust indicadas.

| Área / cambio | Pantallas y componentes | Lógica y persistencia relacionada |
| --- | --- | --- |
| Proyecto, bienvenida y ajustes | `App.tsx`, `WelcomeScreen.tsx`, `ProjectDialogs.tsx`, `RecentProjects.tsx`, `ProjectDeletionDialog.tsx` | `model.ts`, `storage.ts`; Rust: `storage.rs`, `settings.rs`, `recents.rs`, `project_deletion.rs` |
| Guardado, recuperación e historial | `SaveStatus.tsx`, `SaveProgressDialog.tsx`, `VersionHistory.tsx`, `SceneRecoveryActions.tsx`, `EntryHistoryDialog.tsx` | `useProjectPersistence.ts`, `autosave.ts`, `recovery.ts`, `sceneRecovery.ts`, `entryHistory.ts`; Rust: `storage.rs`, `history.rs`, `backup.rs` |
| Navegación principal | `PrimaryNavigation.tsx`, `PlanningNavigation.tsx`, `WorldNavigation.tsx` | `workspaceStructure.ts`, `useWorkspaceNavigation.ts`, `workspaceNavigation.ts`, `workspaceVisitLabel.ts`, `useWorkspaceState.ts` |
| Libros de una saga | `BookNavigation.tsx`, `BooksDialog.tsx` | `books.ts`, `model.ts`; Rust: `storage.rs` |
| Manuscrito y lectura de capítulos | `ChapterManuscript.tsx`, `ManuscriptActions.tsx`, `ManuscriptNavigation.tsx`, `ManuscriptTools.tsx`, editor Tiptap coordinado en `App.tsx` | `manuscript.ts`, `model.ts`, `manuscriptHistory.ts`, `chapterScroll.ts`; Rust: `storage.rs` |
| Planificación de capítulos y escenas | `ChapterPlanner.tsx`, `ChapterOverview.tsx`, `SceneBoard.tsx`, `SceneIntention.tsx`, `SceneContextPanel.tsx` | `chapterPlanning.ts`, `sceneContext.ts`, `books.ts` |
| Tramas y arcos | `PlotsEditor.tsx`, `PlotDevelopment.tsx`, `CharacterArcsEditor.tsx`, `ScenePlotsPanel.tsx`, `SceneArcsPanel.tsx` | `plotThreads.ts`, `characterArcs.ts`; Rust: `storage.rs` |
| Resumen, pendientes e ideas | `ProjectOverview.tsx`, `ProjectPending.tsx`, `WorldIdeaEditor.tsx`, `DecisionFragmentEditor.tsx` | `projectSummary.ts`, `pendingItems.ts`, `pendingSections.ts`, `worldIdeas.ts`, `decisionFragments.ts` |
| Lienzos de planificación | `IdeaCanvasEditor.tsx` | `ideaCanvas.ts`; Rust: `idea_canvas.rs` |
| Fichas, plantillas y campos | `WorldbuildingEditor.tsx`, `WorldPanel.tsx`, `TemplateFields.tsx`, `TemplateSectionsEditor.tsx`, `EntrySection.tsx` | `worldbuilding.ts`, `templateSections.ts`, `entryOrdering.ts`; Rust: `worldbuilding.rs` |
| Lectura enciclopédica | `LoreArticle.tsx`, `LoreContents.tsx`, `LoreOutline.tsx` | `worldLore.ts`; documentación: [world-lore.md](world-lore.md) |
| Estado editorial y canon | `EntryEditorialControl.tsx` | `entryEditorial.ts`, `semanticStatus.ts`, `styles/semantic-status.css` |
| Relaciones, red y genealogía | `EntryRelationsPanel.tsx`, `EntryConnectionDialog.tsx`, `RelationNetwork.tsx`, `Genealogy.tsx`, `FamilyLineages.tsx`, `RelationshipLibrary.tsx` | `entryRelations.ts`, `connectionDraft.ts`, `relationGraph.ts`, `graphGesture.ts`, `genealogyLayout.ts`, `genealogyFamilies.ts`, `genealogyRouting.ts`, `genealogyScene.ts`, `familyOverview.ts`, `partnership.ts`; Rust: `entry_relations.rs` |
| Filtros temporales de relaciones | `RelationshipTimeFilter.tsx`, `RelationshipTimeOptions.tsx`, `StoryDateInput.tsx` | `relationshipTime.ts`, `ages.ts` |
| Recursos visuales y papelera | `VisualLibrary.tsx`, `EntryImage.tsx`, `EntryTransferDialog.tsx` | `visualResources.ts`, `entryImages.ts`, `entryTransfer.ts`; Rust: `entry_images.rs`, `entry_transfer.rs`, `storage.rs` |
| Mapas geográficos | `MapsEditor.tsx`, `MapRegionsPanel.tsx`, `MapRegionsOverlay.tsx`, `MapRoutesPanel.tsx`, `MapLayersPanel.tsx`, `MapInspectorHeading.tsx` | `maps.ts`, `mapRegions.ts`, `mapNavigation.ts`, `mapElementHistory.ts`; Rust: `maps.rs` |
| Dibujo de mapas y materiales | `MapDrawingEditor.tsx`, `DrawingEditorPanels.tsx`, `DrawingLayersPanel.tsx`, `MapArtworkPreview.tsx` | `mapDrawing.ts`, `drawingEditorView.ts`, `mapDrawingPreview.ts`, `mapMaterials.ts`, `mapTerrain.ts`, `mapThemes.ts`, `mapRasterPreview.ts` |
| Escala, viajes y geografía del manuscrito | `MapScalePanel.tsx`, `MapCalibrationOverlay.tsx`, `ManuscriptRoutesPanel.tsx`, `RouteTravelReview.tsx` | `mapCalibration.ts`, `sceneGeography.ts`, `travelContinuity.ts` |
| Cronología y eventos | `TimelineEditor.tsx`, `TimelineDialogs.tsx`, `TimelineInspector.tsx`, `TimelineChart.tsx`, `TimelineEventList.tsx`, `TimelineRelations.tsx` | `timeline.ts`, `timelineWorkspace.ts`, `timelinePreferences.ts`, `timelineChartLayout.ts`; Rust: `timeline.rs` |
| Calendario ficticio | `StoryCalendarDialog.tsx`, `CalendarElementDialog.tsx`, `CalendarElementList.tsx`, `CalendarRecurrences.tsx`, `StoryCalendarView.tsx`, `CalendarDayInspector.tsx`, `CalendarDateConverter.tsx` | `storyCalendar.ts`, `calendarElementDraft.ts`, `calendarBrowse.ts`; Rust: `story_calendar.rs`; estilos: `styles/timeline.css` |
| Referencias y consulta contextual | `TextReferenceProvider.tsx`, `TextReferenceUI.tsx`, `SourceConsultation.tsx`, `EntryUsageSummary.tsx`, `EntryAppearances.tsx`, `TextReferenceBacklinks.tsx` | `textReferenceContext.ts`, `textReferenceIndex.ts`, `textReferenceTokens.ts`, `entryUsage.ts`, `entryAppearanceIndex.ts`, `sceneLinks.ts` |
| Menciones en el manuscrito | `MentionActionDialog.tsx`, `MentionChoiceDialog.tsx` | `mentionDetection.ts`, `manuscriptMentions.ts`, `entryMentionNode.ts`, `textReferenceIndex.ts` |
| Búsqueda y sustitución | `ProjectSearch.tsx`, `ManuscriptFindDialog.tsx` | `globalSearch.ts`, `manuscriptSearch.ts`, `manuscriptHistory.ts` |
| Comentarios y continuidad | `ReviewCommentDialog.tsx`, `ReviewCommentsPanel.tsx`, `ContinuityReview.tsx`, `ReviewFollowup.tsx` | `reviewComments.ts`, `continuity.ts`, `narrativeContinuity.ts`, `continuityContext.ts`, `reviewWorkflow.ts` |
| Exportaciones e intercambio | `ProjectExportDialog.tsx`, `ExportDialog.tsx`, `PlanningExportDialog.tsx`, `EncyclopediaExportDialog.tsx`, `TemplateExportPanel.tsx`, `TemplateImportDialog.tsx` | `projectExport.ts`, `manuscriptExport.ts`, `manuscriptExportPreferences.ts`, `planningExport.ts`, `encyclopediaExport.ts`, `encyclopediaExportJob.ts`, `encyclopediaWorkerClient.ts`, `templateTransfer.ts`, `entryTransfer.ts`; Rust: `export.rs`, `template_transfer.rs`, `entry_transfer.rs` |
| Objetivos de escritura | `WritingGoalsDialog.tsx` | `writingGoals.ts`; Rust: `writing_goals.rs` |

Para relaciones, consultar también [entry-relations.md](entry-relations.md), [relationships-ux.md](relationships-ux.md) y las reglas específicas de `AGENTS.md` antes de cambiar parentescos, rutas o cámaras.

## 4. Dónde crear código nuevo

La organización actual de `src/` es principalmente plana. Mantenerla para cambios acotados; no crear una arquitectura paralela para una sola función.

| Código nuevo | Ubicación y criterio |
| --- | --- |
| Componente de un dominio | `src/NombreDescriptivo.tsx`, junto a los componentes de esa área. Extraerlo si tiene una responsabilidad clara o se reutiliza. |
| Cálculo, validación o transformación | `src/nombreDelDominio.ts` o el módulo existente que ya posee esa regla. Evitar helpers genéricos sin un dueño claro. |
| Control reutilizable | Ampliar primero el componente compartido equivalente con una variante explícita. Crear uno nuevo solo si no existe equivalente. |
| Estilo específico | `src/styles/<area>.css`; comprobar antes los estilos existentes del componente. |
| Token o convención compartida | Tokens de `App.css` / `styles/controls.css`, según su responsabilidad. Documentar el cambio compartido en `AGENTS.md`. |
| Texto de interfaz | Clave inglesa utilizada por `t(...)` y traducción en `src/locales/es.json`. Usar `buttonLabel(...)` para etiquetas de acciones con puntos suspensivos. |
| Modelo persistente | Tipo del dominio en TypeScript y estructura/validación correspondiente en `src-tauri/src/`. Revisar también `model.ts` si cambia el proyecto principal. |
| Operación nativa | Función en el módulo Rust correspondiente, comando y registro en `lib.rs`, adaptador frontend existente o nuevo en `storage.ts`. |
| Prueba frontend sin UI | `tests/<area>.mjs`; añadirla a `npm test` en `package.json` si es una suite nueva. Reutilizar `tests/load-local.mjs` cuando corresponda. |
| Prueba nativa | Módulo `#[cfg(test)]` del archivo Rust correspondiente; reutilizar fixtures de `tests/fixtures/` cuando proceda. |
| Documentación técnica | `docs/`; enlazar desde esta guía o el README según el alcance. |

Evitar aumentar `App.tsx` con reglas de negocio: usarlo para conectar estado, navegación y callbacks. Si una misma regla aparece en dos pantallas, compartir el módulo de dominio o el componente que ya representa ese concepto.

## 5. Estado: contenido, borradores y preferencias

No son intercambiables:

- **Contenido canónico**: `Project` y sus dominios. Debe participar en guardado, recuperación e intercambios aplicables.
- **Borradores de edición**: estado local de diálogos o gestos, hasta su confirmación. No guardarlos en la memoria de navegación.
- **Estado de navegación**: rutas, IDs estables, filtros, selección y posiciones mediante `workspaceNavigation.ts` / `useWorkspaceState.ts`. Volver a una vista no debe restaurar contenido antiguo.
- **Preferencias de dispositivo**: módulos específicos como `worldBrowserPreferences.ts`, `worldSavedAccess.ts` y `manuscriptExportPreferences.ts`. Validar lo leído y respetar el ámbito por proyecto cuando exista. No almacenar texto del proyecto en `localStorage`.
- **Historial de edición de sesión**: `manuscriptHistory.ts` y `mapElementHistory.ts`, con sus límites e invalidación. No sustituye al historial persistente de `history.rs`.

Los espacios pesados usan `DeferredPanel.tsx`: conservar montados los ya visitados para mantener estado local y reanudar solicitudes pendientes con `onPanelReady`. Los que reciben `active` se desactivan una vez y omiten renders posteriores mientras siguen inactivos; al volver reciben las props actuales. Los inspectores y diálogos de esos espacios deben respetar `active`, y las mediciones de paneles ocultos deben ignorar tamaños cero. No convertirlos en importaciones iniciales sin evaluar el coste y `check:bundle`.

## 6. Interfaz y accesibilidad

Antes de modificar una pantalla, inspeccionar el componente, sus estilos y los controles equivalentes de otra pantalla relevante.

- **Selectores y menús**: `Dropdown.tsx` / `Dropdown.css` y `ActionMenu.tsx`. No introducir selectores nativos o menús duplicados donde ya existe un patrón compartido. Navegación por teclado en `menuNavigation.ts` y `dropdownNavigation.ts`.
- **Diálogos**: `ProjectModal.tsx` y, para relaciones, `RelationDialog.tsx`. Mantener título accesible, cierre, Escape, restauración del foco y protección durante operaciones. `dialogFocus.ts` prioriza destinos explícitos y campos editables; las consultas arrancan en un título neutro. El contenedor tiene foco visual neutro en `styles/controls.css`; los controles conservan sus indicadores.
- **Confirmaciones cortas**: variante `confirmation` de `ProjectModal`. No añadir confirmaciones innecesarias ni perder el borrador del panel anterior.
- **Ayuda**: `FieldHelp.tsx`; errores e instrucciones esenciales permanecen visibles. `SectionIndex.tsx` para índices de secciones.
- **Texto enriquecido y referencias**: reutilizar `LongTextEditor.tsx`, `ShortTextEditor.tsx`, `TextReferenceUI.tsx` y sus renderizadores. Mantener el subconjunto Markdown canónico y los rangos de comentarios/menciones.
- **Iconos y acciones**: `lucide-react`, `quick-action`, `icon-button`, `primary-button`, `danger-button`. Iconos solos para acciones claras, siempre con nombre accesible; etiquetas para las primarias, destructivas o ambiguas.
- **Tokens y tipografía**: paleta en `App.css`; medidas, fuente de controles, radios y foco en `styles/controls.css`. Estados semánticos en `semanticStatus.ts` / `styles/semantic-status.css`. La tipografía literaria es independiente de la interfaz.
- **Interacción**: conservar estados hover, pulsado, foco, deshabilitado, carga y error. Usar los patrones de movimiento existentes y respetar movimiento reducido. El contenido oculto debe quedar fuera del foco mediante `inert` / los mecanismos existentes.
- **Paneles y gestos**: `PanelResize.tsx` para divisores y `AreaResize`; `graphGesture.ts` para grafos. Mantener previews locales, cancelación y una confirmación por gesto. La selección ordinaria no debe recentrar cámaras.

`interactions.css`, `workspace.css`, `WorldPanel.css` y los estilos por área también participan en la cascada. Buscar reglas existentes antes de añadir overrides; una regla local no debe modificar por accidente todos los encabezados, SVG o controles de la aplicación.

## 7. Cambios persistentes: recorrido obligatorio

Un campo nuevo en TypeScript no basta para conservarlo en disco. Revisar:

1. Tipo y valores por defecto del dominio; compatibilidad con proyectos donde el campo no existe.
2. Creación del borrador, validación y aplicación de cambios; visualización y limpieza del campo.
3. Estructura Serde y validación Rust. Muchos modelos rechazan campos desconocidos con `deny_unknown_fields`.
4. Lectura/escritura, versiones de esquema y migraciones del dominio. No rebajar una versión nueva al editar otra parte del documento ni subirla sin un motivo de compatibilidad definido.
5. Recuperación, historial, copias de seguridad y paquetes/exportaciones que transportan ese contenido.
6. Pruebas de ida y vuelta y casos inválidos significativos.

Los IDs son estables y los nombres visibles no son rutas. Respetar los controles nativos de rutas, revisión y propiedad del proyecto. No sortear el protocolo de escritura de `storage.rs`: usa un journal y archivos pendientes, y no equivale a una transacción atómica de varios archivos. El README documenta las garantías y límites exactos.

Para escenas, plantillas, fichas e índice del mundo, `storage::atomic_if_changed` compara bytes reales antes de reemplazar el archivo. Incluso si coinciden, sincroniza archivo/directorio y limpia restos `.pending`. Mantener `atomic` para el journal y los metadatos de revisión; no sustituir esta comprobación por fechas, tamaños o una caché del estado del proyecto. Las pruebas específicas están en `src-tauri/src/storage_incremental_tests.rs`.

La verificación nativa de backups (`backup.rs`, `verify_project`) usa un `entry_images::ProjectImageReader` por lote de recursos: validar identidad una vez, pero mantener validación de cada original/miniatura y todas las referencias del historial. No reutilizar lectores entre proyectos u operaciones ni eliminar la comprobación de cambios del proyecto antes de publicar el ZIP.

Los recursos visuales son compartidos: desvincular una imagen no significa borrar su archivo. La limpieza debe respetar papelera, historial, recuperación, mapas, lienzos y copias referenciadas según las reglas existentes.

## 8. Ejemplos de cambios habituales

### Añadir un dato a las eras del calendario

Seguir `storyCalendar.ts` → `calendarElementDraft.ts` → `CalendarElementDialog.tsx` → `StoryCalendarDialog.tsx` / `CalendarElementList.tsx` → `src-tauri/src/story_calendar.rs`. Reutilizar etiquetas traducidas y estilos en `styles/timeline.css`. Comprobar calendarios antiguos, creación, edición, eliminación del valor y conservación en guardado/backup. Suites: `tests/calendar-element-dialog.mjs`, `tests/story-calendar.mjs` y pruebas Rust de `story_calendar`.

### Añadir una vista dentro de un espacio

Partir de su editor y navegación actuales. Si cambia la identidad de la ruta o la restauración, revisar `workspaceStructure.ts`, `workspaceNavigation.ts` y `useWorkspaceState.ts`. Conservar los cinco espacios principales y la separación del resumen de proyecto. Si la vista es pesada, integrarla con `deferPanel` y su estado de disponibilidad. No guardar una copia del proyecto como estado de navegación.

### Añadir un formato de exportación

Entrar por `ProjectExportDialog.tsx` y el exportador del dominio. Mantener modos embebidos, sin diálogos nativos anidados. Si escribe archivos, reutilizar las validaciones y protección de destinos de `src-tauri/src/export.rs`. Para enciclopedias, revisar además worker, cancelación, transporte de texto y preparación acotada de imágenes.

## 9. Cómo comprobar un cambio

Revisar los scripts antes de ejecutarlos. Según las instrucciones actuales, no generar imágenes ni abrir aplicaciones o navegadores para pruebas manuales o automatizadas sin petición explícita.

| Comando | Qué comprueba |
| --- | --- |
| `node tests/<area>.mjs` | Suite concreta del área sin lanzar UI; revisar su contenido antes. |
| `npm test` | Suites Node registradas en `package.json`. Algunas comprueban lógica y otras estructura/código de componentes; no equivalen a pruebas visuales. |
| `npm run build` | Tipado estricto TypeScript y compilación Vite. |
| `node scripts/benchmark-io.mjs 1000 --assets` | Recursos existentes sin modificar, mapas y ZIP con imágenes; mide importación y lectura validada además de backup/restauración. |
| `node scripts/benchmark-io.mjs 1000` | Guardado/apertura/backups nativos y preparación/escritura de exportaciones con datos sintéticos; ver [rendimiento.md](rendimiento.md). |
| `node scripts/benchmark-project.mjs 1000` | Medición sintética de lógica con 1.000 escenas; no mide UI, disco ni exportaciones. Informa primera ejecución y repeticiones; pueden intervenir cachés compartidas. |
| `npm run check:bundle` | Grafo y tamaño de chunks emitidos; requiere un build previo. |
| `cargo test --manifest-path src-tauri/Cargo.toml story_calendar::tests --lib` | Ejemplo de pruebas nativas focalizadas; sustituir el filtro por el módulo afectado. |
| `cargo test --manifest-path src-tauri/Cargo.toml` | Pruebas Rust del proyecto. |

`npm run dev`, `npm run tauri dev` y `npm run preview` son comandos de ejecución, no comprobaciones estáticas. Las instrucciones de aceptación nativa del README solo se ejecutan cuando están autorizadas.

Para una modificación, ejecutar las pruebas relevantes y el build; si cambia persistencia, añadir las pruebas nativas aplicables. No repetir suites ya correctas sin un cambio o duda nueva que lo justifique. Un cambio solo documental requiere revisar rutas, enlaces y coherencia; no necesita compilar la aplicación.

Antes de entregar, revisar archivos modificados, terminología, componentes y tokens compartidos. Indicar los cambios, comprobaciones realizadas y límites pendientes; no afirmar verificación visual si no se ha realizado.

Los benchmarks están en `scripts/benchmark-project.mjs` y `scripts/benchmark-io.mjs`. Los escenarios compartidos viven en `benchmark-fixture.mjs` y `benchmark-assets.mjs`, dentro de `scripts/`; el segundo reutiliza PNG existentes sin modificar píxeles. Su contraparte nativa es la prueba optativa `src-tauri/src/benchmark.rs`, excluida de la aplicación distribuida. Resultados y límites en [rendimiento.md](rendimiento.md).

## 10. Mantener esta guía

Actualizar la fila del dominio cuando se cambie su punto de entrada o se extraiga una responsabilidad compartida. Reservar `AGENTS.md` para instrucciones concisas y convenciones generales; usar `docs/` para explicaciones técnicas. Documentar el comportamiento final y sus límites, sin convertir excepciones aisladas en reglas globales.

### Importar una copia desde Archivos/iCloud en iPad

`restore_project_backup` tiene una ruta iOS que usa el selector de documentos de `tauri-plugin-dialog` (dependencia solo iOS), modo `FileAccessMode::Copy` y filtro ZIP. El proveedor puede ser iCloud Drive u otro disponible en Archivos. La selección se convierte de `FilePath` a ruta local y pasa al restaurador existente; este comprueba manifiesto, límites, rutas y recursos y publica en una carpeta local nueva. El destino lo fija `settings::ensure_local`, sin selector de carpetas ni sustitución de proyectos existentes. La ruta de escritorio se conserva.

Solo admite backups ZIP creados por Write Studio; comprimir una carpeta arbitrariamente no equivale al formato con manifiesto. La importación produce una copia local: no abre ni sincroniza una carpeta de proyecto de iCloud. El ZIP que iOS importa al contenedor queda disponible allí; no se elimina automáticamente una ruta entregada por el proveedor.

Comprobación Rust para iOS y pruebas nativas del restaurador realizadas sin abrir UI. Pendiente probar el selector, la descarga desde iCloud y la importación en iPad. Recompilar/reinstalar la app para incluir el nuevo plugin; la recarga del frontend por sí sola no lo incorpora. No se modifica la carpeta original en iCloud ni se configura CloudKit.

### Carpeta de biblioteca configurable en PC e iPad

La selección actual está en Ajustes → Carpeta predeterminada de proyectos → Cambiar. Sustituye la restricción de biblioteca local fija descrita en las primeras fases móviles. Cambiar de carpeta no mueve proyectos ni cambia la ruta del proyecto ya abierto. Abrir proyecto enumera las subcarpetas con `project.json` de la biblioteca seleccionada; en escritorio conserva «Elegir otra carpeta» para abrir un proyecto fuera de ella.

En iOS, `native/project_directory.m` presenta un `UIDocumentPickerViewController` de carpetas, conserva un bookmark autorizado y resuelve/renueva ese permiso al arrancar. Las autorizaciones usadas en la sesión se mantienen para no perder acceso al proyecto abierto al cambiar la biblioteca. Si se pierde el permiso, se pide seleccionar de nuevo en Ajustes; no se sustituye silenciosamente la carpeta elegida por la local. Sin selección externa, sigue disponible `Documents/Projects`. `Info.ios.plist` expone Documents en Archivos y declara apertura in-place.

`ios_directory.rs` encierra la apertura/guardado del proyecto en `NSFileCoordinator`, sin mantener un mutex de Rust mientras se muestra el selector. Comprueba archivos ubicuos antes de mutar: solicita descargas pendientes y devuelve un error visible para reintentar; rechaza conflictos que el proveedor expone y cambios de ruta durante el acceso coordinado. En iOS, una transacción antigua no se reproduce sobre una revisión más nueva; una transacción de la misma revisión con contenido divergente se rechaza.

`project_disk_guard.rs` conserva huellas de sesión de metadatos, escenas y mundo (sin retener texto) y comprueba cambios en disco antes de guardar proyectos externos, incluso sin cambio de número de revisión. No incluye bytes de imágenes ni historial; no es un protocolo de sincronización distribuida. Si pierde la evidencia por reinicio/expulsión, el guardado externo exige reabrir; conserva la recuperación. Una edición sin conexión y otra remota aún no recibida no pueden detectarse anticipadamente. Mantener un solo dispositivo editando y esperar a iCloud al alternar; la app lo indica en los ajustes de la carpeta externa.

Verificación sin UI: 110 tests nativos, más los 23 de almacenamiento tras el ajuste de lectura/recuperación; pruebas de biblioteca/controles/foco/persistencia y build frontend. Compilación y enlace de biblioteca Rust/Objective-C para `aarch64-apple-ios-sim` correctos, sin lanzar simulador ni app. Pendiente probar en iPad real: selección/cancelación, permiso tras reinicio, descarga de un proyecto desde iCloud, abrir/guardar/reabrir, revocación y alternancia de dispositivos. No se ha validado sincronización real ni edición simultánea.

Para probar: recompilar la parte nativa y reinstalar con Tauri/Xcode, seleccionar la carpeta contenedora de los proyectos (por ejemplo `iCloud Drive/WriteStudio`), y usar Abrir proyecto. Probar primero con una copia. No repetir `ios init`, que sobrescribiría ajustes del proyecto/iconos generados.

### Espera de descargas de iCloud durante la apertura

`storage.openProject` usa `projectOpen.ts`: consulta `prepare_project_open`, espera un segundo entre comprobaciones y continúa al estar listo. El límite de espera de descargas es de dos minutos; no es un límite para el trabajo de apertura posterior. No se mantiene el bloqueo de I/O nativo mientras espera. Si aparecen archivos pendientes entre comprobar y abrir, reintenta únicamente la señal conocida de descarga pendiente; permisos, conflictos y contenido dañado fallan sin bucle. El proyecto ya abierto y su recuperación no se sustituyen durante la espera.

El puente iOS comprueba también la propia carpeta, solicita su descarga antes de enumerarla y vuelve a comprobar los descendientes en cada consulta. No confunde una enumeración incompleta con disponibilidad cuando hay una descarga pendiente. El spinner muestra «Descargando proyecto desde iCloud…» y vuelve a «Abriendo proyecto…» al continuar. El error de apertura permite Cerrar o Reintentar con la misma ruta, pasando de nuevo por las guardas de cambios pendientes.

Pruebas sin UI: estados pendientes/listos, aparición de otro archivo pendiente al abrir, límite temporal con reloj simulado y fallos de permisos/contenido; fases y error reintentable del diálogo compartido. Build frontend y compilación/enlace nativo para iOS correctos. No se ha comprobado una descarga real de iCloud en el iPad; requiere recompilar/reinstalar y probar un proyecto no descargado. Las llamadas del proveedor de archivos pueden tener sus propios tiempos de respuesta, fuera del intervalo entre consultas.

### Retomar el proyecto móvil después de una recarga

Los eventos de ocultación no cierran el proyecto: si React sigue montado, conserva su estado. Una recarga de la webview o un reinicio del proceso, en cambio, partía de `project=null`. En móvil, `useProjectResume` recuerda ahora un marcador local con identidad/ruta del proyecto, selección y espacio de trabajo; no contiene texto, contenido, borradores ni rangos del editor.

Al arrancar espera a los ajustes nativos y a que termine la lectura/decisión de recuperación. Sin borrador pendiente, intenta abrir una sola vez el último proyecto, respetando la espera de iCloud y comprobando identidad antes de adoptarlo. La selección solo se restaura si la escena sigue existiendo. Cerrar proyecto explícitamente o eliminar el activo borra el marcador; no se reabre por renders posteriores. Los fallos se muestran sin bucles de apertura. La recuperación de escritura pendiente conserva su prioridad y decisión explícita.

No es posible garantizar que iPadOS mantenga el proceso vivo. El marcador también puede retomar el proyecto después de volver a lanzar la app; no distingue una terminación del sistema de un cierre forzado desde el selector de apps. El cierre explícito dentro de Write Studio sí se respeta. En escritorio no se activa la reapertura automática.

El popup de apertura/descarga muestra la fase solo en el título y el spinner en el cuerpo, con etiqueta de estado accesible; el guardado conserva sus fases existentes. Pruebas de hook/almacenamiento de navegación, recuperación y diálogo, y build frontend correctos sin abrir UI. Queda pendiente comprobar bloqueo, cambio de app y recarga real en el iPad.

### Zoom táctil de los lienzos

`usePinchZoom.ts` comparte la toma de control de dos dedos entre `MapsEditor.MapCanvas`, `MapDrawingEditor`, `IdeaCanvasEditor`, `RelationNetwork` y `Genealogy`. `pinchGesture.ts` conserva el punto del contenido bajo el centro de ambos dedos y aplica los límites existentes de cada cámara; cada pantalla convierte coordenadas físicas a las de su viewport/SVG o scroll.

Al entrar el segundo dedo se cancelan los gestos provisionales de puntero, incluidos los de hijos (marcadores, vértices, calibración y redimensionado). Hasta levantar todos los dedos se bloquean los eventos que podrían terminar un arrastre o activar un click. La cancelación restaura la cámara inicial; el pinch no modifica coordenadas ni relaciones de contenido. En dibujo, colocar símbolos/etiquetas con el dedo es provisional hasta soltar, para que el segundo dedo pueda cancelar sin añadir contenido ni historial. Ratón, teclado y herramientas de zoom conservan su flujo; ideas mantiene scroll de un dedo y excluye los campos editables del takeover.

Pruebas sin UI: geometría/anclaje, límites, cancelación de hijos, liberación, click/teclado, retirada de listeners y cancelación de símbolos táctiles; regresiones de navegación/historial geográfico, canvas/grupos, geometría de relaciones y preview/dibujo. Build frontend correcto. Queda pendiente probar los gestos reales en iPad, especialmente teclado/trackpad, scroll del canvas y takeover sobre vértices/calibración. No se abrió app ni simulador.
