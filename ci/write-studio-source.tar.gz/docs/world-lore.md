# World entry authoring and lore reading

`WorldbuildingEditor` owns the mode and transient navigation history. `LoreArticle`
reads the same `Worldbuilding`, entry connections, and manuscript appearance index
as the editor; there is no article copy, new project schema, or content migration.
Custom templates retain their section order and field order through `fieldGroups`.
Empty reading fields are filtered by value, including correct handling of zero and
false. Rich text uses the existing safe Markdown renderer. Reference fields reuse
`ReferenceLink`; names and aliases are never replaced speculatively in prose.

The module header remains outside the main content scroll. The entry browser has
its own bounded list. `LoreOutline` occupies the right column on wide containers
and becomes a collapsible overlay on narrower containers. The smallest layout
has a toggled entry browser. Scroll tracking only updates the active section; it
never moves keyboard focus. Explicit section navigation opens closed disclosures
and scrolls within the content root. Mode switches and history retain a section
anchor where that section exists in the destination presentation.

## Pending changes

Field edits continue through the existing synchronous project update callback and
the existing autosave/recovery pipeline in `App`. Navigating within World does not
reload or replace the project and does not require a disk save on every click.
Rich text, source text, and short fields update their live values while typing.
Link-name drafts commit on blur. Story-date drafts apply on blur, and malformed
drafts prevent entry or mode navigation until corrected. Closing a disclosure
keeps its controls mounted. Project save errors remain visible in World with a
retry action calling the existing save function.

Reading omits archived fields and editing controls. Archived entries remain
available through the existing browser status filter. Broken references render
the shared missing-entry state; a history destination that has since been deleted
renders a missing-article state. External whole-value HTTP(S) URLs are distinct
from internal reference buttons and open with `noopener noreferrer`.

Behavior coverage is in `tests/world-lore.mjs`; existing worldbuilding, image,
reference, alias, age, and relationship suites remain applicable.
