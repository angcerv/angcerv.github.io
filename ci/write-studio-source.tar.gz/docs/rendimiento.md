# Medición de rendimiento sin interfaz

Estas herramientas usan datos sintéticos. No abren la aplicación, navegadores ni selectores; no leen proyectos personales ni generan imágenes.

## Lógica en memoria

```sh
node scripts/benchmark-project.mjs 1000
```

Mide resumen, índice de referencias, continuidad y pendientes. Usa 1.000 escenas por defecto en este ejemplo, 200 fichas y 100 ideas; `scripts/benchmark-fixture.mjs` comparte el generador con la prueba de disco. El script informa primera ejecución, mediana y máximo de siete repeticiones. La primera ejecución de una operación puede aprovechar cachés de contenido creadas por otra: no equivale a arrancar la aplicación en frío.

## Disco y exportaciones

```sh
node scripts/benchmark-io.mjs 1000
```

La prueba prepara Markdown, Word y HTML de enciclopedia con los exportadores TypeScript reales. Después ejecuta `benchmark::project_io`, una prueba Rust ignorada por defecto que llama a los módulos nativos, sin arrancar Tauri.

Incluye:

- Guardado inicial de un proyecto nuevo.
- Apertura, guardado manual y automático cambiando una única escena.
- Creación y restauración de backups ZIP.
- Escritura de los tres documentos preparados.
- Empaquetado ZIP de la enciclopedia; con imágenes al activar `--assets`.

La comprobación compara el proyecto abierto/restaurado con la instantánea guardada, verifica los bytes escritos y el HTML del ZIP, y confirma que exportar no sobrescribe archivos existentes. El generador de exportaciones tampoco debe mutar el proyecto.

Se crea una carpeta temporal exclusiva para las entradas y otra para el proyecto nativo y las salidas. Ambas se eliminan al terminar normalmente o al fallar las comprobaciones; un cierre forzado del proceso puede dejar temporales. El benchmark no acepta una carpeta de proyecto de destino. La prueba Rust solo se compila para tests y queda fuera de la aplicación distribuida.

El resultado JSON separa tiempos de preparación y escritura, informa bytes de salida, muestras, medianas y máximos. No sumar medianas como si fueran una medición completa de una exportación individual. El guardado inicial y la importación del lote de recursos tienen una muestra; las demás operaciones tienen tres muestras secuenciales. El historial acumulado durante esas muestras forma parte de la prueba de backups.

### Perfil de compilación

El comando anterior usa el perfil de pruebas Rust sin optimizar. Sirve para detectar problemas funcionales y costes evidentes, pero **sus tiempos no son los de una versión distribuida**. Para repetir con Rust optimizado:

```sh
node scripts/benchmark-io.mjs 1000 --release
```

La compilación inicial puede tardar; no forma parte de los intervalos medidos. TypeScript se ejecuta mediante el cargador local de pruebas de Node, sin el bundle de producción. La salida identifica ambos entornos.

### Límites de interpretación

- Los textos son repetitivos y comprimen mejor que muchos manuscritos reales.
- El fixture predeterminado no tiene imágenes ni mapas. La opción `--assets` usa los recursos pequeños descritos abajo; ninguno de los dos escenarios simula años de historial retenido.
- No se vacían cachés del sistema operativo ni se simula almacenamiento lento.
- No se miden IPC, arranque de workers, diálogos, repintado, latencia del editor o memoria máxima.
- Las operaciones de disco se ejecutan secuencialmente. Evitar compilar o ejecutar otras pruebas durante una medición comparativa.
- No hay umbrales temporales de aprobación: una máquina lenta no debe producir un fallo funcional falso.

Para estudiar imágenes, usar en una ampliación posterior recursos existentes autorizados, conservando su lectura validada y dependencias. No sustituirlas por bytes inválidos ni generar imágenes para este propósito.

## Recursos visuales y mapas

```sh
node scripts/benchmark-io.mjs 1000 --assets
# Para Rust optimizado, añadir --release.
```

`--assets` añade 200 recursos lógicos usando copias **sin modificar** de los PNG ya existentes en `src-tauri/icons/`. Las miniaturas reutilizan el PNG existente de 128 × 128. No se crean imágenes ni se leen proyectos personales. Los 200 IDs reutilizan cíclicamente las mismas fuentes pequeñas: esto aumenta el número de archivos, pero no representa 200 ilustraciones distintas ni un conjunto de alta resolución.

El escenario comparte esos recursos entre 200 fichas con retratos/galerías y 20 mapas. Los mapas contienen en total 2.000 marcadores, 200 rutas, 200 regiones y 40 capas, con enlaces explícitos a fichas y escenas. Los fondos son iconos existentes usados como datos de prueba, no cartografía real. No se incluyen dibujos de terreno.

Además de las operaciones anteriores, mide:

- `storeAllAssets`: importación del lote mediante `entry_images::store`, incluyendo validación PNG y miniaturas. Preparar/copiar las fuentes queda fuera del intervalo. Se mide después de crear el proyecto; no forma parte de `initialSave`.
- `readAllAssetsValidated`: lectura y validación de todos los originales con `ProjectImageReader`. La apertura del proyecto mide metadatos; esta fila mide aparte la carga del lote. No representa el tiempo de apertura de una pantalla ni la memoria de un renderizador.
- Preparación de HTML con imágenes embebidas y de HTML para ZIP con rutas relativas. La codificación base64 del conjunto de entrada se prepara antes del intervalo.
- `encyclopediaZipWithImages`: escritura ZIP con el mismo lector nativo validado que usa el comando real, leyendo las imágenes una a una.

Tras cada restauración, compara los originales y miniaturas con los bytes de entrada. Tras cada ZIP, verifica HTML, número de archivos, rutas y bytes de cada PNG. Las referencias repetidas en galerías no deben producir archivos duplicados. `tests/benchmark-fixtures.mjs` comprueba además IDs, geometrías, enlaces y que preparar el escenario no modifica el proyecto de entrada.

La salida JSON informa IDs lógicos, número de archivos fuente, bytes de originales/miniaturas y cantidades de elementos geográficos. El peso de estos iconos es pequeño: estas pruebas sirven para detectar costes por archivo, referencias y validación, **no para concluir que fotografías grandes, memoria, zoom o exportación PNG de mapas estén optimizados**.

## Hallazgo y optimización del guardado

La implementación inicial de `src-tauri/src/storage.rs`, función `apply`, escribía cada escena con `atomic` y después los datos del mundo y los metadatos. El benchmark inicial mostró el coste de reescribir todo el manuscrito al cambiar una escena.

La implementación actual usa `atomic_if_changed` para escenas, plantillas, fichas e índice del mundo: compara los bytes reales del archivo y solo reemplaza contenido distinto. Conserva la sincronización del archivo/directorio incluso en coincidencias, limpia restos `.pending` y reemplaza destinos simbólicos. El journal y los metadatos de revisión conservan `atomic`; no se usan fechas ni cachés de contenido como prueba de igualdad.

Las pruebas de `storage_incremental_tests.rs` cubren identidad de archivos sin cambios, reparación de archivos borrados/dañados/modificados, recuperación de una transacción parcialmente aplicada, reintentos, restos temporales y conservación del bloqueo por índice del mundo ausente en guardados ordinarios. Las suites nativas existentes cubren además revisiones, conflictos, migraciones, historial y backups.

## Resultado inicial: 31 de octubre de 2026

macOS arm64, Node v22.15.0, Rust en perfil de pruebas sin optimizar. Ambos tamaños contienen 200 fichas y 100 ideas, sin imágenes. Medianas de tres muestras, salvo el guardado inicial (una muestra). Los archivos de resultados conservan todas las muestras: [100 escenas](benchmarks/io-100-debug.json) y [1.000 escenas](benchmarks/io-1000-debug.json).

| Operación | 100 escenas | 1.000 escenas |
| --- | ---: | ---: |
| Guardado inicial | 2375.5 ms | 9245.3 ms |
| Abrir | 12.2 ms | 33.0 ms |
| Guardar una escena (manual) | 2251.0 ms | 9577.2 ms |
| Guardar una escena (automático) | 2448.2 ms | 8785.4 ms |
| Crear backup | 1476.2 ms | 5882.8 ms |
| Restaurar backup | 1239.6 ms | 4699.3 ms |
| Escribir Word preparado | 1.5 ms | 4.7 ms |
| ZIP enciclopedia sin imágenes | 3.8 ms | 5.5 ms |

Preparar el Word de 1.000 escenas tardó 83.334 ms de mediana; escribir sus bytes se mide aparte. El JSON sintético de ese proyecto ocupa 2367657 bytes.

Estos resultados iniciales corresponden a la implementación anterior a `atomic_if_changed`. No establecen un límite de tamaño ni predicen los tiempos de producción.

## Comparación tras evitar reemplazos idénticos

Mismo fixture de 1.000 escenas, 200 fichas y 100 ideas, mismo perfil Rust sin optimizar. Medianas de tres muestras, salvo el guardado inicial. [Muestras posteriores al cambio](benchmarks/io-1000-incremental-debug.json). Son ejecuciones separadas, sin controlar las cachés del sistema; no constituyen una garantía de tiempos.

| Operación | Antes | Después |
| --- | ---: | ---: |
| Guardado inicial | 9245.3 ms | 9143.7 ms |
| Abrir | 33.0 ms | 33.3 ms |
| Guardar una escena (manual) | 9577.2 ms | 193.9 ms |
| Guardar una escena (automático) | 8785.4 ms | 158.7 ms |
| Crear backup | 5882.8 ms | 6216.3 ms |
| Restaurar backup | 4699.3 ms | 5301.0 ms |

La mejora se concentra en aplicar cambios pequeños: se siguen leyendo/comparando archivos y sincronizando datos, pero se evitan los reemplazos idénticos. El guardado inicial y la restauración de un proyecto nuevo siguen creando todos los archivos. No se ha optimizado la compresión de backups ni modificado las políticas de historial.

## Lectura compartida en backups con imágenes

La implementación anterior de `backup::verify_project` reunía los IDs de recursos del proyecto y del historial y llamaba a `entry_images::read` dos veces por ID (original y miniatura). Cada llamada construía un `ProjectImageReader` y volvía a leer/analizar `project.json`: 400 inicializaciones por verificación con 200 recursos.

La implementación actual crea un único `ProjectImageReader` por verificación, siguiendo el patrón usado en la exportación ZIP. No se comparte el lector entre proyectos ni entre operaciones. La creación del backup verifica tanto el origen como el proyecto extraído temporalmente; cada verificación tiene su propio lector.

Cada lectura mantiene la comprobación de ID, ruta canónica, límite de tamaño, dimensiones y decodificación PNG. Se siguen reuniendo referencias actuales y del historial, incluidas las de mapas, papelera y lienzos mediante los recolectores existentes. También se conservan las comprobaciones del ZIP y de cambios del proyecto antes de publicar la copia. Los tiempos agregados no aíslan cuánto corresponde a cada fase.

`src-tauri/src/backup_image_batch_tests.rs` reutiliza un PNG existente para comprobar recursos solo históricos, originales/miniaturas dañados, rechazo de enlaces fuera del proyecto y restauración byte a byte. Las pruebas nativas existentes siguen cubriendo archivos incompletos, manifiestos, historial y publicación segura.

## Resultado con recursos y mapas: 31 de octubre de 2026

1.000 escenas, 200 fichas, 100 ideas, 200 IDs de recursos, 20 mapas, 2.000 marcadores, 200 rutas y 200 regiones. Los recursos reutilizan 14 PNG existentes, con 524221 bytes de originales y 440000 bytes de miniaturas en total (menos de 1 MB). Mismo perfil Rust de pruebas sin optimizar; tres muestras por operación, salvo guardado inicial e importación. [Todas las muestras](benchmarks/io-1000-assets-debug.json).

| Operación | Mediana |
| --- | ---: |
| Guardado inicial sin importar todavía los PNG | 9314.9 ms |
| Importar los 200 recursos con miniaturas | 6484.6 ms |
| Abrir metadatos del proyecto | 68.1 ms |
| Leer/validar los 200 originales en lote | 476.8 ms |
| Guardar una escena (manual) | 320.3 ms |
| Guardar una escena (automático) | 259.0 ms |
| Crear y verificar backup | 27944.6 ms |
| Restaurar backup | 17092.9 ms |
| Enciclopedia ZIP con PNG separados | 490.7 ms |

Todos los proyectos restaurados y los recursos originales/miniaturas coinciden con la entrada. La enciclopedia ZIP contiene un HTML y 200 PNG, sin duplicar los recursos por sus referencias en galerías.

El mayor coste agregado vuelve a estar en backup/restauración. Esta medición motivó compartir el lector de identidad descrito arriba; no atribuye todo el coste a esa causa. Esta medición es anterior al lector compartido de backups; no se modificaron importación ni exportación para obtenerla. Tampoco se han medido imágenes grandes, renderizado, memoria máxima ni interfaz.

## Comparación tras compartir el lector del backup

Mismo fixture de 1.000 escenas, 200 recursos lógicos y 20 mapas; mismo entorno y perfil Rust sin optimizar. Medianas de tres muestras. Son ejecuciones separadas, con cachés del sistema sin controlar. [Muestras posteriores](benchmarks/io-1000-assets-batch-debug.json).

| Operación | Antes | Después |
| --- | ---: | ---: |
| Crear y verificar backup | 27944.6 ms | 10152.8 ms |
| Restaurar backup | 17092.9 ms | 8034.5 ms |
| Guardar una escena (manual) | 320.3 ms | 312.8 ms |
| Enciclopedia ZIP con imágenes | 490.7 ms | 481.1 ms |

El cambio elimina la lectura/análisis repetidos de `project.json` durante cada lote de verificación. Los 108 tests nativos pasan, incluidas las regresiones de imágenes actuales/históricas, miniaturas, rutas y restauración. El benchmark comprueba de nuevo igualdad del proyecto y bytes de recursos/ZIP. No se han eliminado fases de verificación, sincronización, compresión ni publicación segura. Los recursos siguen siendo iconos pequeños; no se han medido imágenes grandes ni interfaz.

## Referencia con Rust optimizado: 31 de octubre de 2026

Se ejecutaron secuencialmente los escenarios de 1.000 escenas de texto y de recursos/mapas con `--release`, conservando todas las comprobaciones de integridad. Compilar quedó fuera de los intervalos. macOS arm64, Node v22.15.0, rustc 1.99.1 y Cargo 1.99.1. La configuración de `Cargo.toml` usa `opt-level = 3`, LTO y una unidad de generación de código.

Muestras completas: [texto](benchmarks/io-1000-release.json) y [recursos/mapas](benchmarks/io-1000-assets-release.json). Medianas de tres muestras, salvo guardado inicial e importación (una).

| Operación | Texto | Recursos y mapas |
| --- | ---: | ---: |
| Guardado inicial (sin importar PNG) | 9082.1 ms | 9083.3 ms |
| Abrir metadatos | 29.9 ms | 26.3 ms |
| Guardar una escena (manual) | 90.5 ms | 78.5 ms |
| Guardar una escena (automático) | 72.7 ms | 74.3 ms |
| Crear y verificar backup | 4750.7 ms | 5899.9 ms |
| Restaurar backup | 4519.1 ms | 5492.8 ms |

En el escenario con recursos:

| Operación | Mediana |
| --- | ---: |
| Importar 200 recursos con miniaturas | 2347.7 ms |
| Leer/validar 200 originales en lote | 26.4 ms |
| Enciclopedia ZIP con imágenes | 32.5 ms |

### Comparación con las referencias sin optimizar

Se comparan las versiones que ya incluían el guardado incremental y, para recursos, el lector compartido de backups. Los fixtures coinciden; las ejecuciones son separadas y no controlan cachés ni carga del sistema.

| Escenario / operación | Debug | Release |
| --- | ---: | ---: |
| Texto: guardar una escena | 193.9 ms | 90.5 ms |
| Texto: backup | 6216.3 ms | 4750.7 ms |
| Recursos: guardar una escena | 312.8 ms | 78.5 ms |
| Recursos: backup | 10152.8 ms | 5899.9 ms |
| Recursos: restauración | 8034.5 ms | 5492.8 ms |

Esta es una referencia del backend optimizado, no una medición completa de la aplicación distribuida: se ejecuta el binario de tests sin arrancar la app Tauri ni usar IPC o interfaz. TypeScript sigue ejecutándose en Node mediante el cargador de pruebas; `--release` no optimiza esos tiempos de preparación. Los recursos son los mismos iconos pequeños repetidos, sin fotos grandes, dibujos de terreno ni memoria máxima. No se ha cambiado código de la aplicación para obtener estos resultados.

## Revisión previa a iPad: 1 de noviembre de 2026

Se ejecutó `benchmark-project.mjs` con 1.000 y 5.000 escenas, 200 fichas y 100 ideas en Node sobre macOS. Se reutilizan las referencias de disco/release anteriores: no se repitieron backups ni exportaciones. No se abrió la interfaz ni se utilizaron proyectos personales.

Con 1.000 escenas, las medianas calientes fueron 26,73 ms para resumen, 1,42 ms para continuidad, 27,57 ms para todos los pendientes y 0,31 ms para solo ideas. El primer índice de referencias tardó 238,42 ms.

Con 5.000 escenas se detectó expulsión cíclica de la caché de menciones por ID (límite 2.000). `mentionDetection.ts` conserva ahora también el último resultado de cada escena viva mediante una clave débil, comprobando catálogo, contenido y decisiones. La caché por ID sigue acotada y permite reutilizar resultados entre objetos compatibles; la nueva caché no mantiene vivas escenas eliminadas.

| Operación, 5.000 escenas | Mediana caliente anterior | Mediana caliente posterior |
| --- | ---: | ---: |
| Resumen | 123,36 ms | 125,98 ms |
| Continuidad | 1043,20 ms | 6,92 ms |
| Todos los pendientes | 1174,72 ms | 142,56 ms |
| Solo ideas | 0,44 ms | 0,70 ms |

Cada mediana corresponde a siete repeticiones dentro de una ejecución; antes/después son procesos separados, sin controlar la carga del sistema. La primera continuidad sigue costando aproximadamente 1,14 s y el primer índice 1,15 s: esta optimización evita recalcular escenas vivas, no acelera su primera detección. El resumen y los pendientes completos siguen recorriendo/contando texto; con este tamaño son candidatos a una siguiente medición de actualización incremental. No se añadieron cachés generales ni cambios de comportamiento basados en tiempos de aprobación.

Las regresiones de `reference-cache.mjs` superan 2.000 escenas y comprueban reutilización e invalidación por contenido, exclusiones y catálogo; las pruebas existentes cubren decisiones, alias, archivo, ambigüedad e idioma. También pasan `mention-review.mjs` y el build.

Estos resultados miden lógica sintética repetitiva en un Mac, no latencia del editor ni rendimiento de iPad. No se obtuvo una medición de memoria máxima; tampoco se midieron fotos grandes, renderizado, IPC o gestos. Queda pendiente medir en dispositivo la primera revisión, memoria y respuesta al editar antes de establecer límites de proyecto.
