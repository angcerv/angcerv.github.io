# Entry relationships

## Definitions and connections

`project.entryRelations.types` contains project-wide reusable definitions. The
Worldbuilding Relationships tab edits these definitions. The Templates tab can
disable a type for a template; role compatibility remains configured on the
shared definition. No relationship settings are stored in custom entry fields.

`project.entryRelations.links` contains concrete connections. A connection has a
stable ID, a type ID and two entry IDs. There is only one record for both views.
In schema version 2, `title` is the role of `sourceId` and `inverseTitle` is the
role of `targetId`. `name` identifies the definition independently of those roles.
For symmetric types both role labels and both compatibility lists are identical.

`saveEntryConnection` is the mutation boundary used by entry forms. It maps the
current entry's chosen role to the correct endpoint, checks role compatibility,
rejects self-connections and checks equivalent connections. Directed connections
with opposite role assignments are distinct; symmetric reversed endpoints are
equivalent. Edits preserve the connection ID. Changing a type to symmetric is
blocked when it would merge existing directed connections; none are discarded.

The connection form infers the current participant role when only one role is
compatible with its template, and lists related entries directly across all templates permitted for the
complementary role. There is no destination-template selector; entry labels show
their template when multiple templates are allowed. Existing incompatible role assignments are not silently reversed.

A template's availability switch uses `disabledTemplateIds`. Compatibility uses
`sourceTemplateIds` and `targetTemplateIds`; an empty compatibility list allows
all templates. Disabling a type or tightening its rules does not remove existing
connections. Those connections remain visible and are marked for review.

## Legacy data

`normalizeEntryRelations` lazily, immutably upgrades version 1 to version 2.
Opening a project does not rewrite its files. Relationship edits persist version
2 through the existing project save/draft/history transaction. Entry packages
also normalize and remap relationship metadata and IDs.

Version 1 mixed participant roles with descriptions of the other endpoint. Its
labels alone cannot reliably determine the writer's intended role assignment.
Migration therefore keeps all connection IDs, endpoint directions, restrictions
and labels exactly as stored. Directed types receive `needsRoleReview`; their
connections display neutral endpoint names instead of asserting participant roles.
Creating/editing those connections is blocked until the shared definition is
reviewed. The definition dialog lists all stored endpoint pairs, lets the writer
swap/edit role labels, and requires explicit confirmation. Symmetric definitions
need no role assignment review. Derived definition names are capped at 120 code
points and disambiguated without changing either original role label.

Pre-existing links to missing entries remain available for explicit review or
removal in Relationships. New explicit entry deletions are handled atomically in
App.update via `removeDeletedEntryRelations`, which removes connections involving
the deleted IDs. It does not erase unrelated pre-existing missing-entry links.
The deletion dialog reports how many connections will be removed.

Definitions belong to the project. Template-only exports retain their existing
field-definition format; entry exports include their connected relationships and
role/availability metadata. Full project backups include all definitions.

## Validation

Frontend tests exercise perspective rendering and real form callbacks, creation
from either endpoint, edits/unlinking, multiple connections per role, unrelated
entries, duplicate rejection, compatibility/selection reset, template availability,
entry-deletion cleanup, explicit legacy review and portable import.
Rust validates both schema versions, metadata, identifiers, mode invariants and
role-aware duplicate keys. Storage and portable-package tests cover version 2
role labels and pending-review metadata. Compatibility changes and legacy missing
entries are deliberately not rejected on load, to avoid making old projects
unopenable or silently losing their connections.


## Relationship network and named views

Worldbuilding Relationships offers Network and Relationship types tabs. Entry
cards can open the network centered on that entry. The canvas uses the existing
entry/connection IDs and mutation dialogs; moving a node never alters story
relationships. The inspector can edit entry names or the original shared links.

Network filters restrict entries by template, relationship type, archive status,
plot context and a one/two-hop focus. Plot context uses explicit scene links,
unambiguous manuscript mentions and related timeline events. It never creates
connections from co-occurrence. Legacy role-review edges are dashed and display
neutral participant names until confirmed; missing endpoints remain in the type
library's existing review workflow.

Saving a named view upgrades only entryRelations to schema version 3 and records
filters, map-space node positions and pan/zoom. Existing v1/v2 definitions and
connections retain their established normalization/review behavior. Exploring,
filtering and dragging are local until a view is saved or updated. The named views
survive normal project saves, recovery drafts, history and full backups. Entry
package exports deliberately omit project-wide views; imports preserve the
current project's existing views. Missing saved-filter references remain visible
as a review notice rather than silently widening the view.

The genealogy view is a later feature. No relationship is classified as parent,
child, spouse or adoption based on its label.
