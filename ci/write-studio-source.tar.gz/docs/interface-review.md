# Interface review

The current review covers welcome, Manuscript, Worldbuilding and Timeline. Automated checks and code inspection are complete; native visual acceptance is pending. The computer-use tool denied access to Safari, so no screenshots, live keyboard interactions or rendered layout checks were performed in this review.

## Changes and automated evidence

- `workspace.css` now imports six stylesheets in an explicit order. Module styles live in `src/styles/`: foundation, timeline, controls, worldbuilding, manuscript and welcome. Keep shared input surface tokens in `controls.css`; edit each module's existing selectors instead of appending new override blocks.
- Removed 26 repeated/superseded declarations and the obsolete writing-status palette, plus nine unused selection/banner rules. Base application and reference-panel styles remain in `App.css` and `WorldPanel.css`; these were not broadly rewritten.
- Action menus render through a portal to escape scrolling containers. Positioning constrains them to the window and opens upward when space below is limited. Escape restores trigger focus; Tab moves to the next/previous control relative to the trigger. Hidden, inert or disabled sources close their menu.
- Timeline filters use the same bounded positioning function. Leaving the filter panel by keyboard closes it. Escape from an open nested dropdown closes that dropdown first. Notes resize when their column width changes.
- Narrow manuscript windows limit the sidebar width and allow heading actions to wrap. Worldbuilding's single-column layout removes the obsolete vertical browser divider.
- Writing-status dots keep the requested palette; label text mixes toward theme text for readability. Contrast checks exceed 4.5:1 in both themes.
- `npm run build` validates TypeScript and bundled CSS. `npm test` includes manuscript, data/recovery, export, worldbuilding, dropdown navigation, timeline, UI rendering and layout helper checks.
- `tests/ui-layout.mjs` verifies panel bounds at 480×360, 760×600, 1024×768 and 1440×900, plus both palettes' label contrast. These are geometry/token tests, not screenshots or browser layout tests.

## Native visual acceptance still required

Use a disposable project with long names, multiple chapters, scenes, templates, entries and dated/undated events. Check light and dark themes at small, medium and large window sizes.

| Area | Acceptance checks |
| --- | --- |
| Welcome | Primary/secondary actions remain distinct; long recent-project titles truncate; options menus stay visible near the bottom/right edge; empty state is balanced. |
| Manuscript | Resize navigation; expand/collapse chapters; navigate to a scene from search; confirm selected chapter/scene styling and status dots; heading actions do not cover the editor. |
| Details | Choose each status with mouse and keyboard; verify the selected checkmark; edit synopsis; open and cancel deletion with Escape; confirm focus returns sensibly. |
| Worldbuilding | Check compact template field rows without stretched neighbors; open/close row settings; create short-text, reference and picklist fields in the modal; verify dropdown menus remain interactive above the modal, autofocus/Tab/Escape and return focus; reorder with drag/handle arrows; block deletion of used fields; inspect archived and missing references. Entry forms keep their responsive columns. |
| Timeline | Switch List/Visual with active filters; scroll chart and details independently; open filters near window edges; Tab out and Escape from nested dropdowns; check notes after resizing. |
| Maps | Import multiple maps; zoom, fit, drag and scroll; place/reposition markers and edit percentages; navigate entry ↔ map, including archived/missing entries; replace artwork; cancel/confirm deletion; verify independent sidebar/details scroll in both themes. |
| Picklists and language | Add single/multiple fields; rename/archive/restore options with existing selections; clear archived choices; search by labels; switch English ↔ Español with unsaved text; verify settings persistence, unchanged project data and longer translated labels at narrow widths. |
| Template transfer | Export one/all templates; import from file/folder/recent project; preview fields/options, rename conflicts, inspect required dependencies; cancel without changes; confirm copied reference restrictions and picklist options; verify source files stay unchanged and Escape/window close dismisses the dialog. |
| Story dates and ages | Create Date fields and assign/reassign a birth role; enter full/partial/negative dates; verify invalid input retains prior values; link entries to events and inspect list/chart/detail ages before/on/after birthdays, partial dates and periods; edit dates and confirm ages update; query an age from the entry; archive/restore the birth field. |
| Field sections | Open/close the section management modal with mouse and Escape; verify focus returns and the compact trigger never truncates. Create, rename and reorder sections; move fields using the always-visible section setting, drag onto highlighted group headings and keyboard handles; confirm moving collapses field editing and restores focus after drop; delete a section and confirm values move to No section. Collapse/expand groups in entry editing and manuscript consultation. Check long labels, both themes, narrow widths and transferred templates. |
| Shared controls | Tab/Shift+Tab follow a useful order; focus remains visible; menus support arrows/Home/End/Escape; reduced-motion preference disables movement; modal actions cannot be activated behind the modal. |

Do not mark native acceptance complete until the rendered app has been checked.
