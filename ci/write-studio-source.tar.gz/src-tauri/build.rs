fn main() {
    if std::env::var("CARGO_CFG_TARGET_OS").as_deref() == Ok("ios") {
        cc::Build::new().file("native/project_directory.m").flag("-fobjc-arc").flag("-fblocks").compile("write_studio_directory");
        for framework in ["UIKit", "Foundation", "UniformTypeIdentifiers"] { println!("cargo:rustc-link-lib=framework={framework}"); }
        println!("cargo:rerun-if-changed=native/project_directory.m");
    }
    tauri_build::build()
}
