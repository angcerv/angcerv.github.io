use super::*;
const ACTIVE: &str = "00000000-0000-0000-0000-000000045001";
const HISTORICAL: &str = "00000000-0000-0000-0000-000000045002";
// Reuse an existing PNG unchanged; do not generate image fixtures.
const PNG: &[u8] = include_bytes!("../icons/128x128.png");
fn fixture() -> (TemporaryFolder, PathBuf, storage::Project) {
    let temporary = TemporaryFolder::new(&std::env::temp_dir(), "backup-image-batch").unwrap();
    let root = temporary.0.join("source");
    fs::create_dir(&root).unwrap();
    let mut project: storage::Project = serde_json::from_str(include_str!(
        "../../tests/fixtures/worldbuilding-project.json"
    ))
    .unwrap();
    let world = project.worldbuilding.as_mut().unwrap();
    world.schema_version = 7;
    for template in &mut world.templates {
        template.schema_version = 7;
    }
    for entry in &mut world.entries {
        entry.schema_version = 7;
    }
    let mut saved = storage::save(&root, project).unwrap();
    for id in [ACTIVE, HISTORICAL] {
        entry_images::store(&root, &saved.id, id, PNG, PNG).unwrap();
    }
    saved.worldbuilding.as_mut().unwrap().entries[0].image_id = Some(ACTIVE.into());
    saved.worldbuilding.as_mut().unwrap().entries[1].image_id = Some(HISTORICAL.into());
    let mut saved = storage::save(&root, saved).unwrap();
    saved.worldbuilding.as_mut().unwrap().entries[1].image_id = None;
    let saved = storage::save(&root, saved).unwrap();
    (temporary, root, saved)
}
#[test]
fn batch_verification_validates_active_and_history_only_assets_and_roundtrips() {
    let (temporary, root, saved) = fixture();
    verify_project(&root).unwrap();
    for (id, name, label) in [
        (HISTORICAL, "image.png", "image"),
        (ACTIVE, "thumbnail.png", "thumbnail"),
        (HISTORICAL, "thumbnail.png", "thumbnail"),
    ] {
        let path = root.join(format!("assets/images/{id}/{name}"));
        fs::write(&path, b"corrupt PNG").unwrap();
        let destination = temporary.0.join(format!("invalid-{id}-{name}.zip"));
        let error = create(&root, &destination, &saved.id, saved.revision).unwrap_err();
        assert!(
            error.contains(&format!("Cannot back up or restore {label} {id}")),
            "{error}"
        );
        assert!(!destination.exists());
        fs::write(&path, PNG).unwrap();
    }
    let destination = temporary.0.join("valid.zip");
    create(&root, &destination, &saved.id, saved.revision).unwrap();
    let parent = temporary.0.join("restored");
    fs::create_dir(&parent).unwrap();
    let restored = restore(&destination, &parent).unwrap();
    assert_eq!(
        serde_json::to_value(&restored.project).unwrap(),
        serde_json::to_value(&saved).unwrap()
    );
    for id in [ACTIVE, HISTORICAL] {
        for thumbnail in [false, true] {
            assert_eq!(
                entry_images::read(Path::new(&restored.path), &saved.id, id, thumbnail).unwrap(),
                PNG
            );
        }
    }
}
#[cfg(unix)]
#[test]
fn batch_reader_rejects_asset_symlinks_outside_the_project() {
    let (temporary, root, saved) = fixture();
    let external = temporary.0.join("external.png");
    fs::write(&external, PNG).unwrap();
    let original = root.join(format!("assets/images/{ACTIVE}/image.png"));
    fs::remove_file(&original).unwrap();
    std::os::unix::fs::symlink(external, original).unwrap();
    assert!(verify_project(&root)
        .unwrap_err()
        .contains("inside the project"));
    assert_eq!(storage::open(&root).unwrap().id, saved.id);
}
