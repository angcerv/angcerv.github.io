#[cfg(any(target_os="ios",test))]
mod project_disk_guard;
#[cfg(target_os="ios")]
mod ios_directory;
mod platform;
mod idea_canvas;
mod entry_relations;
mod entry_transfer;
mod backup;
mod entry_images;
mod export;
mod history;
mod maps;
mod project_deletion;
mod recents;
mod settings;
mod storage;
mod template_transfer;
mod timeline;
mod story_calendar;
mod worldbuilding;
mod writing_goals;
use std::sync::Mutex;
#[cfg(desktop)]
use std::sync::atomic::{AtomicBool, Ordering};
use tauri::Manager;
#[cfg(desktop)]
use tauri::Emitter;
#[derive(Default)]
struct State {
    io: Mutex<()>,
    #[cfg(desktop)]
    exit: AtomicBool,
}
#[tauri::command]
async fn load_entry_package(language:Option<String>)->Result<Option<entry_transfer::EntryPackage>,String>{
 let path=tauri::async_runtime::spawn_blocking(move||platform::FileDialog::new().set_title(if language.as_deref()==Some("es"){"Importar fichas"}else{"Import entries"}).add_filter("Write Studio entries",&["json"]).pick_file()).await.map_err(|error|error.to_string())??;
 path.map(|path|entry_transfer::read(&path)).transpose()
}
#[tauri::command]
async fn export_entry_package(mut package:entry_transfer::EntryPackage,path:String,project_id:String,filename:String,language:Option<String>)->Result<Option<String>,String>{
 let mut ids=std::collections::HashSet::new();for id in worldbuilding::image_ids(&package.worldbuilding){if ids.insert(id.clone()){package.images.push(entry_transfer::PackageImage{id:id.clone(),image:entry_images::read(std::path::Path::new(&path),&project_id,id,false)?,thumbnail:entry_images::read(std::path::Path::new(&path),&project_id,id,true)?});}}
 entry_transfer::validate(&package)?;
 let target=tauri::async_runtime::spawn_blocking(move||platform::FileDialog::new().set_title(if language.as_deref()==Some("es"){"Exportar fichas"}else{"Export entries"}).set_file_name(&filename).add_filter("Write Studio entries",&["json"]).save_file()).await.map_err(|error|error.to_string())??;
 let Some(mut target)=target else{return Ok(None)};if target.extension().and_then(|ext|ext.to_str())!=Some("json"){target.set_extension("json");}entry_transfer::write(&target,&package)?;Ok(Some(target.to_string_lossy().into()))
}
#[tauri::command]
async fn load_template_package(
    source: String,
    path: Option<String>,
    language: Option<String>,
    state: tauri::State<'_, State>,
) -> Result<Option<template_transfer::TemplatePackage>, String> {
    if source != "file" && source != "project" {
        return Err("Unknown template source.".into());
    }
    let project = source == "project";
    let selected = if project && path.is_some() {
        path.map(std::path::PathBuf::from)
    } else {
        tauri::async_runtime::spawn_blocking(move || {
            let spanish = language.as_deref() == Some("es");
            if project {
                platform::FileDialog::new()
                    .set_title(if spanish {
                        "Copiar plantillas de otro proyecto"
                    } else {
                        "Copy templates from another project"
                    })
                    .pick_folder()
            } else {
                platform::FileDialog::new()
                    .set_title(if spanish {
                        "Importar plantillas de Write Studio"
                    } else {
                        "Import Write Studio templates"
                    })
                    .add_filter("Write Studio templates", &["json"])
                    .pick_file()
            }
        })
        .await
        .map_err(|e| e.to_string())??
    };
    let Some(path) = selected else {
        return Ok(None);
    };
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    if project {
        template_transfer::from_project(&path).map(Some)
    } else {
        template_transfer::read_file(&path).map(Some)
    }
}
#[tauri::command]
async fn export_template_package(
    package: template_transfer::TemplatePackage,
    filename: String,
    language: Option<String>,
) -> Result<Option<String>, String> {
    template_transfer::validate(&package)?;
    let selected = tauri::async_runtime::spawn_blocking(move || {
        platform::FileDialog::new()
            .set_title(if language.as_deref() == Some("es") {
                "Exportar plantillas"
            } else {
                "Export templates"
            })
            .set_file_name(&filename)
            .add_filter("Write Studio templates", &["json"])
            .save_file()
    })
    .await
    .map_err(|e| e.to_string())??;
    let Some(mut path) = selected else {
        return Ok(None);
    };
    if path.extension().and_then(|extension| extension.to_str()) != Some("json") {
        path.set_extension("json");
    }
    template_transfer::write_file(&path, &package)?;
    Ok(Some(path.to_string_lossy().into()))
}
#[tauri::command]
async fn inspect_project_deletion(
    path: String,
    app: tauri::AppHandle,
    state: tauri::State<'_, State>,
) -> Result<project_deletion::Target, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    project_deletion::inspect(
        std::path::Path::new(&path),
        &app.path().app_data_dir().map_err(|e| e.to_string())?,
    )
}
#[tauri::command]
async fn delete_project(
    target: project_deletion::Target,
    confirmation: String,
    app: tauri::AppHandle,
    state: tauri::State<'_, State>,
) -> Result<project_deletion::Outcome, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    project_deletion::remove_with(
        &target,
        &confirmation,
        &app.path().app_data_dir().map_err(|e| e.to_string())?,
        project_deletion::move_to_trash,
    )
}
#[tauri::command]
async fn create_project_backup(
    path: String,
    project_id: String,
    revision: u64,
    filename: String,
    state: tauri::State<'_, State>,
) -> Result<Option<String>, String> {
    let target = tauri::async_runtime::spawn_blocking(move || {
        platform::FileDialog::new()
            .set_title("Create project backup")
            .set_file_name(&filename)
            .add_filter("Write Studio backup", &["zip"])
            .save_file()
    })
    .await
    .map_err(|e| e.to_string())??;
    let Some(mut target) = target else {
        return Ok(None);
    };
    if target.extension().and_then(|value| value.to_str()) != Some("zip") {
        target.set_extension("zip");
    }
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    backup::create(std::path::Path::new(&path), &target, &project_id, revision)?;
    Ok(Some(target.to_string_lossy().into()))
}
#[tauri::command]
async fn restore_project_backup(
    app: tauri::AppHandle,
    state: tauri::State<'_, State>,
) -> Result<Option<storage::OpenProject>, String> {
    #[cfg(target_os = "ios")]
    {
        let selected = platform::pick_backup(app.clone()).await?;
        let Some(archive) = selected else { return Ok(None); };
        let _guard = state.io.lock().map_err(|e|e.to_string())?;
        let settings = mobile_settings(&app)?;
        let parent = settings.projects_directory.ok_or("Folder selection is not available in this mobile preview.")?;
        return backup::restore(&archive, std::path::Path::new(&parent)).map(Some);
    }
    #[cfg(not(target_os = "ios"))]
    {
    let default = settings::read(&app.path().app_data_dir().map_err(|e| e.to_string())?)
        .ok()
        .and_then(|settings| settings.projects_directory);
    let selection = tauri::async_runtime::spawn_blocking(move || {
        let archive = platform::FileDialog::new()
            .set_title("Restore a Write Studio backup")
            .add_filter("Write Studio backup", &["zip"])
            .pick_file()?;
        let Some(archive) = archive else { return Ok(None); };
        let mut dialog =
            platform::FileDialog::new().set_title("Choose where to create the restored project folder");
        if let Some(path) = default {
            dialog = dialog.set_directory(path);
        }
        dialog.pick_folder().map(|parent| parent.map(|parent| (archive, parent)))
    })
    .await
    .map_err(|e| e.to_string())??;
    let Some((archive, parent)) = selection else {
        return Ok(None);
    };
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    backup::restore(&archive, &parent).map(Some)
    }
}
#[tauri::command]
async fn choose_entry_image() -> Result<Option<entry_images::SelectedImage>, String> {
    tauri::async_runtime::spawn_blocking(|| {
        let selected = platform::FileDialog::new()
            .add_filter("Images", &["png", "jpg", "jpeg", "webp"])
            .pick_file()?;
        selected.map(|path| entry_images::select(&path)).transpose()
    })
    .await
    .map_err(|e| e.to_string())?
}
#[tauri::command]
async fn choose_entry_images(max_count: usize) -> Result<Option<Vec<entry_images::SelectedImage>>, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let selected = platform::FileDialog::new()
            .add_filter("Images", &["png", "jpg", "jpeg", "webp"])
            .pick_files()?;
        selected.map(|paths| entry_images::select_many(&paths, max_count)).transpose()
    }).await.map_err(|e| e.to_string())?
}
#[tauri::command]
async fn store_entry_image(
    path: String,
    project_id: String,
    image_id: String,
    image: Vec<u8>,
    thumbnail: Vec<u8>,
    state: tauri::State<'_, State>,
) -> Result<(), String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    entry_images::store(
        std::path::Path::new(&path),
        &project_id,
        &image_id,
        &image,
        &thumbnail,
    )
}
#[tauri::command]
async fn read_entry_image(
    path: String,
    project_id: String,
    image_id: String,
    thumbnail: bool,
    state: tauri::State<'_, State>,
) -> Result<Vec<u8>, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    entry_images::read(
        std::path::Path::new(&path),
        &project_id,
        &image_id,
        thumbnail,
    )
}
#[tauri::command]
async fn choose_folder() -> Result<Option<String>, String> {
    #[cfg(target_os="ios")]
    { return ios_directory::choose().await; }
    #[cfg(not(target_os="ios"))]
    {
    tauri::async_runtime::spawn_blocking(|| {
        platform::FileDialog::new()
            .pick_folder()
            .map(|p| p.map(|p| p.to_string_lossy().into_owned()))
    })
    .await
    .map_err(|e| e.to_string())?
    }
}
#[tauri::command]
async fn export_encyclopedia(
    filename: String,
    path: String,
    project_id: String,
    html: String,
    image_ids: Vec<String>,
) -> Result<Option<String>, String> {
    tauri::async_runtime::spawn_blocking(move || {
        let destination = platform::FileDialog::new()
            .set_file_name(&filename)
            .add_filter("Encyclopedia ZIP", &["zip"])
            .save_file()?;
        let Some(mut target) = destination else {
            return Ok(None);
        };
        if target.extension().and_then(|value| value.to_str()) != Some("zip") {
            target.set_extension("zip");
        }
        let images = if image_ids.is_empty() {
            None
        } else {
            Some(entry_images::ProjectImageReader::new(
                std::path::Path::new(&path),
                &project_id,
            )?)
        };
        export::write_encyclopedia(&target, &html, &image_ids, |id| {
            let reader = images.as_ref().ok_or_else(|| "Invalid image identifier.".to_string())?;
            reader.read(id, false).map_err(|_| {
                "An entry image could not be read. Retry or export without images.".to_string()
            })
        })?;
        Ok(Some(target.to_string_lossy().into_owned()))
    })
    .await
    .map_err(|error| error.to_string())?
}
#[tauri::command]
async fn export_manuscript(
    filename: String,
    format: String,
    bytes: Option<Vec<u8>>,
    text: Option<String>,
) -> Result<Option<String>, String> {
    let bytes = export::document_bytes(&format, bytes, text)?;
    if !matches!(format.as_str(), "docx" | "md" | "png" | "html") {
        return Err("Unsupported export format.".into());
    }
    tauri::async_runtime::spawn_blocking(move || {
        let destination = platform::FileDialog::new()
            .set_file_name(&filename)
            .add_filter(
                if format == "docx" {
                    "Word document"
                } else if format == "html" {
                    "HTML document"
                } else if format == "png" {
                    "PNG image"
                } else {
                    "Markdown"
                },
                &[format.as_str()],
            )
            .save_file()?;
        let Some(mut path) = destination else {
            return Ok(None);
        };
        if path.extension().and_then(|value| value.to_str()) != Some(format.as_str()) {
            path.set_extension(&format);
        }
        export::write_new(&path, &bytes)?;
        Ok(Some(path.to_string_lossy().into_owned()))
    })
    .await
    .map_err(|e| e.to_string())?
}
#[tauri::command]
async fn prepare_project_open(path:String,state:tauri::State<'_,State>)->Result<&'static str,String>{
    let _guard=state.io.lock().map_err(|e|e.to_string())?;
    #[cfg(target_os="ios")]
    { Ok(if ios_directory::prepare(std::path::Path::new(&path))? {"ready"} else {"downloading"}) }
    #[cfg(not(target_os="ios"))]
    { let _=path;Ok("ready") }
}
#[tauri::command]
async fn open_project(
    app: tauri::AppHandle,
    path: String,
    state: tauri::State<'_, State>,
) -> Result<storage::OpenProject, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    let project = storage::open(std::path::Path::new(&path))?;
    history::capture(std::path::Path::new(&path), &project)?;
    if let Ok(data)=app.path().app_data_dir(){if let Err(error)=entry_images::collect_orphans(std::path::Path::new(&path),&project,&data){eprintln!("Image cleanup deferred: {error}");}}
    Ok(storage::OpenProject { path, project })
}
#[tauri::command]
async fn save_project(
    app: tauri::AppHandle,
    path: String,
    project: storage::Project,
    automatic: Option<bool>,
    state: tauri::State<'_, State>,
) -> Result<storage::Project, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    let root=std::path::Path::new(&path);
    let saved=if automatic.unwrap_or(false) {storage::save_automatic(root,project)?} else {storage::save(root, project)?};
    // Retention failure must never report an already committed save as failed.
    if let Err(error)=history::compact(root) { eprintln!("History retention deferred: {error}"); }
    if let Ok(data)=app.path().app_data_dir(){if let Err(error)=entry_images::collect_orphans(root,&saved,&data){eprintln!("Image cleanup deferred: {error}");}}
    Ok(saved)
}
#[tauri::command]
async fn name_checkpoint(path: String, project_id: String, revision: u64, name: String, state: tauri::State<'_, State>) -> Result<(), String> {
    let _guard = state.io.lock().map_err(|e|e.to_string())?;
    history::name_checkpoint(std::path::Path::new(&path), &project_id, revision, &name)
}
#[tauri::command]
async fn list_versions(
    path: String,
    state: tauri::State<'_, State>,
) -> Result<Vec<history::Version>, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    let root=std::path::Path::new(&path);
    let current=storage::open(root)?;
    history::capture(root,&current)?;
    if let Err(error)=history::compact(root) {eprintln!("History retention deferred: {error}");}
    history::list(root)
}
#[tauri::command]
async fn read_version(
    path: String,
    revision: u64,
    state: tauri::State<'_, State>,
) -> Result<storage::Project, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    history::read(std::path::Path::new(&path), revision)
}
#[tauri::command]
async fn restore_version(
    path: String,
    revision: u64,
    expected_revision: u64,
    state: tauri::State<'_, State>,
) -> Result<storage::Project, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    history::restore(std::path::Path::new(&path), revision, expected_revision)
}
#[tauri::command]
async fn read_recent_projects(
    app: tauri::AppHandle,
    state: tauri::State<'_, State>,
) -> Result<Vec<recents::RecentProject>, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    recents::read(&app.path().app_data_dir().map_err(|e| e.to_string())?)
}
#[tauri::command]
async fn remember_recent_project(
    app: tauri::AppHandle,
    path: String,
    title: String,
    project_id: String,
    opened: bool,
    state: tauri::State<'_, State>,
) -> Result<Vec<recents::RecentProject>, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    recents::remember(
        &app.path().app_data_dir().map_err(|e| e.to_string())?,
        std::path::Path::new(&path),
        &project_id,
        &title,
        opened,
    )
}
#[tauri::command]
async fn forget_recent_project(
    app: tauri::AppHandle,
    path: String,
    state: tauri::State<'_, State>,
) -> Result<Vec<recents::RecentProject>, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    recents::forget(
        &app.path().app_data_dir().map_err(|e| e.to_string())?,
        &path,
    )
}
#[tauri::command]
async fn read_draft(
    app: tauri::AppHandle,
    state: tauri::State<'_, State>,
) -> Result<Option<storage::Draft>, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    storage::read_draft(&app.path().app_data_dir().map_err(|e| e.to_string())?)
}
#[tauri::command]
async fn write_draft(
    app: tauri::AppHandle,
    draft: Option<storage::Draft>,
    state: tauri::State<'_, State>,
) -> Result<(), String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    storage::write_draft(
        &app.path().app_data_dir().map_err(|e| e.to_string())?,
        draft,
    )
}
#[cfg(mobile)]
fn mobile_settings(app:&tauri::AppHandle)->Result<settings::Settings,String>{
    let root=app.path().app_data_dir().map_err(|e|e.to_string())?;
    let documents=app.path().document_dir().map_err(|e|e.to_string())?;
    #[cfg(target_os="ios")]
    { let selected=ios_directory::restore()?;settings::selected_mobile(&root,&documents,selected.as_deref()) }
    #[cfg(not(target_os="ios"))]
    { settings::ensure_local(&root,&documents) }
}
#[tauri::command]
async fn read_settings(
    app: tauri::AppHandle,
    state: tauri::State<'_, State>,
) -> Result<settings::Settings, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    #[cfg(desktop)]
    let root = app.path().app_data_dir().map_err(|e| e.to_string())?;
    #[cfg(mobile)]
    { mobile_settings(&app) }
    #[cfg(desktop)]
    { settings::read(&root) }
}
#[tauri::command]
async fn set_projects_directory(
    app: tauri::AppHandle,
    directory: String,
    state: tauri::State<'_, State>,
) -> Result<settings::Settings, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    #[cfg(all(mobile,not(target_os="ios")))]
    { let _ = directory; return settings::ensure_local(&app.path().app_data_dir().map_err(|e|e.to_string())?, &app.path().document_dir().map_err(|e|e.to_string())?); }
    #[cfg(target_os="ios")]
    {
        let root=app.path().app_data_dir().map_err(|e|e.to_string())?;
        let previous=settings::read(&root)?;
        let mut next=settings::set_directory(&root,std::path::Path::new(&directory))?;
        if let Err(error)=ios_directory::commit(&directory){
            if let Some(previous)=previous.projects_directory {let _=settings::set_directory(&root,std::path::Path::new(&previous));}
            return Err(error);
        }
        next.local_projects=true;next.external_projects=true;return Ok(next);
    }
    #[cfg(desktop)]
    settings::set_directory(
        &app.path().app_data_dir().map_err(|e| e.to_string())?,
        std::path::Path::new(&directory),
    )
}
#[tauri::command]
async fn create_project(
    app: tauri::AppHandle,
    project: storage::Project,
    folder_name: String,
    state: tauri::State<'_, State>,
) -> Result<storage::OpenProject, String> {
    let _guard = state.io.lock().map_err(|e| e.to_string())?;
    #[cfg(mobile)]
    mobile_settings(&app)?;
    settings::create(
        &app.path().app_data_dir().map_err(|e| e.to_string())?,
        project,
        &folder_name,
    )
}
#[tauri::command]
async fn list_local_projects(app: tauri::AppHandle, state: tauri::State<'_, State>) -> Result<Vec<recents::RecentProject>, String> {
    let _guard = state.io.lock().map_err(|e|e.to_string())?;
    #[cfg(mobile)]
    let settings=mobile_settings(&app)?;
    #[cfg(desktop)]
    let settings=settings::read(&app.path().app_data_dir().map_err(|e|e.to_string())?)?;
    let directory=settings.projects_directory.ok_or("Choose an existing projects folder.")?;
    #[cfg(target_os="ios")]
    { ios_directory::coordinate(std::path::Path::new(&directory),false,||settings::projects_in(std::path::Path::new(&directory))) }
    #[cfg(not(target_os="ios"))]
    { settings::projects_in(std::path::Path::new(&directory)) }
}
#[tauri::command]
fn exit_app(app: tauri::AppHandle, state: tauri::State<State>) -> Result<(), String> {
    #[cfg(desktop)]
    { state.exit.store(true, Ordering::SeqCst); app.exit(0); Ok(()) }
    #[cfg(mobile)]
    { let _ = (app, state); Err("Closing the app is managed by the system on mobile.".into()) }
}
#[cfg_attr(mobile, tauri::mobile_entry_point)]
pub fn run() {
    tauri::Builder::default()
        .manage(State::default())
        .setup(|app| {
            #[cfg(target_os = "ios")]
            app.handle().plugin(tauri_plugin_dialog::init())?;
            #[cfg(not(target_os = "ios"))]
            let _ = app;
            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            create_project_backup,
            restore_project_backup,
            choose_folder,
            choose_entry_image,
            choose_entry_images,
            store_entry_image,
            read_entry_image,
            export_manuscript,
            export_encyclopedia,
            open_project,
            prepare_project_open,
            save_project,
            exit_app,
            read_draft,
            write_draft,
            read_settings,
            list_local_projects,
            set_projects_directory,
            create_project,
            name_checkpoint,
            list_versions,
            read_version,
            restore_version,
            inspect_project_deletion,
            delete_project,
            load_entry_package,
            export_entry_package,
            load_template_package,
            export_template_package,
            read_recent_projects,
            remember_recent_project,
            forget_recent_project
        ])
        .on_window_event(|window, event| {
            #[cfg(mobile)]
            let _ = (window, event);
            #[cfg(desktop)]
            if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                api.prevent_close();
                let _ = window.emit("request-exit", ());
            }
        })
        .build(tauri::generate_context!())
        .expect("Failed to build Write Studio")
        .run(|app, event| {
            #[cfg(mobile)]
            let _ = (app, event);
            #[cfg(desktop)]
            if let tauri::RunEvent::ExitRequested { api, .. } = event {
                if !app.state::<State>().exit.load(Ordering::SeqCst) {
                    api.prevent_exit();
                    let _ = app.emit("request-exit", ());
                }
            }
        });
}

#[cfg(test)]
mod benchmark;
