use serde::{Deserialize,Serialize};
use std::collections::HashSet;

#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct IdeaCanvases {pub schema_version:u32,pub boards:Vec<IdeaCanvas>}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct IdeaCanvas {pub id:String,pub title:String,pub nodes:Vec<CanvasNode>,pub edges:Vec<CanvasEdge>}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct CanvasNode {
 pub id:String,pub kind:String,pub x:f64,pub y:f64,pub title:String,pub text:String,
 #[serde(default,skip_serializing_if="Option::is_none")]pub width:Option<f64>,
 #[serde(default,skip_serializing_if="Option::is_none")]pub height:Option<f64>,
 #[serde(default,skip_serializing_if="Option::is_none")]pub target_id:Option<String>,
 #[serde(default,skip_serializing_if="Option::is_none")]pub group_id:Option<String>,
}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct CanvasEdge {pub id:String,pub from:String,pub to:String,pub label:String}
pub fn validate(data:&IdeaCanvases,check:&mut impl FnMut(&str)->Result<(),String>)->Result<(),String>{
 if ![1,2].contains(&data.schema_version)||data.boards.len()>200{return Err("Invalid idea canvas schema or count.".into());}
 for board in &data.boards{
  check(&board.id)?;
  if board.title.trim().is_empty()||board.title.chars().count()>300||board.nodes.len()>500||board.edges.len()>2000{return Err("Invalid idea canvas.".into());}
  let nodes:HashSet<_>=board.nodes.iter().map(|node|node.id.as_str()).collect();
  for node in &board.nodes{
   check(&node.id)?;
   if !["note","group","entry","scene","event","idea","plot","image"].contains(&node.kind.as_str())||!node.x.is_finite()||!node.y.is_finite()||node.x<0.0||node.x>5760.0||node.y<0.0||node.y>3810.0||node.title.chars().count()>300||node.text.chars().count()>200000{return Err("Invalid canvas card.".into());}
   if data.schema_version<2&&(node.width.is_some()||node.height.is_some()){return Err("Canvas sizes require schemaVersion 2.".into());}
   let minimum_width:f64=if node.kind=="group"{320.0}else{240.0};
   let minimum_height:f64=if node.kind=="group"{240.0}else{190.0};
   if node.width.is_some_and(|value|!value.is_finite()||value<minimum_width.min(6000.0-node.x)||value>6000.0-node.x)||node.height.is_some_and(|value|!value.is_finite()||value<minimum_height.min(4000.0-node.y)||value>4000.0-node.y){return Err("Invalid canvas size.".into());}
   if ["note","group"].contains(&node.kind.as_str()){
    if node.title.trim().is_empty()||node.target_id.is_some(){return Err("Invalid canvas note.".into());}
   }else if !node.target_id.as_ref().is_some_and(|id|crate::entry_images::valid_id(id)){return Err("Invalid canvas reference.".into());}
   if let Some(group)=&node.group_id {
    if node.kind=="group"||!board.nodes.iter().any(|item|item.id==*group&&item.kind=="group"){return Err("Invalid canvas group.".into());}
   }
  }
  let mut pairs=HashSet::new();
  for edge in &board.edges{
   check(&edge.id)?;
   if !nodes.contains(edge.from.as_str())||!nodes.contains(edge.to.as_str())||edge.from==edge.to||edge.label.chars().count()>300||!pairs.insert((&edge.from,&edge.to)){return Err("Invalid canvas connection.".into());}
  }
 }
 Ok(())
}
pub fn image_ids(data:&IdeaCanvases)->impl Iterator<Item=&String>{
 data.boards.iter().flat_map(|board|board.nodes.iter()).filter(|node|node.kind=="image").filter_map(|node|node.target_id.as_ref())
}

#[cfg(test)]
mod tests{
 use crate::storage;
 use serde_json::json;
 fn fixture()->storage::Project{
  serde_json::from_value(json!({"schemaVersion":1,"id":"00000000-0000-0000-0000-000000000001","title":"Novel","revision":0,"chapters":[],"ideaCanvases":{"schemaVersion":1,"boards":[{"id":"00000000-0000-0000-0000-000000000002","title":"Caída de la capital 🌊","nodes":[{"id":"00000000-0000-0000-0000-000000000003","kind":"note","title":"Traición","text":"**Motivo** y contexto","x":40,"y":60},{"id":"00000000-0000-0000-0000-000000000004","kind":"entry","title":"","text":"","targetId":"00000000-0000-0000-0000-000000000099","x":400,"y":60}],"edges":[{"id":"00000000-0000-0000-0000-000000000005","from":"00000000-0000-0000-0000-000000000003","to":"00000000-0000-0000-0000-000000000004","label":"Posible causa"}]}]}})).unwrap()
 }
 #[test]
 fn canvas_save_history_recovery_backup_and_missing_targets(){
  let root=std::env::temp_dir().join(format!("write-studio-canvas-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();
  let mut project=fixture();storage::validate(&project,true).unwrap();
  assert!(project.idea_canvases.as_ref().unwrap().boards[0].nodes[0].width.is_none());
  let data=project.idea_canvases.as_mut().unwrap();data.schema_version=2;
  data.boards[0].nodes[0].width=Some(480.0);data.boards[0].nodes[0].height=Some(340.0);
  data.boards[0].nodes.push(serde_json::from_value(json!({"id":"00000000-0000-0000-0000-000000000006","kind":"group","title":"Alternatives","text":"","x":0,"y":0,"width":800,"height":600})).unwrap());
  data.boards[0].nodes[0].group_id=Some(data.boards[0].nodes[2].id.clone());
  storage::validate(&project,true).unwrap();
  let saved=storage::save(&root,project).unwrap();
  let expected=serde_json::to_value(&saved.idea_canvases).unwrap();
  assert_eq!(serde_json::to_value(storage::open(&root).unwrap().idea_canvases).unwrap(),expected);
  assert_eq!(serde_json::to_value(crate::history::read(&root,saved.revision).unwrap().idea_canvases).unwrap(),expected);
  storage::write_draft(&root.join("recovery"),Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:String::new()})).unwrap();
  assert_eq!(serde_json::to_value(storage::read_draft(&root.join("recovery")).unwrap().unwrap().project.idea_canvases).unwrap(),expected);
  let packet=root.with_extension("zip");crate::backup::create(&root,&packet,&saved.id,saved.revision).unwrap();
  let parent=root.join("restored");std::fs::create_dir_all(&parent).unwrap();
  let restored=crate::backup::restore(&packet,&parent).unwrap();
  assert_eq!(serde_json::to_value(restored.project.idea_canvases).unwrap(),expected);
  std::fs::remove_file(packet).unwrap();std::fs::remove_dir_all(root).unwrap();
 }
 #[test]
 fn canvas_rejects_invalid_geometry_groups_edges_and_duplicates(){
  let project=fixture();
  let mut bad=project.clone();bad.idea_canvases.as_mut().unwrap().boards[0].nodes[0].x=-1.0;assert!(storage::validate(&bad,true).is_err());
  let mut bad=project.clone();bad.idea_canvases.as_mut().unwrap().boards[0].nodes[0].x=f64::NAN;assert!(storage::validate(&bad,true).is_err());
  let mut bad=project.clone();bad.idea_canvases.as_mut().unwrap().boards[0].nodes[0].group_id=Some("missing".into());assert!(storage::validate(&bad,true).is_err());
  let mut bad=project.clone();bad.idea_canvases.as_mut().unwrap().boards[0].nodes[0].kind="combat".into();assert!(storage::validate(&bad,true).is_err());
  let mut bad=project.clone();bad.idea_canvases.as_mut().unwrap().boards[0].edges[0].to="missing".into();assert!(storage::validate(&bad,true).is_err());
  let mut bad=project.clone();bad.idea_canvases.as_mut().unwrap().boards[0].nodes[0].id=bad.id.clone();assert!(storage::validate(&bad,true).is_err());
  let mut bad=project.clone();bad.idea_canvases.as_mut().unwrap().boards[0].nodes[1].target_id=Some("../bad".into());assert!(storage::validate(&bad,true).is_err());
  let mut bad=project.clone();bad.idea_canvases.as_mut().unwrap().schema_version=3;assert!(storage::validate(&bad,true).is_err());
  let mut bad=project.clone();let mut edge=bad.idea_canvases.as_ref().unwrap().boards[0].edges[0].clone();edge.id="00000000-0000-0000-0000-000000000006".into();bad.idea_canvases.as_mut().unwrap().boards[0].edges.push(edge);assert!(storage::validate(&bad,true).is_err());
 }
 #[test]
 fn canvas_images_pin_assets_and_backup_checks_them(){
  let root=std::env::temp_dir().join(format!("write-studio-canvas-assets-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();
  let mut project=storage::save(&root,fixture()).unwrap();
  let id=project.idea_canvases.as_ref().unwrap().boards[0].nodes[1].target_id.clone().unwrap();
  project.idea_canvases.as_mut().unwrap().boards[0].nodes[1].kind="image".into();
  let folder=root.join("assets/images").join(&id);std::fs::create_dir_all(&folder).unwrap();std::fs::write(folder.join("image.png"),b"asset").unwrap();
  crate::entry_images::collect_removed(&root,&project,&[id.clone()]).unwrap();assert!(folder.exists());
  let mut unlinked=project.clone();unlinked.idea_canvases=None;
  crate::entry_images::collect_removed(&root,&unlinked,&[id]).unwrap();assert!(!folder.exists());
  let saved=storage::save(&root,project).unwrap();
  assert!(crate::backup::create(&root,&root.with_extension("zip"),&saved.id,saved.revision).is_err());
  std::fs::remove_dir_all(root).unwrap();
 }

 #[test]
 fn canvas_size_validation_and_schema_compatibility(){
  let mut project=fixture();project.idea_canvases.as_mut().unwrap().boards[0].nodes[0].width=Some(480.0);
  assert!(storage::validate(&project,true).is_err(),"Old schema cannot silently drop sizes");
  project.idea_canvases.as_mut().unwrap().schema_version=2;storage::validate(&project,true).unwrap();
  for value in [0.0,239.0,6001.0,f64::NAN,f64::INFINITY] {
   let mut bad=project.clone();bad.idea_canvases.as_mut().unwrap().boards[0].nodes[0].width=Some(value);assert!(storage::validate(&bad,true).is_err());
  }
  for value in [0.0,189.0,4001.0,f64::NAN] {
   let mut bad=project.clone();bad.idea_canvases.as_mut().unwrap().boards[0].nodes[0].height=Some(value);assert!(storage::validate(&bad,true).is_err());
  }
  let node=&mut project.idea_canvases.as_mut().unwrap().boards[0].nodes[0];node.x=5750.0;node.y=3800.0;node.width=Some(250.0);node.height=Some(200.0);
  storage::validate(&project,true).unwrap();
  project.idea_canvases.as_mut().unwrap().boards[0].nodes[0].width=Some(251.0);assert!(storage::validate(&project,true).is_err());
 }

}
