use crate::{recents, storage};
use serde::{Deserialize, Serialize};
use std::path::Path;

#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Target {
    pub path: String,
    pub project_id: String,
    pub title: String,
    pub revision: u64,
}
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Outcome {
    pub warning: String,
}
fn resolved_location(path: &Path) -> Result<std::path::PathBuf, String> {
    if path.exists() {
        return path.canonicalize().map_err(|e| e.to_string());
    }
    let parent = path.parent().ok_or("Invalid folder path")?;
    Ok(resolved_location(parent)?.join(path.file_name().ok_or("Invalid folder name")?))
}
#[cfg(desktop)]
pub fn move_to_trash(path: &Path) -> Result<(), String> {
    let context = trash::TrashContext::default();
    #[cfg(target_os = "macos")]
    let context = {
        use trash::macos::{DeleteMethod, TrashContextExtMacos};
        let mut context = context;
        context.set_delete_method(DeleteMethod::NsFileManager);
        context
    };
    context.delete(path).map_err(|e| e.to_string())
}
#[cfg(mobile)]
pub fn move_to_trash(_path: &Path) -> Result<(), String> {
    Err("Moving projects to system trash is not available in this mobile preview.".into())
}
pub fn inspect(path: &Path, app_data: &Path) -> Result<Target, String> {
    if std::fs::symlink_metadata(path)
        .map_err(|e| e.to_string())?
        .file_type()
        .is_symlink()
    {
        return Err("Select the original project folder, not a symbolic link.".into());
    }
    let root = path.canonicalize().map_err(|e| e.to_string())?;
    if root.parent().is_none()
        || resolved_location(app_data)?.starts_with(&root)
        || std::env::current_dir().is_ok_and(|cwd| cwd.starts_with(&root))
    {
        return Err("This folder cannot be deleted as a project.".into());
    }
    let project = storage::open(&root)?;
    Ok(Target {
        path: root.to_str().ok_or("Unsupported folder path")?.into(),
        project_id: project.id,
        title: project.title,
        revision: project.revision,
    })
}
pub fn remove_with(
    target: &Target,
    confirmation: &str,
    app_data: &Path,
    trash: impl FnOnce(&Path) -> Result<(), String>,
) -> Result<Outcome, String> {
    let expected = if target.title.is_empty() {
        "DELETE"
    } else {
        &target.title
    };
    if confirmation != expected {
        return Err("Type the exact project name to confirm.".into());
    }
    let current = inspect(Path::new(&target.path), app_data)?;
    if current.path != target.path
        || current.project_id != target.project_id
        || current.title != target.title
        || current.revision != target.revision
    {
        return Err("The project changed. Close this dialog and try again.".into());
    }
    // Read recovery before moving the folder, so matching uses its canonical path.
    let draft = storage::read_draft(app_data);
    let clear_recovery = draft
        .as_ref()
        .ok()
        .and_then(|v| v.as_ref())
        .is_some_and(|draft| {
            draft.project.id == target.project_id
                && Path::new(&draft.path)
                    .canonicalize()
                    .is_ok_and(|path| path == Path::new(&target.path))
        });
    trash(Path::new(&target.path))?;
    // Once Trash succeeds, cleanup errors must never masquerade as deletion failure.
    let mut warnings = Vec::new();
    if let Err(error) = recents::forget(app_data, &target.path) {
        warnings.push(format!("Recent list cleanup failed: {error}"));
    }
    if clear_recovery {
        if let Err(error) = storage::write_draft(app_data, None) {
            warnings.push(format!("Recovery cleanup failed: {error}"));
        }
    }
    if let Err(error) = draft {
        warnings.push(format!("Recovery could not be checked: {error}"));
    }
    Ok(Outcome {
        warning: warnings.join(" "),
    })
}

#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn confirmation_identity_failure_and_cleanup() {
        let base = std::env::temp_dir().join(format!("write-studio-delete-{}", std::process::id()));
        let root = base.join("project");
        let app = base.join("app-data");
        std::fs::create_dir_all(&root).unwrap();
        let project: storage::Project = serde_json::from_str(r#"{"schemaVersion":1,"id":"00000000-0000-0000-0000-000000000001","title":"My story","revision":0,"chapters":[]}"#).unwrap();
        let project = storage::save(&root, project).unwrap();
        recents::remember(&app, &root, &project.id, &project.title, true).unwrap();
        storage::write_draft(
            &app,
            Some(storage::Draft {
                project: project.clone(),
                path: root.to_str().unwrap().into(),
                selected_id: String::new(),
            }),
        )
        .unwrap();
        let target = inspect(&root, &app).unwrap();
        assert!(remove_with(&target, "my story", &app, |_| panic!("must not delete")).is_err());
        let mut wrong = target.clone();
        wrong.project_id = "different".into();
        assert!(remove_with(&wrong, "My story", &app, |_| panic!("must not delete")).is_err());
        wrong = target.clone();
        wrong.revision += 1;
        assert!(remove_with(&wrong, "My story", &app, |_| panic!("must not delete")).is_err());
        assert!(
            remove_with(&target, "My story", &app, |_| Err(
                "Trash unavailable".into()
            ))
            .is_err()
        );
        assert!(root.exists());
        assert_eq!(recents::read(&app).unwrap().len(), 1);
        assert!(storage::read_draft(&app).unwrap().is_some());
        let moved = base.join("mock-trash");
        let result = remove_with(&target, "My story", &app, |path| {
            std::fs::rename(path, &moved).map_err(|e| e.to_string())
        })
        .unwrap();
        assert!(result.warning.is_empty());
        assert!(!root.exists());
        assert!(moved.join("project.json").exists());
        assert!(recents::read(&app).unwrap().is_empty());
        assert!(storage::read_draft(&app).unwrap().is_none());
        std::fs::remove_dir_all(base).unwrap();
    }
    #[cfg(unix)]
    #[test]
    fn rejects_symlink_and_protected_ancestor() {
        let base =
            std::env::temp_dir().join(format!("write-studio-delete-paths-{}", std::process::id()));
        std::fs::create_dir_all(base.join("project")).unwrap();
        std::os::unix::fs::symlink(base.join("project"), base.join("link")).unwrap();
        assert!(
            inspect(&base.join("link"), &base.join("app"))
                .unwrap_err()
                .contains("symbolic")
        );
        assert!(
            inspect(&base, &base.join("app"))
                .unwrap_err()
                .contains("cannot be deleted")
        );
        std::fs::remove_dir_all(base).unwrap();
    }
}
