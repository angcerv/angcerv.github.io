use super::*;

#[test]
fn portable_paths_reject_devices_aliases_and_file_directory_collisions() {
    for name in ["assets/con", "assets/nul.PNG", "assets/aux/data", "assets/LPT³.txt",
        "assets/COM9/data", "assets/CONOUT$", "assets/a|b", "assets/a*b", "assets/a\"b"] {
        assert!(!safe_path(name), "{name}");
    }
    assert!(safe_path("assets/Árbol 世界 🌿/image.png"));
    assert!(safe_path("assets/company/com10.png"));
    for paths in [
        ["assets/Portrait/a.png", "assets/portrait/b.png"],
        ["assets/item", "assets/item/data.json"],
        ["assets/item/data.json", "assets/item"],
        ["assets/a.png", "assets/A.png"],
    ] {
        let mut names = PortableNames::default();
        names.insert(paths[0]).unwrap();
        assert!(names.insert(paths[1]).is_err());
    }
    let mut names = PortableNames::default();
    names.insert("assets/images/a.png").unwrap();
    names.insert("assets/images/b.png").unwrap();
}

fn verify_exchange(archive: &Path, expected: &storage::Project, parent: &Path) {
    fs::create_dir(parent).unwrap();
    let restored = restore(archive, parent).unwrap();
    let root = Path::new(&restored.path);
    assert_eq!(serde_json::to_value(&restored.project).unwrap(), serde_json::to_value(expected).unwrap());
    let mut zip = ZipArchive::new(File::open(archive).unwrap()).unwrap();
    let manifest = inspect(&mut zip).unwrap();
    for descriptor in &manifest.files {
        assert!(!descriptor.path.contains('\\'));
        let mut bytes = Vec::new();
        zip.by_name(&descriptor.path).unwrap().read_to_end(&mut bytes).unwrap();
        assert_eq!(fs::read(root.join(&descriptor.path)).unwrap(), bytes, "{}", descriptor.path);
    }
    // Device paths belong to this installation; canonical project IDs survive moving.
    let app_data = parent.join("Recovery local 世界");
    storage::write_draft(&app_data, Some(storage::Draft {
        project: restored.project.clone(), path: restored.path.clone(), selected_id: String::new(),
    })).unwrap();
    let draft = storage::read_draft(&app_data).unwrap().unwrap();
    assert_eq!(draft.path, restored.path);
    assert_eq!(draft.project.id, expected.id);
    let mut edited = draft.project;
    edited.chapters[0].scenes[0].content.as_mut().unwrap().push_str("\n\nEdición después del traslado 🌿");
    let saved = storage::save(root, edited).unwrap();
    assert_eq!(saved.revision, expected.revision + 1);
    assert_eq!(serde_json::to_value(storage::open(root).unwrap()).unwrap(), serde_json::to_value(saved).unwrap());
    storage::write_draft(&app_data, None).unwrap();
    assert!(storage::read_draft(&app_data).unwrap().is_none());
}

/// Ordinary tests exercise relocation locally. CI also exchanges these exact ZIPs
/// between macOS and Windows; no application or simulator is launched.
#[test]
fn portable_backup_exchange() {
    let (temporary, root, mut project) = super::tests::fixture();
    let timeline = project.timeline.as_mut().unwrap();
    timeline.schema_version = 6;
    timeline.calendar = Some(serde_json::from_value(serde_json::json!({
        "schemaVersion":2,"name":"Mareas 世界","mode":"fixed",
        "months":[{"name":"Alba","days":40},{"name":"Mar","days":20}],
        "weekdays":["Sol","Luna"],"epochYear":-120,"epochWeekday":1,
        "eras":[{"name":"Fundación","startYear":0}],
        "seasons":[{"name":"Lluvias","month":1,"day":1}],
        "holidays":[{"name":"Nueva marea","month":2,"day":20,"duration":3}]
    })).unwrap());
    let maps = project.maps.as_mut().unwrap();
    maps.schema_version = 17;
    maps.maps[0].regions.push(serde_json::from_value(serde_json::json!({
        "id":"00000000-0000-0000-0000-000000070001","title":"Reino 🌊","color":"teal",
        "points":[{"x":0.1,"y":0.1},{"x":0.8,"y":0.1},{"x":0.7,"y":0.8}],
        "labelPosition":{"x":0.4,"y":0.3}
    })).unwrap());
    project.idea_canvases = Some(serde_json::from_value(serde_json::json!({
        "schemaVersion":2,"boards":[{"id":"00000000-0000-0000-0000-000000070002",
        "title":"Planes 世界","edges":[],"nodes":[{
            "id":"00000000-0000-0000-0000-000000070003","kind":"note",
            "title":"Próxima escena","text":"Contexto 🌿","x":40,"y":60,"width":480,"height":240
        }]}]
    })).unwrap());
    let project = storage::save(&root, project).unwrap();
    let archive = temporary.0.join("portable.zip");
    create(&root, &archive, &project.id, project.revision).unwrap();
    verify_exchange(&archive, &project, &temporary.0.join("Otro dispositivo 世界"));
    assert_eq!(storage::open(&root).unwrap().revision, project.revision);
    if let Some(output) = std::env::var_os("WRITE_STUDIO_PORTABILITY_EXPORT") {
        let output = PathBuf::from(output);
        fs::create_dir_all(&output).unwrap();
        fs::copy(&archive, output.join("portable.zip")).unwrap();
        fs::write(output.join("expected.json"), serde_json::to_vec_pretty(&project).unwrap()).unwrap();
    }
    if let Some(input) = std::env::var_os("WRITE_STUDIO_PORTABILITY_IMPORT") {
        let mut count = 0;
        for source in fs::read_dir(input).unwrap() {
            let source = source.unwrap().path();
            if !source.is_dir() { continue; }
            let expected: storage::Project = serde_json::from_slice(&fs::read(source.join("expected.json")).unwrap()).unwrap();
            verify_exchange(&source.join("portable.zip"), &expected, &temporary.0.join(format!("Imported {count} 世界")));
            count += 1;
        }
        assert!(count >= 2, "CI must supply both macOS and Windows artifacts");
    }
}
