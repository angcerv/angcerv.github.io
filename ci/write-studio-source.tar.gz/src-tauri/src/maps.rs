#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct MapPoint {pub x:f64,pub y:f64}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct MapScale {pub from:MapPoint,pub to:MapPoint,pub aspect_ratio:f64,pub distance_km:f64,pub travel_km_per_day:f64}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct DrawingStroke {#[serde(default,skip_serializing_if="Option::is_none")]pub material_mask:Option<MaterialMask>,#[serde(default,skip_serializing_if="Option::is_none")]pub mask:Option<TerrainMask>,#[serde(default,skip_serializing_if="Option::is_none")]pub texture_scale:Option<f64>,#[serde(default,skip_serializing_if="Option::is_none")]pub texture_rotation:Option<f64>,#[serde(default,skip_serializing_if="Option::is_none")]pub opacity:Option<f64>,#[serde(default,skip_serializing_if="Option::is_none")]pub brush_shape:Option<String>,#[serde(default,skip_serializing_if="Option::is_none")]pub softness:Option<f64>,#[serde(default,skip_serializing_if="Option::is_none")]pub erase:Option<bool>,#[serde(default,skip_serializing_if="Option::is_none")]pub closed:Option<bool>,#[serde(default,skip_serializing_if="Option::is_none")]pub material:Option<String>,#[serde(default,skip_serializing_if="Option::is_none")]pub texture_intensity:Option<f64>,#[serde(default,skip_serializing_if="Option::is_none")]pub layer_id:Option<String>,#[serde(default,skip_serializing_if="Option::is_none")]pub color:Option<String>,pub kind:String,pub width:f64,pub points:Vec<MapPoint>}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct MaterialMask {pub id:String,pub target:String,pub groups:Vec<Vec<usize>>,pub water_background:bool}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct TerrainMask {pub points:Vec<MapPoint>,#[serde(default,skip_serializing_if="Vec::is_empty")]pub holes:Vec<Vec<MapPoint>>,#[serde(default,skip_serializing_if="is_false")]pub inverted:bool}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct SymbolPlacementSettings {pub continuous:bool,pub density:f64,pub size_variation:f64,pub rotation_variation:f64,pub base_size:f64,pub base_rotation:f64}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct DrawingObject {#[serde(default,skip_serializing_if="Option::is_none")]pub stamp:Option<SymbolPlacementSettings>,#[serde(default,skip_serializing_if="Option::is_none")]pub points:Option<Vec<MapPoint>>,#[serde(default,skip_serializing_if="Option::is_none")]pub smooth:Option<bool>,#[serde(default,skip_serializing_if="Option::is_none")]pub dashed:Option<bool>,#[serde(default,skip_serializing_if="Option::is_none")]pub rotation:Option<f64>,#[serde(default,skip_serializing_if="Option::is_none")]pub layer_id:Option<String>,#[serde(default,skip_serializing_if="Option::is_none")]pub fill:Option<String>,#[serde(default,skip_serializing_if="Option::is_none")]pub end_x:Option<f64>,#[serde(default,skip_serializing_if="Option::is_none")]pub end_y:Option<f64>,#[serde(default,skip_serializing_if="Option::is_none")]pub line_width:Option<f64>,#[serde(default,skip_serializing_if="Option::is_none")]pub color:Option<String>,#[serde(default,skip_serializing_if="Option::is_none")]pub halo:Option<String>,pub id:String,pub kind:String,pub x:f64,pub y:f64,pub size:f64,#[serde(default,skip_serializing_if="Option::is_none")]pub text:Option<String>}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct MapDrawing {#[serde(default,skip_serializing_if="Option::is_none")]pub texture_frame:Option<MapImageFrame>,#[serde(default,skip_serializing_if="Option::is_none")]pub terrain_colors:Option<std::collections::BTreeMap<String,String>>,#[serde(default,skip_serializing_if="Option::is_none")]pub theme:Option<String>,#[serde(default,skip_serializing_if="Option::is_none")]pub background:Option<String>,pub width:u32,pub height:u32,pub strokes:Vec<DrawingStroke>,pub objects:Vec<DrawingObject>}
use serde::{Deserialize, Serialize};
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct MarkerLabelOffset {pub angle:f64,pub distance:f64}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct Marker {
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub label_offset:Option<MarkerLabelOffset>,
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub layer_id:Option<String>,
    pub id: String,
    pub title: String,
    pub notes: String,
    pub x: f64,
    pub y: f64,
    pub color: String,
    pub icon: String,
    #[serde(default, skip_serializing_if = "Option::is_none")]
    pub entry_id: Option<String>,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct MapRoute {
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub departure:Option<crate::timeline::StoryDate>,
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub arrival:Option<crate::timeline::StoryDate>,
    #[serde(default,skip_serializing_if="Vec::is_empty")]
    pub scene_ids:Vec<String>,
    #[serde(default,skip_serializing_if="Vec::is_empty")]
    pub chapter_ids:Vec<String>,
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub layer_id:Option<String>,
    pub id: String,
    pub title: String,
    pub color: String,
    pub marker_ids: Vec<String>,
    pub notes: String,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct MapLayer {pub id:String,pub title:String,pub visible:bool,#[serde(default,skip_serializing_if="is_false")]pub locked:bool}
fn is_false(value:&bool)->bool{!*value}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct MapRegion {
 pub id:String,pub title:String,pub color:String,pub points:Vec<MapPoint>,
 #[serde(default,skip_serializing_if="Vec::is_empty")]pub holes:Vec<Vec<MapPoint>>,
 #[serde(default,skip_serializing_if="Option::is_none")]pub label_position:Option<MapPoint>,
 #[serde(default,skip_serializing_if="Option::is_none")]pub entry_id:Option<String>,
 #[serde(default,skip_serializing_if="Option::is_none")]pub layer_id:Option<String>,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct MapImageFrame {pub x:f64,pub y:f64,pub width:f64,pub height:f64}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct WorldMap {
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub image_frame:Option<MapImageFrame>,
    #[serde(default,skip_serializing_if="Vec::is_empty")]
    pub regions:Vec<MapRegion>,
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub drawing:Option<MapDrawing>,
    #[serde(default,skip_serializing_if="Option::is_none")]
    pub scale:Option<MapScale>,
    #[serde(default,skip_serializing_if="Vec::is_empty")]
    pub layers:Vec<MapLayer>,
    pub id: String,
    pub title: String,
    pub notes: String,
    pub image_id: String,
    pub markers: Vec<Marker>,
    #[serde(default, skip_serializing_if = "Vec::is_empty")]
    pub routes: Vec<MapRoute>,
}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct TrashedMap {pub map:WorldMap,pub deleted_at:u64}
#[derive(Clone, Debug, Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
pub struct ProjectMaps {
    #[serde(default,skip_serializing_if="Vec::is_empty")]
    pub trash:Vec<TrashedMap>,
    pub schema_version: u32,
    pub maps: Vec<WorldMap>,
}
pub fn valid_region_points(points:&[MapPoint])->bool {
 if points.len()<3||points.len()>128||points.iter().any(|p|!p.x.is_finite()||!p.y.is_finite()||!(0.0..=1.0).contains(&p.x)||!(0.0..=1.0).contains(&p.y)){return false;}
 for i in 0..points.len(){for j in i+1..points.len(){if points[i].x==points[j].x&&points[i].y==points[j].y{return false;}}}
 fn cross(a:&MapPoint,b:&MapPoint,c:&MapPoint)->f64{(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x)}
 fn on(a:&MapPoint,b:&MapPoint,c:&MapPoint)->bool{cross(a,b,c).abs()<1e-12&&c.x>=a.x.min(b.x)&&c.x<=a.x.max(b.x)&&c.y>=a.y.min(b.y)&&c.y<=a.y.max(b.y)}
 let n=points.len();
 for i in 0..n{for j in i+1..n{
  if j==i+1||i==0&&j==n-1{continue;}
  let (a,b,c,d)=(&points[i],&points[(i+1)%n],&points[j],&points[(j+1)%n]);
  if cross(a,b,c)*cross(a,b,d)<0.0&&cross(c,d,a)*cross(c,d,b)<0.0||on(a,b,c)||on(a,b,d)||on(c,d,a)||on(c,d,b){return false;}
 }}
 points.iter().enumerate().map(|(i,p)|p.x*points[(i+1)%n].y-p.y*points[(i+1)%n].x).sum::<f64>().abs()>1e-10
}
fn point_in_ring(p:&MapPoint,ring:&[MapPoint])->bool {
 let mut inside=false;
 for i in 0..ring.len(){let a=&ring[i];let b=&ring[(i+1)%ring.len()];
 let cross=(b.x-a.x)*(p.y-a.y)-(b.y-a.y)*(p.x-a.x);
 if cross.abs()<1e-12&&p.x>=a.x.min(b.x)&&p.x<=a.x.max(b.x)&&p.y>=a.y.min(b.y)&&p.y<=a.y.max(b.y){return false;}
 if (a.y>p.y)!=(b.y>p.y)&&p.x<(b.x-a.x)*(p.y-a.y)/(b.y-a.y)+a.x{inside=!inside;}}
 inside
}
fn rings_intersect(a:&[MapPoint],b:&[MapPoint])->bool {
 fn cross(p:&MapPoint,q:&MapPoint,r:&MapPoint)->f64{(q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x)}
 fn on(p:&MapPoint,q:&MapPoint,r:&MapPoint)->bool{cross(p,q,r).abs()<1e-12&&r.x>=p.x.min(q.x)&&r.x<=p.x.max(q.x)&&r.y>=p.y.min(q.y)&&r.y<=p.y.max(q.y)}
 (0..a.len()).any(|i|(0..b.len()).any(|j|{let (p,q,r,s)=(&a[i],&a[(i+1)%a.len()],&b[j],&b[(j+1)%b.len()]);cross(p,q,r)*cross(p,q,s)<0.0&&cross(r,s,p)*cross(r,s,q)<0.0||on(p,q,r)||on(p,q,s)||on(r,s,p)||on(r,s,q)}))
}
fn valid_polygon_geometry(points:&[MapPoint],holes:&[Vec<MapPoint>])->bool {
 valid_region_points(points)&&holes.len()<=16&&holes.iter().enumerate().all(|(i,hole)|valid_region_points(hole)&&point_in_ring(&hole[0],points)&&!rings_intersect(hole,points)&&holes[..i].iter().all(|other|!rings_intersect(hole,other)&&!point_in_ring(&hole[0],other)&&!point_in_ring(&other[0],hole)))
}
pub fn valid_region_geometry(region:&MapRegion)->bool {valid_polygon_geometry(&region.points,&region.holes)}
pub fn validate(
    maps: &ProjectMaps,
    check: &mut impl FnMut(&str) -> Result<(), String>,
) -> Result<(), String> {
    if ![1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28].contains(&maps.schema_version) {
        return Err("Unsupported maps schemaVersion.".into());
    }
    if !maps.trash.is_empty()&&maps.schema_version<16{return Err("Map trash requires schemaVersion 16.".into());}
    if maps.trash.iter().any(|item|item.deleted_at>9_007_199_254_740_991){return Err("Invalid map deletion date.".into());}
    for map in maps.maps.iter().chain(maps.trash.iter().map(|item|&item.map)) {
        check(&map.id)?;
        if let Some(frame)=&map.image_frame {
            if maps.schema_version<20||map.drawing.is_none()||[frame.x,frame.y,frame.width,frame.height].iter().any(|v|!v.is_finite())||frame.x<0.0||frame.y<0.0||frame.width<=0.0||frame.height<=0.0||frame.x+frame.width>1.0+1e-12||frame.y+frame.height>1.0+1e-12{return Err("Invalid map image frame.".into());}
        }
        if let Some(drawing)=&map.drawing {
            if let Some(frame)=&drawing.texture_frame {
                if maps.schema_version<20||[frame.x,frame.y,frame.width,frame.height].iter().any(|v|!v.is_finite())||frame.x<0.0||frame.y<0.0||frame.width<=0.0||frame.height<=0.0||frame.x+frame.width>drawing.width as f64+1e-9||frame.y+frame.height>drawing.height as f64+1e-9{return Err("Invalid map texture frame.".into());}
            }
            let point=|x:f64,y:f64|x.is_finite()&&y.is_finite()&&(0.0..=1.0).contains(&x)&&(0.0..=1.0).contains(&y);
            if maps.schema_version<7 || drawing.width==0 || drawing.height==0 || drawing.width>if maps.schema_version>=20 {4096}else{2048} || drawing.height>if maps.schema_version>=20 {4096}else{2048} || drawing.strokes.len()>500 || drawing.objects.len()>500 || drawing.strokes.iter().map(|stroke|stroke.points.len()).sum::<usize>()>200_000 {return Err("Invalid map drawing dimensions or limits.".into());}
            let color=|value:&Option<String>|value.as_ref().is_none_or(|value|value.len()==7&&value.starts_with('#')&&value.as_bytes()[1..].iter().all(|c|c.is_ascii_hexdigit()));
            if let Some(palette)=&drawing.terrain_colors {
                if maps.schema_version<10||palette.len()>6||palette.iter().any(|(kind,value)|!["land","water","park","road","nebula","region"].contains(&kind.as_str())||!color(&Some(value.clone()))) {return Err("Invalid terrain palette.".into());}
            }
            if drawing.theme.as_ref().is_some_and(|theme|!["medieval","modern","futuristic","space"].contains(&theme.as_str())) || !color(&drawing.background) {return Err("Invalid map theme or color.".into());}
            if maps.schema_version<8 && (drawing.theme.is_some()||drawing.background.is_some()||drawing.strokes.iter().any(|stroke|stroke.color.is_some()||!["land","water"].contains(&stroke.kind.as_str()))||drawing.objects.iter().any(|object|object.color.is_some()||object.halo.is_some()||!["mountain","forest","village","tower","ruins","label"].contains(&object.kind.as_str()))) {return Err("Map themes require schemaVersion 8.".into());}
            let mut material_mask_ids=std::collections::HashSet::new();
            for (stroke_index,stroke) in drawing.strokes.iter().enumerate() {
                if let Some(mask)=&stroke.material_mask {
                    let mut sources=std::collections::HashSet::new();
                    if maps.schema_version<28||!material_mask_ids.insert(&mask.id)||!crate::entry_images::valid_id(&mask.id)||!["land","water","sea","earth","sand","grass","rock","mud","pavement","cityWater","park","asphalt","alloy","canal","district","transit","nebula","spaceRegion","deepSpace"].contains(&mask.target.as_str())||mask.groups.len()>501||mask.groups.iter().any(|group|group.is_empty()||group.len()>500||group.windows(2).any(|pair|pair[0]>=pair[1])||group.iter().any(|index|*index>=stroke_index||!sources.insert(*index))){return Err("Invalid material mask.".into());}
                }
                if let Some(mask)=&stroke.mask {if maps.schema_version<27||!valid_polygon_geometry(&mask.points,&mask.holes){return Err("Invalid terrain mask.".into());}}
                if (stroke.texture_scale.is_some()||stroke.texture_rotation.is_some())&&(maps.schema_version<26||stroke.material.is_none()||stroke.erase==Some(true)||stroke.texture_scale.is_some_and(|value|!value.is_finite()||!(0.25..=4.0).contains(&value))||stroke.texture_rotation.is_some_and(|value|!value.is_finite()||!(0.0..360.0).contains(&value))){return Err("Invalid terrain texture placement.".into());}

                if stroke.opacity.is_some_and(|opacity|maps.schema_version<25||!opacity.is_finite()||!(0.0..=1.0).contains(&opacity)){return Err("Invalid terrain opacity.".into());}
                if stroke.brush_shape.is_some()||stroke.softness.is_some(){
                    if maps.schema_version<23||(stroke.brush_shape.as_deref()==Some("irregular")&&maps.schema_version<24)||stroke.closed==Some(true)||stroke.brush_shape.as_ref().is_some_and(|shape|!["circle","star","irregular"].contains(&shape.as_str()))||stroke.softness.is_some_and(|softness|!softness.is_finite()||!(0.0..=1.0).contains(&softness)||matches!(stroke.brush_shape.as_deref(),Some("star"|"irregular"))){return Err("Invalid terrain brush shape or softness.".into());}
                }
                if (stroke.erase.is_some()||stroke.closed.is_some())&&maps.schema_version<21{return Err("Terrain contours and erasure require schemaVersion 21.".into());}
                if stroke.erase==Some(true)&&(stroke.closed==Some(true)||stroke.material.is_some()||stroke.texture_intensity.is_some()||stroke.color.is_some()){return Err("Invalid terrain eraser.".into());}
                if stroke.closed==Some(true)&&(stroke.points.len()<3||stroke.points.iter().enumerate().map(|(i,p)|{let q=&stroke.points[(i+1)%stroke.points.len()];p.x*q.y-q.x*p.y}).sum::<f64>().abs()<1e-12){return Err("Invalid filled terrain contour.".into());}

                if let Some(material)=&stroke.material {
                    let medieval=["sea","earth","sand","grass","rock","mud"].contains(&material.as_str());
                    let themed=["pavement","cityWater","park","asphalt","alloy","canal","district","transit","nebula","spaceRegion","deepSpace"].contains(&material.as_str());
                    if (medieval&&maps.schema_version<14)||(themed&&maps.schema_version<15)||(!medieval&&!themed){return Err("Invalid terrain material.".into());}
                }
                if stroke.texture_intensity.is_some_and(|value|stroke.material.is_none()||maps.schema_version<14||!value.is_finite()||!(0.0..=1.0).contains(&value)){return Err("Invalid terrain texture intensity.".into());}

                if !["land","water","park","road","nebula","region"].contains(&stroke.kind.as_str()) || !color(&stroke.color) || !stroke.width.is_finite() || !(if maps.schema_version>=20 {0.0000001}else{0.005}..=0.25).contains(&stroke.width) || stroke.points.is_empty() || stroke.points.len()>2000 || stroke.points.iter().any(|p|!point(p.x,p.y)) {return Err("Invalid map drawing stroke.".into());}
            }
            for object in &drawing.objects {
                if let Some(stamp)=&object.stamp {if maps.schema_version<26||["label","line","ellipse","path"].contains(&object.kind.as_str())||!stamp.density.is_finite()||!(0.1..=1.0).contains(&stamp.density)||!stamp.size_variation.is_finite()||!(0.0..=0.5).contains(&stamp.size_variation)||!stamp.rotation_variation.is_finite()||!(0.0..=180.0).contains(&stamp.rotation_variation)||!stamp.base_size.is_finite()||!(0.0000001..=0.25).contains(&stamp.base_size)||!stamp.base_rotation.is_finite()||!(0.0..360.0).contains(&stamp.base_rotation){return Err("Invalid symbol placement settings.".into());}}

                check(&object.id)?;
                if maps.schema_version<12 && ["castle","windmill","cave","harbor","factory","school","stadium","police","biodome","robotics","skybridge","portal","asteroids","comet","spaceship","jumpGate"].contains(&object.kind.as_str()) {return Err("Extended map symbols require schemaVersion 12.".into());}
                if let Some(rotation)=object.rotation {if maps.schema_version<13||!rotation.is_finite()||!(0.0..360.0).contains(&rotation)||["label","line","ellipse","path"].contains(&object.kind.as_str()) {return Err("Invalid map symbol rotation.".into());}}
                if object.fill.is_some()&&(maps.schema_version<10||object.kind!="ellipse"||!color(&object.fill)) {return Err("Invalid map shape fill.".into());}
                if object.kind=="path" {
                    let valid=object.points.as_ref().is_some_and(|points|points.len()>=2&&points.len()<=256&&points.iter().all(|p|point(p.x,p.y))&&points[0].x==object.x&&points[0].y==object.y&&points.iter().any(|p|p.x!=object.x||p.y!=object.y));
                    if maps.schema_version<21||!valid||object.end_x.is_some()||object.end_y.is_some()||object.line_width.is_none_or(|w|!w.is_finite()||!(0.0000001..=0.02).contains(&w)){return Err("Invalid map path.".into());}
                }else if object.points.is_some()||object.smooth.is_some()||object.dashed.is_some(){return Err("Unexpected map path geometry.".into());}
                let shape=["line","ellipse"].contains(&object.kind.as_str());
                if shape {
                    let valid=match (object.end_x,object.end_y,object.line_width) {(Some(x),Some(y),Some(width))=>point(x,y)&&width.is_finite()&&(if maps.schema_version>=20 {0.0000001}else{0.0005}..=0.02).contains(&width)&&if object.kind=="line" {x!=object.x||y!=object.y} else {x!=object.x&&y!=object.y},_=>false};
                    if maps.schema_version<9||!valid {return Err("Invalid map drawing shape.".into());}
                } else if object.kind!="path"&&(object.end_x.is_some()||object.end_y.is_some()||object.line_width.is_some()) {return Err("Unexpected map shape geometry.".into());}

                if !["mountain","forest","village","tower","ruins","building","hospital","station","airport","bridge","megatower","dome","spaceport","reactor","antenna","star","planet","moon","spaceStation","blackHole","galaxy","castle","windmill","cave","harbor","factory","school","stadium","police","biodome","robotics","skybridge","portal","asteroids","comet","spaceship","jumpGate","label","line","ellipse","path"].contains(&object.kind.as_str()) || !color(&object.color) || !color(&object.halo) || !point(object.x,object.y) || !object.size.is_finite() || !(if maps.schema_version>=20 {0.0000001}else{0.005}..=0.25).contains(&object.size) || object.text.as_ref().is_some_and(|text|text.chars().count()>160) || (object.kind=="label"&&object.text.is_none()) {return Err("Invalid map drawing element.".into());}
            }
        }
        if let Some(scale)=&map.scale {
            let valid_point=|p:&MapPoint|p.x.is_finite()&&p.y.is_finite()&&(0.0..=1.0).contains(&p.x)&&(0.0..=1.0).contains(&p.y);
            if maps.schema_version<4 || !valid_point(&scale.from) || !valid_point(&scale.to) || (scale.from.x==scale.to.x&&scale.from.y==scale.to.y) || [scale.aspect_ratio,scale.distance_km,scale.travel_km_per_day].iter().any(|v|!v.is_finite()||*v<=0.0) {return Err("Invalid map scale.".into());}
        }
        if !crate::entry_images::valid_id(&map.image_id) {
            return Err("Invalid map image identifier.".into());
        }
        if !map.routes.is_empty() && maps.schema_version < 2 {
            return Err("Map routes require schemaVersion 2.".into());
        }
        if maps.schema_version<3 && (!map.layers.is_empty() || map.markers.iter().any(|m|m.layer_id.is_some()) || map.routes.iter().any(|r|r.layer_id.is_some())) {return Err("Map layers require schemaVersion 3.".into());}
        let layer_ids:std::collections::HashSet<_>=map.layers.iter().map(|layer|layer.id.as_str()).collect();
        if maps.schema_version<11&&map.layers.iter().any(|layer|layer.locked) {return Err("Layer locking requires schemaVersion 11.".into());}
        if let Some(drawing)=&map.drawing {
            let refs:Vec<_>=drawing.strokes.iter().filter_map(|stroke|stroke.layer_id.as_ref()).chain(drawing.objects.iter().filter_map(|object|object.layer_id.as_ref())).collect();
            if (!refs.is_empty()&&maps.schema_version<11)||refs.iter().any(|id|!layer_ids.contains(id.as_str())) {return Err("Invalid drawing layer reference.".into());}
        }

        for layer in &map.layers {check(&layer.id)?;}
        if map.markers.iter().filter_map(|m|m.layer_id.as_ref()).chain(map.routes.iter().filter_map(|r|r.layer_id.as_ref())).any(|id|!layer_ids.contains(id.as_str())) {return Err("Invalid map layer reference.".into());}
        if !map.regions.is_empty()&&maps.schema_version<17{return Err("Map regions require schemaVersion 17.".into());}
        if map.regions.len()>200{return Err("Too many map regions.".into());}
        for region in &map.regions {
            check(&region.id)?;
            if !region.holes.is_empty()&&maps.schema_version<19{return Err("Region holes require schemaVersion 19.".into());}
            if region.label_position.as_ref().is_some_and(|p|!p.x.is_finite()||!p.y.is_finite()||!(0.0..=1.0).contains(&p.x)||!(0.0..=1.0).contains(&p.y))||region.title.chars().count()>300||!["teal","amber","blue","rose","violet","stone"].contains(&region.color.as_str())||!valid_region_geometry(region)||region.entry_id.as_ref().is_some_and(|id|!crate::entry_images::valid_id(id))||region.layer_id.as_ref().is_some_and(|id|!layer_ids.contains(id.as_str())){return Err("Invalid map region.".into());}
        }
        let marker_ids: std::collections::HashSet<_> = map.markers.iter().map(|marker| marker.id.as_str()).collect();
        for route in &map.routes {
            if (route.departure.is_some()||route.arrival.is_some())&&maps.schema_version<6 {return Err("Travel dates require schemaVersion 6.".into());}
            for value in [&route.departure,&route.arrival].into_iter().flatten(){crate::timeline::date(value)?;}

            if maps.schema_version<5 && (!route.scene_ids.is_empty()||!route.chapter_ids.is_empty()) {return Err("Route manuscript links require schemaVersion 5.".into());}
            for ids in [&route.scene_ids,&route.chapter_ids] {
                let unique:std::collections::HashSet<_>=ids.iter().collect();
                if unique.len()!=ids.len()||ids.iter().any(|id|!crate::entry_images::valid_id(id)) {return Err("Invalid route manuscript links.".into());}
            }
            check(&route.id)?;
            let unique: std::collections::HashSet<_> = route.marker_ids.iter().collect();
            if route.marker_ids.len() < 2 || unique.len() != route.marker_ids.len()
                || route.marker_ids.iter().any(|id| !marker_ids.contains(id.as_str()))
                || !["teal","amber","blue","rose","violet","stone"].contains(&route.color.as_str()) {
                return Err("Invalid map route stops or color.".into());
            }
        }
        for marker in &map.markers {
            check(&marker.id)?;
            if let Some(offset)=&marker.label_offset {
                if maps.schema_version<22||!offset.angle.is_finite()||!(0.0..360.0).contains(&offset.angle)||!offset.distance.is_finite()||!(8.0..=96.0).contains(&offset.distance){return Err("Invalid map marker label offset.".into());}
            }
            if !marker.x.is_finite()
                || !marker.y.is_finite()
                || !(0.0..=1.0).contains(&marker.x)
                || !(0.0..=1.0).contains(&marker.y)
            {
                return Err("Map marker coordinates must be between 0 and 1.".into());
            }
            if !["teal", "amber", "blue", "rose", "violet", "stone"]
                .contains(&marker.color.as_str())
                || !["pin", "city", "castle", "forest", "flag", "planet", "star", "moon", "satellite", "spaceship"].contains(&marker.icon.as_str())
            {
                return Err("Invalid map marker appearance.".into());
            }
            if maps.schema_version < 18 && ["planet", "star", "moon", "satellite", "spaceship"].contains(&marker.icon.as_str()) {
                return Err("Space marker icons require schemaVersion 18.".into());
            }
            if marker
                .entry_id
                .as_ref()
                .is_some_and(|id| !crate::entry_images::valid_id(id))
            {
                return Err("Invalid map entry reference.".into());
            }
        }
    }
    Ok(())
}

#[cfg(test)]
mod tests {
    use crate::{history, storage};
    use std::fs;
    fn fixture() -> storage::Project {
        serde_json::from_value(serde_json::json!({"schemaVersion":1,"id":"00000000-0000-0000-0000-000000000001","title":"Atlas 世界","revision":0,"chapters":[],"maps":{"schemaVersion":1,"maps":[{"id":"00000000-0000-0000-0000-000000000002","title":"North coast","notes":"Sea route","imageId":"00000000-0000-0000-0000-000000000003","markers":[{"id":"00000000-0000-0000-0000-000000000004","title":"Harbor","notes":"Arrival","x":0.25,"y":0.8,"color":"teal","icon":"city","entryId":"00000000-0000-0000-0000-000000000005"}]}]}})).unwrap()
    }
    fn route_fixture() -> storage::Project {
        let mut project = fixture();
        let maps = project.maps.as_mut().unwrap();
        maps.schema_version = 2;
        let map = &mut maps.maps[0];
        let mut other = map.markers[0].clone();
        other.id = "00000000-0000-0000-0000-000000000006".into();
        other.x = 0.75;
        map.markers.push(other);
        map.routes.push(super::MapRoute {departure:None,arrival:None, scene_ids:vec![],chapter_ids:vec![],layer_id:None,id: "00000000-0000-0000-0000-000000000007".into(), title: "Journey".into(), color: "amber".into(), marker_ids: map.markers.iter().rev().map(|m|m.id.clone()).collect(), notes: "Via the coast".into() });
        project
    }
    fn layer_fixture()->storage::Project{
        let mut project=route_fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=3;
        let map=&mut maps.maps[0];
        map.layers=vec![super::MapLayer{locked:false,id:"00000000-0000-0000-0000-000000000008".into(),title:"Cities 世界".into(),visible:false},super::MapLayer{locked:false,id:"00000000-0000-0000-0000-000000000009".into(),title:"Thomas journey".into(),visible:true}];
        map.markers[0].layer_id=Some(map.layers[0].id.clone());map.routes[0].layer_id=Some(map.layers[1].id.clone());project
    }
    #[test]
    fn map_trash_preserves_complete_maps_and_expires_without_changing_history(){
        let mut project=layer_fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=16;
        maps.maps[0].drawing=Some(drawing_fixture());
        let original=maps.maps.remove(0);let now=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_millis() as u64;
        maps.trash.push(super::TrashedMap{map:original.clone(),deleted_at:now});storage::validate(&project,true).unwrap();
        let root=std::env::temp_dir().join(format!("write-map-trash-{}",std::process::id()));fs::create_dir_all(&root).unwrap();
        let saved=storage::save(&root,project.clone()).unwrap();let reopened=storage::open(&root).unwrap();
        assert_eq!(serde_json::to_value(&reopened).unwrap(),serde_json::to_value(&saved).unwrap());
        assert_eq!(serde_json::to_value(&reopened.maps.as_ref().unwrap().trash[0].map).unwrap(),serde_json::to_value(&original).unwrap());
        let old=history::read(&root,saved.revision).unwrap();assert_eq!(old.maps.as_ref().unwrap().trash.len(),1);
        let mut restored=saved.clone();let maps=restored.maps.as_mut().unwrap();maps.maps.push(maps.trash.remove(0).map);storage::validate(&restored,true).unwrap();
        let mut duplicate=restored.clone();duplicate.maps.as_mut().unwrap().trash.push(super::TrashedMap{map:original.clone(),deleted_at:now});assert!(storage::validate(&duplicate,true).is_err());
        let mut expired=saved.clone();expired.maps.as_mut().unwrap().trash[0].deleted_at=1;
        let expired=storage::save(&root,expired).unwrap();assert!(expired.maps.as_ref().unwrap().trash.is_empty());assert!(history::read(&root,saved.revision).unwrap().maps.as_ref().unwrap().trash.len()==1);
        let mut old_schema=project.clone();old_schema.maps.as_mut().unwrap().schema_version=15;assert!(storage::validate(&old_schema,true).is_err());
        fs::remove_dir_all(root).unwrap();
    }
    fn drawing_fixture()->super::MapDrawing {
        serde_json::from_value(serde_json::json!({"width":1600,"height":1000,"strokes":[{"kind":"land","width":0.1,"points":[{"x":0.2,"y":0.3},{"x":0.4,"y":0.5}]},{"kind":"water","width":0.02,"points":[{"x":0.3,"y":0.4}]}],"objects":[{"id":"00000000-0000-0000-0000-000000000030","kind":"mountain","x":0.5,"y":0.5,"size":0.06},{"id":"00000000-0000-0000-0000-000000000031","kind":"label","x":0.2,"y":0.8,"size":0.02,"text":"Sea 世界"}]})).unwrap()
    }
    #[test]
    fn terrain_materials_validate_and_roundtrip_without_touching_legacy_strokes() {
        let mut project=fixture();project.maps.as_mut().unwrap().schema_version=14;
        let mut drawing=drawing_fixture();drawing.strokes[0].material=Some("grass".into());drawing.strokes[0].texture_intensity=Some(0.65);
        project.maps.as_mut().unwrap().maps[0].drawing=Some(drawing);
        storage::validate(&project,true).unwrap();
        let root=std::env::temp_dir().join(format!("write-materials-{}",std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let saved=storage::save(&root,project.clone()).unwrap();
        let reopened=storage::open(&root).unwrap();
        assert_eq!(serde_json::to_value(&saved.maps).unwrap(),serde_json::to_value(&reopened.maps).unwrap());
        assert_eq!(serde_json::to_value(&crate::history::read(&root,saved.revision).unwrap().maps).unwrap(),serde_json::to_value(&saved.maps).unwrap());
        for case in ["version","material","negative","large","nan","orphan"] {
            let mut invalid=project.clone();let maps=invalid.maps.as_mut().unwrap();let stroke=&mut maps.maps[0].drawing.as_mut().unwrap().strokes[0];
            match case {"version"=>maps.schema_version=13,"material"=>stroke.material=Some("url(bad)".into()),"negative"=>stroke.texture_intensity=Some(-0.1),"large"=>stroke.texture_intensity=Some(1.1),"nan"=>stroke.texture_intensity=Some(f64::NAN),_=>stroke.material=None}
            assert!(storage::validate(&invalid,true).is_err(),"{case}");
        }
        for kind in ["sea","earth","sand","grass","rock","mud"] {
            let stroke=&mut project.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().strokes[0];stroke.material=Some(kind.into());
            storage::validate(&project,true).unwrap();
        }
        let mut expanded=reopened;
        expanded.maps.as_mut().unwrap().schema_version=15;
        let materials=["pavement","cityWater","park","asphalt","alloy","canal","district","transit","nebula","spaceRegion","deepSpace"];
        for material in materials {
            let mut stroke=expanded.maps.as_ref().unwrap().maps[0].drawing.as_ref().unwrap().strokes[0].clone();
            stroke.material=Some(material.into());
            expanded.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().strokes.push(stroke);
        }
        storage::validate(&expanded,true).unwrap();
        let mut old_version=expanded.clone();old_version.maps.as_mut().unwrap().schema_version=14;
        assert!(storage::validate(&old_version,true).is_err());
        let saved=storage::save(&root,expanded).unwrap();let reopened=storage::open(&root).unwrap();
        assert_eq!(serde_json::to_value(&saved.maps).unwrap(),serde_json::to_value(&reopened.maps).unwrap());
        assert_eq!(serde_json::to_value(&crate::history::read(&root,saved.revision).unwrap().maps).unwrap(),serde_json::to_value(&saved.maps).unwrap());
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn fills_and_terrain_palettes_validate_color_kind_and_version() {
        let mut project=fixture();project.maps.as_mut().unwrap().schema_version=10;
        let mut drawing=drawing_fixture();drawing.terrain_colors=Some(std::collections::BTreeMap::from([("land".into(),"#112233".into()),("water".into(),"#b9d9df".into())]));drawing.objects.push(serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000032","kind":"ellipse","x":0.1,"y":0.2,"endX":0.7,"endY":0.8,"size":0.065,"lineWidth":0.003,"color":"#123456","fill":"#112233"})).unwrap());project.maps.as_mut().unwrap().maps[0].drawing=Some(drawing);storage::validate(&project,true).unwrap();
        for case in ["version","fill","line","palette-color","palette-kind"] {
            let mut invalid=project.clone();let maps=invalid.maps.as_mut().unwrap();let drawing=maps.maps[0].drawing.as_mut().unwrap();
            match case {"version"=>maps.schema_version=9,"fill"=>drawing.objects[2].fill=Some("url(bad)".into()),"line"=>drawing.objects[2].kind="line".into(),"palette-color"=>{drawing.terrain_colors.as_mut().unwrap().insert("land".into(),"bad".into());},_=>{drawing.terrain_colors.as_mut().unwrap().insert("unknown".into(),"#112233".into());}}
            assert!(storage::validate(&invalid,true).is_err(),"{case}");
        }
    }
    #[test]
    fn shapes_validate_geometry_width_and_schema() {
        let mut project=fixture();project.maps.as_mut().unwrap().schema_version=9;
        let mut drawing=drawing_fixture();drawing.objects.push(serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000032","kind":"line","x":0.1,"y":0.2,"endX":0.7,"endY":0.8,"size":0.065,"lineWidth":0.003,"color":"#123456"})).unwrap());project.maps.as_mut().unwrap().maps[0].drawing=Some(drawing);storage::validate(&project,true).unwrap();
        for case in ["version","end","width","missing","zero-line","zero-ellipse","unexpected"] {
            let mut invalid=project.clone();let maps=invalid.maps.as_mut().unwrap();let object=&mut maps.maps[0].drawing.as_mut().unwrap().objects[2];
            match case {"version"=>maps.schema_version=8,"end"=>object.end_x=Some(1.1),"width"=>object.line_width=Some(0.0),"missing"=>object.end_y=None,"zero-line"=>{object.end_x=Some(object.x);object.end_y=Some(object.y);},"zero-ellipse"=>{object.kind="ellipse".into();object.end_y=Some(object.y);},_=>object.kind="mountain".into()}
            assert!(storage::validate(&invalid,true).is_err(),"{case}");
        }
    }
    #[test]
    fn themes_validate_colors_symbols_and_preserve_legacy_drawings() {
        let mut project=fixture();project.maps.as_mut().unwrap().schema_version=8;
        let mut drawing=drawing_fixture();drawing.theme=Some("space".into());drawing.background=Some("#101629".into());drawing.strokes[0].kind="nebula".into();drawing.strokes[0].color=Some("#5f417b".into());drawing.objects[0].kind="planet".into();drawing.objects[1].color=Some("#e3e9ff".into());drawing.objects[1].halo=Some("#101629".into());project.maps.as_mut().unwrap().maps[0].drawing=Some(drawing);storage::validate(&project,true).unwrap();
        for case in ["theme","color","stroke-color","halo","version"] {
            let mut invalid=project.clone();let maps=invalid.maps.as_mut().unwrap();let drawing=maps.maps[0].drawing.as_mut().unwrap();
            match case {"theme"=>drawing.theme=Some("unknown".into()),"color"=>drawing.background=Some("url(bad)".into()),"stroke-color"=>drawing.strokes[0].color=Some("#123".into()),"halo"=>drawing.objects[1].halo=Some("bad".into()),_=>maps.schema_version=7}
            assert!(storage::validate(&invalid,true).is_err(),"{case}");
        }
    }
    #[test]
    fn drawings_validate_geometry_kinds_schema_limits_and_ids() {
        let mut project=fixture();project.maps.as_mut().unwrap().schema_version=7;project.maps.as_mut().unwrap().maps[0].drawing=Some(drawing_fixture());storage::validate(&project,true).unwrap();
        for case in ["version","width","point","empty","size","kind","duplicate","label","stroke-limit","point-limit"] {
            let mut invalid=project.clone();let maps=invalid.maps.as_mut().unwrap();let drawing=maps.maps[0].drawing.as_mut().unwrap();
            match case {
                "version"=>maps.schema_version=6,"width"=>drawing.width=0,"point"=>drawing.strokes[0].points[0].x=f64::NAN,"empty"=>drawing.strokes[0].points.clear(),"size"=>drawing.objects[0].size=-1.0,"kind"=>drawing.objects[0].kind="script".into(),"duplicate"=>drawing.objects[1].id=drawing.objects[0].id.clone(),"label"=>drawing.objects[1].text=Some("a".repeat(161)),"stroke-limit"=>drawing.strokes=vec![drawing.strokes[0].clone();501],_=>drawing.strokes[0].points=vec![super::MapPoint{x:0.1,y:0.1};2001]
            }
            assert!(storage::validate(&invalid,true).is_err(),"{case}");
        }
        assert!(fixture().maps.unwrap().maps[0].drawing.is_none());
    }
    #[test]
    fn map_layers_validate_local_links_schema_and_unique_ids(){
        let original=layer_fixture();storage::validate(&original,true).unwrap();
        let mut invalid=original.clone();invalid.maps.as_mut().unwrap().schema_version=2;assert!(storage::validate(&invalid,true).is_err());
        let mut invalid=original.clone();invalid.maps.as_mut().unwrap().maps[0].markers[0].layer_id=Some("00000000-0000-0000-0000-000000000099".into());assert!(storage::validate(&invalid,true).is_err());
        let mut invalid=original.clone();invalid.maps.as_mut().unwrap().maps[0].routes[0].layer_id=Some("bad-id".into());assert!(storage::validate(&invalid,true).is_err());
        let mut invalid=original.clone();let duplicate=invalid.maps.as_ref().unwrap().maps[0].layers[0].clone();invalid.maps.as_mut().unwrap().maps[0].layers.push(duplicate);assert!(storage::validate(&invalid,true).is_err());
        let mut invalid=original.clone();let mut other=fixture().maps.unwrap().maps.remove(0);other.id="00000000-0000-0000-0000-000000000010".into();other.markers.clear();other.layers=vec![super::MapLayer{locked:false,id:"00000000-0000-0000-0000-000000000011".into(),title:"Foreign".into(),visible:true}];invalid.maps.as_mut().unwrap().maps[0].markers[0].layer_id=Some(other.layers[0].id.clone());invalid.maps.as_mut().unwrap().maps.push(other);assert!(storage::validate(&invalid,true).is_err());
        assert!(fixture().maps.unwrap().maps[0].layers.is_empty());
    }
    #[test]
    fn route_manuscript_links_validate_and_retain_deleted_targets() {
        let mut project=route_fixture();project.maps.as_mut().unwrap().schema_version=5;
        let id="00000000-0000-0000-0000-000000000020".to_string();
        project.maps.as_mut().unwrap().maps[0].routes[0].scene_ids=vec![id.clone()];
        project.maps.as_mut().unwrap().maps[0].routes[0].chapter_ids=vec!["00000000-0000-0000-0000-000000000021".into()];
        storage::validate(&project,true).unwrap(); // Deleted targets remain recoverable.
        for case in ["duplicate","invalid","version"] {
            let mut invalid=project.clone();let maps=invalid.maps.as_mut().unwrap();
            match case {"duplicate"=>maps.maps[0].routes[0].scene_ids.push(id.clone()),"invalid"=>maps.maps[0].routes[0].chapter_ids=vec!["bad-id".into()],_=>maps.schema_version=4}
            assert!(storage::validate(&invalid,true).is_err());
        }
        assert!(route_fixture().maps.unwrap().maps[0].routes[0].scene_ids.is_empty());
    }
    #[test]
    fn travel_dates_validate_calendar_and_schema_but_allow_reviewable_order() {
        let mut project=route_fixture();project.maps.as_mut().unwrap().schema_version=6;
        project.maps.as_mut().unwrap().maps[0].routes[0].departure=Some(crate::timeline::StoryDate{year:2000,month:Some(2),day:Some(29)});
        project.maps.as_mut().unwrap().maps[0].routes[0].arrival=Some(crate::timeline::StoryDate{year:1999,month:None,day:None});
        storage::validate(&project,true).unwrap();
        let mut invalid=project.clone();invalid.maps.as_mut().unwrap().schema_version=5;assert!(storage::validate(&invalid,true).is_err());
        let mut invalid=project.clone();invalid.maps.as_mut().unwrap().maps[0].routes[0].departure.as_mut().unwrap().year=1900;assert!(storage::validate(&invalid,true).is_err());
        assert!(route_fixture().maps.unwrap().maps[0].routes[0].departure.is_none());
    }
    #[test]
    fn scale_validation_and_legacy_maps() {
        assert!(fixture().maps.unwrap().maps[0].scale.is_none());
        let mut project=layer_fixture();project.maps.as_mut().unwrap().schema_version=4;
        project.maps.as_mut().unwrap().maps[0].scale=Some(super::MapScale{from:super::MapPoint{x:0.0,y:0.0},to:super::MapPoint{x:1.0,y:1.0},aspect_ratio:2.0,distance_km:100.0,travel_km_per_day:30.0});
        storage::validate(&project,true).unwrap();
        for field in ["distance","pace","ratio","point","same","version"] {
            let mut invalid=project.clone();let maps=invalid.maps.as_mut().unwrap();let scale=maps.maps[0].scale.as_mut().unwrap();
            match field {"distance"=>scale.distance_km=0.0,"pace"=>scale.travel_km_per_day=-1.0,"ratio"=>scale.aspect_ratio=f64::NAN,"point"=>scale.to.x=1.1,"same"=>{scale.to.x=0.0;scale.to.y=0.0;},_=>maps.schema_version=3}
            assert!(storage::validate(&invalid,true).is_err(),"{field}");
        }
    }
    #[test]
    fn route_validation_and_legacy_maps() {
        assert!(fixture().maps.unwrap().maps[0].routes.is_empty());
        let original = route_fixture();
        storage::validate(&original, true).unwrap();
        for stops in [vec![], vec!["00000000-0000-0000-0000-000000000004";2], vec!["00000000-0000-0000-0000-000000000004", "00000000-0000-0000-0000-000000000099"]] {
            let mut invalid = original.clone();
            invalid.maps.as_mut().unwrap().maps[0].routes[0].marker_ids = stops.into_iter().map(String::from).collect();
            assert!(storage::validate(&invalid, true).is_err());
        }
        let mut invalid = original.clone();
        invalid.maps.as_mut().unwrap().schema_version = 1;
        assert!(storage::validate(&invalid, true).is_err());
        let mut invalid = original.clone();
        invalid.maps.as_mut().unwrap().maps[0].routes[0].color = "invalid".into();
        assert!(storage::validate(&invalid, true).is_err());
    }
    #[test]
    fn rotation_validates_kind_range_and_schema() {
        let mut project=fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=13;
        let mut drawing=drawing_fixture();drawing.objects[0].rotation=Some(135.0);maps.maps[0].drawing=Some(drawing);
        assert!(storage::validate(&project,true).is_ok());
        for value in [-1.0,360.0,f64::NAN,f64::INFINITY] {let mut invalid=project.clone();invalid.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().objects[0].rotation=Some(value);assert!(storage::validate(&invalid,true).is_err());}
        let mut invalid=project.clone();invalid.maps.as_mut().unwrap().schema_version=12;assert!(storage::validate(&invalid,true).is_err());
        let mut invalid=project.clone();let object=&mut invalid.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().objects[1];object.rotation=Some(20.0);assert!(storage::validate(&invalid,true).is_err());
    }
    #[test]
    fn extended_symbols_require_new_schema() {
        for kind in ["castle","windmill","cave","harbor","factory","school","stadium","police","biodome","robotics","skybridge","portal","asteroids","comet","spaceship","jumpGate"] {
            let mut project=fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=12;
            let mut drawing=drawing_fixture();drawing.objects[0].kind=kind.into();maps.maps[0].drawing=Some(drawing);
            assert!(storage::validate(&project,true).is_ok(),"{}",kind);
            project.maps.as_mut().unwrap().schema_version=11;assert!(storage::validate(&project,true).is_err());
        }
    }
    #[test]
    fn drawing_layers_validate_schema_and_local_references() {
        let mut project=layer_fixture();
        let maps=project.maps.as_mut().unwrap();maps.schema_version=11;
        let mut drawing=drawing_fixture();drawing.strokes[0].layer_id=Some(maps.maps[0].layers[0].id.clone());drawing.objects[0].layer_id=Some(maps.maps[0].layers[1].id.clone());
        maps.maps[0].drawing=Some(drawing);maps.maps[0].layers[0].locked=true;
        assert!(storage::validate(&project,true).is_ok());
        let mut invalid=project.clone();invalid.maps.as_mut().unwrap().schema_version=10;assert!(storage::validate(&invalid,true).is_err());
        let mut invalid=project.clone();invalid.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().objects[0].layer_id=Some("00000000-0000-0000-0000-000000000099".into());assert!(storage::validate(&invalid,true).is_err());
        let mut invalid=project.clone();invalid.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().strokes[0].layer_id=Some("bad-id".into());assert!(storage::validate(&invalid,true).is_err());
    }
    #[test]
    fn maps_survive_save_draft_journal_and_history() {
        let root = std::env::temp_dir().join(format!("write-studio-maps-{}", std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let mut project=layer_fixture();
        project.maps.as_mut().unwrap().schema_version=5;
        project.maps.as_mut().unwrap().maps[0].routes[0].scene_ids=vec!["00000000-0000-0000-0000-000000000020".into()];
        project.maps.as_mut().unwrap().maps[0].routes[0].chapter_ids=vec!["00000000-0000-0000-0000-000000000021".into()];
        project.maps.as_mut().unwrap().maps[0].scale=Some(super::MapScale{from:super::MapPoint{x:0.0,y:0.0},to:super::MapPoint{x:1.0,y:0.0},aspect_ratio:2.0,distance_km:100.0,travel_km_per_day:30.0});
        project.maps.as_mut().unwrap().schema_version=6;
        project.maps.as_mut().unwrap().maps[0].routes[0].departure=Some(crate::timeline::StoryDate{year:-5,month:Some(2),day:Some(3)});
        project.maps.as_mut().unwrap().maps[0].routes[0].arrival=Some(crate::timeline::StoryDate{year:-5,month:Some(2),day:Some(8)});
        project.maps.as_mut().unwrap().schema_version=7;
        project.maps.as_mut().unwrap().maps[0].drawing=Some(drawing_fixture());
        project.maps.as_mut().unwrap().schema_version=8;
        let drawing=project.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap();drawing.theme=Some("space".into());drawing.background=Some("#101629".into());drawing.objects[0].kind="planet".into();drawing.strokes[0].color=Some("#5f417b".into());
        project.maps.as_mut().unwrap().schema_version=9;
        project.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().objects.push(serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000032","kind":"ellipse","x":0.1,"y":0.2,"endX":0.7,"endY":0.8,"size":0.065,"lineWidth":0.003,"color":"#123456"})).unwrap());
        project.maps.as_mut().unwrap().schema_version=10;
        let artwork=project.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap();artwork.terrain_colors=Some(std::collections::BTreeMap::from([("land".into(),"#112233".into())]));artwork.objects.last_mut().unwrap().fill=Some("#112233".into());
        project.maps.as_mut().unwrap().schema_version=11;
        let map=&mut project.maps.as_mut().unwrap().maps[0];
        map.layers[0].locked=true;
        let drawing=map.drawing.as_mut().unwrap();
        drawing.strokes[0].layer_id=Some(map.layers[0].id.clone());
        drawing.objects[0].layer_id=Some(map.layers[1].id.clone());
        project.maps.as_mut().unwrap().schema_version=12;
        project.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().objects[0].kind="spaceship".into();
        project.maps.as_mut().unwrap().schema_version=13;
        project.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().objects[0].rotation=Some(135.0);
        let saved = storage::save(&root, project).unwrap();
        let expected = serde_json::to_value(&saved.maps).unwrap();
        assert_eq!(
            serde_json::to_value(storage::open(&root).unwrap().maps).unwrap(),
            expected
        );
        storage::write_draft(
            &root.join("recovery"),
            Some(storage::Draft {
                project: saved.clone(),
                path: root.to_str().unwrap().into(),
                selected_id: String::new(),
            }),
        )
        .unwrap();
        assert_eq!(
            serde_json::to_value(
                storage::read_draft(&root.join("recovery"))
                    .unwrap()
                    .unwrap()
                    .project
                    .maps
            )
            .unwrap(),
            expected
        );
        assert_eq!(
            serde_json::to_value(history::read(&root, saved.revision).unwrap().maps).unwrap(),
            expected
        );
        let mut pending = saved.clone();
        pending.revision += 1;
        pending.maps.as_mut().unwrap().maps[0].markers[0].x = 0.99;
        fs::write(
            root.join(".write-studio-transaction.json"),
            serde_json::to_vec(&pending).unwrap(),
        )
        .unwrap();
        let reopened = storage::open(&root).unwrap();
        assert_eq!(reopened.maps.as_ref().unwrap().maps[0].markers[0].x, 0.99);
        let restored = history::restore(&root, saved.revision, reopened.revision).unwrap();
        assert_eq!(serde_json::to_value(restored.maps).unwrap(), expected);
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn space_marker_icons_roundtrip_and_require_current_schema() {
        for icon in ["planet", "star", "moon", "satellite", "spaceship"] {
            let mut project = fixture();
            let maps = project.maps.as_mut().unwrap();
            maps.schema_version = 18;
            maps.maps[0].markers[0].icon = icon.into();
            storage::validate(&project, true).unwrap();
            let encoded = serde_json::to_vec(&project).unwrap();
            let reopened: storage::Project = serde_json::from_slice(&encoded).unwrap();
            storage::validate(&reopened, true).unwrap();
            assert_eq!(reopened.maps.unwrap().maps[0].markers[0].icon, icon);
            project.maps.as_mut().unwrap().schema_version = 17;
            assert!(storage::validate(&project, true).is_err());
        }
    }
    #[test]
    fn rejects_invalid_positions_ids_and_schema_but_keeps_missing_entry_links() {
        let original = fixture();
        storage::validate(&original, true).unwrap(); // Missing entries are intentionally retained.
        for coordinate in [-0.1, 1.1, f64::INFINITY, f64::NAN] {
            let mut invalid = original.clone();
            invalid.maps.as_mut().unwrap().maps[0].markers[0].x = coordinate;
            assert!(storage::validate(&invalid, true).is_err());
        }
        let mut invalid = original.clone();
        invalid.maps.as_mut().unwrap().schema_version = 29;
        assert!(storage::validate(&invalid, true).is_err());
        let mut invalid = original.clone();
        invalid.maps.as_mut().unwrap().maps[0].image_id = "../../file".into();
        assert!(storage::validate(&invalid, true).is_err());
        let mut invalid = original.clone();
        let marker = invalid.maps.as_mut().unwrap().maps[0].markers[0].clone();
        invalid.maps.as_mut().unwrap().maps[0].markers.push(marker);
        assert!(storage::validate(&invalid, true).is_err());
        for (color, icon, entry) in [
            ("red", "pin", "00000000-0000-0000-0000-000000000005"),
            ("teal", "invalid", "00000000-0000-0000-0000-000000000005"),
            ("teal", "city", "bad-id"),
        ] {
            let mut invalid = original.clone();
            let marker = &mut invalid.maps.as_mut().unwrap().maps[0].markers[0];
            marker.color = color.into();
            marker.icon = icon.into();
            marker.entry_id = Some(entry.into());
            assert!(storage::validate(&invalid, true).is_err());
        }
    }
    #[test]
    fn irregular_brush_preserves_legacy_shapes_and_roundtrips(){
        let root=std::env::temp_dir().join(format!("write-irregular-brush-{}",std::process::id()));fs::create_dir_all(&root).unwrap();
        let mut project=fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=24;let mut drawing=drawing_fixture();
        drawing.strokes[0].brush_shape=Some("irregular".into());drawing.strokes[1].brush_shape=Some("star".into());maps.maps[0].drawing=Some(drawing);
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();
        assert_eq!(serde_json::to_value(storage::open(&root).unwrap().maps).unwrap(),expected);
        assert_eq!(serde_json::to_value(history::read(&root,saved.revision).unwrap().maps).unwrap(),expected);
        storage::write_draft(&root.join("recovery"),Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:String::new()})).unwrap();
        assert_eq!(serde_json::to_value(storage::read_draft(&root.join("recovery")).unwrap().unwrap().project.maps).unwrap(),expected);
        let mut legacy=saved.clone();let maps=legacy.maps.as_mut().unwrap();maps.schema_version=23;assert!(super::validate(maps,&mut |_|Ok(())).is_err());
        maps.maps[0].drawing.as_mut().unwrap().strokes[0].brush_shape=Some("star".into());storage::validate(&legacy,true).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn material_masks_roundtrip_and_reject_cycles(){
        let root=std::env::temp_dir().join(format!("write-material-masks-{}",std::process::id()));fs::create_dir_all(&root).unwrap();
        let mut project=fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=28;let mut drawing=drawing_fixture();drawing.strokes.truncate(1);
        let mut painted=drawing.strokes[0].clone();painted.material_mask=Some(super::MaterialMask{id:"10000000-0000-0000-0000-000000000021".into(),target:"land".into(),groups:vec![vec![0]],water_background:true});drawing.strokes.push(painted);maps.maps[0].drawing=Some(drawing);
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().maps).unwrap(),expected);assert_eq!(serde_json::to_value(history::read(&root,saved.revision).unwrap().maps).unwrap(),expected);
        storage::write_draft(&root.join("recovery"),Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:String::new()})).unwrap();assert_eq!(serde_json::to_value(storage::read_draft(&root.join("recovery")).unwrap().unwrap().project.maps).unwrap(),expected);
        for case in ["schema","cycle","future","duplicate","empty-group","target","id"]{let mut invalid=saved.clone();let maps=invalid.maps.as_mut().unwrap();let mask=maps.maps[0].drawing.as_mut().unwrap().strokes[1].material_mask.as_mut().unwrap();match case {"schema"=>maps.schema_version=27,"cycle"=>mask.groups=vec![vec![1]],"future"=>mask.groups=vec![vec![2]],"duplicate"=>mask.groups=vec![vec![0],vec![0]],"empty-group"=>mask.groups=vec![vec![]],"target"=>mask.target="invented".into(),_=>mask.id="invalid".into()}assert!(super::validate(maps,&mut |_|Ok(())).is_err(),"{case}");}
        let mut duplicate=saved.clone();let drawing=duplicate.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap();drawing.strokes.push(drawing.strokes[1].clone());assert!(super::validate(duplicate.maps.as_ref().unwrap(),&mut |_|Ok(())).is_err());
        let mut trash=saved.clone();let maps=trash.maps.as_mut().unwrap();let map=maps.maps.remove(0);maps.trash.push(super::TrashedMap{map,deleted_at:0});storage::validate(&trash,true).unwrap();fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn terrain_masks_roundtrip_and_validate(){
        let root=std::env::temp_dir().join(format!("write-terrain-masks-{}",std::process::id()));fs::create_dir_all(&root).unwrap();
        let mut project=fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=27;let mut drawing=drawing_fixture();
        drawing.strokes[0].mask=Some(serde_json::from_value(serde_json::json!({"points":[{"x":0.1,"y":0.1},{"x":0.9,"y":0.1},{"x":0.9,"y":0.9},{"x":0.1,"y":0.9}],"holes":[[{"x":0.3,"y":0.3},{"x":0.5,"y":0.3},{"x":0.4,"y":0.5}]],"inverted":true})).unwrap());maps.maps[0].drawing=Some(drawing);
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().maps).unwrap(),expected);assert_eq!(serde_json::to_value(history::read(&root,saved.revision).unwrap().maps).unwrap(),expected);
        storage::write_draft(&root.join("recovery"),Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:String::new()})).unwrap();assert_eq!(serde_json::to_value(storage::read_draft(&root.join("recovery")).unwrap().unwrap().project.maps).unwrap(),expected);
        for case in ["old-schema","too-few","crossing","nonfinite","outside","hole-outside","too-many"]{
            let mut invalid=saved.clone();let maps=invalid.maps.as_mut().unwrap();let mask=maps.maps[0].drawing.as_mut().unwrap().strokes[0].mask.as_mut().unwrap();
            match case {"old-schema"=>maps.schema_version=26,"too-few"=>mask.points.truncate(2),"crossing"=>mask.points.swap(1,2),"nonfinite"=>mask.points[0].x=f64::NAN,"outside"=>mask.points[0].x=-0.1,"hole-outside"=>mask.holes[0][0].x=0.0,_=>mask.points=vec![super::MapPoint{x:0.1,y:0.1};129]}
            assert!(super::validate(maps,&mut |_|Ok(())).is_err(),"{case}");
        }
        let mut trash=saved.clone();let maps=trash.maps.as_mut().unwrap();let map=maps.maps.remove(0);maps.trash.push(super::TrashedMap{map,deleted_at:0});storage::validate(&trash,true).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn texture_placement_and_symbol_recipes_roundtrip_and_validate(){
        let root=std::env::temp_dir().join(format!("write-texture-symbols-{}",std::process::id()));fs::create_dir_all(&root).unwrap();
        let mut project=fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=26;let mut drawing=drawing_fixture();
        drawing.strokes[0].material=Some("grass".into());drawing.strokes[0].texture_scale=Some(1.5);drawing.strokes[0].texture_rotation=Some(45.0);
        drawing.objects[0].stamp=Some(super::SymbolPlacementSettings{continuous:true,density:0.8,size_variation:0.3,rotation_variation:60.0,base_size:0.06,base_rotation:30.0});maps.maps[0].drawing=Some(drawing);
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();
        assert_eq!(serde_json::to_value(storage::open(&root).unwrap().maps).unwrap(),expected);
        assert_eq!(serde_json::to_value(history::read(&root,saved.revision).unwrap().maps).unwrap(),expected);
        storage::write_draft(&root.join("recovery"),Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:String::new()})).unwrap();
        assert_eq!(serde_json::to_value(storage::read_draft(&root.join("recovery")).unwrap().unwrap().project.maps).unwrap(),expected);
        for case in ["old-schema","scale-small","scale-large","scale-nan","rotation-negative","rotation-360","rotation-nan","no-material","density","density-nan","size-variation","rotation-variation","base-size","base-rotation","non-symbol"]{
            let mut invalid=saved.clone();let maps=invalid.maps.as_mut().unwrap();let drawing=maps.maps[0].drawing.as_mut().unwrap();
            match case {"old-schema"=>maps.schema_version=25,"scale-small"=>drawing.strokes[0].texture_scale=Some(0.1),"scale-large"=>drawing.strokes[0].texture_scale=Some(4.1),"scale-nan"=>drawing.strokes[0].texture_scale=Some(f64::NAN),"rotation-negative"=>drawing.strokes[0].texture_rotation=Some(-1.0),"rotation-360"=>drawing.strokes[0].texture_rotation=Some(360.0),"rotation-nan"=>drawing.strokes[0].texture_rotation=Some(f64::NAN),"no-material"=>drawing.strokes[0].material=None,"density"=>drawing.objects[0].stamp.as_mut().unwrap().density=0.0,"density-nan"=>drawing.objects[0].stamp.as_mut().unwrap().density=f64::NAN,"size-variation"=>drawing.objects[0].stamp.as_mut().unwrap().size_variation=0.6,"rotation-variation"=>drawing.objects[0].stamp.as_mut().unwrap().rotation_variation=181.0,"base-size"=>drawing.objects[0].stamp.as_mut().unwrap().base_size=0.0,"base-rotation"=>drawing.objects[0].stamp.as_mut().unwrap().base_rotation=360.0,_=>{drawing.objects[0].kind="label".into();drawing.objects[0].text=Some("Label".into());}}
            assert!(super::validate(maps,&mut |_|Ok(())).is_err(),"{case}");
        }
        let mut valid=saved.clone();let drawing=valid.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap();drawing.strokes[0].texture_scale=Some(0.25);drawing.strokes[0].texture_rotation=Some(0.0);let stamp=drawing.objects[0].stamp.as_mut().unwrap();stamp.density=0.1;stamp.size_variation=0.0;stamp.rotation_variation=180.0;stamp.base_size=0.0000001;stamp.base_rotation=359.9;storage::validate(&valid,true).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn terrain_opacity_roundtrips_and_rejects_invalid_values(){
        let root=std::env::temp_dir().join(format!("write-terrain-opacity-{}",std::process::id()));fs::create_dir_all(&root).unwrap();
        let mut project=fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=25;
        let mut drawing=drawing_fixture();drawing.strokes[0].opacity=Some(0.35);maps.maps[0].drawing=Some(drawing);
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();
        assert_eq!(serde_json::to_value(storage::open(&root).unwrap().maps).unwrap(),expected);
        assert_eq!(serde_json::to_value(history::read(&root,saved.revision).unwrap().maps).unwrap(),expected);
        storage::write_draft(&root.join("recovery"),Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:String::new()})).unwrap();
        assert_eq!(serde_json::to_value(storage::read_draft(&root.join("recovery")).unwrap().unwrap().project.maps).unwrap(),expected);
        assert!(expected["maps"][0]["drawing"]["strokes"][1].get("opacity").is_none());
        for value in [-0.1,1.1,f64::NAN,f64::INFINITY]{let mut invalid=saved.clone();invalid.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().strokes[0].opacity=Some(value);assert!(super::validate(invalid.maps.as_ref().unwrap(),&mut |_|Ok(())).is_err());}
        for value in [0.0,1.0]{let mut valid=saved.clone();valid.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().strokes[0].opacity=Some(value);storage::validate(&valid,true).unwrap();}
        let mut legacy=saved;legacy.maps.as_mut().unwrap().schema_version=24;assert!(storage::validate(&legacy,true).is_err());
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn terrain_brush_styles_roundtrip_and_validate(){
        let root=std::env::temp_dir().join(format!("write-brush-styles-{}",std::process::id()));fs::create_dir_all(&root).unwrap();
        let mut project=layer_fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=23;let mut drawing=drawing_fixture();
        drawing.strokes[0].brush_shape=Some("star".into());drawing.strokes[1].softness=Some(0.65);
        maps.maps[0].drawing=Some(drawing);
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();
        assert_eq!(serde_json::to_value(storage::open(&root).unwrap().maps).unwrap(),expected);
        assert_eq!(serde_json::to_value(history::read(&root,saved.revision).unwrap().maps).unwrap(),expected);
        storage::write_draft(&root.join("recovery"),Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:String::new()})).unwrap();
        assert_eq!(serde_json::to_value(storage::read_draft(&root.join("recovery")).unwrap().unwrap().project.maps).unwrap(),expected);
        for case in ["old-schema","shape","negative","large","nan","star-softness","contour"]{
            let mut invalid=saved.clone();let maps=invalid.maps.as_mut().unwrap();let drawing=maps.maps[0].drawing.as_mut().unwrap();
            match case {"old-schema"=>maps.schema_version=22,"shape"=>drawing.strokes[0].brush_shape=Some("square".into()),"negative"=>drawing.strokes[1].softness=Some(-0.1),"large"=>drawing.strokes[1].softness=Some(1.1),"nan"=>drawing.strokes[1].softness=Some(f64::NAN),"star-softness"=>drawing.strokes[0].softness=Some(0.5),_=>drawing.strokes[0].closed=Some(true)}
            assert!(storage::validate(&invalid,true).is_err(),"{case}");
        }
        let mut eraser=saved.clone();let stroke=&mut eraser.maps.as_mut().unwrap().maps[0].drawing.as_mut().unwrap().strokes[1];stroke.erase=Some(true);stroke.material=None;stroke.color=None;storage::validate(&eraser,true).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn marker_label_offsets_survive_storage_history_recovery_and_trash(){
        let root=std::env::temp_dir().join(format!("write-marker-labels-{}",std::process::id()));fs::create_dir_all(&root).unwrap();
        let mut project=layer_fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=22;
        maps.maps[0].markers[0].label_offset=Some(super::MarkerLabelOffset{angle:225.0,distance:48.0});
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();
        assert_eq!(serde_json::to_value(storage::open(&root).unwrap().maps).unwrap(),expected);
        assert_eq!(serde_json::to_value(history::read(&root,saved.revision).unwrap().maps).unwrap(),expected);
        storage::write_draft(&root.join("recovery"),Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:String::new()})).unwrap();
        assert_eq!(serde_json::to_value(storage::read_draft(&root.join("recovery")).unwrap().unwrap().project.maps).unwrap(),expected);
        for case in ["old-schema","angle-negative","angle-large","angle-nan","distance-small","distance-large","distance-infinite"]{
            let mut invalid=saved.clone();let maps=invalid.maps.as_mut().unwrap();let offset=maps.maps[0].markers[0].label_offset.as_mut().unwrap();
            match case {"old-schema"=>maps.schema_version=21,"angle-negative"=>offset.angle=-1.0,"angle-large"=>offset.angle=360.0,"angle-nan"=>offset.angle=f64::NAN,"distance-small"=>offset.distance=7.9,"distance-large"=>offset.distance=96.1,_=>offset.distance=f64::INFINITY}
            assert!(storage::validate(&invalid,true).is_err(),"{case}");
        }
        let mut trashed=saved.clone();let maps=trashed.maps.as_mut().unwrap();let map=maps.maps.remove(0);let now=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).unwrap().as_millis() as u64;
        maps.trash.push(super::TrashedMap{map,deleted_at:now});let trashed=storage::save(&root,trashed).unwrap();
        let reopened=storage::open(&root).unwrap();assert_eq!(serde_json::to_value(reopened.maps).unwrap(),serde_json::to_value(trashed.maps).unwrap());
        let mut reset=saved.clone();reset.maps.as_mut().unwrap().maps[0].markers[0].label_offset=None;storage::validate(&reset,true).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn terrain_erasure_contours_and_paths_roundtrip_and_validate(){
        let root=std::env::temp_dir().join(format!("write-map-creation-{}",std::process::id()));fs::create_dir_all(&root).unwrap();
        let mut project=layer_fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=21;
        let mut drawing=drawing_fixture();
        drawing.strokes.push(serde_json::from_value(serde_json::json!({"kind":"land","width":0.03,"closed":true,"material":"grass","points":[{"x":0.1,"y":0.1},{"x":0.8,"y":0.1},{"x":0.4,"y":0.8}]})).unwrap());
        drawing.strokes.push(serde_json::from_value(serde_json::json!({"kind":"land","width":0.03,"erase":true,"points":[{"x":0.2,"y":0.2},{"x":0.4,"y":0.3}]})).unwrap());
        drawing.objects.push(serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000091","kind":"path","x":0.1,"y":0.2,"size":0.065,"lineWidth":0.003,"color":"#368caa","smooth":true,"dashed":true,"points":[{"x":0.1,"y":0.2},{"x":0.5,"y":0.6},{"x":0.8,"y":0.5}]})).unwrap());
        maps.maps[0].drawing=Some(drawing);
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();
        assert_eq!(serde_json::to_value(storage::open(&root).unwrap().maps).unwrap(),expected);
        assert_eq!(serde_json::to_value(history::read(&root,saved.revision).unwrap().maps).unwrap(),expected);
        storage::write_draft(&root.join("recovery"),Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:String::new()})).unwrap();
        assert_eq!(serde_json::to_value(storage::read_draft(&root.join("recovery")).unwrap().unwrap().project.maps).unwrap(),expected);
        for case in ["schema","short-contour","flat-contour","colored-eraser","material-eraser","short-path","long-path","path-origin","path-coordinate","path-width","symbol-points"]{
            let mut invalid=saved.clone();let maps=invalid.maps.as_mut().unwrap();let drawing=maps.maps[0].drawing.as_mut().unwrap();
            match case {
                "schema"=>maps.schema_version=20,
                "short-contour"=>drawing.strokes[2].points.truncate(2),
                "flat-contour"=>drawing.strokes[2].points.iter_mut().for_each(|p|p.y=0.1),
                "colored-eraser"=>drawing.strokes[3].color=Some("#123456".into()),
                "material-eraser"=>drawing.strokes[3].material=Some("earth".into()),
                "short-path"=>drawing.objects[2].points.as_mut().unwrap().truncate(1),
                "long-path"=>{let p=drawing.objects[2].points.as_ref().unwrap()[0].clone();drawing.objects[2].points=Some(vec![p;257]);},
                "path-origin"=>drawing.objects[2].x=0.2,
                "path-coordinate"=>drawing.objects[2].points.as_mut().unwrap()[1].y=1.1,
                "path-width"=>drawing.objects[2].line_width=Some(f64::NAN),
                _=>drawing.objects[0].points=Some(vec![]),
            }
            assert!(storage::validate(&invalid,true).is_err(),"{case}");
        }
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn region_holes_and_expanded_canvas_survive_storage_and_reject_invalid_geometry(){
        let root=std::env::temp_dir().join(format!("write-studio-hole-expansion-{}",std::process::id()));fs::create_dir_all(&root).unwrap();
        let mut project=layer_fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=20;
        let map=&mut maps.maps[0];let mut drawing=drawing_fixture();drawing.width=3000;drawing.height=2400;drawing.strokes[0].width=0.002;drawing.objects[0].size=0.002;drawing.texture_frame=Some(super::MapImageFrame{x:300.0,y:480.0,width:1500.0,height:1440.0});map.drawing=Some(drawing);
        map.image_frame=Some(super::MapImageFrame{x:0.1,y:0.2,width:0.5,height:0.6});
        map.regions.push(serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000088","title":"Ring","color":"blue","points":[{"x":0.1,"y":0.1},{"x":0.9,"y":0.1},{"x":0.9,"y":0.9},{"x":0.1,"y":0.9}],"holes":[[{"x":0.3,"y":0.3},{"x":0.7,"y":0.3},{"x":0.7,"y":0.7},{"x":0.3,"y":0.7}]]})).unwrap());
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();
        assert_eq!(serde_json::to_value(storage::open(&root).unwrap().maps).unwrap(),expected);
        assert_eq!(serde_json::to_value(history::read(&root,saved.revision).unwrap().maps).unwrap(),expected);
        storage::write_draft(&root.join("recovery"),Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:String::new()})).unwrap();
        assert_eq!(serde_json::to_value(storage::read_draft(&root.join("recovery")).unwrap().unwrap().project.maps).unwrap(),expected);
        for case in ["outside","touching","overlap","crossing","empty","frame","dimensions","old-schema"] {
            let mut invalid=saved.clone();let maps=invalid.maps.as_mut().unwrap();let map=&mut maps.maps[0];
            match case {
              "outside"=>map.regions[0].holes[0][0].x=0.0,
              "touching"=>map.regions[0].holes[0][0].x=0.1,
              "overlap"=>{let hole=map.regions[0].holes[0].clone();map.regions[0].holes.push(hole);},
              "crossing"=>map.regions[0].holes[0].swap(1,2),
              "empty"=>map.regions[0].holes.push(vec![]),
              "frame"=>map.image_frame.as_mut().unwrap().width=1.0,
              "dimensions"=>map.drawing.as_mut().unwrap().width=4097,
              _=>maps.schema_version=18,
            }
            assert!(storage::validate(&invalid,true).is_err(),"{case}");
        }
        let mut legacy=saved.clone();let maps=legacy.maps.as_mut().unwrap();maps.schema_version=18;maps.maps[0].image_frame=None;maps.maps[0].drawing=None;assert!(storage::validate(&legacy,true).is_err());
        legacy.maps.as_mut().unwrap().maps[0].regions[0].holes.clear();storage::validate(&legacy,true).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn regions_roundtrip_history_recovery_and_validate(){
        let root=std::env::temp_dir().join(format!("write-studio-regions-{}",std::process::id()));fs::create_dir_all(&root).unwrap();
        let mut project=layer_fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=17;
        let layer_id=maps.maps[0].layers[0].id.clone();
        maps.maps[0].regions.push(serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000087","title":"Reino 🌊","color":"teal","labelPosition":{"x":0.4,"y":0.3},"layerId":layer_id,"entryId":"00000000-0000-0000-0000-000000000099","points":[{"x":0.1,"y":0.1},{"x":0.8,"y":0.1},{"x":0.7,"y":0.8},{"x":0.2,"y":0.7}]})).unwrap());
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();
        assert_eq!(serde_json::to_value(storage::open(&root).unwrap().maps).unwrap(),expected);
        assert_eq!(serde_json::to_value(history::read(&root,saved.revision).unwrap().maps).unwrap(),expected);
        storage::write_draft(&root.join("recovery"),Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:String::new()})).unwrap();
        assert_eq!(serde_json::to_value(storage::read_draft(&root.join("recovery")).unwrap().unwrap().project.maps).unwrap(),expected);
        for case in ["schema","layer","entry","color","duplicate","crossing","coordinates","label","flat"] {
            let mut invalid=saved.clone();let maps=invalid.maps.as_mut().unwrap();let region=&mut maps.maps[0].regions[0];
            match case {
             "label"=>region.label_position=Some(super::MapPoint{x:1.1,y:0.5}),"schema"=>maps.schema_version=16,"layer"=>region.layer_id=Some("missing".into()),"entry"=>region.entry_id=Some("../bad".into()),"color"=>region.color="red".into(),
             "duplicate"=>region.points.push(region.points[0].clone()),"crossing"=>region.points.swap(1,2),"coordinates"=>region.points[0].x=f64::NAN,
             _=>{for point in &mut region.points{point.y=0.5;}}
            }
            assert!(storage::validate(&invalid,true).is_err(),"{case}");
        }
        fs::remove_dir_all(root).unwrap();
    }

}

pub fn image_ids(maps:&ProjectMaps)->impl Iterator<Item=&String>{maps.maps.iter().chain(maps.trash.iter().map(|item|&item.map)).map(|map|&map.image_id)}
