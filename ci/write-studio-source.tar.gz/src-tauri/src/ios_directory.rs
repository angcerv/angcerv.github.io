use std::{
    ffi::{CStr, CString, c_char, c_void},
    path::Path,
    sync::mpsc,
};
unsafe extern "C" {
    fn ws_choose_directory(
        callback: extern "C" fn(*const c_char, *const c_char, *mut c_void),
        context: *mut c_void,
    );
    fn ws_restore_directory(error: *mut *mut c_char) -> *mut c_char;
    fn ws_commit_directory(path: *const c_char) -> *mut c_char;
    fn ws_prepare_directory(path:*const c_char,error:*mut *mut c_char)->i32;
    fn ws_free_string(value: *mut c_char);
    fn ws_coordinate_directory(
        path: *const c_char,
        writing: bool,
        work: extern "C" fn(*mut c_void),
        context: *mut c_void,
    ) -> *mut c_char;
}
unsafe fn owned(value: *mut c_char) -> Option<String> {
    if value.is_null() {
        return None;
    }
    let text = unsafe { CStr::from_ptr(value) }
        .to_string_lossy()
        .into_owned();
    unsafe { ws_free_string(value) };
    Some(text)
}
pub fn restore() -> Result<Option<String>, String> {
    let mut error = std::ptr::null_mut();
    let path = unsafe { owned(ws_restore_directory(&mut error)) };
    if let Some(error) = unsafe { owned(error) } {
        Err(error)
    } else {
        Ok(path)
    }
}
pub fn commit(path: &str) -> Result<(), String> {
    let path = CString::new(path).map_err(|e| e.to_string())?;
    match unsafe { owned(ws_commit_directory(path.as_ptr())) } {
        Some(error) => Err(error),
        None => Ok(()),
    }
}
pub async fn choose() -> Result<Option<String>, String> {
    tauri::async_runtime::spawn_blocking(|| {
        type Reply = mpsc::Sender<Result<Option<String>, String>>;
        extern "C" fn reply(path: *const c_char, error: *const c_char, context: *mut c_void) {
            let sender = unsafe { Box::from_raw(context as *mut Reply) };
            let value = if !error.is_null() {
                Err(unsafe { CStr::from_ptr(error) }
                    .to_string_lossy()
                    .into_owned())
            } else {
                Ok(if path.is_null() {
                    None
                } else {
                    Some(
                        unsafe { CStr::from_ptr(path) }
                            .to_string_lossy()
                            .into_owned(),
                    )
                })
            };
            let _ = sender.send(value);
        }
        let (sender, receiver) = mpsc::channel();
        unsafe { ws_choose_directory(reply, Box::into_raw(Box::new(sender)) as *mut c_void) };
        receiver.recv().map_err(|e| e.to_string())?
    })
    .await
    .map_err(|e| e.to_string())?
}
// Thread-local depth permits recovery/open helpers inside a coordinated save.
thread_local! {static DEPTH:std::cell::Cell<usize>=const{std::cell::Cell::new(0)};}
pub fn coordinate<T>(
    path: &Path,
    writing: bool,
    work: impl FnOnce() -> Result<T, String>,
) -> Result<T, String> {
    if DEPTH.with(|depth| depth.get() > 0) {
        return work();
    }
    struct Job<F, T> {
        work: Option<F>,
        result: Option<Result<T, String>>,
    }
    extern "C" fn invoke<F: FnOnce() -> Result<T, String>, T>(context: *mut c_void) {
        let job = unsafe { &mut *(context as *mut Job<F, T>) };
        DEPTH.with(|depth| depth.set(depth.get() + 1));
        job.result = Some(
            std::panic::catch_unwind(std::panic::AssertUnwindSafe(|| job.work.take().unwrap()()))
                .unwrap_or_else(|_| Err("Project file operation failed.".into())),
        );
        DEPTH.with(|depth| depth.set(depth.get() - 1));
    }
    fn perform<F: FnOnce() -> Result<T, String>, T>(
        path: &Path,
        writing: bool,
        work: F,
    ) -> Result<T, String> {
        let path = CString::new(path.to_string_lossy().as_bytes()).map_err(|e| e.to_string())?;
        let mut job = Job {
            work: Some(work),
            result: None,
        };
        let error = unsafe {
            owned(ws_coordinate_directory(
                path.as_ptr(),
                writing,
                invoke::<F, T>,
                &mut job as *mut _ as *mut c_void,
            ))
        };
        if let Some(error) = error {
            return Err(error);
        }
        job.result.ok_or("Project file access was not granted.")?
    }
    perform(path, writing, work)
}

pub fn external(path:&Path)->bool {
    std::env::var_os("HOME").map(|home|!path.starts_with(std::path::PathBuf::from(home))).unwrap_or(true)
}

pub fn prepare(path:&Path)->Result<bool,String>{
    let path=CString::new(path.to_string_lossy().as_bytes()).map_err(|e|e.to_string())?;
    let mut error=std::ptr::null_mut();let status=unsafe{ws_prepare_directory(path.as_ptr(),&mut error)};
    if let Some(error)=unsafe{owned(error)}{return Err(error);}
    match status {0=>Ok(true),1=>Ok(false),_=>Err("Project files are unavailable. Check iCloud and try again.".into())}
}
