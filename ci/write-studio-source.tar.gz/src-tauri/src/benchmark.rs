//! Opt-in disk benchmark. Not compiled into the application or run by default tests.
use crate::{backup, entry_images, export, storage};
use std::{fs, path::PathBuf, time::Instant};

struct Scratch(PathBuf);
impl Drop for Scratch {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
fn measured<T>(samples: &mut Vec<f64>, operation: impl FnOnce() -> T) -> T {
    let start = Instant::now();
    let result = operation();
    samples.push(start.elapsed().as_secs_f64() * 1000.0);
    result
}

#[derive(serde::Deserialize)]
struct Asset {
    id: String,
    source: String,
}
fn assert_assets(
    root: &std::path::Path,
    project_id: &str,
    assets: &[(String, Vec<u8>)],
    thumbnail: &[u8],
) {
    let reader = entry_images::ProjectImageReader::new(root, project_id).unwrap();
    for (id, bytes) in assets {
        assert_eq!(reader.read(id, false).unwrap(), *bytes);
        assert_eq!(reader.read(id, true).unwrap(), thumbnail);
    }
}

#[test]
#[ignore = "Explicit synthetic disk benchmark; requires WRITE_STUDIO_BENCH_INPUT"]
fn project_io() {
    let input = PathBuf::from(
        std::env::var_os("WRITE_STUDIO_BENCH_INPUT").expect("Run node scripts/benchmark-io.mjs"),
    );
    let project: storage::Project =
        serde_json::from_slice(&fs::read(input.join("project.json")).unwrap()).unwrap();
    // Reserve a fresh directory; never accept a project/output path from the caller.
    let root = std::env::temp_dir().join(format!(
        "write-studio-io-{}-{}",
        std::process::id(),
        std::time::SystemTime::now()
            .duration_since(std::time::UNIX_EPOCH)
            .unwrap()
            .as_nanos()
    ));
    fs::create_dir(&root).unwrap();
    let scratch = Scratch(root);
    let project_root = scratch.0.join("project");
    fs::create_dir(&project_root).unwrap();
    let mut rows = serde_json::Map::new();
    let mut initial = Vec::new();
    let mut saved = measured(&mut initial, || {
        storage::save(&project_root, project).unwrap()
    });
    rows.insert("initialSave".into(), serde_json::json!(initial));
    let assets: Vec<(String, Vec<u8>)> = if input.join("assets.json").exists() {
        let manifest: Vec<Asset> =
            serde_json::from_slice(&fs::read(input.join("assets.json")).unwrap()).unwrap();
        manifest
            .into_iter()
            .map(|asset| (asset.id, fs::read(input.join(asset.source)).unwrap()))
            .collect()
    } else {
        Vec::new()
    };
    let thumbnail = if assets.is_empty() {
        Vec::new()
    } else {
        fs::read(input.join("thumbnail.png")).unwrap()
    };
    if !assets.is_empty() {
        let mut imports = Vec::new();
        measured(&mut imports, || {
            for (id, bytes) in &assets {
                entry_images::store(&project_root, &saved.id, id, bytes, &thumbnail).unwrap();
            }
        });
        rows.insert("storeAllAssets".into(), serde_json::json!(imports));
        assert_assets(&project_root, &saved.id, &assets, &thumbnail);
    }
    let mut asset_reads = Vec::new();
    eprintln!("Benchmark: initial save and asset setup complete");
    let mut opens = Vec::new();
    let mut saves = Vec::new();
    let mut automatic = Vec::new();
    let mut backups = Vec::new();
    let mut restores = Vec::new();
    for i in 0..3 {
        eprintln!("Benchmark: disk sample {}/3", i + 1);
        let opened = measured(&mut opens, || storage::open(&project_root).unwrap());
        assert_eq!(
            serde_json::to_value(&opened).unwrap(),
            serde_json::to_value(&saved).unwrap()
        );
        if !assets.is_empty() {
            let read = measured(&mut asset_reads, || {
                let reader =
                    entry_images::ProjectImageReader::new(&project_root, &saved.id).unwrap();
                assets
                    .iter()
                    .map(|(id, _)| reader.read(id, false).unwrap())
                    .collect::<Vec<_>>()
            });
            for ((_, expected), actual) in assets.iter().zip(read) {
                assert_eq!(*expected, actual);
            }
        }
        let mut edited = saved.clone();
        edited.chapters[0].scenes[0]
            .content
            .as_mut()
            .unwrap()
            .push_str(" Updated.");
        saved = measured(&mut saves, || storage::save(&project_root, edited).unwrap());
        let mut edited = saved.clone();
        edited.chapters[0].scenes[0]
            .content
            .as_mut()
            .unwrap()
            .push_str(" Autosaved.");
        saved = measured(&mut automatic, || {
            storage::save_automatic(&project_root, edited).unwrap()
        });
        let archive = scratch.0.join(format!("backup-{i}.zip"));
        measured(&mut backups, || {
            backup::create(&project_root, &archive, &saved.id, saved.revision).unwrap()
        });
        let parent = scratch.0.join(format!("restore-{i}"));
        fs::create_dir(&parent).unwrap();
        let restored = measured(&mut restores, || {
            backup::restore(&archive, &parent).unwrap()
        });
        assert_eq!(
            serde_json::to_value(&restored.project).unwrap(),
            serde_json::to_value(&saved).unwrap()
        );
        if !assets.is_empty() {
            assert_assets(
                std::path::Path::new(&restored.path),
                &saved.id,
                &assets,
                &thumbnail,
            );
        }
    }
    if !assets.is_empty() {
        rows.insert(
            "readAllAssetsValidated".into(),
            serde_json::json!(asset_reads),
        );
    }
    for (name, samples) in [
        ("open", opens),
        ("manualSaveOneScene", saves),
        ("automaticSaveOneScene", automatic),
        ("backup", backups),
        ("restore", restores),
    ] {
        rows.insert(name.into(), serde_json::json!(samples));
    }
    for name in ["manuscript.md", "manuscript.docx", "encyclopedia.html"] {
        let bytes = fs::read(input.join(name)).unwrap();
        let mut writes = Vec::new();
        for i in 0..3 {
            let target = scratch.0.join(format!("{i}-{name}"));
            measured(&mut writes, || export::write_new(&target, &bytes).unwrap());
            assert_eq!(fs::read(&target).unwrap(), bytes);
            if name == "manuscript.docx" {
                let mut archive = zip::ZipArchive::new(fs::File::open(&target).unwrap()).unwrap();
                let mut document = String::new();
                std::io::Read::read_to_string(
                    &mut archive.by_name("word/document.xml").unwrap(),
                    &mut document,
                )
                .unwrap();
                assert!(document.contains("Synthetic project") && document.contains("Scene 0"));
            }
            assert!(
                export::write_new(&target, &bytes).is_err(),
                "Exports must not overwrite existing files"
            );
        }
        rows.insert(format!("write:{name}"), serde_json::json!(writes));
    }
    let html = fs::read_to_string(input.join("encyclopedia.zip.html")).unwrap();
    let image_ids: Vec<String> =
        serde_json::from_slice(&fs::read(input.join("encyclopedia.images.json")).unwrap()).unwrap();
    let mut zip = Vec::new();
    for i in 0..3 {
        let target = scratch.0.join(format!("encyclopedia-{i}.zip"));
        measured(&mut zip, || {
            let reader = if image_ids.is_empty() {
                None
            } else {
                Some(entry_images::ProjectImageReader::new(&project_root, &saved.id).unwrap())
            };
            export::write_encyclopedia(&target, &html, &image_ids, |id| {
                reader.as_ref().unwrap().read(id, false)
            })
            .unwrap()
        });
        let mut archive = zip::ZipArchive::new(fs::File::open(target).unwrap()).unwrap();
        let mut actual = String::new();
        std::io::Read::read_to_string(&mut archive.by_name("index.html").unwrap(), &mut actual)
            .unwrap();
        assert_eq!(actual, html);
        assert_eq!(archive.len(), 1 + image_ids.len());
        for (index, id) in image_ids.iter().enumerate() {
            let mut bytes = Vec::new();
            std::io::Read::read_to_end(
                &mut archive
                    .by_name(&format!("images/image-{}.png", index + 1))
                    .unwrap(),
                &mut bytes,
            )
            .unwrap();
            assert_eq!(
                &bytes,
                &assets
                    .iter()
                    .find(|(asset_id, _)| asset_id == id)
                    .unwrap()
                    .1
            );
            assert!(html.contains(&format!("images/image-{}.png", index + 1)));
        }
    }
    rows.insert(
        if image_ids.is_empty() {
            "encyclopediaZipWithoutImages"
        } else {
            "encyclopediaZipWithImages"
        }
        .into(),
        serde_json::json!(zip),
    );
    println!("BENCHMARK_JSON:{}", serde_json::Value::Object(rows));
}
