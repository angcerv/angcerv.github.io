//! System UI boundary. Mobile implementations must preserve cancellation vs failure.
use std::path::PathBuf;

#[derive(Default)]
pub(crate) struct FileDialog {
    #[cfg(desktop)]
    inner: rfd::FileDialog,
}
impl FileDialog {
    pub fn new() -> Self {
        Self::default()
    }
    pub fn set_title(self, _title: &str) -> Self {
        #[cfg(desktop)]
        {
            return Self {
                inner: self.inner.set_title(_title),
            };
        }
        #[cfg(mobile)]
        {
            self
        }
    }
    pub fn set_file_name(self, _name: &str) -> Self {
        #[cfg(desktop)]
        {
            return Self {
                inner: self.inner.set_file_name(_name),
            };
        }
        #[cfg(mobile)]
        {
            self
        }
    }
    #[cfg(not(target_os = "ios"))]
    pub fn set_directory(self, _path: impl AsRef<std::path::Path>) -> Self {
        #[cfg(desktop)]
        {
            return Self {
                inner: self.inner.set_directory(_path),
            };
        }
        #[cfg(mobile)]
        {
            self
        }
    }
    pub fn add_filter(self, _name: &str, _extensions: &[&str]) -> Self {
        #[cfg(desktop)]
        {
            return Self {
                inner: self.inner.add_filter(_name, _extensions),
            };
        }
        #[cfg(mobile)]
        {
            self
        }
    }
    pub fn pick_file(self) -> Result<Option<PathBuf>, String> {
        #[cfg(desktop)]
        {
            return Ok(self.inner.pick_file());
        }
        #[cfg(mobile)]
        {
            Err("File selection is not available in this mobile preview.".into())
        }
    }
    pub fn pick_files(self) -> Result<Option<Vec<PathBuf>>, String> {
        #[cfg(desktop)]
        { return Ok(self.inner.pick_files()); }
        #[cfg(mobile)]
        { Err("File selection is not available in this mobile preview.".into()) }
    }
    pub fn pick_folder(self) -> Result<Option<PathBuf>, String> {
        #[cfg(desktop)]
        {
            return Ok(self.inner.pick_folder());
        }
        #[cfg(mobile)]
        {
            Err("Folder selection is not available in this mobile preview.".into())
        }
    }
    pub fn save_file(self) -> Result<Option<PathBuf>, String> {
        #[cfg(desktop)]
        {
            return Ok(self.inner.save_file());
        }
        #[cfg(mobile)]
        {
            Err("File export is not available in this mobile preview.".into())
        }
    }
}

/// iOS imports a copy through Files; project restoration never edits the provider source.
#[cfg(target_os = "ios")]
pub async fn pick_backup(app: tauri::AppHandle) -> Result<Option<PathBuf>, String> {
    use tauri_plugin_dialog::{DialogExt, FileAccessMode, PickerMode};
    tauri::async_runtime::spawn_blocking(move || {
        app.dialog().file()
            .add_filter("Write Studio backup", &["zip"])
            .set_picker_mode(PickerMode::Document)
            .set_file_access_mode(FileAccessMode::Copy)
            .blocking_pick_file()
            .map(|file|file.into_path().map_err(|error|error.to_string()))
            .transpose()
    }).await.map_err(|error|error.to_string())?
}
