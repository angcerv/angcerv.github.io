use serde::Serialize;
use std::{
    fs::{self, File, OpenOptions},
    io::{Cursor, Read, Write},
    path::{Path, PathBuf},
};
const MAX_BYTES: usize = 24 * 1024 * 1024;
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct SelectedImage {
    pub name:String,
    pub bytes: Vec<u8>,
}
pub fn valid_id(id: &str) -> bool {
    id.len() == 36
        && id.bytes().enumerate().all(|(i, b)| {
            if [8, 13, 18, 23].contains(&i) {
                b == b'-'
            } else {
                b.is_ascii_hexdigit()
            }
        })
}
fn project_root(path: &Path, project_id: &str) -> Result<PathBuf, String> {
    let root = path.canonicalize().map_err(|e| e.to_string())?;
    let metadata: serde_json::Value =
        serde_json::from_slice(&fs::read(root.join("project.json")).map_err(|e| e.to_string())?)
            .map_err(|e| e.to_string())?;
    if metadata.get("id").and_then(|v| v.as_str()) != Some(project_id) {
        return Err("The image belongs to a different project.".into());
    }
    Ok(root)
}
fn read_limited(path: &Path, limit: usize) -> Result<Vec<u8>, String> {
    let mut bytes = Vec::new();
    File::open(path)
        .map_err(|e| e.to_string())?
        .take((limit + 1) as u64)
        .read_to_end(&mut bytes)
        .map_err(|e| e.to_string())?;
    if bytes.len() > limit {
        return Err("The image is too large.".into());
    }
    Ok(bytes)
}
pub fn select(path: &Path) -> Result<SelectedImage, String> {
    let bytes = read_limited(path, 20 * 1024 * 1024)?;
    if !(bytes.starts_with(b"\x89PNG\r\n\x1a\n")
        || bytes.starts_with(&[0xff, 0xd8, 0xff])
        || (bytes.starts_with(b"RIFF") && bytes.get(8..12) == Some(b"WEBP")))
    {
        return Err("Choose a PNG, JPEG or WebP image.".into());
    }
    Ok(SelectedImage { bytes,name:path.file_name().map(|name|name.to_string_lossy().into_owned()).unwrap_or_default() })
}
pub fn select_many(paths: &[PathBuf], max_count: usize) -> Result<Vec<SelectedImage>, String> {
    if paths.len() > max_count.min(256) {
        return Err("A gallery can contain up to 256 images.".into());
    }
    let mut images = Vec::new();
    let mut total = 0usize;
    for path in paths {
        let image = select(path)?;
        total += image.bytes.len();
        if total > 64 * 1024 * 1024 {
            return Err("Choose images totaling less than 64 MB.".into());
        }
        images.push(image);
    }
    Ok(images)
}

pub(crate) fn validate_png(bytes: &[u8], max_dimension: u32) -> Result<(), String> {
    if bytes.len() > MAX_BYTES {
        return Err("The image is too large.".into());
    }
    let mut decoder = png::Decoder::new(Cursor::new(bytes));
    decoder.set_limits(png::Limits {
        bytes: 32 * 1024 * 1024,
    });
    let mut reader = decoder
        .read_info()
        .map_err(|_| "The image could not be decoded.".to_string())?;
    let info = reader.info();
    if info.width == 0
        || info.height == 0
        || info.width > max_dimension
        || info.height > max_dimension
        || info.animation_control.is_some()
    {
        return Err("Invalid image dimensions or animation.".into());
    }
    let mut buffer = vec![0; reader.output_buffer_size()];
    reader
        .next_frame(&mut buffer)
        .map_err(|_| "The image is damaged.".to_string())?;
    Ok(())
}
pub fn store(
    path: &Path,
    project_id: &str,
    image_id: &str,
    image: &[u8],
    thumbnail: &[u8],
) -> Result<(), String> {
    if !valid_id(image_id) {
        return Err("Invalid image identifier.".into());
    }
    validate_png(image, 2048)?;
    validate_png(thumbnail, 256)?;
    let root = project_root(path, project_id)?;
    let mut assets = root.clone();
    for name in ["assets", "images"] {
        assets.push(name);
        if !assets.exists() {
            fs::create_dir(&assets).map_err(|e| e.to_string())?;
        }
        let metadata = fs::symlink_metadata(&assets).map_err(|e| e.to_string())?;
        if metadata.file_type().is_symlink() || !metadata.is_dir() {
            return Err("The images folder must be a local project directory.".into());
        }
    }
    let assets = assets.canonicalize().map_err(|e| e.to_string())?;
    if !assets.starts_with(&root) {
        return Err("The images folder must be inside the project.".into());
    }
    let folder = assets.join(image_id);
    fs::create_dir(&folder).map_err(|e| e.to_string())?;
    // Never overwrite assets: older revisions and recovery drafts may still reference them.
    for (name, bytes) in [("image.png", image), ("thumbnail.png", thumbnail)] {
        let mut file = OpenOptions::new()
            .write(true)
            .create_new(true)
            .open(folder.join(name))
            .map_err(|e| e.to_string())?;
        file.write_all(bytes)
            .and_then(|_| file.sync_all())
            .map_err(|e| e.to_string())?;
    }
    crate::storage::sync_directory(&folder)
        .map_err(|e| e.to_string())?;
    crate::storage::sync_directory(&assets)
        .map_err(|e| e.to_string())?;
    crate::storage::sync_directory(root.join("assets"))
        .map_err(|e| e.to_string())?;
    crate::storage::sync_directory(&root)
        .map_err(|e| e.to_string())?;
    Ok(())
}
pub fn read(
    path: &Path,
    project_id: &str,
    image_id: &str,
    thumbnail: bool,
) -> Result<Vec<u8>, String> {
    if !valid_id(image_id) {
        return Err("Invalid image identifier.".into());
    }
    ProjectImageReader::new(path, project_id)?.read(image_id, thumbnail)
}
/// Validate project identity once for a batch of immutable asset reads.
pub(crate) struct ProjectImageReader {
    root: PathBuf,
}
impl ProjectImageReader {
    pub(crate) fn new(path: &Path, project_id: &str) -> Result<Self, String> {
        Ok(Self {
            root: project_root(path, project_id)?,
        })
    }
    pub(crate) fn read(&self, image_id: &str, thumbnail: bool) -> Result<Vec<u8>, String> {
        if !valid_id(image_id) {
            return Err("Invalid image identifier.".into());
        }
        let file = self
            .root
            .join("assets/images")
            .join(image_id)
            .join(if thumbnail {
                "thumbnail.png"
            } else {
                "image.png"
            })
            .canonicalize()
            .map_err(|_| "Image file is missing. You can replace or remove the image.".to_string())?;
        if !file.starts_with(&self.root) {
            return Err("The image must be inside the project.".into());
        }
        let bytes = read_limited(&file, MAX_BYTES)?;
        validate_png(&bytes, if thumbnail { 256 } else { 2048 })?;
        Ok(bytes)
    }
}
#[cfg(test)]
mod tests {
    use super::*;
    use crate::{history, storage};
    const IMAGE_ID: &str = "00000000-0000-0000-0000-000000000901";
    const SECOND_ID: &str = "00000000-0000-0000-0000-000000000902";
    #[test]
    fn batch_selection_preserves_order_and_validates_before_returning() {
        let root=std::env::temp_dir().join(format!("image-batch-{}",std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let first=root.join("z.png");let second=root.join("a.png");
        fs::write(&first,png(1,1)).unwrap();fs::write(&second,png(1,1)).unwrap();
        let paths=vec![first.clone(),second.clone()];
        let images=select_many(&paths,2).unwrap();
        assert_eq!(images[0].name,"z.png");assert_eq!(images[1].name,"a.png");
        assert!(select_many(&paths,1).is_err());
        fs::write(&second,b"invalid").unwrap();assert!(select_many(&paths,2).is_err());
        fs::remove_dir_all(root).unwrap();
    }
    fn png(width: u32, height: u32) -> Vec<u8> {
        let mut bytes = Vec::new();
        {
            let mut encoder = png::Encoder::new(&mut bytes, width, height);
            encoder.set_color(png::ColorType::Rgba);
            encoder.set_depth(png::BitDepth::Eight);
            let mut writer = encoder.write_header().unwrap();
            writer
                .write_image_data(&vec![128; (width * height * 4) as usize])
                .unwrap();
        }
        bytes
    }
    fn fixture(label: &str) -> (PathBuf, storage::Project) {
        let root = std::env::temp_dir().join(format!(
            "write-studio-images-{label}-{}",
            std::process::id()
        ));
        fs::create_dir_all(&root).unwrap();
        let project: storage::Project = serde_json::from_str(include_str!(
            "../../tests/fixtures/worldbuilding-project.json"
        ))
        .unwrap();
        let saved = storage::save(&root, project).unwrap();
        (root, saved)
    }
    fn attach(mut project: storage::Project, id: Option<&str>) -> storage::Project {
        let world = project.worldbuilding.as_mut().unwrap();
        world.schema_version = 4;
        for template in &mut world.templates {
            template.schema_version = 4;
        }
        for entry in &mut world.entries {
            entry.schema_version = 4;
        }
        world.entries[0].image_id = id.map(str::to_string);
        project
    }
    #[test]
    fn batch_reader_validates_identity_once_and_each_asset_path() {
        let (root, project) = fixture("batch-reader");
        let image = png(64, 32);
        store(&root, &project.id, IMAGE_ID, &image, &png(32, 16)).unwrap();
        assert!(ProjectImageReader::new(&root, "another-project").is_err());
        let reader = ProjectImageReader::new(&root, &project.id).unwrap();
        fs::rename(root.join("project.json"), root.join("project.saved.json")).unwrap();
        assert_eq!(reader.read(IMAGE_ID, false).unwrap(), image);
        assert!(reader.read("../escape", false).is_err());
        assert!(reader.read(SECOND_ID, false).is_err());
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn assets_survive_replacement_removal_history_recovery_and_project_move() {
        let (root, first) = fixture("history");
        let image = png(64, 32);
        let thumb = png(32, 16);
        let source = root.join("source.png");
        fs::write(&source, &image).unwrap();
        let chosen = select(&source).unwrap();
        store(&root, &first.id, IMAGE_ID, &chosen.bytes, &thumb).unwrap();
        fs::remove_file(source).unwrap();
        let second = storage::save(&root, attach(first.clone(), Some(IMAGE_ID))).unwrap();
        assert_eq!(
            storage::open(&root).unwrap().worldbuilding.unwrap().entries[0]
                .image_id
                .as_deref(),
            Some(IMAGE_ID)
        );
        let draft_root = root.join("draft-test");
        let draft = storage::Draft {
            project: second.clone(),
            path: root.to_string_lossy().into(),
            selected_id: second.chapters[0].scenes[0].id.clone(),
        };
        storage::write_draft(&draft_root, Some(draft)).unwrap();
        assert_eq!(
            storage::read_draft(&draft_root)
                .unwrap()
                .unwrap()
                .project
                .worldbuilding
                .unwrap()
                .entries[0]
                .image_id
                .as_deref(),
            Some(IMAGE_ID)
        );
        store(&root, &second.id, SECOND_ID, &image, &thumb).unwrap();
        let mut pending = attach(second.clone(), Some(SECOND_ID));
        pending.revision += 1;
        fs::write(
            root.join(".write-studio-transaction.json"),
            serde_json::to_vec(&pending).unwrap(),
        )
        .unwrap();
        let third = storage::open(&root).unwrap();
        assert_eq!(
            third.worldbuilding.as_ref().unwrap().entries[0]
                .image_id
                .as_deref(),
            Some(SECOND_ID)
        );
        assert!(!root.join(".write-studio-transaction.json").exists());
        let fourth = storage::save(&root, attach(third, None)).unwrap();
        assert!(
            storage::open(&root).unwrap().worldbuilding.unwrap().entries[0]
                .image_id
                .is_none()
        );
        assert_eq!(read(&root, &first.id, IMAGE_ID, false).unwrap(), image);
        let restored = history::restore(&root, second.revision, fourth.revision).unwrap();
        assert_eq!(
            restored.worldbuilding.unwrap().entries[0]
                .image_id
                .as_deref(),
            Some(IMAGE_ID)
        );
        assert_eq!(read(&root, &first.id, IMAGE_ID, true).unwrap(), thumb);
        let no_image = history::restore(&root, first.revision, restored.revision).unwrap();
        assert_eq!(no_image.worldbuilding.as_ref().unwrap().schema_version, 4);
        assert!(
            no_image.worldbuilding.unwrap().entries[0]
                .image_id
                .is_none()
        );
        let moved = root.with_extension("moved");
        fs::rename(&root, &moved).unwrap();
        assert_eq!(read(&moved, &first.id, IMAGE_ID, false).unwrap(), image);
        fs::remove_dir_all(moved).unwrap();
    }
    #[test]
    fn invalid_images_paths_and_overwrites_are_rejected() {
        let (root, project) = fixture("validation");
        let image = png(8, 8);
        assert!(store(&root, &project.id, "../outside", &image, &image).is_err());
        assert!(store(&root, "foreign", IMAGE_ID, &image, &image).is_err());
        assert!(store(&root, &project.id, IMAGE_ID, b"not an image", &image).is_err());
        assert!(store(&root, &project.id, IMAGE_ID, &image, &png(257, 1)).is_err());
        store(&root, &project.id, IMAGE_ID, &image, &image).unwrap();
        assert!(store(&root, &project.id, IMAGE_ID, &png(2, 2), &image).is_err());
        assert_eq!(read(&root, &project.id, IMAGE_ID, false).unwrap(), image);
        assert!(read(&root, &project.id, SECOND_ID, true).is_err());
        assert!(read(&root, &project.id, "../../project.json", false).is_err());
        let mut invalid = attach(project.clone(), Some("../../source"));
        assert!(storage::save(&root, invalid.clone()).is_err());
        invalid.worldbuilding.as_mut().unwrap().entries[0].image_id = Some(SECOND_ID.into());
        invalid.worldbuilding.as_mut().unwrap().schema_version = 3;
        for template in &mut invalid.worldbuilding.as_mut().unwrap().templates {
            template.schema_version = 3;
        }
        for entry in &mut invalid.worldbuilding.as_mut().unwrap().entries {
            entry.schema_version = 3;
        }
        assert!(storage::save(&root, invalid).is_err());
        fs::write(
            root.join("assets/images")
                .join(IMAGE_ID)
                .join("thumbnail.png"),
            b"damaged",
        )
        .unwrap();
        assert!(read(&root, &project.id, IMAGE_ID, true).is_err());
        fs::remove_dir_all(root).unwrap();
    }
    #[cfg(unix)]
    #[test]
    fn assets_cannot_escape_through_a_symbolic_link() {
        let (root, project) = fixture("symlink");
        let outside = root.with_extension("outside");
        fs::create_dir_all(&outside).unwrap();
        std::os::unix::fs::symlink(&outside, root.join("assets")).unwrap();
        let image = png(1, 1);
        assert!(store(&root, &project.id, IMAGE_ID, &image, &image).is_err());
        assert_eq!(fs::read_dir(&outside).unwrap().count(), 0);
        assert!(!outside.join("images").join(IMAGE_ID).exists());
        fs::remove_dir_all(root).unwrap();
        fs::remove_dir_all(outside).unwrap();
    }
    #[test]
    fn legacy_orphan_cleanup_respects_age_current_and_recovery(){
        use std::fs::FileTimes;
        use std::time::{SystemTime,Duration};
        let (root,saved)=fixture("orphan-gc");
        let recovery_root=std::env::temp_dir().join(format!("write-orphan-recovery-{}",std::process::id()));
        let current=attach(saved.clone(),Some(IMAGE_ID));
        let recent="00000000-0000-0000-0000-000000000965";
        for id in [IMAGE_ID,SECOND_ID,recent] {
            let folder=root.join(format!("assets/images/{id}"));fs::create_dir_all(&folder).unwrap();
            for name in ["image.png","thumbnail.png"] {let file=folder.join(name);fs::write(&file,b"asset").unwrap();if id!=recent {File::options().write(true).open(file).unwrap().set_times(FileTimes::new().set_modified(SystemTime::now()-Duration::from_secs(31*86400))).unwrap();}}
        }
        let recovery=attach(saved,Some(SECOND_ID));
        storage::write_draft(&recovery_root,Some(storage::Draft{project:recovery,path:root.to_string_lossy().into_owned(),selected_id:String::new()})).unwrap();
        collect_orphans(&root,&current,&recovery_root).unwrap();
        assert!(root.join(format!("assets/images/{SECOND_ID}/image.png")).exists());
        storage::write_draft(&recovery_root,None).unwrap();collect_orphans(&root,&current,&recovery_root).unwrap();
        assert!(!root.join(format!("assets/images/{SECOND_ID}")).exists());
        assert!(root.join(format!("assets/images/{IMAGE_ID}/image.png")).exists());assert!(root.join(format!("assets/images/{recent}/image.png")).exists());
        fs::remove_dir_all(root).unwrap();fs::remove_dir_all(recovery_root).unwrap();
    }

}

/// Only explicitly removed library assets are candidates. Never sweep arbitrary
/// folders: another import or a recovery draft may own an uncommitted asset.
pub fn collect_removed(path:&Path,current:&crate::storage::Project,candidates:&[String])->Result<(),String>{collect_with_recovery(path,current,candidates,None)}
fn collect_with_recovery(path:&Path,current:&crate::storage::Project,candidates:&[String],recovery:Option<&crate::storage::Project>)->Result<(),String>{
 if candidates.is_empty(){return Ok(());}
 use std::collections::HashSet;
 let mut referenced=HashSet::new();
 fn keep(project:&crate::storage::Project,ids:&mut HashSet<String>){
  if let Some(data)=&project.idea_canvases {ids.extend(crate::idea_canvas::image_ids(data).cloned());}
  if let Some(world)=&project.worldbuilding {ids.extend(crate::worldbuilding::image_ids(world).cloned());}
  if let Some(maps)=&project.maps {ids.extend(crate::maps::image_ids(maps).cloned());}
 }
 keep(current,&mut referenced);
 if let Some(recovery)=recovery {if recovery.id==current.id {keep(recovery,&mut referenced);}}
 // Pin only the assets present in migration backups, rather than retaining
 // every asset merely because any backup folder exists.
 let backups=path.join(".write-studio-backups");
 if backups.exists(){
  if fs::symlink_metadata(&backups).map_err(|e|e.to_string())?.file_type().is_symlink(){return Err("Invalid backup directory.".into());}
  for item in fs::read_dir(&backups).map_err(|e|e.to_string())? {
   let item=item.map_err(|e|e.to_string())?;
   if !item.file_type().map_err(|e|e.to_string())?.is_dir()||item.file_type().map_err(|e|e.to_string())?.is_symlink()||item.file_name().to_string_lossy().ends_with(".building"){return Err("Incomplete backup; image cleanup deferred.".into());}
   let marker:serde_json::Value=serde_json::from_slice(&fs::read(item.path().join("backup.json")).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
   if marker.get("projectId").and_then(|value|value.as_str())!=Some(current.id.as_str()){return Err("Backup belongs to another project.".into());}
   let mut assets=item.path();
   for part in ["assets","images"] {assets.push(part);if assets.exists()&&fs::symlink_metadata(&assets).map_err(|e|e.to_string())?.file_type().is_symlink(){return Err("Invalid backup asset directory.".into());}}
   if assets.exists(){for image in fs::read_dir(assets).map_err(|e|e.to_string())? {let image=image.map_err(|e|e.to_string())?;let id=image.file_name().to_string_lossy().into_owned();if !valid_id(&id){return Err("Unknown backup image; cleanup deferred.".into());}referenced.insert(id);}}
  }
 }
 let history=path.join(".write-studio-history");
 if history.exists(){
  if fs::symlink_metadata(&history).map_err(|e|e.to_string())?.file_type().is_symlink(){return Err("Invalid history directory.".into());}
  for item in fs::read_dir(history).map_err(|e|e.to_string())? {
   let item=item.map_err(|e|e.to_string())?;let name=item.file_name().to_string_lossy().into_owned();
   if name=="checkpoints.json" {continue;}
   let revision=name.strip_prefix("r-").and_then(|v|v.strip_suffix(".json")).and_then(|v|v.parse::<u64>().ok()).ok_or("Unsupported history file; image retained.")?;
   if item.file_type().map_err(|e|e.to_string())?.is_symlink(){return Err("Invalid history file.".into());}
   let version=crate::history::read(path,revision)?;
   if version.id!=current.id{return Err("History belongs to another project.".into());}
   keep(&version,&mut referenced);
  }
 }
 let root=project_root(path,&current.id)?;
 let mut directory=root.clone();
 for name in ["assets","images"] {directory.push(name);if !directory.exists(){return Ok(());}let meta=fs::symlink_metadata(&directory).map_err(|e|e.to_string())?;if meta.file_type().is_symlink()||!meta.is_dir(){return Err("Invalid image directory.".into());}}
 for id in candidates {
  if !valid_id(id)||referenced.contains(id){continue;}
  let folder=directory.join(id);if !folder.exists(){continue;}
  let meta=fs::symlink_metadata(&folder).map_err(|e|e.to_string())?;if meta.file_type().is_symlink()||!meta.is_dir(){continue;}
  let files=fs::read_dir(&folder).map_err(|e|e.to_string())?.collect::<Result<Vec<_>,_>>().map_err(|e|e.to_string())?;
  if files.iter().any(|file|!matches!(file.file_name().to_str(),Some("image.png"|"thumbnail.png"))||file.file_type().map_or(true,|kind|!kind.is_file()||kind.is_symlink())){continue;}
  for file in files {fs::remove_file(file.path()).map_err(|e|e.to_string())?;}
  fs::remove_dir(folder).map_err(|e|e.to_string())?;
 }
 Ok(())
}

/// Legacy or replaced assets have no deletion metadata. Give them a full 30-day
/// grace period and verify current, trash, recovery, history and backup usage.
pub fn collect_orphans(path:&Path,current:&crate::storage::Project,recovery_root:&Path)->Result<(),String>{
 use std::time::{SystemTime,UNIX_EPOCH};
 let recovery=crate::storage::read_draft(recovery_root)?;
 let now=SystemTime::now().duration_since(UNIX_EPOCH).map_err(|e|e.to_string())?.as_secs();
 let mut directory=project_root(path,&current.id)?;
 for part in ["assets","images"] {directory.push(part);if !directory.exists(){return Ok(());}let meta=fs::symlink_metadata(&directory).map_err(|e|e.to_string())?;if meta.file_type().is_symlink()||!meta.is_dir(){return Err("Invalid image directory.".into());}}
 let mut candidates=Vec::new();
 for item in fs::read_dir(directory).map_err(|e|e.to_string())? {
  let item=item.map_err(|e|e.to_string())?;let id=item.file_name().to_string_lossy().into_owned();
  let kind=item.file_type().map_err(|e|e.to_string())?;if !valid_id(&id)||!kind.is_dir()||kind.is_symlink(){continue;}
  let mut old=true;let files=fs::read_dir(item.path()).map_err(|e|e.to_string())?.collect::<Result<Vec<_>,_>>().map_err(|e|e.to_string())?;
  if files.is_empty(){continue;}
  for file in files {
   let kind=file.file_type().map_err(|e|e.to_string())?;
   if !kind.is_file()||kind.is_symlink()||!matches!(file.file_name().to_str(),Some("image.png"|"thumbnail.png")){old=false;break;}
   let modified=file.metadata().and_then(|meta|meta.modified()).map_err(|e|e.to_string())?.duration_since(UNIX_EPOCH).map_err(|e|e.to_string())?.as_secs();
   if modified>now||now-modified<30*86400 {old=false;break;}
  }
  if old {candidates.push(id);}
 }
 collect_with_recovery(path,current,&candidates,recovery.as_ref().map(|draft|&draft.project))
}
