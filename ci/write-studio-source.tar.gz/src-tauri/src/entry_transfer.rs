use crate::{worldbuilding,entry_images};
use serde::{Serialize,Deserialize};
use std::{collections::HashSet,fs::File,io::Read,path::Path};
const MAX_BYTES:usize=64*1024*1024;
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct EntryPackage {#[serde(default,skip_serializing_if="Option::is_none")]pub entry_relations:Option<crate::entry_relations::EntryRelations>,pub format:String,pub schema_version:u32,pub root_entry_ids:Vec<String>,pub worldbuilding:worldbuilding::Worldbuilding,pub images:Vec<PackageImage>}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(deny_unknown_fields)]
pub struct PackageImage {pub id:String,pub image:Vec<u8>,pub thumbnail:Vec<u8>}
pub fn validate(packet:&EntryPackage)->Result<(),String>{
 if packet.format!="write-studio-entries"||packet.schema_version!=1{return Err("Unsupported entry file format or version.".into());}
 if packet.root_entry_ids.is_empty()||packet.worldbuilding.entries.is_empty()||packet.worldbuilding.entries.len()>10000{return Err("Select between 1 and 10,000 entries.".into());}
 let mut ids=HashSet::new();worldbuilding::validate(&packet.worldbuilding,&mut |id|{if !entry_images::valid_id(id)||!ids.insert(id.to_string()){return Err("Invalid or duplicate entry package identifier.".into());}Ok(())})?;
 if let Some(relations)=&packet.entry_relations{crate::entry_relations::validate(relations,&mut |id|{if !entry_images::valid_id(id)||!ids.insert(id.to_string()){return Err("Invalid or duplicate entry package identifier.".into());}Ok(())})?;}
 let entries:HashSet<_>=packet.worldbuilding.entries.iter().map(|entry|entry.id.as_str()).collect();let mut roots=HashSet::new();
 if packet.root_entry_ids.iter().any(|id|!entries.contains(id.as_str())||!roots.insert(id)){return Err("Invalid entry selection.".into());}
 let expected:HashSet<_>=worldbuilding::image_ids(&packet.worldbuilding).map(|id|id.as_str()).collect();let mut images=HashSet::new();
 for image in &packet.images {if !entry_images::valid_id(&image.id)||!expected.contains(image.id.as_str())||!images.insert(image.id.as_str()){return Err("Invalid entry package image.".into());}entry_images::validate_png(&image.image,2048)?;entry_images::validate_png(&image.thumbnail,256)?;}
 if images!=expected{return Err("The entry package is missing an image.".into());}
 if serde_json::to_vec(packet).map_err(|error|error.to_string())?.len()>MAX_BYTES{return Err("Entry files must be smaller than 64 MB.".into());}Ok(())
}
pub fn read(path:&Path)->Result<EntryPackage,String>{let mut bytes=Vec::new();File::open(path).map_err(|error|error.to_string())?.take((MAX_BYTES+1) as u64).read_to_end(&mut bytes).map_err(|error|error.to_string())?;if bytes.len()>MAX_BYTES{return Err("Entry files must be smaller than 64 MB.".into());}let packet=serde_json::from_slice(&bytes).map_err(|_|"This is not a valid Write Studio entry file.".to_string())?;validate(&packet)?;Ok(packet)}
pub fn write(path:&Path,packet:&EntryPackage)->Result<(),String>{validate(packet)?;{let bytes=serde_json::to_vec_pretty(packet).map_err(|error|error.to_string())?;if bytes.len()>MAX_BYTES{return Err("Entry files must be smaller than 64 MB.".into());}crate::export::write_new(path,&bytes)}}
#[cfg(test)]
mod tests {
 use super::*;
 fn png()->Vec<u8>{let mut bytes=Vec::new();{let mut encoder=png::Encoder::new(&mut bytes,2,2);encoder.set_color(png::ColorType::Rgba);encoder.set_depth(png::BitDepth::Eight);let mut writer=encoder.write_header().unwrap();writer.write_image_data(&[128;16]).unwrap();}bytes}
 fn packet()->EntryPackage{
  let project:crate::storage::Project=serde_json::from_str(include_str!("../../tests/fixtures/worldbuilding-project.json")).unwrap();let mut world=project.worldbuilding.unwrap();world.schema_version=9;for template in &mut world.templates{template.schema_version=9;}for entry in &mut world.entries{entry.schema_version=9;}
  let id="00000000-0000-0000-0000-000000000980".to_string();world.entries[0].image_id=Some(id.clone());
  EntryPackage{entry_relations:None,format:"write-studio-entries".into(),schema_version:1,root_entry_ids:vec![world.entries[0].id.clone()],worldbuilding:world,images:vec![PackageImage{id,image:png(),thumbnail:png()}]}
 }
 #[test]
 fn portable_entries_roundtrip_images_and_no_overwrite(){
  let mut packet=packet();packet.entry_relations=Some(serde_json::from_value(serde_json::json!({"schemaVersion":1,"types":[{"id":"00000000-0000-0000-0000-000000000950","title":"Friends","inverseTitle":"Friends","symmetric":true,"sourceTemplateIds":[],"targetTemplateIds":[]}],"links":[{"id":"00000000-0000-0000-0000-000000000951","typeId":"00000000-0000-0000-0000-000000000950","sourceId":packet.worldbuilding.entries[0].id,"targetId":packet.worldbuilding.entries[1].id}]})).unwrap());validate(&packet).unwrap();let root=std::env::temp_dir().join(format!("write-studio-entry-transfer-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();let path=root.join("fichas 世界.json");write(&path,&packet).unwrap();let expected=std::fs::read(&path).unwrap();let loaded=read(&path).unwrap();assert_eq!(serde_json::to_value(&loaded).unwrap(),serde_json::to_value(&packet).unwrap());assert!(write(&path,&packet).is_err());assert_eq!(std::fs::read(&path).unwrap(),expected);std::fs::remove_dir_all(root).unwrap();
 }
 #[test]
 fn rejects_invalid_entry_files_and_incomplete_images(){
  for case in ["format","version","missing-image","invalid-image","duplicate-root","unknown-root","duplicate-id"]{let mut packet=packet();match case{"format"=>packet.format="other".into(),"version"=>packet.schema_version=2,"missing-image"=>packet.images.clear(),"invalid-image"=>packet.images[0].image=vec![0],"duplicate-root"=>packet.root_entry_ids.push(packet.root_entry_ids[0].clone()),"unknown-root"=>packet.root_entry_ids=vec!["00000000-0000-0000-0000-000000000999".into()],_=>packet.worldbuilding.entries[0].id=packet.worldbuilding.templates[0].id.clone()}assert!(validate(&packet).is_err(),"{}",case);}
  assert!(serde_json::from_str::<EntryPackage>(r#"{"format":"write-studio-entries"}"#).is_err());
 }
}
