use crate::{entry_images, history, storage};
use serde::{Deserialize, Serialize};
use std::{
    collections::{BTreeMap, HashMap, HashSet},
    fs::{self, File, FileTimes, OpenOptions},
    io::{Read, Write},
    path::{Path, PathBuf},
    sync::atomic::{AtomicU64, Ordering},
    time::{Duration, SystemTime, UNIX_EPOCH},
};
use zip::{ZipArchive, ZipWriter, write::SimpleFileOptions};
const MANIFEST: &str = ".write-studio-backup.json";
const FOLDERS: [&str; 5] = [
    "manuscript",
    "worldbuilding",
    "assets",
    ".write-studio-history",
    ".write-studio-backups",
];
const MAX_FILES: usize = 100_000;
const MAX_FILE: u64 = 256 * 1024 * 1024;
const MAX_TOTAL: u64 = 4 * 1024 * 1024 * 1024;
static COUNTER: AtomicU64 = AtomicU64::new(0);
fn err(error: impl std::fmt::Display) -> String {
    error.to_string()
}
fn stamp() -> u64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .unwrap_or_default()
        .as_secs()
}
fn nonce() -> String {
    format!(
        "{}-{}-{}",
        stamp(),
        std::process::id(),
        COUNTER.fetch_add(1, Ordering::Relaxed)
    )
}
#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct BackupFile {
    path: String,
    size: u64,
    modified_at: u64,
}
#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Manifest {
    schema_version: u32,
    project_id: String,
    title: String,
    revision: u64,
    created_at: u64,
    files: Vec<BackupFile>,
}
struct TemporaryFolder(PathBuf);
impl TemporaryFolder {
    fn new(parent: &Path, label: &str) -> Result<Self, String> {
        for _ in 0..100 {
            let path = parent.join(format!(".write-studio-{label}-{}", nonce()));
            match fs::create_dir(&path) {
                Ok(()) => return Ok(Self(path)),
                Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => continue,
                Err(error) => return Err(err(error)),
            }
        }
        Err("Could not reserve a temporary backup folder.".into())
    }
}
impl Drop for TemporaryFolder {
    fn drop(&mut self) {
        let _ = fs::remove_dir_all(&self.0);
    }
}
// Apply the same portable filename rules on every host, before extraction.
fn reserved_component(part: &str) -> bool {
    let stem = part.split('.').next().unwrap_or("").trim_end_matches(' ').to_uppercase();
    matches!(stem.as_str(), "CON" | "PRN" | "AUX" | "NUL" | "CONIN$" | "CONOUT$")
        || ["COM", "LPT"].iter().any(|prefix| stem.strip_prefix(prefix)
            .is_some_and(|suffix| matches!(suffix, "1" | "2" | "3" | "4" | "5" | "6" | "7" | "8" | "9" | "¹" | "²" | "³")))
}
/// Record both files and their implicit directories. Reject case aliases and
/// file/directory conflicts regardless of ZIP order or the host filesystem.
#[derive(Default)]
struct PortableNames(HashMap<String, (String, bool)>);
impl PortableNames {
    fn insert(&mut self, name: &str) -> Result<(), String> {
        let parts: Vec<_> = name.split('/').collect();
        let mut path = String::new();
        for (index, part) in parts.iter().enumerate() {
            if index > 0 { path.push('/'); }
            path.push_str(part);
            let is_file = index + 1 == parts.len();
            let key = path.to_lowercase();
            if let Some((original, previous_file)) = self.0.get(&key) {
                if original != &path || *previous_file || is_file {
                    return Err("Backup filenames conflict across platforms. Rename the conflicting files before backing up.".into());
                }
            } else { self.0.insert(key, (path.clone(), is_file)); }
        }
        Ok(())
    }
}
fn safe_path(name: &str) -> bool {
    if name.is_empty()
        || name.len() > 1024
        || name.contains(['\\', ':', '<', '>', '"', '|', '?', '*'])
        || name.chars().any(char::is_control)
        || name.split('/').any(|part| {
            part.is_empty() || part == "." || part == ".." || part.ends_with([' ', '.'])
                || reserved_component(part)
        })
    {
        return false;
    }
    name == "project.json"
        || name
            .split_once('/')
            .is_some_and(|(folder, _)| FOLDERS.contains(&folder))
}
fn collect(root: &Path) -> Result<Vec<BackupFile>, String> {
    fn walk(
        root: &Path,
        path: &Path,
        files: &mut Vec<BackupFile>,
        total: &mut u64,
    ) -> Result<(), String> {
        let metadata = fs::symlink_metadata(path).map_err(err)?;
        if metadata.file_type().is_symlink() {
            return Err(format!(
                "Backup cannot follow symbolic links: {}",
                path.display()
            ));
        }
        if metadata.is_dir() {
            for item in fs::read_dir(path).map_err(err)? {
                walk(root, &item.map_err(err)?.path(), files, total)?;
            }
        } else if metadata.is_file() {
            let name = path
                .strip_prefix(root)
                .map_err(err)?
                .to_str()
                .ok_or("A project filename is not valid Unicode.")?
                .replace(std::path::MAIN_SEPARATOR, "/");
            if !safe_path(&name) {
                return Err("The project contains an unsupported filename.".into());
            }
            if metadata.len() > MAX_FILE || files.len() >= MAX_FILES {
                return Err("This project exceeds the backup file limits.".into());
            }
            *total = total
                .checked_add(metadata.len())
                .ok_or("Backup size overflow.")?;
            if *total > MAX_TOTAL {
                return Err("This project exceeds the 4 GB backup limit.".into());
            }
            files.push(BackupFile {
                path: name,
                size: metadata.len(),
                modified_at: metadata
                    .modified()
                    .ok()
                    .and_then(|value| value.duration_since(UNIX_EPOCH).ok())
                    .map(|value| value.as_secs())
                    .unwrap_or(0),
            });
        } else {
            return Err("Backup supports regular files and directories only.".into());
        }
        Ok(())
    }
    let mut files = Vec::new();
    let mut total = 0;
    walk(root, &root.join("project.json"), &mut files, &mut total)?;
    for folder in FOLDERS {
        let path = root.join(folder);
        if path.exists() || fs::symlink_metadata(&path).is_ok() {
            walk(root, &path, &mut files, &mut total)?;
        }
    }
    let mut names = PortableNames::default();
    for file in &files { names.insert(&file.path)?; }
    files.sort_by(|a, b| a.path.cmp(&b.path));
    Ok(files)
}
fn verify_project(root: &Path) -> Result<storage::Project, String> {
    let project = storage::open(root)?;
    let mut images = HashSet::new();
    fn references(project: &storage::Project, images: &mut HashSet<String>) {
        if let Some(data)=&project.idea_canvases {images.extend(crate::idea_canvas::image_ids(data).cloned());}
        if let Some(maps) = &project.maps {
            for id in crate::maps::image_ids(maps) {images.insert(id.clone());}
        }
        if let Some(world) = &project.worldbuilding {
            for id in crate::worldbuilding::image_ids(world) {images.insert(id.clone());}
        }
    }
    references(&project, &mut images);
    history::validate_checkpoints(root, &project)?;
    let directory = root.join(".write-studio-history");
    if directory.exists() {
        for item in fs::read_dir(&directory).map_err(err)? {
            let item = item.map_err(err)?;
            let name = item.file_name().to_string_lossy().into_owned();
            if name == "checkpoints.json" { continue; }
            let revision = name
                .strip_prefix("r-")
                .and_then(|value| value.strip_suffix(".json"))
                .and_then(|value| value.parse::<u64>().ok())
                .ok_or("The project history contains an unsupported file.")?;
            let version = history::read(root, revision)?;
            if version.id != project.id {
                return Err("A historical version belongs to another project.".into());
            }
            references(&version, &mut images);
        }
    }
    if !images.is_empty() {
        // Validate the project identity once for this immutable asset batch.
        // Each read still validates the ID, canonical path, size and PNG bytes.
        let reader = entry_images::ProjectImageReader::new(root, &project.id)?;
        for id in images {
            reader.read(&id, false)
                .map_err(|error| format!("Cannot back up or restore image {id}: {error}"))?;
            reader.read(&id, true)
                .map_err(|error| format!("Cannot back up or restore thumbnail {id}: {error}"))?;
        }
    }
    Ok(project)
}
fn inspect(archive: &mut ZipArchive<File>) -> Result<Manifest, String> {
    if archive.len() > MAX_FILES + 1 {
        return Err("The ZIP contains too many files.".into());
    }
    let mut names = PortableNames::default();
    let mut actual = BTreeMap::new();
    let mut total = 0u64;
    for index in 0..archive.len() {
        let file = archive.by_index(index).map_err(err)?;
        let name = file.name();
        if (name != MANIFEST && !safe_path(name))
            || file.enclosed_name().is_none()
            || file.is_dir()
            || file.is_symlink()
            || file.encrypted()
            || file
                .unix_mode()
                .is_some_and(|mode| !matches!(mode & 0o170000, 0 | 0o100000))
        {
            return Err("The ZIP contains an unsafe or unsupported file.".into());
        }
        names.insert(name)?;
        if file.size() > MAX_FILE {
            return Err("A ZIP entry exceeds the 256 MB file limit.".into());
        }
        total = total.checked_add(file.size()).ok_or("ZIP size overflow.")?;
        if total > MAX_TOTAL {
            return Err("The ZIP exceeds the 4 GB uncompressed limit.".into());
        }
        if name != MANIFEST {
            actual.insert(name.to_string(), file.size());
        }
    }
    let mut bytes = Vec::new();
    archive
        .by_name(MANIFEST)
        .map_err(|_| "Choose a Write Studio backup ZIP.".to_string())?
        .take(32 * 1024 * 1024 + 1)
        .read_to_end(&mut bytes)
        .map_err(err)?;
    if bytes.len() > 32 * 1024 * 1024 {
        return Err("The backup manifest is too large.".into());
    }
    let manifest: Manifest = serde_json::from_slice(&bytes).map_err(err)?;
    if manifest.schema_version != 1 || manifest.files.len() > MAX_FILES {
        return Err("Unsupported backup version.".into());
    }
    let expected: BTreeMap<_, _> = manifest
        .files
        .iter()
        .map(|file| (file.path.clone(), file.size))
        .collect();
    if expected.len() != manifest.files.len()
        || expected != actual
        || !expected.contains_key("project.json")
    {
        return Err("The backup is incomplete or its manifest does not match.".into());
    }
    Ok(manifest)
}
fn extract(
    archive: &mut ZipArchive<File>,
    manifest: &Manifest,
    destination: &Path,
) -> Result<storage::Project, String> {
    for descriptor in &manifest.files {
        let path = destination.join(&descriptor.path);
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).map_err(err)?;
        }
        let mut output = OpenOptions::new()
            .create_new(true)
            .write(true)
            .open(&path)
            .map_err(err)?;
        let mut input = archive
            .by_name(&descriptor.path)
            .map_err(err)?
            .take(descriptor.size + 1);
        let bytes = std::io::copy(&mut input, &mut output).map_err(err)?;
        if bytes != descriptor.size {
            return Err("A backup file has an incorrect length.".into());
        }
        let modified = UNIX_EPOCH
            .checked_add(Duration::from_secs(descriptor.modified_at))
            .ok_or("Invalid backup modification time.")?;
        output
            .set_times(FileTimes::new().set_modified(modified))
            .map_err(err)?;
        output.sync_all().map_err(err)?;
    }
    fn sync_directories(path: &Path) -> Result<(), String> {
        for item in fs::read_dir(path).map_err(err)? {
            let path = item.map_err(err)?.path();
            if path.is_dir() {
                sync_directories(&path)?;
            }
        }
        crate::storage::sync_directory(path)
            .map_err(err)
    }
    sync_directories(destination)?;
    let project = verify_project(destination)?;
    if project.id != manifest.project_id
        || project.revision != manifest.revision
        || project.title != manifest.title
    {
        return Err("The backup metadata does not match its project.".into());
    }
    Ok(project)
}
pub fn create(
    root: &Path,
    destination: &Path,
    project_id: &str,
    revision: u64,
) -> Result<(), String> {
    let root = root.canonicalize().map_err(err)?;
    let parent = destination
        .parent()
        .ok_or("Choose a ZIP destination.")?
        .canonicalize()
        .map_err(err)?;
    if parent.starts_with(&root) {
        return Err("Save the backup outside the project folder.".into());
    }
    if destination.exists() {
        return Err(
            "A file already exists at this destination. Choose a new backup filename.".into(),
        );
    }
    let project = verify_project(&root)?;
    if project.id != project_id || project.revision != revision {
        return Err("The project changed on disk. Reopen it before making a backup.".into());
    }
    history::capture(&root, &project)?;
    let manifest = Manifest {
        schema_version: 1,
        project_id: project.id.clone(),
        title: project.title.clone(),
        revision: project.revision,
        created_at: stamp(),
        files: collect(&root)?,
    };
    let temporary = TemporaryFolder::new(&parent, "backup")?;
    let zip_path = temporary.0.join("backup.zip");
    let mut writer = ZipWriter::new(File::create(&zip_path).map_err(err)?);
    let options = SimpleFileOptions::default()
        .compression_method(zip::CompressionMethod::Deflated)
        .unix_permissions(0o600);
    for descriptor in &manifest.files {
        let source = root.join(&descriptor.path);
        if fs::symlink_metadata(&source)
            .map_err(err)?
            .file_type()
            .is_symlink()
        {
            return Err("A project file changed while making the backup.".into());
        }
        writer.start_file(&descriptor.path, options).map_err(err)?;
        let length = std::io::copy(
            &mut File::open(source).map_err(err)?.take(descriptor.size + 1),
            &mut writer,
        )
        .map_err(err)?;
        if length != descriptor.size {
            return Err("A project file changed while making the backup.".into());
        }
    }
    writer.start_file(MANIFEST, options).map_err(err)?;
    writer
        .write_all(&serde_json::to_vec_pretty(&manifest).map_err(err)?)
        .map_err(err)?;
    writer.finish().map_err(err)?.sync_all().map_err(err)?;
    // Read every entry back (including CRC checks), then reopen the extracted project and history.
    let mut archive = ZipArchive::new(File::open(&zip_path).map_err(err)?).map_err(err)?;
    let checked = inspect(&mut archive)?;
    let verification = temporary.0.join("verified");
    fs::create_dir(&verification).map_err(err)?;
    extract(&mut archive, &checked, &verification)?;
    if serde_json::to_vec(&storage::open(&root)?).map_err(err)?
        != serde_json::to_vec(&project).map_err(err)?
    {
        return Err("The project changed while making the backup. Create a new copy.".into());
    }
    let mut source = File::open(&zip_path).map_err(err)?;
    let mut output = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(destination)
        .map_err(err)?;
    if let Err(error) = std::io::copy(&mut source, &mut output).and_then(|_| output.sync_all()) {
        drop(output);
        let _ = fs::remove_file(destination);
        return Err(err(error));
    }
    crate::storage::sync_directory(parent)
        .map_err(err)?;
    Ok(())
}
fn slug(title: &str) -> String {
    let value = title
        .to_lowercase()
        .chars()
        .map(|c| if c.is_ascii_alphanumeric() { c } else { '-' })
        .collect::<String>();
    let value = value
        .split('-')
        .filter(|value| !value.is_empty())
        .collect::<Vec<_>>()
        .join("-");
    if value.is_empty() {
        "project".into()
    } else {
        value.chars().take(48).collect()
    }
}
pub fn restore(archive_path: &Path, parent: &Path) -> Result<storage::OpenProject, String> {
    let parent = parent.canonicalize().map_err(err)?;
    if !parent.is_dir() {
        return Err("Choose an existing destination folder.".into());
    }
    if fs::metadata(archive_path).map_err(err)?.len() > MAX_TOTAL {
        return Err("The ZIP exceeds the 4 GB limit.".into());
    }
    let mut archive = ZipArchive::new(File::open(archive_path).map_err(err)?).map_err(err)?;
    let manifest = inspect(&mut archive)?;
    let temporary = TemporaryFolder::new(&parent, "restore")?;
    let project = extract(&mut archive, &manifest, &temporary.0)?;
    // Reserve an entirely new directory. Existing folders and projects are never reused.
    let mut destination = None;
    for _ in 0..100 {
        let candidate = parent.join(format!("{}-restored-{}", slug(&project.title), nonce()));
        match fs::create_dir(&candidate) {
            Ok(()) => {
                destination = Some(candidate);
                break;
            }
            Err(error) if error.kind() == std::io::ErrorKind::AlreadyExists => continue,
            Err(error) => return Err(err(error)),
        }
    }
    let destination = destination.ok_or("Could not reserve a new restore folder.")?;
    let publication = (|| -> Result<(), String> {
        for item in fs::read_dir(&temporary.0).map_err(err)? {
            let item = item.map_err(err)?;
            fs::rename(item.path(), destination.join(item.file_name())).map_err(err)?;
        }
        crate::storage::sync_directory(&destination)
            .map_err(err)?;
        crate::storage::sync_directory(&parent)
            .map_err(err)?;
        Ok(())
    })();
    if let Err(error) = publication {
        let _ = fs::remove_dir_all(&destination);
        return Err(error);
    }
    Ok(storage::OpenProject {
        path: destination.to_string_lossy().into(),
        project,
    })
}
#[cfg(test)]
mod tests {
    use super::*;
    const IMAGE: &str = "00000000-0000-0000-0000-000000000901";
    fn png() -> Vec<u8> {
        let mut data = Vec::new();
        {
            let mut encoder = png::Encoder::new(&mut data, 2, 1);
            encoder.set_color(png::ColorType::Rgba);
            let mut writer = encoder.write_header().unwrap();
            writer
                .write_image_data(&[255, 0, 0, 255, 0, 0, 255, 255])
                .unwrap();
        }
        data
    }
    pub(super) fn fixture() -> (TemporaryFolder, PathBuf, storage::Project) {
        let temporary = TemporaryFolder::new(&std::env::temp_dir(), "backup-test").unwrap();
        let root = temporary.0.join("source");
        fs::create_dir(&root).unwrap();
        let mut project: storage::Project = serde_json::from_str(include_str!(
            "../../tests/fixtures/worldbuilding-project.json"
        ))
        .unwrap();
        project.title = "Árbol 世界 🌿".into();
        let first = storage::save(&root, project).unwrap();
        let mut next = first.clone();
        next.books=vec![storage::Book{id:"00000000-0000-0000-0000-000000088881".into(),title:"Primer libro".into(),chapter_ids:next.chapters.iter().map(|chapter|chapter.id.clone()).collect()},storage::Book{id:"00000000-0000-0000-0000-000000088882".into(),title:"Continuación".into(),chapter_ids:vec![]}];
        next.plots=Some(serde_json::from_value(serde_json::json!({"schemaVersion":1,"threads":[{"id":"00000000-0000-0000-0000-000000000980","title":"The disappearance","color":"violet","status":"active","notes":"Find the truth","beats":[{"sceneId":next.chapters[0].scenes[0].id,"note":"First clue"}]}]})).unwrap());
        next.chapters[0].scenes[0].content = Some("Últimos cambios **sin perder** 🌿".into());
        next.chapters[0].scenes[0].review_comments.push(storage::ReviewComment{id:"00000000-0000-0000-0000-000000000989".into(),from:1,to:8,quote:"Últimos".into(),text:"Review this passage".into(),resolved:false,detached:false});
        next.timeline=Some(serde_json::from_value(serde_json::json!({"schemaVersion":4,"relationTypes":[{"id":"00000000-0000-0000-0000-000000000969","title":"Participants","templateIds":[]}],"tracks":[{"id":"00000000-0000-0000-0000-000000000970","title":"Main story","eventIds":["00000000-0000-0000-0000-000000000990"]}],"events":[{"id":"00000000-0000-0000-0000-000000000990","title":"Before winter","notes":"Notes","dateLabel":"Long ago","start":{"year":-12},"sceneIds":[next.chapters[0].scenes[0].id],"entryIds":[],"relations":[{"relationId":"00000000-0000-0000-0000-000000000969","entryIds":["00000000-0000-0000-0000-000000000968"]}],"plotIds":["00000000-0000-0000-0000-000000000906"]}]})).unwrap());
        let world = next.worldbuilding.as_mut().unwrap();
        world.schema_version = 7;
        for template in &mut world.templates {
            template.schema_version = 7;
        }
        for entry in &mut world.entries {
            entry.schema_version = 7;
        }
        world.entries[0].image_id = Some(IMAGE.into());
        world.schema_version=12;for template in &mut world.templates{template.schema_version=12;}for entry in &mut world.entries{entry.schema_version=12;}
        world.entries[0].image_ids=vec![IMAGE.into()];
        world.visual_resources=vec![crate::worldbuilding::VisualResource{id:IMAGE.into(),title:"Shared portrait".into(),notes:"Portable metadata".into(),category:Some("portrait".into()),caption:Some("Portrait caption".into()),..Default::default()},crate::worldbuilding::VisualResource{id:"00000000-0000-0000-0000-000000000905".into(),title:"Standalone sheet".into(),notes:"Not linked to an entry".into(),category:Some("portrait".into()),caption:Some("Alternative portrait".into()),variant_of:Some(IMAGE.into()),variant_label:Some("Travel clothes".into()),original_filename:Some("travel-clothes.webp".into()),deleted_at:Some(SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64),..Default::default()}];
        world.templates[0].fields.push(serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000994","label":"Climate","fieldType":"picklist","archived":false,"options":[{"id":"00000000-0000-0000-0000-000000000995","label":"Cold","archived":false}]})).unwrap());
        world.templates[0].fields.push(serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000996","label":"Tags","fieldType":"multiPicklist","archived":false,"options":[{"id":"00000000-0000-0000-0000-000000000997","label":"Port","archived":true}]})).unwrap());
        world.templates[0].fields.push(serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000998","label":"Birth date","fieldType":"date","archived":false,"isBirthDate":true})).unwrap());
        world.templates[0].sections=Some(vec![serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000999","title":"Basic information"})).unwrap()]);
        world.templates[0].fields.last_mut().unwrap().section_id =
            Some("00000000-0000-0000-0000-000000000999".into());
        let template_id = world.templates[0].id.clone();
        for entry in &mut world.entries {
            if entry.template_id == template_id {
                entry.values.insert(
                    "00000000-0000-0000-0000-000000000998".into(),
                    serde_json::json!({"year":0,"month":2,"day":29}),
                );
                entry.values.insert(
                    "00000000-0000-0000-0000-000000000994".into(),
                    serde_json::json!("00000000-0000-0000-0000-000000000995"),
                );
                entry.values.insert(
                    "00000000-0000-0000-0000-000000000996".into(),
                    serde_json::json!(["00000000-0000-0000-0000-000000000997"]),
                );
            }
        }

        next.entry_relations=Some(serde_json::from_value(serde_json::json!({"schemaVersion":1,"types":[{"id":"00000000-0000-0000-0000-000000000950","title":"Friends","inverseTitle":"Friends","symmetric":true,"sourceTemplateIds":[],"targetTemplateIds":[]}],"links":[{"id":"00000000-0000-0000-0000-000000000951","typeId":"00000000-0000-0000-0000-000000000950","sourceId":world.entries[0].id,"targetId":world.entries[1].id}]})).unwrap());
        next.maps=Some(serde_json::from_value(serde_json::json!({"schemaVersion":1,"maps":[{"id":"00000000-0000-0000-0000-000000000991","title":"Coast","notes":"Map notes","imageId":"00000000-0000-0000-0000-000000000993","markers":[{"id":"00000000-0000-0000-0000-000000000992","title":"Harbor","notes":"Arrival","x":0.25,"y":0.75,"color":"teal","icon":"city","entryId":world.entries[0].id}]}]})).unwrap());
        let layered=next.maps.as_mut().unwrap();layered.schema_version=10;
        layered.maps[0].layers.push(crate::maps::MapLayer{locked:false,id:"00000000-0000-0000-0000-000000000981".into(),title:"Hidden cities".into(),visible:false});
        layered.maps[0].markers[0].layer_id=Some(layered.maps[0].layers[0].id.clone());
        layered.maps[0].drawing=Some(serde_json::from_value(serde_json::json!({"width":1600,"height":1000,"strokes":[{"kind":"land","width":0.1,"points":[{"x":0.4,"y":0.5}]}],"objects":[{"id":"00000000-0000-0000-0000-000000000979","kind":"label","x":0.5,"y":0.5,"size":0.02,"text":"Sea 世界"}]})).unwrap());
        let artwork=layered.maps[0].drawing.as_mut().unwrap();artwork.theme=Some("space".into());artwork.background=Some("#101629".into());artwork.strokes[0].color=Some("#5f417b".into());
        artwork.objects.push(serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000978","kind":"line","x":0.1,"y":0.2,"endX":0.8,"endY":0.7,"size":0.065,"lineWidth":0.004,"color":"#e3e9ff"})).unwrap());
        artwork.terrain_colors=Some(std::collections::BTreeMap::from([("land".into(),"#112233".into())]));artwork.objects.last_mut().unwrap().kind="ellipse".into();artwork.objects.last_mut().unwrap().fill=Some("#112233".into());
        let data = png();
        entry_images::store(&root, &next.id, IMAGE, &data, &data).unwrap();
        entry_images::store(&root,&next.id,"00000000-0000-0000-0000-000000000905",&data,&data).unwrap();
        entry_images::store(
            &root,
            &next.id,
            "00000000-0000-0000-0000-000000000993",
            &data,
            &data,
        )
        .unwrap();
        let saved = storage::save(&root, next).unwrap();
        (temporary, root, saved)
    }
    #[test]
    fn material_masks_survive_backup_restore(){
        let (temporary,root,mut project)=fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=28;let drawing=maps.maps[0].drawing.as_mut().unwrap();let mut stroke=drawing.strokes[0].clone();stroke.material_mask=Some(crate::maps::MaterialMask{id:"10000000-0000-0000-0000-000000000021".into(),target:"grass".into(),groups:vec![vec![0]],water_background:false});drawing.strokes.push(stroke);
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();let target=temporary.0.join("material-masks.zip");create(&root,&target,&saved.id,saved.revision).unwrap();let restored=restore(&target,&temporary.0).unwrap();assert_eq!(serde_json::to_value(&restored.project.maps).unwrap(),expected);
    }
    #[test]
    fn terrain_masks_survive_backup_restore(){
        let (temporary,root,mut project)=fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=27;
        maps.maps[0].drawing.as_mut().unwrap().strokes[0].mask=Some(serde_json::from_value(serde_json::json!({"points":[{"x":0.1,"y":0.1},{"x":0.8,"y":0.1},{"x":0.5,"y":0.8}],"inverted":true})).unwrap());
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();let target=temporary.0.join("terrain-masks.zip");create(&root,&target,&saved.id,saved.revision).unwrap();let restored=restore(&target,&temporary.0).unwrap();assert_eq!(serde_json::to_value(&restored.project.maps).unwrap(),expected);
    }
    #[test]
    fn texture_placement_and_symbol_recipes_survive_backup_restore(){
        let (temporary,root,mut project)=fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=26;let drawing=maps.maps[0].drawing.as_mut().unwrap();
        drawing.strokes[0].material=Some("grass".into());drawing.strokes[0].texture_scale=Some(1.5);drawing.strokes[0].texture_rotation=Some(45.0);
        drawing.objects.push(serde_json::from_value(serde_json::json!({"id":"10000000-0000-0000-0000-000000000002","kind":"forest","x":0.2,"y":0.3,"size":0.06,"rotation":35.0,"stamp":{"continuous":true,"density":0.8,"sizeVariation":0.3,"rotationVariation":60.0,"baseSize":0.06,"baseRotation":30.0}})).unwrap());
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();let target=temporary.0.join("texture-symbol-settings.zip");create(&root,&target,&saved.id,saved.revision).unwrap();
        let restored=restore(&target,&temporary.0).unwrap();assert_eq!(serde_json::to_value(&restored.project.maps).unwrap(),expected);
    }
    #[test]
    fn terrain_opacity_survives_complete_backup_restore(){
        let (temporary,root,mut project)=fixture();let maps=project.maps.as_mut().unwrap();maps.schema_version=25;
        maps.maps[0].drawing.as_mut().unwrap().strokes[0].opacity=Some(0.35);
        let saved=storage::save(&root,project).unwrap();let expected=serde_json::to_value(&saved.maps).unwrap();
        let target=temporary.0.join("terrain-opacity.zip");create(&root,&target,&saved.id,saved.revision).unwrap();
        let restored=restore(&target,&temporary.0).unwrap();assert_eq!(serde_json::to_value(&restored.project.maps).unwrap(),expected);
    }
    #[test]
    fn map_trash_roundtrips_complete_snapshots_and_assets(){
        let (temporary,root,mut project)=fixture();
        let maps=project.maps.as_mut().unwrap();maps.schema_version=17;
        maps.maps[0].regions.push(serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000987","title":"Región en papelera","color":"amber","points":[{"x":0.1,"y":0.1},{"x":0.8,"y":0.1},{"x":0.4,"y":0.8}]})).unwrap());
        let map=maps.maps.remove(0);let expected=serde_json::to_value(&map).unwrap();
        maps.trash.push(crate::maps::TrashedMap{map,deleted_at:SystemTime::now().duration_since(UNIX_EPOCH).unwrap().as_millis() as u64});
        let saved=storage::save(&root,project).unwrap();let target=temporary.0.join("trashed-maps.zip");create(&root,&target,&saved.id,saved.revision).unwrap();
        let restored=restore(&target,&temporary.0).unwrap();assert!(restored.project.maps.as_ref().unwrap().maps.is_empty());assert_eq!(serde_json::to_value(&restored.project.maps.as_ref().unwrap().trash[0].map).unwrap(),expected);
        assert!(Path::new(&restored.path).join("assets/images/00000000-0000-0000-0000-000000000993/image.png").exists());
    }
    #[test]
    fn map_assets_are_required_in_current_and_historical_backups() {
        let (temporary, root, mut project) = fixture();
        fs::remove_file(root.join("assets/images/00000000-0000-0000-0000-000000000993/image.png"))
            .unwrap();
        let archive = temporary.0.join("missing-map.zip");
        assert!(create(&root, &archive, &project.id, project.revision).is_err());
        assert!(!archive.exists());
        project.maps = None;
        let saved = storage::save(&root, project).unwrap();
        assert!(create(&root, &archive, &saved.id, saved.revision).is_err());
        assert!(!archive.exists());
    }
    fn archive_bytes(path: &Path) -> Vec<(String, Vec<u8>)> {
        let mut zip = ZipArchive::new(File::open(path).unwrap()).unwrap();
        (0..zip.len())
            .map(|index| {
                let mut file = zip.by_index(index).unwrap();
                let name = file.name().to_string();
                let mut bytes = Vec::new();
                file.read_to_end(&mut bytes).unwrap();
                (name, bytes)
            })
            .collect()
    }
    fn write_archive(path: &Path, files: &[(String, Vec<u8>)]) {
        let mut zip = ZipWriter::new(File::create(path).unwrap());
        for (name, data) in files {
            zip.start_file(
                name,
                SimpleFileOptions::default().compression_method(zip::CompressionMethod::Stored),
            )
            .unwrap();
            zip.write_all(data).unwrap();
        }
        zip.finish().unwrap();
    }
    #[test]
    fn complete_backups_restore_into_new_folders_with_images_history_and_timeline() {
        let (temporary, root, project) = fixture();
        history::name_checkpoint(&root, &project.id, project.revision, "Before rewriting chapter 3").unwrap();
        let target = temporary.0.join("story.zip");
        let original = fs::read(root.join("project.json")).unwrap();
        assert!(project.worldbuilding.as_ref().unwrap().visual_resources.iter().any(|item|item.title=="Standalone sheet"));
        let trashed=project.worldbuilding.as_ref().unwrap().visual_resources.iter().find(|item|item.title=="Standalone sheet").unwrap();assert_eq!(trashed.original_filename.as_deref(),Some("travel-clothes.webp"));assert!(trashed.deleted_at.is_some());
        create(&root, &target, &project.id, project.revision).unwrap();
        assert!(archive_bytes(&target).iter().any(|(name,_)|name=="assets/images/00000000-0000-0000-0000-000000000905/image.png"));
        let independent=std::process::Command::new("python3").args(["-c", "import sys,zipfile,json; z=zipfile.ZipFile(sys.argv[1]); assert z.testzip() is None; m=json.loads(z.read('.write-studio-backup.json')); assert {f['path']:f['size'] for f in m['files']} == {i.filename:i.file_size for i in z.infolist() if i.filename != '.write-studio-backup.json'}; assert json.loads(z.read('project.json'))['id'] == m['projectId']"]).arg(&target).output().unwrap();
        assert!(
            independent.status.success(),
            "{}",
            String::from_utf8_lossy(&independent.stderr)
        );
        let files = archive_bytes(&target);
        for expected in [
            "project.json",
            MANIFEST,
            ".write-studio-history/r-1.json",
            ".write-studio-history/r-2.json",
            ".write-studio-history/checkpoints.json",
        ] {
            assert!(files.iter().any(|(name, _)| name == expected));
        }
        assert!(
            files
                .iter()
                .any(|(name, _)| name == &format!("assets/images/{IMAGE}/image.png"))
        );
        assert!(
            files
                .iter()
                .any(|(name, _)| name.starts_with(".write-studio-backups/"))
        );
        let restored = restore(&target, &temporary.0).unwrap();
        assert_ne!(Path::new(&restored.path), root);
        assert_eq!(
            serde_json::to_value(&project).unwrap(),
            serde_json::to_value(&restored.project).unwrap()
        );
        assert_eq!(
            entry_images::read(Path::new(&restored.path), &project.id, IMAGE, true).unwrap(),
            png()
        );
        assert_eq!(history::list(Path::new(&restored.path)).unwrap().len(), 2);
        assert_eq!(history::list(Path::new(&restored.path)).unwrap()[0].checkpoint_name.as_deref(),Some("Before rewriting chapter 3"));
        assert_eq!(
            history::list(&root)
                .unwrap()
                .iter()
                .map(|version| version.saved_at)
                .collect::<Vec<_>>(),
            history::list(Path::new(&restored.path))
                .unwrap()
                .iter()
                .map(|version| version.saved_at)
                .collect::<Vec<_>>()
        );
        let second = restore(&target, &temporary.0).unwrap();
        assert_ne!(restored.path, second.path);
        assert_eq!(fs::read(root.join("project.json")).unwrap(), original);
        let previous = history::restore(Path::new(&restored.path), 1, project.revision).unwrap();
        assert!(
            previous.worldbuilding.unwrap().entries[0]
                .image_id
                .is_none()
        );
        assert!(create(&root, &target, &project.id, project.revision).is_err());
        assert_eq!(archive_bytes(&target).len(), files.len());
        assert!(
            create(
                &root,
                &root.join("recursive.zip"),
                &project.id,
                project.revision
            )
            .is_err()
        );
        assert!(
            create(
                &root,
                &temporary.0.join("conflict.zip"),
                &project.id,
                project.revision + 1
            )
            .is_err()
        );
    }
    #[test]
    fn damaged_incomplete_and_unsafe_archives_never_publish_a_project() {
        let (temporary, root, project) = fixture();
        let target = temporary.0.join("valid.zip");
        create(&root, &target, &project.id, project.revision).unwrap();
        let files = archive_bytes(&target);
        let parent = temporary.0.join("restored");
        fs::create_dir(&parent).unwrap();
        let bad = temporary.0.join("bad.zip");
        for name in [
            "../escape.txt",
            "assets/../escape.txt",
            "/escape.txt",
            "assets\\escape.txt",
            "assets/C:escape.txt",
            "assets/NUL.txt",
            "assets/COM¹/data.json",
            "assets/invalid?.json",
            "assets/trailing./data.json",
        ] {
            let mut modified = files.clone();
            modified.push((name.into(), b"unsafe".to_vec()));
            write_archive(&bad, &modified);
            assert!(restore(&bad, &parent).is_err());
            assert_eq!(fs::read_dir(&parent).unwrap().count(), 0);
        }
        let mut duplicate = files.clone();
        duplicate.push(("assets/DUPLICATE".into(), vec![]));
        duplicate.push(("assets/duplicate".into(), vec![]));
        write_archive(&bad, &duplicate);
        assert!(restore(&bad, &parent).is_err());
        let missing: Vec<_> = files
            .iter()
            .filter(|(name, _)| name != &format!("assets/images/{IMAGE}/thumbnail.png"))
            .cloned()
            .collect();
        write_archive(&bad, &missing);
        assert!(restore(&bad, &parent).is_err());
        let mut wrong = files.clone();
        let manifest = wrong.iter_mut().find(|(name, _)| name == MANIFEST).unwrap();
        let mut metadata: serde_json::Value = serde_json::from_slice(&manifest.1).unwrap();
        metadata["projectId"] = "foreign".into();
        manifest.1 = serde_json::to_vec(&metadata).unwrap();
        write_archive(&bad, &wrong);
        assert!(restore(&bad, &parent).is_err());
        write_archive(&bad, &files);
        let mut zip = ZipArchive::new(File::open(&bad).unwrap()).unwrap();
        let offset = zip.by_name("project.json").unwrap().data_start() as usize;
        drop(zip);
        let mut bytes = fs::read(&bad).unwrap();
        bytes[offset] ^= 1;
        fs::write(&bad, &bytes).unwrap();
        assert!(restore(&bad, &parent).is_err());
        fs::write(&bad, &bytes[..bytes.len() - 20]).unwrap();
        assert!(restore(&bad, &parent).is_err());
        assert_eq!(fs::read_dir(&parent).unwrap().count(), 0);
        assert!(!temporary.0.join("escape.txt").exists());
        fs::remove_file(root.join(format!("assets/images/{IMAGE}/thumbnail.png"))).unwrap();
        assert!(
            create(
                &root,
                &temporary.0.join("missing-image.zip"),
                &project.id,
                project.revision
            )
            .is_err()
        );
        assert!(!temporary.0.join("missing-image.zip").exists());
    }
    #[cfg(unix)]
    #[test]
    fn symbolic_links_are_not_followed_or_restored() {
        let (temporary, root, project) = fixture();
        let target = temporary.0.join("story.zip");
        let secret = temporary.0.join("external.txt");
        fs::write(&secret, "external").unwrap();
        std::os::unix::fs::symlink(&secret, root.join("manuscript/external")).unwrap();
        assert!(create(&root, &target, &project.id, project.revision).is_err());
        assert!(!target.exists());
        let mut zip = ZipWriter::new(File::create(&target).unwrap());
        zip.add_symlink("assets/link", "/tmp", SimpleFileOptions::default())
            .unwrap();
        zip.finish().unwrap();
        let parent = temporary.0.join("restore");
        fs::create_dir(&parent).unwrap();
        assert!(restore(&target, &parent).is_err());
        assert_eq!(fs::read_dir(parent).unwrap().count(), 0);
    }
}

#[cfg(test)]
#[path = "backup_image_batch_tests.rs"]
mod image_batch_tests;

#[cfg(test)]
#[path = "backup_portability_tests.rs"]
mod portability_tests;
