use std::{
    fs::{self, OpenOptions},
    io::Write,
    path::Path,
};
pub fn document_bytes(
    format: &str,
    bytes: Option<Vec<u8>>,
    text: Option<String>,
) -> Result<Vec<u8>, String> {
    match (bytes, text) {
        (Some(bytes), None) => Ok(bytes),
        (None, Some(text)) if matches!(format, "html" | "md") => Ok(text.into_bytes()),
        _ => Err("Invalid export content.".into()),
    }
}
pub fn write_new(path: &Path, bytes: &[u8]) -> Result<(), String> {
    let mut file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .map_err(|e| {
            if e.kind() == std::io::ErrorKind::AlreadyExists {
                "A file already exists here. Choose a new filename to keep existing files safe."
                    .to_string()
            } else {
                e.to_string()
            }
        })?;
    if let Err(error) = file.write_all(bytes).and_then(|_| file.sync_all()) {
        drop(file);
        let _ = fs::remove_file(path);
        return Err(error.to_string());
    }
    Ok(())
}
/// Write directly to disk, retaining at most one image in memory. Stored project
/// images are immutable PNGs; IDs never become paths inside the archive.
pub fn write_encyclopedia(
    path: &Path,
    html: &str,
    image_ids: &[String],
    mut read_image: impl FnMut(&str) -> Result<Vec<u8>, String>,
) -> Result<(), String> {
    let mut seen = std::collections::HashSet::new();
    for id in image_ids {
        if !crate::entry_images::valid_id(id) || !seen.insert(id) {
            return Err("Invalid image identifier.".into());
        }
    }
    let file = OpenOptions::new()
        .write(true)
        .create_new(true)
        .open(path)
        .map_err(|error| {
            if error.kind() == std::io::ErrorKind::AlreadyExists {
                "A file already exists here. Choose a new filename to keep existing files safe."
                    .to_string()
            } else {
                error.to_string()
            }
        })?;
    let result = (|| {
        let mut archive = zip::ZipWriter::new(file);
        let options = zip::write::SimpleFileOptions::default();
        archive
            .start_file(
                "index.html",
                options.compression_method(zip::CompressionMethod::Deflated),
            )
            .map_err(|error| error.to_string())?;
        archive
            .write_all(html.as_bytes())
            .map_err(|error| error.to_string())?;
        for (index, id) in image_ids.iter().enumerate() {
            let bytes = read_image(id)?;
            archive
                .start_file(
                    format!("images/image-{}.png", index + 1),
                    options.compression_method(zip::CompressionMethod::Stored),
                )
                .map_err(|error| error.to_string())?;
            archive
                .write_all(&bytes)
                .map_err(|error| error.to_string())?;
        }
        archive
            .finish()
            .and_then(|file| file.sync_all().map_err(zip::result::ZipError::Io))
            .map_err(|error| error.to_string())
    })();
    if result.is_err() {
        let _ = fs::remove_file(path);
    }
    result
}
#[cfg(test)]
mod tests {
    use super::*;
    #[test]
    fn encyclopedia_zip_streams_images_and_keeps_local_links() {
        use std::io::Read;
        let root =
            std::env::temp_dir().join(format!("write-studio-encyclopedia-{}", std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let path = root.join("world.zip");
        let ids: Vec<String> = (1..=36)
            .map(|i| format!("00000000-0000-0000-0000-{i:012}"))
            .collect();
        let html = "<h1>Océano 🌿</h1><img src=\"images/image-1.png\">";
        let mut reads = 0;
        write_encyclopedia(&path, html, &ids, |id| {
            assert_eq!(id, ids[reads]);
            reads += 1;
            Ok(vec![reads as u8; 1024 * 1024])
        })
        .unwrap();
        assert_eq!(reads, 36);
        assert!(fs::metadata(&path).unwrap().len() > 32 * 1024 * 1024);
        let mut archive = zip::ZipArchive::new(std::fs::File::open(&path).unwrap()).unwrap();
        assert_eq!(archive.len(), 37);
        let mut text = String::new();
        archive
            .by_name("index.html")
            .unwrap()
            .read_to_string(&mut text)
            .unwrap();
        assert_eq!(text, html);
        let mut last = Vec::new();
        archive
            .by_name("images/image-36.png")
            .unwrap()
            .read_to_end(&mut last)
            .unwrap();
        assert_eq!(last, vec![36; 1024 * 1024]);
        assert!(write_encyclopedia(&path, "overwrite", &[], |_| unreachable!()).is_err());
        drop(archive);
        let failed = root.join("failed.zip");
        assert!(write_encyclopedia(&failed, html, &ids, |_| Err("missing image".into())).is_err());
        assert!(!failed.exists());
        assert!(
            write_encyclopedia(&failed, html, &["../escape".into()], |_| unreachable!()).is_err()
        );
        assert!(!failed.exists());
        assert!(
            write_encyclopedia(
                &failed,
                html,
                &[ids[0].clone(), ids[0].clone()],
                |_| unreachable!()
            )
            .is_err()
        );
        assert!(!failed.exists());
        write_encyclopedia(&root.join("text.zip"), html, &[], |_| unreachable!()).unwrap();
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn text_exports_preserve_utf8_and_require_one_compatible_payload() {
        assert_eq!(
            document_bytes("html", None, Some("🌿 océano".into())).unwrap(),
            "🌿 océano".as_bytes()
        );
        assert!(document_bytes("docx", None, Some("text".into())).is_err());
        assert!(document_bytes("html", Some(vec![]), Some("text".into())).is_err());
        assert!(document_bytes("md", None, None).is_err());
        assert_eq!(
            document_bytes("png", Some(vec![1, 2]), None).unwrap(),
            vec![1, 2]
        );
    }
    #[test]
    fn exports_create_files_without_overwriting_existing_content() {
        let root = std::env::temp_dir().join(format!("write-studio-export-{}", std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let path = root.join("novel.md");
        write_new(&path, "# Novel 🌿\n".as_bytes()).unwrap();
        assert!(write_new(&path, b"replacement").is_err());
        assert_eq!(fs::read_to_string(path).unwrap(), "# Novel 🌿\n");
        fs::remove_dir_all(root).unwrap();
    }
}
