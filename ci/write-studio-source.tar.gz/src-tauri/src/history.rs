use crate::storage::{self, Project};
use serde::{Deserialize, Serialize};
use std::collections::BTreeMap;
use std::{
    fs,
    path::Path,
    time::{SystemTime, UNIX_EPOCH},
};
#[derive(Serialize)]
#[serde(rename_all = "camelCase")]
pub struct Version {
    pub revision: u64,
    pub saved_at: u64,
    pub title: String,
    pub checkpoint_name: Option<String>,
}
#[derive(Serialize, Deserialize)]
#[serde(rename_all = "camelCase", deny_unknown_fields)]
struct Checkpoints {
    project_id: String,
    names: BTreeMap<u64, String>,
}
fn checkpoints(root: &Path, current: &Project) -> Result<Checkpoints, String> {
    let path = root.join(".write-studio-history/checkpoints.json");
    let data = match fs::read(path) {
        Ok(bytes) => serde_json::from_slice::<Checkpoints>(&bytes).map_err(|e| e.to_string())?,
        Err(e) if e.kind() == std::io::ErrorKind::NotFound => Checkpoints {
            project_id: current.id.clone(),
            names: BTreeMap::new(),
        },
        Err(e) => return Err(e.to_string()),
    };
    if data.project_id != current.id {
        return Err("Checkpoints belong to another project.".into());
    }
    for (revision, name) in &data.names {
        if *revision > current.revision
            || name.trim().is_empty()
            || name.chars().count() > 160
            || read(root, *revision)?.id != current.id
        {
            return Err("Invalid revision checkpoint.".into());
        }
    }
    Ok(data)
}
pub fn validate_checkpoints(root: &Path, current: &Project) -> Result<(), String> {
    checkpoints(root, current).map(|_| ())
}
pub fn name_checkpoint(
    root: &Path,
    project_id: &str,
    revision: u64,
    name: &str,
) -> Result<(), String> {
    let name = name.trim();
    if name.is_empty() || name.chars().count() > 160 {
        return Err("Checkpoint names must contain between 1 and 160 characters.".into());
    }
    let current = storage::open(root)?;
    if current.id != project_id || current.revision != revision {
        return Err("Project changed on disk. Save it again before creating a checkpoint.".into());
    }
    capture(root, &current)?;
    let mut data = checkpoints(root, &current)?;
    data.names.insert(revision, name.into());
    storage::atomic(
        &root.join(".write-studio-history/checkpoints.json"),
        &serde_json::to_vec_pretty(&data).map_err(|e| e.to_string())?,
    )
}
// Full immutable project snapshots include manuscript text and all worldbuilding values.
pub fn capture(root: &Path, project: &Project) -> Result<(), String> {
    storage::validate(project, true)?;
    let directory = root.join(".write-studio-history");
    fs::create_dir_all(&directory).map_err(|e| e.to_string())?;
    let path = directory.join(format!("r-{}.json", project.revision));
    if path.exists()
        && fs::read(&path).map_err(|e| e.to_string())?
            == serde_json::to_vec_pretty(project).map_err(|e| e.to_string())?
    {
        return Ok(());
    }
    storage::atomic(
        &path,
        &serde_json::to_vec_pretty(project).map_err(|e| e.to_string())?,
    )
}
// Automatic saves still commit the project every time, but only periodically snapshot it.
pub fn capture_automatic(root: &Path, project: &Project) -> Result<(), String> {
    let directory = root.join(".write-studio-history");
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_secs();
    if directory.exists() {
        let mut latest = None;
        for item in fs::read_dir(directory).map_err(|e| e.to_string())? {
            let item = item.map_err(|e| e.to_string())?;
            let name = item.file_name().to_string_lossy().into_owned();
            let Some(revision) = name
                .strip_prefix("r-")
                .and_then(|s| s.strip_suffix(".json"))
                .and_then(|s| s.parse::<u64>().ok())
            else {
                continue;
            };
            if revision >= project.revision || name != format!("r-{revision}.json") {
                continue;
            }
            if latest
                .as_ref()
                .is_none_or(|(previous, _)| revision > *previous)
            {
                latest = Some((revision, item.path()));
            }
        }
        if let Some((revision, path)) = latest {
            let metadata = fs::symlink_metadata(path).map_err(|e| e.to_string())?;
            if !metadata.is_file() || metadata.file_type().is_symlink() {
                return Err("History contains an unsupported file.".into());
            }
            let timestamp = metadata
                .modified()
                .map_err(|e| e.to_string())?
                .duration_since(UNIX_EPOCH)
                .map_err(|e| e.to_string())?
                .as_secs();
            // A clock rollback takes an extra snapshot rather than disabling history indefinitely.
            if timestamp <= now && now - timestamp < 10 * 60 {
                if read(root, revision)?.id != project.id {
                    return Err("History belongs to another project.".into());
                }
                return Ok(());
            }
        }
    }
    capture(root, project)
}
pub fn read(root: &Path, revision: u64) -> Result<Project, String> {
    let bytes = fs::read(
        root.join(".write-studio-history")
            .join(format!("r-{revision}.json")),
    )
    .map_err(|e| e.to_string())?;
    let project: Project = serde_json::from_slice(&bytes).map_err(|e| e.to_string())?;
    storage::validate(&project, true)?;
    if project.revision != revision {
        return Err("Version revision does not match its file.".into());
    }
    Ok(project)
}
pub fn list(root: &Path) -> Result<Vec<Version>, String> {
    let current = storage::open(root)?;
    capture(root, &current)?;
    let labels = checkpoints(root, &current)?;
    let mut versions = Vec::new();
    for item in fs::read_dir(root.join(".write-studio-history")).map_err(|e| e.to_string())? {
        let item = item.map_err(|e| e.to_string())?;
        let name = item.file_name().to_string_lossy().into_owned();
        let Some(revision) = name
            .strip_prefix("r-")
            .and_then(|s| s.strip_suffix(".json"))
            .and_then(|s| s.parse::<u64>().ok())
        else {
            continue;
        };
        if revision > current.revision {
            continue;
        }
        let project = read(root, revision)?;
        if project.id != current.id {
            return Err("History belongs to another project.".into());
        }
        let saved_at = item
            .metadata()
            .and_then(|m| m.modified())
            .ok()
            .and_then(|t| t.duration_since(UNIX_EPOCH).ok())
            .map(|t| t.as_secs())
            .unwrap_or_else(|| {
                SystemTime::now()
                    .duration_since(UNIX_EPOCH)
                    .unwrap_or_default()
                    .as_secs()
            });
        versions.push(Version {
            revision,
            saved_at,
            title: project.title,
            checkpoint_name: labels.names.get(&revision).cloned(),
        });
    }
    versions.sort_by_key(|version| std::cmp::Reverse(version.revision));
    Ok(versions)
}
// Saving the authoritative project stays independent from best-effort history retention.
// Named checkpoints and the two newest snapshots are never removed.
pub fn compact(root: &Path) -> Result<(), String> {
    let now = SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map_err(|e| e.to_string())?
        .as_secs();
    compact_at(root, now)
}
fn compact_at(root: &Path, now: u64) -> Result<(), String> {
    const INTERVAL: u64 = 10 * 60;
    const RETENTION: u64 = 30 * 24 * 60 * 60;
    let current = storage::open(root)?;
    // Never clean an incomplete transaction or a project without a verified current snapshot.
    if root.join(".write-studio-transaction.json").exists() {
        return Ok(());
    }
    if !root
        .join(format!(".write-studio-history/r-{}.json", current.revision))
        .is_file()
    {
        return Ok(());
    }
    let labels = checkpoints(root, &current)?;
    let directory = root.join(".write-studio-history");
    if !directory.exists() {
        return Ok(());
    }
    let mut snapshots = Vec::new();
    for item in fs::read_dir(&directory).map_err(|e| e.to_string())? {
        let item = item.map_err(|e| e.to_string())?;
        let name = item.file_name().to_string_lossy().into_owned();
        let Some(revision) = name
            .strip_prefix("r-")
            .and_then(|s| s.strip_suffix(".json"))
            .and_then(|s| s.parse::<u64>().ok())
        else {
            continue;
        };
        if name != format!("r-{revision}.json") || revision > current.revision {
            continue;
        }
        let metadata = fs::symlink_metadata(item.path()).map_err(|e| e.to_string())?;
        if !metadata.is_file() || metadata.file_type().is_symlink() {
            return Err("History contains an unsupported file.".into());
        }
        let project = read(root, revision)?;
        if project.id != current.id {
            return Err("History belongs to another project.".into());
        }
        let timestamp = metadata
            .modified()
            .map_err(|e| e.to_string())?
            .duration_since(UNIX_EPOCH)
            .map_err(|e| e.to_string())?
            .as_secs();
        snapshots.push((revision, timestamp, item.path()));
    }
    snapshots.sort_by_key(|item| std::cmp::Reverse(item.0));
    if !snapshots.iter().any(|item| item.0 == current.revision) {
        return Ok(());
    }
    let mut buckets = std::collections::HashSet::new();
    let mut remove = Vec::new();
    for (index, (revision, timestamp, path)) in snapshots.iter().enumerate() {
        // Clock rollback must not cause deletion of snapshots that appear to be in the future.
        if labels.names.contains_key(revision) || *timestamp > now {
            continue;
        }
        let recent = now.saturating_sub(*timestamp) <= RETENTION;
        let representative = recent && buckets.insert(timestamp / INTERVAL);
        if index < 2 || *revision == current.revision || representative {
            continue;
        }
        remove.push(path);
    }
    // Validate every candidate before removing anything; corrupt/foreign history is left alone.
    for path in remove {
        fs::remove_file(path).map_err(|e| e.to_string())?;
    }
    Ok(())
}
pub fn restore(root: &Path, revision: u64, expected_revision: u64) -> Result<Project, String> {
    let current = storage::open(root)?;
    if current.revision != expected_revision {
        return Err("Project changed on disk. Reopen it before restoring.".into());
    }
    let mut previous = read(root, revision)?;
    if previous.id != current.id || revision > current.revision {
        return Err("Invalid project version.".into());
    }
    capture(root, &current)?;
    // Restore old contents using the current supported world format, never downgrade schemas.
    if let Some(current_world) = &current.worldbuilding {
        let previous_world =
            previous
                .worldbuilding
                .get_or_insert_with(|| crate::worldbuilding::Worldbuilding {
                    visual_resources:Vec::new(),
                    schema_version: current_world.schema_version,
                    templates: Vec::new(),
                    entries: Vec::new(),
                });
        if previous_world.schema_version < current_world.schema_version {
            previous_world.schema_version = current_world.schema_version;
            for template in &mut previous_world.templates {
                template.schema_version = current_world.schema_version;
            }
            for entry in &mut previous_world.entries {
                entry.schema_version = current_world.schema_version;
            }
        }
    }
    previous.revision = current.revision;
    storage::save(root, previous)
}

#[cfg(test)]
mod tests {
    use super::*;
    fn timestamp(root: &Path, revision: u64, seconds: u64) {
        fs::File::options()
            .write(true)
            .open(root.join(format!(".write-studio-history/r-{revision}.json")))
            .unwrap()
            .set_times(
                fs::FileTimes::new()
                    .set_modified(UNIX_EPOCH + std::time::Duration::from_secs(seconds)),
            )
            .unwrap();
    }
    #[test]
    fn autosaves_commit_every_edit_but_space_history_and_preserve_named_points() {
        let root =
            std::env::temp_dir().join(format!("write-studio-auto-history-{}", std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let original: Project = serde_json::from_str(include_str!(
            "../../tests/fixtures/worldbuilding-project.json"
        ))
        .unwrap();
        let mut current = storage::save(&root, original).unwrap();
        let first = current.revision;
        for i in 0..5 {
            current.chapters[0].scenes[0].content = Some(format!("Latest edit {i}"));
            current = storage::save_automatic(&root, current).unwrap();
            assert_eq!(
                storage::open(&root).unwrap().chapters[0].scenes[0].content,
                current.chapters[0].scenes[0].content
            );
        }
        assert_eq!(
            fs::read_dir(root.join(".write-studio-history"))
                .unwrap()
                .count(),
            1
        );
        assert!(read(&root, current.revision).is_err());
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();
        timestamp(&root, first, now - 601);
        current = storage::save_automatic(&root, current).unwrap();
        assert!(read(&root, current.revision).is_ok());
        name_checkpoint(&root, &current.id, current.revision, "Keep forever").unwrap();
        let named = current.revision;
        current = storage::save_automatic(&root, current).unwrap();
        // Opening history captures the current state even between scheduled snapshots.
        assert_eq!(list(&root).unwrap()[0].revision, current.revision);
        compact_at(&root, now + 90 * 24 * 60 * 60).unwrap();
        assert!(read(&root, named).is_ok());
        assert!(read(&root, current.revision).is_ok());
        assert!(read(&root, first).is_err());
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn retention_groups_legacy_versions_and_expires_only_unnamed_history() {
        let root = std::env::temp_dir().join(format!(
            "write-studio-history-retention-{}",
            std::process::id()
        ));
        fs::create_dir_all(&root).unwrap();
        let mut current: Project = serde_json::from_str(include_str!(
            "../../tests/fixtures/worldbuilding-project.json"
        ))
        .unwrap();
        for i in 1..=9 {
            current.title = format!("Revision {i}");
            current = storage::save(&root, current).unwrap();
            if i == 1 || i == 6 {
                name_checkpoint(&root, &current.id, current.revision, "Protected").unwrap();
            }
        }
        let now = 600 * 100000;
        let times = [
            now - 60 * 86400,
            now - 40 * 86400,
            now - 1210,
            now - 1205,
            now - 1201,
            now - 5,
            now - 4,
            now - 3,
            now - 2,
        ];
        for (i, time) in times.into_iter().enumerate() {
            timestamp(&root, i as u64 + 1, time);
        }
        let bytes = fs::read(root.join("project.json")).unwrap();
        compact_at(&root, now).unwrap();
        // 3/4/5 share a time block; keep its newest. 8/9 are always retained.
        for revision in [1, 5, 6, 8, 9] {
            assert!(read(&root, revision).is_ok(), "keep {revision}");
        }
        for revision in [2, 3, 4, 7] {
            assert!(read(&root, revision).is_err(), "remove {revision}");
        }
        assert_eq!(fs::read(root.join("project.json")).unwrap(), bytes);
        compact_at(&root, now + 60 * 86400).unwrap();
        assert!(read(&root, 5).is_err());
        for revision in [1, 6, 8, 9] {
            assert!(read(&root, revision).is_ok());
        }
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn retention_leaves_foreign_corrupt_and_future_history_untouched() {
        let root = std::env::temp_dir().join(format!(
            "write-studio-retention-invalid-{}",
            std::process::id()
        ));
        fs::create_dir_all(&root).unwrap();
        let original: Project = serde_json::from_str(include_str!(
            "../../tests/fixtures/worldbuilding-project.json"
        ))
        .unwrap();
        let mut current = storage::save(&root, original).unwrap();
        for _ in 0..3 {
            current = storage::save(&root, current).unwrap();
        }
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .unwrap()
            .as_secs();
        timestamp(&root, 1, now + 86400);
        compact_at(&root, now).unwrap();
        assert!(read(&root, 1).is_ok());
        let mut foreign = current.clone();
        foreign.id = "00000000-0000-0000-0000-000000000999".into();
        foreign.revision = 2;
        capture(&root, &foreign).unwrap();
        assert!(compact_at(&root, now).is_err());
        assert!(read(&root, 1).is_ok());
        fs::write(root.join(".write-studio-history/r-2.json"), b"broken").unwrap();
        assert!(compact_at(&root, now).is_err());
        assert!(read(&root, 1).is_ok());
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn named_checkpoints_survive_saves_and_restore_without_changing_snapshots() {
        let root =
            std::env::temp_dir().join(format!("write-studio-checkpoints-{}", std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let original: Project = serde_json::from_str(include_str!(
            "../../tests/fixtures/worldbuilding-project.json"
        ))
        .unwrap();
        let first = storage::save(&root, original).unwrap();
        let bytes = fs::read(root.join(format!(".write-studio-history/r-{}.json", first.revision)))
            .unwrap();
        name_checkpoint(
            &root,
            &first.id,
            first.revision,
            "  Antes de reescribir 世界  ",
        )
        .unwrap();
        assert_eq!(
            list(&root).unwrap()[0].checkpoint_name.as_deref(),
            Some("Antes de reescribir 世界")
        );
        assert_eq!(
            fs::read(root.join(format!(".write-studio-history/r-{}.json", first.revision)))
                .unwrap(),
            bytes
        );
        for name in [" ".to_string(), "a".repeat(161)] {
            assert!(name_checkpoint(&root, &first.id, first.revision, &name).is_err());
        }
        assert!(name_checkpoint(&root, "foreign", first.revision, "No").is_err());
        let mut edited = first.clone();
        edited.chapters[0].scenes[0].content = Some("Rewritten".into());
        let second = storage::save(&root, edited).unwrap();
        assert!(name_checkpoint(&root, &first.id, first.revision, "Stale").is_err());
        name_checkpoint(&root, &second.id, second.revision, "After rewriting").unwrap();
        let restored = restore(&root, first.revision, second.revision).unwrap();
        assert_eq!(
            restored.chapters[0].scenes[0].content,
            first.chapters[0].scenes[0].content
        );
        let versions = list(&root).unwrap();
        assert!(versions[0].checkpoint_name.is_none());
        assert_eq!(
            versions[1].checkpoint_name.as_deref(),
            Some("After rewriting")
        );
        assert_eq!(
            versions[2].checkpoint_name.as_deref(),
            Some("Antes de reescribir 世界")
        );
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn history_write_failure_keeps_saved_project_unchanged() {
        let root = std::env::temp_dir().join(format!(
            "write-studio-history-failure-{}",
            std::process::id()
        ));
        fs::create_dir_all(&root).unwrap();
        let project: Project = serde_json::from_str(include_str!(
            "../../tests/fixtures/worldbuilding-project.json"
        ))
        .unwrap();
        let saved = storage::save(&root, project).unwrap();
        let mut changed = saved.clone();
        changed.title = "Unsaved".into();
        fs::create_dir(
            root.join(".write-studio-history")
                .join(format!("r-{}.json", saved.revision + 1)),
        )
        .unwrap();
        assert!(storage::save(&root, changed).is_err());
        assert_eq!(storage::open(&root).unwrap().title, saved.title);
        assert!(!root.join(".write-studio-transaction.json").exists());
        fs::remove_dir_all(root).unwrap();
    }
    #[test]
    fn versions_preserve_contents_restore_as_new_revision_and_reject_conflicts() {
        let root =
            std::env::temp_dir().join(format!("write-studio-history-test-{}", std::process::id()));
        fs::create_dir_all(&root).unwrap();
        let original: Project = serde_json::from_str(include_str!(
            "../../tests/fixtures/worldbuilding-project.json"
        ))
        .unwrap();
        let first = storage::save(&root, original).unwrap();
        let mut changed = first.clone();
        changed.title = "Second version".into();
        changed.chapters[0].scenes[0].content = Some("New text".into());
        let world = changed.worldbuilding.as_mut().unwrap();
        world.schema_version = 3;
        for template in &mut world.templates {
            template.schema_version = 3;
        }
        for entry in &mut world.entries {
            entry.schema_version = 3;
        }
        let second = storage::save(&root, changed).unwrap();
        assert_eq!(list(&root).unwrap().len(), 2);
        assert_eq!(
            read(&root, first.revision).unwrap().chapters[0].scenes[0].content,
            first.chapters[0].scenes[0].content
        );
        assert!(restore(&root, first.revision, first.revision).is_err());
        let restored = restore(&root, first.revision, second.revision).unwrap();
        assert_eq!(restored.revision, second.revision + 1);
        assert_eq!(restored.title, first.title);
        assert_eq!(
            restored.chapters[0].scenes[0].content,
            first.chapters[0].scenes[0].content
        );
        assert_eq!(restored.worldbuilding.as_ref().unwrap().schema_version, 3);
        assert_eq!(
            read(&root, second.revision).unwrap().title,
            "Second version"
        );
        assert_eq!(storage::open(&root).unwrap().revision, restored.revision);
        // Staged snapshots without a committed revision are not presented as saved history.
        let mut future = restored.clone();
        future.revision += 10;
        capture(&root, &future).unwrap();
        assert_eq!(list(&root).unwrap().len(), 3);
        let mut foreign = first.clone();
        foreign.id = "00000000-0000-0000-0000-000000000999".into();
        capture(&root, &foreign).unwrap();
        assert!(restore(&root, first.revision, restored.revision).is_err());
        fs::remove_dir_all(root).unwrap();
    }
}
