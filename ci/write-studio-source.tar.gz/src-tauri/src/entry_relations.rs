use serde::{Serialize,Deserialize};
use std::collections::{HashSet,HashMap};
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(tag="kind",rename_all="camelCase",deny_unknown_fields)]
pub enum GenealogyMeaning {
 #[serde(rename_all="camelCase")] Parent {parent_role:ParentRole,lineage:Lineage},
 #[serde(rename_all="camelCase")] Guardian {parent_role:ParentRole},
 #[serde(rename_all="camelCase")] StepParent {parent_role:ParentRole},
 FormerPartner,
 Partner,
 Sibling
}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase")]
pub enum ParentRole {Source,Target}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase")]
pub enum Lineage {Biological,Adoptive,Unknown}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct EntryRelationType {#[serde(default,skip_serializing_if="Option::is_none")]pub genealogy:Option<GenealogyMeaning>,#[serde(default,skip_serializing_if="Option::is_none")]pub name:Option<String>,#[serde(default,skip_serializing_if="Option::is_none")]pub disabled_template_ids:Option<Vec<String>>,#[serde(default,skip_serializing_if="Option::is_none")]pub needs_role_review:Option<bool>,pub id:String,pub title:String,pub inverse_title:String,pub symmetric:bool,pub source_template_ids:Vec<String>,pub target_template_ids:Vec<String>}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase")]
pub enum PartnershipStatus {Dating,Married,Separated,Divorced}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct EntryRelation {#[serde(default,skip_serializing_if="Option::is_none")]pub partnership_status:Option<PartnershipStatus>,#[serde(default,skip_serializing_if="Option::is_none")]pub start:Option<crate::timeline::StoryDate>,#[serde(default,skip_serializing_if="Option::is_none")]pub end:Option<crate::timeline::StoryDate>,pub id:String,pub type_id:String,pub source_id:String,pub target_id:String}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct EntryRelations {#[serde(default,skip_serializing_if="Option::is_none")]pub lineages:Option<Vec<FamilyLineage>>,#[serde(default,skip_serializing_if="Option::is_none")]pub views:Option<Vec<RelationGraphView>>,pub schema_version:u32,pub types:Vec<EntryRelationType>,pub links:Vec<EntryRelation>}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct FamilyLineage {pub id:String,pub name:String,pub member_ids:Vec<String>}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct GraphPoint {pub x:f64,pub y:f64}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct GraphCamera {pub x:f64,pub y:f64,pub zoom:f64}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct GraphSettings {#[serde(default,skip_serializing_if="Option::is_none")]pub at:Option<crate::timeline::StoryDate>,#[serde(default,skip_serializing_if="Option::is_none")]pub show_ended:Option<bool>,pub focus_id:String,pub depth:u8,pub template_id:String,pub type_id:String,pub plot_id:String,pub show_archived:bool,pub show_labels:bool}
#[derive(Clone,Debug,Serialize,Deserialize)]
#[serde(rename_all="camelCase",deny_unknown_fields)]
pub struct RelationGraphView {pub id:String,pub name:String,pub settings:GraphSettings,pub positions:std::collections::BTreeMap<String,GraphPoint>,pub camera:GraphCamera}
pub fn validate(relations:&EntryRelations,check:&mut impl FnMut(&str)->Result<(),String>)->Result<(),String>{
 if ![1,2,3,4,5,6,7,8,9].contains(&relations.schema_version){return Err("Unsupported entry relationships schemaVersion.".into());}
 if let Some(lineages)=&relations.lineages {
  if relations.schema_version<8||lineages.len()>1000{return Err("Invalid lineages version or limit.".into());}
  let mut names=HashSet::new();
  for lineage in lineages {
   check(&lineage.id)?;
   if lineage.name.trim().is_empty()||lineage.name.chars().count()>80||!names.insert(lineage.name.trim().to_lowercase())||lineage.member_ids.len()>10000{return Err("Invalid lineage name or members.".into());}
   let mut members=HashSet::new();for id in &lineage.member_ids {if !crate::entry_images::valid_id(id)||!members.insert(id){return Err("Invalid lineage member.".into());}}
  }
 }
 if let Some(views)=&relations.views {
  if relations.schema_version<3||views.len()>1000{return Err("Invalid relationship views version or limit.".into());}
  let mut names=HashSet::new();
  for view in views {
   check(&view.id)?;
   if view.settings.at.is_some()||view.settings.show_ended.is_some(){if relations.schema_version<7{return Err("Dated relationship views require schemaVersion 7.".into());}let at=view.settings.at.as_ref().ok_or("A dated relationship view requires a date.")?;crate::timeline::date(at)?;}

   if view.name.trim().is_empty()||view.name.chars().count()>80||!names.insert(view.name.trim().to_lowercase())||![1,2].contains(&view.settings.depth){return Err("Invalid relationship view name or depth.".into());}
   for id in [&view.settings.focus_id,&view.settings.template_id,&view.settings.type_id,&view.settings.plot_id]{if !id.is_empty()&&!crate::entry_images::valid_id(id){return Err("Invalid relationship view filter.".into());}}
   if view.positions.len()>20000||view.positions.iter().any(|(id,p)|!crate::entry_images::valid_id(id)||!p.x.is_finite()||!p.y.is_finite()||p.x.abs()>100000.0||p.y.abs()>100000.0)||!view.camera.x.is_finite()||!view.camera.y.is_finite()||view.camera.x.abs()>1e9||view.camera.y.abs()>1e9||!view.camera.zoom.is_finite()||!(0.15..=3.0).contains(&view.camera.zoom){return Err("Invalid relationship view positions or camera.".into());}
  }
 }
 let mut names=HashSet::new();let mut types=HashMap::new();for kind in &relations.types {check(&kind.id)?;if [&kind.title,&kind.inverse_title].iter().any(|title|title.trim().is_empty()||title.chars().count()>120)||!names.insert(if relations.schema_version>=2 {kind.name.as_deref().unwrap_or("").trim().to_lowercase()}else{kind.title.trim().to_lowercase()}){return Err("Invalid relationship name.".into());}if relations.schema_version>=2&&kind.name.as_ref().is_none_or(|name|name.trim().is_empty()||name.chars().count()>120){return Err("Invalid relationship type name.".into());}if relations.schema_version==1&&(kind.name.is_some()||kind.disabled_template_ids.is_some()||kind.needs_role_review.is_some()){return Err("Relationship metadata requires schemaVersion 2.".into());}for ids in [&kind.source_template_ids,&kind.target_template_ids].into_iter().chain(kind.disabled_template_ids.as_ref()){let mut unique=HashSet::new();if ids.iter().any(|id|!crate::entry_images::valid_id(id)||!unique.insert(id)){return Err("Invalid relationship templates.".into());}}if relations.schema_version>=2&&!kind.symmetric&&!kind.needs_role_review.unwrap_or(false)&&kind.title.trim().to_lowercase()==kind.inverse_title.trim().to_lowercase(){return Err("Participant roles must be distinct.".into());}if kind.symmetric&&kind.needs_role_review.unwrap_or(false){return Err("Symmetric roles do not require confirmation.".into());}if kind.symmetric&&(kind.title!=kind.inverse_title||kind.source_template_ids!=kind.target_template_ids){return Err("Invalid symmetric relationship.".into());}if let Some(meaning)=&kind.genealogy {
 if relations.schema_version<4||kind.needs_role_review.unwrap_or(false){return Err("Genealogy requires schemaVersion 4 and confirmed roles.".into());}
 if matches!(meaning,GenealogyMeaning::Guardian{..}|GenealogyMeaning::StepParent{..}|GenealogyMeaning::FormerPartner)&&relations.schema_version<6{return Err("Care and former partner meanings require schemaVersion 6.".into());}
 match meaning {GenealogyMeaning::Parent{..}|GenealogyMeaning::Guardian{..}|GenealogyMeaning::StepParent{..} if kind.symmetric=>return Err("Parent relationships require distinct roles.".into()),GenealogyMeaning::Partner|GenealogyMeaning::FormerPartner|GenealogyMeaning::Sibling if !kind.symmetric=>return Err("Partners and siblings require symmetric roles.".into()),_=>{}}
 }types.insert(kind.id.as_str(),kind);}
 let mut pairs=HashSet::new();for link in &relations.links {check(&link.id)?;
 if link.start.is_some()||link.end.is_some(){if relations.schema_version<5{return Err("Connection dates require schemaVersion 5.".into());}if let Some(date)=&link.start{crate::timeline::date(date)?;}if let Some(date)=&link.end{crate::timeline::date(date)?;}if let(Some(start),Some(end))=(&link.start,&link.end){if crate::timeline::bound(end,true)<crate::timeline::bound(start,false){return Err("Connection end precedes its start.".into());}}}
 let kind=types.get(link.type_id.as_str()).ok_or("Unknown relationship type.")?;if link.partnership_status.is_some()&&(relations.schema_version<9||!matches!(kind.genealogy,Some(GenealogyMeaning::Partner)|Some(GenealogyMeaning::FormerPartner))){return Err("Partnership status requires a couple relationship and schemaVersion 9.".into());}if !crate::entry_images::valid_id(&link.source_id)||!crate::entry_images::valid_id(&link.target_id)||link.source_id==link.target_id{return Err("Invalid relationship endpoints.".into());}let(a,b)=if kind.symmetric&&link.source_id>link.target_id{(&link.target_id,&link.source_id)}else{(&link.source_id,&link.target_id)};if !pairs.insert((&link.type_id,a,b)){return Err("Duplicate relationship.".into());}}
 let mut children:HashMap<&str,HashSet<&str>>=HashMap::new();let mut degree:HashMap<&str,usize>=HashMap::new();
 for link in &relations.links {let kind=types[link.type_id.as_str()];if let Some(GenealogyMeaning::Parent{parent_role,..})=&kind.genealogy {
 let(parent,child)=match parent_role {ParentRole::Source=>(link.source_id.as_str(),link.target_id.as_str()),ParentRole::Target=>(link.target_id.as_str(),link.source_id.as_str())};
 if children.entry(parent).or_default().insert(child){degree.entry(parent).or_insert(0);*degree.entry(child).or_insert(0)+=1;}
 }}
 let mut queue:Vec<&str>=degree.iter().filter_map(|(id,count)|(*count==0).then_some(*id)).collect();let mut index=0;
 while index<queue.len(){let id=queue[index];index+=1;if let Some(next)=children.get(id){for child in next {let count=degree.get_mut(child).unwrap();*count-=1;if *count==0{queue.push(child);}}}}
 if queue.len()!=degree.len(){return Err("Ancestry cycle detected.".into());}
 Ok(())
}
#[cfg(test)]
mod tests {
 use super::*;
 use crate::storage;
 fn fixture()->storage::Project{
  let mut project:storage::Project=serde_json::from_str(include_str!("../../tests/fixtures/worldbuilding-project.json")).unwrap();let world=project.worldbuilding.as_ref().unwrap();
  project.entry_relations=Some(EntryRelations{lineages:None,views:None,schema_version:1,types:vec![EntryRelationType{genealogy:None,name:None,disabled_template_ids:None,needs_role_review:None,id:"00000000-0000-0000-0000-000000000950".into(),title:"Friends".into(),inverse_title:"Friends".into(),symmetric:true,source_template_ids:vec![],target_template_ids:vec![]}],links:vec![EntryRelation{partnership_status:None,start:None,end:None,id:"00000000-0000-0000-0000-000000000951".into(),type_id:"00000000-0000-0000-0000-000000000950".into(),source_id:world.entries[0].id.clone(),target_id:world.entries[1].id.clone()}]});project
 }
 #[test]
 fn relationships_survive_save_draft_history_and_journal(){
  let root=std::env::temp_dir().join(format!("write-studio-entry-relations-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();let saved=storage::save(&root,fixture()).unwrap();let expected=serde_json::to_value(&saved.entry_relations).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().entry_relations).unwrap(),expected);
  let draft=root.join("draft");storage::write_draft(&draft,Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:saved.chapters[0].id.clone()})).unwrap();assert_eq!(serde_json::to_value(storage::read_draft(&draft).unwrap().unwrap().project.entry_relations).unwrap(),expected);assert_eq!(serde_json::to_value(crate::history::read(&root,saved.revision).unwrap().entry_relations).unwrap(),expected);
  let mut pending=saved;pending.revision+=1;pending.worldbuilding.as_mut().unwrap().entries.remove(1);storage::atomic(&root.join(".write-studio-transaction.json"),&serde_json::to_vec_pretty(&pending).unwrap()).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().entry_relations).unwrap(),expected);std::fs::remove_dir_all(root).unwrap();
 }
 #[test]
 fn explicit_roles_and_review_metadata_survive_storage_and_portable_exports(){
  let mut project=fixture();let relations=project.entry_relations.as_mut().unwrap();relations.schema_version=2;
  let kind=&mut relations.types[0];kind.name=Some("Teaching".into());kind.title="Mentor".into();kind.inverse_title="Apprentice".into();kind.symmetric=false;kind.needs_role_review=Some(true);kind.disabled_template_ids=Some(vec!["00000000-0000-0000-0000-000000000999".into()]);
  let mut opposite=relations.links[0].clone();opposite.id="00000000-0000-0000-0000-000000000952".into();std::mem::swap(&mut opposite.source_id,&mut opposite.target_id);relations.links.push(opposite);
  storage::validate(&project,true).unwrap();
  let root=std::env::temp_dir().join(format!("write-studio-relations-v2-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();
  let saved=storage::save(&root,project.clone()).unwrap();let reopened=storage::open(&root).unwrap();assert_eq!(serde_json::to_value(&reopened.entry_relations).unwrap(),serde_json::to_value(&saved.entry_relations).unwrap());
  let packet=crate::entry_transfer::EntryPackage{format:"write-studio-entries".into(),schema_version:1,root_entry_ids:vec![saved.worldbuilding.as_ref().unwrap().entries[0].id.clone()],worldbuilding:saved.worldbuilding.clone().unwrap(),images:vec![],entry_relations:saved.entry_relations.clone()};
  crate::entry_transfer::validate(&packet).unwrap();let loaded:crate::entry_transfer::EntryPackage=serde_json::from_slice(&serde_json::to_vec(&packet).unwrap()).unwrap();assert_eq!(serde_json::to_value(loaded.entry_relations).unwrap(),serde_json::to_value(packet.entry_relations).unwrap());
  for case in ["same-role","same-link","same-type-name","symmetric-duplicates","missing-name","long-name","bad-disabled-template"]{
   let mut invalid=project.clone();let relations=invalid.entry_relations.as_mut().unwrap();match case{
    "same-role"=>{relations.types[0].needs_role_review=None;relations.types[0].inverse_title="Mentor".into();},
    "same-link"=>{relations.links[1].source_id=relations.links[0].source_id.clone();relations.links[1].target_id=relations.links[0].target_id.clone();},
    "same-type-name"=>{let mut kind=relations.types[0].clone();kind.id="00000000-0000-0000-0000-000000000953".into();relations.types.push(kind);},
    "symmetric-duplicates"=>{relations.types[0].needs_role_review=None;relations.types[0].symmetric=true;relations.types[0].inverse_title="Mentor".into();},
    "missing-name"=>relations.types[0].name=None,
    "long-name"=>relations.types[0].name=Some("x".repeat(121)),
    _=>relations.types[0].disabled_template_ids=Some(vec!["invalid".into()])
   }assert!(storage::validate(&invalid,true).is_err(),"{case}");
  }
  std::fs::remove_dir_all(root).unwrap();
 }
 #[test]
 fn relationship_views_roundtrip_save_history_draft_and_validate_geometry(){
  let mut project=fixture();let relations=project.entry_relations.as_mut().unwrap();relations.schema_version=3;relations.types[0].name=Some("Friendship".into());
  let entry_id=relations.links[0].source_id.clone();
  let view:RelationGraphView=serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000960","name":"Ethan's circle","settings":{"focusId":entry_id,"depth":2,"templateId":"","typeId":"","plotId":"","showArchived":false,"showLabels":true},"positions":{entry_id:{"x":300,"y":500}},"camera":{"x":20,"y":40,"zoom":0.75}})).unwrap();
  relations.views=Some(vec![view]);storage::validate(&project,true).unwrap();
  let root=std::env::temp_dir().join(format!("write-studio-relation-views-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();
  let saved=storage::save(&root,project.clone()).unwrap();let expected=serde_json::to_value(&saved.entry_relations).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().entry_relations).unwrap(),expected);assert_eq!(serde_json::to_value(crate::history::read(&root,saved.revision).unwrap().entry_relations).unwrap(),expected);
  let draft=root.join("draft");storage::write_draft(&draft,Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:saved.chapters[0].id.clone()})).unwrap();assert_eq!(serde_json::to_value(storage::read_draft(&draft).unwrap().unwrap().project.entry_relations).unwrap(),expected);
  let mut pending=saved;pending.revision+=1;pending.entry_relations.as_mut().unwrap().views.as_mut().unwrap()[0].name="Revised circle".into();storage::atomic(&root.join(".write-studio-transaction.json"),&serde_json::to_vec_pretty(&pending).unwrap()).unwrap();assert_eq!(storage::open(&root).unwrap().entry_relations.unwrap().views.unwrap()[0].name,"Revised circle");
  for case in ["version","name","duplicate-name","depth","filter","point","point-id","zoom","camera"]{
   let mut invalid=project.clone();let relations=invalid.entry_relations.as_mut().unwrap();let view=&mut relations.views.as_mut().unwrap()[0];
   match case{
    "version"=>relations.schema_version=2,
    "name"=>view.name=" ".into(),
    "duplicate-name"=>{let mut other=view.clone();other.id="00000000-0000-0000-0000-000000000961".into();relations.views.as_mut().unwrap().push(other);},
    "depth"=>view.settings.depth=3,
    "filter"=>view.settings.type_id="invalid".into(),
    "point"=>view.positions.values_mut().next().unwrap().x=f64::NAN,
    "point-id"=>{view.positions.insert("bad".into(),GraphPoint{x:0.0,y:0.0});},
    "zoom"=>view.camera.zoom=0.0,
    _=>view.camera.x=f64::INFINITY
   }assert!(storage::validate(&invalid,true).is_err(),"{case}");
  }
  std::fs::remove_dir_all(root).unwrap();
 }
 #[test]
 fn genealogy_roundtrips_and_rejects_cycles_and_invalid_meanings(){
  let mut project=fixture();let relations=project.entry_relations.as_mut().unwrap();relations.schema_version=4;
  let kind=&mut relations.types[0];kind.name=Some("Family".into());kind.title="Parent".into();kind.inverse_title="Child".into();kind.symmetric=false;kind.genealogy=Some(GenealogyMeaning::Parent{parent_role:ParentRole::Target,lineage:Lineage::Adoptive});
  storage::validate(&project,true).unwrap();
  let root=std::env::temp_dir().join(format!("write-studio-genealogy-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();
  let saved=storage::save(&root,project.clone()).unwrap();let expected=serde_json::to_value(&saved.entry_relations).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().entry_relations).unwrap(),expected);assert_eq!(serde_json::to_value(crate::history::read(&root,saved.revision).unwrap().entry_relations).unwrap(),expected);
  let packet=crate::entry_transfer::EntryPackage{format:"write-studio-entries".into(),schema_version:1,root_entry_ids:vec![saved.worldbuilding.as_ref().unwrap().entries[0].id.clone()],worldbuilding:saved.worldbuilding.clone().unwrap(),images:vec![],entry_relations:saved.entry_relations.clone()};crate::entry_transfer::validate(&packet).unwrap();let decoded:crate::entry_transfer::EntryPackage=serde_json::from_slice(&serde_json::to_vec(&packet).unwrap()).unwrap();assert_eq!(serde_json::to_value(decoded.entry_relations).unwrap(),expected);
  for case in ["version","cycle","partner","review"]{let mut invalid=project.clone();let relations=invalid.entry_relations.as_mut().unwrap();match case {
   "version"=>relations.schema_version=3,
   "cycle"=>{let mut opposite=relations.links[0].clone();opposite.id="00000000-0000-0000-0000-000000000952".into();std::mem::swap(&mut opposite.source_id,&mut opposite.target_id);relations.links.push(opposite);},
   "partner"=>relations.types[0].genealogy=Some(GenealogyMeaning::Partner),
   _=>relations.types[0].needs_role_review=Some(true)
  }assert!(storage::validate(&invalid,true).is_err(),"{case}");}
  std::fs::remove_dir_all(root).unwrap();
 }
 #[test]
 fn explicit_siblings_roundtrip_without_parents_and_require_symmetric_roles(){
  let mut project=fixture();let relations=project.entry_relations.as_mut().unwrap();relations.schema_version=4;relations.types[0].name=Some("Siblings".into());relations.types[0].genealogy=Some(GenealogyMeaning::Sibling);
  storage::validate(&project,true).unwrap();let root=std::env::temp_dir().join(format!("write-studio-siblings-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();let saved=storage::save(&root,project.clone()).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().entry_relations).unwrap(),serde_json::to_value(saved.entry_relations).unwrap());
  let relations=project.entry_relations.as_mut().unwrap();relations.types[0].symmetric=false;relations.types[0].inverse_title="Other sibling".into();assert!(storage::validate(&project,true).is_err());std::fs::remove_dir_all(root).unwrap();
 }
 #[test]
 fn connection_dates_validate_and_survive_storage_and_portable_exports(){
  let mut project=fixture();let relations=project.entry_relations.as_mut().unwrap();relations.schema_version=5;relations.types[0].name=Some("Interest".into());relations.types[0].title="Interested person".into();relations.types[0].inverse_title="Person of interest".into();relations.types[0].symmetric=false;
  relations.links[0].start=Some(crate::timeline::StoryDate{year:-20,month:Some(2),day:None});relations.links[0].end=Some(crate::timeline::StoryDate{year:0,month:Some(2),day:Some(29)});
  storage::validate(&project,true).unwrap();let root=std::env::temp_dir().join(format!("write-studio-connection-dates-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();let saved=storage::save(&root,project.clone()).unwrap();let expected=serde_json::to_value(&saved.entry_relations).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().entry_relations).unwrap(),expected);
  let packet=crate::entry_transfer::EntryPackage{format:"write-studio-entries".into(),schema_version:1,root_entry_ids:vec![saved.worldbuilding.as_ref().unwrap().entries[0].id.clone()],worldbuilding:saved.worldbuilding.clone().unwrap(),images:vec![],entry_relations:saved.entry_relations.clone()};crate::entry_transfer::validate(&packet).unwrap();let decoded:crate::entry_transfer::EntryPackage=serde_json::from_slice(&serde_json::to_vec(&packet).unwrap()).unwrap();assert_eq!(serde_json::to_value(decoded.entry_relations).unwrap(),expected);
  for case in ["version","invalid-day","reversed","range"]{let mut invalid=project.clone();let relations=invalid.entry_relations.as_mut().unwrap();match case{
   "version"=>relations.schema_version=4,
   "invalid-day"=>relations.links[0].end.as_mut().unwrap().day=Some(30),
   "reversed"=>relations.links[0].end.as_mut().unwrap().year=-30,
   _=>relations.links[0].start.as_mut().unwrap().year=1000000
  }assert!(storage::validate(&invalid,true).is_err(),"{case}");}
  project.entry_relations.as_mut().unwrap().links[0].start=None;storage::validate(&project,true).unwrap();std::fs::remove_dir_all(root).unwrap();
 }
 #[test]
 fn care_affinity_and_former_partner_meanings_roundtrip_without_implying_ancestry(){
  for (index,meaning) in [GenealogyMeaning::Guardian{parent_role:ParentRole::Target},GenealogyMeaning::StepParent{parent_role:ParentRole::Source},GenealogyMeaning::FormerPartner].into_iter().enumerate(){
   let mut project=fixture();let relations=project.entry_relations.as_mut().unwrap();relations.schema_version=6;let kind=&mut relations.types[0];kind.name=Some("Family context".into());kind.symmetric=matches!(meaning,GenealogyMeaning::FormerPartner);if !kind.symmetric{kind.inverse_title="Ward or stepchild".into();}kind.genealogy=Some(meaning);
   storage::validate(&project,true).unwrap();let root=std::env::temp_dir().join(format!("write-studio-family-context-{}-{index}",std::process::id()));std::fs::create_dir_all(&root).unwrap();let saved=storage::save(&root,project.clone()).unwrap();let expected=serde_json::to_value(&saved.entry_relations).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().entry_relations).unwrap(),expected);
   let packet=crate::entry_transfer::EntryPackage{format:"write-studio-entries".into(),schema_version:1,root_entry_ids:vec![saved.worldbuilding.as_ref().unwrap().entries[0].id.clone()],worldbuilding:saved.worldbuilding.clone().unwrap(),images:vec![],entry_relations:saved.entry_relations.clone()};crate::entry_transfer::validate(&packet).unwrap();let decoded:crate::entry_transfer::EntryPackage=serde_json::from_slice(&serde_json::to_vec(&packet).unwrap()).unwrap();assert_eq!(serde_json::to_value(decoded.entry_relations).unwrap(),expected);
   let mut invalid=project.clone();invalid.entry_relations.as_mut().unwrap().schema_version=5;assert!(storage::validate(&invalid,true).is_err());
   let kind=&mut invalid.entry_relations.as_mut().unwrap().types[0];kind.symmetric=!kind.symmetric;invalid.entry_relations.as_mut().unwrap().schema_version=6;assert!(storage::validate(&invalid,true).is_err());std::fs::remove_dir_all(root).unwrap();
  }
 }
 #[test]
 fn historical_view_filters_roundtrip_and_validate_without_changing_connections(){
  let mut project=fixture();let relations=project.entry_relations.as_mut().unwrap();relations.schema_version=7;relations.types[0].name=Some("Friendship".into());
  relations.views=Some(vec![serde_json::from_value(serde_json::json!({"id":"00000000-0000-0000-0000-000000000970","name":"Before the voyage","settings":{"focusId":"","depth":1,"templateId":"","typeId":"","plotId":"","showArchived":false,"showLabels":true,"at":{"year":-20,"month":2,"day":29},"showEnded":true},"positions":{},"camera":{"x":0,"y":0,"zoom":1}})).unwrap()]);
  let original_links=serde_json::to_value(&relations.links).unwrap();storage::validate(&project,true).unwrap();
  let root=std::env::temp_dir().join(format!("write-studio-historical-views-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();let saved=storage::save(&root,project.clone()).unwrap();let expected=serde_json::to_value(&saved.entry_relations).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().entry_relations).unwrap(),expected);assert_eq!(serde_json::to_value(crate::history::read(&root,saved.revision).unwrap().entry_relations).unwrap(),expected);
  let draft=root.join("draft");storage::write_draft(&draft,Some(storage::Draft{project:saved.clone(),path:root.to_string_lossy().into(),selected_id:saved.chapters[0].id.clone()})).unwrap();assert_eq!(serde_json::to_value(storage::read_draft(&draft).unwrap().unwrap().project.entry_relations).unwrap(),expected);
  assert_eq!(serde_json::to_value(&saved.entry_relations.as_ref().unwrap().links).unwrap(),original_links);
  for case in ["version","date","missing-date","range"]{let mut invalid=project.clone();let relations=invalid.entry_relations.as_mut().unwrap();let settings=&mut relations.views.as_mut().unwrap()[0].settings;match case{"version"=>relations.schema_version=6,"date"=>settings.at.as_mut().unwrap().day=Some(30),"missing-date"=>settings.at=None,_=>settings.at.as_mut().unwrap().year=1000000}assert!(storage::validate(&invalid,true).is_err(),"{case}");}
  std::fs::remove_dir_all(root).unwrap();
 }
 #[test]
 fn relationships_reject_invalid_or_duplicate_links(){
  storage::validate(&fixture(),true).unwrap();for case in ["schema","type","self","duplicate","name","id","symmetric"]{let mut project=fixture();let relations=project.entry_relations.as_mut().unwrap();match case{"schema"=>relations.schema_version=10,"type"=>relations.links[0].type_id="00000000-0000-0000-0000-000000000999".into(),"self"=>relations.links[0].target_id=relations.links[0].source_id.clone(),"duplicate"=>{let mut link=relations.links[0].clone();link.id="00000000-0000-0000-0000-000000000952".into();std::mem::swap(&mut link.source_id,&mut link.target_id);relations.links.push(link);},"name"=>relations.types[0].title=" ".into(),"id"=>relations.links[0].target_id="bad".into(),_=>relations.types[0].inverse_title="Other".into()}assert!(storage::validate(&project,true).is_err(),"{}",case);}
 }
 #[test]
 fn lineages_round_trip_and_validate_without_creating_links(){
  let mut project=fixture();let member=project.worldbuilding.as_ref().unwrap().entries[0].id.clone();
  let relations=project.entry_relations.as_mut().unwrap();relations.schema_version=8;relations.types[0].name=Some("Friendship".into());
  relations.lineages=Some(vec![FamilyLineage{id:"00000000-0000-0000-0000-000000000960".into(),name:"Witham".into(),member_ids:vec![member.clone()]}]);
  let json=serde_json::to_string(&project).unwrap();let restored:storage::Project=serde_json::from_str(&json).unwrap();storage::validate(&restored,true).unwrap();
  assert_eq!(restored.entry_relations.unwrap().lineages.unwrap()[0].member_ids,vec![member.clone()]);
  let root=std::env::temp_dir().join(format!("write-studio-lineages-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();let saved=storage::save(&root,project.clone()).unwrap();let expected=serde_json::to_value(&saved.entry_relations).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().entry_relations).unwrap(),expected);
  let packet=crate::entry_transfer::EntryPackage{format:"write-studio-entries".into(),schema_version:1,root_entry_ids:vec![member.clone()],worldbuilding:saved.worldbuilding.clone().unwrap(),images:vec![],entry_relations:saved.entry_relations.clone()};crate::entry_transfer::validate(&packet).unwrap();std::fs::remove_dir_all(&root).unwrap();
  for case in ["version","name","duplicate-name","duplicate-member","invalid-member"] {
   let mut bad=project.clone();let r=bad.entry_relations.as_mut().unwrap();
   match case {"version"=>r.schema_version=7,"name"=>r.lineages.as_mut().unwrap()[0].name=" ".into(),"duplicate-name"=>{let mut second=r.lineages.as_ref().unwrap()[0].clone();second.id="00000000-0000-0000-0000-000000000961".into();r.lineages.as_mut().unwrap().push(second);},"duplicate-member"=>r.lineages.as_mut().unwrap()[0].member_ids.push(member.clone()),_=>r.lineages.as_mut().unwrap()[0].member_ids=vec!["bad".into()]}
   assert!(storage::validate(&bad,true).is_err(),"{}",case);
  }
 }

 #[test]
 fn partnership_status_survives_storage_packages_and_backup(){
  let mut project=fixture();let r=project.entry_relations.as_mut().unwrap();r.schema_version=9;r.types[0].name=Some("Couple".into());r.types[0].genealogy=Some(GenealogyMeaning::Partner);r.links[0].partnership_status=Some(PartnershipStatus::Married);
  storage::validate(&project,true).unwrap();let root=std::env::temp_dir().join(format!("write-studio-partnership-{}",std::process::id()));std::fs::create_dir_all(&root).unwrap();let saved=storage::save(&root,project.clone()).unwrap();let expected=serde_json::to_value(&saved.entry_relations).unwrap();assert_eq!(serde_json::to_value(storage::open(&root).unwrap().entry_relations).unwrap(),expected);
  let packet=crate::entry_transfer::EntryPackage{format:"write-studio-entries".into(),schema_version:1,root_entry_ids:vec![saved.worldbuilding.as_ref().unwrap().entries[0].id.clone()],worldbuilding:saved.worldbuilding.clone().unwrap(),images:vec![],entry_relations:saved.entry_relations.clone()};crate::entry_transfer::validate(&packet).unwrap();let decoded:crate::entry_transfer::EntryPackage=serde_json::from_slice(&serde_json::to_vec(&packet).unwrap()).unwrap();assert_eq!(serde_json::to_value(decoded.entry_relations).unwrap(),expected);
  let zip=root.with_extension("zip");let restored_parent=root.with_extension("restored");std::fs::create_dir_all(&restored_parent).unwrap();crate::backup::create(&root,&zip,&saved.id,saved.revision).unwrap();let restored=crate::backup::restore(&zip,&restored_parent).unwrap();assert_eq!(serde_json::to_value(restored.project.entry_relations).unwrap(),expected);std::fs::remove_file(zip).unwrap();std::fs::remove_dir_all(restored_parent).unwrap();
  let mut bad=project.clone();bad.entry_relations.as_mut().unwrap().schema_version=8;assert!(storage::validate(&bad,true).is_err());
  let mut bad=project.clone();bad.entry_relations.as_mut().unwrap().types[0].genealogy=None;assert!(storage::validate(&bad,true).is_err());
  let mut bad=serde_json::to_value(&project).unwrap();bad["entryRelations"]["links"][0]["partnershipStatus"]=serde_json::json!("unknown");assert!(serde_json::from_value::<storage::Project>(bad).is_err());
  std::fs::remove_dir_all(&root).unwrap();
 }

}
