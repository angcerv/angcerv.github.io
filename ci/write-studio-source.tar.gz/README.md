# Write Studio

Local desktop manuscript editor for macOS and Windows (Windows validation pending), built with Tauri 2, React 19, TypeScript and Tiptap 3. Application identifier: `com.angy.writestudio`.

Guía para desarrolladores: [mapa del código, responsabilidades y patrones de ampliación](docs/guia-desarrollo.md).
Mediciones sin interfaz: [benchmarks de lógica, disco y exportaciones](docs/rendimiento.md).

## Development and checks

```sh
npm install
npm run tauri dev
npm run build
npm run check:bundle
npm test
cargo test --manifest-path src-tauri/Cargo.toml
```

The frontend build alone does not exercise native folder selection or window lifecycle. Rust uses `rfd` for native folder selection; no frontend filesystem plugin or general filesystem permission is exposed. The application operates offline after installation.

Large workspaces and export/history dialogs load from bundled local modules on first use. Visited workspaces stay mounted to preserve drafts, and navigation/search restoration waits for the panel to be ready. Loading failures offer an explicit retry; no network connection is required. `npm run check:bundle` inspects the built static module graph and checks that these panels remain deferred and that JavaScript chunks stay within the default 500 kB warning threshold.

## Windows builds

Windows x64 packaging uses `src-tauri/tauri.windows.conf.json`, merged automatically by Tauri. It produces a per-user NSIS `-setup.exe` with Spanish/English installer languages and an embedded WebView2 offline installer. Installation needs no separate WebView2 download; this increases the download size. The application keeps the same project/backup formats on Mac and Windows; device-local settings and recent paths remain specific to each computer.

Build on Windows with Node 22, stable Rust MSVC, Visual Studio C++ Build Tools and the Windows SDK (see [Tauri prerequisites](https://v2.tauri.app/start/prerequisites/)):

```powershell
npm ci
npm test
cargo test --manifest-path src-tauri/Cargo.toml --lib --locked
npm run tauri -- build --target x86_64-pc-windows-msvc
```

Python 3 must be available as `python3` for the independent export/backup checks. The installer is in `src-tauri/target/x86_64-pc-windows-msvc/release/bundle/nsis/`.

`.github/workflows/windows.yml` runs the non-UI checks on Windows and uploads the installer as a workflow artifact, manually or on a `v*` tag. This project directory must be the GitHub repository root for GitHub to discover that workflow. It does not publish releases automatically. Once the Windows checks and an explicit manual installation/open/save/backup/export check pass, the installer can be attached to GitHub Releases. Current builds are unsigned; public distribution signing remains a separate setup step. No Windows build or UI verification is implied by local macOS checks.

Persistence flushes each written file before publication. Unix additionally synchronizes directories; Windows validates directories instead because the Unix directory-fsync pattern is unavailable to ordinary Windows apps. Matching files use a writable handle on Windows for `FlushFileBuffers`; unchanged files are still retained, and journals/recovery guards remain active.

## Cross-platform reliability

`.github/workflows/platform-compatibility.yml` runs frontend/native checks on macOS and Windows, creates synthetic ZIP fixtures on each host, then restores both fixtures on both hosts. Exchange checks compare every archived file byte, project metadata, books, comments, galleries, history, map regions, planning canvases and recurring calendars; they edit/save the moved project and exercise device-local recovery. Separate jobs check the iOS device and simulator targets without launching either. Workflows require this directory as the repository root and have not been executed merely by adding the files.

Backup creation/restoration applies portable filename rules on every OS: reject Windows device names, reserved characters, case aliases and file/directory collisions before extracting. Paths remain relative with `/` separators; archive metadata never supplies local project paths. Recovery writes stay serialized, and a failed write still drains a newer queued draft or explicit discard; failure of the final request remains visible. Canvas history shares Ctrl/Cmd+Z, Ctrl+Y and Ctrl/Cmd+Shift+Z without consuming editable fields, composition or handled key events.

The same project format does not imply complete platform feature parity. iPad project-folder access uses the native coordinated directory adapter and backup import uses the mobile dialog plugin. General file/image pickers and export destinations still need their mobile implementations in `platform.rs`. Real-device validation of keyboard occlusion, Split View, touch, suspension, file providers and memory use remains pending. Desktop installers also need installation/update checks and signing before a verified public release.

## Using projects

The active book lives in the manuscript sidebar header; when the sidebar is hidden or the scene board is open, the same compact control is available in the manuscript header. A single book shows its name without a redundant selector. Its options open **Organize books** or start a new book draft. Switching books remembers the last chapter/scene per book during the session and retains unsaved manuscript edits.

The book organizer separates the book list from the selected book’s numbered chapters. Rename and book ordering are explicit contextual actions; chapters can be selected and moved together with one destination chooser. Moves preserve source order and append to the destination, while chapter reordering remains in planning. At narrow widths the organizer switches between the book list and chapter detail. All organization changes remain local until **Save**; Cancel, X and Escape discard the entire draft. Only empty books can be removed, and the last book is retained. Saving merges organization metadata onto the latest project content/revision, preserving scenes, comments, references and shared world/maps/timeline. An open scene follows its chapter into the new book.

Opening or creating a project now starts at **Project overview**, a brief composition of existing content and attention counts. Choose **Build the world**, **Plan the story** or **Write**. The header's **Project overview** control returns there; save/recovery errors remain visible in the shared shell. Summary calculations are deferred and show a loading state rather than false zero counts. Recovery still returns to the recovered manuscript context.

The five primary workspaces are **Manuscript**, **Story planning**, **World**, **Timeline** and **Pending**. Planning groups **Chapters and scenes** (outline/board), **Plots** and **Character arcs**. Manuscript keeps scene/chapter reading and a contextual **Plan this chapter** action. World groups entries, relationships, maps and visual resources; **Configure** opens templates or relationship types. Maps and planning preserve their stable internal navigation destinations, so existing context links and Back/Forward still work. This is an interface reorganization, with no project schema migration. Last-working-area choices are session-only; reopening does not promise to restore the prior session's editor position.

**Pending** separates **Ideas and decisions** from **Review**, remembering each section's filters during the session. The default review list excludes optional scene-development checks; choose that category explicitly. Likewise, entries without appearances remain available in Continuity review but are excluded from the default warning list. Overview attention links open the corresponding global list without leftover search/chapter filters. Explicit idea links reveal their target, including incorporated/discarded ideas.

Entry editing, reading and contextual consultation share a grouped **Where this entry is used** presentation: detailed manuscript appearances, related ideas, planning, structured event participation, maps and other references. Each source is grouped by stable ID; marker notes and marker membership share their destination, as do event notes and participation. Mentions do not imply event participation. Map/route destinations and exact manuscript mention navigation remain explicit. Map entry fields are expandable, and consultation does not duplicate the complete management workspace. Visual library filters remain session-only, separate from the image chooser's filters.

Scene intention fields are shared between the chapter planner’s scene details and the manuscript context. Both edit the same `scene.planning` values, independently of the synopsis and each plot/arc beat. Explicit **Edit entry** actions from manuscript/map consultation open editing even if World was last in reading mode.

Contextual links to timeline events reveal their inspector without clearing the timeline filters. An inactive timeline drawer has no modal semantics, so it cannot block another workspace’s keyboard navigation.

Project actions offer one **Export…** entry leading to the existing manuscript, planning and encyclopedia exporters. Backups and history remain separate safety operations. None of these views copies manuscript text or project content into navigation preferences.

Choose **Settings** (the gear icon) and select the default projects folder once. **New project** asks for a display name and suggests an editable folder name, then creates a dedicated child folder under that location. The destination is previewed before creation. Creation writes the initial project immediately. You can also select/change the default projects folder from the creation dialog. **Open project** selects an existing project folder. Rename the project, chapters and scenes using their title fields. Add chapters from the sidebar and scenes from the chapter heading. **Save project** writes all changes manually. The footer confirms **Saved** only after Rust acknowledges completion. **Close project**, window close, and native application quit offer Save / Discard / Cancel when changes are pending. Saving errors retain the current editor contents. Reload protection in the browser is best effort only.

## Books and sagas

Use **Manuscript → Manage books** to organize a saga in one project. The initial book retains all existing chapters and uses the project title; add more books, rename or reorder them, and assign chapters using the shared dropdowns. Changes apply with **Save**; Cancel/Escape discards the dialog draft. Only empty books can be removed. The manuscript, chapter planner and board follow the selected book. Cross-project lore copies are unnecessary: entries, maps, resources, plots/arcs, pending items and timeline stay shared.

Timeline filters and manuscript appearances offer **All books** or one book (timeline membership comes from explicit scene links). Find/replace adds **Current book** while preserving a clearly labelled **All books** scope. Manuscript and planning exports select a book independently; Word covers and filenames use its title. Exporting all books includes book headings. Scoped planning export excludes other books’ scene beats without treating those scenes as deleted.

Optional `books: [{id, title, chapterIds}]` metadata extends project schema 1. Every chapter belongs to exactly one book when books are present; chapter and scene IDs, text files and shared lore remain unchanged. Flat chapter order remains authoritative inside a book; book array order groups the manuscript. Existing projects without books retain the single-novel behavior. Native validation rejects duplicate, missing and dangling memberships; save, history, recovery and portable backups retain the metadata. Older application builds cannot read projects once book metadata is saved.

## Project format, schemaVersion 1

```text
project.json
manuscript/scenes/<scene-id>.md
```

`project.json` contains `schemaVersion`, stable project `id`, `title`, `revision`, and an ordered `chapters` array. Each chapter contains stable `id`, `title`, and ordered `scenes`; each scene contains stable `id` and `title`. Scene text lives exclusively in its Markdown file. Array order is authoritative; filenames are IDs and never titles. No HTML or localStorage manuscript storage is used. Device-local interface preferences are stored in localStorage; manuscript text is not.

Example metadata:

```json
{
  "schemaVersion": 1,
  "id": "00000000-0000-0000-0000-000000000001",
  "title": "My story",
  "revision": 1,
  "chapters": [{
    "id": "00000000-0000-0000-0000-000000000002",
    "title": "Chapter 1",
    "scenes": [{
      "id": "00000000-0000-0000-0000-000000000003",
      "title": "Scene 1"
    }]
  }]
}
```

The format keeps the small outline in `project.json` rather than a separate outline file. Worldbuilding files are added only after templates or entries are created; timeline files are not created yet. Unknown schema versions, unknown metadata fields, duplicate or unsafe identifiers, missing scene files, invalid JSON, and unbalanced/unsupported Markdown line breaks are rejected. The manuscript format needs no migration. Reference fields upgrade worldbuilding separately, with a prior backup as described below.

### Markdown subset

UTF-8, LF line endings. Paragraphs are separated by exactly two newlines, including empty paragraphs. Bold uses `**text**`, italic uses `_text_`, and hard breaks use two spaces followed by a newline. Backslash escapes preserve literal Markdown punctuation. The editor supports only paragraphs, bold, italic and hard breaks; richer pasted formatting is reduced to that editor schema. The parser handles the application's canonical subset, not arbitrary Markdown documents. External headings, lists, links, raw HTML and other advanced syntax are not interpreted as formatting. Scene files remain readable in any text editor. To preserve formatting and exact empty paragraph counts, external edits should follow this subset. Markdown is parsed structurally; no HTML tag stripping is used.

## Save and recovery protocol

Rust serializes operations within this application instance. During file operations, editor and structural controls are disabled. Revision checks reject saves from an outdated project revision. New projects reserve a new child directory using exclusive directory creation; existing directories are never reused or overwritten. The underlying low-level initial save still requires an empty folder.

Each save increments the revision and first writes a complete pending snapshot to `.write-studio-transaction.json`. Each individual file is written through a sibling `.pending` file, flushed with `sync_all`, then renamed; containing directories are also flushed. Unchanged scene, template, entry and world index bytes reuse their existing files while still syncing them and their directories; comparison uses disk bytes so missing or damaged content is repaired during application. Journals and revision metadata retain atomic replacement. Scenes and worldbuilding files are applied before project metadata; each worldbuilding index is written after its template and entry files. The journal is deleted after successful application. This is **not** an atomic multi-file transaction: external readers can see intermediate files. Opening or saving automatically rolls forward a validated pending snapshot, making an interrupted save recoverable. Do not delete the journal after a failure. Retrying the same completed snapshot is safe if its content and revision match. When a pending journal matches the current base revision, retrying also saves edits made after the failure. If no journal remains and a divergent newer disk revision is found, reopening is required; preserve any newer unsaved text separately first.

Deleted scenes are removed from metadata but their Markdown files are retained as unreferenced files for manual recovery. This is not versioned backup. Keep independent backups of project folders. Simultaneous editing in multiple application processes or external editors is not supported; external content edits that do not update metadata revision are not detected. The project journal protects attempted saves. Unsaved typing is protected separately by recovery snapshots described below; edits not yet acknowledged by the recovery writer can still be lost on abrupt termination.

## Native acceptance check

1. Run `npm run tauri dev`. Set the default projects folder in Settings, then create a named project. Cancel a folder picker once to verify cancellation preserves both the setting and the current project.
2. Rename the project and create two chapters with multiple scenes. Enter accents, emoji and non-Latin text, several paragraphs, bold, italic, combined formatting and Shift+Enter breaks. Save and confirm **Saved**.
3. Close and reopen the folder, then quit and relaunch. Confirm titles, chapter/scene order, text and formatting match.
4. Edit text, then try another project, Close project, the window close button, and Cmd+Q. Check Cancel retains text, Save persists it, and Discard proceeds. Canceling the save folder picker must keep the unsaved prompt. Reopen the same folder with Discard and verify the editor shows the saved text, not the discarded draft.
5. Attempt to open a folder with malformed `project.json` or a missing scene. Confirm an error appears and the current manuscript remains available. To test write failure, make the project folder unwritable in Finder, edit and save, then restore permissions and retry.
6. Switch themes, restart and confirm the preference. Check scene/chapter deletion confirmation and reopening a chapter with no scenes.
7. Reorder chapters and scenes with the up/down buttons. Move a scene into another chapter using **Move to chapter**, including an empty chapter. The scene should remain open. Save, close and reopen, then verify both the order and the text. Repeat without saving, restart and recover the draft to verify the recovered structure.

## Current scope

The sections below document the implemented writing, autosave/recovery, history, export, worldbuilding, maps and timeline workflows. Undo/redo history is retained in memory for the 60 most recently edited scenes during a project session, including scene/chapter view switches. It resets on project reload and is invalidated if a scene is restored with different content. Native UI acceptance remains a manual check on the user's Mac. Vite may report a bundle-size advisory for Tiptap; the editor is loaded locally and there is no network backend.


## Stable writing sessions and draft recovery

`npm run tauri dev` now disables the Rust file watcher and frontend live reload by default. This avoids restarting the writing session when source/configuration files receive filesystem events. Restart the command manually to load code changes. When intentionally developing application code, opt in with:

```sh
WRITE_STUDIO_LIVE_RELOAD=1 npm run tauri dev
```

The file events themselves do not identify which process touched the files. Disabling live reload prevents these events from resetting the application; it does not establish their external cause.

Each manuscript or worldbuilding change queues an independent recovery snapshot through Rust. Writes are serialized, pending intermediate snapshots are coalesced, and the footer distinguishes **Updating recovery copy**, **Recovery copy updated**, and recovery errors. This never displays the project as **Saved**; Save is still required to update its Markdown files. Recovery snapshots use atomic temporary-file replacement and directory flushing. They live outside the repository and project folder, under Tauri's application data directory: on macOS, `~/Library/Application Support/com.angy.writestudio/recovery.json`. They contain the project snapshot, original project path, and selected scene ID. No story content is kept in localStorage.

After a restart or reload, the application offers **Recover draft** or **Discard recovery** before another project can overwrite the copy. Recovering restores unsaved text in memory without writing project files. Save, an explicit discard, or a successful switch to another project clears the recovery copy in order, after preceding draft writes complete. Canceling a project picker preserves it. A malformed recovery copy blocks new writing until the user explicitly discards it or exits with the file intact for manual recovery.

Recovery is not a historical backup. Only the latest acknowledged snapshot is guaranteed by this mechanism; a process termination while **Updating recovery copy** may lose the most recent edits. This change cannot recover text already lost before recovery snapshots were implemented.

### Regression check for unexpected restarts

1. Stop any earlier development process using Ctrl+C in its terminal, then run `npm run tauri dev` again.
2. Open a test project, add a second scene and type a recognizable Unicode sentence. Wait for **Recovery copy updated** without pressing Save.
3. Stop and restart the development command. Choose **Recover draft** and confirm both scenes and their text are present. Save and reopen the project normally.
4. While writing, changing application source files should no longer reload Vite or rebuild Tauri in the default mode. Verify there are no white loading flashes. Code changes take effect after restarting the command.


## Project names and default location

Settings are persisted by Rust in `settings.json` alongside the recovery file, using `schemaVersion: 1` and nullable `projectsDirectory`. The initial location is unset so the user can choose it explicitly. The selected location must be an existing directory. Changing it affects future projects only; existing projects can still be opened from any folder.

A project has three independent identifiers:

- A stable UUID in `project.json.id`, used for identity.
- A display name in `project.json.title`, supporting Unicode. The creation name is trimmed and must contain 1–120 characters.
- Its physical folder name, chosen during creation and available from the project path. A suggested lowercase ASCII slug is generated from the title; the user can edit it before creation. It uses letters, digits and hyphens, up to 80 characters, and excludes reserved names and leading/trailing hyphens. Titles without ASCII letters or digits receive the editable fallback `project`.

The folder name is not duplicated in metadata: the directory itself is its source of truth. Renaming the display title does not rename the directory or change the UUID. Two projects can have the same display name if their folder names differ. A duplicate folder name produces an error without modifying the existing folder. A partially failed creation retains its new folder and recovery journal, and reports the path; it is never silently removed.

To verify natively: choose a projects folder in Settings, restart the application, and confirm that location is remembered. Create “Mi historia” and check it appears under `mi-historia`. Try creating it again and confirm the existing project is untouched; change only the folder name and create successfully. Rename the project's display title and confirm the directory stays unchanged. Change the default location and confirm only subsequent projects use it. Cancel creation and check that no directory is created and the current manuscript remains intact.


## Manuscript organization

Chapter headings provide **Move chapter up** and **Move chapter down**. Scene headings provide **Move scene up** and **Move scene down**, within the current chapter. Boundary actions are disabled. For projects with multiple chapters, **Move to chapter** moves the current scene to the end of the selected chapter; use the scene arrows to choose its final position. An empty source chapter is retained and can receive new or moved scenes.

All structural edits keep project, chapter and scene IDs, display titles and Markdown text intact. Moving the current scene keeps it selected and does not remount its editor, preserving its editing history during the move. These changes use the existing unsaved-change, recovery and manual-save flow. The schema remains at version 1: ordering and chapter membership are represented by the existing metadata arrays; no migration or file renaming is needed. Reordering actions are separate from Tiptap's text undo/redo; use the arrows or chapter selector to reverse them.

The JavaScript workflow tests and Rust storage tests share original/reordered manuscript fixtures. They cover immutable structural changes, boundary no-ops, moving the last scene out of a chapter, populating an empty chapter, scene uniqueness and content preservation, and saving/reopening/recovering the resulting structure.


## Worldbuilding, first usable stage

The **Worldbuilding** project tab is the dedicated editing workspace. Its Entries view has a browser beside the entry editor; Templates provides a wider field editor. The manuscript scene stays mounted when switching tabs, preserving its text undo history, selection and scroll position. **Back to manuscript** returns focus to the writing position. The toolbar **Toggle world reference** button opens a read-only consultation panel alongside the manuscript. It supports search, template filtering, selection and copying plain field values. **Edit in Worldbuilding** opens the selected entry in the editing tab. The panel has no template/entry mutation callback or editing forms. Narrow windows collapse manuscript navigation while this panel is open to preserve editor space.

**Templates** creates user-defined categories with any name. Each template has an ordered array of fields with stable UUIDs and five supported types: `shortText`, `longText`, `number`, `boolean`, `reference`. Existing field types are displayed but cannot be changed; explicit conversions are deferred. Field names and order can change without affecting stored values. Archive/restore replaces destructive field removal: archived fields and their values remain in their original records. New fields appear empty in existing entries. No predefined categories or template inheritance are imposed.

**Entries** creates records from a chosen template, edits their title and values, and filters/searches by template, title or text values. Entry template references and field value keys are IDs, never display names. Entries can be archived/restored. Archived field values can be inspected in the entry details. Text fields are plain JSON strings; long text preserves newlines. Number and checkbox values are typed JSON values; empty values are represented by missing keys or null. Creating a template/entry or adding a field requires its Create/Add action; incomplete creation forms are not part of the saved project.

### Additive storage format

The existing manuscript `schemaVersion: 1` and file layout stay valid. Worldbuilding is an additive, separately versioned companion format, requiring no rewrite or migration of existing manuscript data. Basic worldbuilding uses `schemaVersion: 1` for its index, templates and entries. Enabling unrestricted Reference fields upgrades these companion records to version 2; choosing an allowed template uses version 3. Existing saved data is backed up before either upgrade; the file layout stays the same:

```text
worldbuilding/index.json
worldbuilding/templates/<template-id>.json
worldbuilding/entries/<template-id>/<entry-id>.json
```

The index is authoritative for ordered template IDs and entry locations (`id`, `templateId`). Template files contain their ID, display title and ordered `fields` (`id`, `label`, `fieldType`, `archived`). Entry files contain ID, `templateId`, title, `archived`, and a `values` object keyed by field ID. The complete worldbuilding object is included in in-memory IPC payloads, recovery copies and pending save journals, but is omitted from `project.json` to avoid duplicating the authoritative records. Projects without worldbuilding need no companion files.

Save and interrupted-save recovery cover the manuscript and worldbuilding together through the existing roll-forward journal. This remains a recoverable multi-file operation, not atomic visibility of the whole project to external readers. Open validates schema versions, locations, global ID uniqueness, template and field references, and typed values. A missing index in a nonempty worldbuilding folder is treated as an error, and files remain untouched. Invalid data cannot replace the currently open project in memory. Reference fields use the versioned upgrade and backup protocol below. Any future format migration must also create a backup before modifying saved data.

Tests share a fixture containing Unicode, multiline text, zero, false, null, archived values and multiple templates. They verify renamed/reordered/archived fields retain values, filters and search, separate authoritative files, compatibility with manuscript-only projects, typed-value validation, interrupted worldbuilding save recovery, draft recovery and rejection of missing/invalid files and unsafe locations.

### Native acceptance check

1. Save current work, restart `npm run tauri dev`, open a test project and select the **Worldbuilding** project tab.
2. Create a template of your own, then add one field of each supported type. Create two entries in **Entries** and fill in Unicode text, multiple paragraphs, a number and a checkbox.
3. Return to **Templates**, rename and reorder fields, then archive one. Confirm the entry still has its other values and shows the retired value under **Archived fields**. Restore it and verify the original value returns.
4. Write in the manuscript, open **Toggle world reference**, consult/search entries, and close the side panel. Confirm the writing position and text undo history remain available. The side panel must offer no editing controls. Open a reference using **Edit in Worldbuilding**, make a change in the full editing tab, then use **Back to manuscript** and verify the reference updates.
5. Save, close and reopen the project. Verify both manuscript and entries. Change a worldbuilding value without saving, wait for **Recovery copy updated**, restart and recover the draft.
6. Archive and restore an entry. Confirm template filters, search and the archived-entry view show the expected records. Test the panel at a narrow window width.


## Interaction feedback and workspace navigation

Worldbuilding navigation distinguishes entry editing, reading, templates, the relationship network, genealogy, relationship types and visual resources. Back/Forward can return from a graph to the same selected entry and back to the graph, even when the entry ID does not change. History labels name the actual pane; an unrelated deleted entry does not invalidate a graph or resource-library visit.

Network and genealogy explorations retain their filters, selected entry/connection, camera and inspector state in session-only workspace memory. Each initial focus has its own exploration. Temporary network changes retain their original baseline when returning; modal names and relationship-edit drafts are not remembered. Returning renders current project data, never an old world snapshot. Genealogy layouts are memoized for unchanged world/relationship/filter inputs, so selecting an entry or zooming does not recompute the family layout.

Navigation position capture measures UI containers while pruning editor paragraph descendants, SVG geometry and hidden/inert branches. It retains disclosure and scrolling state, including nested closed disclosures. If a named control has been removed, restoration does not reuse a different element at its old DOM position. Node-based regression checks cover real view remounts and synthetic large editor/hidden trees without opening a UI; an interactive usability pass with a large real project remains a manual verification.

Shared interaction styles provide hover, pressed and keyboard-focus states for buttons, dropdowns, text inputs, checkboxes, disclosure summaries, links and checkbox labels. Selected controls retain a distinct active state. Disabled controls do not animate or react to hover/press. All dropdowns now use the application's custom combobox/listbox rather than native macOS popup menus. Both the trigger and option menu receive matching theme, hover, press and focus feedback. The `prefers-reduced-motion` preference disables transitions and press movement while retaining color and focus feedback.

Project tabs support Left/Right arrows and Home/End, with linked tab panels and a single tab stop. Both the manuscript and worldbuilding editor remain mounted while their inactive view is hidden. Worldbuilding entry selection is shared with the reference pane; search and view navigation change interface state only, without marking project data dirty. All edits continue through the existing manual-save and recovery flow; no storage format changes are involved.

UI rendering tests verify that the reference pane has only search/filter controls and plain field values, that the separate editing workspace retains editable controls and archived values, and that rendering either view leaves project data unchanged. For visual acceptance, check hover/press/focus in both themes, keyboard navigation across tabs and controls, disabled arrows/actions, custom dropdowns, and reduced-motion mode. Verify repeated view changes retain the scene's caret, scroll position and Undo history.


## Custom dropdowns

`Dropdown` is shared by chapter movement, template selection, field type selection, and both worldbuilding filters. It has a theme-colored trigger, rotating chevron, selected-option checkmark, highlighted options, a bounded scrollable menu and reduced-motion support. The menu is portalled above scrolling containers and automatically opens above the trigger when there is insufficient space below. Scrolling outside the menu, clicking outside, or moving focus away dismisses it. Menus also close when their source view becomes hidden or their source fieldset becomes disabled/inert.

Keyboard behavior: Enter/Space opens or confirms, Up/Down moves through enabled options with wrapping, Home/End selects the first/last highlight, and typing finds labels (including accented names). Tab confirms the highlighted choice and advances focus; Escape dismisses without changing the value. Selection is only committed on confirmation/click, so browsing chapter destinations cannot accidentally move a scene. Buttons use accessible combobox/listbox relationships and retain existing field labels. These controls do not change the project storage format.

Automated checks cover initial selection, empty string filter values, keyboard navigation boundaries, disabled options, wrapping and typeahead; UI rendering checks confirm the worldbuilding views no longer contain native selects. Native acceptance: open each dropdown, inspect both themes, hover and choose options, test keyboard actions and cancellation, test a long list near the bottom of a scroll area, and verify busy/dialog states dismiss an open menu. For **Move to chapter**, confirm Arrow/Escape leaves the scene untouched and Enter/click applies the chosen move.


## References between entries

Add a **Reference** field in Templates. It stores one optional link as `{ "entryId": "<stable-entry-uuid>" }`, keyed by the stable field ID, or null when cleared. Entry names are resolved at display time; renaming an entry or template never rewrites incoming links. Each Reference field has a search input and the shared custom dropdown. Search matches entry and template display names. New choices contain active entries only and respect any allowed-template restriction; **None** clears the reference. Equal entry/template display names are disambiguated using their IDs.

Existing links to archived entries stay intact and display **Archived**. They remain navigable in both the editor and read-only reference pane. Archiving a Reference field also preserves its value. A well-formed reference to a missing target is retained with **Missing entry**, allowing the user to choose a replacement or clear it; it is not silently removed. Malformed reference objects and unsafe identifiers are rejected by Rust before saving. Missing files that are still declared in the worldbuilding index continue to make project opening fail safely, as before.

The read-only pane follows linked entries without modifying project data and provides **Back** for reference navigation. The full editor navigates to the target, clearing unrelated filters and showing the archived-entry view when needed. Ordinary search can match the current display names of linked entries. Self references and cycles are allowed; resolving/searching a reference is one hop and never recursively renders a graph.

### Worldbuilding schemaVersion 2 and upgrade backups

Version 2 adds `fieldType: "reference"` and object-valued entry references. Its index, all templates and all entries must consistently use `schemaVersion: 2`; the manuscript project format stays at version 1. Basic version 1 projects still open and save without conversion until the first Reference field is added. Recovery snapshots immediately preserve the version 2 in-memory draft.

At the first manual Save that upgrades existing worldbuilding from 1 to 2, Rust verifies the last saved project and copies its `project.json`, manuscript, worldbuilding, and any assets/timeline folders into `.write-studio-backups/worldbuilding-v1-r<revision>-<timestamp>/`. The backup contains plain original files plus `backup.json` with the source ID, revision and reason. Files and directories are flushed before the backup is marked complete and before any migration journal or authoritative file write. Incomplete backup attempts retain a `.building` directory. If backup creation fails, the upgrade stops and original files remain unchanged; edits remain in memory. Symbolic links are not followed while copying source files.

The existing journal then writes the complete version 2 snapshot. If interrupted, opening rolls forward the whole pending snapshot, including all versioned templates, entries and references. The completed pre-upgrade backup remains separate and readable as a version 1 project. Ordinary later version 2 saves do not create additional migration backups. Downgrades are rejected. Older application versions cannot read the version 2 worldbuilding format; to use the old data, copy the completed backup to another location before opening it. This is a migration backup, not a general save history.

### Reference acceptance check

1. Create two entries, add a Reference field to one template, search for the other entry and select it. Save, close and reopen; verify the link remains.
2. Rename the target and its template. Confirm references display the new names and still navigate to the same entry.
3. In Manuscript, follow the reference in **World reference**, use **Back**, and return to writing. Confirm the pane remains read-only and the writing point is retained.
4. Archive the target. Confirm the existing link remains visible and navigable with an Archived indicator, while archived entries are excluded from new selections. Restore the target and verify the indicator clears.
5. Archive/restore the Reference field and verify its original value remains. Select **None** to explicitly clear a link.
6. For a project that previously had version 1 worldbuilding, verify the first reference Save creates a complete backup folder. An unsaved reference edit should also survive restarting and recovering the draft.

Automated checks cover stable IDs through renames and archiving, searchable choices, duplicate names, missing targets, self/cyclic references, read-only links, archived picker values, migration backups (including blocked backup creation), partial migration recovery, v2 save/reopen/draft recovery, malformed references, and downgrade rejection.


## Reference template restrictions

Reference fields provide **Allowed template** at creation and in their existing field settings. **Any template** is the default and preserves the unrestricted behavior of existing Reference fields. Selecting a specific template stores its stable ID in the field's optional `targetTemplateId`; display-name changes do not affect the rule. The picker and its search include only active entries belonging to that template, plus **None** for clearing a value.

Changing a rule never changes entry values. Existing references that no longer fit remain visible and navigable with **Needs review · Expected <template>** in the editing and consultation views. Template settings also show a count of affected existing links, including archived entry values. Choosing Any template removes the restriction and review warning without rewriting incoming links. This is a selector restriction with review of existing data: persisted mismatches are intentionally accepted, not rejected or silently converted. A missing allowed-template ID is preserved and flagged for review; no new candidates are offered until the rule is corrected.

### Worldbuilding schemaVersion 3

Version 3 adds optional `targetTemplateId` metadata to Reference field definitions. Any template is represented by absence of that property. Rust validates that restrictions occur only on Reference fields, use a valid ID, and belong to a version 3 world. Index, templates and entries use the same schema version. Adding or changing an unrestricted field in an existing version 3 world never downgrades it.

Older versions 1 and 2 still open without conversion. The first restriction promotes the in-memory world to version 3. On manual Save, upgrading saved data from either 1 or 2 to 3 uses the same complete pre-upgrade backup protocol described above, with the source version in `.write-studio-backups/worldbuilding-v<source-version>-r<revision>-<timestamp>/`. The backup marker records the source version and the `worldbuildingSchemaUpgrade` reason. Manuscript storage remains at version 1. Subsequent version 3 saves do not create repeated upgrade backups, and clearing all restrictions does not downgrade the format. Drafts and interrupted-save recovery include both the rules and all original reference values.

Automated checks cover creating a restricted field, adding a restriction to an existing Reference, v1/v2 upgrades, filtering/search, template renames, archived targets, mismatch review and counts, removing a rule, preserving IDs and values, v2 backup and v3 save/reopen/draft recovery, invalid restriction metadata and downgrade rejection.

Native acceptance: create a Reference field with Allowed template set to a specific template and confirm its picker/search show only that template's active entries. Switch the rule to a different template, verify the old link is kept with Needs review in both views, then select a valid replacement. Rename the allowed template and verify the rule still works. Choose Any template and verify all active entry templates are available again. Save and reopen, and also check an unsaved rule change through draft recovery.

### Deleting worldbuilding records

Entries can be deleted from their detail heading, including archived entries. A confirmation lists incoming links (including links from archived entries/fields). Those links keep their IDs and display `Missing entry` until replaced or cleared. Templates can only be deleted when they have zero associated entries, including archived entries. The model and storage validation both enforce this rule. References whose allowed template is deleted keep the rule and display `Allowed template is missing` for review.

Deletion is a project edit: draft recovery protects it, and Save commits it. There is no editor undo for deletion. As with removed manuscript scenes, previously saved JSON files remain on disk as unindexed recovery artifacts; the authoritative worldbuilding index excludes them, so reopening does not restore them. This is not a secure erase feature.

Manual check: delete an entry with incoming links, cancel once, then confirm and verify `Missing entry`. Try deleting a template with only archived entries (disabled). Delete those entries, delete the now-empty template, save, and reopen. Confirm removed records stay absent and remaining fields and reference rules are preserved.

### Scene references

Open **Worldbuilding → Link entry…** beside the scene title to search active worldbuilding entries and add them to the current scene. Click a linked entry to open its read-only details in the reference pane, or remove the association without deleting the entry. The pane lists **In this scene** before the general search. Existing links to archived entries remain readable; deleted entries are explicitly marked `Missing entry` and can be unlinked.

Entry details in Worldbuilding show **Appears in … scenes**, with chapter names and buttons that return to the scene. This list is derived from scene IDs, so renaming, reordering, or transferring scenes needs no duplicate backlink updates. Deletion confirmation includes affected scenes.

Persistence adds optional `entryIds` UUID arrays to scenes in `project.json`, the recovery draft, and the transaction journal. Missing arrays mean no links. Project schemaVersion remains 1 for this additive field; older app builds that reject unknown fields cannot open projects containing links. No manuscript Markdown or worldbuilding record formats change. Save commits associations like other project edits.

Manual check: associate two entries with a scene, follow one in the reference pane, visit the entry in Worldbuilding and return using its scene button. Move the scene to another chapter, save and reopen. Confirm associations and chapter labels persist. Archive or delete a linked entry and verify its status; remove the link and confirm the entry itself is unaffected.

### Manuscript workspace

The manuscript has one heading with the current chapter, editable scene title, **New scene**, and **Tools**. Formatting and undo/redo stay next to the writing area. Scene details groups scene ordering/transfers/deletion and chapter naming/ordering/deletion. Scene links are managed in the Worldbuilding consultation pane. It closes when selecting another scene; references are no longer mounted as a disclosure strip above every scene. The read-only world reference pane remains separate from these editing controls.

### Autosave and version history

Projects with a folder autosave after four seconds without an edit. The status bar reports autosaving, saved, or failure. Editing stays available during autosave: a completed save advances the disk revision while newer text, worldbuilding edits, and scene links remain dirty for the next save. Failure keeps changes in memory and the independent recovery draft; manual Save or a new edit allows another attempt. Project switching and manual saves are blocked while autosave is in flight.

The **Version history** toolbar button opens saved snapshots with dates, manuscript contents, templates and entry values. Restoring requires explicit confirmation, saves current unsaved edits first, and creates a new revision. The prior revision remains available. Restoring a snapshot from an earlier worldbuilding format promotes its records to the current format without downgrading the project. Disk revision conflicts prevent restoration.

Full project snapshots are stored in `.write-studio-history/r-<revision>.json`. Opening an older project captures its current version; subsequent saves stage a full snapshot before the transaction journal and authoritative files are written. The history list recovers pending transactions and excludes staged revisions newer than the committed revision. Existing identical snapshots keep their timestamps. History is local to the project, has no automatic pruning yet, and grows with saves; it is separate from migration backups and recovery drafts. It does not include external assets.

Manual check: type, pause four seconds and verify the Saved status. Open history, inspect a prior manuscript and worldbuilding entry, confirm restore and verify a new revision appears while the replaced version remains. Type during a slow save and verify the newer text survives the next autosave. Quit/reopen and confirm the restored version and scene links persist.

### Compact interface and manuscript inspector

The application header contains the project name (click to rename), project actions and general menu; Manuscript/Worldbuilding remain visible tabs. Tools is now a separate 310 px inspector, shown as an overlay at narrow widths. Chapter and scene rows expose contextual tools on hover or keyboard focus. Navigation width can be dragged at its separator or changed with Left/Right/Home/End while the separator has focus. Selection, editor document and writing scroll remain mounted while tools open.

Worldbuilding uses compact rows, a two-column layout for short entry fields, full-width long text/reference fields, linked-scene chips and adjacent template actions. Shared interaction styles distinguish focus, selection, hover and disabled states without movement on press; reduced motion is respected. The full project path is available on hover over the footer folder label.

UI validation includes SSR coverage of scene/chapter/reference inspector views, accessible resize control, deletion guards, read-only consultation, reference links, compact Worldbuilding navigation, and keyboard dropdown navigation. Visual native-window inspection is still required when no browser/desktop preview is connected.

### Recent projects

The welcome screen lists up to ten recently opened or created projects with direct opening, display names, short folder hints and last-opened dates. The full path is available on hover. Manual and automatic saves update renamed project titles. Recent project metadata lives in `recent-projects.json` in the app data directory, separately from project files and settings. Paths are canonicalized to avoid duplicates; project copies in distinct folders remain distinct.

Removing an item only edits this list, never the project or its history. Missing/moved folders produce an actionable error and remain listed until removed; Open project can locate a moved folder. Existing projects start appearing after their next successful open; the app does not scan folders for projects. A recent-list read/write failure does not cancel a successful project save/open.

### Global project search

Use the toolbar search button or Cmd+Shift+F (Ctrl+Shift+F) to search the current project, including unsaved changes. Literal phrases match without case or accent differences. Scene titles, chapter titles and plain scene text are searched; Markdown formatting does not interrupt a phrase. Entry titles, template titles, field labels/values and resolved reference titles are included. Archived entries and values are retained and labelled.

Results are grouped into Scenes and Entries with a matching context snippet. Choose a result to open its scene or entry; archived entry navigation reveals the correct archived view. Up/Down moves through results, Enter opens the focused result, Tab navigates controls, and Escape dismisses the dialog. Search only reads the in-memory project; it creates no files and changes no content or saved format.

### Manuscript export

Use **Export manuscript** in the toolbar to create a Word `.docx` or UTF-8 Markdown `.md` file from the current manuscript, including unsaved edits. Select all chapters or any subset; output always follows manuscript order. Scene headings are optional; omitting them inserts scene separators. Worldbuilding, scene links and project history are not exported.

DOCX preserves paragraphs (including empty paragraphs), bold/italic text, hard breaks and Unicode. It uses paragraph styles for the document title, chapters and scene headings, with Word outline levels for chapter/scene navigation. Presentation options include an optional title page with the project title and optional author, configurable page breaks between chapters, Georgia/Times New Roman/Arial, 11/12/14 pt, single/1.5/double line spacing, A4/Letter and 2/2.54/3 cm margins. A title page always separates from the first exported chapter, even when chapter page breaks are disabled. Without a title page, the document retains its inline project title. Its OOXML package layout follows [Microsoft's package documentation](https://learn.microsoft.com/en-us/office/open-xml/general/how-to-create-a-package). Markdown preserves the canonical scene text and adds escaped project/chapter/scene headings.

The native Save dialog chooses the destination. Cancel creates no file. Existing files are never overwritten; choose a new filename if the destination exists. Export does not save, replace or alter the active project. File write failures report an error and remove partial newly created output where possible.

Format, scene-heading and presentation preferences are remembered per project on this computer in `manuscriptExportPreferences.ts`, with versioned validation and a session fallback if local storage is unavailable. Only enumerated layout settings are stored; author names, project titles, chapter selections and manuscript text are excluded. The author is a dialog draft and appears only on a Word title page. Restoring defaults resets the layout without changing manuscript data or the chapter selection. Markdown ignores all Word-only layout options.

Automated checks validate the DOCX ZIP CRCs, XML parts, style relationship, Unicode and XML escaping, empty paragraphs, bold+italic runs, title-page separation, optional author, line/chapter breaks, paper/margin/font settings, chapter selection/order, unchanged Markdown, preference validation/privacy and immutable source data. Dialog checks cover option changes, busy/error states and duplicate-save guards. Native file pickers and Word/Pages rendering have not been verified in this environment.

Recent projects also appear in the application menu next to New project and Open project. Opening a recent project from an active project uses the existing unsaved-changes confirmation and preserves the chosen destination through Save/Discard. Recovery registers the recovered project path. The welcome screen always displays the Recent projects section, including a clear empty state.

### Consultation and save feedback

Selecting a world reference replaces the browser with its read-only detail, positioned at the top. **All references** returns to the list and keeps its search/filter; linked entries offer **Previous entry** navigation. The manuscript editor remains mounted. Scene reorder/transfer shows a dismissible destination confirmation for six seconds.

The footer shows a short primary save state (Saved, Unsaved changes, Saving…, Couldn’t save). Expand it for recovery-copy information and error details; Escape or an outside click dismisses that information. Recovery failures also keep a visible warning. These interface changes do not alter project schemas, autosave timing or storage formats.

### Project and scene action hierarchy

The project-name menu contains Rename, Save, Export, Version history and Close. Search and settings remain general controls; the manuscript heading exposes Scene details (or Chapter details) and Worldbuilding. Cmd+S/Ctrl+S uses the existing guarded manual-save flow. The world pane combines read-only entry consultation with linking/unlinking to the current scene; unlinking never deletes the entry. Secondary entry archive/delete actions live in an explicitly labelled menu, while Edit template sits beside the template name.

Opening an inspector no longer changes the navigation's visible/hidden preference. Side panels overlay at constrained widths and only one secondary panel is active. Selecting a chapter shows its scene list rather than silently selecting its first scene. Contextual chapter controls operate on that chapter. The New project dialog exposes the generated folder as a summary with an optional Change folder name control. Entry-reference dropdowns contain their search input; Tab dismisses without committing an option traversed with arrow keys.

### Chapter and scene synopses

Scene details and Chapter details contain separate plain-text synopsis fields. Selecting a chapter shows its synopsis and the synopses of its scenes in manuscript order. Empty synopses add no placeholder blocks to the overview. Global search includes synopsis text, marks its source, and opens the relevant inspector when a synopsis matches. Chapters (including empty planned chapters) also have their own result group.

Optional `synopsis` strings are stored on scene/chapter metadata in `project.json`, recovery drafts, transaction journals and full history snapshots. Old projects with no synopsis fields load unchanged. Project schemaVersion remains 1 for this additive field; older builds rejecting unknown fields cannot open projects with synopses. Reordering or transferring scenes keeps the synopsis with the scene. Clearing the text persists an empty synopsis. Synopses never enter the scene Markdown files or DOCX/Markdown manuscript exports.

Checks cover old-file compatibility, Unicode/multiline roundtrips, draft/journal recovery, history restore, overview/inspector rendering, search results, synopsis preservation on scene transfer, and exclusion from both export formats.

### Scene writing status

Scene details includes **Writing status**: Not started, Draft, In review and Finished. Navigation uses distinct icons with accessible names/tooltips; chapter overviews and history previews show the text label too. Writing status is independent of file-save/recovery status, and changing it uses the same autosave and recovery flow as other scene metadata.

Scenes without an explicitly chosen status display Not started when their text is empty and Draft when they contain text. This covers old files and new scenes without rewriting them. Once the user chooses a status, editing or clearing the text never changes it automatically. Reordering and moving scenes keep their chosen status.

The optional scene `writingStatus` field uses `notStarted`, `draft`, `inReview` or `finished`; Rust rejects unsupported values. It is stored in project metadata, recovery snapshots, transaction journals and history, and is excluded from manuscript Markdown and DOCX exports. Project schemaVersion stays 1 for the additive field; older builds that reject unknown fields cannot open projects with an explicit writingStatus.

Checks cover default/explicit statuses, reordering/transfers, rendering/accessibility, unchanged scene content, all four states through save/reopen, recovery/history, invalid values and export exclusion.

Writing-status colours use neutral grey (Not started), slate blue (Draft), muted amber (In review) and teal (Finished), with separate light/dark theme tokens. Full labels have subdued backgrounds; compact navigation indicators colour only the icon. Distinct icons, visible labels in overviews, and accessible names remain in place. Foreground/background label contrast was checked for all eight theme/state combinations (minimum measured ratio 5.25:1). No project data changes are required for this styling.

### Timeline

The Timeline project tab stores story events independently of chapter/scene reading order. Each event has a title, notes, a free time label, optional structured start/end dates, and links to scenes and worldbuilding entries. For example, a label such as Before the war can stand alone or accompany a structured date. Dates accept signed year, year-MM or year-MM-DD, including year 0. Calendar month/day validation uses proleptic Gregorian leap-year rules; use labels/manual ordering for other calendars. No times or timezones are inferred.

By date sorts dated events first, using the earliest day of an incomplete start date; equal dates retain their manual order. Undated events stay at the end in manual order. Manual order exposes accessible up/down controls; reordering is disabled while filtering. Sorting/reordering events never changes manuscript order. Free labels are not automatically interpreted as dates.

Titles, notes, labels and links use the existing autosave/recovery flow. Structured dates use an explicit **Apply dates** action, with pending-date and validation messages; apply them before leaving the event. End dates require a start, and their latest possible day must not precede the earliest possible start day, allowing incomplete periods. Event deletion asks for confirmation and preserves linked records. Deleted scene/entry links remain explicit Missing scene/Missing entry values and can be unlinked; deletion warnings identify the effect on events.

An optional `timeline` object (schemaVersion 1) is embedded in project metadata alongside chapters. Old projects load without it. Events have globally unique UUIDs; date ranges, duplicate link IDs and schema versions are validated before saves. Missing link targets are permitted for recovery/review. Project schemaVersion remains 1 for this additive field; earlier builds rejecting unknown fields cannot open projects with timeline data. Full history snapshots and drafts include events, and restoring a pre-timeline snapshot removes them from the active version while keeping later history available. No separate timeline folder is created. Manuscript exports exclude timeline events.

Global search groups event results separately and opens the selected event. History previews include event notes and dates. Tests cover negative/partial dates, leap years, period validation, stable sorting/manual ordering, free labels, search, persistence/recovery/history, missing links, global UUID collisions and export exclusion. Native visual acceptance remains to be checked on the user's Mac.

### Visual timeline

Timeline has **List** and **Visual** modes, sharing search and selected event. The visual view draws exact-date events as points, explicit periods as intervals, and incomplete dates as dashed possible calendar ranges. Undated events stay in a separate section; free time labels never acquire an invented calendar position. Each dated event has its own labelled row so simultaneous events/periods remain separately selectable.

Zoom in/out explores the current range with horizontal scrolling; **Fit all** restores the full dated extent, and **Focus selected** narrows the range around the selected dated event. Calendar ticks adapt to the visible scale. The axis uses integer proleptic Gregorian day coordinates, including negative years, year 0, leap years and the supported extreme years, without JavaScript Date/timezone conversions. Month/year-only dates span their earliest/latest possible days and are labelled as partial rather than exact durations.

Clicking or keyboard-activating a graphical event opens the existing details; in narrow windows the detail follows the chart and scrolls into view. The scroll region is focusable, all plotted/undated events are buttons with date-aware accessible names, and keyboard focus reveals off-screen markers. This is a read-only visualization of the existing data: there is no date drag-and-drop, and neither list ordering nor manuscript structure changes. No persistence formats or dependencies were added.

Checks cover day coordinates against independent UTC calendar calculations, negative/extreme-year roundtrips, leap/month boundaries, interval/partial-date classification, finite extents for single points, scale ticks, focused domains, empty and undated cases, selected-state/accessibility markup, and unchanged source events. Native visual review remains pending where desktop inspection is unavailable.

### Entry images (Worldbuilding schemaVersion 4)

Each entry has an optional main image, independent of its template fields. In Worldbuilding → Entries, use **Add image**, **Change image** or **Remove image**. Clicking the portrait opens a larger view; Escape or Close dismisses it. The manuscript reference pane also shows the image read-only, and entry lists use thumbnails.

Import accepts PNG, JPEG and WebP files up to 20 MB and 40 megapixels. The app creates a static PNG copy with a maximum side of 2048 px and a thumbnail with a maximum side of 256 px, preserving aspect ratio and transparency. The source file is not modified; the project keeps the optimized copy rather than a full-resolution archival original. Import uses the app's operation lock so opening, closing or restoring a project cannot race an attachment.

Files live in `assets/images/<image-id>/image.png` and `thumbnail.png`, while entries store only `imageId`. Thumbnail reads are lazy, cached in a bounded 48-item cache, and object URLs are released when thumbnails leave the visible area or views unmount. Full images load only when expanded. Moving the complete project folder preserves the images. No external image URLs or machine-specific source paths are stored.

Adding the first image promotes worldbuilding records to schemaVersion 4 and uses the existing pre-upgrade backup protocol. Existing projects without images remain unchanged. Replacing/removing an image or deleting an entry does not delete its asset files: history and recovery drafts may still need them. History snapshots store identifiers rather than duplicating image bytes. Keep the `assets` folder with the rest of the project when copying or backing it up. Missing/damaged assets are shown as unavailable and can be replaced or removed explicitly; they do not prevent opening the project's text.

Automated tests cover asset persistence after source removal, replacement/removal, history and draft recovery, moving the project folder, schema validation, invalid/corrupt images, path restrictions, overwrite protection, thumbnail dimensions and cancelled imports. Native file-picker, canvas decoding and visual acceptance still require a running desktop-app check.

### Complete project backups

Use **Project actions → Create backup…** to create a dated ZIP. Any pending edits are saved first; cancelling the ZIP save dialog leaves those edits saved. The native dialog proposes `<project>-backup-YYYY-MM-DD-HHMMSS.zip` using local time. Choose a location outside the project; existing ZIPs are never overwritten.

The ZIP includes `project.json`, `manuscript/`, `worldbuilding/`, `assets/`, `.write-studio-history/` and `.write-studio-backups/` when present. It includes unused/deleted-record recovery files inside those folders and retained images needed by historical versions. It excludes unrelated files in the project root, transient transaction journals, app-wide preferences and app-data recovery drafts. The current snapshot includes the latest saved edits, so a separate recovery draft is not needed in the ZIP.

A versioned `.write-studio-backup.json` manifest lists the project identity/revision and every file's size and modification time. Before publishing the ZIP, Write Studio reads every archived file back, checks ZIP integrity, and reopens an extracted verification copy including its history and referenced images. A missing/damaged historical image or invalid history file causes an explicit error instead of presenting an incomplete backup as successful. Verification temporarily needs additional free space beside the ZIP.

Use **Restore backup…** in Application options, or **Restore a backup** on the welcome screen. Choose a Write Studio ZIP and a parent folder (the default projects folder is suggested when configured). Restore validates paths, duplicates, file types, manifest contents and checksums, then creates a uniquely named `<project>-restored-…` directory. It opens that new project and registers it in recent projects. Current projects and existing folders are never overwritten; unsaved current edits use the usual Save/Discard/Cancel prompt before restoration. Cancelling either native picker keeps the current project open.

Restoration preserves history contents and file modification times. Unsupported, encrypted, linked, incomplete or damaged ZIPs are rejected. Resource limits are 100,000 project files, 256 MB per file and 4 GB uncompressed total. Backup ZIPs are not encrypted. Automated tests cover full round trips with images/history/timeline, independent Python ZIP validation, source preservation, repeated restores, no overwrite, missing assets, corrupted/truncated ZIPs, unsafe paths, duplicate names and symbolic links. Native save/open-folder dialogs and visual acceptance remain a desktop-app check.

### Focus writing mode

Select a manuscript scene and click **Focus**, or press **⌘⇧Enter / Ctrl+Shift+Enter**. This hides the application header, module tabs, manuscript navigation, formatting toolbar and secondary panels. The same Tiptap editor remains mounted with its selection and undo history, and the previous sidebar width, collapsed chapters and panel states are kept. **Exit focus**, the shortcut again, or **Escape** restores the normal workspace. Leaving the manuscript, selecting a chapter overview, or opening another project ends focus mode.

The focus bar's **Appearance** panel offers narrow/medium/wide text widths, serif/sans type, 16–28 px font size and 1.4–2.2 line spacing. Preferences are saved locally as `write-studio.focus-preferences`; they apply only in focus mode and do not change manuscript content, project files or exported formatting. Invalid preferences fall back to bounded defaults. Focus mode itself is not restored automatically on app launch.

A quiet scene word count and the normal save/recovery status remain visible. Bold/italic, undo and manual save keyboard shortcuts continue working. Escape closes appearance settings or a modal before exiting focus; focus toggling is blocked during modal/project operations and ignores IME composition and repeated key presses. Hidden panels are inert, preventing menus from remaining active over the focus view.

Automated checks cover preference round trips, invalid values, supported ranges, style scoping, shortcut matching and the accessible focus-bar controls. Native acceptance should verify editor selection/undo after entering/exiting, saved panel layout, appearance controls in both themes, and typing/autosave in a desktop session.

### Project and session writing goals

Open **Writing goals** from the manuscript toolbar, **Goals** in focus mode, or **Project actions → Writing goals…**. Set an optional total manuscript target and a session target. **Save goals** applies changes; **Start session** saves the targets, records the manuscript word count and returns to writing. Targets accept positive whole numbers up to 10,000,000. Clear a target to remove it; end an active session before clearing its session goal.

The project goal measures the current word count across all manuscript scenes. A session measures the net difference from its starting manuscript word count, across scene/chapter changes. Deleting text or a scene reduces progress, undo restores it, and a session may finish with negative net words. Formatting syntax, titles, synopses, worldbuilding and timeline notes do not count. The same whitespace-based word definition is used by the editor and goals. Counts are cached per scene so only changed scene text is parsed while typing.

An active session stays with the project across saves, app restarts and project switches until **End session** is chosen. Changing its target does not reset its starting count. Ending records its result and completion time; the goals panel shows the five most recently completed sessions while retaining the full history. A new session starts from the manuscript's current count. Reaching a target marks it complete visually without stopping writing or showing a modal.

Goals and sessions use optional `writingGoals` metadata (own schemaVersion 1) in `project.json`. Existing projects need no migration or default target. Metadata is included in autosave, recovery drafts, journal recovery, full version history and complete ZIP backups, and excluded from manuscript exports. Restoring a historical project revision also restores its goal/session state. Appearance preferences remain separate local settings.

Automated checks cover canonical word counts, scene moves/deletion, negative progress, target limits, immutable session state, repeated sessions, clock rollback, persistence/recovery/backup/history and progress controls. Native acceptance should verify starting a session, writing in several scenes, deleting/undoing text, changing targets, ending a session, and resuming after reopening a project.

Project deletion is available from **Project actions → Delete project…** and each recent project's options menu. The dialog displays the full folder path and requires the exact project name (case and spacing included). It moves the entire folder, including images and local version history, to the system Trash; it never permanently erases it. Unsaved changes in the open project are saved before confirmation. Cancelling keeps the project. Removing a card from recent projects remains a separate action that keeps its files. To reopen a deleted project, restore its folder from the system Trash and choose Open project.

### Maps linked to worldbuilding

The **Maps** workspace supports multiple imported maps per project (worlds, regions, cities or interiors). Choose **New map** and select a PNG, JPEG or WebP up to 20 MB / 40 megapixels. The existing local image pipeline stores an immutable PNG copy (long edge up to 2048 px) and thumbnail in `assets/images/<image UUID>/`; the original file is never modified and is no longer needed. Only the selected map image is loaded, and its object URL is released when leaving the view.

Choose **Add marker**, then click the image, or use **Add at center** for keyboard access. Marker details provide a name, notes, icon, color, optional worldbuilding link, and numeric horizontal/vertical percentages. **Reposition selected marker** moves it on the next image click. The canvas offers zoom, fit, focus selected marker, drag panning and scroll navigation. Positions are normalized to the image, independent of zoom/window size. **Replace image…** preserves these relative positions; check their geographic meaning after changing the artwork.

**Open entry** navigates from a marker to its worldbuilding entry. Each entry lists **Map locations** that return to the corresponding map and selected marker, including archived entries. Deleted entries leave explicit missing links on markers until replaced or cleared. Deleting a marker/map asks for confirmation and keeps linked entries and image assets for prior versions.

Map metadata is optional, versioned project data in `project.json` (`maps.schemaVersion: 1`). It participates in manual save, autosave, crash recovery, history and ZIP backup/restore; it is excluded from manuscript exports. Backup validation requires assets referenced by both current and historical maps. Existing projects need no migration. Automated tests cover normalized coordinates at different scales/scroll offsets, bounds, backlinks/missing links, immutable image replacement, invalid metadata, save/recovery/history and backups with map images. Native visual/interaction acceptance remains a desktop-app check.

### Picklist fields and interface language

Templates offer **Picklist** (one choice) and **Multi-picklist** (several choices). When adding a field, enter its options one per line. Option names must be nonempty and unique, ignoring case. Edit option labels in the template; selections use stable UUIDs, so renaming an option does not lose values. Archive options to prevent new selections while retaining existing values, or restore them later. Single choices can be cleared with **None**; multiple choices appear as removable chips. Entry search, global search and the read-only world reference show option labels rather than UUIDs. Adding these field types upgrades worldbuilding metadata to schemaVersion 5, with the existing backup-before-upgrade mechanism. Manual save, autosave, recovery, version history and portable backups preserve options and selections.

Use **Settings → Language → Español / English** to change the application interface immediately. The preference is stored locally as `write-studio.language`, alongside the local appearance preferences. Language changes rerender the current application without remounting its project/editor. Manuscript text, project names, template/field/entry names, map labels and user-defined picklist options keep their original content. Interface messages live in `src/locales/es.json`; the English source strings are the fallback. Dates and number formatting follow the selected language. Native operating-system controls and low-level system errors follow the OS language. No translation service or network request is used.

### Reusing templates across projects

In **Worldbuilding → Templates**, use **Import / export → Import or copy templates…**. Choose a template JSON file, a local Write Studio project folder, or a recent project. Copying from a project reads its saved template definitions without opening, recovering or writing to that project; save changes there first. A pending save or detected source change stops the copy so you can retry safely.

The preview lets you choose templates, inspect their fields/options and adjust their names before importing. Restricted reference fields automatically include their required templates, including circular/self references. Every imported template, field and picklist option receives a fresh ID; restrictions point to the corresponding imported copies. Existing destination templates/entries are retained. Conflicting names get a suggested copy suffix; explicit empty/duplicate names must be corrected. Missing reference targets remain explicitly missing, with a preview warning; they never silently bind to an unrelated existing template.

**Export template…** exports the selected template and dependencies. **Import / export → Export all templates…** exports the whole collection. Portable files use `.write-templates.json` and a versioned `write-studio-templates` format. They contain template definitions, archived fields/options and reference rules, with no entries, writing or images. Files are validated and limited to 2 MB / 1,000 templates. Exports create new files and never overwrite an existing file. Imports update the current project through the normal edit/autosave/recovery/history flow. Importing and exporting both support English and Spanish.

Automated tests cover portable file round trips, source preservation, pending saves, malformed/oversized/unsupported files, dependency cycles, ID/reference remapping, archived fields/options, name collisions, repeated imports, missing targets and bilingual source controls. Native file/folder dialogs and the interactive preview still require a desktop acceptance check.

Template field editing uses a compact single-column list with independent row heights, a drag handle, field name, type badge and adjacent edit/archive/delete actions. Edit expands that row's name and reference/picklist settings. Reference review warnings remain visible while collapsed. **Add field** opens a centered dialog with autofocus, a custom type dropdown, conditional reference/options controls, **Cancel** and **Save field**. Cancelling changes nothing; saving uses the existing field creation/schema upgrade flow. Dropdown menus inside native dialogs are portalled into the dialog so they remain interactive in its top layer. Escape dismisses a dropdown before the dialog, and focus returns to the source control. Field deletion asks for confirmation and is allowed only when no entry (including archived entries) has a stored value for that field; otherwise archive it to keep values. The template deletion area is separated below the list by a divider.

### Structured dates and ages in the story

Choose **World → Configure → Templates → Add field → Date**. Date values accept a year, year-month or full date (for example `120`, `120-06`, `120-06-15`, `-4-02-29`). They use the same proleptic Gregorian calendar and astronomical year numbering as the timeline, including year 0. Type a value and apply it with **Apply date**, Enter or leaving the field; invalid input shows an error and keeps the previously stored value. Clearing the value removes the date. Dates display consistently in entry editing, read-only world references and search.

Mark one Date field per template as **Use as birth date for age calculations**, either while creating it or in the field's edit panel. Selecting another replaces the role while preserving all values. Archived date fields retain their data but do not drive age calculations until restored. This optional role is suitable for people, creatures or any kind of entry that needs an age; entries without a configured birth field do not get age badges.

Linked entries display their calculated ages in timeline list rows, visual chart labels and event details. Calculations use the event's structured start/end dates, never the computer's current date or a free-form time label. Full dates give completed years; periods can give an age range. Partial dates show approximate bounds such as `≈ 23–24 years`. Events entirely before birth show **Not born yet**; a known birth within a period is distinguished from overlapping uncertain birth/event ranges. Missing dates show **Age unknown**. For February 29 birthdays, the completed year advances on March 1 in non-leap years. An entry's **Age at a story date** panel also supports a temporary reference date without changing project data.

Worldbuilding schemaVersion 6 adds Date values (`{year, month?, day?}`) and the optional field role `isBirthDate`. Ages are derived, never stored. Existing schema versions remain readable; adding a Date upgrades through the normal pre-migration backup flow. Dates and birth roles are included in save, autosave, recovery, history, portable project backups and template import/export. Changing dates or reference roles recalculates ages automatically. Automated tests cover exact birthdays, leap years, negative/year-zero dates, partial bounds, birth-overlapping periods, invalid metadata, role uniqueness, persistence/recovery/history, ZIP/template round trips and English/Spanish presentation. Desktop visual acceptance remains pending.


## Worldbuilding field sections

In **World → Configure → Templates → Sections**, create, rename and reorder one-level groups such as Basic information, Appearance and History. Assign a section when adding a field, change it in the field settings, or drag a field onto another group heading. Existing fields remain in **No section**. Deleting a section moves its fields there without deleting values, references or birth-date roles.

Entry editing and the manuscript's read-only reference panel display collapsible section headings, preserving the template order. The entry title and images stay outside these groups. Template import/export and project copying retain section names/order while generating fresh section IDs. Schema version 7 stores optional template sections and field membership; older projects remain readable and upgrade through the normal backup flow when sections are added. Automated coverage includes grouping, moves, deletion, age preservation, save/recovery/history and portable template/project round trips.


## Find and replace in the manuscript

Use **Review tools → Find and replace** or **Cmd+F / Ctrl+F** in the manuscript. **Cmd+Shift+F / Ctrl+Shift+F** retains the global project search. Choose the current scene, chapter or entire manuscript, with optional case sensitivity and whole-word matching. Search uses literal visible text, including text across bold/italic boundaries; Markdown syntax and planning metadata are excluded. Find and replacement fields accept a single line.

Previous/next controls and Enter/Shift+Enter navigate contextual previews. **Open fragment** closes the dialog and selects the exact occurrence in the scene. Replace the current match or all matches in the selected scope; the total is visible before applying. An empty replacement deletes matching text. Changes use normal project autosave/recovery and editor transactions, retaining formatting and remapping comments and mention decisions. Undo is per scene, including replacements made while that scene was not open; there is no project-wide replacement undo. History is session-only and bounded to 60 scenes.


## Review follow-up

Opening a comment, scene pending item or continuity warning from Pending, chapter planning, writing context, the comments panel or Continuity review starts a compact follow-up beside the workspace. It keeps the active issue visible while editing text, entries, events or routes. **Return** restores the source view, filters, grouping, expanded pending cards and scroll position against the latest project data. If a source row has disappeared after correction, keyboard focus returns to the source view or its filters. Deleted source views fall back to Pending.

Comments can be resolved directly from the follow-up. Continuity warnings are checked again against current data: a corrected warning displays **Warning no longer detected**; **Dismiss as intentional** retains the existing evidence-based local dismissal rules. Editing relevant evidence brings the warning back. Follow-up uses contextual anchors for text warnings, so moving text does not switch to another identical mention. Changed/ambiguous fragments and deleted sources remain explicit. The follow-up and its origin are session-only view state, never manuscript snapshots; returning does not revert edits. Focus mode hides the follow-up until focus mode is exited.
