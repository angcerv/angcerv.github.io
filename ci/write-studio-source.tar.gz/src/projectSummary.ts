import type {Project} from './model';
import {getSceneStatus} from './model';
import {countSceneWords} from './writingGoals';
export function projectSummary(project:Project){
 const scenes=project.chapters.flatMap(chapter=>chapter.scenes);
 return {books:project.books?.length??0,chapters:project.chapters.length,scenes:scenes.length,words:scenes.reduce((sum,scene)=>sum+countSceneWords(scene.content),0),entries:project.worldbuilding?.entries.filter(entry=>!entry.archived).length??0,comments:scenes.reduce((sum,scene)=>sum+(scene.reviewComments?.filter(comment=>!comment.resolved).length??0),0),reviewScenes:scenes.filter(scene=>getSceneStatus(scene)==='inReview').length,decisions:project.worldIdeas?.filter(idea=>idea.status==='decided').length??0};
}
