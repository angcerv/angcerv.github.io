import Dropdown from './Dropdown';
import { t } from './i18n';
import type { WorldMap } from './maps';
export default function MapLayerSelect({map,id,value,onChange}:{map:WorldMap;id:string;value?:string;onChange:(layerId:string|undefined)=>void}){
 return <><label htmlFor={id}>{t('Layer')}</label><Dropdown id={id} aria-label={t('Layer')} value={value??''} onChange={value=>onChange(value||undefined)} options={[{value:'',label:t('No layer')},...(map.layers??[]).map(layer=>({value:layer.id,label:(layer.title||t('Untitled layer'))+(layer.visible?'':t(' · Hidden'))+(layer.locked?t(' · Locked'):''),disabled:layer.locked}))]}/></>;
}
