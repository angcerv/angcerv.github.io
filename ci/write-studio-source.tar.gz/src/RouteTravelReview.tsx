import FieldHelp from './FieldHelp';
import StoryDateInput from './StoryDateInput';
import { reviewRouteTravel, travelReviewText } from './travelContinuity';
import { t } from './i18n';
import type { MapRoute, WorldMap } from './maps';
export default function RouteTravelReview({map,route,onChange}:{map:WorldMap;route:MapRoute;onChange:(patch:Partial<MapRoute>)=>void}){
 const result=reviewRouteTravel(map,route);
 return <section className="route-travel-review"><h3>{t('Travel continuity')}<FieldHelp label={t('Travel continuity')} description={t('Set the map scale and travel pace to check journey durations.')+' '+t('Uses elapsed days between dates. Partial dates only warn when every possible interval is too short. Estimates exclude terrain, detours and rest.')}/></h3><label htmlFor="route-departure">{t('Departure (optional)')}</label><StoryDateInput compact id="route-departure" value={route.departure} onChange={date=>onChange({departure:date??undefined})}/><label htmlFor="route-arrival">{t('Arrival (optional)')}</label><StoryDateInput compact id="route-arrival" value={route.arrival} onChange={date=>onChange({arrival:date??undefined})}/>
 {result&&<p className={result.kind==='fits'?'world-hint':'travel-warning'} role="status">{travelReviewText(result)}</p>}
</section>;
}
