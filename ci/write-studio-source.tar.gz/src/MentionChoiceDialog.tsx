import {focusDialog} from './dialogFocus';
import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import {X} from 'lucide-react';
import { t } from './i18n';
import type { Worldbuilding } from './worldbuilding';
export default function MentionChoiceDialog({world,ids,label,onChoose,onClose}:{world:Worldbuilding;ids:string[];label:string;onChoose:(id:string)=>void;onClose:()=>void}){
 const dialog=useRef<HTMLDialogElement>(null),previous=useRef(typeof document==='undefined'?null:document.activeElement as HTMLElement|null);
 useEffect(()=>{const node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous.current?.isConnected)previous.current.focus();};},[]);
 const entries=ids.flatMap(id=>{const entry=world.entries.find(entry=>entry.id===id);return entry&&!entry.archived?[entry]:[];});
 const content=<dialog ref={dialog} className="field-create-dialog" aria-labelledby="mention-choice-title" onCancel={event=>{event.preventDefault();onClose();}}><header className="ui-dialog-heading"><h2 id="mention-choice-title">{t('Choose an entry for “{0}”',label)}</h2><button type="button" className="icon-button ui-close-button" aria-label={t('Close')} title={t('Close')} onClick={onClose}><X size={18} aria-hidden="true"/></button></header><div className="field-create-body mention-choice-list"><p className="world-hint">{t('Your choice is saved for this occurrence only.')}</p>{entries.map(entry=><button type="button" key={entry.id} onClick={()=>onChoose(entry.id)}>{entry.title||t('Untitled entry')}<small>{world.templates.find(template=>template.id===entry.templateId)?.title||t('Untitled template')}</small></button>)}{!entries.length&&<p className="ui-empty-state ui-empty-state-compact">{t('No entries available for this mention.')}</p>}</div><footer><button type="button" onClick={onClose} className="quick-action quick-action-text">{t('Cancel')}</button></footer></dialog>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}
