import {focusDialog} from './dialogFocus';
import {t,buttonLabel} from './i18n';
import { useEffect, useRef } from 'react';
import { Trash2, X } from 'lucide-react';
export default function ManuscriptDeletionDialog({kind,title,hasTimelineLinks,onCancel,onConfirm}: {kind:'scene'|'chapter';title:string;hasTimelineLinks:boolean;onCancel:()=>void;onConfirm:()=>void}) {
 const ref=useRef<HTMLDialogElement>(null);
 useEffect(()=>{const dialog=ref.current;dialog?.showModal();focusDialog(dialog);return()=>dialog?.close();},[]);
 return <dialog ref={ref} className="manuscript-deletion-dialog" aria-labelledby="manuscript-delete-title" aria-describedby="manuscript-delete-description" onCancel={event=>{event.preventDefault();onCancel();}}>
  <button type="button" className="icon-button ui-close-button manuscript-delete-close" title={t("Cancel")} aria-label={t("Cancel")} onClick={onCancel}><X size={18}/></button><div className="manuscript-delete-icon"><Trash2 size={20}/></div><h2 id="manuscript-delete-title">{t(kind==='scene'?"Delete scene":"Delete chapter")}?</h2>
  <p id="manuscript-delete-description">{t("Delete “")}{title}”{kind==='chapter' ? t(' and all its scenes') : ''}{t("? This cannot be undone in the editor.")}</p>
  {hasTimelineLinks && <p className="world-hint">{t("Timeline events will keep these links as Missing scene.")}</p>}
  <div className="manuscript-dialog-actions"><button type="button" onClick={onCancel}>{t("Cancel")}</button><button type="button" className="danger-button" onClick={onConfirm}>{buttonLabel(kind==='scene'?"Delete scene":"Delete chapter")}</button></div>
 </dialog>;
}
