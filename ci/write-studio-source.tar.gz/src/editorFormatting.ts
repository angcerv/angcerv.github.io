import {Extension} from '@tiptap/core';
export type FormattingAction='bold'|'italic'|'underline'|'bulletList';
const formats={
 bold:{key:'b',command:'toggleBold',mark:'bold'},
 italic:{key:'i',command:'toggleItalic',mark:'italic'},
 underline:{key:'u',command:'toggleUnderline',mark:'underline'},
 bulletList:{key:'Shift-8',command:'toggleBulletList',mark:undefined},
} as const;
function macPlatform(){return typeof navigator!=='undefined'&&/Mac|iPhone|iPad|iPod/i.test(navigator.platform||navigator.userAgent);}
export function formattingShortcut(action:FormattingAction,mac=macPlatform()){
 const key=formats[action].key;
 return mac?`⌘${key.startsWith('Shift-')?'⇧':''}${key.slice(-1).toUpperCase()}`:`Ctrl+${key.startsWith('Shift-')?'Shift+':''}${key.slice(-1).toUpperCase()}`;
}
export function formattingAriaShortcut(action:FormattingAction,mac=macPlatform()){
 const key=formats[action].key.replace(/-/g,'+');return `${mac?'Meta':'Control'}+${key}`;
}
/** Local editor keymaps only; never enable a format that its document schema cannot retain. */
export const EditorFormattingShortcuts=Extension.create({
 name:'editorFormattingShortcuts',priority:1000,
 addKeyboardShortcuts(){
  const shortcuts:Record<string,()=>boolean>={};
  for(const format of Object.values(formats)){
   const run=()=>{
    if(!this.editor.isEditable)return false;
    if(format.mark?!this.editor.schema.marks[format.mark]:!this.editor.schema.nodes.bulletList)return false;
    return this.editor.commands[format.command]();
   };
   shortcuts[`Mod-${format.key}`]=run;
  }
  return shortcuts;
 },
});
