import {imageDimensions} from './entryImages';
import {t} from './i18n';
/** Optimize an export copy; stored images are never modified. */
export async function encyclopediaExportImage(blob:Blob,signal:AbortSignal):Promise<Blob>{
 signal.throwIfAborted();
 if(blob.size<=160*1024)return blob;
 const bitmap=await createImageBitmap(blob);
 try{
  signal.throwIfAborted();
  const size=imageDimensions(bitmap.width,bitmap.height,1600),canvas=document.createElement('canvas');
  canvas.width=size.width;canvas.height=size.height;
  const context=canvas.getContext('2d');if(!context)throw new Error(t('Image processing is unavailable.'));
  context.imageSmoothingQuality='high';context.drawImage(bitmap,0,0,size.width,size.height);
  const encoded=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(new Error(t('The image could not be prepared.'))),'image/webp',0.9));
  signal.throwIfAborted();
  // WebKit may fall back to PNG; use its real MIME type and retain the smaller copy.
  return encoded.size<blob.size?encoded:blob;
 }finally{bitmap.close();}
}
