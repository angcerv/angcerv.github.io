import { visibleChapterScene } from './chapterScroll';
import type { ReactNode, Ref } from 'react';
import { Plus } from 'lucide-react';
import { t } from './i18n';
import type { Chapter, Scene } from './model';
import SceneWritingStatus from './SceneWritingStatus';

export default function ChapterManuscript({chapter,activeSceneId,scrollRef,onActivate,onAddScene,renderScene}:{chapter:Chapter;activeSceneId?:string;scrollRef:Ref<HTMLDivElement>;onActivate:(sceneId:string)=>void;onAddScene:()=>void;renderScene:(scene:Scene)=>ReactNode}){
 return <div ref={scrollRef} className="writing-scroll chapter-manuscript-scroll" aria-label={t('Complete chapter text')} onScroll={event=>{
  const node=event.currentTarget,rect=node.getBoundingClientRect();
  const scenes=Array.from(node.querySelectorAll<HTMLElement>('[data-chapter-scene]')).map(element=>{const box=element.getBoundingClientRect();return {id:element.dataset.chapterScene!,top:box.top,bottom:box.bottom};});
  const id=visibleChapterScene(scenes,{top:rect.top,height:node.clientHeight,atEnd:node.scrollHeight>node.clientHeight&&node.scrollHeight-node.clientHeight-node.scrollTop<=2});
  if(id&&id!==activeSceneId)onActivate(id);
 }}><div className="writing-page chapter-manuscript">
  <header className="chapter-reading-heading"><h1>{chapter.title||t('Untitled chapter')}</h1><p>{t('{0} scenes',chapter.scenes.length)}</p></header>
  {chapter.scenes.map((scene,index)=><section key={scene.id} className={`chapter-manuscript-scene${scene.id===activeSceneId?' active':''}`} id={`chapter-scene-${scene.id}`} data-chapter-scene={scene.id} aria-label={scene.title||t('Untitled scene')} onFocusCapture={()=>onActivate(scene.id)}>
   <header className="chapter-scene-heading"><button type="button" onClick={()=>onActivate(scene.id)}><span>{t('Scene {0}',index+1)}</span><h2>{scene.title||t('Untitled scene')}</h2></button><SceneWritingStatus scene={scene} compact/></header>
   {renderScene(scene)}
  </section>)}
  <button type="button" className="chapter-add-scene" onClick={onAddScene}><Plus size={15}/>{t('New scene')}</button>
 </div></div>;
}
