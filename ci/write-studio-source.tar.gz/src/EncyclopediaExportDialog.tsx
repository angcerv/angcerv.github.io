import ExportSuccess from './ExportSuccess';
import {focusDialog} from './dialogFocus';
import {entryImageIds} from './visualResources';
import {useEffect,useMemo,useRef,useState} from 'react';
import {BookOpen,Download,LoaderCircle,X} from 'lucide-react';
import type {Project} from './model';
import {defaultEncyclopediaOptions,encyclopediaCategories,encyclopediaFilename,encyclopediaSelection,encyclopediaPackageImages} from './encyclopediaExport';
import type {EncyclopediaFormat} from './encyclopediaExport';
import {saveEncyclopediaPackage,saveTextExport} from './storage';
import {prepareEncyclopedia} from './encyclopediaExportJob';
import Dropdown from './Dropdown';
import {message,t,useLanguage,buttonLabel} from './i18n';
export default function EncyclopediaExportDialog({project,path,onClose,embedded=false,onBusyChange}:{embedded?:boolean;onBusyChange?:(busy:boolean)=>void;project:Project;path:string;onClose:()=>void}){
 const language=useLanguage(),dialog=useRef<HTMLDialogElement>(null),[format,setFormat]=useState<EncyclopediaFormat>('zip'),[options,setOptions]=useState(()=>defaultEncyclopediaOptions(project)),[busy,setBusy]=useState(false),[error,setError]=useState(''),[saved,setSaved]=useState(''),saving=useRef(false),statusFocus=useRef<HTMLDivElement>(null),closeButton=useRef<HTMLButtonElement>(null);
 const statusWasShown=useRef(false),preparation=useRef<AbortController|null>(null),[preparing,setPreparing]=useState(false);
 useEffect(()=>()=>preparation.current?.abort(),[]);
 const compact=busy||!!error||!!saved;
 const categories=encyclopediaCategories(project),available=encyclopediaSelection(project,{...options,templateIds:categories.map(category=>category.id)}),selection=useMemo(()=>encyclopediaSelection(project,options),[project,options,language]),count=selection.reduce((sum,category)=>sum+category.entries.length,0),imageCount=new Set(selection.flatMap(category=>category.entries).flatMap(entryImageIds)).size;
 useEffect(()=>{if(embedded)return;const previous=document.activeElement as HTMLElement|null;const node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous?.isConnected)previous.focus();};},[]);
 useEffect(()=>{
  if(busy){statusWasShown.current=true;statusFocus.current?.focus();}
  else if(saved||error){statusWasShown.current=true;closeButton.current?.focus();}
  else if(statusWasShown.current){statusWasShown.current=false;dialog.current?.querySelector<HTMLButtonElement>('#encyclopedia-format')?.focus();}
 },[busy,saved,error]);
 function change(patch:Partial<typeof options>){setOptions({...options,...patch});setSaved('');setError('');}
 async function save(){
  if(saving.current||!count)return;saving.current=true;setBusy(true);setError('');setSaved('');
  const controller=new AbortController();preparation.current=controller;setPreparing(true);
  try{
   const source=await prepareEncyclopedia(project,options,format,path,controller.signal);
   controller.signal.throwIfAborted();setPreparing(false);
   const filename=encyclopediaFilename(project.title,format);
   const destination=format==='zip'?await saveEncyclopediaPackage(filename,path,project.id,source,encyclopediaPackageImages(project,options).map(image=>image.id)):await saveTextExport(filename,format,source);
   if(destination)setSaved(destination);
  }catch(error){if(!controller.signal.aborted)setError(message(String(error)));}
  finally{preparation.current=null;saving.current=false;setPreparing(false);setBusy(false);}
 }
 const Surface=embedded?'section':'dialog';
 useEffect(()=>{onBusyChange?.(busy);},[busy,onBusyChange]);
 return <Surface ref={dialog} className={`export-dialog encyclopedia-export-dialog${compact?' encyclopedia-export-compact':''}`} aria-labelledby="encyclopedia-export-title" onCancel={event=>{event.preventDefault();if(!busy)onClose();}}>
  <header hidden={embedded} inert={embedded} className="encyclopedia-export-heading"><BookOpen size={22} aria-hidden="true"/><div><h2 id="encyclopedia-export-title">{t('Export encyclopedia')}</h2><p>{project.title}</p></div><button type="button" className="icon-button ui-close-button" aria-label={t('Close')} title={t('Close')} disabled={busy} onClick={onClose}><X size={18}/></button></header>
  {compact?<>
   <div className="encyclopedia-export-result" ref={statusFocus} tabIndex={-1} aria-busy={busy}>
    {busy?<div role="status"><LoaderCircle className="encyclopedia-export-spinner" size={32} aria-hidden="true"/><h3>{t('Exporting encyclopedia…')}</h3><p>{t('Preparing the document and saving your file.')}</p></div>:error?<div role="alert" className="prompt-error"><h3>{t('Could not export the encyclopedia')}</h3><p>{error}</p></div>:<ExportSuccess path={saved} hint={format==='zip'?t('Unzip the file and open index.html. Keep the images folder beside it.'):undefined}/>}
   </div>
   {busy&&preparing&&<footer className="encyclopedia-export-result-actions"><button type="button" className="quick-action quick-action-text" onClick={()=>preparation.current?.abort()}>{t('Cancel')}</button></footer>}
   {!busy&&<footer className="encyclopedia-export-result-actions">{error&&<button type="button" className="quick-action quick-action-text" onClick={()=>{setError('');setSaved('');}}>{t('Back to options')}</button>}<button ref={closeButton} type="button" className="primary-button" onClick={onClose}>{t('Close')}</button></footer>}
  </>:<><div className="encyclopedia-export-body"><p className="encyclopedia-export-intro">{t('Export your world entries with a linked index. Manuscript text and planning notes are not included.')}</p>
   <fieldset disabled={busy}><legend className="visually-hidden">{t('Encyclopedia export options')}</legend><label htmlFor="encyclopedia-format">{t('Format')}</label><Dropdown id="encyclopedia-format" value={format} options={[{value:'zip',label:t('ZIP · HTML with separate images (recommended)')},{value:'html',label:t('HTML · standalone encyclopedia')},{value:'md',label:t('Markdown · editable text')}]} onChange={value=>{setFormat(value as EncyclopediaFormat);setSaved('');setError('');}}/><p className="field-hint">{format==='zip'?t('An offline encyclopedia with index.html and a separate images folder, each image included only once. Unzip it before opening index.html.'):format==='html'?t('One offline document with internal links and embedded images. Open it in your browser to read it or print it as PDF.'):t('Includes headings, formatted text and internal links. Entry images are included in HTML and ZIP.')}</p>
    <div className="encyclopedia-export-sections"><section aria-labelledby="encyclopedia-categories-title"><div className="encyclopedia-categories-heading"><h3 id="encyclopedia-categories-title">{t('Entry categories')}</h3><div><button type="button" onClick={()=>change({templateIds:categories.map(category=>category.id)})}>{t('Select all')}</button><button type="button" onClick={()=>change({templateIds:[]})}>{t('Clear selection')}</button></div></div>
    <div className="encyclopedia-categories">{categories.map(category=><label key={category.id}><input type="checkbox" checked={options.templateIds.includes(category.id)} onChange={event=>change({templateIds:event.target.checked?[...options.templateIds,category.id]:options.templateIds.filter(id=>id!==category.id)})}/><span>{category.title}</span><small>{available.find(item=>item.id===category.id)?.entries.length??0}</small></label>)}{!categories.length&&<p>{t('No entry categories yet.')}</p>}</div>
    </section><section aria-labelledby="encyclopedia-content-title"><h3 id="encyclopedia-content-title">{t('Include in export')}</h3><div className="encyclopedia-export-toggles">{([{key:'archivedEntries',label:'Include archived entries'},{key:'archivedFields',label:'Include archived fields'},{key:'relations',label:'Include entry relationships'},{key:'backlinks',label:'Include references from other exported entries'},{key:'images',label:'Include entry images (HTML and ZIP)'}] as const).map(({key,label})=><label key={key}><input type="checkbox" checked={options[key]} disabled={key==='images'&&format==='md'} onChange={event=>change({[key]:event.target.checked})}/>{t(label)}</label>)}</div></section></div>
    <p className="encyclopedia-export-count" role="status">{t('{0} entries · {1} categories',count,selection.length)}{format!=='md'&&options.images?` · ${t('{0} entry images',imageCount)}`:''}</p>
    {!count&&<p className="ui-empty-state ui-empty-state-compact">{t('Select at least one category with entries to export.')}</p>}
    {format==='html'&&options.images&&<p className="field-hint">{t('Images are optimized for the exported document. Originals remain unchanged.')}</p>}
    <details className="encyclopedia-export-preview"><summary>{t('Preview the index')}</summary>{selection.map(category=><section key={category.id}><h4>{category.title}</h4><ul>{category.entries.map(entry=><li key={entry.id}>{entry.title||t('Untitled entry')}</li>)}</ul></section>)}</details>
   </fieldset>
  </div>
  <footer><span>{format==='zip'?'ZIP':format==='html'?'HTML':'Markdown'} · UTF-8</span><button type="button" className="primary-button" disabled={busy||!count} onClick={()=>void save()}><Download size={15} aria-hidden="true"/>{busy?buttonLabel('Exporting…'):buttonLabel('Export encyclopedia…')}</button></footer></>}
 </Surface>;
}
