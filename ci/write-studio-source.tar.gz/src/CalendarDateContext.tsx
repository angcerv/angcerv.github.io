import FieldHelp from './FieldHelp';
import {t} from './i18n';
import type {StoryDate,TimelineEvent} from './timeline';
import type {StoryCalendar} from './storyCalendar';
import {calendarDateContext,calendarWorldDateContext} from './storyCalendar';
function DateContext({date,calendar,label,worldDate=false}:{date:StoryDate;calendar:StoryCalendar;label?:string;worldDate?:boolean}){
 const context=worldDate?calendarWorldDateContext(date,calendar):calendarDateContext(date,calendar);if(!context.season&&!context.holidays.length)return null;
 return <div className="calendar-date-context">{label&&<strong>{label}</strong>}{context.season&&<p><span>{t('Season')}</span> {context.season.name}{context.season.description&&<FieldHelp label={t('About {0}',context.season.name)} description={context.season.description}/>}</p>}{context.holidays.map(holiday=><p key={holiday.name}><span>{t('Holiday')}</span> {holiday.name}{holiday.description&&<FieldHelp label={t('About {0}',holiday.name)} description={holiday.description}/>}</p>)}</div>;
}
export function CalendarEventContext({event,calendar}:{event:Pick<TimelineEvent,'start'|'end'>;calendar?:StoryCalendar}){
 if(!calendar||!event.start)return null;
 return <><DateContext date={event.start} calendar={calendar} label={event.end?t('At the start'):undefined}/>{event.end&&<DateContext date={event.end} calendar={calendar} label={t('At the end')}/>}</>;
}
export default function CalendarDateContext({date,calendar,worldDate=false}:{date:StoryDate;calendar:StoryCalendar;worldDate?:boolean}){return <DateContext date={date} calendar={calendar} worldDate={worldDate}/>;}
