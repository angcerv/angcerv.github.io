import { t } from './i18n';
import { Feather, FolderOpen, Plus, ArchiveRestore } from 'lucide-react';
import RecentProjects from './RecentProjects';
import type { ComponentProps } from 'react';
type Props=ComponentProps<typeof RecentProjects> & {onNew:()=>void;onBrowse:()=>void;onRestore?:()=>void};
export default function WelcomeScreen({onNew,onBrowse,onRestore,...recents}:Props) {
 return <div className="welcome-screen"><div className="welcome-container"><section className="welcome-hero" aria-labelledby="welcome-title"><div className="welcome-brand-mark"><Feather size={30} aria-hidden="true"/></div><div className="welcome-hero-copy"><p className="welcome-eyebrow">{t("YOUR WRITING SPACE")}</p><h1 id="welcome-title">{t("Welcome to Write Studio")}</h1><p>{t("Give your stories a place to grow.")}</p></div><div className="welcome-actions"><button type="button" className="project-launch-button welcome-new primary-button" onClick={onNew}><Plus size={17}/>{t("New project")}</button><button type="button" className="project-launch-button welcome-open quick-action quick-action-text" onClick={onBrowse}><FolderOpen size={17}/>{t("Open project")}</button></div>{onRestore && <button type="button" className="welcome-restore" onClick={onRestore}><ArchiveRestore size={14}/>{t("Restore a backup")}</button>}</section><RecentProjects {...recents}/></div></div>;
}
