import { t } from './i18n';
import { Feather, FolderOpen, Plus, ArchiveRestore, ArrowRight } from 'lucide-react';
import RecentProjects from './RecentProjects';
import type { ComponentProps } from 'react';
type Props=ComponentProps<typeof RecentProjects> & {onNew:()=>void;onBrowse:()=>void;onRestore?:()=>void};
export default function WelcomeScreen({onNew,onBrowse,onRestore,...recents}:Props) {
 const latest=!recents.loading&&!recents.error?recents.projects.reduce<(typeof recents.projects)[number]|undefined>((best,item)=>!best||item.lastOpened>best.lastOpened?item:best,undefined):undefined;
 const disabled=recents.disabled||!!recents.openingPath;
 return <div className="welcome-screen"><div className="welcome-container"><section className="welcome-hero" aria-labelledby="welcome-title"><div className="welcome-brand-mark"><Feather size={30} aria-hidden="true"/></div><div className="welcome-hero-copy"><h1 id="welcome-title">{t("Welcome to Write Studio")}</h1></div><div className="welcome-actions">{latest&&<button type="button" className="primary-button welcome-continue" disabled={disabled} onClick={()=>recents.onOpen(latest.path,latest.title)}><ArrowRight size={17}/><span>{t("Continue {0}",latest.title||t("Untitled project"))}</span></button>}<button type="button" disabled={disabled} className={`project-launch-button welcome-new ${latest?'quick-action quick-action-text':'primary-button'}`} onClick={onNew}><Plus size={17}/>{t("New project")}</button><button type="button" disabled={disabled} className="project-launch-button welcome-open quick-action quick-action-text" onClick={onBrowse}><FolderOpen size={17}/>{t("Open project")}</button></div>{onRestore && <button type="button" disabled={disabled} className="welcome-restore quick-action quick-action-text" onClick={onRestore}><ArchiveRestore size={14}/>{t("Restore a backup")}</button>}</section><RecentProjects {...recents}/></div></div>;
}
