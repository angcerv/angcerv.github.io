import {focusDialog} from './dialogFocus';
import {useEffect,useRef,useState} from 'react';
import type {ReactNode} from 'react';
import {createPortal} from 'react-dom';
import {X} from 'lucide-react';
import {t,buttonLabel} from './i18n';
export default function RelationDialog({title,onClose,children,dirty=false,className='',variant='form',headerActions}:{title:string;onClose:()=>void;children:ReactNode;dirty?:boolean;className?:string;variant?:'confirmation'|'list'|'form';headerActions?:ReactNode}){
 const [confirming,setConfirming]=useState(false);
 const cancelFocus=useRef<HTMLElement|null>(null);
 const requestClose=()=>{if(dirty){if(!confirming&&typeof document!=='undefined')cancelFocus.current=document.activeElement as HTMLElement|null;setConfirming(true);}else onClose();};
 const ref=useRef<HTMLDialogElement>(null);
 useEffect(()=>{const previous=document.activeElement as HTMLElement|null;ref.current?.showModal();focusDialog(ref.current,variant==='form');return()=>{ref.current?.close();if(previous?.isConnected)previous.focus();};},[]);
 useEffect(()=>{if(confirming)focusDialog(ref.current);else if(cancelFocus.current?.isConnected){cancelFocus.current.focus();cancelFocus.current=null;}},[confirming]);
 const content=<dialog ref={ref} className={`field-create-dialog entry-relation-dialog relation-dialog-${confirming?'confirmation':variant} ${className}${confirming?' is-confirming-discard':''}`} aria-labelledby="relationship-dialog-title" onClickCapture={event=>{if(dirty&&!confirming&&(event.target as Element).closest('[data-relation-cancel]')){event.preventDefault();event.stopPropagation();requestClose();}}} onCancel={event=>{event.preventDefault();if(confirming)setConfirming(false);else requestClose();}}><header><h2 id="relationship-dialog-title">{confirming?t('Discard unsaved changes?'):title}</h2>{!confirming&&headerActions}<button type="button" className="icon-button ui-close-button" aria-label={buttonLabel(confirming?'Continue editing':'Close')} onClick={()=>{if(confirming)setConfirming(false);else requestClose();}}><X size={18}/></button></header><div className="field-create-body" inert={confirming}>{children}</div>{confirming&&<section className="relation-discard-confirm" role="alertdialog" aria-label={t('Discard unsaved changes?')}><p>{t('Discard your unsaved edits?')}</p><div className="relation-connection-footer"><button type="button" onClick={()=>setConfirming(false)} className="quick-action quick-action-text">{t('Continue editing')}</button><button type="button" className="danger-button" onClick={onClose}>{t('Discard changes')}</button></div></section>}</dialog>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}
