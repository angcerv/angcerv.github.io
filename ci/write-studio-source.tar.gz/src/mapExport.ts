import {orderedMapElements} from './mapElementOrder';
import {markerLabelFont} from './mapMarkerLabels';
import {layoutMapLabels,regionLabelPoint} from './mapLabels';
import {visibleMapRegions} from './mapRegions';
import type {MapRegion} from './mapRegions';
import { drawingSvg } from './mapDrawing';
import { mapColors, markerLabel } from './maps';
import type { MapMarker, MapRoute, WorldMap } from './maps';
import type { Worldbuilding } from './worldbuilding';
import { t } from './i18n';

export function mapExportFilename(title:string) {
 return `${(title.trim()||t('World map')).replace(/[<>:"/\\|?*\u0000-\u001f]/g,'-').replace(/[. ]+$/,'').slice(0,120)||'map'}.png`;
}
export function exportRoutePoints(route:MapRoute,map:WorldMap,width:number,height:number) {
 const stops=route.markerIds.map(id=>map.markers.find(marker=>marker.id===id));
 return stops.some(stop=>!stop)?[]:stops.map(stop=>({x:stop!.x*width,y:stop!.y*height}));
}
async function svgImage(svg:string) {
 const url=URL.createObjectURL(new Blob([svg],{type:'image/svg+xml'}));
 try {const image=new Image();image.src=url;await image.decode();return image;} finally {URL.revokeObjectURL(url);}
}
/** Render the whole map at its original resolution, independently of editor zoom/pan. */
export async function renderMapPng(image:HTMLImageElement,map:WorldMap,world:Worldbuilding,markers:MapMarker[],routes:MapRoute[],labels:boolean,displayWidth:number,icons:Map<string,string>,regions:MapRegion[]=visibleMapRegions(map),regionLabels=labels):Promise<Uint8Array> {
 const width=image.naturalWidth,height=image.naturalHeight;
 if(!width||!height)throw new Error(t('The map image could not be displayed.'));
 const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
 const context=canvas.getContext('2d');if(!context)throw new Error(t('Image processing is unavailable.'));const ctx=context;
 ctx.drawImage(image,0,0);
 if(map.drawing)ctx.drawImage(await svgImage(drawingSvg(map.drawing,labels,map.layers)),0,0,width,height);
 const scale=width/Math.max(1,displayWidth);
 const labelLayout=layoutMapLabels([...markers.map(marker=>({id:marker.id,show:labels,kind:'marker' as const,text:markerLabel(marker,world),point:marker,labelOffset:marker.labelOffset})),...regions.filter(region=>regionLabels&&region.title).map(region=>({id:region.id,kind:'region' as const,text:region.title,point:regionLabelPoint(region),fixed:!!region.labelPosition}))],width/scale,height/scale,{measureText:text=>{ctx.font=markerLabelFont;return Math.ceil(ctx.measureText(text).width)+2;}});
 ctx.lineJoin='round';ctx.lineCap='round';
 function drawRegion(region:MapRegion){
  ctx.beginPath();for(const ring of [region.points,...region.holes??[]]){ring.forEach((point,index)=>index?ctx.lineTo(point.x*width,point.y*height):ctx.moveTo(point.x*width,point.y*height));ctx.closePath();}
  ctx.globalAlpha=.18;ctx.fillStyle=mapColors[region.color];ctx.fill('evenodd');ctx.globalAlpha=1;ctx.strokeStyle=mapColors[region.color];ctx.lineWidth=2*scale;ctx.stroke();
  const placement=labelLayout.get(region.id);
  if(regionLabels&&region.title&&placement?.visible){const x=(placement.x+placement.width/2)*scale,y=(placement.y+placement.height/2)*scale;ctx.font=`500 ${14*scale}px system-ui, sans-serif`;ctx.textAlign='center';ctx.textBaseline='middle';ctx.strokeStyle='white';ctx.lineWidth=1.5*scale;ctx.strokeText(placement.text,x,y);ctx.fillStyle='#20252d';ctx.fillText(placement.text,x,y);ctx.textAlign='start';}
 }

 function drawRoute(route:MapRoute){const points=exportRoutePoints(route,map,width,height);if(points.length<2)return;
  ctx.beginPath();points.forEach((point,index)=>index?ctx.lineTo(point.x,point.y):ctx.moveTo(point.x,point.y));
  ctx.strokeStyle='rgba(255,255,255,.75)';ctx.lineWidth=5*scale;ctx.stroke();ctx.strokeStyle=mapColors[route.color];ctx.lineWidth=2.5*scale;ctx.stroke();
 }
 const iconImages=await Promise.all(markers.map(marker=>{const svg=icons.get(marker.id);return svg?svgImage(svg):Promise.resolve(null);}));
 function drawMarker(marker:MapMarker){const index=markers.indexOf(marker);
  const x=marker.x*width,y=marker.y*height;
  ctx.beginPath();ctx.arc(x,y,15*scale,0,Math.PI*2);ctx.fillStyle=mapColors[marker.color];ctx.fill();ctx.strokeStyle='#fff';ctx.lineWidth=2*scale;ctx.stroke();
  const icon=iconImages[index];if(icon)ctx.drawImage(icon,x-9*scale,y-9*scale,18*scale,18*scale);

 if(labels){ctx.font=`500 ${13*scale}px system-ui, sans-serif`;ctx.textBaseline='middle';ctx.textAlign='center';
  const placement=labelLayout.get(marker.id);if(placement?.visible){
   if(placement.leader){const line=placement.leader;ctx.beginPath();ctx.moveTo((marker.x*width)+line.x1*scale,(marker.y*height)+line.y1*scale);ctx.lineTo((marker.x*width)+line.x2*scale,(marker.y*height)+line.y2*scale);ctx.strokeStyle='#18202b';ctx.lineWidth=3*scale;ctx.stroke();ctx.strokeStyle='#fff';ctx.lineWidth=scale;ctx.stroke();}
   const x=(placement.x+placement.width/2)*scale,y=(placement.y+placement.height/2)*scale;
   ctx.strokeStyle='#18202b';ctx.lineWidth=2*scale;placement.text.split('\n').forEach((line,index,lines)=>{const lineY=y+(index-(lines.length-1)/2)*18*scale;ctx.strokeText(line,x,lineY);ctx.fillStyle='#fff';ctx.fillText(line,x,lineY);});
  }
  ctx.textAlign='start';
 }

 }
 for(const element of orderedMapElements(map,markers,routes,regions)){if(element.kind==='region')drawRegion(element.value);else if(element.kind==='route')drawRoute(element.value);else drawMarker(element.value);}

 const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(new Error(t('The map could not be exported.'))),'image/png'));
 return new Uint8Array(await blob.arrayBuffer());
}
