import {BookOpen,Plus} from 'lucide-react';
import {t} from './i18n';
export default function ManuscriptEmptyState({hasChapters=false,onAddChapter}:{hasChapters?:boolean;onAddChapter:()=>void}){
 return <div className="manuscript-empty ui-empty-state"><BookOpen aria-hidden="true"/><h2>{t(hasChapters?'Choose a chapter':'Add your first chapter.')}</h2><button type="button" className="primary-button" onClick={onAddChapter}><Plus size={16} aria-hidden="true"/>{t('New chapter')}</button></div>;
}
