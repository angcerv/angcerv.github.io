import type {EntryOrder} from './entryOrdering';
export type WorldView={favoritesOnly?:boolean;canon?:string;query:string;templateId:string;archived:boolean;editorial:string;order:EntryOrder};
export type SavedWorldAccess={entries:string[];views:{id:string;name:string;view:WorldView}[]};
const key=(projectId:string)=>`write-studio.world-access.${projectId}`;
const empty=():SavedWorldAccess=>({entries:[],views:[]});
export function readWorldAccess(projectId:string):SavedWorldAccess{
 try {const value=JSON.parse(localStorage.getItem(key(projectId))??'null');if(!value)return empty();return {entries:Array.isArray(value.entries)?[...new Set<string>(value.entries.filter((id:unknown)=>typeof id==='string'))].slice(0,100):[],views:Array.isArray(value.views)?value.views.filter((item:any)=>typeof item?.id==='string'&&typeof item.name==='string'&&item.name.trim()&&typeof item.view?.query==='string'&&typeof item.view.templateId==='string'&&typeof item.view.archived==='boolean'&&(item.view.favoritesOnly===undefined||typeof item.view.favoritesOnly==='boolean')&&(item.view.canon===undefined||['','unclassified','confirmed','provisional','alternative'].includes(item.view.canon))&&['','unclassified','notStarted','developing','inReview','defined'].includes(item.view.editorial)&&['alphabetical','reverseAlphabetical','recentlyModified','oldestModified'].includes(item.view.order)).slice(0,50):[]};}catch{return empty();}
}
export function rememberWorldAccess(projectId:string,value:SavedWorldAccess):boolean{try{localStorage.setItem(key(projectId),JSON.stringify(value));return true;}catch{return false;}}
