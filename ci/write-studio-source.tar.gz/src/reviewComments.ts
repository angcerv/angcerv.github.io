import { Plugin, PluginKey } from '@tiptap/pm/state';
import { Decoration, DecorationSet } from '@tiptap/pm/view';
import type { Node } from '@tiptap/pm/model';
import { t } from './i18n';
export type ReviewComment={id:string;from:number;to:number;quote:string;text:string;resolved:boolean;detached?:boolean};
type CommentState={comments:ReviewComment[];decorations:DecorationSet};
export const commentKey=new PluginKey<CommentState>('review-comments');
export type CommentDraft={from:number;to:number;quote:string;comment?:ReviewComment};
export function createCommentPlugin(initial:ReviewComment[],onOpen:(draft:CommentDraft)=>void){
 function state(doc:Node,comments:ReviewComment[]):CommentState{return {comments,decorations:DecorationSet.create(doc,comments.filter(c=>!c.resolved&&!c.detached&&c.from>0&&c.to>c.from&&c.to<=doc.content.size).map(c=>Decoration.inline(c.from,c.to,{class:'manuscript-review-comment','data-comment-id':c.id,title:t('Review comment: {0}',c.text)})))};}
 return new Plugin<CommentState>({key:commentKey,state:{init:(_,s)=>state(s.doc,initial),apply(tr,previous){
  let comments=previous.comments;
  if(tr.docChanged)comments=comments.map(c=>{if(c.detached)return c;const from=tr.mapping.map(c.from,1),to=tr.mapping.map(c.to,-1);const quote=from<to&&to<=tr.doc.content.size?tr.doc.textBetween(from,to,'\n','\n'):'';return quote?{...c,from,to,quote}:{...c,from:0,to:0,detached:true};});
  const command=tr.getMeta(commentKey);
  if(command?.kind==='sync')comments=command.comments;
  if(command?.kind==='upsert')comments=comments.some(c=>c.id===command.comment.id)?comments.map(c=>c.id===command.comment.id?command.comment:c):[...comments,command.comment];
  if(command?.kind==='compose'){const {from,to}=tr.selection;const quote=tr.doc.textBetween(from,to,'\n','\n');if(from<to&&quote.trim())onOpen({from,to,quote});}
  return state(tr.doc,comments);
 }},props:{decorations:s=>commentKey.getState(s)?.decorations,handleDOMEvents:{click(view,event){const target=(event.target as HTMLElement).closest('[data-comment-id]');if(!target)return false;const comment=commentKey.getState(view.state)?.comments.find(c=>c.id===target.getAttribute('data-comment-id'));if(!comment)return false;event.preventDefault();onOpen({from:comment.from,to:comment.to,quote:comment.quote,comment});return true;}},handleKeyDown(view,event){if((event.metaKey||event.ctrlKey)&&event.altKey&&event.key.toLowerCase()==='m'){event.preventDefault();view.dispatch(view.state.tr.setMeta(commentKey,{kind:'compose'}));return true;}return false;}}});
}
