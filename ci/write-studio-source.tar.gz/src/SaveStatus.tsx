import { message, t } from './i18n';
import { useEffect, useRef } from 'react';
import { Check, ChevronDown, AlertCircle } from 'lucide-react';
export default function SaveStatus({ ready, busy, operation, autosaving, error, dirty, recovery, hasProject }: { ready: boolean; busy: boolean; operation: string; autosaving: boolean; error: string; dirty: boolean; recovery: string; hasProject: boolean }) {
  const details = useRef<HTMLDetailsElement>(null);
  useEffect(() => {
    const dismiss = (event: PointerEvent) => { if (details.current && !details.current.contains(event.target as Node)) details.current.open = false; };
    document.addEventListener('pointerdown', dismiss); return () => document.removeEventListener('pointerdown', dismiss);
  }, []);
  const label = !ready ? t("Checking recovery…") : autosaving || (busy && operation === t('Saving…')) ? t("Saving…") : busy ? message(operation) : error ? t("Couldn’t save") : hasProject ? dirty ? t("Unsaved changes") : t("Saved") : '';
  if (!label) return null;
  const recoveryFailed = recovery.startsWith(t("Recovery failed:"));
  return <div className="save-status"><details ref={details} onKeyDown={event => { if (event.key === 'Escape' && details.current?.open) { event.preventDefault(); details.current.open = false; details.current.querySelector('summary')?.focus(); } }}><summary data-semantic-tone={!ready||busy||autosaving?'info':error?'error':dirty?'attention':'success'}>{error ? <AlertCircle size={13} /> : label === t('Saved') ? <Check size={13} /> : null}<span role="status" aria-live="polite">{label}</span><ChevronDown size={12} /></summary><div className="save-status-details">{error ? <p className="save-status-error">{message(error)}</p> : hasProject && <p>{dirty ? t("Current changes have not all been saved to the project folder.") : t("Current changes are saved to the project folder.")}</p>}{hasProject && <><p>{t("Autosave checks every 30 seconds and saves only when there are changes.")}</p><p>{t("History keeps one version per 10-minute block for 30 days, plus the two latest versions. Named checkpoints are always kept.")}</p></>}{recovery && <p><strong>{t("Recovery")}</strong><br />{message(recovery)}</p>}<p>{t("The recovery copy is separate from the saved project.")}</p></div></details>{recoveryFailed && <span className="recovery-warning" role="alert">{t("Recovery unavailable")}</span>}</div>;
}
