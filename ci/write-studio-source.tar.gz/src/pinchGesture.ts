export type PinchPoint={x:number;y:number};
export function pinchGeometry(a:PinchPoint,b:PinchPoint){return {center:{x:(a.x+b.x)/2,y:(a.y+b.y)/2},distance:Math.max(1,Math.hypot(b.x-a.x,b.y-a.y))};}
export function pinchCamera(camera:{x:number;y:number;zoom:number},ratio:number,start:PinchPoint,center:PinchPoint,min:number,max:number){
 const zoom=Math.max(min,Math.min(max,camera.zoom*ratio)),factor=zoom/camera.zoom;
 return {zoom,x:center.x-(start.x-camera.x)*factor,y:center.y-(start.y-camera.y)*factor};
}
