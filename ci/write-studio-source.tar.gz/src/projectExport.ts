export type ProjectExportKind='manuscript'|'planning'|'encyclopedia'|'entries'|'templates';
export type ProjectExportRequest={kind?:ProjectExportKind;ids?:string[]};
export const projectExportKinds:readonly ProjectExportKind[]=['manuscript','planning','encyclopedia','entries','templates'];
export const projectExportLabels:Record<ProjectExportKind,string>={manuscript:'Manuscript',planning:'Planning',encyclopedia:'Encyclopedia',entries:'Entry package',templates:'Template package'};
