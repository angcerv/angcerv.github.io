import {t} from './i18n';
import Dropdown from './Dropdown';
import type {ProjectPlots} from './plotThreads';
import {linkArcScene} from './characterArcs';
export default function SceneArcsPanel({plots,sceneId,onChange,onOpen}:{plots:ProjectPlots;sceneId:string;onChange:(plots:ProjectPlots)=>void;onOpen:(id:string)=>void}){
 const arcs=plots.arcs??[],linked=arcs.filter(arc=>arc.beats.some(beat=>beat.sceneId===sceneId));
 return <section className="scene-plots-panel"><h3>{t('Character arcs')}</h3>{linked.map(arc=><button type="button" key={arc.id} onClick={()=>onOpen(arc.id)}>{arc.title||t('Untitled arc')}</button>)}{!linked.length&&<p className="world-hint">{t('No character arcs linked to this scene.')}</p>}<label htmlFor="scene-link-arc">{t('Link to an arc')}</label><Dropdown id="scene-link-arc" value="" placeholder={t('Choose an arc')} options={arcs.filter(arc=>!linked.includes(arc)).map(arc=>({value:arc.id,label:arc.title||t('Untitled arc')}))} onChange={id=>onChange(linkArcScene(plots,id,sceneId,true))}/><button type="button" onClick={()=>onOpen('')}>{t('Manage character arcs')}</button></section>;
}
