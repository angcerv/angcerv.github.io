import type {Project} from './model';
import type {WorkspaceRoute} from './workspaceNavigation';
import {t} from './i18n';
export function workspaceVisitLabel(project:Project,route:WorkspaceRoute):string{
 if(route.view==='canvas')return t('Idea canvases');
 if(route.view==='home')return t('Project overview');
 if(route.view==='manuscript'){
  const chapter=project.chapters.find(chapter=>chapter.id===route.chapterId||chapter.id===route.selectedId||chapter.scenes.some(scene=>scene.id===route.selectedId));
  if(route.manuscriptMode==='board')return t('Scene board');
  if(route.manuscriptMode==='planning')return `${t('Chapter planning')} · ${chapter?.title||t('Untitled chapter')}`;
  if(route.manuscriptMode==='chapter')return chapter?.title||t('Untitled chapter');
  return chapter?.scenes.find(scene=>scene.id===route.selectedId)?.title||chapter?.title||t('Manuscript');
 }
 if(route.view==='worldbuilding'&&route.worldPane){const labels={network:'Relationship network',genealogy:'Genealogy',relationshipTypes:'Relationship types',resources:'Visual resources'};if(route.worldPane in labels)return t(labels[route.worldPane as keyof typeof labels]);}
 if(route.view==='worldbuilding')return route.worldSection==='templates'?project.worldbuilding?.templates.find(template=>template.id===route.worldTemplateRequest?.id)?.title||t('Templates'):project.worldbuilding?.entries.find(entry=>entry.id===route.worldEntryId)?.title||t('World index');
 if(route.view==='plots')return project.plots?.threads.find(plot=>plot.id===route.plotId)?.title||t('Plots');
 if(route.view==='arcs')return project.plots?.arcs?.find(arc=>arc.id===route.arcId)?.title||t('Character arcs');
 if(route.view==='timeline')return project.timeline?.events.find(event=>event.id===route.timelineEventId)?.title||t('Timeline');
 if(route.view==='maps')return project.maps?.maps.find(map=>map.id===route.mapId)?.title||t('Maps');
 return project.worldIdeas?.find(idea=>idea.id===route.pendingIdeaId)?.title||t('Pending');
}
