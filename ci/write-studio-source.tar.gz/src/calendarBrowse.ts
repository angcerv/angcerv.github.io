import type {StoryDate,TimelineEvent} from './timeline';
import type {StoryCalendar} from './storyCalendar';
import {calendarFromStoryDate,calendarMonthDays,calendarWeekday,storyDateFromCalendar} from './storyCalendar';
import {storyDay} from './timelineChartLayout';
export type CalendarPosition={year:number;month:number;page:number;day:number};
const validYear=(year:number)=>Number.isInteger(year)&&year>=-999999&&year<=999999;
export function initialCalendarPosition(calendar:StoryCalendar,events:TimelineEvent[],selectedId:string):CalendarPosition{
 for(const event of [events.find(event=>event.id===selectedId),...events]){
  if(!event?.start?.month||!event.start.day)continue;
  try{const date=calendarFromStoryDate(event.start,calendar);return positionForCalendarDate(calendar,date);}catch{/* Try another exact event before the reference date. */}
 }
 return {year:0,month:1,page:0,day:1};
}
export function positionForCalendarDate(calendar:StoryCalendar,date:StoryDate):CalendarPosition{
 const offset=calendarWeekday({year:date.year,month:date.month!,day:1},calendar),day=date.day??1;
 return {year:date.year,month:date.month!,day,page:Math.floor((offset+day-1)/(calendar.weekdays.length*6))};
}
export function normalizeCalendarPosition(calendar:StoryCalendar,position:CalendarPosition):CalendarPosition{
 const year=validYear(position.year)?position.year:0,month=Number.isInteger(position.month)?Math.max(1,Math.min(calendar.months.length,position.month)):1,days=calendarMonthDays(calendar,year,month),offset=calendarWeekday({year,month,day:1},calendar),pages=Math.ceil((days+offset)/(calendar.weekdays.length*6));
 return {year,month,day:Math.max(1,Math.min(days,Number.isInteger(position.day)?position.day:1)),page:Math.max(0,Math.min(pages-1,Number.isInteger(position.page)?position.page:0))};
}
export function calendarMonthPage(calendar:StoryCalendar,position:CalendarPosition){
 const view=normalizeCalendarPosition(calendar,position),days=calendarMonthDays(calendar,view.year,view.month),columns=calendar.weekdays.length,offset=calendarWeekday({year:view.year,month:view.month,day:1},calendar),start=view.page*columns*6,length=Math.min(columns*6,Math.ceil((days+offset-start)/columns)*columns);
 return {...view,days,pages:Math.ceil((days+offset)/(columns*6)),first:Math.max(1,start-offset+1),last:Math.min(days,start+length-offset),cells:Array.from({length},(_,index)=>{const day=start+index-offset+1;return day>=1&&day<=days?{year:view.year,month:view.month,day}:null;})};
}
export function adjacentCalendarMonth(calendar:StoryCalendar,position:CalendarPosition,direction:-1|1):CalendarPosition|null{
 let {year,month}=normalizeCalendarPosition(calendar,position);month+=direction;if(month===0){year--;month=calendar.months.length;}else if(month>calendar.months.length){year++;month=1;}
 return validYear(year)?{year,month,page:0,day:1}:null;
}
export function calendarEventRanges(events:TimelineEvent[]){
 const exact:{event:TimelineEvent;start:number;end:number}[]=[],uncertain:TimelineEvent[]=[];
 for(const event of events){if(!event.start?.month||!event.start.day||(event.end&&(!event.end.month||!event.end.day))){uncertain.push(event);continue;}exact.push({event,start:storyDay(event.start),end:storyDay(event.end??event.start)});}
 return {exact,uncertain};
}
export function storedCalendarDate(date:StoryDate,calendar:StoryCalendar):StoryDate|undefined{try{return storyDateFromCalendar(date,calendar);}catch{return undefined;}}
export function calendarDayEvents(date:StoryDate,calendar:StoryCalendar,ranges:ReturnType<typeof calendarEventRanges>['exact']):TimelineEvent[]{
 const stored=storedCalendarDate(date,calendar);if(!stored)return [];const day=storyDay(stored);return ranges.filter(range=>range.start<=day&&range.end>=day).map(range=>range.event);
}
