import type {DrawingPoint} from './mapDrawing';
const n=(value:number)=>Number(value.toFixed(3));
/** Quadratic joins stay inside the control-point hull, including near map edges. */
export function drawingPath(points:DrawingPoint[],width:number,height:number,smooth=false){
 const p=points.map(p=>({x:p.x*width,y:p.y*height}));if(!p.length)return '';
 const start=`M${n(p[0].x)} ${n(p[0].y)}`;
 if(!smooth||p.length<3)return start+p.slice(1).map(q=>` L${n(q.x)} ${n(q.y)}`).join('');
 return start+p.slice(1,-1).map((q,i)=>` Q${n(q.x)} ${n(q.y)} ${n((q.x+p[i+2].x)/2)} ${n((q.y+p[i+2].y)/2)}`).join('')+` L${n(p[p.length-1].x)} ${n(p[p.length-1].y)}`;
}
/** Bounded simplification retains endpoints and physical detail after canvas expansion. */
export function simplifyDrawingPath(points:DrawingPoint[],width:number,height:number,tolerance=5):DrawingPoint[]{
 if(points.length<=2)return points;
 const a=points[0],b=points[points.length-1],dx=(b.x-a.x)*width,dy=(b.y-a.y)*height,length=dx*dx+dy*dy;
 let far=tolerance*tolerance,index=-1;
 for(let i=1;i<points.length-1;i++){const px=(points[i].x-a.x)*width,py=(points[i].y-a.y)*height,t=length?Math.max(0,Math.min(1,(px*dx+py*dy)/length)):0,d=(px-t*dx)**2+(py-t*dy)**2;if(d>far){far=d;index=i;}}
 return index<0?[a,b]:[...simplifyDrawingPath(points.slice(0,index+1),width,height,tolerance).slice(0,-1),...simplifyDrawingPath(points.slice(index),width,height,tolerance)];
}
