import {availableRoles,connectionCandidates} from './entryRelations';
import type {EntryRelations,ConnectionSelection,RelationRole} from './entryRelations';
import type {Worldbuilding,Entry} from './worldbuilding';
/** Keep only a still-valid endpoint, using the same eligibility rules as saving. */
export function changeConnectionSelection(relations:EntryRelations,world:Worldbuilding,entry:Entry,current:ConnectionSelection,typeId:string,requestedRole?:RelationRole,editingId?:string):ConnectionSelection{
 const type=relations.types.find(item=>item.id===typeId);if(!type)return {typeId,role:'',templateId:'',entryId:''};
 const roles=availableRoles(type,entry);
 const role=type.symmetric?'source':requestedRole?(roles.includes(requestedRole)?requestedRole:''):roles.includes(current.role as RelationRole)?current.role:roles.length===1?roles[0]:'';
 const other=world.entries.find(item=>item.id===current.entryId);
 const keep=!!other&&!!role&&connectionCandidates(relations,world,entry,type,role,other.templateId,editingId).some(item=>item.id===other.id);
 return {typeId,role,templateId:keep?other!.templateId:'',entryId:keep?other!.id:''};
}

import {formatStoryDate,parseStoryDate} from './timeline';
export function connectionDraftChanged(current:ConnectionSelection,original:ConnectionSelection,start:string,end:string,originalStart:string,originalEnd:string):boolean{
 const date=(value:string)=>{try{return formatStoryDate(parseStoryDate(value));}catch{return value.trim();}};
 return current.typeId!==original.typeId||current.role!==original.role||current.entryId!==original.entryId||date(start)!==date(originalStart)||date(end)!==date(originalEnd);
}
