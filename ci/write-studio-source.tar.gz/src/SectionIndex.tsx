export type IndexSection={id:string;title:string};
/** Shared section links; the owning screen controls scrolling and active tracking. */
export default function SectionIndex({sections,active,onSelect,label,id,hidden=false}:{sections:IndexSection[];active:string;onSelect:(id:string)=>void;label:string;id?:string;hidden?:boolean}){
 return <nav id={id} className="section-index" aria-label={label} aria-hidden={hidden||undefined} inert={hidden}>{sections.map(section=><button type="button" key={section.id} aria-current={active===section.id?'location':undefined} aria-controls={section.id} onClick={()=>onSelect(section.id)}>{section.title}</button>)}</nav>;
}
