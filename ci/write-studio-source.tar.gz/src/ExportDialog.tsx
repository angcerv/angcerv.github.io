import ExportSuccess from './ExportSuccess';
import {focusDialog} from './dialogFocus';
import {bookProject,exportBookProject} from './books';
import {RotateCcw,X} from 'lucide-react';
import {message,t,buttonLabel} from './i18n';
import {useEffect,useMemo,useRef,useState} from 'react';
import type {Project} from './model';
import {suggestFolderName} from './model';
import {exportManuscript} from './manuscriptExport';
import {defaultManuscriptExportPreferences,loadManuscriptExportPreferences,storeManuscriptExportPreferences} from './manuscriptExportPreferences';
import type {ManuscriptExportPreferences} from './manuscriptExportPreferences';
import {saveManuscriptExport} from './storage';
import Dropdown from './Dropdown';
import FieldHelp from './FieldHelp';
export default function ExportDialog({project,onClose,initialBookId='',embedded=false,onBusyChange}:{embedded?:boolean;onBusyChange?:(busy:boolean)=>void;project:Project;onClose:()=>void;initialBookId?:string}){
 const [bookId,setBookId]=useState(initialBookId);
 const scoped=useMemo(()=>exportBookProject(project,bookId),[project,bookId]),exportProject=scoped;
 const dialog=useRef<HTMLDialogElement>(null),saving=useRef(false);
 const [options,setOptions]=useState(()=>loadManuscriptExportPreferences(project.id));
 const [selected,setSelected]=useState(()=>scoped.chapters.map(chapter=>chapter.id)),[author,setAuthor]=useState('');
 const [busy,setBusy]=useState(false),[error,setError]=useState(''),[saved,setSaved]=useState('');
 const {format}=options;
 const available=selected.filter(id=>scoped.chapters.some(chapter=>chapter.id===id));
 useEffect(()=>{if(embedded)return;const previous=document.activeElement as HTMLElement|null,node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous?.isConnected)previous.focus();};},[]);
 useEffect(()=>storeManuscriptExportPreferences(project.id,options),[project.id,options]);
 function clearResult(){setSaved('');setError('');}
 function change(patch:Partial<ManuscriptExportPreferences>){setOptions(previous=>({...previous,...patch}));clearResult();}
 async function save(){
  if(saving.current||!available.length)return;saving.current=true;setBusy(true);clearResult();
  try{
   await new Promise<void>(resolve=>setTimeout(resolve,0));
   const bytes=exportManuscript(exportProject,available,format,{...options,author});
   const path=await saveManuscriptExport(`${suggestFolderName(exportProject.title)}.${format}`,format,bytes);
   if(path)setSaved(path);
  }catch(e){setError(String(e));}finally{saving.current=false;setBusy(false);}
 }
 const Surface=embedded?'section':'dialog';
 useEffect(()=>{onBusyChange?.(busy);},[busy,onBusyChange]);
 return <Surface ref={dialog} className="export-dialog manuscript-export-dialog" aria-labelledby="export-title" onCancel={event=>{event.preventDefault();if(!busy)onClose();}}>
  <header hidden={embedded} inert={embedded} className="ui-dialog-heading"><h2 id="export-title">{t('Export manuscript')}</h2><button type="button" className="icon-button ui-close-button" aria-label={t('Close')} title={t('Close')} disabled={busy} onClick={onClose}><X size={18} aria-hidden="true"/></button></header>
  <div className="manuscript-export-body"><p>{t('Includes current unsaved text. Worldbuilding and project files are kept separately.')}</p>
  <fieldset disabled={busy}><legend className="visually-hidden">{t('Export options')}</legend>
   {!!project.books?.length&&<div className="ui-form-field"><label htmlFor="export-book">{t('Book')}</label><Dropdown id="export-book" value={bookId} options={[{value:'',label:t('All books')},...project.books.map(book=>({value:book.id,label:book.title}))]} onChange={id=>{setBookId(id);setSelected(bookProject(project,id).chapters.map(chapter=>chapter.id));clearResult();}}/></div>}
   <div className="export-format" role="group" aria-label={t('Export format')}>{(['docx','md'] as const).map(value=><label key={value}><input type="radio" name="export-format" checked={format===value} onChange={()=>change({format:value})}/>{value==='docx'?t('Word (.docx)'):t('Markdown (.md)')}</label>)}<button type="button" className="quick-action" aria-label={t('Restore export defaults')} title={t('Restore export defaults')} onClick={()=>change({...defaultManuscriptExportPreferences})}><RotateCcw size={15}/></button><FieldHelp label={t('Export options')} description={t('Presentation settings are remembered for this project on this computer. Chapter selection and the author name are not remembered.')}/></div>
   <div className="export-chapter-heading"><h3>{t('Chapters')}</h3><button type="button" onClick={()=>{setSelected(scoped.chapters.map(chapter=>chapter.id));clearResult();}}>{t('Select all')}</button><button type="button" onClick={()=>{setSelected([]);clearResult();}}>{t('Clear')}</button></div>
   <div className="export-chapters">{scoped.chapters.map((chapter,index)=><label key={chapter.id}><input type="checkbox" checked={selected.includes(chapter.id)} onChange={event=>{setSelected(previous=>event.target.checked?[...previous,chapter.id]:previous.filter(id=>id!==chapter.id));clearResult();}}/><span>{index+1}. {chapter.title||t('Untitled chapter')}</span><small>{chapter.scenes.length===1?t('1 scene'):t('{0} scenes',chapter.scenes.length)}</small></label>)}</div>
   {!available.length&&<p className="field-hint">{t('Select at least one chapter.')}</p>}
   <label className="export-scene-titles"><input type="checkbox" checked={options.sceneTitles} onChange={event=>change({sceneTitles:event.target.checked})}/>{t('Include scene titles')}</label>
   {format==='docx'?<section className="manuscript-export-presentation" aria-labelledby="export-presentation-title"><h3 id="export-presentation-title">{t('Presentation')}</h3>
    <div className="manuscript-export-toggles"><label><input type="checkbox" checked={options.coverPage} onChange={event=>change({coverPage:event.target.checked})}/>{t('Include a title page')}</label><label><input type="checkbox" checked={options.chapterPageBreaks} onChange={event=>change({chapterPageBreaks:event.target.checked})}/>{t('Start each chapter on a new page')}</label></div>
    {options.coverPage&&<div className="ui-form-field"><label htmlFor="export-author">{t('Author (optional)')}</label><input id="export-author" value={author} maxLength={120} onChange={event=>{setAuthor(event.target.value);clearResult();}}/></div>}
    <div className="manuscript-export-layout">
     <div className="ui-form-field"><label htmlFor="export-font">{t('Font')}</label><Dropdown id="export-font" value={options.font} options={[{value:'georgia',label:'Georgia'},{value:'times',label:'Times New Roman'},{value:'arial',label:'Arial'}]} onChange={value=>change({font:value as ManuscriptExportPreferences['font']})}/></div>
     <div className="ui-form-field"><label htmlFor="export-font-size">{t('Font size')}</label><Dropdown id="export-font-size" value={String(options.fontSize)} options={[11,12,14].map(size=>({value:String(size),label:t('{0} pt',size)}))} onChange={value=>change({fontSize:Number(value) as ManuscriptExportPreferences['fontSize']})}/></div>
     <div className="ui-form-field"><label htmlFor="export-line-spacing">{t('Line spacing')}</label><Dropdown id="export-line-spacing" value={String(options.lineSpacing)} options={[{value:'1',label:t('Single spacing')},{value:'1.5',label:t('1.5 lines')},{value:'2',label:t('Double spacing')}]} onChange={value=>change({lineSpacing:Number(value) as ManuscriptExportPreferences['lineSpacing']})}/></div>
     <div className="ui-form-field"><label htmlFor="export-paper">{t('Paper size')}</label><Dropdown id="export-paper" value={options.paperSize} options={[{value:'a4',label:'A4'},{value:'letter',label:t('Letter')}]} onChange={value=>change({paperSize:value as ManuscriptExportPreferences['paperSize']})}/></div>
     <div className="ui-form-field"><label htmlFor="export-margins">{t('Margins')}</label><Dropdown id="export-margins" value={options.margins} options={[{value:'standard',label:t('Standard · 2.54 cm')},{value:'compact',label:t('Compact · 2 cm')},{value:'wide',label:t('Wide · 3 cm')}]} onChange={value=>change({margins:value as ManuscriptExportPreferences['margins']})}/></div>
    </div>
   </section>:<p className="field-hint">{t('Markdown preserves text and headings. Title pages, typography and page layout apply only to Word.')}</p>}
   <p className="field-hint">{t('Chapters follow manuscript order. Choose a new filename; existing files are never replaced.')}</p>
   {error&&<p role="alert" className="prompt-error">{message(error)}</p>}{saved&&<ExportSuccess path={saved}/>}
  </fieldset></div>
   <footer className="world-form-actions" aria-busy={busy}><button type="button" className="primary-button" disabled={busy||!available.length} onClick={()=>void save()}>{busy?buttonLabel('Exporting…'):buttonLabel('Export…')}</button></footer>
 </Surface>;
}
