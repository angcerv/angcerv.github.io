import type {Entry} from './worldbuilding';
import {editorialLabels,canonLabels} from './entryEditorial';
import type {EditorialStatus,CanonStatus} from './entryEditorial';
import Dropdown from './Dropdown';
import {statusTone} from './semanticStatus';
import {t,buttonLabel} from './i18n';

type Dimension='editorial'|'canon';
function EntryStatus({entry,dimension,onChange,compact=false}:{entry:Entry;dimension:Dimension;onChange?:(entry:Entry)=>void;compact?:boolean}){
 const editorial=dimension==='editorial',value=(editorial?entry.editorialStatus:entry.canonStatus)??'';
 const labels:Record<string,string>=editorial?editorialLabels:canonLabels;
 const label=t(editorial?'Editorial':'Canon'),id=editorial?'entry-editorial-status':'entry-canon-status';
 if(!onChange&&!value)return null;
 const text=value?t(labels[value]):t('Unclassified');
 const badge=<span className="semantic-status entry-state-badge" data-semantic-tone={value?statusTone(dimension,value):'neutral'} aria-label={`${label}: ${text}`}>{text}</span>;
 if(compact)return badge;
 return <span className="entry-state-dimension">{onChange?<label htmlFor={id}>{label}</label>:<span className="entry-state-label">{label}</span>}{onChange?<Dropdown id={id} variant="badge" aria-label={label} value={value} options={[{value:'',label:t('Unclassified'),tone:'neutral'},...Object.entries(labels).map(([value,label])=>({value,label:buttonLabel(label),tone:statusTone(dimension,value)}))]} onChange={value=>{const next={...entry};if(editorial){if(value)next.editorialStatus=value as EditorialStatus;else delete next.editorialStatus;}else{if(value)next.canonStatus=value as CanonStatus;else delete next.canonStatus;}onChange(next);}}/>:badge}</span>;
}
export function EditorialBadge({entry}:{entry:Entry}){return <EntryStatus entry={entry} dimension="editorial" compact/>;}
export function CanonBadge({entry}:{entry:Entry}){return <EntryStatus entry={entry} dimension="canon" compact/>;}
export function EntryStatuses({entry,onChange,compact=false}:{entry:Entry;onChange?:(entry:Entry)=>void;compact?:boolean}){
 if(!onChange&&!entry.editorialStatus&&!entry.canonStatus)return null;
 return <span className={`entry-states${compact?' entry-states-compact':''}`}><EntryStatus entry={entry} dimension="editorial" onChange={onChange} compact={compact}/><EntryStatus entry={entry} dimension="canon" onChange={onChange} compact={compact}/></span>;
}
export default function EntryEditorial({entry,onChange}:{entry:Entry;onChange:(entry:Entry)=>void}){return <EntryStatuses entry={entry} onChange={onChange}/>;}
