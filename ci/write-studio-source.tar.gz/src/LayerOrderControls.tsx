import { ArrowUp, ArrowDown } from 'lucide-react';
import {buttonLabel} from './i18n';
import { reorderMapLayers } from './maps';
import type { MapLayer } from './maps';
export default function LayerOrderControls({layers,id,onChange}:{layers:MapLayer[];id:string;onChange:(layers:MapLayer[])=>void}){
 const index=layers.findIndex(layer=>layer.id===id),name=layers[index]?.title??'';
 return <span className="layer-order-controls">{(['up','down'] as const).map(direction=><button key={direction} type="button" className="drawing-layer-action quick-action" disabled={index<0||(direction==='up'?index===layers.length-1:index===0)} title={buttonLabel(direction==='up'?'Raise layer {0}':'Lower layer {0}',name)} aria-label={buttonLabel(direction==='up'?'Raise layer {0}':'Lower layer {0}',name)} onClick={event=>{event?.preventDefault();event?.stopPropagation();const next=reorderMapLayers(layers,id,direction);if(next!==layers)onChange(next);}}>{direction==='up'?<ArrowUp size={13}/>:<ArrowDown size={13}/>}</button>)}</span>;
}
