import {X} from 'lucide-react';
import RelationshipOptions from './RelationshipOptions';
import RelationshipTimeFilter from './RelationshipTimeFilter';
import {formatStoryDate} from './timeline';
import type {StoryDate} from './timeline';
import {t} from './i18n';
export default function RelationshipTimeOptions({id,at,showEnded,onChange}:{id:string;at?:StoryDate;showEnded:boolean;onChange:(at:StoryDate|undefined,showEnded:boolean)=>void}){
 return <div className="relationship-time-options"><RelationshipOptions label={t('Temporal filters')}><RelationshipTimeFilter id={id} at={at} showEnded={showEnded} onChange={onChange}/></RelationshipOptions>{at&&<div className="relationship-time-active" role="status"><span>{t('Story date')}: {formatStoryDate(at)}{showEnded?` · ${t('Show ended connections')}`:''}</span><button type="button" className="quick-action" aria-label={t('Reset story date')} title={t('Reset story date')} onClick={()=>onChange(undefined,false)}><X size={16} aria-hidden="true"/></button></div>}</div>;
}
