import {Node,mergeAttributes} from '@tiptap/react';
export const EntryMentionNode=Node.create({
 name:'entryMention',group:'inline',inline:true,atom:true,selectable:true,
 addAttributes(){return {entryId:{default:'',parseHTML:element=>element.getAttribute('data-entry-reference')},label:{default:'',parseHTML:element=>element.textContent??''}};},
 parseHTML(){return [{tag:'span[data-entry-reference]',getAttrs:element=>/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i.test((element as HTMLElement).getAttribute('data-entry-reference')??'')?{}:false}];},
 renderHTML({node,HTMLAttributes}){return ['span',mergeAttributes(HTMLAttributes,{'data-entry-reference':node.attrs.entryId,class:'inline-entry-reference',role:'link',tabindex:0}),node.attrs.label];},
 renderText({node}){return node.attrs.label;},
});
