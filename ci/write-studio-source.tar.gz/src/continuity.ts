import {reviewNarrativeContinuity} from './narrativeContinuity';
import {timelineEventEntryIds} from './timeline';
import { reviewRouteTravel, travelReviewText } from './travelContinuity';
import type { Project } from './model';
import { emptyWorld, isEntryReference } from './worldbuilding';
import { sceneMentions, mentionContext } from './mentionDetection';
import { patchScene } from './manuscript';
import { t } from './i18n';

export type ContinuityKind='ambiguous'|'broken'|'unused'|'travel'|'age'|'chronology';
export type ContinuityIssue={id:string;kind:ContinuityKind;title:string;context:string;excerpt?:string;sceneId?:string;range?:{from:number;to:number};candidateIds?:string[];entryId?:string;mapId?:string;markerId?:string;routeId?:string;relatedSceneIds?:string[];eventId?:string};
export function reviewContinuity(project:Project):ContinuityIssue[]{
 const world=project.worldbuilding??emptyWorld,ids=new Set(world.entries.map(entry=>entry.id)),used=new Set<string>(),issues:ContinuityIssue[]=[];
 for(const chapter of project.chapters)for(const scene of chapter.scenes){
  const context=`${chapter.title||t('Untitled chapter')} / ${scene.title||t('Untitled scene')}`;
  const missingManual=(scene.entryIds??[]).filter(id=>!ids.has(id));
  for(const id of scene.entryIds??[])if(ids.has(id))used.add(id);
  if(missingManual.length)issues.push({id:`scene:${scene.id}`,kind:'broken',title:missingManual.length===1?t('Scene link to a deleted entry'):t('{0} scene links to deleted entries',missingManual.length),context,sceneId:scene.id});
  for(const mention of sceneMentions(scene,world)){
   const range={from:mention.from,to:mention.to};
   if(mention.entryIds.length>1)issues.push({id:`ambiguous:${scene.id}:${mention.from}`,kind:'ambiguous',title:mention.label,context,excerpt:mentionContext(scene,mention.from,mention.to),sceneId:scene.id,range,candidateIds:mention.entryIds});
   else if(mention.entryIds[0]){const id=mention.entryIds[0];if(ids.has(id))used.add(id);else issues.push({id:`mention:${scene.id}:${mention.from}`,kind:'broken',title:t('“{0}” links to a deleted entry',mention.label),context,excerpt:mentionContext(scene,mention.from,mention.to),sceneId:scene.id,range});}
  }
 }
 for(const entry of world.entries){
  const template=world.templates.find(template=>template.id===entry.templateId);
  for(const field of template?.fields??[]){const value=entry.values[field.id];if(isEntryReference(value)&&!ids.has(value.entryId))issues.push({id:`field:${entry.id}:${field.id}`,kind:'broken',title:t('Field link to a deleted entry'),context:`${entry.title||t('Untitled entry')} / ${field.label||t('Untitled field')}`,entryId:entry.id});}
 }
 for(const map of project.maps?.maps??[])for(const marker of map.markers)if(marker.entryId&&!ids.has(marker.entryId))issues.push({id:`marker:${marker.id}`,kind:'broken',title:t('Map marker linked to a deleted entry'),context:`${map.title||t('Untitled map')} / ${marker.title||t('Untitled marker')}`,mapId:map.id,markerId:marker.id});
 for(const event of project.timeline?.events??[]){const missing=timelineEventEntryIds(event).filter(id=>!ids.has(id));if(missing.length)issues.push({id:`event:${event.id}`,kind:'broken',title:missing.length===1?t('Timeline link to a deleted entry'):t('{0} timeline links to deleted entries',missing.length),context:event.title||t('Untitled event'),eventId:event.id});}
 for(const map of project.maps?.maps??[])for(const route of map.routes??[]){
  const result=reviewRouteTravel(map,route);if(!result||result.kind==='fits')continue;
  const relatedSceneIds=project.chapters.flatMap(chapter=>chapter.scenes.filter(scene=>route.sceneIds?.includes(scene.id)||route.chapterIds?.includes(chapter.id)).map(scene=>scene.id));
  issues.push({id:`travel:${route.id}`,kind:'travel',title:result.kind==='reversed'?t('Travel dates are reversed'):t('Not enough time for this journey'),context:`${map.title||t('Untitled map')} / ${route.title||t('Untitled route')}`,excerpt:travelReviewText(result),mapId:map.id,routeId:route.id,relatedSceneIds});
 }
 for(const entry of world.entries)if(!entry.archived&&!used.has(entry.id))issues.push({id:`unused:${entry.id}`,kind:'unused',title:entry.title||t('Untitled entry'),context:world.templates.find(template=>template.id===entry.templateId)?.title||t('Missing template'),entryId:entry.id});
 return [...reviewNarrativeContinuity(project),...issues];
}
export function resolveContinuityMention(project:Project,sceneId:string,range:{from:number;to:number},entryId:string):Project{
 const scene=project.chapters.flatMap(chapter=>chapter.scenes).find(scene=>scene.id===sceneId);if(!scene)return project;
 const mention=sceneMentions(scene,project.worldbuilding??emptyWorld).find(mention=>mention.from===range.from&&mention.to===range.to&&mention.entryIds.length>1&&mention.entryIds.includes(entryId));if(!mention)return project;
 return patchScene(project,sceneId,{resolvedMentions:[...(scene.resolvedMentions??[]).filter(item=>item.to<=range.from||item.from>=range.to),{...range,text:mention.label,entryId}]});
}
