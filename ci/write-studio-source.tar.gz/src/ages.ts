import {timelineEventEntryIds} from './timeline';
import { t } from './i18n';
import { daysInMonth } from './timeline';
import type { StoryDate, TimelineEvent } from './timeline';
import type { Entry, Field, Worldbuilding } from './worldbuilding';
export function isStoryDate(value:unknown):value is StoryDate {
 if(!value||typeof value!=='object'||Array.isArray(value))return false;
 const date=value as Record<string,unknown>;
 if(Object.keys(date).some(key=>!['year','month','day'].includes(key))||!Number.isInteger(date.year)||Number(date.year)<-999999||Number(date.year)>999999)return false;
 if(date.month!==undefined&&(!Number.isInteger(date.month)||Number(date.month)<1||Number(date.month)>12))return false;
 return date.day===undefined || (date.month!==undefined&&Number.isInteger(date.day)&&Number(date.day)>=1&&Number(date.day)<=daysInMonth(Number(date.year),Number(date.month)));
}
export function birthDateField(world:Worldbuilding|undefined,entry:Entry):Field|undefined {
 return world?.templates.find(template=>template.id===entry.templateId)?.fields.find(field=>field.fieldType==='date'&&field.isBirthDate&&!field.archived);
}
export function entryBirthDate(world:Worldbuilding|undefined,entry:Entry):StoryDate|undefined {
 const field=birthDateField(world,entry),value=field?entry.values[field.id]:undefined;return isStoryDate(value)?value:undefined;
}
type FullDate={year:number;month:number;day:number};
const edge=(date:StoryDate,last=false):FullDate=>({year:date.year,month:date.month??(last?12:1),day:date.day??(last?daysInMonth(date.year,date.month??12):1)});
const compare=(a:FullDate,b:FullDate)=>a.year-b.year||a.month-b.month||a.day-b.day;
// Feb 29 birthdays advance on March 1 in non-leap years. Astronomical years include year 0.
const completedYears=(birth:FullDate,date:FullDate)=>date.year-birth.year-Number(date.month<birth.month||(date.month===birth.month&&date.day<birth.day));
export type AgeResult={kind:'unknown'}|{kind:'beforeBirth'}|{kind:'birthUncertain';max:number}|{kind:'spansBirth';max:number}|{kind:'age';min:number;max:number;approximate:boolean};
export function ageAtDate(birth:StoryDate|undefined,start:StoryDate|undefined,end?:StoryDate):AgeResult {
 if(!isStoryDate(birth)||!isStoryDate(start)||(end!==undefined&&!isStoryDate(end)))return {kind:'unknown'};
 const first=edge(start),last=edge(end??start,true),earliestBirth=edge(birth),latestBirth=edge(birth,true);
 if(compare(last,first)<0)return {kind:'unknown'};
 if(compare(last,earliestBirth)<0)return {kind:'beforeBirth'};
 const max=Math.max(0,completedYears(earliestBirth,last));
 if(compare(first,latestBirth)<0)return {kind:birth.day!==undefined&&start.day!==undefined&&end?.day!==undefined?'spansBirth':'birthUncertain',max};
 return {kind:'age',min:completedYears(latestBirth,first),max,approximate:birth.month===undefined||birth.day===undefined||start.month===undefined||start.day===undefined||(end!==undefined&&(end.month===undefined||end.day===undefined))};
}
export function ageLabel(result:AgeResult):string {
 if(result.kind==='unknown')return t('Age unknown');
 if(result.kind==='beforeBirth')return t('Not born yet');
 if(result.kind==='birthUncertain')return t('Birth timing uncertain');
 if(result.kind==='spansBirth')return t('Born during this event');
 const text=result.min===result.max?(result.min===1?t('1 year'):t('{0} years',result.min)):t('{0}–{1} years',result.min,result.max);
 return result.approximate?`≈ ${text}`:text;
}
export function ageExplanation(result:AgeResult):string {
 if(result.kind==='unknown')return t('Set a birth date and a structured story date to calculate age.');
 if(result.kind==='beforeBirth')return t('This event takes place before the earliest possible birth date.');
 if(result.kind==='spansBirth')return t('Birth occurs during this period. Age at the end is {0} years.',result.max);
 if(result.kind==='birthUncertain')return t('The date ranges overlap birth. The entry may not have been born yet, or may be up to {0} years old.',result.max);
 return result.approximate?t('Approximate range based on the available date precision.'):t('Completed years at the event date, or across its start and end dates.');
}
export function eventEntryAges(world:Worldbuilding|undefined,event:TimelineEvent){
 return timelineEventEntryIds(event).flatMap(id=>{const entry=world?.entries.find(entry=>entry.id===id);return entry&&birthDateField(world,entry)?[{entry,age:ageAtDate(entryBirthDate(world,entry),event.start,event.end)}]:[];});
}
