/** Place menus within the window, including short and narrow layouts. */
export function floatingPanelPosition(rect: {left:number;right:number;top:number;bottom:number}, viewport: {width:number;height:number}, preferredWidth=280, preferredHeight=360) {
 const gutter=12, width=Math.max(0,Math.min(preferredWidth,viewport.width-gutter*2));
 const below=Math.max(0,viewport.height-rect.bottom-gutter-6), above=Math.max(0,rect.top-gutter-6);
 const opensBelow=below>=Math.min(preferredHeight,200) || below>=above;
 const maxHeight=Math.min(preferredHeight,Math.max(0,viewport.height-gutter*2),opensBelow ? below : above);
 return {left:Math.max(gutter,Math.min(rect.right-width,viewport.width-width-gutter)),width,maxHeight,...(opensBelow ? {top:Math.max(gutter,Math.min(viewport.height-gutter,rect.bottom+6))} : {bottom:Math.max(gutter,viewport.height-rect.top+6)})};
}
