import type {VisualUse} from './visualResourceUsage';
import type {VisualResource} from './visualResources';
import {visualCategoryLabels} from './visualResources';
import {t} from './i18n';
export function VisualResourceDetails({resource,resources,compact=false}:{resource:VisualResource;resources:VisualResource[];compact?:boolean}){
 const base=resources.find(item=>item.id===resource.variantOf),showVariantLabel=!!resource.variantLabel&&resource.variantLabel!==resource.title;
 return <div className="visual-resource-details">{!compact&&resource.originalFilename&&<small className="visual-resource-filename">{t('Original filename')}: {resource.originalFilename}</small>}{(resource.category||showVariantLabel)&&<div className="visual-resource-tags">{resource.category&&<small>{t(visualCategoryLabels[resource.category])}</small>}{showVariantLabel&&<small>{resource.variantLabel}</small>}</div>}{base&&<small>{t('Variant of: {0}',base.title)}</small>}{resource.caption&&<p className="visual-resource-caption">{resource.caption}</p>}{!compact&&resource.notes&&resource.notes!==resource.caption&&<p className="visual-resource-notes">{resource.notes}</p>}</div>;
}

export function visualUsageSummary(uses:VisualUse[]){
 const labels={entry:'Used by: {0}',map:'Used in maps: {0}',trashedMap:'Maps in trash: {0}',canvas:'Planning boards: {0}',variant:'Dependent variants: {0}'};
 return <div className="visual-resource-usage">{Object.entries(labels).map(([kind,label])=>{const matches=uses.filter(use=>use.kind===kind);return matches.length?<small key={kind}>{t(label,matches.map(use=>use.title).join(', '))}</small>:null;})}{!uses.length&&<small>{t('No current links')}</small>}</div>;
}
