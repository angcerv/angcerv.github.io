import ActionMenu from './ActionMenu';
import {t,buttonLabel} from './i18n';
import {Settings} from 'lucide-react';
export type WorldSection='entries'|'relations'|'maps'|'resources'|'templates'|'types';
export default function WorldNavigation({selected,onSelect}:{selected:WorldSection;onSelect:(value:WorldSection)=>void}){
 return <nav className="world-tabs module-navigation" aria-label={t('Worldbuilding view')}>{([{id:'entries',label:'Entries'},{id:'relations',label:'Relationships'},{id:'maps',label:'Maps'},{id:'resources',label:'Visual resources'}] as const).map(({id,label})=><button type="button" key={id} aria-pressed={selected===id} onClick={()=>onSelect(id)}>{buttonLabel(label)}</button>)}<ActionMenu label={t('World configuration')} actions={[{label:t('Templates'),onClick:()=>onSelect('templates')},{label:t('Relationship types'),onClick:()=>onSelect('types')}]}><Settings size={16}/><span>{buttonLabel(selected==='templates'?'Templates':selected==='types'?'Relationship types':'Configure')}</span></ActionMenu></nav>;
}
