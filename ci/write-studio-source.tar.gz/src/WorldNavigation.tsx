import ActionMenu from './ActionMenu';
import {t,buttonLabel} from './i18n';
import {BookOpen,Network,Map,Images,Settings} from 'lucide-react';
export type WorldSection='entries'|'relations'|'maps'|'resources'|'templates'|'types';
export default function WorldNavigation({selected,onSelect}:{selected:WorldSection;onSelect:(value:WorldSection)=>void}){
 return <nav className="world-tabs workspace-tabs workspace-tabs-internal module-navigation" aria-label={t('Worldbuilding view')}>{([{id:'entries',label:'Entries',Icon:BookOpen},{id:'relations',label:'Relationships',Icon:Network},{id:'maps',label:'Maps',Icon:Map},{id:'resources',label:'Visual resources',Icon:Images}] as const).map(({id,label,Icon})=><button type="button" key={id} aria-current={selected===id?'page':undefined} aria-pressed={selected===id} onClick={()=>onSelect(id)}><Icon size={16} aria-hidden="true"/>{buttonLabel(label)}</button>)}<ActionMenu iconOnly={selected!=='templates'&&selected!=='types'} label={t('World configuration')} actions={[{label:t('Templates'),onClick:()=>onSelect('templates')},{label:t('Relationship types'),onClick:()=>onSelect('types')}]}><Settings size={16}/>{(selected==='templates'||selected==='types')&&<span>{buttonLabel(selected==='templates'?'Templates':'Relationship types')}</span>}</ActionMenu></nav>;
}
