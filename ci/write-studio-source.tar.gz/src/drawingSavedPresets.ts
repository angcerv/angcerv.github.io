import type {MaterialPreset,SymbolPreset} from './drawingToolPresets';
import {symbolArtwork} from './mapDrawing';
import type {BrushKind} from './mapDrawing';
import {isTerrainMaterial} from './mapMaterials';
export type BrushRecipe=Omit<MaterialPreset,'material'>&{material?:MaterialPreset['material'];brush:BrushKind;mode:'solid'|'material'|'erase'};
export type SavedDrawingPreset={id:string;name:string;favorite:boolean;recipe:{type:'brush';value:BrushRecipe}|{type:'symbol';value:SymbolPreset}};
const limit=48,key=(projectId:string)=>`write-studio.drawing-presets.${projectId}`;
const record=(v:unknown):v is Record<string,unknown>=>!!v&&typeof v==='object'&&!Array.isArray(v);
const number=(v:unknown,min:number,max:number)=>typeof v==='number'&&Number.isFinite(v)&&v>=min&&v<=max;
const color=(v:unknown)=>typeof v==='string'&&/^#[0-9a-f]{6}$/i.test(v);
export function normalizeDrawingPresets(input:unknown):SavedDrawingPreset[]{
 if(!Array.isArray(input))return [];const result:SavedDrawingPreset[]=[],ids=new Set<string>(),symbols=new Set<string>();
 for(const item of input.slice(0,limit)){
  if(!record(item)||typeof item.id!=='string'||!item.id||item.id.length>80||ids.has(item.id)||typeof item.name!=='string'||!item.name.trim()||item.name.length>80||!record(item.recipe)||!record(item.recipe.value))continue;
  const value=item.recipe.value;let recipe:SavedDrawingPreset['recipe'];
  if(item.recipe.type==='symbol'){
   const p=value.placement;if(typeof value.kind!=='string'||!Object.prototype.hasOwnProperty.call(symbolArtwork,value.kind)||symbols.has(value.kind)||!number(value.size,.0000001,.25)||!number(value.rotation,0,359.999999)||value.color!==undefined&&!color(value.color)||!record(p)||typeof p.continuous!=='boolean'||!number(p.density,.1,1)||!number(p.sizeVariation,0,.5)||!number(p.rotationVariation,0,180))continue;
   recipe={type:'symbol',value:{kind:value.kind as SymbolPreset['kind'],size:value.size as number,rotation:value.rotation as number,...(value.color?{color:value.color as string}:{}),placement:{continuous:p.continuous,density:p.density as number,sizeVariation:p.sizeVariation as number,rotationVariation:p.rotationVariation as number}}};symbols.add(value.kind);
  }else if(item.recipe.type==='brush'){
   if(!['solid','material','erase'].includes(String(value.mode))||!['land','water','park','road','nebula','region'].includes(String(value.brush))||!color(value.color)||!number(value.size,.0000001,.25)||!number(value.intensity,0,1)||!number(value.opacity,0,1)||!number(value.softness,0,1)||!number(value.textureScale,.25,4)||!number(value.textureRotation,0,359.999999)||!['circle','star','irregular'].includes(String(value.shape))||typeof value.contour!=='boolean'||value.mode==='material'&&!isTerrainMaterial(value.material))continue;
   recipe={type:'brush',value:{brush:value.brush as BrushKind,mode:value.mode as BrushRecipe['mode'],color:value.color as string,size:value.size as number,intensity:value.intensity as number,opacity:value.opacity as number,softness:value.softness as number,textureScale:value.textureScale as number,textureRotation:value.textureRotation as number,shape:value.shape as BrushRecipe['shape'],contour:value.contour,...(value.mode==='material'?{material:value.material as MaterialPreset['material']}:{})}};
  }else continue;
  ids.add(item.id);result.push({id:item.id,name:item.name.trim().normalize('NFC'),favorite:item.favorite===true,recipe});
 }
 return result;
}
export function loadDrawingPresets(projectId:string){try{const raw=localStorage.getItem(key(projectId));if(!raw||raw.length>100000)return [];const data=JSON.parse(raw);return data?.version===1?normalizeDrawingPresets(data.presets):[];}catch{return [];}}
export function storeDrawingPresets(projectId:string,presets:SavedDrawingPreset[]){try{localStorage.setItem(key(projectId),JSON.stringify({version:1,presets:normalizeDrawingPresets(presets)}));return true;}catch{return false;}}
export function saveDrawingPreset(presets:SavedDrawingPreset[],preset:SavedDrawingPreset){
 const filtered=presets.filter(item=>item.id!==preset.id&&!(item.recipe.type==='symbol'&&preset.recipe.type==='symbol'&&item.recipe.value.kind===preset.recipe.value.kind)&&JSON.stringify(item.recipe)!==JSON.stringify(preset.recipe));
 return normalizeDrawingPresets([preset,...filtered].slice(0,limit));
}
