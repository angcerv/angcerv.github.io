import {useId,useState} from 'react';
import {ChevronRight} from 'lucide-react';
import {locale,t} from './i18n';
import type {Entry,Worldbuilding} from './worldbuilding';

function ContentsGroup({title,entries,selectedId,onNavigate}:{title:string;entries:Entry[];selectedId?:string;onNavigate:(id:string)=>void}){
 const [open,setOpen]=useState(false),id=useId();
 return <section className="lore-contents-group"><h2><button type="button" className="lore-contents-toggle" aria-expanded={open} aria-controls={id} onClick={()=>setOpen(!open)}><ChevronRight size={16} aria-hidden="true"/><span>{title}</span></button></h2><div id={id} className={`world-filter-collapse${open?' is-expanded':''}`} inert={!open} aria-hidden={!open}><div><ul>{entries.map(entry=><li key={entry.id}><button type="button" aria-current={selectedId===entry.id?'page':undefined} onClick={()=>onNavigate(entry.id)}>{entry.title||t('Untitled entry')}</button></li>)}</ul></div></div></section>;
}

export default function LoreContents({world,entries=world.entries,selectedId,onNavigate}:{world:Worldbuilding;entries?:Entry[];selectedId?:string;onNavigate:(id:string)=>void}){
 const compare=new Intl.Collator(locale(),{sensitivity:'base',numeric:true}).compare;
 const groups=world.templates.map(template=>({id:template.id,title:template.title||t('Untitled template'),entries:entries.filter(entry=>entry.templateId===template.id)}));
 const missing=entries.filter(entry=>!world.templates.some(template=>template.id===entry.templateId));
 if(missing.length)groups.push({id:'missing-template',title:t('Missing template'),entries:missing});
 return <nav className="lore-contents" aria-label={t('World index')}>{groups.filter(group=>group.entries.length).sort((a,b)=>compare(a.title,b.title)||compare(a.id,b.id)).map(group=><ContentsGroup key={group.id} title={group.title} entries={[...group.entries].sort((a,b)=>compare(a.title||t('Untitled entry'),b.title||t('Untitled entry'))||compare(a.id,b.id))} selectedId={selectedId} onNavigate={onNavigate}/>)}{!entries.length&&<p className="ui-empty-state ui-empty-state-compact">{t('No entries yet.')}</p>}</nav>;
}
