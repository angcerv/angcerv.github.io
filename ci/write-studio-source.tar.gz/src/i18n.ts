import { useSyncExternalStore } from 'react';
import spanish from './locales/es.json';
export type Language = 'en' | 'es';
const messages:Record<string,string>=spanish;
const preferenceKey='write-studio.language';
function readLanguage():Language {try{return localStorage.getItem(preferenceKey)==='es'?'es':'en';}catch{return 'en';}}
let language:Language=readLanguage();
const listeners=new Set<()=>void>();
export const getLanguage=()=>language;
export const locale=()=>language==='es'?'es-ES':'en-GB';
export function setLanguage(next:Language){if(next!=='en'&&next!=='es')return;language=next;try{localStorage.setItem(preferenceKey,next);}catch{/* Keep the current session preference if storage is unavailable. */}listeners.forEach(listener=>listener());}
export function useLanguage(){return useSyncExternalStore(listener=>{listeners.add(listener);return()=>{listeners.delete(listener);};},getLanguage,getLanguage);}
export function translate(key:string,lang:Language,...values:unknown[]):string {
 const text=lang==='es'?(messages[key] ?? key):key;
 return text.replace(/\{(\d+)\}/g,(placeholder,index)=>Number(index)<values.length?String(values[Number(index)]):placeholder);
}
export function t(key:string,...values:unknown[]):string {return translate(key,language,...values);}
/** Action punctuation belongs to the UI template, never interpolated project content. */
export function buttonLabel(key:string,...values:unknown[]):string {
 if(!Object.prototype.hasOwnProperty.call(messages,key))return translate(key,language,...values);
 const template=(language==='es'?messages[key]:key).replace(/…|\.\.\./g,'');
 return template.replace(/\{(\d+)\}/g,(placeholder,index)=>Number(index)<values.length?String(values[Number(index)]):placeholder);
}

export function message(text:string):string {
 if(language!=='es')return text;
 if(Object.prototype.hasOwnProperty.call(messages,text))return t(text);
 if(text.startsWith('Error: '))return `Error: ${message(text.slice(7))}`;
 return text;
}
