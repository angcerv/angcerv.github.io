import type {Worldbuilding} from './worldbuilding';
import type {ProjectMaps} from './maps';
import type {VisualUsageContext} from './visualResourceUsage';
import {visualResources,restoreVisualResource,permanentlyRemoveVisualResource} from './visualResources';
import {restoreMap,permanentlyRemoveMap} from './maps';
import {t} from './i18n';
export type TrashSelection={kind:'image'|'map';id:string};
export type TrashItem=TrashSelection&{title:string;imageId:string;deletedAt:number};
export const trashKey=(item:TrashSelection)=>`${item.kind}:${item.id}`;
export function projectTrashItems(world:Worldbuilding,maps?:ProjectMaps):TrashItem[]{
 return [...visualResources(world,true).filter(resource=>resource.deletedAt!==undefined).map(resource=>({kind:'image' as const,id:resource.id,title:resource.title,imageId:resource.id,deletedAt:resource.deletedAt!})),...(maps?.trash??[]).map(item=>({kind:'map' as const,id:item.map.id,title:item.map.title||t('Untitled map'),imageId:item.map.imageId,deletedAt:item.deletedAt}))].sort((a,b)=>b.deletedAt-a.deletedAt||a.title.localeCompare(b.title));
}
/** Prepare the complete immutable change before committing either domain. */
export function applyProjectTrash(world:Worldbuilding,maps:ProjectMaps|undefined,selection:TrashSelection[],action:'restore'|'delete',context:VisualUsageContext={}){
 const keys=new Set(selection.map(trashKey)),items=projectTrashItems(world,maps).filter(item=>keys.has(trashKey(item)));
 if(items.length!==keys.size)throw new Error(t('Some selected items are no longer in the trash. Review the selection.'));
 let nextMaps=maps,nextWorld=world;
 for(const item of items.filter(item=>item.kind==='map')){
  if(!nextMaps)throw new Error(t('Maps are unavailable.'));
  if(action==='restore'&&nextMaps.maps.some(map=>map.id===item.id))throw new Error(t('A map with this identifier already exists.'));
  nextMaps=action==='restore'?restoreMap(nextMaps,item.id):permanentlyRemoveMap(nextMaps,item.id);
 }
 const images=items.filter(item=>item.kind==='image').sort((a,b)=>{
  const variant=(id:string)=>!!world.visualResources?.find(resource=>resource.id===id)?.variantOf;
  return (Number(variant(a.id))-Number(variant(b.id)))*(action==='delete'?-1:1);
 });
 for(const item of images)nextWorld=action==='restore'?restoreVisualResource(nextWorld,item.id):permanentlyRemoveVisualResource(nextWorld,item.id,{...context,maps:nextMaps});
 return {world:nextWorld,maps:nextMaps};
}
