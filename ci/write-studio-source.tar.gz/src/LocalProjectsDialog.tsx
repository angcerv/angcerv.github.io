import {FolderOpen} from 'lucide-react';
import {useEffect,useRef,useState} from 'react';
import ProjectModal from './ProjectModal';
import RecentProjects from './RecentProjects';
import {chooseFolder,listLocalProjects} from './storage';
import type {RecentProject} from './storage';
import {t,buttonLabel} from './i18n';

export default function LocalProjectsDialog({onOpen,onClose,onBrowse,directory}:{onBrowse?:(path:string)=>void;directory?:string|null;onOpen:(path:string,title:string)=>void;onClose:()=>void}){
 const [projects,setProjects]=useState<RecentProject[]>([]),[loading,setLoading]=useState(true),[error,setError]=useState(''),[attempt,setAttempt]=useState(0);
 useEffect(()=>{let disposed=false;setLoading(true);setError('');void listLocalProjects().then(value=>{if(!disposed)setProjects(value);}).catch(error=>{if(!disposed)setError(String(error));}).finally(()=>{if(!disposed)setLoading(false);});return()=>{disposed=true;};},[attempt]);
 const browsingLock=useRef(false),[browsing,setBrowsing]=useState(false);
 // Keep this dialog mounted until the native picker returns an actual selection.
 async function browse(){
  if(browsingLock.current||!onBrowse)return;
  browsingLock.current=true;setBrowsing(true);setError('');
  try{const path=await chooseFolder();if(path)onBrowse(path);}
  catch(error){setError(String(error));}
  finally{browsingLock.current=false;setBrowsing(false);}
 }
 const folderParts=directory?.split(/[\\/]/).filter(Boolean);
 const folderName=folderParts?.[folderParts.length-1];
 return <ProjectModal className="local-projects-dialog" title={t('Open project')} busy={browsing} onClose={onClose}><RecentProjects local disabled={browsing} variant="selector" libraryTitle={folderName} projects={projects} loading={loading} error={error} onOpen={onOpen} onRetry={()=>setAttempt(value=>value+1)}/>{onBrowse&&<footer className="local-projects-footer"><button type="button" className="quick-action quick-action-text" disabled={browsing} aria-busy={browsing||undefined} onClick={()=>void browse()}><FolderOpen size={16} aria-hidden="true"/>{buttonLabel("Choose another folder…")}</button></footer>}</ProjectModal>;
}
