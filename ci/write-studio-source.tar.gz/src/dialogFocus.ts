/** Open dialogs at a neutral heading; controls receive focus through user navigation. */
export function focusDialog(dialog:HTMLDialogElement|null|undefined,_editable=false){
 if(!dialog)return;
 const heading=dialog.querySelector<HTMLElement>('h2');
 if(heading){heading.setAttribute('tabindex','-1');heading.setAttribute('data-dialog-initial-heading','');}
 (heading??dialog).focus({preventScroll:true});
}
