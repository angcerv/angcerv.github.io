import { Plugin, PluginKey } from '@tiptap/pm/state';
import { Decoration, DecorationSet } from '@tiptap/pm/view';
import type { Node as ProseMirrorNode } from '@tiptap/pm/model';
import type { Worldbuilding } from './worldbuilding';
import type { IgnoredMention, ResolvedMention } from './model';
import { mentionNames, paragraphMentions, isIgnoredMention } from './mentionDetection';
export { findMentions, mentionNames } from './mentionDetection';
import { t } from './i18n';
export type MentionAction={from:number;to:number;text:string;ignored:boolean;resolved?:boolean};
export type MentionCommand=MentionAction|{kind:'sync';ignored:IgnoredMention[];resolved:ResolvedMention[]}|({kind:'resolve';entryId:string}&IgnoredMention)|{kind:'clearResolution';from:number;to:number}|{kind:'flash';from:number;to:number}|{kind:'clearFlash'};
type MentionState={decorations:DecorationSet;ignored:IgnoredMention[];resolved:ResolvedMention[];flash?:{from:number;to:number}};
export const mentionPluginKey=new PluginKey<MentionState>('manuscript-entry-mentions');
export function createMentionPlugin(world:Worldbuilding,onOpen:(ids:string[],label:string,range?:{from:number;to:number})=>void,initialIgnored:IgnoredMention[]=[],onAction?:(action:MentionAction)=>void,initialResolved:ResolvedMention[]=[]){
 const names=mentionNames(world);
 function valid<T extends IgnoredMention>(doc:ProseMirrorNode,items:T[]):T[]{return items.filter(item=>item.from>0&&item.to>item.from&&item.to<=doc.content.size&&doc.textBetween(item.from,item.to,'','\n')===item.text);}
 function decorate(doc:ProseMirrorNode,ignored:IgnoredMention[],resolved:ResolvedMention[],flash?:{from:number;to:number}){
  const decorations:Decoration[]=[];
  doc.descendants((node,pos)=>{
   if(!node.isTextblock)return;
   const text=node.textBetween(0,node.content.size,'','\n');
   for(const mention of paragraphMentions(text,pos,names,resolved)){
    const {from,to}=mention,isIgnored=isIgnoredMention(mention,ignored);
    decorations.push(Decoration.inline(from,to,{
     class:isIgnored?'manuscript-ignored-mention':'manuscript-entry-mention','data-entry-ids':JSON.stringify(mention.entryIds),
     title:isIgnored?t('Right-click to restore this link'):t('Open entry for “{0}” · Alt+Enter · Right-click for link options',mention.label),
    },{entryIds:mention.entryIds,label:mention.label,ignored:isIgnored,resolved:mention.resolved}));
   }
   return false;
  });
  if(flash&&flash.from>0&&flash.to<=doc.content.size)decorations.push(Decoration.inline(flash.from,flash.to,{class:'manuscript-mention-highlight'},{flash:true}));
  return DecorationSet.create(doc,decorations);
 }
 return new Plugin<MentionState>({
  key:mentionPluginKey,
  state:{
   init:(_,state)=>{const ignored=valid(state.doc,initialIgnored),resolved=valid(state.doc,initialResolved);return {ignored,resolved,decorations:decorate(state.doc,ignored,resolved)};},
   apply:(transaction,previous)=>{
    const command=transaction.getMeta(mentionPluginKey) as MentionCommand|undefined;
    if(!transaction.docChanged&&!command)return previous;
    function remap<T extends IgnoredMention>(items:T[]):T[]{return transaction.docChanged?items.flatMap(item=>{
     const from=transaction.mapping.mapResult(item.from,1),to=transaction.mapping.mapResult(item.to,-1);
     return from.deletedAcross||to.deletedAcross?[]:[{...item,from:from.pos,to:to.pos}];
    }):items;}
    let ignored=remap(previous.ignored),resolved=remap(previous.resolved),flash=transaction.docChanged?undefined:previous.flash;
    if(command){
     if(!('kind' in command)){ignored=ignored.filter(item=>item.from!==command.from||item.to!==command.to);if(!command.ignored)ignored=[...ignored,{from:command.from,to:command.to,text:command.text}];}
     else if(command.kind==='sync'){ignored=command.ignored;resolved=command.resolved;}
     else if(command.kind==='resolve'){
      const match=(()=>{let found=false;transaction.doc.descendants((node,pos)=>{if(node.isTextblock){const text=node.textBetween(0,node.content.size,'','\n');found ||= paragraphMentions(text,pos,names).some(item=>item.from===command.from&&item.to===command.to&&item.label===command.text&&item.entryIds.includes(command.entryId));return false;}});return found;})();
      if(match){resolved=[...resolved.filter(item=>item.from>=command.to||item.to<=command.from),{from:command.from,to:command.to,text:command.text,entryId:command.entryId}];ignored=ignored.filter(item=>item.from!==command.from||item.to!==command.to);}
     }else if(command.kind==='clearResolution')resolved=resolved.filter(item=>item.from!==command.from||item.to!==command.to);
     else if(command.kind==='flash')flash={from:command.from,to:command.to};
     else if(command.kind==='clearFlash')flash=undefined;
    }
    ignored=valid(transaction.doc,ignored);resolved=valid(transaction.doc,resolved);
    return {ignored,resolved,flash,decorations:decorate(transaction.doc,ignored,resolved,flash)};
   },
  },
  props:{
   decorations:state=>mentionPluginKey.getState(state)?.decorations,
   handleClick(view,_pos,event){
    if(!(event.target instanceof Element))return false;
    const link=event.target.closest<HTMLElement>('.manuscript-entry-mention');
    if(!link||!view.dom.contains(link))return false;
    const pos=view.posAtDOM(link,0),match=mentionPluginKey.getState(view.state)?.decorations.find(pos,pos+1).find(item=>!item.spec.flash);
    if(!match)return false;
    onOpen(match.spec.entryIds,match.spec.label,{from:match.from,to:match.to});return true;
   },
   handleDOMEvents:{contextmenu(view,event){
    if(!onAction||!(event.target instanceof Element))return false;
    const link=event.target.closest('.manuscript-entry-mention, .manuscript-ignored-mention');
    if(!link||!view.dom.contains(link))return false;
    const pos=view.posAtDOM(link,0),match=mentionPluginKey.getState(view.state)?.decorations.find(pos,pos+1).find(item=>!item.spec.flash);
    if(!match)return false;
    event.preventDefault();onAction({from:match.from,to:match.to,text:match.spec.label,ignored:match.spec.ignored,resolved:match.spec.resolved});return true;
   }},
   handleKeyDown(view,event){
    if(event.key!=='Enter'||!event.altKey||event.isComposing)return false;
    const {from,to}=view.state.selection;
    const match=mentionPluginKey.getState(view.state)?.decorations.find(from,to).find(item=>!item.spec.flash);
    if(!match)return false;
    if(event.shiftKey&&onAction){event.preventDefault();onAction({from:match.from,to:match.to,text:match.spec.label,ignored:match.spec.ignored,resolved:match.spec.resolved});return true;}
    if(match.spec.ignored)return false;
    event.preventDefault();onOpen(match.spec.entryIds,match.spec.label,{from:match.from,to:match.to});return true;
   },
  },
 });
}
