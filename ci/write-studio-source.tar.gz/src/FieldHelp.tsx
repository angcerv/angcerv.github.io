import {textReferencePlainText} from './textReferenceTokens';
import { useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Info } from 'lucide-react';
import { t } from './i18n';

export default function FieldHelp({label,description,variant}:{label:string;description?:string;variant?:'toolbar'}){
 const id=useId(),trigger=useRef<HTMLButtonElement>(null),tooltip=useRef<HTMLSpanElement>(null),timer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
 const [open,setOpen]=useState(false),[position,setPosition]=useState({left:0,top:0});
 const text=description?textReferencePlainText(description).trim():undefined;
 function reveal(){clearTimeout(timer.current);setOpen(true);}
 function hide(){clearTimeout(timer.current);setOpen(false);}
 function leave(){clearTimeout(timer.current);timer.current=setTimeout(()=>{if(document.activeElement!==trigger.current)setOpen(false);},120);}
 useEffect(()=>()=>clearTimeout(timer.current),[]);
 useLayoutEffect(()=>{
  if(!open||!text||!trigger.current||!tooltip.current)return;
  const anchor=trigger.current.getBoundingClientRect(),box=tooltip.current.getBoundingClientRect();
  setPosition({left:Math.max(8,Math.min(anchor.left,window.innerWidth-box.width-8)),top:Math.max(8,Math.min(anchor.bottom+8+box.height<=window.innerHeight-8?anchor.bottom+8:anchor.top-box.height-8,window.innerHeight-box.height-8))});
 },[open,text]);
 useEffect(()=>{
  if(!open||!text)return;
  const outside=(event:Event)=>{if(!trigger.current?.contains(event.target as Node)&&!tooltip.current?.contains(event.target as Node))hide();};
  const scroll=(event:Event)=>{if(!tooltip.current?.contains(event.target as Node))hide();};
  const key=(event:KeyboardEvent)=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();hide();}};
  document.addEventListener('pointerdown',outside,true);document.addEventListener('keydown',key,true);window.addEventListener('scroll',scroll,true);window.addEventListener('resize',hide);
  return()=>{document.removeEventListener('pointerdown',outside,true);document.removeEventListener('keydown',key,true);window.removeEventListener('scroll',scroll,true);window.removeEventListener('resize',hide);};
 },[open,text]);
 if(!text)return null;
 return <span className={`field-help${variant==='toolbar'?' field-help-toolbar':''}`}><button ref={trigger} type="button" className="field-help-button" aria-label={t('About field {0}',label)} aria-describedby={open?id:undefined} onPointerEnter={event=>{if(event.pointerType!=='touch')reveal();}} onPointerLeave={leave} onFocus={reveal} onBlur={hide} onClick={reveal}><Info size={14} aria-hidden="true"/></button>{open&&typeof document!=='undefined'&&createPortal(<span id={id} ref={tooltip} role="tooltip" className="field-help-tooltip" style={position} onPointerEnter={reveal} onPointerLeave={leave}>{text}</span>,trigger.current?.closest('dialog[open]')??document.body)}</span>;
}
