/** Bound preview memory independently of zoom. Exports continue using native SVG. */
export function rasterPreviewSize(width:number,height:number,pixels=2_000_000,maxEdge=2048){
 const ratio=Math.min(1,maxEdge/width,maxEdge/height,Math.sqrt(pixels/(width*height)));
 return {width:Math.max(1,Math.floor(width*ratio)),height:Math.max(1,Math.floor(height*ratio))};
}
export function previewSvgSource(markup:string,width:number,height:number,pixels=2_000_000){
 const size=rasterPreviewSize(width,height,pixels);
 return `data:image/svg+xml;charset=utf-8,${encodeURIComponent(`<svg xmlns="http://www.w3.org/2000/svg" width="${size.width}" height="${size.height}" viewBox="0 0 ${width} ${height}">${markup}</svg>`)}`;
}
const jobs:(()=>Promise<void>)[]=[];let running=false;
function drain(){if(running||!jobs.length)return;running=true;setTimeout(()=>{const job=jobs.shift();if(!job){running=false;drain();return;}void job().finally(()=>{running=false;drain();});},0);}
/** At most one bounded canvas/image decode at a time, shared by viewer and layers. */
export function rasterizeSvgPreview(source:string,width:number,height:number,signal:AbortSignal,pixels=2_000_000):Promise<string|undefined>{
 return new Promise(resolve=>{
  if(signal.aborted){resolve(undefined);return;}
  const job=()=>new Promise<void>(finished=>{
   if(signal.aborted){resolve(undefined);finished();return;}
   const size=rasterPreviewSize(width,height,pixels);let image:HTMLImageElement,canvas:HTMLCanvasElement;
   try{image=new Image();canvas=document.createElement('canvas');}catch{resolve(undefined);finished();return;}let settled=false;
   const done=(url?:string)=>{if(settled){if(url)URL.revokeObjectURL(url);return;}settled=true;signal.removeEventListener('abort',abort);image.onload=null;image.onerror=null;image.src='';canvas.width=0;canvas.height=0;resolve(url);finished();};
   const abort=()=>done();signal.addEventListener('abort',abort,{once:true});
   image.onerror=()=>done();image.onload=()=>{if(signal.aborted){done();return;}try{canvas.width=size.width;canvas.height=size.height;const context=canvas.getContext('2d');if(!context){done();return;}context.drawImage(image,0,0,size.width,size.height);canvas.toBlob(blob=>{if(settled)return;done(blob?URL.createObjectURL(blob):undefined);},'image/png');}catch{done();}};
   try{
    const svg=decodeURIComponent(source.slice(source.indexOf(',')+1)).replace(/^(<svg\b[^>]*\bwidth=")[^"]+("\s+height=")[^"]+/,(_match,before,between)=>`${before}${size.width}${between}${size.height}`);
    image.src=`data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
   }catch{done();}
  });
  const cancelQueued=()=>{const index=jobs.indexOf(queued);if(index>=0){jobs.splice(index,1);resolve(undefined);}};
  const queued=async()=>{signal.removeEventListener('abort',cancelQueued);try{await job();}catch{resolve(undefined);}};
  signal.addEventListener('abort',cancelQueued,{once:true});
  jobs.push(queued);drain();
 });
}
