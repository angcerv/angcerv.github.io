import {lineageDraftChanged} from './lineageDraft';
import {useState} from 'react';
import {Plus, Pencil, Trash2, GitBranch, X} from 'lucide-react';
import Dropdown from './Dropdown';
import RelationDialog from './RelationDialog';
import {t} from './i18n';
import type {EntryRelations,FamilyLineage} from './entryRelations';
import type {Worldbuilding} from './worldbuilding';

export function LineageMembership({relations,entryId,onChange,onOpen}:{relations:EntryRelations;entryId:string;onChange:(next:EntryRelations)=>void;onOpen?:(id:string)=>void}){
 const lineages=relations.lineages??[];
 const memberships=lineages.filter(lineage=>lineage.memberIds.includes(entryId)),available=lineages.filter(lineage=>!lineage.memberIds.includes(entryId));
 return <section className="lineage-membership"><h4>{t('Family lineages')}</h4><div className="lineage-membership-items">
  {memberships.map(lineage=><span key={lineage.id} className="entry-relationship-chip">{onOpen?<button type="button" className="entry-connection-link" onClick={()=>onOpen(lineage.id)}>{lineage.name}</button>:<span>{lineage.name}</span>}<button type="button" className="relation-unlink-action" aria-label={t('Remove this entry from lineage {0}',lineage.name)} title={t('Remove this entry from lineage {0}',lineage.name)} onClick={()=>onChange({...relations,lineages:lineages.map(item=>item.id===lineage.id?{...item,memberIds:item.memberIds.filter(id=>id!==entryId)}:item)})}><X size={16} aria-hidden="true"/></button></span>)}
  {!!available.length&&<Dropdown id={`lineage-add-${entryId}`} variant="add" value="" placeholder={t('Add to lineage')} aria-label={t('Add to lineage')} icon={<Plus size={16}/>} onChange={id=>{if(id)onChange({...relations,lineages:lineages.map(item=>item.id===id?{...item,memberIds:[...item.memberIds,entryId]}:item)});}} options={available.map(item=>({value:item.id,label:item.name}))} searchable={available.length>6}/>}
  {!lineages.length&&<span className="world-hint">{t('No lineages created yet.')}</span>}
 </div></section>;
}

export default function FamilyLineages({world,relations,onChange,onClose}:{world:Worldbuilding;relations:EntryRelations;onChange:(next:EntryRelations)=>void;onClose:()=>void}){
 const [draft,setDraft]=useState<FamilyLineage|null>(null),[query,setQuery]=useState(''),[deleting,setDeleting]=useState(false);
 const lineages=relations.lineages??[],old=lineages.find(item=>item.id===draft?.id),dirty=lineageDraftChanged(draft,old);
 const duplicate=!!draft&&lineages.some(item=>item.id!==draft.id&&item.name.trim().toLocaleLowerCase()===draft.name.trim().toLocaleLowerCase());
 function save(){if(!draft?.name.trim()||duplicate)return;onChange({...relations,schemaVersion:8,lineages:old?lineages.map(item=>item.id===draft.id?{...draft,name:draft.name.trim()}:item):[...lineages,{...draft,name:draft.name.trim()}]});setDraft(null);setQuery('');}
 const candidates=world.entries.filter(entry=>(!entry.archived||draft?.memberIds.includes(entry.id))&&entry.title.toLocaleLowerCase().includes(query.trim().toLocaleLowerCase()));
 const missingIds=draft?.memberIds.filter(id=>!world.entries.some(entry=>entry.id===id))??[];
 const visibleIds=new Set([...candidates.map(entry=>entry.id),...missingIds]);
 const visibleSelected=draft?.memberIds.filter(id=>visibleIds.has(id)).length??0;
 function selectVisible(selected:boolean){setDraft(current=>current?{...current,memberIds:selected?[...new Set([...current.memberIds,...visibleIds])]:current.memberIds.filter(id=>!visibleIds.has(id))}:current);}
 return <RelationDialog variant={draft?'form':'list'} className="lineage-dialog" title={draft?t(old?'Edit lineage':'New lineage'):t('Family lineages')} dirty={dirty} onClose={onClose} headerActions={!draft?<div className="lineage-list-toolbar"><span>{t(lineages.length===1?'1 lineage':'{0} lineages',lineages.length)}</span><button type="button" className="primary-button" onClick={()=>{setDraft({id:crypto.randomUUID(),name:'',memberIds:[]});setDeleting(false);}}><Plus size={16}/>{t('New lineage')}</button></div>:undefined}>
  {draft?<form className="entry-connection-form" onSubmit={event=>{event.preventDefault();save();}}>
   <div className="ui-form-field">
    <label htmlFor="lineage-name">{t('Lineage name (required)')}</label>
    <input id="lineage-name" maxLength={80} value={draft.name} aria-invalid={duplicate} aria-describedby={duplicate?'lineage-name-error':!draft.name.trim()?'lineage-name-required':undefined} onChange={event=>setDraft({...draft,name:event.target.value})}/>
    {!draft.name.trim()&&<p id="lineage-name-required" className="field-hint">{t('Enter a name to save the lineage.')}</p>}
    {duplicate&&<p id="lineage-name-error" className="prompt-error" role="alert">{t('A lineage with this name already exists.')}</p>}
   </div>
   <fieldset className="lineage-member-choices">
    <legend>{t('Lineage members')} <span className="lineage-member-count" role="status">{t(draft.memberIds.length===1?'1 selected':'{0} selected',draft.memberIds.length)}</span></legend>
    <div className="ui-form-field">
     <label htmlFor="lineage-member-search">{t('Search members')}</label>
     <input id="lineage-member-search" type="search" value={query} onChange={event=>setQuery(event.target.value)}/>
    </div>
    <div className="lineage-selection-actions">
     <label><input type="checkbox" aria-label={t('Select filtered results')} aria-controls="lineage-member-list" aria-checked={visibleSelected>0&&visibleSelected<visibleIds.size?'mixed':visibleSelected>0} ref={node=>{if(node)node.indeterminate=visibleSelected>0&&visibleSelected<visibleIds.size;}} checked={!!visibleIds.size&&visibleSelected===visibleIds.size} disabled={!visibleIds.size} onChange={event=>selectVisible(event.target.checked)}/>{t('Select results')}</label>
     <span role="status">{t(visibleIds.size===1?'1 result':'{0} results',visibleIds.size)}</span>
    </div>
    <div id="lineage-member-list" className="idea-entry-choices lineage-member-list">
     {candidates.map(entry=><label key={entry.id}>
      <input type="checkbox" checked={draft.memberIds.includes(entry.id)} onChange={event=>setDraft({...draft,memberIds:event.target.checked?[...draft.memberIds,entry.id]:draft.memberIds.filter(id=>id!==entry.id)})}/>
      <span>{entry.title}</span>{entry.archived&&<span className="semantic-status" data-semantic-tone="neutral">{t('Archived')}</span>}
     </label>)}
     {missingIds.map(id=><label key={id}>
      <input type="checkbox" checked onChange={()=>setDraft({...draft,memberIds:draft.memberIds.filter(member=>member!==id)})}/>
      <span className="semantic-label" data-semantic-tone="error">{t('Missing entry')} · {id}</span>
     </label>)}
     {!candidates.length&&!missingIds.length&&<p className="ui-empty-state ui-empty-state-compact">{t('No matching entries.')}</p>}
    </div>
   </fieldset>
   {deleting&&old?<section className="lineage-delete-confirm" role="alert" aria-label={t('Delete lineage')}>
    <p>{t('Delete this lineage? Characters and their relationships are kept.')}</p>
    <div className="relation-connection-footer">
     <button type="button" onClick={()=>setDeleting(false)} className="quick-action quick-action-text">{t('Cancel')}</button>
     <button type="button" className="danger-button" onClick={()=>{onChange({...relations,lineages:lineages.filter(item=>item.id!==draft.id)});setDraft(null);setDeleting(false);setQuery('');}}>{t('Delete lineage')}</button>
    </div>
   </section>:<div className="relation-connection-footer">
    {old&&<button type="button" className="danger-button relation-delete-action" onClick={()=>setDeleting(true)}><Trash2 size={15}/>{t('Delete lineage')}</button>}
    <button type="button" data-relation-cancel onClick={onClose} className="quick-action quick-action-text">{t('Cancel')}</button>
    <button type="submit" className="primary-button" disabled={!draft.name.trim()||duplicate}>{t('Save lineage')}</button>
   </div>}
  </form>:<>

   {!lineages.length?<div className="ui-empty-state"><GitBranch size={24}/><p>{t('Create a lineage and choose its members. Membership does not create family relationships.')}</p></div>:<div className="lineage-list">{lineages.map(lineage=><article key={lineage.id} className="entry-connection-card">
    <div className="lineage-list-identity"><strong>{lineage.name}</strong><span>{t(lineage.memberIds.length===1?'1 member':'{0} members',lineage.memberIds.length)}</span></div>
    <button type="button" className="relation-icon-action" aria-label={t('Edit lineage {0}',lineage.name)} title={t('Edit lineage {0}',lineage.name)} onClick={()=>{setDraft({...lineage,memberIds:[...lineage.memberIds]});setDeleting(false);}}><Pencil size={16}/></button>
   </article>)}</div>}
  </>}
 </RelationDialog>;
}
