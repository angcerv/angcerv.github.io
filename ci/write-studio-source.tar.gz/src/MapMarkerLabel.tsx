import {useEffect,useRef,useState} from 'react';
import type {PointerEvent as ReactPointerEvent} from 'react';
import type {MapLabelPlacement} from './mapLabels';
import type {MarkerLabelOffset} from './mapMarkerLabels';
import {markerLabelCenter,markerLabelOffset,markerLabelLeader} from './mapMarkerLabels';
import {isGraphDrag} from './graphGesture';
import {t} from './i18n';
type Props={name:string;point:{x:number;y:number};width:number;height:number;placement?:MapLabelPlacement;offset?:MarkerLabelOffset;selected:boolean;editable:boolean;interactive:boolean;onSelect:()=>void;onChange:(offset?:MarkerLabelOffset)=>void;onHover:(active:boolean)=>void;onFocus:(active:boolean)=>void;onInteractionChange:(busy:boolean)=>void};
type Gesture={pointerId:number;start:{x:number;y:number};origin:{x:number;y:number};moved:boolean;target:HTMLButtonElement};
export default function MapMarkerLabel({name,point,width,height,placement,offset,selected,editable,interactive,onSelect,onChange,onHover,onFocus,onInteractionChange}:Props){
 const [preview,setPreview]=useState<MarkerLabelOffset|null>(null),gesture=useRef<Gesture|null>(null),suppressClick=useRef(false);
 function release(active:Gesture){if(active.target.hasPointerCapture(active.pointerId))active.target.releasePointerCapture(active.pointerId);}
 function cancel(){const active=gesture.current;gesture.current=null;setPreview(null);if(active){suppressClick.current=true;onInteractionChange(false);release(active);}}
 useEffect(()=>{if(gesture.current)cancel();},[selected,editable,interactive,point.x,point.y,width,height,offset?.angle,offset?.distance,placement?.visible,placement?.width,placement?.height,placement?.text]);
 useEffect(()=>()=>{const active=gesture.current;gesture.current=null;if(active){onInteractionChange(false);release(active);}},[]);
 if(!placement?.visible)return null;
 const px=point.x*width,py=point.y*height,local=preview?markerLabelCenter(preview,placement.width,placement.height):{x:placement.x+placement.width/2-px,y:placement.y+placement.height/2-py};
 const x=px+local.x-placement.width/2,y=py+local.y-placement.height/2,leader=markerLabelLeader(x-px,y-py,placement.width,placement.height);
 function proposed(active:Gesture,clientX:number,clientY:number){return markerLabelOffset({x:active.origin.x+clientX-active.start.x,y:active.origin.y+clientY-active.start.y},placement!.width,placement!.height);}
 function finish(event:ReactPointerEvent<HTMLButtonElement>,cancelled=false){const active=gesture.current;if(!active||active.pointerId!==event.pointerId)return;
  gesture.current=null;setPreview(null);onInteractionChange(false);const moved=active.moved||isGraphDrag(active.start,{x:event.clientX,y:event.clientY});suppressClick.current=cancelled||moved;
  if(!cancelled&&moved)onChange(proposed(active,event.clientX,event.clientY));release(active);
 }
 return <>{leader&&<svg className="map-marker-leader" width="1" height="1" style={{left:px,top:py}} aria-hidden="true"><line {...leader}/></svg>}<button type="button" className={`map-marker-name${selected?' selected':''}`} data-draggable={editable&&interactive||undefined} style={{left:x,top:y,width:placement.width,height:placement.height,pointerEvents:interactive?'auto':'none'}} tabIndex={selected&&interactive?0:-1} aria-label={selected?t('Move label of {0}',name):t('Select marker {0}',name)} title={name} aria-pressed={selected}
 onPointerEnter={event=>{if(event.pointerType!=='touch')onHover(true);}} onPointerLeave={()=>onHover(false)} onFocus={()=>onFocus(true)} onBlur={()=>onFocus(false)}
 onPointerDown={event=>{event.stopPropagation();suppressClick.current=false;if(gesture.current||!editable||!interactive||event.button!==0||!event.isPrimary)return;event.preventDefault();event.currentTarget.focus();gesture.current={pointerId:event.pointerId,start:{x:event.clientX,y:event.clientY},origin:local,moved:false,target:event.currentTarget};onInteractionChange(true);event.currentTarget.setPointerCapture(event.pointerId);}}
 onPointerMove={event=>{const active=gesture.current;if(!active||active.pointerId!==event.pointerId)return;if(!active.moved&&!isGraphDrag(active.start,{x:event.clientX,y:event.clientY}))return;active.moved=true;setPreview(proposed(active,event.clientX,event.clientY));}}
 onPointerUp={event=>{event.stopPropagation();finish(event);}} onPointerCancel={event=>finish(event,true)} onLostPointerCapture={event=>finish(event,true)} onWheelCapture={event=>{if(gesture.current){event.preventDefault();event.stopPropagation();}}}
 onClick={event=>{event.stopPropagation();if(suppressClick.current){suppressClick.current=false;return;}if(!selected)onSelect();}}
 onKeyDown={event=>{if(event.key==='Escape'&&gesture.current){event.preventDefault();event.stopPropagation();cancel();return;}if(!editable||!interactive)return;if(event.key==='Home'){event.preventDefault();event.stopPropagation();onChange(undefined);return;}if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key))return;event.preventDefault();event.stopPropagation();const step=event.shiftKey?10:1;onChange(markerLabelOffset({x:local.x+(event.key==='ArrowLeft'?-step:event.key==='ArrowRight'?step:0),y:local.y+(event.key==='ArrowUp'?-step:event.key==='ArrowDown'?step:0)},placement.width,placement.height));}}><span>{placement.text}</span></button></>;
}
