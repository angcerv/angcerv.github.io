import {clipTerrainGeometry} from './terrainMask';
import {enhancedBrush,brushFootprint,brushInk} from './mapBrush';
import {isWaterMaterial} from './mapThemes';
import {isTerrainMaterial,materialScale,materialSurface,terrainMaterials,textureIntensity,textureScaleValue,textureRotationValue} from './mapMaterials';
import type {TerrainMaterial} from './mapMaterials';
import type {DrawingStroke,MapDrawing,MaterialMaskTarget,MaterialMask} from './mapDrawing';
const n=(value:number)=>Number(value.toFixed(3));
export function terrainOpacity(value=1){return Number.isFinite(value)?Math.max(0,Math.min(1,value)):1;}
function alpha(geometry:string,opacity:number){return opacity===1?geometry:`<g opacity="${opacity}">${geometry}</g>`;}

const geometryCache=new WeakMap<DrawingStroke,{width:number;height:number;white:string}>();
/** Cached brush footprints. Texture is painted once through their opaque union. */
function footprint(stroke:DrawingStroke,width:number,height:number,paint='white',clipId='ws-live-terrain-clip'){
 let cached=geometryCache.get(stroke);
 if(!cached||cached.width!==width||cached.height!==height){
  const points=stroke.points;
  const white=enhancedBrush(stroke)?brushFootprint(stroke,width,height):!points.length?'':stroke.closed&&points.length>=3?`<path d="${points.map((p,i)=>`${i?'L':'M'}${n(p.x*width)} ${n(p.y*height)}`).join(' ')} Z" fill="white" fill-rule="evenodd"/>`:points.length===1?`<circle cx="${n(points[0].x*width)}" cy="${n(points[0].y*height)}" r="${n(stroke.width*width/2)}" fill="white"/>`:`<path d="${points.map((p,i)=>`${i?'L':'M'}${n(p.x*width)} ${n(p.y*height)}`).join(' ')}" stroke="white" stroke-width="${n(stroke.width*width)}" stroke-linecap="round" stroke-linejoin="round" fill="none"/>`;
  cached={width,height,white};geometryCache.set(stroke,cached);
 }
 const geometry=clipTerrainGeometry(paint==='white'?cached.white:brushInk(cached.white,paint),stroke.mask,width,height,clipId);
 return stroke.materialMask?`<g mask="url(#ws-material-${stroke.materialMask.id})">${geometry}</g>`:geometry;
}
function terrainBounds(strokes:DrawingStroke[],width:number,height:number,scale=materialScale(width,height)){
 let left=width,top=height,right=0,bottom=0;
 for(const stroke of strokes){const radius=stroke.width*width/2+8*scale;for(const point of stroke.points){left=Math.min(left,point.x*width-radius);top=Math.min(top,point.y*height-radius);right=Math.max(right,point.x*width+radius);bottom=Math.max(bottom,point.y*height+radius);}}
 const x=Math.max(0,left),y=Math.max(0,top);return {x:n(x),y:n(y),width:n(Math.max(0,Math.min(width,right)-x)),height:n(Math.max(0,Math.min(height,bottom)-y))};
}
/** Immediate map-space paint while dragging; coast finishing stays on commit. */
export function previewTerrainStroke(stroke:DrawingStroke,width:number,height:number){
 const material=isTerrainMaterial(stroke.material)?stroke.material:undefined,color=stroke.erase?'#64748b':stroke.color??(stroke.kind==='land'?'#d9d0a4':'#b9d9df');
 if(!material&&!enhancedBrush(stroke))return alpha(footprint(stroke,width,height,color),terrainOpacity(stroke.opacity));
 const bounds=terrainBounds([stroke],width,height),mask='ws-live-terrain-mask';
 const surface=material?materialSurface(material,textureIntensity(stroke.textureIntensity),bounds.width,bounds.height,stroke.color,bounds,stroke):`<rect x="${bounds.x}" y="${bounds.y}" width="${bounds.width}" height="${bounds.height}" fill="${color}"/>`;
 return `<defs><mask id="${mask}" x="${bounds.x}" y="${bounds.y}" width="${bounds.width}" height="${bounds.height}" maskUnits="userSpaceOnUse" style="mask-type:luminance">${footprint(stroke,width,height)}</mask></defs><g data-live-terrain="${material??'solid'}" pointer-events="none"${terrainOpacity(stroke.opacity)<1?` opacity="${terrainOpacity(stroke.opacity)}"`:''} mask="url(#${mask})">${surface}</g>`;

}
type TerrainRun={material?:TerrainMaterial;color:string;intensity:number;opacity:number;textureScale:number;textureRotation:number;strokes:DrawingStroke[]};
function terrainRuns(strokes:DrawingStroke[]){
 const runs:TerrainRun[]=[];
 for(const stroke of strokes){
  if(!stroke.points.length)continue;
  const material=isTerrainMaterial(stroke.material)?stroke.material:undefined;
  const color=stroke.color??(material?terrainMaterials[material].color:stroke.kind==='land'?'#d9d0a4':'#b9d9df');
  const intensity=textureIntensity(stroke.textureIntensity),opacity=terrainOpacity(stroke.opacity),textureScale=textureScaleValue(stroke.textureScale),textureRotation=textureRotationValue(stroke.textureRotation),previous=runs[runs.length-1];
  if(opacity===1&&previous?.opacity===1&&material&&previous?.material===material&&previous.color===color&&previous.intensity===intensity&&previous.textureScale===textureScale&&previous.textureRotation===textureRotation)previous.strokes.push(stroke);
  else runs.push({material,color,intensity,opacity,textureScale,textureRotation,strokes:[stroke]});
 }
 return runs;
}
export function renderTerrainStrokes(strokes:DrawingStroke[],width:number,height:number,prefix:string,underlying:DrawingStroke[]=[],waterBackground=false,textureScale?:number):string{
 // Erasure removes only preceding terrain in this layer. Later paint remains intact.
 if(strokes.some(stroke=>stroke.erase)){
  let result='',pending:DrawingStroke[]=[],segment=0;
  for(const stroke of strokes){
   if(!stroke.erase){pending.push(stroke);continue;}
   const id=`${prefix}-erase-${segment++}`;
   result+=renderTerrainStrokes(pending,width,height,`${id}-paint`,[],waterBackground,textureScale);pending=[];
   result=`<defs><mask id="${id}" x="0" y="0" width="${width}" height="${height}" maskUnits="userSpaceOnUse" style="mask-type:luminance"><rect width="${width}" height="${height}" fill="white"/>${alpha(footprint(stroke,width,height,'black',`${id}-clip`),terrainOpacity(stroke.opacity))}</mask></defs><g data-terrain-erased="true" mask="url(#${id})">${result}</g>`;
  }
  return result+renderTerrainStrokes(pending,width,height,`${prefix}-after-${segment}`,[],waterBackground,textureScale);
 }
 const runs=terrainRuns(strokes);
 if(!runs.some(run=>run.material||run.strokes.some(enhancedBrush)))return runs.map((run,ri)=>run.strokes.map((stroke,si)=>alpha(footprint(stroke,width,height,run.color,`${prefix}-solid-${ri}-${si}`),run.opacity)).join('')).join('');
 const scale=textureScale??materialScale(width,height);
 // Vector masks avoid full-map turbulence/displacement buffers at high zoom.
 let definitions='';
 const geometries=runs.map((run,ri)=>[...new Set(run.strokes.map((stroke,si)=>footprint(stroke,width,height,'white',`${prefix}-geometry-${ri}-${si}`)))].join(''));
 const body=runs.map((run,index)=>{
  if(!run.material&&!run.strokes.some(enhancedBrush))return run.strokes.map((stroke,si)=>alpha(footprint(stroke,width,height,run.color,`${prefix}-solid-${index}-${si}`),run.opacity)).join('');
  const mask=`${prefix}-mask-${index}`,bounds=terrainBounds(run.strokes,width,height,scale);
  definitions+=`<mask id="${mask}" x="${bounds.x}" y="${bounds.y}" width="${bounds.width}" height="${bounds.height}" maskUnits="userSpaceOnUse" maskContentUnits="userSpaceOnUse" style="mask-type:luminance">${geometries[index]}</mask>`;
  const surface=run.material?materialSurface(run.material,run.intensity,bounds.width,bounds.height,run.color,bounds,run):`<rect x="${bounds.x}" y="${bounds.y}" width="${bounds.width}" height="${bounds.height}" fill="${run.color}"/>`;
  return `<g ${run.material?`data-terrain-material="${run.material}"`:'data-terrain-brush="true"'} pointer-events="none"${run.opacity<1?` opacity="${run.opacity}"`:''} mask="url(#${mask})">${surface}</g>`;
 }).join('');
 let coast='';
 // Coastlines belong to the final water/land interface, not individual brush outlines.
 // Chronological black/white coverage honors later painting and solid-color occlusion.
 const coverageRuns=[...terrainRuns(underlying.some(stroke=>stroke.erase)?[]:underlying),...runs];
 if((waterBackground||coverageRuns.some(run=>!!run.material&&isWaterMaterial(run.material)))&&coverageRuns.some(run=>run.material&&!isWaterMaterial(run.material))){
  const coverageGeometry=coverageRuns.map((run,ri)=>alpha([...new Set(run.strokes.map((stroke,si)=>footprint(stroke,width,height,'white',`${prefix}-coverage-${ri}-${si}`)))].join(''),run.opacity));
  const coastBounds=terrainBounds(strokes,width,height,scale),coastExtent=`x="${coastBounds.x}" y="${coastBounds.y}" width="${coastBounds.width}" height="${coastBounds.height}"`;
  const seaCoverage=coverageRuns.map((run,index)=>!!run.material&&isWaterMaterial(run.material)?coverageGeometry[index]:brushInk(coverageGeometry[index],'black')).join('');
  definitions+=`<mask id="${prefix}-sea" ${coastExtent} maskUnits="userSpaceOnUse" style="mask-type:luminance"><rect ${coastExtent} fill="${waterBackground?'white':'black'}"/>${seaCoverage}</mask>`;
  const bands: string[]=[];
  const waterMaterial=[...coverageRuns].reverse().find(run=>run.material&&isWaterMaterial(run.material))?.material??'sea',waterPalette=terrainMaterials[waterMaterial];
  for(const [name,radius,color,opacity] of [['shelf',12,waterPalette.light,.18],['wash',6,waterPalette.light,.35],['ink',1.2,waterPalette.dark,.65]] as const){
   // Grow land footprints and inset later occluders using vector stroke widths.
   // Final sea coverage restricts these narrow bands to the water side of shores.
   const reach=coverageRuns.map((run,ri)=>run.strokes.map((stroke,si)=>{
    const land=!!run.material&&!isWaterMaterial(run.material)&&run.opacity===1&&!(stroke.softness??0),amount=(land?1:-1)*radius*scale;
    const geometry=footprint(stroke,width,height,land?'white':'black',`${prefix}-coast-${name}-${ri}-${si}-clip`);
    return alpha(geometry.replace(/scale\(([\d.]+)\)/g,(_,value)=>`scale(${n(Math.max(0,Number(value)+amount))})`).replace(/(stroke-width|r)="([\d.]+)"/g,(_,attribute,value)=>`${attribute}="${n(Math.max(0,Number(value)+(attribute==='r'?amount:amount*2)))}"`),run.opacity);
   }).join('')).join('');
   definitions+=`<mask id="${prefix}-coast-${name}" ${coastExtent} maskUnits="userSpaceOnUse" style="mask-type:luminance">${reach}</mask>`;
   bands.push(`<rect ${coastExtent} fill="${color}" opacity="${opacity}" mask="url(#${prefix}-coast-${name})"/>`);
  }
  coast=`<g data-terrain-coast="true" mask="url(#${prefix}-sea)" pointer-events="none">${bands.join('')}</g>`;

 }
 return `<defs>${definitions}</defs>${body}${coast}`;
}

/** Freeze ordered visible source indices. Sources always precede their dependent stroke. */
export function captureMaterialMask(drawing:MapDrawing,layers:import('./maps').MapLayer[],target:MaterialMaskTarget,id=crypto.randomUUID()):MaterialMask{
 const order=[undefined,...layers.filter(layer=>layer.visible).map(layer=>layer.id)];
 return {id,target,waterBackground:drawing.background==='#b9d9df',groups:order.map(layerId=>drawing.strokes.flatMap((stroke,index)=>stroke.layerId===layerId?[index]:[])).filter(group=>group.length)};
}
export function matchesMaskMaterial(stroke:DrawingStroke,target:MaterialMaskTarget){
 const water=isTerrainMaterial(stroke.material)?isWaterMaterial(stroke.material):stroke.kind==='water';
 return target==='water'?water:target==='land'?!water:stroke.material===target;
}
/** Acyclic SVG stencil graph: no copied artwork, raster sampling or recursive SVG expansion. */
export function materialMaskDefinitions(drawing:MapDrawing){
 const {width,height}=drawing,extent=`x="0" y="0" width="${width}" height="${height}"`;
 const sources=new Set<number>();drawing.strokes.forEach((stroke,index)=>stroke.materialMask?.groups.forEach(group=>group.forEach(source=>{if(source>=0&&source<index)sources.add(source);})));
 const sourceDefinitions=[...sources].map(index=>(['white','black'] as const).map(paint=>`<g id="ws-material-source-${index}-${paint}">${footprint(drawing.strokes[index],width,height,paint,`ws-material-source-${index}-${paint}-clip`)}</g>`).join('')).join('');
 return sources.size||drawing.strokes.some(stroke=>stroke.materialMask)?`<defs>${sourceDefinitions}${drawing.strokes.map((stroke,index)=>{
  const mask=stroke.materialMask;if(!mask)return '';
  const prefix=`ws-material-${mask.id}`;let definitions='';
  const groups=mask.groups.map((group,gi)=>{
   let body='';
   for(const sourceIndex of group){
    if(!Number.isInteger(sourceIndex)||sourceIndex<0||sourceIndex>=index)continue;
    const source=drawing.strokes[sourceIndex],id=`${prefix}-${gi}-${sourceIndex}`;
    if(source.erase){definitions+=`<mask id="${id}-erase" ${extent} maskUnits="userSpaceOnUse" style="mask-type:luminance"><rect ${extent} fill="white"/>${alpha(`<use href="#ws-material-source-${sourceIndex}-black"/>`,terrainOpacity(source.opacity))}</mask>`;body=`<g mask="url(#${id}-erase)">${body}</g>`;}
    else body+=alpha(`<use href="#ws-material-source-${sourceIndex}-${matchesMaskMaterial(source,mask.target)?'white':'black'}"/>`,terrainOpacity(source.opacity));
   }
   return body;
  }).join('');
  const background=mask.waterBackground&&(mask.target==='water'||mask.target==='sea');
  return `${definitions}<mask id="${prefix}" ${extent} maskUnits="userSpaceOnUse" style="mask-type:luminance"><rect ${extent} fill="${background?'white':'black'}"/>${groups}</mask>`;
 }).join('')}</defs>`:'';
}
