import {parentConnections} from './entryRelations';
import type {EntryRelations} from './entryRelations';
/** Full recorded family, independent of graph/date visibility. No inferred relatives. */
export function familyOverview(relations:EntryRelations,entryId:string){
 const parents=parentConnections(relations);
 return {
  parents:[...new Set(parents.filter(edge=>edge.childId===entryId).map(edge=>edge.parentId))],
  partners:[...new Set(relations.links.filter(link=>!relations.types.find(type=>type.id===link.typeId)?.needsRoleReview&&['partner','formerPartner'].includes(relations.types.find(type=>type.id===link.typeId)?.genealogy?.kind??'')&&(link.sourceId===entryId||link.targetId===entryId)).map(link=>link.sourceId===entryId?link.targetId:link.sourceId))],
  children:[...new Set(parents.filter(edge=>edge.parentId===entryId).map(edge=>edge.childId))],
 };
}
