import {useContext,useRef,useState} from 'react';
import type {ChangeEvent} from 'react';
import {Link2,X,ArrowUpRight,Unlink} from 'lucide-react';
import {TextReferenceContext} from './textReferenceContext';
import {insertTextReference,textReferences,mapTextReferences} from './textReferenceTokens';
import {t} from './i18n';
export function TextEntryLink({entryId,label}:{entryId:string;label:string}){
 const context=useContext(TextReferenceContext),entry=context?.world.entries.find(item=>item.id===entryId);
 if(!context)return <span>{label}</span>;
 if(!entry)return <span className="text-reference-missing" title={t('Missing entry')} aria-label={t('{0} · Missing entry',label)}>{label}<span aria-hidden="true"> ⚠</span></span>;
 return <button type="button" className="text-entry-link" onClick={()=>context.openEntry(entryId)} title={t('Consult {0}',entry.title)+(entry.archived?` · ${t('Archived')}`:'')}>{label}<ArrowUpRight size={11} aria-hidden="true"/></button>;
}
export function ReferenceText({value}:{value:string}){
 const nodes:React.ReactNode[]=[];let from=0;
 for(const ref of textReferences(value)){nodes.push(value.slice(from,ref.from));nodes.push(<TextEntryLink key={ref.from} entryId={ref.entryId} label={ref.label}/>);from=ref.to;}
 nodes.push(value.slice(from));return <>{nodes}</>;
}
export function TextReferenceList({value}:{value:string}){
 const refs=[...new Map(textReferences(value).map(ref=>[ref.entryId,ref])).values()];
 if(!refs.length)return null;
 return <div className="text-reference-list" aria-label={t('Text references')}>{refs.map(ref=><TextEntryLink key={ref.entryId} entryId={ref.entryId} label={ref.label}/>)}</div>;
}
export function TextReferencePicker({onChoose,onClose}:{onChoose:(id:string,title:string)=>void;onClose:()=>void}){
 const context=useContext(TextReferenceContext),[query,setQuery]=useState('');
 const entries=context?.world.entries.filter(entry=>!entry.archived&&[entry.title,...(entry.linkAliases??[])].some(name=>name.toLocaleLowerCase().includes(query.toLocaleLowerCase())))??[];
 return <div className="text-reference-picker" role="group" aria-label={t('Choose an entry reference')} onKeyDown={event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();onClose();}}}><div><input type="search" aria-label={t('Search entries')} value={query} onChange={e=>setQuery(e.target.value)}/><button title={t('Close reference picker')} type="button" className="icon-button ui-close-button" aria-label={t('Close reference picker')} onClick={onClose}><X size={16}/></button></div><div className="text-reference-options">{entries.map(entry=><button type="button" key={entry.id} onClick={()=>onChoose(entry.id,entry.title)}><strong>{entry.title||t('Untitled entry')}</strong><small>{context?.world.templates.find(template=>template.id===entry.templateId)?.title}</small></button>)}{!entries.length&&<p>{t('No matching entries.')}</p>}</div></div>;
}
/** Native textareas retain their existing controlled value, events and selection. */
export function TextReferenceTools({targetId,value,onChange,maxLength}:{targetId:string;value:string;onChange:(event:ChangeEvent<HTMLTextAreaElement>)=>void;maxLength?:number}){
 const context=useContext(TextReferenceContext),[open,setOpen]=useState(false),[error,setError]=useState(''),selection=useRef({from:0,to:0}),trigger=useRef<HTMLButtonElement>(null);
 if(!context)return null;
 const close=()=>{setOpen(false);trigger.current?.focus();};
 return <div className="text-reference-tools"><button ref={trigger} type="button" aria-expanded={open} onMouseDown={e=>e.preventDefault()} onClick={()=>{const element=document.getElementById(targetId) as HTMLTextAreaElement|null;selection.current={from:element?.selectionStart??value.length,to:element?.selectionEnd??value.length};setOpen(!open);setError('');}}><Link2 size={13}/>{t('Link to an entry')}</button><TextReferenceList value={value}/>{[...new Map(textReferences(value).map(ref=>[ref.entryId,ref])).values()].map(ref=><button type="button" className="text-reference-unlink" key={ref.entryId} title={t('Remove references to {0}',ref.label)} aria-label={t('Remove references to {0}',ref.label)} onClick={()=>{const next=mapTextReferences(value,item=>item.entryId===ref.entryId?item.label:value.slice(item.from,item.to));onChange({target:{value:next},currentTarget:{value:next}} as ChangeEvent<HTMLTextAreaElement>);}}><Unlink size={12}/><span>{ref.label}</span></button>)}{open&&<TextReferencePicker onClose={close} onChoose={(entryId,title)=>{const {from,to}=selection.current;const selected=value.slice(from,to);const label=selected.trim()?selected:title||t('Untitled entry');const next=insertTextReference(value,from,to,entryId,label);if(maxLength!==undefined&&next.value.length>maxLength){setError(t('The reference exceeds this field’s character limit.'));return;}onChange({target:{value:next.value},currentTarget:{value:next.value}} as ChangeEvent<HTMLTextAreaElement>);setOpen(false);requestAnimationFrame(()=>{const element=document.getElementById(targetId) as HTMLTextAreaElement|null;element?.focus();element?.setSelectionRange(next.caret,next.caret);});}}/>}{error&&<p role="alert">{error}</p>}</div>;
}
