import {polygonBrushPoints} from './mapBrush';
import type {TerrainBrushShape} from './mapBrush';
import {useEffect,useState} from 'react';
import type {RefObject} from 'react';
import type {RegionPoint} from './mapRegions';
import {mapPoint} from './maps';

/** Decorative hover feedback owns its frame updates, keeping pointer motion out of the editor draft. */
export default function MapPointerPreview({surface,bounds,enabled,width,height,radiusX,radiusY=radiusX,from,standalone=false,geometryKey='',shape='circle',softness=0}:{surface:RefObject<HTMLElement|SVGSVGElement|null>;bounds:RefObject<Element|null>;enabled:boolean;width:number;height:number;radiusX:number;radiusY?:number;from?:RegionPoint;standalone?:boolean;geometryKey?:string;shape?:TerrainBrushShape;softness?:number}){
 const [position,setPosition]=useState<RegionPoint|null>(null);
 useEffect(()=>{
  setPosition(null);const node=surface.current;if(!enabled||!node)return;
  let frame:number|undefined,pending:RegionPoint|null=null,disposed=false;
  const clear=()=>{if(frame!==undefined)cancelAnimationFrame(frame);frame=undefined;pending=null;setPosition(null);};
  const move=(event:PointerEvent)=>{
   if(event.pointerType==='touch'||event.isPrimary===false){clear();return;}
   const rect=bounds.current?.getBoundingClientRect();pending=rect&&rect.width>0&&rect.height>0&&event.clientX>=rect.left&&event.clientX<=rect.left+rect.width&&event.clientY>=rect.top&&event.clientY<=rect.top+rect.height?mapPoint(event.clientX,event.clientY,rect):null;
   if(typeof requestAnimationFrame!=='function'){setPosition(pending);return;}
   if(frame===undefined)frame=requestAnimationFrame(()=>{frame=undefined;if(!disposed)setPosition(pending);});
  };
  node.addEventListener('pointermove',move as EventListener);node.addEventListener('pointerleave',clear);node.addEventListener('pointercancel',clear);window.addEventListener('blur',clear);
  return()=>{disposed=true;clear();node.removeEventListener('pointermove',move as EventListener);node.removeEventListener('pointerleave',clear);node.removeEventListener('pointercancel',clear);window.removeEventListener('blur',clear);};
 },[surface,bounds,enabled,geometryKey]);
 if(!enabled||!position)return null;
 const content=<g className="map-pointer-preview" aria-hidden="true" pointerEvents="none">{from&&<line className="map-pointer-guide" x1={from.x*width} y1={from.y*height} x2={position.x*width} y2={position.y*height} vectorEffect="non-scaling-stroke"/>}{shape!=='circle'?<><polygon className="map-pointer-halo" points={polygonBrushPoints(shape,position.x*width,position.y*height,radiusX,radiusY)} vectorEffect="non-scaling-stroke"/><polygon points={polygonBrushPoints(shape,position.x*width,position.y*height,radiusX,radiusY)} vectorEffect="non-scaling-stroke"/></>:<><ellipse className="map-pointer-halo" cx={position.x*width} cy={position.y*height} rx={radiusX} ry={radiusY} vectorEffect="non-scaling-stroke"/><ellipse cx={position.x*width} cy={position.y*height} rx={radiusX} ry={radiusY} vectorEffect="non-scaling-stroke"/>{softness>0&&softness<1&&<ellipse className="map-pointer-soft-core" cx={position.x*width} cy={position.y*height} rx={radiusX*(1-softness)} ry={radiusY*(1-softness)} vectorEffect="non-scaling-stroke"/>}</>}</g>;
 return standalone?<svg className="map-pointer-preview-overlay" viewBox={`0 0 ${width} ${height}`} preserveAspectRatio="none" aria-hidden="true" focusable="false" pointerEvents="none">{content}</svg>:content;
}
