import {focusDialog} from './dialogFocus';
import MapInspectorHeading from './MapInspectorHeading';
import type {ReactNode} from 'react';
import {TextReferenceTools} from './TextReferenceUI';
import FieldHelp from './FieldHelp';
import RouteTravelReview from './RouteTravelReview';
import RouteManuscriptLinks from './RouteManuscriptLinks';
import type { Chapter } from './model';
import { formatMapNumber } from './MapScalePanel';
import MapLayerSelect from './MapLayerSelect';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ArrowDown, ArrowUp, Plus, Route, Trash2, X } from 'lucide-react';
import {t,buttonLabel} from './i18n';
import Dropdown from './Dropdown';
import { addMapRoute, mapColors, markerLabel, updateMap, updateMapRoute, routeDistances, mapLayerLocked } from './maps';
import type { MapColor, MapMarker, MapRoute, ProjectMaps, WorldMap } from './maps';
import type { Worldbuilding } from './worldbuilding';
export function CreateRouteDialog({markers,world,initialMarkerId,onCancel,onSave}:{markers:MapMarker[];world:Worldbuilding;initialMarkerId:string;onCancel:()=>void;onSave:(title:string,ids:string[])=>void}){
 const dialog=useRef<HTMLDialogElement>(null),previous=useRef(typeof document==='undefined'?null:document.activeElement as HTMLElement|null);
 const [title,setTitle]=useState(''),[from,setFrom]=useState(markers.some(marker=>marker.id===initialMarkerId)?initialMarkerId:markers[0]?.id??''),[to,setTo]=useState('');
 const valid=!!title.trim()&&from!==to&&markers.some(marker=>marker.id===from)&&markers.some(marker=>marker.id===to);
 useEffect(()=>{const node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous.current?.isConnected)previous.current.focus();};},[]);
 const content=<dialog ref={dialog} className="field-create-dialog" aria-labelledby="create-route-title" onCancel={event=>{event.preventDefault();onCancel();}}><header><h2 id="create-route-title">{t('New route')}</h2><button title={t("Close")} type="button" className="icon-button ui-close-button" aria-label={t('Close')} onClick={onCancel}><X size={18}/></button></header><form onSubmit={event=>{event.preventDefault();if(valid)onSave(title.trim(),[from,to]);}}><div className="field-create-body"><label htmlFor="route-new-title">{t('Route name')}</label><input id="route-new-title" required value={title} onChange={event=>setTitle(event.target.value)}/><label htmlFor="route-from">{t('From')}</label><Dropdown id="route-from" aria-label={t('From')} value={from} onChange={value=>{setFrom(value);if(to===value)setTo('');}} options={markers.map(marker=>({value:marker.id,label:markerLabel(marker,world)}))}/><label htmlFor="route-to">{t('To')}</label><Dropdown id="route-to" aria-label={t('To')} value={to} placeholder={t('Choose destination')} onChange={setTo} options={markers.filter(marker=>marker.id!==from).map(marker=>({value:marker.id,label:markerLabel(marker,world)}))}/><p className="field-create-hint">{t('You can add and reorder stops after creating the route.')}</p></div><footer><button type="button" onClick={onCancel} className="quick-action quick-action-text">{t('Cancel')}</button><button type="submit" className="primary-button" disabled={!valid}>{t('Create route')}</button></footer></form></dialog>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}
function DeleteRouteDialog({title,onCancel,onDelete}:{title:string;onCancel:()=>void;onDelete:()=>void}){
 const dialog=useRef<HTMLDialogElement>(null),previous=useRef(typeof document==='undefined'?null:document.activeElement as HTMLElement|null);
 useEffect(()=>{const node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous.current?.isConnected)previous.current.focus();};},[]);
 const content=<dialog ref={dialog} className="manuscript-deletion-dialog" aria-labelledby="delete-route-title" onCancel={event=>{event.preventDefault();onCancel();}}><h2 id="delete-route-title">{t('Delete route?')}</h2><p>{t('Delete “{0}”? Its markers and linked entries are kept.',title)}</p><div className="manuscript-dialog-actions"><button type="button" onClick={onCancel}>{t('Cancel')}</button><button type="button" className="danger-button" onClick={onDelete}>{t('Delete route')}</button></div></dialog>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}
export default function MapRoutesPanel({maps,map,world,markers,routes,selectedId,initialMarkerId,onSelect,onSelectMarker,onChange,chapters=[],onOpenScene,onOpenChapter,detailsOnly=false,headerAction}:{headerAction?:ReactNode;detailsOnly?:boolean;chapters?:Chapter[];onOpenScene?:(id:string)=>void;onOpenChapter?:(id:string)=>void;maps:ProjectMaps;map:WorldMap;world:Worldbuilding;markers:MapMarker[];routes:MapRoute[];selectedId:string;initialMarkerId:string;onSelect:(id:string)=>void;onSelectMarker:(id:string)=>void;onChange:(maps:ProjectMaps)=>void}){
 const [adding,setAdding]=useState(false),[deleting,setDeleting]=useState(false);
 const route=routes.find(route=>route.id===selectedId);
 const distances=route?routeDistances(map,route):null,total=distances?.reduce((sum,distance)=>sum+distance,0);
 function change(patch:Partial<MapRoute>){if(route&&!mapLayerLocked(map,route.layerId))onChange(updateMapRoute('departure' in patch||'arrival' in patch?{...maps,schemaVersion:maps.schemaVersion>=6?maps.schemaVersion:6}:patch.sceneIds||patch.chapterIds?{...maps,schemaVersion:maps.schemaVersion>=5?maps.schemaVersion:5}:maps,map.id,{...route,...patch}));}
 function move(index:number,direction:-1|1){if(!route)return;const ids=[...route.markerIds];[ids[index],ids[index+direction]]=[ids[index+direction],ids[index]];change({markerIds:ids});}
 if(detailsOnly&&!route)return null;
 return <section className="map-routes-panel"><MapInspectorHeading back={headerAction} icon={<Route size={15}/>} title={<>{t(detailsOnly?'Route details':'Routes')}{!detailsOnly&&<span> · {routes.length}</span>}</>} help={<FieldHelp label={t('Routes')} description={t('Connect places by creating a route between markers.')+' '+t('Show at least two markers to create a route.')}/>}/>
  {adding&&<CreateRouteDialog markers={markers} world={world} initialMarkerId={initialMarkerId} onCancel={()=>setAdding(false)} onSave={(title,ids)=>{const next=addMapRoute(maps,map.id,title,ids);if(next){onChange(next.maps);onSelect(next.routeId);setAdding(false);}}}/>}
  {deleting&&route&&<DeleteRouteDialog title={route.title} onCancel={()=>setDeleting(false)} onDelete={()=>{onChange(updateMap(maps,{...map,routes:(map.routes??[]).filter(item=>item.id!==route.id)}));onSelect('');setDeleting(false);}}/>}
  {!detailsOnly&&<>
  <div className="map-route-list">{routes.map(item=><button type="button" key={item.id} aria-pressed={item.id===selectedId} onClick={()=>onSelect(item.id)}><span className="map-route-swatch" style={{background:mapColors[item.color]}}/><span>{item.title||t('Untitled route')}<small>{t('{0} stops',item.markerIds.length)}</small></span></button>)}</div>
  <button type="button" className="quick-action" aria-label={t('New route')} title={markers.length<2?t('Show at least two markers to create a route.'):t('New route')} disabled={markers.length<2} aria-haspopup="dialog" onClick={()=>setAdding(true)}><Route size={14}/><Plus size={10}/></button>
  </>}
  {route&&<fieldset className="map-route-form" disabled={mapLayerLocked(map,route.layerId)}>{distances&&map.scale&&<div className="map-distance-summary" role="status"><strong>{t('Total distance')}: {formatMapNumber(total!)} km</strong><span>{t('Estimated travel')}: {formatMapNumber(total!/map.scale.travelKmPerDay)} {t('days')}</span></div>}<label htmlFor="map-route-title">{t('Route name')}</label><input id="map-route-title" value={route.title} onChange={event=>change({title:event.target.value})}/><h3>{t('Appearance')}</h3><label htmlFor="map-route-color">{t('Color')}</label><Dropdown id="map-route-color" aria-label={t('Route color')} value={route.color} onChange={value=>change({color:value as MapColor})} options={Object.keys(mapColors).map(value=>({value,label:buttonLabel(value[0].toUpperCase()+value.slice(1))}))}/>
   <MapLayerSelect map={map} id="route-layer" value={route.layerId} onChange={layerId=>change({layerId})}/><h3>{t('Stops in order')}</h3><ol>{route.markerIds.map((id,index)=>{const marker=map.markers.find(marker=>marker.id===id);return <li key={id}><button type="button" className="route-stop-name" onClick={()=>onSelectMarker(id)}>{marker?markerLabel(marker,world):t('Missing marker')}<small>{index===0?t('Origin'):index===route.markerIds.length-1?t('Destination'):t('Stop {0}',index+1)}</small>{index>0&&distances&&<small>{formatMapNumber(distances[index-1])} km · {formatMapNumber(distances[index-1]/map.scale!.travelKmPerDay)} {t('days')}</small>}</button><button type="button" aria-label={t('Move stop up')} disabled={index===0} onClick={()=>move(index,-1)}><ArrowUp size={13}/></button><button type="button" aria-label={t('Move stop down')} disabled={index===route.markerIds.length-1} onClick={()=>move(index,1)}><ArrowDown size={13}/></button><button type="button" aria-label={t('Remove stop')} disabled={route.markerIds.length<=2} onClick={()=>change({markerIds:route.markerIds.filter(item=>item!==id)})}><X size={13}/></button></li>;})}</ol>
   <label htmlFor="route-add-stop">{t('Add stop')}</label><Dropdown id="route-add-stop" aria-label={t('Add stop')} value="" placeholder={t('Choose a marker')} options={markers.filter(marker=>!route.markerIds.includes(marker.id)).map(marker=>({value:marker.id,label:markerLabel(marker,world)}))} onChange={id=>change({markerIds:[...route.markerIds,id]})}/>
   <RouteTravelReview map={map} route={route} onChange={change}/><RouteManuscriptLinks route={route} chapters={chapters} onChange={change} onOpenScene={onOpenScene} onOpenChapter={onOpenChapter}/><label htmlFor="map-route-notes">{t('Route notes')}</label><><textarea id="map-route-notes" rows={3} value={route.notes} onChange={event=>change({notes:event.target.value})}/><TextReferenceTools targetId="map-route-notes" value={route.notes} onChange={event=>change({notes:event.target.value})}/></><button type="button" className="danger-button" onClick={()=>setDeleting(true)}><Trash2 size={14}/>{t('Delete route')}</button>
  </fieldset>}
 </section>;
}
