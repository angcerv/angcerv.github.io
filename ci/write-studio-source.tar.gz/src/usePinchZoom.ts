import {useEffect,useRef} from 'react';
import type {RefObject} from 'react';
import {pinchGeometry} from './pinchGesture';
import type {PinchPoint} from './pinchGesture';
type Motion={ratio:number;start:PinchPoint;center:PinchPoint};
export function usePinchZoom<T>(surface:RefObject<HTMLElement|SVGSVGElement|null>,options:{enabled?:boolean;context?:string;start:()=>T;update:(snapshot:T,motion:Motion)=>void;cancel:(snapshot:T)=>void;onActive?:(active:boolean)=>void}){
 const latest=useRef(options);latest.current=options;
 useEffect(()=>{
  const node=surface.current;if(!node||options.enabled===false)return;
  let session:{snapshot:T;ids:number[];distance:number;start:PinchPoint;cancel:(snapshot:T)=>void;ended:boolean}|null=null;
  const pointers=new Map<number,EventTarget|null>();let suppressUntil=0,cancelling=false;
  const editable=(target:EventTarget|null)=>target instanceof Element&&!!target.closest('input,textarea,select,[contenteditable="true"],[role="textbox"]');
  const stop=(event:Event)=>{if(event.cancelable)event.preventDefault();event.stopImmediatePropagation();};
  const gate=(event:PointerEvent)=>{
   if(event.pointerType!=='touch'||cancelling||!session&&editable(event.target))return;
   if(event.type==='pointerdown')pointers.set(event.pointerId,event.target);
   const block=!!session||pointers.size>1;
   if(event.type==='pointerup'||event.type==='pointercancel')pointers.delete(event.pointerId);
   if(block)stop(event);
  };
  const touches=(event:TouchEvent)=>Array.from(event.touches);
  const point=(touch:Touch)=>({x:touch.clientX,y:touch.clientY});
  const start=(event:TouchEvent)=>{
   if(event.touches.length<2||touches(event).some(touch=>editable(touch.target)))return;stop(event);if(session)return;
   const pair=touches(event).slice(0,2),geometry=pinchGeometry(point(pair[0]),point(pair[1]));
   const snapshot=latest.current.start();
   // Cancel child-owned resize/vertex/marker previews too, before blocking subsequent pointer events.
   cancelling=true;
   for(const [pointerId,target] of pointers){if(target instanceof Element)target.dispatchEvent(new PointerEvent('pointercancel',{bubbles:true,pointerId,pointerType:'touch'}));}
   cancelling=false;
   session={snapshot,ids:pair.map(touch=>touch.identifier),distance:geometry.distance,start:geometry.center,cancel:latest.current.cancel,ended:false};
   latest.current.onActive?.(true);
  };
  const move=(event:TouchEvent)=>{
   if(!session)return;stop(event);if(session.ended)return;
   const pair=session.ids.map(id=>touches(event).find(touch=>touch.identifier===id));if(!pair[0]||!pair[1])return;
   const geometry=pinchGeometry(point(pair[0]),point(pair[1]));
   latest.current.update(session.snapshot,{ratio:geometry.distance/session.distance,start:session.start,center:geometry.center});
  };
  const end=(event:TouchEvent)=>{
   if(!session)return;stop(event);
   if(event.type==='touchcancel'&&!session.ended)session.cancel(session.snapshot);
   session.ended=true;suppressUntil=Date.now()+350;
   if(!event.touches.length){session=null;pointers.clear();latest.current.onActive?.(false);}
  };
  const click=(event:MouseEvent)=>{if(event.detail>0&&(session||Date.now()<suppressUntil))stop(event);};
  const pointerEvents=['pointerdown','pointermove','pointerup','pointercancel'] as const;
  for(const type of pointerEvents)node.addEventListener(type,gate as EventListener,true);
  node.addEventListener('touchstart',start as EventListener,{capture:true,passive:false});node.addEventListener('touchmove',move as EventListener,{capture:true,passive:false});
  node.addEventListener('touchend',end as EventListener,{capture:true,passive:false});node.addEventListener('touchcancel',end as EventListener,{capture:true,passive:false});node.addEventListener('click',click as EventListener,true);
  return()=>{if(session&&!session.ended)session.cancel(session.snapshot);latest.current.onActive?.(false);for(const type of pointerEvents)node.removeEventListener(type,gate as EventListener,true);node.removeEventListener('touchstart',start as EventListener,true);node.removeEventListener('touchmove',move as EventListener,true);node.removeEventListener('touchend',end as EventListener,true);node.removeEventListener('touchcancel',end as EventListener,true);node.removeEventListener('click',click as EventListener,true);};
 },[surface,options.enabled,options.context]);
}
