import type {Project} from './model';
import type {ProjectMaps} from './maps';
/** Only explicit route links; chapter membership is labelled, never scene participation. */
export function manuscriptMapRoutes(maps:ProjectMaps,chapterId:string,sceneId?:string){
 return maps.maps.flatMap(map=>(map.routes??[]).flatMap(route=>{
  const direct=sceneId?!!route.sceneIds?.includes(sceneId):!!route.chapterIds?.includes(chapterId),inherited=!!sceneId&&!!route.chapterIds?.includes(chapterId);
  return direct||inherited?[{map,route,direct,inherited}]:[];
 }));
}
/** Marker locations of explicitly linked entries, independent of mentions/templates/routes. */
export function sceneEntryMapMarkers(project:Project,sceneId:string){
 const scene=project.chapters.flatMap(chapter=>chapter.scenes).find(scene=>scene.id===sceneId);if(!scene)return [];
 const ids=new Set(scene.entryIds??[]),entries=new Map((project.worldbuilding?.entries??[]).map(entry=>[entry.id,entry]));
 return (project.maps?.maps??[]).flatMap(map=>map.markers.flatMap(marker=>marker.entryId&&ids.has(marker.entryId)?[{map,marker,entry:entries.get(marker.entryId)}]:[]));
}
