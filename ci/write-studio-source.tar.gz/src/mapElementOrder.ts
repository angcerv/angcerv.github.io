import type {WorldMap,MapMarker,MapRoute} from './maps';
import type {MapRegion} from './mapRegions';
export type GeographicElement={id:string;layerId?:string}&({kind:'marker';value:MapMarker}|{kind:'route';value:MapRoute}|{kind:'region';value:MapRegion});
/** Back to front, first by shared layer, then by the explicit mixed element order. */
export function orderedMapElements(map:WorldMap,markers=map.markers,routes=map.routes??[],regions=map.regions??[]):GeographicElement[]{
 const elements:GeographicElement[]=[...regions.map(value=>({id:value.id,layerId:value.layerId,kind:'region' as const,value})),...routes.map(value=>({id:value.id,layerId:value.layerId,kind:'route' as const,value})),...markers.map(value=>({id:value.id,layerId:value.layerId,kind:'marker' as const,value}))];
 const positions=new Map((map.elementOrder??[]).map((id,index)=>[id,index])),layers=new Map((map.layers??[]).map((layer,index)=>[layer.id,index]));
 const fallback=new Map(elements.map((item,index)=>[item.id,index]));
 const rank=(item:GeographicElement)=>positions.get(item.id)??positions.size+fallback.get(item.id)!;
 return elements.sort((a,b)=>(layers.get(a.layerId??'')??-1)-(layers.get(b.layerId??'')??-1)||rank(a)-rank(b));
}
export function mapElementStack(map:WorldMap){return new Map(orderedMapElements(map).map((item,index)=>[item.id,index+1]));}
/** A drag changes the displayed subset only. Hidden elements keep their slots. */
export function reorderMapElements(map:WorldMap,frontToBackIds:string[]):WorldMap{
 const elements=orderedMapElements(map),ids=[...frontToBackIds].reverse(),chosen=new Set(ids),byId=new Map(elements.map(item=>[item.id,item]));
 if(chosen.size!==ids.length||ids.some(id=>!byId.has(id)))return map;
 const layer=byId.get(ids[0])?.layerId;if(ids.some(id=>byId.get(id)?.layerId!==layer)||layer&&map.layers?.find(item=>item.id===layer)?.locked)return map;
 let index=0;const order=elements.map(item=>chosen.has(item.id)?ids[index++]:item.id);
 if(order.every((id,i)=>id===elements[i].id))return map;
 return {...map,elementOrder:order};
}

/** Move membership and stacking in one geographic history step. */
export function moveMapElement(map:WorldMap,id:string,layerId?:string,beforeId?:string):WorldMap{
 layerId=layerId||undefined;
 const elements=orderedMapElements(map),item=elements.find(item=>item.id===id);
 if(!item||layerId&&!map.layers?.some(layer=>layer.id===layerId)||map.layers?.some(layer=>layer.locked&&(layer.id===item.layerId||layer.id===layerId)))return map;
 if(beforeId&&!elements.some(item=>item.id===beforeId&&item.layerId===layerId&&item.id!==id))return map;
 const key=item.kind==='marker'?'markers':item.kind==='route'?'routes':'regions';
 const next:WorldMap=item.layerId===layerId?map:{...map,[key]:(map[key]??[]).map(value=>value.id===id?{...value,layerId}:value)};
 const order=orderedMapElements(next).map(item=>item.id).filter(value=>value!==id);
 // The list is front-to-back, so insertion before a row paints after that row.
 const lastPeer=elements.filter(item=>item.id!==id&&item.layerId===layerId)[0];
 const position=beforeId?order.indexOf(beforeId)+1:lastPeer?order.indexOf(lastPeer.id):order.length;
 order.splice(position,0,id);
 return {...next,elementOrder:order};
}
