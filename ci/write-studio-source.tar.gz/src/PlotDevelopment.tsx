import { TextReferenceTools } from './TextReferenceUI';
import { useEffect, useId, useRef, useState } from 'react';
import { useWorkspaceState } from './useWorkspaceState';
import { ArrowUpRight, X } from 'lucide-react';
import { t } from './i18n';
import type { Project } from './model';
import type { PlotThread } from './plotThreads';
import { plotChapterTracks } from './plotThreads';
import { mapColors } from './maps';
import type { CSSProperties } from 'react';

type Selection = { plotId:string; chapterId:string; sceneId:string|null };
type Props = {project:Project;plots:PlotThread[];selectedId:string;mode?:'visual'|'table';active?:boolean;onSelect:(id:string)=>void;onOpenPlot:(id:string)=>void;onOpenScene:(id:string)=>void;onOpenChapter?:(id:string)=>void;onChangeNote:(plotId:string,sceneId:string,note:string)=>void};
export default function PlotDevelopment({project,plots,selectedId,mode='visual',active=true,onSelect,onOpenPlot,onOpenScene,onOpenChapter,onChangeNote}:Props) {
 const [selection,setSelection]=useWorkspaceState<Selection|null>('plots.point',null);
 const [compact,setCompact]=useState(false),id=useId();
 const root=useRef<HTMLDivElement>(null),trigger=useRef<HTMLButtonElement|null>(null),inspector=useRef<HTMLDialogElement>(null);
 const chosenPlot=plots.find(plot=>plot.id===selection?.plotId);
 const chapter=project.chapters.find(c=>c.id===selection?.chapterId);
 const scenes=chapter?.scenes.filter(scene=>chosenPlot?.beats.some(beat=>beat.sceneId===scene.id))??[];
 const scene=scenes.find(scene=>scene.id===selection?.sceneId),beat=chosenPlot?.beats.find(beat=>beat.sceneId===scene?.id);
 const noteId=`${id}-note-${chosenPlot?.id}-${scene?.id}`;
 const show=!!(chosenPlot&&chapter&&scenes.length&&(!selection?.sceneId||scene));
 useEffect(()=>{if(selection&&!show)setSelection(null);},[selection,show]);
 // Match the inspector layout to actual workspace width, including desktop resizing.
 useEffect(()=>{
  const element=root.current;if(!element)return;
  const measure=()=>{if(element.clientWidth>0)setCompact(element.clientWidth<900);};
  measure();const observer=new ResizeObserver(()=>{if(element.clientWidth)measure();});observer.observe(element);
  return()=>observer.disconnect();
 },[]);
 useEffect(()=>{
  const panel=inspector.current;if(!panel)return;
  if(!active||!show){panel.close();return;}
  if(panel.open&&panel.matches(':modal')!==compact)panel.close();
  if(!panel.open){if(compact)panel.showModal();else panel.show();panel.focus({preventScroll:true});}
  return()=>panel.close();
 },[active,show,compact]);
 function open(plot:PlotThread,chapterId:string,sceneId:string|null,button:HTMLButtonElement){
  trigger.current=button;setSelection({plotId:plot.id,chapterId,sceneId});onSelect(plot.id);
 }
 function close(){
  // A view switch can hide the original trigger. Focus its visible equivalent.
  const controls=Array.from(root.current?.querySelectorAll<HTMLButtonElement>('button')??[]);
  const equivalent=controls.find(button=>mode==='table'?button.dataset.countKey===`${selection?.plotId}:${selection?.chapterId}`:button.dataset.pointKey===`${selection?.plotId}:${selection?.sceneId}`);
  const target=equivalent??(trigger.current&&!trigger.current.closest('[hidden]')?trigger.current:null)??controls.find(button=>button.dataset.plotKey===selection?.plotId);
  inspector.current?.close();setSelection(null);target?.focus({preventScroll:true});
 }
 return <div ref={root} hidden={!plots.length} className={`plot-development${show?' has-inspector':''}`} data-compact={compact} onKeyDown={event=>{if(event.key==='Escape'&&show&&active&&!event.defaultPrevented){event.preventDefault();event.stopPropagation();close();}}}>
  <div className="plot-development-main">
   <p className="plot-development-key">{mode==='table'?t('Table numbers count linked scenes.'):t('Line numbers identify scenes within each chapter.')}</p>
   <div className="plot-development-scroll" hidden={mode==='table'} tabIndex={0} role="region" aria-label={t('Visual plot development')}>
    <table className="plot-development-table" style={{width:190+project.chapters.reduce((n,c)=>n+Math.max(160,c.scenes.length*34+20),0)}}>
     <caption className="visually-hidden">{t('Plots and their scenes by chapter')}</caption>
     <colgroup><col style={{width:190}}/>{project.chapters.map(c=><col key={c.id} style={{width:Math.max(160,c.scenes.length*34+20)}}/>)}</colgroup>
     <thead><tr><th scope="col">{t('Plot')}</th>{project.chapters.map((c,index)=><th scope="col" key={c.id}>{onOpenChapter?<button type="button" className="plot-development-chapter" title={t('Open chapter: {0}',c.title||t('Untitled chapter'))} onClick={()=>onOpenChapter(c.id)}><span>{t('Chapter {0}',index+1)}</span><strong>{c.title||t('Untitled chapter')}</strong></button>:<><span>{t('Chapter {0}',index+1)}</span><strong>{c.title||t('Untitled chapter')}</strong></>}</th>)}</tr></thead>
     <tbody>{plots.map(plot=><tr key={plot.id} className={selectedId===plot.id?'is-selected':''} style={{'--plot-color':mapColors[plot.color]} as CSSProperties}>
      <th scope="row"><button type="button" className="plot-development-name" data-plot-key={plot.id} onClick={()=>onOpenPlot(plot.id)}><span className="plot-color-dot" style={{background:mapColors[plot.color]}}/><span>{plot.title||t('Untitled plot')}</span></button></th>
      {plotChapterTracks(project,plot).map(track=><td key={track.chapter.id}><div className="plot-development-track" style={{gridTemplateColumns:`repeat(${Math.max(1,track.slots.length)},minmax(0,1fr))`}}>
       {track.active&&<span aria-hidden="true" className={`plot-development-rail${track.gap?' is-pause':''}`} style={{left:`${track.start}%`,width:`${track.end-track.start}%`}}/>}
       {track.slots.map(({scene,sceneIndex,beat})=>beat?<button type="button" key={scene.id} data-point-key={`${plot.id}:${scene.id}`} className="plot-development-point" aria-label={t('{0} · {1} · Scene {2}: {3}',plot.title||t('Untitled plot'),track.chapter.title||t('Untitled chapter'),sceneIndex+1,scene.title||t('Untitled scene'))} title={scene.title||t('Untitled scene')} aria-pressed={selection?.plotId===plot.id&&selection.sceneId===scene.id} aria-controls={selection?.plotId===plot.id&&selection.sceneId===scene.id?`${id}-inspector`:undefined} onClick={event=>open(plot,track.chapter.id,scene.id,event.currentTarget)}>{sceneIndex+1}</button>:<span key={scene.id} className="plot-development-slot" aria-hidden="true"/>)}
       {!track.slots.some(slot=>slot.beat)&&<span className="visually-hidden">{t('No linked scenes')}</span>}
      </div></td>)}
     </tr>)}</tbody>
    </table>
   </div>
   <div className="plot-matrix-scroll" hidden={mode!=='table'} tabIndex={0} role="region" aria-label={t('Development by chapter')}>
    <table><caption className="visually-hidden">{t('Development by chapter')}</caption><thead><tr><th scope="col">{t('Plot')}</th>{project.chapters.map((c,index)=><th scope="col" key={c.id}>{t('Chapter {0}',index+1)}<strong>{c.title||t('Untitled chapter')}</strong></th>)}</tr></thead>
     <tbody>{plots.map(plot=><tr key={plot.id} className={selectedId===plot.id?'selected':''}>
      <th scope="row"><button type="button" onClick={()=>onOpenPlot(plot.id)}><span className="plot-color-dot" style={{background:mapColors[plot.color]}}/>{plot.title||t('Untitled plot')}</button></th>
      {plotChapterTracks(project,plot).map(track=>{const linked=track.slots.filter(slot=>slot.beat);return <td key={track.chapter.id}>{linked.length?<button type="button" className="plot-chapter-present" data-count-key={`${plot.id}:${track.chapter.id}`} aria-label={t('{0} · {1}: {2} linked scenes',plot.title||t('Untitled plot'),track.chapter.title||t('Untitled chapter'),linked.length)} aria-pressed={selection?.plotId===plot.id&&selection.chapterId===track.chapter.id} aria-controls={selection?.plotId===plot.id&&selection.chapterId===track.chapter.id?`${id}-inspector`:undefined} style={{borderColor:mapColors[plot.color]}} onClick={event=>open(plot,track.chapter.id,linked.length===1?linked[0].scene.id:null,event.currentTarget)}>{linked.length}</button>:<span title={t('No linked scenes')}>—</span>}</td>;})}
     </tr>)}</tbody>
    </table>
   </div>
   {!project.chapters.length&&<p className="world-hint">{t('Add chapters and link scenes to see how your plots develop.')}</p>}
   <p className="plot-development-legend"><span className="plot-legend-line" aria-hidden="true"/>{t('Plot appearances')}<span className="plot-legend-line is-pause" aria-hidden="true"/>{t('Pause between appearances')}</p>
  </div>
  {show&&chosenPlot&&chapter&&<dialog ref={inspector} id={`${id}-inspector`} tabIndex={-1} className="plot-point-inspector" aria-labelledby={`${id}-title`} onCancel={event=>{event.preventDefault();close();}}>
   <div className="plot-inspector-body"><div className="plot-inspector-content">
   <header><div><small>{chosenPlot.title||t('Untitled plot')} · {chapter.title||t('Untitled chapter')}</small><h3 id={`${id}-title`}>{scene?t('Scene {0}: {1}',chapter.scenes.findIndex(s=>s.id===scene.id)+1,scene.title||t('Untitled scene')):t('Linked scenes')}</h3></div><button type="button" className="quick-action ui-close-button" title={t('Close scene detail')} aria-label={t('Close scene detail')} onClick={close}><X size={16}/></button></header>
   {scenes.length>1&&<nav className="plot-inspector-scenes" aria-label={t('Linked scenes')}>{scenes.map(item=><button type="button" key={item.id} aria-pressed={scene?.id===item.id} onClick={()=>setSelection({plotId:chosenPlot.id,chapterId:chapter.id,sceneId:item.id})}>{t('Scene {0}: {1}',chapter.scenes.findIndex(s=>s.id===item.id)+1,item.title||t('Untitled scene'))}</button>)}</nav>}
   {scene&&beat&&<div key={`${chosenPlot.id}:${scene.id}`} className="plot-inspector-edit"><label htmlFor={noteId}>{t('What advances in this scene?')}</label><textarea id={noteId} rows={6} value={beat.note} onChange={event=>onChangeNote(chosenPlot.id,scene.id,event.target.value)}/><TextReferenceTools targetId={noteId} value={beat.note} onChange={event=>onChangeNote(chosenPlot.id,scene.id,event.target.value)}/><button type="button" className="quick-action quick-action-text" onClick={()=>onOpenScene(scene.id)}><ArrowUpRight size={15}/>{t('Open scene in manuscript')}</button></div>}
   </div></div>
  </dialog>}
 </div>;
}
