import {focusDialog} from './dialogFocus';
import {X} from 'lucide-react';
import {TextReferenceTools} from './TextReferenceUI';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { t } from './i18n';
import type { CommentDraft, ReviewComment } from './reviewComments';
export default function ReviewCommentDialog({draft,onClose,onSave}:{draft:CommentDraft;onClose:()=>void;onSave:(comment:ReviewComment)=>void}){
 const ref=useRef<HTMLDialogElement>(null),[text,setText]=useState(draft.comment?.text??'');
 useEffect(()=>{ref.current?.showModal();focusDialog(ref.current);return()=>ref.current?.close();},[]);
 const content=<dialog ref={ref} className="field-create-dialog review-comment-dialog" aria-labelledby="review-comment-title" onCancel={e=>{e.preventDefault();onClose();}}><header className="ui-dialog-heading"><h2 id="review-comment-title">{t('Review comment')}</h2><button type="button" className="icon-button ui-close-button" aria-label={t('Close')} title={t('Close')} onClick={onClose}><X size={18} aria-hidden="true"/></button></header><form onSubmit={e=>{e.preventDefault();if(text.trim())onSave({...draft.comment,id:draft.comment?.id??crypto.randomUUID(),from:draft.from,to:draft.to,quote:draft.quote,text:text.trim(),resolved:draft.comment?.resolved??false});}}><div className="field-create-body"><blockquote>{draft.quote}</blockquote><label htmlFor="review-comment-text">{t('Comment')}</label><><textarea id="review-comment-text" required maxLength={10000} rows={5} value={text} onChange={e=>setText(e.target.value)}/><TextReferenceTools targetId="review-comment-text" value={text} onChange={e=>setText(e.target.value)} maxLength={10000}/></></div><footer><button type="button" onClick={onClose} className="quick-action quick-action-text">{t('Cancel')}</button><button type="submit" className="primary-button" disabled={!text.trim()}>{t('Save comment')}</button></footer></form></dialog>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}
