import { Check } from 'lucide-react';
import { useEffect, useState } from 'react';
import { t, message } from './i18n';
import { formatStoryDate, parseStoryDate } from './timeline';
import type { StoryDate } from './timeline';
export default function StoryDateInput({id,value,onChange,compact=false,applyLabel=false}:{compact?:boolean;applyLabel?:boolean;id:string;value:StoryDate|undefined;onChange:(value:StoryDate|null)=>void}) {
 const stored=formatStoryDate(value),[draft,setDraft]=useState(stored),[error,setError]=useState('');
 useEffect(()=>{setDraft(stored);setError('');},[stored]);
 const dirty=draft.trim()!==stored;
 function apply(){if(!dirty)return;try{const date=parseStoryDate(draft);setError('');onChange(date??null);setDraft(formatStoryDate(date));}catch(error){setError(String(error));}}
 return <div className={`story-date-input${applyLabel?' story-date-input-labelled':''}`}><div className="date-input-with-action"><input id={id} aria-describedby={[!compact?`${id}-hint`:'',error?`${id}-error`:''].filter(Boolean).join(' ')||undefined} aria-invalid={!!error} value={draft} placeholder={applyLabel?undefined:t('Year, year-MM or year-MM-DD')} maxLength={13} onChange={event=>{setDraft(event.target.value);setError('');}} onBlur={apply} onKeyDown={event=>{if(event.key==='Enter'){event.preventDefault();apply();}}}/><button type="button" className="quick-action date-input-apply" aria-label={t('Apply date')} title={t('Apply date')} disabled={!dirty} onPointerDown={event=>event.preventDefault()} onClick={apply}><Check size={15} aria-hidden="true"/>{applyLabel&&t('Apply')}</button></div><small hidden={compact} id={`${id}-hint`}>{t('Year, month or complete date. Negative years and year 0 are supported.')}</small>{error&&<p id={`${id}-error`} role="alert" className="prompt-error">{message(error)}</p>}</div>;
}
