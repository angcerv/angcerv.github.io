import {useEffect,useMemo,useState} from 'react';
import type {CSSProperties} from 'react';
import {ChevronLeft,ChevronRight,Focus,Pencil} from 'lucide-react';
import Dropdown from './Dropdown';
import FieldHelp from './FieldHelp';
import CalendarEventButton from './CalendarEventButton';
import {useWorkspaceState} from './useWorkspaceState';
import {calendarFromStoryDate,calendarWorldDateContext,calendarWorldDateLabel,calendarYearLabel} from './storyCalendar';
import type {StoryCalendar} from './storyCalendar';
import {adjacentCalendarMonth,calendarDayEvents,calendarEventRanges,calendarMonthPage,initialCalendarPosition,positionForCalendarDate} from './calendarBrowse';
import type {CalendarPosition} from './calendarBrowse';
import type {StoryDate,TimelineEvent} from './timeline';
import {t} from './i18n';
export default function StoryCalendarView({calendar,events,selectedId,onSelectEvent,onConfigure,onDayChange,onSelectDay}:{onDayChange?:(date:StoryDate)=>void;onSelectDay?:(date:StoryDate)=>void;calendar?:StoryCalendar;events:TimelineEvent[];selectedId:string;onSelectEvent:(id:string)=>void;onConfigure:()=>void}){
 if(!calendar)return <div className="ui-empty-state"><p>{t('Configure the world calendar to browse its years and months.')}</p><button type="button" className="primary-button" onClick={onConfigure}><Pencil size={16}/>{t('Configure calendar')}</button></div>;
 return <CalendarBrowser calendar={calendar} events={events} selectedId={selectedId} onSelectEvent={onSelectEvent} onDayChange={onDayChange} onSelectDay={onSelectDay}/>;
}
export function CalendarBrowser({calendar,events,selectedId,onSelectEvent,onDayChange,onSelectDay}:{onDayChange?:(date:StoryDate)=>void;onSelectDay?:(date:StoryDate)=>void;calendar:StoryCalendar;events:TimelineEvent[];selectedId:string;onSelectEvent:(id:string)=>void}){
 const [position,setPosition]=useWorkspaceState<CalendarPosition>('timeline.calendar.position',()=>initialCalendarPosition(calendar,events,selectedId));
 const page=calendarMonthPage(calendar,position),[year,setYear]=useState(String(page.year)),[error,setError]=useState(''),[uncertainShown,setUncertainShown]=useState(50);
 const ranges=useMemo(()=>calendarEventRanges(events),[events]),previous=adjacentCalendarMonth(calendar,page,-1),next=adjacentCalendarMonth(calendar,page,1);
 useEffect(()=>{setYear(String(page.year));setError('');},[page.year]);
 useEffect(()=>{onDayChange?.({year:page.year,month:page.month,day:page.day});},[page.year,page.month,page.day,onDayChange]);
 let selectedPosition:CalendarPosition|undefined;const selected=events.find(event=>event.id===selectedId);
 if(selected?.start?.month&&selected.start.day)try{selectedPosition=positionForCalendarDate(calendar,calendarFromStoryDate(selected.start,calendar));}catch{/* Keep unsupported dates in the ordinary inspector. */}
 function browse(patch:Partial<CalendarPosition>){setPosition({year:page.year,month:page.month,page:page.page,day:page.day,...patch});}
 function turnPage(direction:-1|1){const next=calendarMonthPage(calendar,{year:page.year,month:page.month,day:page.day,page:page.page+direction});browse({page:next.page,day:next.first});}
 function go(next:CalendarPosition){setPosition(next);setYear(String(next.year));setError('');}
 const eventButton=(event:TimelineEvent)=><CalendarEventButton key={event.id} event={event} selected={event.id===selectedId} onSelect={onSelectEvent}/>;
 return <section className="calendar-browser" aria-label={t('Calendar view')}>
  <header className="calendar-browser-heading"><h2>{calendar.name}</h2></header>
  <div className="calendar-browser-controls"><div className="calendar-browser-month-controls"><button type="button" className="quick-action" aria-label={t('Previous month')} title={t('Previous month')} disabled={!previous} onClick={()=>previous&&go(previous)}><ChevronLeft size={16}/></button><label>{t('Month')}<Dropdown id="calendar-browse-month" value={String(page.month)} options={calendar.months.map((month,index)=>({value:String(index+1),label:month.name}))} onChange={value=>go({year:page.year,month:Number(value),page:0,day:1})}/></label><button type="button" className="quick-action" aria-label={t('Next month')} title={t('Next month')} disabled={!next} onClick={()=>next&&go(next)}><ChevronRight size={16}/></button></div><form className="calendar-browser-year-controls" noValidate onSubmit={event=>{event.preventDefault();const value=Number(year);if(!year.trim()||!Number.isInteger(value)||value<-999999||value>999999){setError(t('Enter a world year between -999999 and 999999.'));return;}go({year:value,month:page.month,page:0,day:1});}}><label>{t('Year')}<input type="number" min={-999999} max={999999} step={1} value={year} aria-invalid={!!error} aria-describedby={error?'calendar-browse-error':undefined} onChange={event=>{setYear(event.target.value);setError('');}}/></label><button type="submit" className="quick-action quick-action-text">{t('Go')}</button></form><div className="calendar-browser-utilities"><button type="button" className="quick-action" disabled={!selectedPosition} aria-label={t('Locate selected event')} title={t('Locate selected event')} onClick={()=>selectedPosition&&go(selectedPosition)}><Focus size={16}/></button><FieldHelp variant="toolbar" label={t('Calendar dates')} description={t('Browse using world years, including negative years and year 0. Events follow the current timeline filters. Only complete dates are placed on days.')}/></div></div>
  {error&&<p id="calendar-browse-error" className="prompt-error" role="alert">{error}</p>}
  <p className={`calendar-browser-period${calendarYearLabel(page.year,calendar)===String(page.year)?' visually-hidden':''}`} role="status">{calendar.months[page.month-1].name} · {calendarYearLabel(page.year,calendar)}</p>
  <div className="calendar-browser-scroll"><div className="calendar-browser-grid" style={{'--calendar-columns':calendar.weekdays.length} as CSSProperties}>
   <div className="calendar-browser-weekdays">{calendar.weekdays.map(name=><span key={name}>{name}</span>)}</div>
   <div className="calendar-browser-days">{page.cells.map((cell,index)=>{
    if(!cell)return <span key={`empty-${index}`} aria-hidden="true" className="calendar-browser-empty-day"/>;
    const context=calendarWorldDateContext(cell,calendar),matches=calendarDayEvents(cell,calendar,ranges.exact),seasonStart=calendar.seasons?.some(season=>season.month===cell.month&&season.day===cell.day);
    return <button type="button" key={cell.day} className="calendar-browser-day" aria-pressed={page.day===cell.day} aria-label={[calendarWorldDateLabel(cell,calendar),context.season?.name,...context.holidays.map(item=>item.name),t('{0} events',matches.length)].filter(Boolean).join(' · ')} onClick={()=>{browse({day:cell.day});onSelectDay?.(cell);}}><strong>{cell.day}</strong>{seasonStart&&<span className="calendar-browser-season">{context.season?.name}</span>}{context.holidays.slice(0,2).map(holiday=><span key={holiday.name} className="calendar-browser-holiday">{holiday.name}</span>)}{context.holidays.length>2&&<small>{t('{0} more holidays',context.holidays.length-2)}</small>}{matches.length>0&&<small className="calendar-browser-event-count">{t('{0} events',matches.length)}</small>}</button>;
   })}</div></div>
   {page.pages>1&&<div className="calendar-browser-paging"><button type="button" className="quick-action" title={t('Previous weeks')} aria-label={t('Previous weeks')} disabled={page.page===0} onClick={()=>turnPage(-1)}><ChevronLeft size={16}/></button><span>{t('Days {0}–{1} of {2}',page.first,page.last,page.days)}</span><button type="button" className="quick-action" title={t('Next weeks')} aria-label={t('Next weeks')} disabled={page.page===page.pages-1} onClick={()=>turnPage(1)}><ChevronRight size={16}/></button></div>}
   {ranges.uncertain.length>0&&<details className="calendar-browser-uncertain timeline-form-disclosure"><summary>{t('Events without an exact date')} <span className="compact-count">{ranges.uncertain.length}</span></summary><p>{t('These events have undated or incomplete dates and are not assigned to a specific calendar day.')}</p>{ranges.uncertain.slice(0,uncertainShown).map(eventButton)}{ranges.uncertain.length>uncertainShown&&<button type="button" className="quick-action quick-action-text" onClick={()=>setUncertainShown(uncertainShown+50)}>{t('Show more events')}</button>}</details>}
  </div>

 </section>;
}
