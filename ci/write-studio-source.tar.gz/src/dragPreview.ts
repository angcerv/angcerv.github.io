/** A visual-only copy in the top layer: keeps inherited styles and never intercepts drops. */
export function createDragPreview(source:HTMLElement|null,x:number,y:number){
 if(!source)return;
 const rect=source.getBoundingClientRect();
 const copy=source.cloneNode(true) as HTMLElement;
 copy.removeAttribute('id');
 copy.querySelectorAll('[id]').forEach(node=>node.removeAttribute('id'));
 copy.querySelectorAll('dialog').forEach(node=>node.remove());
 copy.classList.remove('dragging','is-moving','drop-before','drop-after','is-drop-target');
 copy.classList.add('ui-drag-preview');
 copy.setAttribute('aria-hidden','true');copy.inert=true;
 copy.setAttribute('popover','manual');
 Object.assign(copy.style,{position:'fixed',inset:'auto',margin:'0',boxSizing:'border-box',width:`${rect.width}px`,height:`${rect.height}px`,minWidth:'0',maxWidth:'none',pointerEvents:'none',opacity:'1',transition:'none',animation:'none'});
 let shown=false;
 return {
  move(clientX:number,clientY:number){
   if(!shown){source.parentElement?.append(copy);copy.showPopover();shown=true;}
   copy.style.left=`${rect.left+clientX-x}px`;copy.style.top=`${rect.top+clientY-y}px`;
  },
  remove(){copy.remove();}
 };
}
