import ActionMenu from './ActionMenu';
import ProjectModal from './ProjectModal';
import {useRef,useState} from 'react';
import {BookmarkPlus,LayoutList,Trash2,Ellipsis} from 'lucide-react';
import type {Template} from './worldbuilding';
import {readWorldAccess,rememberWorldAccess} from './worldSavedAccess';
import type {WorldView,SavedWorldAccess} from './worldSavedAccess';
import {editorialLabels,canonLabels} from './entryEditorial';
import {t} from './i18n';

export function sameWorldView(a:WorldView,b:WorldView){
 return a.query===b.query&&a.templateId===b.templateId&&a.archived===b.archived&&a.editorial===b.editorial&&(a.canon??'')===(b.canon??'')&&!!a.favoritesOnly===!!b.favoritesOnly&&a.order===b.order;
}
export function useWorldSavedAccess(projectId:string){
 const [state,setState]=useState(()=>({projectId,saved:readWorldAccess(projectId),error:''}));
 const current=state.projectId===projectId?state:{projectId,saved:readWorldAccess(projectId),error:''};
 if(current!==state)setState(current);
 function save(saved:SavedWorldAccess){setState({projectId,saved,error:rememberWorldAccess(projectId,saved)?'':t('Could not save views and favorites on this device.')});}
 return {...current,save};
}
export default function WorldSavedAccess({access,templates=[],view,onApply}:{access:ReturnType<typeof useWorldSavedAccess>;templates?:Template[];view:WorldView;onApply:(view:WorldView)=>void}){
 const {saved,save}=access;
 const [mode,setMode]=useState<'save'|'manage'|null>(null),[name,setName]=useState('');
 const origin=useRef<HTMLDivElement>(null);
 function close(){setMode(null);setName('');origin.current?.querySelector<HTMLButtonElement>('button')?.focus({preventScroll:true});}
 function description(value:WorldView){
  const parts=[value.templateId?templates.find(template=>template.id===value.templateId)?.title||t('Missing template'):t('All templates'),t(value.archived?'Archived':'Active')];
  if(value.editorial)parts.push(t(value.editorial==='unclassified'?'Unclassified':editorialLabels[value.editorial as keyof typeof editorialLabels]));
  if(value.canon)parts.push(t(value.canon==='unclassified'?'Unclassified':canonLabels[value.canon as keyof typeof canonLabels]));
  if(value.favoritesOnly)parts.push(t('Favorites only'));
  if(value.query)parts.push('“'+value.query+'”');
  const orders={alphabetical:'Name: A–Z',reverseAlphabetical:'Name: Z–A',recentlyModified:'Recently modified',oldestModified:'Oldest modifications first'};
  parts.push(t(orders[value.order]));
  return parts.join(' · ');
 }
 return <div ref={origin} className="world-view-menu"><ActionMenu animated iconOnly label={t('Entry list options')} actions={[{label:t('Save current view'),icon:<BookmarkPlus size={16}/>,onClick:()=>setMode('save')},{label:t('Saved views'),icon:<LayoutList size={16}/>,disabled:!saved.views.length,disabledReason:t('No saved views.'),onClick:()=>setMode('manage')}]}><Ellipsis size={16}/></ActionMenu>
 {mode&&<ProjectModal title={t(mode==='save'?'Save current view':'Saved views')} onClose={close}>
 {mode==='save'?<form className="world-save-view-form" onSubmit={event=>{event.preventDefault();if(!name.trim())return;save({...saved,views:[...saved.views,{id:crypto.randomUUID(),name:name.trim(),view:{...view}}].slice(-50)});close();}}><label htmlFor="world-shortcut-name">{t('View name')}</label><input id="world-shortcut-name" required maxLength={80} value={name} onChange={event=>setName(event.target.value)}/><div className="welcome-actions"><button type="button" onClick={close} className="quick-action quick-action-text">{t('Cancel')}</button><button type="submit" className="primary-button" disabled={!name.trim()}>{t('Save')}</button></div></form>:<div className="world-saved-list">{saved.views.map(item=><div className="world-saved-row" key={item.id}><button type="button" className="world-saved-view" aria-label={item.name} aria-pressed={sameWorldView(view,item.view)} onClick={()=>{onApply(item.view);close();}}><strong>{item.name}</strong><small>{description(item.view)}</small></button><button type="button" className="quick-action destructive-action" aria-label={t('Delete saved view: {0}',item.name)} title={t('Delete saved view')} onClick={()=>save({...saved,views:saved.views.filter(value=>value.id!==item.id)})}><Trash2 size={14}/></button></div>)}{!saved.views.length&&<p className="ui-empty-state ui-empty-state-compact">{t('No saved views.')}</p>}</div>}
 </ProjectModal>}</div>;
}
