import type {Project} from './model';
import type {ContinuityIssue} from './continuity';
import {sceneMentions} from './mentionDetection';
import {emptyWorld} from './worldbuilding';
import {timelineEventEntryIds,eventDateLabel,formatStoryDate} from './timeline';
import {entryBirthDate} from './ages';
import {reviewRouteTravel} from './travelContinuity';
import {t,locale} from './i18n';
export type ContinuityGrouping='entry'|'scene'|'plot'|'none';
export type ContinuityContext={entryIds:string[];sceneIds:string[];plotIds:string[]};
export type ContinuityGroup={id:string;title:string;detail?:string;issues:ContinuityIssue[]};
export function continuityContexts(project:Project,issues:ContinuityIssue[]):Map<string,ContinuityContext>{
 const world=project.worldbuilding??emptyWorld,sceneEntries=new Map<string,Set<string>>();
 for(const chapter of project.chapters)for(const scene of chapter.scenes){const ids=new Set(scene.entryIds??[]);for(const mention of sceneMentions(scene,world))if(mention.entryIds.length===1)ids.add(mention.entryIds[0]);sceneEntries.set(scene.id,ids);}
 const result=new Map<string,ContinuityContext>();
 for(const issue of issues){
  const scenes=new Set([...(issue.sceneId?[issue.sceneId]:[]),...(issue.relatedSceneIds??[])]),entries=new Set([...(issue.entryId?[issue.entryId]:[]),...(issue.candidateIds??[])]),plots=new Set<string>();
  const event=(project.timeline?.events??[]).find(event=>event.id===issue.eventId);
  if(event){for(const id of event.sceneIds)scenes.add(id);for(const id of timelineEventEntryIds(event))entries.add(id);for(const id of event.plotIds??[])plots.add(id);}
  const map=project.maps?.maps.find(map=>map.id===issue.mapId),route=map?.routes?.find(route=>route.id===issue.routeId);
  for(const id of route?.sceneIds??[])scenes.add(id);
  for(const id of scenes)for(const entryId of sceneEntries.get(id)??[])entries.add(entryId);
  for(const plot of project.plots?.threads??[])if(plot.beats.some(beat=>scenes.has(beat.sceneId)))plots.add(plot.id);
  result.set(issue.id,{entryIds:[...entries].filter(id=>world.entries.some(entry=>entry.id===id)),sceneIds:[...scenes].filter(id=>sceneEntries.has(id)),plotIds:[...plots].filter(id=>project.plots?.threads.some(plot=>plot.id===id))});
 }
 return result;
}
export function contextChoices(project:Project,grouping:ContinuityGrouping,contexts:Map<string,ContinuityContext>){
 const ids=new Set([...contexts.values()].flatMap(context=>grouping==='entry'?context.entryIds:grouping==='scene'?context.sceneIds:grouping==='plot'?context.plotIds:[]));
 return (grouping==='entry'?(project.worldbuilding?.entries??[]).map(entry=>({id:entry.id,title:entry.title||t('Untitled entry'),detail:project.worldbuilding?.templates.find(template=>template.id===entry.templateId)?.title})):grouping==='scene'?project.chapters.flatMap(chapter=>chapter.scenes.map(scene=>({id:scene.id,title:scene.title||t('Untitled scene'),detail:chapter.title}))):grouping==='plot'?(project.plots?.threads??[]).map(plot=>({id:plot.id,title:plot.title||t('Untitled plot'),detail:undefined})):[]).filter(item=>ids.has(item.id)).sort((a,b)=>a.title.localeCompare(b.title,locale(),{numeric:true,sensitivity:'base'}));
}
export function matchesContinuityContext(context:ContinuityContext|undefined,grouping:ContinuityGrouping,id:string){return !id||!!context&&(grouping==='entry'?context.entryIds:grouping==='scene'?context.sceneIds:grouping==='plot'?context.plotIds:[]).includes(id);}
export function groupContinuityIssues(project:Project,issues:ContinuityIssue[],grouping:ContinuityGrouping,contexts:Map<string,ContinuityContext>,selected=''):ContinuityGroup[]{
 if(grouping==='none')return issues.length?[{id:'all',title:'',issues}]:[];
 const choices=contextChoices(project,grouping,contexts),byId=new Map(choices.map(choice=>[choice.id,choice])),groups=new Map<string,ContinuityGroup>(),other:ContinuityIssue[]=[],unused:ContinuityIssue[]=[];
 for(const issue of issues){if(issue.kind==='unused'&&!selected){unused.push(issue);continue;}
  const context=contexts.get(issue.id),ids=context?(grouping==='entry'?context.entryIds:grouping==='scene'?context.sceneIds:context.plotIds):[];
  const targets=ids.filter(id=>!selected||id===selected).flatMap(id=>byId.has(id)?[byId.get(id)!]:[]);
  if(!targets.length){other.push(issue);continue;}
  for(const target of targets){const group=groups.get(target.id)??{...target,issues:[]};group.issues.push(issue);groups.set(target.id,group);}
 }
 return [...choices.flatMap(choice=>groups.has(choice.id)?[groups.get(choice.id)!]:[]),...(other.length?[{id:'other',title:t('Other warnings'),issues:other}]:[]),...(unused.length?[{id:'unused',title:t('Entries without appearances'),issues:unused}]:[])];
}
export function continuityFacts(project:Project,issue:ContinuityIssue):{label:string;value:string}[]{
 const facts:{label:string;value:string}[]=[],world=project.worldbuilding,event=project.timeline?.events.find(event=>event.id===issue.eventId);
 if(issue.kind==='age'){
  const entry=world?.entries.find(entry=>entry.id===issue.entryId),birth=entry&&entryBirthDate(world,entry);
  if(entry&&birth)facts.push({label:t('Birth of {0}',entry.title),value:formatStoryDate(birth)});
  if(event)facts.push({label:event.title||t('Untitled event'),value:eventDateLabel(event)});
 }
 if(issue.kind==='chronology')for(const id of [...(issue.relatedSceneIds??[]),...(issue.sceneId?[issue.sceneId]:[])]){
  const scene=project.chapters.flatMap(chapter=>chapter.scenes).find(scene=>scene.id===id),events=project.timeline?.events.filter(event=>event.sceneIds.includes(id)&&event.start)??[];
  if(scene)facts.push({label:scene.title||t('Untitled scene'),value:events.map(event=>`${event.title}: ${eventDateLabel(event)}`).join('; ')||t('Date unknown')});
 }
 if(issue.kind==='travel'){
  const map=project.maps?.maps.find(map=>map.id===issue.mapId),route=map?.routes?.find(route=>route.id===issue.routeId);
  if(map&&route){if(route.departure)facts.push({label:t('Departure'),value:formatStoryDate(route.departure)});if(route.arrival)facts.push({label:t('Arrival'),value:formatStoryDate(route.arrival)});const review=reviewRouteTravel(map,route),number=(n:number)=>new Intl.NumberFormat(locale(),{maximumFractionDigits:1}).format(n);if(review&&review.kind!=='reversed')facts.push({label:t('Required / available time'),value:t('{0} / {1} days',number(review.requiredDays),number(review.availableDays))});}
 }
 if(issue.kind==='ambiguous')for(const id of issue.candidateIds??[]){const entry=world?.entries.find(entry=>entry.id===id);if(entry)facts.push({label:entry.title,value:world?.templates.find(template=>template.id===entry.templateId)?.title||t('Missing template')});}
 return facts;
}
