import type {Chapter,Project} from './model';
import {getSceneStatus} from './model';
import type {PendingItem} from './pendingItems';
import {countSceneWords} from './writingGoals';
import {longTextPlainText} from './longText';
export type ChapterPlan={schemaVersion:1;purpose:string;conflict:string;turn:string;outcome:string;notes:string;plotIds:string[];arcIds:string[]};
export const emptyChapterPlan:ChapterPlan={schemaVersion:1,purpose:'',conflict:'',turn:'',outcome:'',notes:'',plotIds:[],arcIds:[]};
export function patchChapterPlan(project:Project,id:string,patch:Partial<Omit<ChapterPlan,'schemaVersion'>>):Project{
 if(!project.chapters.some(chapter=>chapter.id===id))return project;
 return {...project,chapters:project.chapters.map(chapter=>chapter.id===id?{...chapter,planning:{...(chapter.planning??emptyChapterPlan),...patch,schemaVersion:1}}:chapter)};
}
export function setChapterExpectation(project:Project,id:string,kind:'plot'|'arc',targetId:string,expected:boolean):Project{
 const chapter=project.chapters.find(chapter=>chapter.id===id);if(!chapter)return project;
 const key=kind==='plot'?'plotIds':'arcIds',ids=chapter.planning?.[key]??[];
 if(ids.includes(targetId)===expected)return project;
 return patchChapterPlan(project,id,{[key]:expected?[...ids,targetId]:ids.filter(id=>id!==targetId)});
}
export function chapterCoverage(project:Project,chapter:Chapter,kind:'plot'|'arc'){
 const expectedIds=kind==='plot'?chapter.planning?.plotIds??[]:chapter.planning?.arcIds??[],sources=kind==='plot'?project.plots?.threads??[]:project.plots?.arcs??[];
 const sceneIds=new Set(chapter.scenes.map(scene=>scene.id));
 return [...new Set([...expectedIds,...sources.filter(source=>source.beats.some(beat=>sceneIds.has(beat.sceneId))).map(source=>source.id)])].map(id=>{
  const source=sources.find(source=>source.id===id),linkedSceneIds=chapter.scenes.filter(scene=>source?.beats.some(beat=>beat.sceneId===scene.id)).map(scene=>scene.id);
  return {id,source,expected:expectedIds.includes(id),linkedSceneIds,gap:expectedIds.includes(id)&&!linkedSceneIds.length};
 });
}
export function chapterPlanningSummary(project:Project,chapter:Chapter){
 const plots=chapterCoverage(project,chapter,'plot'),arcs=chapterCoverage(project,chapter,'arc');
 return {scenes:chapter.scenes.length,words:chapter.scenes.reduce((sum,scene)=>sum+countSceneWords(scene.content),0),finished:chapter.scenes.filter(scene=>getSceneStatus(scene)==='finished').length,missingSynopses:chapter.scenes.filter(scene=>!scene.synopsis?.trim()).length,emptyScenes:chapter.scenes.filter(scene=>!countSceneWords(scene.content)).length,coverageGaps:[...plots,...arcs].filter(item=>item.gap).length,hasSynopsis:!!chapter.synopsis?.trim(),hasPurpose:!!longTextPlainText(chapter.planning?.purpose??'').trim(),plots,arcs};
}
export function chapterPendingItems(project:Project,chapter:Chapter,items:PendingItem[]):PendingItem[]{
 const scenes=new Set(chapter.scenes.map(scene=>scene.id));
 return items.filter(item=>{
  if(item.idea&&!['idea','deciding','decided'].includes(item.idea.status))return false;
  return !!item.idea?.plotIds?.some(id=>chapter.planning?.plotIds.includes(id))||item.chapterId===chapter.id||item.chapterIds?.includes(chapter.id)||!!item.sceneId&&scenes.has(item.sceneId)||item.issue?.relatedSceneIds?.some(id=>scenes.has(id))||!!item.issue?.eventId&&project.timeline?.events.some(event=>event.id===item.issue?.eventId&&event.sceneIds.some(id=>scenes.has(id)));
 });
}
