import {locale} from './i18n';
import type {Entry,Worldbuilding} from './worldbuilding';
import type {EntryRelations} from './entryRelations';
import {ensureVisualResourceSchema} from './visualResources';
export type EntryOrder='alphabetical'|'reverseAlphabetical'|'recentlyModified'|'oldestModified';
const preferenceKey='write-studio.entry-order';
const validOrders:EntryOrder[]=['alphabetical','reverseAlphabetical','recentlyModified','oldestModified'];
export function readEntryOrder():EntryOrder{try{const value=localStorage.getItem(preferenceKey);return validOrders.includes(value as EntryOrder)?value as EntryOrder:'alphabetical';}catch{return 'alphabetical';}}
export function rememberEntryOrder(order:EntryOrder){try{localStorage.setItem(preferenceKey,order);}catch{/* Keep the current view preference in memory. */}}
export function sortEntries(entries:Entry[],order:EntryOrder):Entry[]{
 const collator=new Intl.Collator(locale(),{sensitivity:'base',numeric:true});
 return entries.map((entry,index)=>({entry,index})).sort((a,b)=>{
  const alphabetical=collator.compare(a.entry.title,b.entry.title);
  if(order==='alphabetical'||order==='reverseAlphabetical')return (order==='alphabetical'?alphabetical:-alphabetical)||a.index-b.index;
  const first=a.entry.modifiedAt,second=b.entry.modifiedAt;
  if(first===undefined&&second!==undefined)return 1;if(second===undefined&&first!==undefined)return -1;
  return (first!==undefined&&second!==undefined?(order==='recentlyModified'?second-first:first-second):0)||alphabetical||a.index-b.index;
 }).map(item=>item.entry);
}
function stableValue(value:unknown):unknown{
 if(Array.isArray(value))return value.map(stableValue);
 if(value&&typeof value==='object')return Object.fromEntries(Object.entries(value).sort(([a],[b])=>a.localeCompare(b)).map(([key,item])=>[key,stableValue(item)]));
 return value;
}
function content(entry:Entry){return JSON.stringify([entry.canonStatus??null,entry.editorialStatus??null,entry.templateId,entry.title,entry.archived,entry.imageId??null,entry.imageIds??[],entry.linkAliases??[],stableValue(entry.values)]);}
/** Stamp real record/connection edits at the project update boundary, never view changes. */
export function stampEntryModifications(before:Worldbuilding|undefined,after:Worldbuilding|undefined,beforeRelations?:EntryRelations,afterRelations?:EntryRelations,now=Date.now()):Worldbuilding|undefined{
 if(after)after=ensureVisualResourceSchema(after);
 if(!after||before===after&&beforeRelations?.links===afterRelations?.links)return after;
 const touched=new Set<string>();
 if(beforeRelations?.links!==afterRelations?.links){
  const oldLinks=new Map((beforeRelations?.links??[]).map(link=>[link.id,link])),newLinks=new Map((afterRelations?.links??[]).map(link=>[link.id,link]));
  for(const id of new Set([...oldLinks.keys(),...newLinks.keys()])){const old=oldLinks.get(id),next=newLinks.get(id);if(JSON.stringify(stableValue(old))!==JSON.stringify(stableValue(next)))for(const link of [old,next])if(link){touched.add(link.sourceId);touched.add(link.targetId);}}
 }
 const oldEntries=new Map((before?.entries??[]).map(entry=>[entry.id,entry]));
 for(const entry of after.entries){const old=oldEntries.get(entry.id);if(!old||old!==entry&&content(old)!==content(entry))touched.add(entry.id);}
 if(!after.entries.some(entry=>touched.has(entry.id)))return after;
 const version=after.schemaVersion>=10?after.schemaVersion:10;
 return {...after,schemaVersion:version,templates:after.templates.map(template=>template.schemaVersion===version?template:{...template,schemaVersion:version}),entries:after.entries.map(entry=>({...entry,schemaVersion:version,...(touched.has(entry.id)?{modifiedAt:now}:{})}))};
}
