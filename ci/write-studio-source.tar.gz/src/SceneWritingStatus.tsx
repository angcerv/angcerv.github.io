import FieldHelp from './FieldHelp';
import { t } from './i18n';
import { Circle, Pencil, Eye, Check } from 'lucide-react';
import { getSceneStatus, writingStatusLabels } from './model';
import type { Scene, WritingStatus } from './model';
export default function SceneWritingStatus({ scene, compact = false }: { scene: Scene; compact?: boolean }) {
  const status = getSceneStatus(scene), label = t(writingStatusLabels[status]);
  const Icon = { notStarted: Circle, draft: Pencil, inReview: Eye, finished: Check }[status];
  return <span className={`scene-writing-status status-${status}${compact ? ' compact' : ''}`} role="img" aria-label={t("Writing status: {0}", label)} title={t("Writing status: {0}", label)}><Icon size={13} aria-hidden="true" />{!compact && <span>{t(label)}</span>}</span>;
}

export function WritingStatusSelector({ value, onChange }: { value: WritingStatus; onChange: (value: WritingStatus) => void }) {
 return <fieldset className="writing-status-selector" aria-labelledby="scene-writing-status-label"><legend id="scene-writing-status-label">{t("Writing status")}<FieldHelp label={t("Writing status")} description={t("Writing progress, independent of saving.")}/></legend><div className="writing-status-options">{(Object.entries(writingStatusLabels) as [WritingStatus,string][]).map(([status,label])=><label key={status} className={`writing-status-pill status-${status}${value===status ? ' selected' : ''}`}><input type="radio" name="scene-writing-status" value={status} checked={value===status} onChange={()=>onChange(status)}/><span className="status-dot" aria-hidden="true"/><span>{t(label)}</span>{value===status && <Check size={14} className="status-selected-check" aria-hidden="true"/>}</label>)}</div></fieldset>;
}
