import type {Project} from './model';
import type {TextReferenceSource} from './textReferenceIndex';
import {t} from './i18n';
export function entryUsageGroups(project:Project,index:TextReferenceSource[],entryId:string){
 const groups=new Map<string,Map<string,{source:TextReferenceSource;fields:string[]}>>();
 for(const source of index){
  if(source.entryId!==entryId||source.kind==='entry'&&source.id===entryId)continue;
  if(source.kind==='scene'&&source.field===t('Manuscript'))continue; // Detailed appearances own these occurrences.
  if(source.kind==='idea'&&project.worldIdeas?.some(idea=>idea.id===source.id&&idea.entryIds.includes(entryId)&&['idea','deciding','decided'].includes(idea.status)))continue;
  const group=source.kind==='event'?'Timeline':source.kind==='map'?'Maps':['plot','arc','scenePlan','chapterPlan','chapter'].includes(source.kind)?'Story planning':'References from other content';
  let items=groups.get(group);if(!items){items=new Map();groups.set(group,items);}
  const key=`${source.kind}:${source.id}:${source.markerId??''}:${source.routeId??''}`,previous=items.get(key);
  if(previous){if(!previous.fields.includes(source.field))previous.fields.push(source.field);}else items.set(key,{source,fields:[source.field]});
 }
 return [...groups].map(([label,items])=>({label,items:[...items.values()]}));
}
