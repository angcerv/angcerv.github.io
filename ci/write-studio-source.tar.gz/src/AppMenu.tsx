import {t,buttonLabel} from './i18n';
import type {RecentProject} from './storage';
import {Feather,FilePlus,FolderOpen,ArchiveRestore} from 'lucide-react';
import ActionMenu from './ActionMenu';
export default function AppMenu({ disabled, onNew, onOpen, onRestore, recents = [], onOpenRecent, recentsLoading = false, recentsError = '', onRetryRecents }: { disabled: boolean; onNew: () => void; onOpen: () => void; onRestore?:()=>void; recents?: RecentProject[]; onOpenRecent?: (path: string) => void; recentsLoading?: boolean; recentsError?: string; onRetryRecents?: () => void }) {
 const loadingStatus=t('Loading recent projects…');
 return <ActionMenu label={t('Application options')} disabled={disabled} actions={[
  {label:t('New project'),icon:<FilePlus size={16}/>,onClick:onNew},
  {label:t('Open project'),icon:<FolderOpen size={16}/>,onClick:onOpen},
  ...(onRestore?[{label:buttonLabel('Restore backup…'),icon:<ArchiveRestore size={16}/>,onClick:onRestore}]:[]),
  ...recents.map(project=>({id:project.path,label:project.title||t('Untitled project'),description:project.path.split(/[\\/]/).filter(Boolean).slice(-2).join('/'),group:t('Recent projects'),icon:<FolderOpen size={15}/>,onClick:()=>onOpenRecent?.(project.path)})),
  ...(recentsError?[{label:t('Retry recent projects'),group:t('Recent projects'),onClick:()=>onRetryRecents?.()}]:[])
 ]} footer={recentsLoading?<p className="app-menu-note" role="status">{loadingStatus}</p>:recentsError?<p className="app-menu-note" role="alert">{t('Recent projects unavailable.')}</p>:!recents.length?<p className="app-menu-note">{t('No recent projects yet.')}</p>:undefined}><Feather size={20}/><span className="app-menu-brand">Write Studio</span></ActionMenu>;
}
