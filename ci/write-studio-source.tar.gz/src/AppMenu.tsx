import { menuNavigationIndex } from './menuNavigation';
import {t,buttonLabel} from './i18n';
import { useEffect, useRef, useState } from 'react';
import type { RecentProject } from './storage';
import { ChevronDown, FilePlus, FolderOpen, ArchiveRestore } from 'lucide-react';

export default function AppMenu({ disabled, onNew, onOpen, onRestore, recents = [], onOpenRecent, recentsLoading = false, recentsError = '', onRetryRecents }: { disabled: boolean; onNew: () => void; onOpen: () => void; onRestore?:()=>void; recents?: RecentProject[]; onOpenRecent?: (path: string) => void; recentsLoading?: boolean; recentsError?: string; onRetryRecents?: () => void }) {
  const [open, setOpen] = useState(false);
  const root = useRef<HTMLDivElement>(null);
  const focusLast=useRef(false);
  const trigger = useRef<HTMLButtonElement>(null);
  useEffect(() => { if (disabled) setOpen(false); }, [disabled]);
  useEffect(() => {
    if (!open) return;
    const items=Array.from(root.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]:not(:disabled)')??[]);
    items[focusLast.current?items.length-1:0]?.focus();focusLast.current=false;
    const outside = (event: Event) => { if (!root.current?.contains(event.target as Node)) setOpen(false); };
    document.addEventListener('pointerdown', outside);
    document.addEventListener('focusin', outside);
    return () => { document.removeEventListener('pointerdown', outside); document.removeEventListener('focusin', outside); };
  }, [open]);
  function choose(action: () => void) { setOpen(false); trigger.current?.focus(); action(); }
  return <div className="app-menu" ref={root} onKeyDown={event => {
    if (event.key === 'Escape') { setOpen(false); trigger.current?.focus(); event.stopPropagation(); }
    if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
      event.preventDefault();
      if (!open) { focusLast.current=event.key==='ArrowUp'||event.key==='End';setOpen(true); return; }
      const items = Array.from(root.current?.querySelectorAll<HTMLButtonElement>('[role="menuitem"]') ?? []);
      const current = items.indexOf(document.activeElement as HTMLButtonElement);
      const index = menuNavigationIndex(event.key,current,items.length);
      items[index]?.focus();
    }
  }}>
    <button ref={trigger} type="button" className="app-menu-trigger" aria-label={t("Application options")} aria-haspopup="menu" aria-expanded={open} aria-controls={open ? 'application-menu' : undefined} disabled={disabled} onClick={() => setOpen(!open)}><ChevronDown size={16} /></button>
    {open && !disabled && <div id="application-menu" className="app-menu-popup" role="menu" aria-label={t("Application options")}><button type="button" role="menuitem" onClick={() => choose(onNew)}><FilePlus size={16} />{t("New project")}</button><button type="button" role="menuitem" onClick={() => choose(onOpen)}><FolderOpen size={16} />{t("Open project")}</button>{onRestore && <button type="button" role="menuitem" onClick={()=>choose(onRestore)}><ArchiveRestore size={16}/>{buttonLabel("Restore backup…")}</button>}<div role="separator" className="app-menu-divider" /><div className="app-menu-section-label">{t("Recent projects")}</div>{recentsLoading && <p className="app-menu-note" role="status">{t("Loading…")}</p>}{recents.map(project => <button type="button" role="menuitem" key={project.path} title={project.path} onClick={() => choose(() => onOpenRecent?.(project.path))}><FolderOpen size={15} /><span className="app-recent-label"><strong>{project.title || t("Untitled project")}</strong><small>{project.path.split('/').filter(Boolean).slice(-2).join('/')}</small></span></button>)}{recentsError && <><p className="app-menu-note" role="alert">{t("Recent projects unavailable.")}</p><button type="button" role="menuitem" onClick={() => choose(() => onRetryRecents?.())}>{t("Retry recent projects")}</button></>}{!recents.length && !recentsLoading && !recentsError && <p className="app-menu-note">{t("No recent projects yet.")}</p>}</div>}
  </div>;
}
