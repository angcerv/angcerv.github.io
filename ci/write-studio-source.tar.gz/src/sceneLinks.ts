import { sceneReferenceSummary } from './mentionDetection';
import type { Chapter, Scene } from './model';
import type { Worldbuilding } from './worldbuilding';

export function linkSceneEntry(scene: Scene, world: Worldbuilding, entryId: string): Scene {
  if (scene.entryIds?.includes(entryId) || !world.entries.some(entry => entry.id === entryId && !entry.archived)) return scene;
  return { ...scene, entryIds: [...(scene.entryIds ?? []), entryId] };
}
export function unlinkSceneEntry(scene: Scene, entryId: string): Scene {
  if (!scene.entryIds?.includes(entryId)) return scene;
  return { ...scene, entryIds: scene.entryIds.filter(id => id !== entryId) };
}
export function scenesForEntry(chapters: Chapter[], entryId: string,world?:Worldbuilding) {
  return chapters.flatMap(chapter => chapter.scenes.filter(scene => (scene.entryIds?.includes(entryId)||!!world&&sceneReferenceSummary(scene,world).references.some(reference=>reference.id===entryId))).map(scene => ({ chapter, scene })));
}
