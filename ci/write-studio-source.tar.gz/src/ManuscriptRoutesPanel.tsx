import {manuscriptMapRoutes} from './sceneGeography';
import { Route, X, Crosshair } from 'lucide-react';
import Dropdown from './Dropdown';
import {t,buttonLabel} from './i18n';
import { linkRouteTarget, mapColors } from './maps';
import type { ProjectMaps } from './maps';
export default function ManuscriptRoutesPanel({maps,chapterId,sceneId,onChange,onOpen,readOnly=false}:{readOnly?:boolean;maps:ProjectMaps;chapterId:string;sceneId?:string;onChange?:(maps:ProjectMaps)=>void;onOpen?:(mapId:string,routeId:string)=>void}){
 const all=maps.maps.flatMap(map=>(map.routes??[]).map(route=>({map,route})));
 const id=sceneId??chapterId;
 const linked=manuscriptMapRoutes(maps,chapterId,sceneId);
 return <section className="manuscript-routes-panel"><h3><Route size={15}/>{t('Map routes')}</h3>
 {linked.map(({map,route,direct,inherited})=>{return <div className="route-manuscript-row" key={`${map.id}:${route.id}`}><button type="button" className="route-manuscript-open" disabled={!onOpen} onClick={()=>onOpen?.(map.id,route.id)} title={t('Open route on map')} aria-label={readOnly?t('Locate route {0} on map',route.title||t('Untitled route')):undefined}><i style={{background:mapColors[route.color]}}/><span>{route.title||t('Untitled route')}<small>{map.title}{sceneId?` · ${buttonLabel(direct&&inherited?'Linked to scene and chapter':inherited?'Linked to chapter':'Linked to scene')}`:''}</small></span>{readOnly&&<Crosshair size={15} aria-hidden="true"/>}</button>{!readOnly&&direct&&<button type="button" className="icon-button" aria-label={t('Unlink route {0}',route.title)} title={t('Unlink route')} onClick={()=>onChange?.(linkRouteTarget(maps,map.id,route.id,sceneId?'scene':'chapter',id,false))}><X size={14}/></button>}</div>;})}
 {!linked.length&&<p className="world-hint">{t(readOnly?'No routes linked to this scene or its chapter.':'No routes linked yet. Create routes in Maps, then link them here.')}</p>}
 {!readOnly&&<><label htmlFor="manuscript-link-route">{t('Link a route')}</label><Dropdown id="manuscript-link-route" value="" placeholder={t('Choose a route')} options={all.filter(item=>!linked.some(link=>link.map.id===item.map.id&&link.route.id===item.route.id)).map(({map,route})=>({value:route.id,label:`${route.title||t('Untitled route')} · ${map.title}`}))} onChange={routeId=>{const item=all.find(item=>item.route.id===routeId);if(item)onChange?.(linkRouteTarget(maps,item.map.id,routeId,sceneId?'scene':'chapter',id,true));}}/></>}
 </section>;
}
