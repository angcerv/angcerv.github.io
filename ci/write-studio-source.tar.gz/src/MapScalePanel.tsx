import {useState} from 'react';
import type {ReactNode} from 'react';
import {initialCalibration,validCalibration} from './mapCalibration';
import type {CalibrationReference} from './mapCalibration';
import FieldHelp from './FieldHelp';
import {Pencil,Trash2,Eye,EyeOff} from 'lucide-react';
import Dropdown from './Dropdown';
import ProjectModal from './ProjectModal';
import {locale,t,buttonLabel} from './i18n';
import {markerLabel,scaledDistance} from './maps';
import type {MapScale,WorldMap} from './maps';
import type {Worldbuilding} from './worldbuilding';
export function formatMapNumber(value:number){return new Intl.NumberFormat(locale(),{maximumFractionDigits:1}).format(value);}

type RenderCalibration=(props:{reference:CalibrationReference;distanceKm?:number;onChange:(reference:CalibrationReference)=>void;onInteractionChange:(active:boolean)=>void})=>ReactNode;
type ScaleProps={active?:boolean;map:WorldMap;world:Worldbuilding;aspectRatio?:number;onChange:(scale:MapScale|undefined)=>void;renderCalibration?:RenderCalibration;showReference?:boolean;onShowReferenceChange?:(show:boolean)=>void};
export function MapScaleDialog({map,aspectRatio,renderCalibration,onSave,onClose}:{map:WorldMap;aspectRatio?:number;renderCalibration?:RenderCalibration;onSave:(scale:MapScale|undefined)=>void;onClose:()=>void}){
 const [reference,setReference]=useState(()=>initialCalibration(map.scale,aspectRatio)),[distance,setDistance]=useState(String(map.scale?.distanceKm??100)),[pace,setPace]=useState(String(map.scale?.travelKmPerDay??30)),[dragging,setDragging]=useState(false);
 const [discarding,setDiscarding]=useState(false);
 const initial=initialCalibration(map.scale,aspectRatio);
 const dirty=JSON.stringify(reference)!==JSON.stringify(initial)||distance!==String(map.scale?.distanceKm??100)||pace!==String(map.scale?.travelKmPerDay??30);
 const requestClose=()=>{if(dragging)return;if(dirty)setDiscarding(true);else onClose();};
 const distanceKm=Number(distance),travelKmPerDay=Number(pace);
 const valid=validCalibration(reference)&&Number.isFinite(distanceKm)&&distanceKm>0&&Number.isFinite(travelKmPerDay)&&travelKmPerDay>0;
 const preview=valid?{...reference,distanceKm,travelKmPerDay}:undefined;
 return <ProjectModal variant={discarding?'confirmation':undefined} title={t(discarding?'Discard unsaved changes?':map.scale?'Edit scale':'Set scale')} titleAccessory={!discarding&&<FieldHelp label={t('Map scale')} description={t('Drag the line endpoints or choose Draw reference line and drag on the map. Use the arrow keys on an endpoint for precision. Changes are saved only when you apply them.')}/>} onClose={()=>discarding?setDiscarding(false):requestClose()} className="map-scale-dialog map-calibration-dialog">{discarding&&<div><p>{t('Discard your unsaved edits?')}</p><div className="welcome-actions"><button type="button" className="quick-action quick-action-text" onClick={()=>setDiscarding(false)}>{t('Continue editing')}</button><button type="button" className="danger-button" onClick={onClose}>{t('Discard changes')}</button></div></div>}<form hidden={discarding} inert={discarding} onSubmit={event=>{event.preventDefault();if(valid&&!dragging)onSave({...reference,distanceKm,travelKmPerDay});}}>
  <div className="map-calibration-preview">{renderCalibration?.({reference,distanceKm:distanceKm>0?distanceKm:undefined,onChange:setReference,onInteractionChange:setDragging})}</div>
  <div className="map-calibration-settings"><p className="world-hint">{t('Drag the endpoints to match a known distance.')}</p>
   <div className="ui-form-field"><label htmlFor="scale-distance">{t('Reference line distance (km)')}</label><input id="scale-distance" type="number" required min="0" step="any" value={distance} onChange={event=>setDistance(event.target.value)}/></div>
   <div className="ui-form-field"><label htmlFor="map-travel-pace">{t('Travel pace (km/day)')}</label><input id="map-travel-pace" type="number" required min="0" step="any" value={pace} onChange={event=>setPace(event.target.value)}/></div>
   {!validCalibration(reference)&&<p className="prompt-error" role="alert">{t('The reference line must have two different endpoints.')}</p>}
   {((distance.trim()&&(!Number.isFinite(distanceKm)||distanceKm<=0))||(pace.trim()&&(!Number.isFinite(travelKmPerDay)||travelKmPerDay<=0)))&&<p className="prompt-error" role="alert">{t('Enter a distance and travel pace greater than zero.')}</p>}
   {preview&&<dl className="map-measurement-values" role="status"><dt>{t('Map width')}</dt><dd>{formatMapNumber(scaledDistance(preview,{x:0,y:.5},{x:1,y:.5}))} km</dd></dl>}
  </div>
  <footer className="map-scale-dialog-actions">{map.scale&&<button type="button" className="danger-button quick-action quick-action-text" disabled={dragging} onClick={()=>onSave(undefined)}><Trash2 size={14}/>{t('Remove scale')}</button>}<button type="button" disabled={dragging} onClick={requestClose} className="quick-action quick-action-text">{t('Cancel')}</button><button type="submit" className="primary-button" disabled={!valid||dragging}>{t('Apply scale')}</button></footer>
 </form></ProjectModal>;
}

export default function MapScalePanel({active=true,map,world,aspectRatio,onChange,renderCalibration,showReference=false,onShowReferenceChange}:ScaleProps){
 const [from,setFrom]=useState(''),[to,setTo]=useState(''),[editing,setEditing]=useState(false);
 const a=map.markers.find(marker=>marker.id===from),b=map.markers.find(marker=>marker.id===to);
 const options=map.markers.map(marker=>({value:marker.id,label:markerLabel(marker,world)}));
 const distance=map.scale&&a&&b&&a.id!==b.id?scaledDistance(map.scale,a,b):undefined;
 const canConfigure=!!map.scale||!!aspectRatio;
 return <section className="map-scale-panel">
  <header><h3>{t('Map scale')}</h3><div className="map-scale-header-actions">{map.scale&&onShowReferenceChange&&<button type="button" className="quick-action" title={buttonLabel(showReference?'Hide reference line':'Show reference line')} aria-label={buttonLabel(showReference?'Hide reference line':'Show reference line')} aria-pressed={showReference} onClick={()=>onShowReferenceChange(!showReference)}>{showReference?<EyeOff size={15}/>:<Eye size={15}/>}</button>}<button type="button" className="quick-action" title={buttonLabel(map.scale?'Edit scale':'Set scale')} aria-label={buttonLabel(map.scale?'Edit scale':'Set scale')} aria-haspopup="dialog" disabled={!canConfigure} onClick={()=>setEditing(true)}><Pencil size={15} aria-hidden="true"/></button></div></header>
  {map.scale?<dl className="map-measurement-values"><dt>{t('Calibration distance')}</dt><dd>{formatMapNumber(map.scale.distanceKm)} km</dd><dt>{t('Travel pace')}</dt><dd>{formatMapNumber(map.scale.travelKmPerDay)} {t('km/day')}</dd></dl>:<p className="world-hint">{t('Calibrate the scale to calculate distances.')}</p>}
  <header><h3>{t('Distance')}</h3><FieldHelp label={t('Scale and distances')} description={t('Distances use straight segments. Travel estimates exclude terrain, detours and rest. Replacing the image clears the scale.')}/></header>
  {map.markers.length<2?<p className="world-hint">{t('Add at least two markers to measure distances.')}</p>:<><div className="map-field-grid"><div><label htmlFor="scale-from">{t('From')}</label><Dropdown id="scale-from" value={from} placeholder={t('Choose a marker')} options={options} onChange={value=>{setFrom(value);if(to===value)setTo('');}}/></div><div><label htmlFor="scale-to">{t('To')}</label><Dropdown id="scale-to" value={to} placeholder={t('Choose a marker')} options={options.filter(option=>option.value!==from)} onChange={setTo}/></div></div>{distance!==undefined&&map.scale?<dl className="map-measurement-values map-distance-summary" role="status"><dt>{t('Straight-line distance')}</dt><dd>{formatMapNumber(distance)} km</dd><dt>{t('Estimated travel')}</dt><dd>{formatMapNumber(distance/map.scale.travelKmPerDay)} {t('days')}</dd></dl>:map.scale&&<p className="world-hint">{t('Choose an origin and destination to see their distance.')}</p>}</>}
  {!canConfigure&&<p role="status" className="world-hint">{t('Wait for the map image to load before calibrating the scale.')}</p>}
  {active&&editing&&<MapScaleDialog map={map} aspectRatio={aspectRatio} renderCalibration={renderCalibration} onClose={()=>setEditing(false)} onSave={scale=>{onChange(scale);setEditing(false);}}/>}
 </section>;
}
