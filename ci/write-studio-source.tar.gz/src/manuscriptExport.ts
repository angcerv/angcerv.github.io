import {normalizeManuscriptExportPreferences} from './manuscriptExportPreferences';
import type {ManuscriptExportPreferences} from './manuscriptExportPreferences';
import { fromMarkdown } from './model';
import type { Project } from './model';
import type { JSONContent } from '@tiptap/react';
export type ExportFormat = 'docx' | 'md';
export type ManuscriptExportOptions=Partial<Omit<ManuscriptExportPreferences,'format'>>&{author?:string};
const xml = (text: string) => {
  if (/[\u0000-\u0008\u000b\u000c\u000e-\u001f\ufffe\uffff]/u.test(text)) throw new Error('The manuscript contains a character unsupported by Word.');
  return text.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
};
const heading = (text: string) => text.replace(/[\r\n]+/g, ' ').replace(/[\\`*_[\]{}<>#!|~\-+.()]/g, '\\$&');
const run = (node: JSONContent): string => node.type === 'hardBreak' ? '<w:r><w:br/></w:r>' : `<w:r><w:rPr>${node.marks?.some(mark => mark.type === 'bold') ? '<w:b/>' : ''}${node.marks?.some(mark => mark.type === 'italic') ? '<w:i/>' : ''}</w:rPr><w:t xml:space="preserve">${xml(node.text ?? '')}</w:t></w:r>`;
const paragraph = (text: string, style: string, pageBreak = false) => `<w:p><w:pPr><w:pStyle w:val="${style}"/>${pageBreak ? '<w:pageBreakBefore/>' : ''}</w:pPr><w:r><w:t xml:space="preserve">${xml(text)}</w:t></w:r></w:p>`;
// A standard ZIP container using stored entries. No runtime dependency or network required.
function zip(files: Record<string, string>): Uint8Array {
  const encoder = new TextEncoder();
  const locals: Uint8Array[] = [], central: Uint8Array[] = [];
  let offset = 0, directorySize = 0;
  const crc32 = (bytes: Uint8Array) => { let crc = 0xffffffff; for (const byte of bytes) { crc ^= byte; for (let i = 0; i < 8; i++) crc = (crc >>> 1) ^ ((crc & 1) ? 0xedb88320 : 0); } return (crc ^ 0xffffffff) >>> 0; };
  for (const [name, text] of Object.entries(files)) {
    const filename = encoder.encode(name), body = encoder.encode(text), crc = crc32(body);
    const local = new Uint8Array(30 + filename.length + body.length), v = new DataView(local.buffer);
    v.setUint32(0, 0x04034b50, true); v.setUint16(4, 20, true); v.setUint16(6, 0x800, true); v.setUint16(12, 33, true);
    v.setUint32(14, crc, true); v.setUint32(18, body.length, true); v.setUint32(22, body.length, true); v.setUint16(26, filename.length, true);
    local.set(filename, 30); local.set(body, 30 + filename.length);
    const entry = new Uint8Array(46 + filename.length), d = new DataView(entry.buffer);
    d.setUint32(0, 0x02014b50, true); d.setUint16(4, 20, true); d.setUint16(6, 20, true); d.setUint16(8, 0x800, true); d.setUint16(14, 33, true);
    d.setUint32(16, crc, true); d.setUint32(20, body.length, true); d.setUint32(24, body.length, true); d.setUint16(28, filename.length, true); d.setUint32(42, offset, true); entry.set(filename, 46);
    locals.push(local); central.push(entry); offset += local.length; directorySize += entry.length;
  }
  if (offset + directorySize > 0xffffffff) throw new Error('The manuscript is too large to export.');
  const end = new Uint8Array(22), e = new DataView(end.buffer);
  e.setUint32(0, 0x06054b50, true); e.setUint16(8, central.length, true); e.setUint16(10, central.length, true); e.setUint32(12, directorySize, true); e.setUint32(16, offset, true);
  const output = new Uint8Array(offset + directorySize + end.length); let position = 0;
  for (const part of [...locals, ...central, end]) { output.set(part, position); position += part.length; }
  return output;
}
export function exportManuscript(project: Project, chapterIds: string[], format: ExportFormat, options: boolean|ManuscriptExportOptions = true): Uint8Array {
  const settings=normalizeManuscriptExportPreferences(typeof options==='boolean'?{sceneTitles:options}:options);
  const {sceneTitles}=settings;
  const author=options&&typeof options==='object'&&typeof options.author==='string'?options.author.trim():'';
  if(format!=='docx'&&format!=='md')throw new Error('Unsupported manuscript export format.');
  const selected = new Set(chapterIds), chapters = project.chapters.filter(chapter => selected.has(chapter.id));
  if (!chapters.length) throw new Error('Select at least one chapter.');
  const owners=new Map((project.books??[]).flatMap(book=>book.chapterIds.map(id=>[id,book] as const)));
  const grouped=new Set(chapters.map(chapter=>owners.get(chapter.id)?.id).filter(Boolean)).size>1;
  const startsBook=(index:number)=>grouped&&(index===0||owners.get(chapters[index-1].id)?.id!==owners.get(chapters[index].id)?.id);

  if (format === 'md') return new TextEncoder().encode([`# ${heading(project.title || 'Untitled project')}`, ...chapters.flatMap((chapter,chapterIndex) => [...(startsBook(chapterIndex)?[`## ${heading(owners.get(chapter.id)?.title??'')}`]:[]),`${grouped?'###':'##'} ${heading(chapter.title || 'Untitled chapter')}`, ...chapter.scenes.flatMap((scene, index) => [sceneTitles ? `${grouped?'####':'###'} ${heading(scene.title || 'Untitled scene')}` : index > 0 ? '***' : '', scene.content])])].filter(text => text !== '').join('\n\n') + '\n');
  let body = paragraph(project.title || 'Untitled project', settings.coverPage?'CoverTitle':'Title');
  if(settings.coverPage&&author)body+=paragraph(author,'CoverAuthor');
  chapters.forEach((chapter, index) => {
    if(startsBook(index))body+=paragraph(owners.get(chapter.id)?.title??'', 'Heading1',index===0?settings.coverPage:settings.chapterPageBreaks);
    body += paragraph(chapter.title || 'Untitled chapter', grouped?'Heading2':'Heading1', startsBook(index)?false:index===0?settings.coverPage:settings.chapterPageBreaks);
    chapter.scenes.forEach((scene, sceneIndex) => {
      if (sceneTitles) body += paragraph(scene.title || 'Untitled scene', grouped?'Heading3':'Heading2');
      else if (sceneIndex > 0) body += paragraph('* * *', 'SceneBreak');
      for (const p of fromMarkdown(scene.content).content ?? []) body += `<w:p>${(p.content ?? []).map(run).join('')}</w:p>`;
    });
  });
  const declaration = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>';
  const namespace = 'http://schemas.openxmlformats.org/wordprocessingml/2006/main';
  const font={georgia:'Georgia',times:'Times New Roman',arial:'Arial'}[settings.font];
  const page=settings.paperSize==='letter'?{width:12240,height:15840}:{width:11906,height:16838};
  const margin={standard:1440,compact:1134,wide:1701}[settings.margins];
  const style = (id: string, name: string, size: number, bold = false) => `<w:style w:type="paragraph" w:styleId="${id}"><w:name w:val="${name}"/><w:basedOn w:val="Normal"/><w:pPr><w:keepNext/><w:keepLines/><w:spacing w:before="240" w:after="120"/>${id==='Heading1'?'<w:outlineLvl w:val="0"/>':id==='Heading2'?'<w:outlineLvl w:val="1"/>':id==='Heading3'?'<w:outlineLvl w:val="2"/>':''}</w:pPr><w:rPr>${bold ? '<w:b/>' : ''}<w:sz w:val="${size}"/><w:szCs w:val="${size}"/></w:rPr></w:style>`;
  return zip({
    '[Content_Types].xml': `${declaration}<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/></Types>`,
    '_rels/.rels': `${declaration}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/></Relationships>`,
    'word/document.xml': `${declaration}<w:document xmlns:w="${namespace}"><w:body>${body}<w:sectPr><w:pgSz w:w="${page.width}" w:h="${page.height}"/><w:pgMar w:top="${margin}" w:right="${margin}" w:bottom="${margin}" w:left="${margin}" w:header="720" w:footer="720" w:gutter="0"/></w:sectPr></w:body></w:document>`,
    'word/_rels/document.xml.rels': `${declaration}<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rIdStyles" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>`,
    'word/styles.xml': `${declaration}<w:styles xmlns:w="${namespace}"><w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="${font}" w:hAnsi="${font}" w:eastAsia="${font}" w:cs="${font}"/><w:sz w:val="${settings.fontSize*2}"/><w:szCs w:val="${settings.fontSize*2}"/></w:rPr></w:rPrDefault><w:pPrDefault><w:pPr><w:spacing w:after="160" w:line="${settings.lineSpacing*240}" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults><w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>${style('Title', 'Title', 40)}<w:style w:type="paragraph" w:styleId="CoverTitle"><w:name w:val="Cover title"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:before="2880" w:after="480"/><w:jc w:val="center"/></w:pPr><w:rPr><w:b/><w:sz w:val="40"/><w:szCs w:val="40"/></w:rPr></w:style><w:style w:type="paragraph" w:styleId="CoverAuthor"><w:name w:val="Cover author"/><w:basedOn w:val="Normal"/><w:pPr><w:jc w:val="center"/></w:pPr></w:style>${style('Heading1', 'heading 1', 32, true)}${style('Heading2', 'heading 2', 26, true)}${style('Heading3', 'heading 3', 24, true)}<w:style w:type="paragraph" w:styleId="SceneBreak"><w:name w:val="Scene Break"/><w:pPr><w:jc w:val="center"/></w:pPr></w:style></w:styles>`,
  });
}
