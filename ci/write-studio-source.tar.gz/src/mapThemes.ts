import type {TerrainMaterial} from './mapMaterials';
import type {BrushKind} from './mapDrawing';
export const mapThemes={
 medieval:{label:'Medieval',background:'#b9d9df',ink:'#303c35',halo:'#f5efd6',brushes:[{kind:'land',label:'Land',color:'#d9d0a4'},{kind:'water',label:'Water',color:'#b9d9df'}],symbols:['mountain','forest','village','tower','ruins','castle','windmill','cave','harbor']},
 modern:{label:'Modern city',background:'#e7e9e6',ink:'#263f47',halo:'#f8faf7',brushes:[{kind:'land',label:'Ground',color:'#d8d4ca'},{kind:'water',label:'Water',color:'#9bcad9'},{kind:'park',label:'Parks',color:'#a5c29b'},{kind:'road',label:'Streets',color:'#717b85'}],symbols:['building','hospital','station','airport','bridge','factory','school','stadium','police']},
 futuristic:{label:'Futuristic city',background:'#182a3e',ink:'#d7f6ff',halo:'#162537',brushes:[{kind:'land',label:'Ground',color:'#44576d'},{kind:'water',label:'Water',color:'#276a81'},{kind:'region',label:'Urban zones',color:'#677294'},{kind:'road',label:'Transit ways',color:'#57b9c6'}],symbols:['megatower','dome','spaceport','reactor','antenna','biodome','robotics','skybridge','portal']},
 space:{label:'Space',background:'#101629',ink:'#e3e9ff',halo:'#101629',brushes:[{kind:'nebula',label:'Nebulae',color:'#5f417b'},{kind:'region',label:'Space regions',color:'#253d66'},{kind:'water',label:'Deep space',color:'#101629'}],symbols:['star','planet','moon','spaceStation','blackHole','galaxy','asteroids','comet','spaceship','jumpGate']},
} as const;
export type MapTheme=keyof typeof mapThemes;
export function themeFor(value?:MapTheme){return mapThemes[value??'medieval'];}

/** Palette membership is explicit; saved strokes keep their original identity. */
export const themeMaterialIds:Record<MapTheme,TerrainMaterial[]>={
 medieval:['sea','earth','sand','grass','rock','mud'],
 modern:['pavement','cityWater','park','asphalt'],
 futuristic:['alloy','canal','district','transit'],
 space:['nebula','spaceRegion','deepSpace'],
};
export const materialBrushKind:Partial<Record<TerrainMaterial,BrushKind>>={sea:'water',cityWater:'water',canal:'water',deepSpace:'water',park:'park',asphalt:'road',district:'region',transit:'road',nebula:'nebula',spaceRegion:'region'};
export const isWaterMaterial=(kind:TerrainMaterial)=>kind==='sea'||kind==='cityWater'||kind==='canal';

/** Match the initial brush rather than selecting water just because it is first in a palette. */
export function defaultThemeMaterial(theme:MapTheme='medieval'):TerrainMaterial{return themeMaterialIds[theme].find(kind=>(materialBrushKind[kind]??'land')===mapThemes[theme].brushes[0].kind)??themeMaterialIds[theme][0];}
