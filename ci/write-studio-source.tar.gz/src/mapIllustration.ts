/** Original cenital artwork. Layered vector paint keeps the editor/export sharp without filters or shared IDs. */
export const painted=(art:string,ink='#494953')=>`<g data-map-illustration="painted" stroke="${ink}" stroke-width="1.1" stroke-linejoin="round" stroke-linecap="round">${art}</g>`;
export function roof(x:number,y:number,w:number,h:number,base='#b97759',light='#e5b783',dark='#88534b'){
 const m=x+w/2;
 return `<rect x="${x+2}" y="${y+3}" width="${w}" height="${h}" rx="3" fill="#182333" opacity=".2" stroke="none"/><rect x="${x}" y="${y}" width="${w}" height="${h}" rx="2" fill="${base}"/><path d="M${x+1} ${y+1}H${m}V${y+h-1}H${x+1}Z" fill="${light}" stroke="none"/><path d="M${m} ${y+1}H${x+w-1}V${y+h-1}H${m}Z" fill="${dark}" stroke="none"/><path d="M${m} ${y+1}V${y+h-1}M${x+2} ${y+2}H${x+w-2}" fill="none" stroke="${light}"/><path d="M${x+2} ${y+h*.35}H${m-1}m-${w/2-2} ${h*.28}H${m-1}" stroke="${base}" stroke-width=".7" opacity=".7"/>`;
}
export function canopy(x:number,y:number,r:number,base='#668061',light='#a9b57a',dark='#405f54'){
 return `<ellipse cx="${x+2}" cy="${y+3}" rx="${r}" ry="${r*.85}" fill="#22383b" opacity=".22" stroke="none"/><path d="M${x-r} ${y}q-${r*.15} -${r*.8} ${r*.7} -${r*.8}q${r*.4} -${r*.65} ${r*.95} 0q${r*.8} ${r*.1} ${r*.45} ${r*.85}q${r*.25} ${r*.8} -${r*.6} ${r*.85}q-${r*.7} ${r*.4} -${r*.9} -${r*.1}q-${r*.75} ${r*.1} -${r*.6} -${r*.8}Z" fill="${base}" stroke="${dark}"/><path d="M${x-r*.65} ${y}q-${r*.1} -${r*.55} ${r*.45} -${r*.5}q${r*.3} -${r*.4} ${r*.65} -.2" fill="none" stroke="${light}" stroke-width="2.5"/><path d="m${x-r*.25} ${y+r*.5} ${r*.4} -${r*.25} ${r*.4} .3" fill="none" stroke="${dark}" opacity=".6"/>`;
}
export function disk(x:number,y:number,r:number,base:string,light:string,dark:string){
 return `<circle cx="${x+1}" cy="${y+2}" r="${r}" fill="#142035" opacity=".22" stroke="none"/><circle cx="${x}" cy="${y}" r="${r}" fill="${base}"/><path d="M${x-r*.85} ${y-r*.2}Q${x-r*.5} ${y-r*.9} ${x+r*.2} ${y-r*.85}" fill="none" stroke="${light}" stroke-width="${Math.max(1.5,r*.18)}"/><path d="M${x+r*.7} ${y-r*.65}Q${x+r*1.3} ${y+r*.6} ${x-r*.15} ${y+r*.95}Q${x+r*.75} ${y+r*.4} ${x+r*.7} ${y-r*.65}Z" fill="${dark}" stroke="none"/>`;
}
export const medievalSymbols={
 mountain:painted('<path d="m6 34 9-19 17-9 19 13 8 23-17 16-23-4Z" fill="#8b9290"/><path d="m6 34 26-28-5 25-8 23Z" fill="#bdc2ad" stroke="none"/><path d="m32 6 19 13 8 23-25-8Z" fill="#64747b" stroke="none"/><path d="m27 31 7 3 8 24-23-4Z" fill="#9da994" stroke="none"/><path d="m32 6-9 19 8-4 8 7-4-13Z" fill="#e3e4ce"/><path d="m27 31 7 3m0 0 11 10m-25-7-5 9m30-20 5 9m-18 5-4 9" fill="none" stroke="#667b7a"/>'),
 forest:painted(canopy(17,41,12)+canopy(43,43,13)+canopy(31,22,17)+canopy(49,20,8), '#405f54'),
 village:painted('<path d="M5 33q22-12 54-3v25H5Z" fill="#bfab84" stroke="none" opacity=".45"/>'+roof(7,29,19,23)+roof(32,9,22,28)+roof(35,45,15,12,'#9d8872','#d1c09a','#746c65')+'<path d="m27 32 4 4 2 17" fill="none" stroke="#e8d6ae" stroke-width="4"/>'),
 tower:painted(disk(32,32,23,'#a9a28b','#e5d8b4','#777c76')+'<path d="M15 15h9v7h16v-7h9v9h-7v16h7v9h-9v-7H24v7h-9v-9h7V24h-7Z" fill="#d4c5a1"/><path d="M25 25h14v14H25Z" fill="#596365"/><path d="M26 26h12v3H26Z" fill="#8c9b8c" stroke="none"/>'),
 ruins:painted('<path d="m7 16 15-6 17 3 17 12-3 28-21 5-24-9Z" fill="#8f9d79" opacity=".35" stroke="none"/><path d="M11 15h18v7H18v25h10v7H11Zm28 3 15 6v28H36v-7h11V28l-9-4Z" fill="#c4b392"/><path d="m18 22 3 4-3 5m29 5-5 4 5 5" fill="none" stroke="#827d70"/><path d="m29 12 6 2-1 7-6-2Zm-2 39 6-3 5 7-8 3Z" fill="#a2967e"/>'),
};
