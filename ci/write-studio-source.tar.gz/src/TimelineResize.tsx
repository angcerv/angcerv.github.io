// Timeline keeps its established bounds and labels through the shared splitter.
export {default} from './PanelResize';
