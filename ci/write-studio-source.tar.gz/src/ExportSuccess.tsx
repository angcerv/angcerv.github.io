import {CheckCircle2} from 'lucide-react';
import {t} from './i18n';

export default function ExportSuccess({path,hint}:{path?:string;hint?:string}) {
 return <div className="export-success" role="status"><CheckCircle2 size={20} aria-hidden="true"/><div className="export-success-content"><strong>{t('Export completed')}</strong>{path&&<p>{t('Exported to')} <span>{path}</span></p>}{hint&&<p>{hint}</p>}</div></div>;
}
