import {focusDialog} from './dialogFocus';
import {useWorkspaceState} from './useWorkspaceState';
import {captureWorkspacePosition,restoreWorkspacePosition} from './workspaceNavigation';
import type {WorkspacePosition} from './workspaceNavigation';
import Dropdown from './Dropdown';
import FieldHelp from './FieldHelp';
import {continuityContexts,contextChoices,matchesContinuityContext,groupContinuityIssues,continuityFacts} from './continuityContext';
import type {ContinuityGrouping} from './continuityContext';
import {statusTone} from './semanticStatus';
import { useEffect, useMemo, useRef, useState } from 'react';
import { ClipboardCheck, Search, X, ArrowUpRight } from 'lucide-react';
import { createPortal } from 'react-dom';
import { t, useLanguage } from './i18n';
import type { Project } from './model';
import { reviewContinuity } from './continuity';
import type { ContinuityIssue, ContinuityKind } from './continuity';
import {continuityEvidence,loadContinuityDismissals,saveContinuityDismissals} from './narrativeContinuity';
import MentionChoiceDialog from './MentionChoiceDialog';
import { emptyWorld } from './worldbuilding';

export default function ContinuityReview({project,onClose,onOpen,onResolve,returnPosition}:{returnPosition?:WorkspacePosition;project:Project;onClose:()=>void;onOpen:(issue:ContinuityIssue,position?:WorkspacePosition)=>void;onResolve:(sceneId:string,range:{from:number;to:number},entryId:string)=>void}){
 const language=useLanguage(),dialog=useRef<HTMLDialogElement>(null),previous=useRef(typeof document==='undefined'?null:document.activeElement as HTMLElement|null);
 const pendingFocus=useRef<string|null>(null),[announcement,setAnnouncement]=useState('');
 const [filter,setFilter]=useWorkspaceState<ContinuityKind|'all'>('continuity.kind','all'),[query,setQuery]=useWorkspaceState('continuity.query',''),[choice,setChoice]=useState<ContinuityIssue|null>(null);
 const [grouping,setGrouping]=useWorkspaceState<ContinuityGrouping>('continuity.grouping','entry'),[contextId,setContextId]=useWorkspaceState('continuity.context','');
 const [dismissed,setDismissed]=useState(()=>loadContinuityDismissals(project.id)),[showDismissed,setShowDismissed]=useWorkspaceState('continuity.dismissed',false);
 useEffect(()=>saveContinuityDismissals(project.id,dismissed),[project.id,dismissed]);
 const issues=useMemo(()=>reviewContinuity(project),[project,language]);
 const labels={all:t('All'),age:t('Ages'),chronology:t('Scene chronology'),ambiguous:t('Ambiguous mentions'),broken:t('Broken links'),travel:t('Travel'),unused:t('Entries without appearances')};
 const evidence=useMemo(()=>new Map(issues.map(issue=>[issue.id,continuityEvidence(project,issue)])),[issues,project]);
 const isDismissed=(issue:ContinuityIssue)=>dismissed[issue.id]===evidence.get(issue.id);
 const dismissedCount=issues.filter(isDismissed).length;
 const visible=issues.filter(issue=>showDismissed?isDismissed(issue):!isDismissed(issue));
 const categories=['all','age','chronology','ambiguous','broken','travel','unused'] as const;
 const contexts=useMemo(()=>continuityContexts(project,issues),[project,issues]);
 const choices=useMemo(()=>contextChoices(project,grouping,contexts),[project,grouping,contexts]);
 const selectedContext=choices.some(choice=>choice.id===contextId)?contextId:'';
 const needle=query.normalize('NFD').replace(/\p{M}/gu,'').trim().toLocaleLowerCase();
 const facts=useMemo(()=>new Map(issues.map(issue=>[issue.id,continuityFacts(project,issue)])),[project,issues]);
 const names=useMemo(()=>new Map([...(project.worldbuilding?.entries??[]).map(entry=>['entry:'+entry.id,entry.title] as const),...project.chapters.flatMap(chapter=>chapter.scenes.map(scene=>['scene:'+scene.id,scene.title] as const)),...(project.plots?.threads??[]).map(plot=>['plot:'+plot.id,plot.title] as const)]),[project]);
 const scoped=visible.filter(issue=>{
  if(!matchesContinuityContext(contexts.get(issue.id),grouping,selectedContext))return false;
  if(!needle)return true;const context=contexts.get(issue.id);
  const linked=[...(context?.entryIds??[]).map(id=>names.get('entry:'+id)??''),...(context?.sceneIds??[]).map(id=>names.get('scene:'+id)??''),...(context?.plotIds??[]).map(id=>names.get('plot:'+id)??'')];
  return [issue.title,issue.context,issue.excerpt??'',...linked,...(facts.get(issue.id)??[]).map(fact=>fact.label+' '+fact.value)].some(value=>value.normalize('NFD').replace(/\p{M}/gu,'').toLocaleLowerCase().includes(needle));
 });
 const counts=Object.fromEntries(categories.map(kind=>[kind,scoped.filter(issue=>kind==='all'?issue.kind!=='unused':issue.kind===kind).length]));
 const results=scoped.filter(issue=>filter==='all'?issue.kind!=='unused':issue.kind===filter);
 const groups=groupContinuityIssues(project,results,grouping,contexts,selectedContext);
 const changeDismissal=(issue:ContinuityIssue)=>{const index=results.indexOf(issue);pendingFocus.current=results[index+1]?.id??results[index-1]?.id??'';setAnnouncement(t(showDismissed?'Warning restored':'Warning dismissed'));setDismissed(previous=>{const next={...previous};if(showDismissed)delete next[issue.id];else next[issue.id]=evidence.get(issue.id)!;return next;});};
 useEffect(()=>{if(pendingFocus.current===null)return;const article=[...(dialog.current?.querySelectorAll<HTMLElement>('[data-continuity-id]')??[])].find(node=>node.dataset.continuityId===pendingFocus.current);(article?.querySelector<HTMLButtonElement>('button')??dialog.current?.querySelector<HTMLButtonElement>('#continuity-context, #continuity-grouping'))?.focus();pendingFocus.current=null;},[dismissed,issues]);
 useEffect(()=>{const node=dialog.current;node?.showModal();focusDialog(node);const frame=requestAnimationFrame(()=>{if(node&&returnPosition)restoreWorkspacePosition(node,returnPosition,true);});return()=>{cancelAnimationFrame(frame);node?.close();if(previous.current?.isConnected)previous.current.focus();};},[]);
 const currentChoice=choice?issues.find(issue=>issue.id===choice.id):undefined;
 const openIssue=(issue:ContinuityIssue)=>{const position=captureWorkspacePosition(dialog.current);position.focusFallback={id:'continuity-grouping',tag:'BUTTON',path:[]};onOpen(issue,position);};
 const renderIssue=(issue:ContinuityIssue,groupId:string)=><article key={issue.id} data-continuity-id={issue.id} className={`continuity-item continuity-${issue.kind}`}><div className="continuity-item-heading"><h3>{issue.title}</h3><span className="semantic-status" data-semantic-tone={showDismissed?'neutral':statusTone('continuity',issue.kind)}>{labels[issue.kind]}</span></div><p className="continuity-context">{issue.context}</p>{!!facts.get(issue.id)?.length&&<dl className="continuity-facts">{(facts.get(issue.id)??[]).map((fact,index)=><div key={index}><dt>{fact.label}</dt><dd>{fact.value}</dd></div>)}</dl>}{issue.excerpt&&<p className="continuity-excerpt">{issue.excerpt}</p>}<div className="continuity-item-actions">{issue.kind==='ambiguous'&&<button type="button" onClick={()=>setChoice(issue)}>{t('Choose entry')}</button>}<button id={`continuity-open-${groupId}-${issue.id}`} type="button" onClick={()=>openIssue(issue.eventId&&(issue.kind==='age'||issue.kind==='chronology')?{...issue,entryId:undefined,sceneId:undefined}:issue)}><ArrowUpRight size={13}/>{issue.eventId&&(issue.kind==='age'||issue.kind==='chronology')?t('Open event'):issue.routeId?t('Open route on map'):issue.sceneId?t('Go to text'):issue.kind==='unused'?t('Open entry'):t('Review source')}</button>{issue.kind==='age'&&issue.entryId&&<button id={`continuity-entry-${groupId}-${issue.id}`} type="button" onClick={()=>openIssue({...issue,eventId:undefined})}>{t('Open entry')}<ArrowUpRight size={13}/></button>}{issue.kind==='chronology'&&issue.sceneId&&<button id={`continuity-scene-${groupId}-${issue.id}`} type="button" onClick={()=>openIssue({...issue,eventId:undefined})}>{t('Open scene')}<ArrowUpRight size={13}/></button>}{issue.relatedSceneIds?.map(id=>{const scene=project.chapters.flatMap(c=>c.scenes).find(s=>s.id===id);return scene&&<button id={`continuity-related-${groupId}-${issue.id}-${id}`} type="button" key={id} onClick={()=>openIssue({...issue,sceneId:id})}>{scene.title||t('Untitled scene')}<ArrowUpRight size={13}/></button>;})}<button type="button" onClick={()=>changeDismissal(issue)}>{showDismissed?t('Restore warning'):t('Dismiss as intentional')}</button></div></article>;
 const content=<dialog ref={dialog} id="continuity-review-dialog" className="continuity-review" aria-labelledby="continuity-title" onCancel={event=>{event.preventDefault();onClose();}}>
  <header><div><ClipboardCheck size={20} aria-hidden="true"/><h2 id="continuity-title">{t('Continuity review')}</h2></div><button title={t("Close")} type="button" className="icon-button ui-close-button" aria-label={t('Close')} onClick={onClose}><X size={18}/></button></header>
  <div className="continuity-review-body"><p className="continuity-intro">{t('Review ages, scene chronology, links and travel times. Warnings are suggestions: flashbacks and background references may be intentional.')}</p>
  <div className="continuity-filters" role="group" aria-label={t('Review categories')}>{categories.map(kind=><button type="button" key={kind} aria-pressed={filter===kind} onClick={()=>setFilter(kind)}>{labels[kind]}<span>{counts[kind]}</span></button>)}</div>
  <div className="continuity-context-controls"><div className="ui-form-field"><label htmlFor="continuity-grouping">{t('Group warnings')}<FieldHelp label={t('Group warnings')} description={t('Groups follow explicit links and confirmed mentions. Candidate entries remain ambiguous. A warning may appear in several linked contexts; the result count counts each warning once.')}/></label><Dropdown id="continuity-grouping" value={grouping} options={[{value:'entry',label:t('By entry')},{value:'scene',label:t('By scene')},{value:'plot',label:t('By plot')},{value:'none',label:t('No grouping')}]} onChange={value=>{setGrouping(value as ContinuityGrouping);setContextId('');}}/></div>{grouping!=='none'&&<div className="ui-form-field"><label htmlFor="continuity-context">{t('Review context')}</label><Dropdown id="continuity-context" searchable value={selectedContext} options={[{value:'',label:t('All contexts')},...choices.map(choice=>({value:choice.id,label:choice.detail?`${choice.title} · ${choice.detail}`:choice.title,searchText:choice.title}))]} onChange={setContextId}/></div>}</div>
  <label className="continuity-search"><Search size={15} aria-hidden="true"/><span className="visually-hidden">{t('Search continuity review')}</span><input type="search" value={query} placeholder={t('Search scenes, entries or text…')} onChange={event=>setQuery(event.target.value)}/></label>
  {filter==='unused'&&<p className="continuity-intro">{t('Only confirmed text mentions and manual scene links count as appearances.')}</p>}
  <div className="continuity-review-status"><button type="button" aria-pressed={showDismissed} onClick={()=>setShowDismissed(!showDismissed)}>{showDismissed?t('Show pending warnings'):t('Dismissed warnings ({0})',dismissedCount)}</button><small>{t('Dismissals are saved on this computer. Changed source data brings a warning back.')}</small></div>
  <p className="visually-hidden" role="status">{announcement}</p><p className="continuity-result-count" role="status">{t('{0} results',results.length)}</p>
  <div className="continuity-results">{groups.map(group=><section key={group.id} className="continuity-context-group">{group.title&&<header><h3>{group.title}</h3>{group.detail&&<span>{group.detail}</span>}<span className="compact-count">{group.issues.length}</span></header>}{group.issues.map(issue=>renderIssue(issue,group.id))}</section>)}{!results.length&&<div className="continuity-empty ui-empty-state"><ClipboardCheck size={30}/><p>{query?t('No matching results.'):visible.some(issue=>filter==='unused'||issue.kind!=='unused')?t('Nothing to review in this category.'):showDismissed?t('No dismissed warnings.'):t('No pending continuity warnings.')}</p>{(query||selectedContext||filter!=='all')&&<button type="button" onClick={()=>{setQuery('');setContextId('');setFilter('all');}}>{t('Clear filters')}</button>}</div>}</div>
 </div></dialog>;
 return <>{typeof document==='undefined'?content:createPortal(content,document.body)}{currentChoice?.sceneId&&currentChoice.range&&currentChoice.candidateIds&&<MentionChoiceDialog world={project.worldbuilding??emptyWorld} ids={currentChoice.candidateIds} label={currentChoice.title} onClose={()=>setChoice(null)} onChoose={id=>{onResolve(currentChoice.sceneId!,currentChoice.range!,id);setChoice(null);}}/>}</>;
}
