import type {Project} from './model';
import {textReferences,textReferencePlainText} from './textReferenceTokens';
import {isEntryReference} from './worldbuilding';
import {sceneMentions} from './mentionDetection';
import {timelineEventEntryIds} from './timeline';
import {t,getLanguage} from './i18n';
export type TextReferenceSource={range?:{from:number;to:number};routeId?:string;markerId?:string;kind:'entry'|'scene'|'chapter'|'chapterPlan'|'scenePlan'|'plot'|'arc'|'event'|'idea'|'map'|'template';id:string;entryId:string;label:string;field:string;excerpt:string;count:number};
const projectIndexes=new WeakMap<Project,{language:string;sources:TextReferenceSource[]}>();
// Only reference-bearing fields are parsed; keep this cache bounded across edits.
const parsedTexts=new Map<string,{counts:Map<string,number>;excerpt:string}>();
function referencesIn(value:string){
 const cached=parsedTexts.get(value);if(cached)return cached;
 const counts=new Map<string,number>();
 for(const ref of textReferences(value))counts.set(ref.entryId,(counts.get(ref.entryId)??0)+1);
 const result={counts,excerpt:counts.size?textReferencePlainText(value).slice(0,220):''};
 parsedTexts.set(value,result);if(parsedTexts.size>2000)parsedTexts.delete(parsedTexts.keys().next().value!);
 return result;
}
/** References are indexed from saved text; no offsets or duplicated link tables can go stale. */
export function indexProjectTextReferences(project:Project):TextReferenceSource[]{
 const language=getLanguage(),cached=projectIndexes.get(project);
 if(cached?.language===language)return cached.sources;
 const sources:TextReferenceSource[]=[];
 function add(kind:TextReferenceSource['kind'],id:string,label:string,field:string,value:unknown){
  if(typeof value!=='string')return;
  const {counts,excerpt}=referencesIn(value);
  for(const [entryId,count] of counts)sources.push({kind,id,label,field,entryId,count,excerpt});
 }
 const world=project.worldbuilding;
 for(const entry of world?.entries??[]){
  const template=world?.templates.find(template=>template.id===entry.templateId);
  for(const [fieldId,value] of Object.entries(entry.values)){
   const field=template?.fields.find(field=>field.id===fieldId)?.label??t('Untitled field');
   add('entry',entry.id,entry.title,field,value);
   if(isEntryReference(value))sources.push({kind:'entry',id:entry.id,label:entry.title,field,entryId:value.entryId,count:1,excerpt:''});
  }
 }
 for(const template of world?.templates??[])for(const field of template.fields)add('template',template.id,template.title,field.label,field.description);
 for(const chapter of project.chapters){
  for(const field of ['purpose','conflict','turn','outcome','notes'] as const)add('chapterPlan',chapter.id,chapter.title,t('Chapter planning'),chapter.planning?.[field]);
  add('chapter',chapter.id,chapter.title,t('Chapter synopsis'),chapter.synopsis);
  for(const scene of chapter.scenes){
   for(const field of ['goal','conflict','change'] as const)add('scenePlan',scene.id,`${chapter.title} / ${scene.title}`,t('Scene intention'),scene.planning?.[field]);
   add('scene',scene.id,`${chapter.title} / ${scene.title}`,t('Scene synopsis'),scene.synopsis);
   for(const comment of scene.reviewComments??[])add('scene',scene.id,scene.title,t('Review comment'),comment.text);
   if(world&&typeof scene.content==='string'){
    const counts=new Map<string,number>();
    for(const mention of sceneMentions(scene,world))if(mention.entryIds.length===1)counts.set(mention.entryIds[0],(counts.get(mention.entryIds[0])??0)+1);
    for(const entryId of new Set([...(scene.entryIds??[]),...counts.keys()]))sources.push({kind:'scene',id:scene.id,label:`${chapter.title} / ${scene.title}`,field:t('Manuscript'),entryId,count:counts.get(entryId)??1,excerpt:''});
   }
  }
 }
 for(const plot of project.plots?.threads??[]){add('plot',plot.id,plot.title,t('Plot notes'),plot.notes);for(const beat of plot.beats)add('plot',plot.id,plot.title,project.chapters.flatMap(c=>c.scenes).find(s=>s.id===beat.sceneId)?.title??t('Deleted scene'),beat.note);}
 for(const arc of project.plots?.arcs??[]){sources.push({kind:'arc',id:arc.id,label:arc.title,field:t('Character'),entryId:arc.entryId,count:1,excerpt:''});for(const field of ['startingPoint','desire','innerConflict','resolution','notes'] as const)add('arc',arc.id,arc.title,t('Character arcs'),arc[field]);for(const beat of arc.beats)for(const field of ['note','goal','conflict','relationships'] as const)add('arc',arc.id,arc.title,project.chapters.flatMap(chapter=>chapter.scenes).find(scene=>scene.id===beat.sceneId)?.title??t('Deleted scene'),beat[field]);}
 for(const event of project.timeline?.events??[])add('event',event.id,event.title,t('Event notes'),event.notes);
 for(const idea of project.worldIdeas??[]){add('idea',idea.id,idea.title,t('Ideas and decisions'),idea.description);add('idea',idea.id,idea.title,t('Decision taken'),idea.decision);}
 for(const map of project.maps?.maps??[]){
  add('map',map.id,map.title,t('Map notes'),map.notes);
  for(const marker of map.markers){const start=sources.length;add('map',map.id,`${map.title} / ${marker.title}`,marker.title,marker.notes);for(let i=start;i<sources.length;i++)sources[i]={...sources[i],markerId:marker.id};}
  for(const route of map.routes??[]){const start=sources.length;add('map',map.id,`${map.title} / ${route.title}`,route.title,route.notes);for(let i=start;i<sources.length;i++)sources[i]={...sources[i],routeId:route.id};}
 }
 for(const event of project.timeline?.events??[])for(const entryId of new Set(timelineEventEntryIds({...event,entryIds:event.entryIds??[]})))sources.push({kind:'event',id:event.id,entryId,label:event.title,field:t('Linked event entry'),excerpt:'',count:1});
 for(const map of project.maps?.maps??[])for(const marker of map.markers)if(marker.entryId)sources.push({kind:'map',id:map.id,markerId:marker.id,entryId:marker.entryId,label:`${map.title} / ${marker.title}`,field:t('Map marker'),excerpt:'',count:1});
 projectIndexes.set(project,{language,sources});
 return sources;
}
