import { menuNavigationIndex } from './menuNavigation';
import { Fragment, useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { floatingPanelPosition } from './floatingPanelPosition';
import type { ReactNode } from 'react';
import { Check, ChevronDown } from 'lucide-react';
export type MenuAction = { label: string; group?:string; id?:string; description?:string; selected?:boolean;checked?:boolean;icon?: ReactNode; disabled?: boolean; danger?: boolean; disabledReason?:string; onClick: () => void };
export default function ActionMenu({ label, children, actions, disabled = false, iconOnly=false, variant='secondary',animated=false,footer }: { label: string; children: ReactNode; footer?:ReactNode; actions: MenuAction[]; disabled?: boolean; iconOnly?:boolean;animated?:boolean;variant?:'secondary'|'primary'|'row' }) {
  const [open, setOpen] = useState(false), id = useId();
  const focusLast=useRef(false);
  const popup = useRef<HTMLDivElement>(null);
  const [position,setPosition]=useState<ReturnType<typeof floatingPanelPosition> | null>(null);
  const root = useRef<HTMLDivElement>(null), trigger = useRef<HTMLButtonElement>(null);
 const [closing,setClosing]=useState(false),exitTimer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
 const [pointerRestored,setPointerRestored]=useState(false);
 function pointerFocus(pointer:boolean){trigger.current?.toggleAttribute?.('data-pointer-focus',pointer);setPointerRestored(pointer);}
 function changeOpen(next:boolean){
  clearTimeout(exitTimer.current);
  if(!next&&open&&animated){setClosing(true);exitTimer.current=setTimeout(()=>setClosing(false),160);}else setClosing(false);
  setOpen(next);
 }
 useEffect(()=>()=>clearTimeout(exitTimer.current),[]);
  useEffect(() => { if (disabled) changeOpen(false); }, [disabled]);
  useLayoutEffect(()=>{
    if(!open)return;
    const place=()=>{const rect=trigger.current?.getBoundingClientRect();if(rect)setPosition(floatingPanelPosition(rect,{width:window.innerWidth,height:window.innerHeight},variant==='row'?200:280,variant==='row'?actions.length*48+16:360));};
    place();const scroll=(event:Event)=>{if(!popup.current?.contains(event.target as Node))changeOpen(false);};
    window.addEventListener('resize',place);window.addEventListener('scroll',scroll,true);
    return()=>{window.removeEventListener('resize',place);window.removeEventListener('scroll',scroll,true);};
  },[open,variant,actions.length]);
  useEffect(() => {
    if (!open || !position) return;
    const items=Array.from(popup.current?.querySelectorAll<HTMLButtonElement>(':is([role="menuitem"],[role="menuitemradio"],[role="menuitemcheckbox"]):not(:disabled)') ?? []);
    items[focusLast.current ? items.length-1 : 0]?.focus();focusLast.current=false;
    const outside = (event: Event) => { if (!root.current?.contains(event.target as Node) && !popup.current?.contains(event.target as Node)) changeOpen(false); };
    const observer=new MutationObserver(()=>{if(trigger.current?.matches(':disabled') || trigger.current?.closest('[hidden],[inert]'))changeOpen(false);});
    for(let node:HTMLElement|null=trigger.current;node;node=node.parentElement)observer.observe(node,{attributes:true,attributeFilter:['disabled','hidden','inert']});
    document.addEventListener('pointerdown', outside); document.addEventListener('focusin', outside);
    return () => { observer.disconnect();document.removeEventListener('pointerdown', outside); document.removeEventListener('focusin', outside); };
  }, [open, !!position]);
  useEffect(()=>{if(!pointerRestored)return;const keyboard=()=>pointerFocus(false);document.addEventListener('keydown',keyboard,true);return()=>document.removeEventListener('keydown',keyboard,true);},[pointerRestored]);
  return <div ref={root} className="action-menu" onKeyDown={event => {
    if (event.key === 'Escape' && open) { event.preventDefault(); event.stopPropagation(); changeOpen(false); trigger.current?.focus(); }
    if(event.key==='Tab' && open) {
      event.preventDefault();changeOpen(false);
      const controls=Array.from(document.querySelectorAll<HTMLElement>('button,input,textarea,select,a[href],[tabindex="0"]')).filter(element=>!element.matches(':disabled') && !element.closest('[hidden],[inert]') && element.getClientRects().length>0 && !popup.current?.contains(element));
      const index=controls.indexOf(trigger.current!);(controls[index+(event.shiftKey?-1:1)] ?? trigger.current)?.focus();return;
    }
    if (!['ArrowDown','ArrowUp','Home','End'].includes(event.key)) return;
    event.preventDefault(); if (!open) { focusLast.current=event.key==='ArrowUp' || event.key==='End';changeOpen(true); return; }
    const items = Array.from(popup.current?.querySelectorAll<HTMLButtonElement>(':is([role="menuitem"],[role="menuitemradio"],[role="menuitemcheckbox"]):not(:disabled)') ?? []), current = items.indexOf(document.activeElement as HTMLButtonElement);
    items[menuNavigationIndex(event.key,current,items.length)]?.focus();
  }}><button ref={trigger} type="button" className={`${iconOnly?'action-menu-trigger quick-action action-menu-icon':'action-menu-trigger'}${variant==='primary'?' primary-button':variant==='row'?' action-menu-row':''}`} aria-label={label} title={label} aria-haspopup="menu" aria-expanded={open} aria-controls={open ? id : undefined} disabled={disabled} onPointerDown={()=>pointerFocus(true)} onClick={event => {pointerFocus((event?.detail??0)>0);changeOpen(!open);}}>{children}{!iconOnly&&<ChevronDown size={13} />}</button>{(open||closing) && position && createPortal(<div ref={popup} id={id} inert={!open} aria-hidden={!open} className={`app-menu-popup action-menu-popup${variant==='row'?' action-menu-popup-row':''}${animated?' is-animated':''}${closing?' is-closing':''}`} style={position} role="menu" aria-label={label}>{actions.map((action,index) => <Fragment key={action.id??action.label}>{action.group&&action.group!==actions[index-1]?.group&&<><div role="separator" className="app-menu-divider"/><div className="app-menu-section-label">{action.group}</div></>}<button type="button" role={action.checked!==undefined?"menuitemcheckbox":action.selected===undefined?"menuitem":"menuitemradio"} aria-checked={action.checked??action.selected} key={action.id??action.label} disabled={action.disabled} className={action.danger ? 'danger-menu-action' : ''} onClick={event => { pointerFocus((event?.detail??0)>0);if(action.checked===undefined){changeOpen(false); trigger.current?.focus();} if(!trigger.current?.matches(':disabled') && !trigger.current?.closest('[hidden],[inert]'))action.onClick(); }}>{action.checked!==undefined&&<span className="menu-checkbox-mark" aria-hidden="true">{action.checked&&<Check size={12}/>}</span>}{action.icon}{(action.disabled&&action.disabledReason)||action.description?<span className="menu-action-copy">{action.label}<small>{action.disabled?action.disabledReason??action.description:action.description}</small></span>:action.label}</button></Fragment>)}{footer}</div>,trigger.current?.closest('dialog[open],[data-relationship-options]')??document.body)}</div>;
}
