import {useState} from 'react';
import ProjectModal from './ProjectModal';
import {t} from './i18n';
export default function ProjectRenameDialog({title,busy=false,onClose,onSave}:{title:string;busy?:boolean;onClose:()=>void;onSave:(title:string)=>void}){
 const [name,setName]=useState(title),trimmed=name.trim(),invalid=!trimmed;
 return <ProjectModal variant="confirmation" title={t('Rename project')} busy={busy} onClose={onClose}><form onSubmit={event=>{event.preventDefault();if(!busy&&trimmed)onSave(trimmed);}}><div className="ui-form-field"><label htmlFor="rename-project-title">{t('Project name')}</label><input id="rename-project-title" value={name} maxLength={Math.max(120,title.length)} required disabled={busy} aria-invalid={invalid} aria-describedby={invalid?'rename-project-error':undefined} onChange={event=>setName(event.target.value)}/>{invalid&&<p id="rename-project-error" className="prompt-error" role="alert">{t('Enter a project name.')}</p>}</div><div className="welcome-actions"><button type="button" className="quick-action quick-action-text" disabled={busy} onClick={onClose}>{t('Cancel')}</button><button type="submit" className="primary-button" disabled={busy||invalid}>{t('Save name')}</button></div></form></ProjectModal>;
}
