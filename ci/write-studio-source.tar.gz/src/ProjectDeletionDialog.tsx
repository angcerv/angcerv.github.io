import {focusDialog} from './dialogFocus';
import {message,t,buttonLabel} from './i18n';
import { useEffect, useRef, useState } from 'react';
import { Trash2 } from 'lucide-react';
import type { ProjectDeletionTarget } from './storage';
export default function ProjectDeletionDialog({target,busy,error,onCancel,onConfirm}:{target:ProjectDeletionTarget;busy:boolean;error:string;onCancel:()=>void;onConfirm:(confirmation:string)=>void}) {
 const ref=useRef<HTMLDialogElement>(null);
 const [confirmation,setConfirmation]=useState('');
 const expected=target.title || 'DELETE';
 useEffect(()=>{const dialog=ref.current;dialog?.showModal();focusDialog(dialog);return()=>dialog?.close();},[]);
 return <dialog ref={ref} className="manuscript-deletion-dialog project-deletion-dialog" aria-labelledby="delete-project-title" onCancel={event=>{event.preventDefault();if(!busy)onCancel();}}>
  <div className="manuscript-delete-icon"><Trash2 size={22}/></div><h2 id="delete-project-title">{t("Delete project?")}</h2>
  <p>{t("Move “")}{target.title || t("Untitled project")}{t("” and its entire folder to the Trash? This includes all writing, worldbuilding, images and version history. You can recover the folder from the system Trash.")}</p>
  <p className="deletion-project-path">{target.path}</p>
  <form onSubmit={event=>{event.preventDefault();if(!busy && confirmation===expected)onConfirm(confirmation);}}>
   <label htmlFor="delete-project-confirmation">{t("Type") + " "}<strong>{expected}</strong>{" " + t("to confirm")}</label>
   <input id="delete-project-confirmation" value={confirmation} onChange={event=>setConfirmation(event.target.value)} disabled={busy} autoComplete="off" autoCapitalize="off" spellCheck={false}/>
   {error && <p role="alert" className="prompt-error">{message(error)}</p>}
   <div className="manuscript-dialog-actions"><button type="button" disabled={busy} onClick={onCancel}>{t("Cancel")}</button><button type="submit" className="danger-button" disabled={busy || confirmation!==expected}>{busy?buttonLabel("Moving to Trash…"):t("Move to Trash")}</button></div>
  </form>
 </dialog>;
}
