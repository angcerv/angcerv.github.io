import type { Project } from './model';
// The disk revision advances, but edits made during I/O always win for content.
export function reconcileAutosave(current: Project, snapshot: Project, saved: Project): { project: Project; hasNewEdits: boolean } {
  if (current.id !== snapshot.id || saved.id !== snapshot.id) throw new Error('Autosave project changed during save.');
  return current === snapshot ? { project: saved, hasNewEdits: false } : { project: { ...current, revision: saved.revision }, hasNewEdits: true };
}
