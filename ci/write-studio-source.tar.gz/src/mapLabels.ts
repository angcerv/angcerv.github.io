import {conservativeMarkerLabelWidth,wrapMarkerLabel,markerLabelCenter,markerLabelLeader} from './mapMarkerLabels';
import type {MarkerLabelOffset} from './mapMarkerLabels';
import {pointInRing} from './mapRegions';
import type {MapRegion,RegionPoint} from './mapRegions';
export type MapLabel={id:string;kind:'marker'|'region';text:string;point:RegionPoint;labelOffset?:MarkerLabelOffset;fixed?:boolean;selected?:boolean;show?:boolean};
export type MapLabelPlacement={x:number;y:number;width:number;height:number;visible:boolean;text:string;anchor?:number;leader?:{x1:number;y1:number;x2:number;y2:number}};
export type MapLabelLayoutOptions={previous?:ReadonlyMap<string,MapLabelPlacement>;viewport?:{x:number;y:number;width:number;height:number};measureText?:(text:string)=>number};
const regionAnchors=new WeakMap<MapRegion,RegionPoint>();
export function regionLabelPoint(region:MapRegion):RegionPoint{if(region.labelPosition)return region.labelPosition;const cached=regionAnchors.get(region);if(cached)return cached;const point=automaticRegionLabelPoint(region);regionAnchors.set(region,point);return point;}
function automaticRegionLabelPoint(region:MapRegion):RegionPoint{if(region.labelPosition)return region.labelPosition;const center={x:region.points.reduce((n,p)=>n+p.x,0)/region.points.length,y:region.points.reduce((n,p)=>n+p.y,0)/region.points.length};const inside=(p:RegionPoint)=>pointInRing(p,region.points)&&!(region.holes??[]).some(hole=>pointInRing(p,hole));if(inside(center))return center;const candidates:RegionPoint[]=[];for(let y=1;y<40;y++)for(let x=1;x<40;x++){const p={x:x/40,y:y/40};if(inside(p))candidates.push(p);}return candidates.sort((a,b)=>(a.x-center.x)**2+(a.y-center.y)**2-((b.x-center.x)**2+(b.y-center.y)**2))[0]??region.points[0];}
/** Pixel-space labels keep a comfortable size at every zoom. Only density changes. */
export function layoutMapLabels(items:MapLabel[],width:number,height:number,options:MapLabelLayoutOptions={}){
 const result=new Map<string,MapLabelPlacement>();
 const bounds=options.viewport??{x:0,y:0,width,height};
 const viewport={left:Math.max(0,bounds.x),top:Math.max(0,bounds.y),right:Math.min(width,bounds.x+bounds.width),bottom:Math.min(height,bounds.y+bounds.height)};
 const occupied=items.filter(i=>i.kind==='marker').map(i=>({x:i.point.x*width-19,y:i.point.y*height-19,width:38,height:38}));
 const intersects=(a:typeof occupied[number],b:typeof occupied[number],gap:number)=>a.x<b.x+b.width+gap&&a.x+a.width+gap>b.x&&a.y<b.y+b.height+gap&&a.y+a.height+gap>b.y;
 const sorted=items.filter(item=>item.show!==false||item.selected).sort((a,b)=>Number(!!b.selected)-Number(!!a.selected)||Number(!!b.fixed||!!b.labelOffset)-Number(!!a.fixed||!!a.labelOffset)||Number(a.kind==='region')-Number(b.kind==='region')||a.id.localeCompare(b.id));
 for(const item of sorted){
  const marker=item.kind==='marker';
  const {left,top,right,bottom}=marker?viewport:{left:0,top:0,right:width,bottom:height},availableWidth=Math.max(1,right-left),availableHeight=Math.max(1,bottom-top);
  const charWidth=(c:string)=>c.charCodeAt(0)>255||/[MW@]/.test(c)?14:/[A-Z]/.test(c)?11:/[il.,' ]/.test(c)?5:9;
  const measure=marker?(options.measureText??conservativeMarkerLabelWidth):(value:string)=>Array.from(value).reduce((n,c)=>n+charWidth(c),0);
  const full=item.text.replace(/\s+/g,' ').trim(),maximum=marker?240:Math.min(190,availableWidth),padding=marker?14:16;
  let text=full,lines=1,w:number;
  if(marker){const wrapped=wrapMarkerLabel(full,maximum-padding,measure);text=wrapped.join('\n');lines=wrapped.length;w=Math.max(30,...wrapped.map(line=>measure(line)+padding));}
  else{const chars=Array.from(full);if(measure(text)>maximum-padding){let used=0;text='';for(const char of chars){if(used+charWidth(char)+charWidth('…')>maximum-padding)break;text+=char;used+=charWidth(char);}text+='…';}w=Math.min(maximum,Math.max(30,measure(text)+padding));}
  const h=marker?lines*18+6:Math.min(availableHeight,24),px=item.point.x*width,py=item.point.y*height;
  const manual=marker&&item.labelOffset?markerLabelCenter(item.labelOffset,w,h):undefined;
  const offsets=manual?[[manual.x,manual.y]]:item.fixed?[[0,0]]:marker?[[0,25+h/2],[0,-25-h/2],[25+w/2,0],[-25-w/2,0],[25+w/2,25+h/2],[-25-w/2,25+h/2],[25+w/2,-25-h/2],[-25-w/2,-25-h/2]]:[[0,0],[0,-30],[0,30],[-45,0],[45,0],[0,-60],[0,60],[-80,0],[80,0]];
  const remembered=options.previous?.get(item.id)?.anchor;
  const order=offsets.map((_,i)=>i);if(marker&&!manual&&remembered!==undefined&&remembered<order.length){order.splice(order.indexOf(remembered),1);order.unshift(remembered);}
  let placement:MapLabelPlacement|undefined,best=Infinity;
  for(const anchor of order){const [dx,dy]=offsets[anchor],box={x:manual?px+dx-w/2:Math.max(left,Math.min(right-w,px+dx-w/2)),y:manual?py+dy-h/2:Math.max(top,Math.min(bottom-h,py+dy-h/2)),width:w,height:h};
   const collisions=occupied.filter(other=>intersects(box,other,marker?3:5)).length,visible=collisions===0;
   if(collisions<best){placement={...box,visible:false,text,anchor};best=collisions;}
   if(visible){placement={...box,visible:true,text,anchor};break;}
  }
  const chosen=placement!;if(item.selected||item.fixed||manual)chosen.visible=true;
  // Offscreen selections keep their inspector, without pulling a name away from its point.
  if(marker&&(px<left-16||px>right+16||py<top-16||py>bottom+16))chosen.visible=false;
  if(marker)chosen.leader=markerLabelLeader(chosen.x-px,chosen.y-py,w,h);
  if(chosen.visible)occupied.push(chosen);result.set(item.id,chosen);
 }
 return result;
}
