export type TextReference={entryId:string;label:string;from:number;to:number};
const validId=/^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;
export function encodeTextReference(entryId:string,label:string){
 if(!label.trim())throw new Error('A text reference needs a label.');
 if(!validId.test(entryId))throw new Error('Invalid text reference identifier.');
 return `[[entry:${entryId}|${label.replace(/[\r\n]+/g,' ').replace(/[\\\[\]]/g,'\\$&')}]]`;
}
export function textReferenceAt(source:string,from:number):TextReference|undefined{
 const match=/^\[\[entry:([0-9a-f-]{36})\|((?:\\[^\r\n]|[^\\\]\r\n]|\](?!\]))*)\]\]/i.exec(source.slice(from));
 if(!match||!validId.test(match[1])||!match[2].trim())return;
 return {entryId:match[1],label:match[2].replace(/\\(.)/g,'$1'),from,to:from+match[0].length};
}
export function textReferences(source:string):TextReference[]{
 const found:TextReference[]=[];
 for(let i=0;i<source.length;i++){
  if(source[i]==='\\'){i++;continue;}
  if(source.startsWith('[[entry:',i)){const ref=textReferenceAt(source,i);if(ref){found.push(ref);i=ref.to-1;}}
 }
 return found;
}
export function mapTextReferences(source:string,map:(ref:TextReference)=>string){
 let result='',position=0;
 for(const ref of textReferences(source)){result+=source.slice(position,ref.from)+map(ref);position=ref.to;}
 return result+source.slice(position);
}
export const textReferencePlainText=(source:string)=>mapTextReferences(source,ref=>ref.label);
export const remapTextReferences=(source:string,remap:(id:string)=>string)=>mapTextReferences(source,ref=>encodeTextReference(remap(ref.entryId),ref.label));
export function insertTextReference(source:string,from:number,to:number,entryId:string,label:string){
 const start=Math.max(0,Math.min(source.length,from)),end=Math.max(start,Math.min(source.length,to));
 const token=encodeTextReference(entryId,label);return {value:source.slice(0,start)+token+source.slice(end),caret:start+token.length};
}
