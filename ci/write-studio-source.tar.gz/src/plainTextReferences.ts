import {Extension} from '@tiptap/core';
import {Plugin} from '@tiptap/pm/state';
import {isHistoryTransaction} from '@tiptap/pm/history';
import type {JSONContent} from '@tiptap/react';
import {textReferences,encodeTextReference} from './textReferenceTokens';

/** Plain fields retain literal punctuation; only entry tokens become inline nodes. */
export function plainReferenceDocument(value:string):JSONContent{
 return {type:'doc',content:value.split('\n').map(line=>{
  const content:JSONContent[]=[];let from=0;
  for(const ref of textReferences(line)){
   if(ref.from>from)content.push({type:'text',text:line.slice(from,ref.from)});
   content.push({type:'entryMention',attrs:{entryId:ref.entryId,label:ref.label}});from=ref.to;
  }
  if(from<line.length)content.push({type:'text',text:line.slice(from)});
  return {type:'paragraph',content};
 })};
}
export function plainReferenceText(doc:JSONContent,visible=false):string{
 function inline(node:JSONContent):string{
  if(node.type==='entryMention')return visible?node.attrs?.label??'':encodeTextReference(node.attrs?.entryId??'',node.attrs?.label??'');
  if(node.type==='text')return node.text??'';
  if(node.type==='hardBreak')return '\n';
  return (node.content??[]).map(inline).join('');
 }
 return (doc.content??[]).map(inline).join('\n');
}
export function plainReferenceLimit(maxLength:number,onReject:()=>void){
 return Extension.create({name:'plainReferenceLimit',addProseMirrorPlugins(){return [new Plugin({filterTransaction:(transaction,state)=>{
  if(!transaction.docChanged||transaction.getMeta('preventUpdate')||isHistoryTransaction(transaction))return true;
  const length=plainReferenceText(transaction.doc.toJSON(),true).length,previous=plainReferenceText(state.doc.toJSON(),true).length;
  if(length<=maxLength||length<previous)return true;
  onReject();return false;
 }})];}});
}

/** Keep legacy raw-text fragment offsets mapped to atomic reference positions. */
export function plainReferenceIndex(doc:JSONContent){
 let text='';const positions:{from:number;to:number}[]=[];
 const append=(value:string,pos:number,atom=false)=>{for(let i=0;i<value.length;i++){text+=value[i];positions.push({from:pos+(atom?0:i),to:pos+(atom?1:i+1)});}};
 let offset=0;
 for(const [index,paragraph] of (doc.content??[]).entries()){
  if(index)append('\n',offset,true);
  let position=offset+1;
  for(const node of paragraph.content??[]){
   if(node.type==='entryMention'){append(encodeTextReference(node.attrs?.entryId??'',node.attrs?.label??''),position,true);position++;}
   else if(node.type==='hardBreak'){append('\n',position,true);position++;}
   else {append(node.text??'',position);position+=node.text?.length??0;}
  }
  offset=position+1;
 }
 return {text,positions};
}
