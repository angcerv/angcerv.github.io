import type {Project} from './model';
import type {Entry,EntryValue,Field} from './worldbuilding';
import {entryImageIds,upgradeVisualResources,validateVisualResource} from './visualResources';
import {stampEntryModifications} from './entryOrdering';
import {editorialLabels,canonLabels} from './entryEditorial';
import {displayFieldValue} from './worldbuilding';
import {t} from './i18n';
export type EntryRecoveryRequest={source:Project;entryId:string};
function same(a:unknown,b:unknown):boolean{if(a===b)return true;if(Array.isArray(a)&&Array.isArray(b))return a.length===b.length&&a.every((value,index)=>same(value,b[index]));if(a&&b&&typeof a==='object'&&typeof b==='object'){const left=a as Record<string,unknown>,right=b as Record<string,unknown>,keys=new Set([...Object.keys(left),...Object.keys(right)]);return [...keys].every(key=>same(left[key],right[key]));}return false;}
function compatibleValue(field:Field,value:EntryValue|undefined){
 if(value===null||value===undefined||value==='')return true;
 if(field.fieldType==='picklist')return typeof value==='string'&&!!field.options?.some(option=>option.id===value);
 if(field.fieldType==='multiPicklist')return Array.isArray(value)&&value.every(id=>field.options?.some(option=>option.id===id));
 return true;
}
export function entryRecoveryPlan(current:Project,{source,entryId}:EntryRecoveryRequest){
 if(current.id!==source.id)throw new Error(t('This version belongs to another project.'));
 const entry=current.worldbuilding?.entries.find(entry=>entry.id===entryId),old=source.worldbuilding?.entries.find(entry=>entry.id===entryId);
 if(!entry||!old)throw new Error(t('The entry must exist in both the current project and the selected version.'));
 if(entry.templateId!==old.templateId)throw new Error(t('The entry uses a different template. Review the historical values manually.'));
 const template=current.worldbuilding?.templates.find(template=>template.id===entry.templateId),historical=source.worldbuilding?.templates.find(template=>template.id===old.templateId);
 if(!template||!historical)throw new Error(t('The entry template is unavailable.'));
 const skipped:Field[]=[],values={...entry.values};
 for(const field of historical.fields){const target=template.fields.find(item=>item.id===field.id);if(!target||target.fieldType!==field.fieldType||!compatibleValue(target,old.values[field.id])){if(old.values[field.id]!==undefined&&old.values[field.id]!==null&&old.values[field.id]!=='')skipped.push(field);continue;}if(old.values[field.id]===undefined)delete values[field.id];else values[field.id]=structuredClone(old.values[field.id]);}
 const next:Entry={...entry,title:old.title,archived:old.archived,values};
 for(const key of ['linkAliases','imageId','imageIds','editorialStatus','canonStatus'] as const){delete next[key];if(old[key]!==undefined)Object.assign(next,{[key]:structuredClone(old[key])});}
 return {entry:next,skipped,changed:!same({...entry,modifiedAt:undefined},{...next,modifiedAt:undefined})};
}
export function recoverEntry(current:Project,request:EntryRecoveryRequest,now=Date.now()):Project{
 const plan=entryRecoveryPlan(current,request);let world=current.worldbuilding!;
 world={...world,entries:world.entries.map(entry=>entry.id===request.entryId?plan.entry:entry)};
 const images=new Set(entryImageIds(plan.entry)),historicalResources=request.source.worldbuilding?.visualResources??[];for(const resource of historicalResources)if(images.has(resource.id)&&resource.variantOf)images.add(resource.variantOf);const missing=historicalResources.filter(resource=>images.has(resource.id)&&!world.visualResources?.some(current=>current.id===resource.id));
 if(plan.entry.imageIds?.length||missing.length){if(world.schemaVersion<11)world=upgradeVisualResources(world);if(missing.length)world={...world,visualResources:[...(world.visualResources??[]).filter(resource=>!missing.some(item=>item.id===resource.id)),...missing.map(item=>({...item}))]};}
 for(const resource of missing){const problem=validateVisualResource(resource,world.visualResources??[]);if(problem)throw new Error(t(problem));}
 return {...current,worldbuilding:stampEntryModifications(current.worldbuilding,world,undefined,undefined,now)};
}
export function compareEntryVersion(current:Project,source:Project,entryId:string){
 const currentWorld=current.worldbuilding,oldWorld=source.worldbuilding,entry=currentWorld?.entries.find(entry=>entry.id===entryId),old=oldWorld?.entries.find(entry=>entry.id===entryId);
 if(!entry||!old)return [];
 const fields=currentWorld?.templates.find(template=>template.id===entry.templateId)?.fields??[],oldFields=oldWorld?.templates.find(template=>template.id===old.templateId)?.fields??[];
 const result:{id:string;label:string;before:string;after:string}[]=[];
 function add(id:string,label:string,before:unknown,after:unknown,text:(value:any,old:boolean)=>string){if(!same(before,after))result.push({id,label,before:text(before,true),after:text(after,false)});}
 add('template',t('Template'),old.templateId,entry.templateId,(value,previous)=>(previous?oldWorld:currentWorld)?.templates.find(template=>template.id===value)?.title||t('Missing template'));
 add('title',t('Entry title'),old.title,entry.title,value=>value||'—');
 add('archive',t('Entry status'),old.archived,entry.archived,value=>t(value?'Archived':'Active'));
 add('editorial',t('Editorial status'),old.editorialStatus,entry.editorialStatus,value=>value?t(editorialLabels[value as keyof typeof editorialLabels]):t('Unclassified'));
 add('canon',t('Canon status'),old.canonStatus,entry.canonStatus,value=>value?t(canonLabels[value as keyof typeof canonLabels]):t('Unclassified'));
 add('aliases',t('Link aliases'),old.linkAliases??[],entry.linkAliases??[],value=>value.join(' · ')||'—');
 add('images',t('Images'),{main:old.imageId,ids:entryImageIds(old)},{main:entry.imageId,ids:entryImageIds(entry)},(value,previous)=>{const world=previous?oldWorld:currentWorld;return value.ids.map((id:string)=>{const label=world?.visualResources?.find(resource=>resource.id===id)?.title??t('Image');return label+(id===value.main?' · '+t('Main image'):'');}).join('\n')||'—';});
 for(const id of new Set([...oldFields.map(field=>field.id),...fields.map(field=>field.id)])){const oldField=oldFields.find(field=>field.id===id),field=fields.find(field=>field.id===id);add(id,field?.label||oldField?.label||t('Untitled field'),old.values[id],entry.values[id],(value,previous)=>displayFieldValue((previous?oldField:field)??oldField??field!,value,previous?oldWorld:currentWorld)||'—');}
 return result;
}
