import { suggestFolderName } from './model';
export function backupFilename(title:string,date=new Date()):string {
 const pad=(value:number)=>String(value).padStart(2,'0');
 const day=`${date.getFullYear()}-${pad(date.getMonth()+1)}-${pad(date.getDate())}`;
 const time=`${pad(date.getHours())}${pad(date.getMinutes())}${pad(date.getSeconds())}`;
 return `${suggestFolderName(title).slice(0,60)}-backup-${day}-${time}.zip`;
}
