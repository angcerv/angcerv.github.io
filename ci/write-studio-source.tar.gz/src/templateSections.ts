import { t } from './i18n';
import { enableSections, reorderField, updateTemplate } from './worldbuilding';
import type { Field, Template, Worldbuilding } from './worldbuilding';
export function fieldGroups(template:Template,activeOnly=false):{id:string;title:string;fields:Field[]}[]{
 const groups=(template.sections??[]).map(section=>({...section,fields:template.fields.filter(field=>field.sectionId===section.id&&(!activeOnly||!field.archived))}));
 const ids=new Set(groups.map(group=>group.id));
 const ungrouped=template.fields.filter(field=>(!field.sectionId||!ids.has(field.sectionId))&&(!activeOnly||!field.archived));
 return [...groups,{id:'',title:t('No section'),fields:ungrouped}];
}
function validName(template:Template,title:string,id?:string){
 if(!title.trim())throw new Error(t('Section names cannot be empty.'));
 if(template.sections?.some(section=>section.id!==id&&section.title.trim().toLocaleLowerCase()===title.trim().toLocaleLowerCase()))throw new Error(t('A section with this name already exists.'));
}
export function addSection(world:Worldbuilding,templateId:string,title:string):Worldbuilding{
 const template=world.templates.find(template=>template.id===templateId);if(!template)return world;validName(template,title);
 const upgraded=enableSections(world),current=upgraded.templates.find(template=>template.id===templateId)!;
 return updateTemplate(upgraded,{...current,sections:[...(current.sections??[]),{id:crypto.randomUUID(),title:title.trim()}]});
}
export function renameSection(world:Worldbuilding,templateId:string,id:string,title:string):Worldbuilding{
 const template=world.templates.find(template=>template.id===templateId);if(!template?.sections?.some(section=>section.id===id))return world;validName(template,title,id);
 return updateTemplate(world,{...template,sections:template.sections.map(section=>section.id===id?{...section,title:title.trim()}:section)});
}
export function deleteSection(world:Worldbuilding,templateId:string,id:string):Worldbuilding{
 const template=world.templates.find(template=>template.id===templateId);if(!template?.sections?.some(section=>section.id===id))return world;
 return updateTemplate(world,{...template,sections:template.sections.filter(section=>section.id!==id),fields:template.fields.map(field=>{if(field.sectionId!==id)return field;const {sectionId:_,...next}=field;return next;})});
}
export function reorderSection(world:Worldbuilding,templateId:string,id:string,direction:-1|1):Worldbuilding{
 const template=world.templates.find(template=>template.id===templateId),sections=[...(template?.sections??[])],index=sections.findIndex(section=>section.id===id),next=index+direction;
 if(!template||index<0||next<0||next>=sections.length)return world;
 [sections[index],sections[next]]=[sections[next],sections[index]];return updateTemplate(world,{...template,sections});
}
export function placeField(world:Worldbuilding,templateId:string,fieldId:string,sectionId?:string,beforeId?:string):Worldbuilding{
 const template=world.templates.find(template=>template.id===templateId),field=template?.fields.find(field=>field.id===fieldId);if(beforeId===fieldId)return world;
 if(!template||!field||(sectionId&&!template.sections?.some(section=>section.id===sectionId)))return world;
 const {sectionId:_,...rest}=field,next={...rest,...(sectionId?{sectionId}:{})},fields=template.fields.filter(field=>field.id!==fieldId);
 const index=beforeId?fields.findIndex(field=>field.id===beforeId&&field.sectionId===sectionId):-1;
 fields.splice(index<0?fields.length:index,0,next);return updateTemplate(world,{...template,fields});
}
export function moveWithinSection(world:Worldbuilding,templateId:string,fieldId:string,direction:-1|1):Worldbuilding{
 const template=world.templates.find(template=>template.id===templateId),field=template?.fields.find(field=>field.id===fieldId);if(!template||!field)return world;
 const siblings=template.fields.filter(item=>item.sectionId===field.sectionId),index=siblings.findIndex(item=>item.id===fieldId),target=siblings[index+direction];
 return target?reorderField(world,templateId,fieldId,template.fields.findIndex(item=>item.id===target.id)):world;
}
