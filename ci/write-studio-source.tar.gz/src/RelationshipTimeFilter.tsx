import {RotateCcw} from 'lucide-react';
import {useState} from 'react';
import StoryDateInput from './StoryDateInput';
import FieldHelp from './FieldHelp';
import type {StoryDate} from './timeline';
import {t} from './i18n';
type TimeFilterProps={id:string;at?:StoryDate;showEnded:boolean;onChange:(at:StoryDate|undefined,showEnded:boolean)=>void;showEndedControl?:boolean};
export function RelationshipEndedToggle({at,showEnded,onChange}:Pick<TimeFilterProps,'at'|'showEnded'|'onChange'>){
 return <label className="relationship-time-ended"><input type="checkbox" disabled={!at} checked={showEnded} onChange={event=>onChange(at,event.target.checked)}/>{t('Show ended connections')}</label>;
}
export default function RelationshipTimeFilter({id,at,showEnded,onChange,showEndedControl=true}:TimeFilterProps){
 const [reset,setReset]=useState(0);
 return <div className="relationship-time-filter"><div className="relation-filter-field"><label htmlFor={id}>{t('Story date')}<FieldHelp label={t('At this story date')} description={t('Story date accepts a year, year-MM or year-MM-DD, including negative years and year zero. Dates apply on Enter or when leaving the field. Unknown or partial dates can remain uncertain.')}/></label><StoryDateInput key={reset} compact applyLabel id={id} value={at} onChange={date=>onChange(date??undefined,date?showEnded:false)}/></div>{showEndedControl&&<RelationshipEndedToggle at={at} showEnded={showEnded} onChange={onChange}/>}<button type="button" className="quick-action quick-action-text relationship-time-reset" aria-label={t('Reset story date')} title={t('Reset story date')} onClick={()=>{setReset(reset+1);onChange(undefined,false);}}><RotateCcw size={16} aria-hidden="true"/>{t('Reset date')}</button></div>;
}
