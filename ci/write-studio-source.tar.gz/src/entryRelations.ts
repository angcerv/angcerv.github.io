import {supportsPartnership} from './partnership';
import type {PartnershipStatus} from './partnership';
import {relationshipStatus} from './relationshipTime';
import {t} from './i18n';
import {formatStoryDate,parseStoryDate,validatePeriod} from './timeline';
import type {StoryDate} from './timeline';
import type {RelationGraphView} from './relationGraph';
import type {Entry,Worldbuilding} from './worldbuilding';

// In v2 title is the source participant's role; inverseTitle is the target role.
// name identifies the reusable type independently of the participant roles.
export type GenealogyMeaning={kind:'parent';parentRole:RelationRole;lineage:'biological'|'adoptive'|'unknown'}|{kind:'guardian'|'stepParent';parentRole:RelationRole}|{kind:'partner'|'formerPartner'|'sibling'};
export type EntryRelationType={genealogy?:GenealogyMeaning;id:string;name?:string;title:string;inverseTitle:string;symmetric:boolean;sourceTemplateIds:string[];targetTemplateIds:string[];disabledTemplateIds?:string[];needsRoleReview?:boolean};
export type EntryRelation={partnershipStatus?:PartnershipStatus;start?:StoryDate;end?:StoryDate;id:string;typeId:string;sourceId:string;targetId:string};
export type FamilyLineage={id:string;name:string;memberIds:string[]};
export type EntryRelations={schemaVersion:1|2|3|4|5|6|7|8|9;lineages?:FamilyLineage[];views?:RelationGraphView[];types:EntryRelationType[];links:EntryRelation[]};
export type RelationRole='source'|'target';
export const emptyEntryRelations:EntryRelations={schemaVersion:2,types:[],links:[]};
export const relationTypeName=(type:EntryRelationType)=>type.name??(type.symmetric?type.title:`${type.title} / ${type.inverseTitle}`);

/** Legacy labels were used inconsistently as roles and descriptions. Keep every
 * endpoint, ID, restriction and label; directed roles require explicit confirmation.
 * Migration is lazy and immutable, so opening a project never rewrites its files. */
export function normalizeEntryRelations(relations:EntryRelations=emptyEntryRelations):EntryRelations{
 if(relations.schemaVersion>=2)return relations;
 const names=new Set<string>();
 return {...relations,schemaVersion:2,types:relations.types.map(type=>{
  const base=Array.from(relationTypeName(type)).slice(0,120).join('');let name=base,index=1;
  while(names.has(name.toLocaleLowerCase())){const suffix=` (${++index})`;name=Array.from(base).slice(0,120-suffix.length).join('')+suffix;}
  names.add(name.toLocaleLowerCase());return {...type,name,...(!type.symmetric?{needsRoleReview:true}:{})};
 })};
}
export function templateAllowsRole(type:EntryRelationType,templateId:string,role:RelationRole){
 const ids=role==='source'?type.sourceTemplateIds:type.targetTemplateIds;
 return !(type.disabledTemplateIds??[]).includes(templateId)&&(!ids.length||ids.includes(templateId));
}
export function availableRoles(type:EntryRelationType,entry:Entry):RelationRole[]{
 return (['source','target'] as RelationRole[]).filter(role=>templateAllowsRole(type,entry.templateId,role));
}
export function entryConnections(input:EntryRelations,entryId:string){
 const relations=normalizeEntryRelations(input);
 return relations.links.filter(link=>link.sourceId===entryId||link.targetId===entryId).flatMap(link=>{
  const type=relations.types.find(type=>type.id===link.typeId);if(!type)return [];
  const role:RelationRole=link.sourceId===entryId?'source':'target';
  return [{link,type,role,entryId:role==='source'?link.targetId:link.sourceId,currentRole:role==='source'?type.title:type.inverseTitle,relatedRole:role==='source'?type.inverseTitle:type.title}];
 });
}
function equivalent(type:EntryRelationType,a:EntryRelation,b:EntryRelation){return a.typeId===b.typeId&&(a.sourceId===b.sourceId&&a.targetId===b.targetId||type.symmetric&&a.sourceId===b.targetId&&a.targetId===b.sourceId);}
export type ConnectionProblem='missing'|'self'|'review'|'incompatible'|'duplicate'|'ancestry'|'dates';
export function connectionProblem(input:EntryRelations,world:Worldbuilding,link:EntryRelation):ConnectionProblem|undefined{
 const relations=normalizeEntryRelations(input),type=relations.types.find(type=>type.id===link.typeId),source=world.entries.find(entry=>entry.id===link.sourceId),target=world.entries.find(entry=>entry.id===link.targetId);
 if(!type||!source||!target)return 'missing';
 if(source.id===target.id)return 'self';
 if(connectionDateProblem(link))return 'dates';
 if(type.needsRoleReview)return 'review';
 if(!templateAllowsRole(type,source.templateId,'source')||!templateAllowsRole(type,target.templateId,'target'))return 'incompatible';
 if(relations.links.some(other=>other.id!==link.id&&equivalent(type,link,other)))return 'duplicate';
 if(hasAncestryCycle({...relations,links:[...relations.links.filter(other=>other.id!==link.id),link]}))return 'ancestry';
}
export function connectionFromEntry(typeId:string,currentId:string,otherId:string,role:RelationRole,id=''):EntryRelation{return {id,typeId,sourceId:role==='source'?currentId:otherId,targetId:role==='source'?otherId:currentId};}
export function saveEntryConnection(input:EntryRelations,world:Worldbuilding,currentId:string,role:RelationRole,typeId:string,otherId:string,id?:string,dates?:Pick<EntryRelation,'start'|'end'|'partnershipStatus'>):EntryRelations{
 const relations=normalizeEntryRelations(input),old=id?relations.links.find(link=>link.id===id):undefined;
 if(id&&(!old||old.sourceId!==currentId&&old.targetId!==currentId))return input;
 const link={...connectionFromEntry(typeId,currentId,otherId,role,id??crypto.randomUUID()),...(old?.partnershipStatus?{partnershipStatus:old.partnershipStatus}:{}),...(dates??(old?{...(old.start?{start:old.start}:{}),...(old.end?{end:old.end}:{}),...(old.partnershipStatus?{partnershipStatus:old.partnershipStatus}:{})}:{}))};
 if(!supportsPartnership(relations.types.find(type=>type.id===typeId))||!link.partnershipStatus)delete link.partnershipStatus;
 if(connectionProblem(relations,world,link))return input;
 // Archived endpoints may be retained during editing, but cannot acquire new links.
 if([link.sourceId,link.targetId].some(entryId=>world.entries.find(entry=>entry.id===entryId)?.archived&&entryId!==old?.sourceId&&entryId!==old?.targetId))return input;
 return {...relations,schemaVersion:link.partnershipStatus?9:(link.start||link.end)&&relations.schemaVersion<5?5:relations.schemaVersion,links:id?relations.links.map(item=>item.id===id?link:item):[...relations.links,link]};
}
export function removeEntryConnection(input:EntryRelations,id:string):EntryRelations{
 const relations=normalizeEntryRelations(input);return {...relations,links:relations.links.filter(link=>link.id!==id)};
}
export function connectionCandidates(input:EntryRelations,world:Worldbuilding,current:Entry,type:EntryRelationType,role:RelationRole,templateId:string,editingId?:string){
 return world.entries.filter(other=>other.templateId===templateId&&other.id!==current.id&&(!other.archived||input.links.some(link=>link.id===editingId&&(link.sourceId===other.id||link.targetId===other.id)))&&!connectionProblem(input,world,connectionFromEntry(type.id,current.id,other.id,role,editingId)));
}
export type ConnectionSelection={typeId:string;role:RelationRole|'';templateId:string;entryId:string};
export function selectConnectionTemplate(selection:ConnectionSelection,templateId:string):ConnectionSelection{return selection.templateId===templateId?selection:{...selection,templateId,entryId:''};}
export function typeUpdateProblem(input:EntryRelations,type:EntryRelationType):'duplicate'|'ancestry'|'partnership'|undefined{
 const links=input.links.filter(link=>link.typeId===type.id);
 if(links.some(link=>link.partnershipStatus)&&!supportsPartnership(type))return 'partnership';
 if(links.some((link,index)=>links.slice(index+1).some(other=>equivalent(type,link,other))))return 'duplicate';
 if(hasAncestryCycle({...input,types:[...input.types.filter(other=>other.id!==type.id),type]}))return 'ancestry';
}
export function updateEntryRelationType(input:EntryRelations,type:EntryRelationType):EntryRelations{
 const relations=normalizeEntryRelations(input);
 type={...type,name:relationTypeName(type)};
 if(typeUpdateProblem(relations,type))return input; // Never silently merge opposite directed links.
 return {...relations,schemaVersion:type.genealogy&&['guardian','stepParent','formerPartner'].includes(type.genealogy.kind)&&relations.schemaVersion<6?6:type.genealogy&&relations.schemaVersion<4?4:relations.schemaVersion,types:relations.types.some(item=>item.id===type.id)?relations.types.map(item=>item.id===type.id?type:item):[...relations.types,type]};
}
export function removeDeletedEntryRelations(input:EntryRelations|undefined,before:Worldbuilding|undefined,after:Worldbuilding|undefined):EntryRelations|undefined{
 if(!input||!before||!after)return input;
 const deleted=new Set(before.entries.filter(entry=>!after.entries.some(other=>other.id===entry.id)).map(entry=>entry.id));
 if(!deleted.size)return input;
 return {...input,...(input.lineages?{lineages:input.lineages.map(lineage=>({...lineage,memberIds:lineage.memberIds.filter(id=>!deleted.has(id))}))}:{}),links:input.links.filter(link=>!deleted.has(link.sourceId)&&!deleted.has(link.targetId))};
}

/** Genealogy is explicit metadata; custom role names never imply ancestry. */
export function parentConnections(input:EntryRelations){
 return input.links.flatMap(link=>{const type=input.types.find(type=>type.id===link.typeId);const meaning=type?.genealogy;
  return meaning?.kind==='parent'&&!type?.needsRoleReview?[{link,type:type!,parentId:meaning.parentRole==='source'?link.sourceId:link.targetId,childId:meaning.parentRole==='source'?link.targetId:link.sourceId,lineage:meaning.lineage}]:[];
 });
}
export function hasAncestryCycle(input:EntryRelations){
 const edges=parentConnections(input),children=new Map<string,Set<string>>(),degree=new Map<string,number>();
 for(const {parentId,childId} of edges){if(!children.has(parentId))children.set(parentId,new Set());if(children.get(parentId)!.has(childId))continue;children.get(parentId)!.add(childId);degree.set(parentId,degree.get(parentId)??0);degree.set(childId,(degree.get(childId)??0)+1);}
 const queue=[...degree.keys()].filter(id=>degree.get(id)===0);let visited=0;
 for(let i=0;i<queue.length;i++){const id=queue[i];visited++;for(const child of children.get(id)??[]){degree.set(child,degree.get(child)!-1);if(degree.get(child)===0)queue.push(child);}}
 return visited!==degree.size;
}

export function connectionDateProblem(link:Pick<EntryRelation,'start'|'end'>):string|undefined {
 try {for(const date of [link.start,link.end])if(date){const parsed=parseStoryDate(formatStoryDate(date));if(!parsed||JSON.stringify(parsed)!==JSON.stringify({year:date.year,...(date.month!==undefined?{month:date.month}:{}),...(date.day!==undefined?{day:date.day}:{})}))return 'This date is not valid.';}
 if(link.start&&link.end)validatePeriod(link.start,link.end);
 }catch(error){return error instanceof Error?error.message:String(error);}
}
export function connectionDateLabel(link:Pick<EntryRelation,'start'|'end'>){return link.start||link.end?[link.start?`${t('Start')}: ${formatStoryDate(link.start)}`:t('Start date unknown'),link.end?`${t('End')}: ${formatStoryDate(link.end)}`:t('End date not specified')].join(' · '):'';}

export function isFormerPartner(type:EntryRelationType,link:EntryRelation,at?:StoryDate){if(at)return relationshipStatus(link,at)==='ended'&&(type.genealogy?.kind==='partner'||type.genealogy?.kind==='formerPartner');return type.genealogy?.kind==='formerPartner'||type.genealogy?.kind==='partner'&&!!link.end;}
