export const projectDownloadPending='Project files are still downloading. Try opening again when iCloud finishes.';
export async function openWhenAvailable<T>({check,open,onProgress,now=Date.now,delay=ms=>new Promise(resolve=>setTimeout(resolve,ms)),timeoutMs=120000,pollMs=1000}:{check:()=>Promise<'ready'|'downloading'>;open:()=>Promise<T>;onProgress?:(phase:'opening'|'downloading')=>void;now?:()=>number;delay?:(ms:number)=>Promise<unknown>;timeoutMs?:number;pollMs?:number}):Promise<T>{
 const deadline=now()+timeoutMs;
 for(;;){
  const status=await check();
  if(status==='ready'){
   onProgress?.('opening');
   try{return await open();}catch(error){if(String(error)!==projectDownloadPending)throw error;}
  }
  onProgress?.('downloading');
  const remaining=deadline-now();
  if(remaining<=0)throw new Error('The project could not finish downloading from iCloud. Check your connection and try again.');
  await delay(Math.min(pollMs,remaining));
 }
}
