import {createGenealogyRouter} from './genealogyRouting';
import type {GenealogyRoute} from './genealogyRouting';
import type {GraphPoint} from './relationGraph';
import type {genealogyFamilies} from './genealogyFamilies';
export type GenealogyRouteRequest={id:string;source:string;target:string;label:string;kind:'partner'|'sibling'|'care';icon?:boolean};
type Family=ReturnType<typeof genealogyFamilies>[number];
export function buildGenealogyScene(positions:Record<string,GraphPoint>,requests:GenealogyRouteRequest[],families:Family[],familyLabel:(meanings:string[])=>string){
 const router=createGenealogyRouter(positions),routes=new Map<string,GenealogyRoute>(),unrouted=new Set<string>();
 // Couple labels reserve their own clear space before secondary connectors.
 for(const request of [...requests].sort((a,b)=>(a.kind==='partner'?0:1)-(b.kind==='partner'?0:1)||a.id.localeCompare(b.id))){const route=router.betweenNodes(request.source,request.target,request.label,request.kind,request.icon);routes.set(request.id,route);if(route.blocked)unrouted.add(request.id);}
 const branches=families.map(family=>{
  const mark=router.checkpoint();
  const ids=[...family.parentIds,...family.children.map(child=>child.id)],xs=ids.map(id=>positions[id].x),top=Math.max(...family.parentIds.map(id=>positions[id].y+32)),bottom=Math.min(...family.children.map(child=>positions[child.id].y-32));
  const rail=router.rail(Math.min(...xs),Math.max(...xs),family.railY,top+18,bottom-18,family.key),parents=new Map<string,GenealogyRoute>(),children=new Map<string,GenealogyRoute>(),connections=new Map<string,string>();
  if(rail){for(const id of family.parentIds)parents.set(id,router.toPoint(id,{x:positions[id].x,y:rail.y},'bottom',family.key));for(const child of family.children){const meanings=[...new Set(child.edges.map(edge=>edge.lineage))];children.set(child.id,router.toPoint(child.id,{x:positions[child.id].x,y:rail.y},'top',family.key,true,familyLabel(meanings)));}}
  const shared=!!rail&&[...parents.values(),...children.values()].every(route=>!route.blocked);
  if(!shared)router.rollback(mark);
  for(const child of family.children)for(const edge of child.edges){if(shared){const p=positions[edge.parentId],c=positions[child.id];connections.set(edge.link.id,parents.get(edge.parentId)!.path+` M ${p.x} ${rail!.y} H ${c.x}`+children.get(child.id)!.path.replace(/^M/,' M'));}
   else {const route=router.betweenNodes(edge.parentId,child.id,'','care');routes.set(edge.link.id,route);connections.set(edge.link.id,route.path);if(route.blocked)unrouted.add(edge.link.id);}}
  // Junctions only at actual branches of this recorded parent set.
  const junctions=shared?[...new Set(ids.map(id=>positions[id].x))].filter(x=>{
   const directions=new Set<string>();if(x>Math.min(...xs))directions.add('left');if(x<Math.max(...xs))directions.add('right');
   const add=(from:GraphPoint|undefined)=>{if(!from)return;if(from.x<x)directions.add('left');if(from.x>x)directions.add('right');if(from.y<rail!.y)directions.add('up');if(from.y>rail!.y)directions.add('down');};
   for(const id of family.parentIds)if(positions[id].x===x){const path=parents.get(id)!.points;add(path[path.length-2]);}
   for(const child of family.children)if(positions[child.id].x===x)add(children.get(child.id)!.points[1]);
   return directions.size>=3;
  }).map(x=>({x,y:rail!.y})):[];
  return {...family,shared,trunk:shared?rail!.path+' '+[...parents.values()].map(p=>p.path).join(' '):'',childrenRoutes:children,parentRoutes:parents,connections,junctions};
 });
 const extents:GraphPoint[]=[];for(const p of Object.values(positions))extents.push({x:p.x-100,y:p.y-32},{x:p.x+100,y:p.y+32});
 const drawn=[...routes.values(),...branches.filter(branch=>branch.shared).flatMap(branch=>[...branch.parentRoutes.values(),...branch.childrenRoutes.values()])];
 for(const route of drawn){extents.push(...route.points);if(route.label){const width=route.labelWidth??52;extents.push({x:route.label.x-width/2,y:route.label.y-15},{x:route.label.x+width/2,y:route.label.y+15});}}
 const framePoints={...positions};if(extents.length){framePoints['__route-min']={x:Math.min(...extents.map(p=>p.x))+100,y:Math.min(...extents.map(p=>p.y))+32};framePoints['__route-max']={x:Math.max(...extents.map(p=>p.x))-100,y:Math.max(...extents.map(p=>p.y))-32};}
 return {routes,branches,framePoints,unrouted:[...unrouted]};
}
