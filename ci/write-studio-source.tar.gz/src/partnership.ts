import type {EntryRelation,EntryRelationType} from './entryRelations';
export type PartnershipStatus='dating'|'married'|'separated'|'divorced';
export const partnershipLabels:Record<PartnershipStatus,string>={dating:'Dating',married:'Married',separated:'Separated',divorced:'Divorced'};
export function supportsPartnership(type:EntryRelationType|undefined){return !!type&&!type.needsRoleReview&&['partner','formerPartner'].includes(type.genealogy?.kind??'');}
export function partnershipLabel(link:EntryRelation){return link.partnershipStatus?partnershipLabels[link.partnershipStatus]:undefined;}
