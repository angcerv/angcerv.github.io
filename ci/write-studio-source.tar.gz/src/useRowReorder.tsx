import {useEffect,useRef,useState} from 'react';
import type {PointerEvent} from 'react';
import {GripVertical} from 'lucide-react';
import {createDragPreview} from './dragPreview';
import {isGraphDrag} from './graphGesture';
import {t} from './i18n';

/** Reorder only the named slots, retaining filtered and unrelated items in place. */
export function orderedSlots<T extends {id:string}>(items:T[],ids:readonly string[]):T[]{
 const unique=new Set(ids);if(unique.size!==ids.length||ids.some(id=>!items.some(item=>item.id===id)))return items;
 const chosen=new Map(items.map(item=>[item.id,item]));let index=0;
 const next=items.map(item=>unique.has(item.id)?chosen.get(ids[index++])!:item);
 return next.every((item,i)=>item===items[i])?items:next;
}
export default function useRowReorder(onChange:(group:string,ids:string[])=>void){
 const [preview,setPreview]=useState<{group:string;ids:string[];id:string}|undefined>(undefined);
 const gesture=useRef<{group:string;id:string;ids:string[];original:string[];pointerId:number;x:number;y:number;active:boolean;scope:HTMLElement;handle:HTMLButtonElement;preview?:ReturnType<typeof createDragPreview>}|null>(null);
 const [announcement,setAnnouncement]=useState('');
 function clear(){const active=gesture.current;gesture.current=null;active?.preview?.remove();setPreview(undefined);if(active?.handle.hasPointerCapture(active.pointerId))active.handle.releasePointerCapture(active.pointerId);}
 useEffect(()=>{const cancel=()=>clear();window.addEventListener('blur',cancel);return()=>{window.removeEventListener('blur',cancel);gesture.current?.preview?.remove();};},[]);
 function move(event:PointerEvent<HTMLButtonElement>){
  const active=gesture.current;if(!active||active.pointerId!==event.pointerId)return;
  if(!active.active&&!isGraphDrag(active,{x:event.clientX,y:event.clientY}))return;
  event.preventDefault();active.active=true;active.preview?.move(event.clientX,event.clientY);
  const rows=[...active.scope.querySelectorAll<HTMLElement>('[data-sort-row]')].filter(row=>!row.closest('.ui-drag-preview')&&row.dataset.sortGroup===active.group&&row.dataset.sortRow!==active.id);
  const position=rows.filter(row=>{const rect=row.getBoundingClientRect();return event.clientY>rect.top+rect.height/2;}).length;
  const ids=active.ids.filter(id=>id!==active.id);ids.splice(position,0,active.id);active.ids=ids;setPreview({group:active.group,ids,id:active.id});
  for(let node:HTMLElement|null=active.scope;node;node=node.parentElement){if(node.scrollHeight<=node.clientHeight||!/(auto|scroll)/.test(getComputedStyle(node).overflowY))continue;const rect=node.getBoundingClientRect();if(event.clientY<rect.top+32)node.scrollTop-=14;else if(event.clientY>rect.bottom-32)node.scrollTop+=14;break;}
 }
 function finish(event:PointerEvent<HTMLButtonElement>){const active=gesture.current;if(!active||active.pointerId!==event.pointerId)return;if(active.active){move(event);if(active.ids.some((id,i)=>id!==active.original[i])){onChange(active.group,active.ids);setAnnouncement(t('Order updated.'));}}clear();}
 return {
  status:<span className="visually-hidden" role="status">{announcement}</span>,
  order<T extends {id:string}>(group:string,items:T[]){return preview?.group===group?orderedSlots(items,preview.ids):items;},
  row(group:string,id:string){return {'data-sort-row':id,'data-sort-group':group,'data-sort-moving':preview?.group===group&&preview.id===id||undefined};},
  handle(group:string,id:string,label:string,ids:string[],disabled=false){return <button type="button" className="quick-action ui-row-drag-handle" disabled={disabled||ids.length<2} aria-label={t('Reorder {0}',label)} title={t('Drag to reorder, or use arrow keys')} onClick={event=>{event.preventDefault();event.stopPropagation();}} onPointerDown={event=>{if(disabled||event.button!==0||!event.isPrimary||gesture.current)return;const row=event.currentTarget.closest<HTMLElement>('[data-sort-row]'),scope=row?.closest<HTMLElement>('[data-sort-scope]');if(!row||!scope)return;event.preventDefault();event.stopPropagation();event.currentTarget.focus();event.currentTarget.setPointerCapture(event.pointerId);gesture.current={group,id,ids:[...ids],original:[...ids],pointerId:event.pointerId,x:event.clientX,y:event.clientY,active:false,scope,handle:event.currentTarget,preview:createDragPreview(row,event.clientX,event.clientY)};}} onPointerMove={move} onPointerUp={finish} onPointerCancel={clear} onLostPointerCapture={clear} onKeyDown={event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();clear();return;}if(!['ArrowUp','ArrowDown'].includes(event.key)||gesture.current)return;event.preventDefault();event.stopPropagation();const from=ids.indexOf(id),to=from+(event.key==='ArrowUp'?-1:1);if(to<0||to>=ids.length)return;const next=[...ids];[next[from],next[to]]=[next[to],next[from]];onChange(group,next);setAnnouncement(t('Order updated.'));}}><GripVertical size={14} aria-hidden="true"/></button>;}
 };
}
