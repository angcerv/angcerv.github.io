import {useEffect,useRef,useState} from 'react';
import type {PointerEvent} from 'react';
import {GripVertical} from 'lucide-react';
import {createDragPreview} from './dragPreview';
import {isGraphDrag} from './graphGesture';
import {t} from './i18n';

/** Reorder only the named slots, retaining filtered and unrelated items in place. */
export function orderedSlots<T extends {id:string}>(items:T[],ids:readonly string[]):T[]{
 const unique=new Set(ids);if(unique.size!==ids.length||ids.some(id=>!items.some(item=>item.id===id)))return items;
 const chosen=new Map(items.map(item=>[item.id,item]));let index=0;
 const next=items.map(item=>unique.has(item.id)?chosen.get(ids[index++])!:item);
 return next.every((item,i)=>item===items[i])?items:next;
}
type Transfer={prefix:string;onMove:(id:string,group:string,beforeId?:string)=>string|void};
type Target={group:string;beforeId?:string};
type Preview={group:string;ids:string[];id:string;target?:Target;invalid?:boolean};
export default function useRowReorder(onChange:(group:string,ids:string[])=>void,transfer?:Transfer){
 const [preview,setPreview]=useState<Preview|undefined>(undefined);
 const gesture=useRef<{group:string;id:string;ids:string[];original:string[];pointerId:number;x:number;y:number;active:boolean;scope:HTMLElement;handle:HTMLButtonElement;target?:Target;invalid?:boolean;preview?:ReturnType<typeof createDragPreview>}|null>(null);
 const [announcement,setAnnouncement]=useState('');
 function clear(){const active=gesture.current;gesture.current=null;active?.preview?.remove();setPreview(undefined);if(active?.handle.hasPointerCapture(active.pointerId))active.handle.releasePointerCapture(active.pointerId);}
 useEffect(()=>{const cancel=()=>clear();window.addEventListener('blur',cancel);return()=>{window.removeEventListener('blur',cancel);gesture.current?.preview?.remove();};},[]);
 function move(event:PointerEvent<HTMLButtonElement>){
  const active=gesture.current;if(!active||active.pointerId!==event.pointerId)return;
  if(!active.active&&!isGraphDrag(active,{x:event.clientX,y:event.clientY}))return;
  event.preventDefault();active.active=true;active.preview?.move(event.clientX,event.clientY);
  const transferable=!!transfer&&active.group.startsWith(transfer.prefix);
  let group=active.group;active.invalid=false;active.target=undefined;
  if(transferable){
   const hit=active.scope.ownerDocument.elementFromPoint(event.clientX,event.clientY),zone=hit?.closest<HTMLElement>('[data-sort-zone]');
   if(!zone||!active.scope.contains(zone)||zone.dataset.sortDisabled==='true'||!zone.dataset.sortZone?.startsWith(transfer.prefix))active.invalid=true;
   else {group=zone.dataset.sortZone;if(group!==active.group&&zone.tagName==='DETAILS')(zone as HTMLDetailsElement).open=true;}
  }
  const rows=[...active.scope.querySelectorAll<HTMLElement>('[data-sort-row]')].filter(row=>!row.closest('.ui-drag-preview')&&row.dataset.sortGroup===group&&row.dataset.sortRow!==active.id&&row.dataset.sortTransferOnly!=='true'&&row.getBoundingClientRect().height>0);
  const position=rows.filter(row=>{const rect=row.getBoundingClientRect();return event.clientY>rect.top+rect.height/2;}).length;
  if(active.invalid)active.ids=[...active.original];
  else if(group!==active.group){active.ids=[...active.original];active.target={group,beforeId:rows[position]?.dataset.sortRow};}
  else {const ids=active.ids.filter(id=>id!==active.id);ids.splice(position,0,active.id);active.ids=ids;}
  setPreview({group:active.group,ids:active.ids,id:active.id,target:active.target,invalid:active.invalid});
  for(let node:HTMLElement|null=active.scope;node;node=node.parentElement){if(node.scrollHeight<=node.clientHeight||!/(auto|scroll)/.test(getComputedStyle(node).overflowY))continue;const rect=node.getBoundingClientRect();if(event.clientY<rect.top+32)node.scrollTop-=14;else if(event.clientY>rect.bottom-32)node.scrollTop+=14;break;}
 }
 function finish(event:PointerEvent<HTMLButtonElement>){
  const active=gesture.current;if(!active||active.pointerId!==event.pointerId)return;
  let focusId:string|undefined;
  if(active.active){move(event);if(!active.invalid){if(active.target){focusId=transfer?.onMove(active.id,active.target.group,active.target.beforeId)??active.id;setAnnouncement(t('Element moved to layer.'));}else if(active.ids.some((id,i)=>id!==active.original[i])){onChange(active.group,active.ids);setAnnouncement(t('Order updated.'));}}}
  clear();
  if(focusId&&typeof requestAnimationFrame==='function')requestAnimationFrame(()=>{const row=[...active.scope.querySelectorAll<HTMLElement>('[data-sort-row]')].find(row=>!row.closest('.ui-drag-preview')&&row.dataset.sortRow===focusId);row?.querySelector<HTMLButtonElement>('.ui-row-drag-handle')?.focus({preventScroll:true});});
 }
 return {
  status:<span className="visually-hidden" role="status">{announcement}</span>,
  transferring:!!preview&&!!transfer&&preview.group.startsWith(transfer.prefix),
  order<T extends {id:string}>(group:string,items:T[]){return preview?.group===group?orderedSlots(items,preview.ids):items;},
  zone(group:string,disabled=false){return {'data-sort-zone':group,'data-sort-disabled':disabled||undefined,'data-sort-target':preview?.target?.group===group||undefined,'data-sort-append':preview?.target?.group===group&&!preview.target.beforeId||undefined};},
  row(group:string,id:string){return {'data-sort-row':id,'data-sort-group':group,'data-sort-moving':preview?.group===group&&preview.id===id||undefined,'data-sort-insert':preview?.target?.group===group&&preview.target.beforeId===id||undefined};},
  handle(group:string,id:string,label:string,ids:string[],disabled=false){return <button type="button" className="quick-action ui-row-drag-handle" style={{cursor:preview?.invalid&&preview.id===id?'not-allowed':undefined}} disabled={disabled||ids.length<2&&!(transfer&&group.startsWith(transfer.prefix))} aria-label={t('Reorder {0}',label)} title={t(transfer&&group.startsWith(transfer.prefix)?'Drag to reorder or move between layers. Arrow keys reorder.':'Drag to reorder, or use arrow keys')} onClick={event=>{event.preventDefault();event.stopPropagation();}} onPointerDown={event=>{if(disabled||event.button!==0||!event.isPrimary||gesture.current)return;const row=event.currentTarget.closest<HTMLElement>('[data-sort-row]'),scope=row?.closest<HTMLElement>('[data-sort-scope]');if(!row||!scope)return;event.preventDefault();event.stopPropagation();event.currentTarget.focus();event.currentTarget.setPointerCapture(event.pointerId);gesture.current={group,id,ids:[...ids],original:[...ids],pointerId:event.pointerId,x:event.clientX,y:event.clientY,active:false,scope,handle:event.currentTarget,preview:createDragPreview(row,event.clientX,event.clientY)};}} onPointerMove={move} onPointerUp={finish} onPointerCancel={clear} onLostPointerCapture={clear} onKeyDown={event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();clear();return;}if(!['ArrowUp','ArrowDown'].includes(event.key)||gesture.current)return;event.preventDefault();event.stopPropagation();const from=ids.indexOf(id),to=from+(event.key==='ArrowUp'?-1:1);if(to<0||to>=ids.length)return;const next=[...ids];[next[from],next[to]]=[next[to],next[from]];onChange(group,next);setAnnouncement(t('Order updated.'));}}><GripVertical size={14} aria-hidden="true"/></button>;}
 };
}
