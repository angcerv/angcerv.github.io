import { locale, t } from './i18n';
import { fromMarkdown } from './model';
import type { Chapter } from './model';
export const MAX_WORD_GOAL=10_000_000;
export type WritingSession={id:string;startedAt:number;startWords:number;targetWords:number};
export type CompletedSession=WritingSession & {endedAt:number;endWords:number};
export type WritingGoals={schemaVersion:1;projectTarget?:number;sessionTarget?:number;activeSession?:WritingSession;sessions:CompletedSession[]};
export const emptyWritingGoals:WritingGoals={schemaVersion:1,sessions:[]};
export const countPlainWords=(text:string)=>text.trim().split(/\s+/u).filter(Boolean).length;
export function countSceneWords(markdown:string):number {
 const document=fromMarkdown(markdown);
 return countPlainWords((document.content ?? []).map(paragraph=>(paragraph.content ?? []).map(node=>node.type==='hardBreak' ? '\n' : node.text ?? '').join('')).join('\n'));
}
/** Recount only changed scenes, and release entries for deleted scenes/projects. */
export function createManuscriptCounter(){
 const cache=new Map<string,{content:string;words:number}>();
 return (chapters:Chapter[])=>{const present=new Set<string>();let total=0;for(const chapter of chapters)for(const scene of chapter.scenes){present.add(scene.id);let value=cache.get(scene.id);if(!value || value.content!==scene.content){value={content:scene.content,words:countSceneWords(scene.content)};cache.set(scene.id,value);}total+=value.words;}for(const id of cache.keys())if(!present.has(id))cache.delete(id);return total;};
}
export function parseWordGoal(value:string):number|undefined {
 if(!value.trim())return undefined;
 if(!/^\d+$/.test(value.trim()))throw new Error(t("Enter a positive whole number of words."));
 const number=Number(value);if(!Number.isSafeInteger(number) || number<1 || number>MAX_WORD_GOAL)throw new Error(t("Choose a goal between 1 and 10,000,000 words."));return number;
}
export function configureGoals(goals:WritingGoals,projectTarget?:number,sessionTarget?:number):WritingGoals {
 for(const value of [projectTarget,sessionTarget])if(value!==undefined)parseWordGoal(String(value));
 if(goals.activeSession && !sessionTarget)throw new Error(t("End the current session before clearing its goal."));
 return {...goals,projectTarget,sessionTarget,...(goals.activeSession ? {activeSession:{...goals.activeSession,targetWords:sessionTarget!}} : {})};
}
export function startWritingSession(goals:WritingGoals,words:number,id=crypto.randomUUID(),now=Date.now()):WritingGoals {
 if(goals.activeSession)throw new Error(t('A writing session is already active.'));
 if(!goals.sessionTarget)throw new Error(t('Set a session word goal first.'));
 if(goals.sessions.length>=100_000)throw new Error(t("This project has reached its session history limit."));
 return {...goals,activeSession:{id,startedAt:now,startWords:words,targetWords:goals.sessionTarget}};
}
export function endWritingSession(goals:WritingGoals,words:number,now=Date.now()):WritingGoals {
 if(!goals.activeSession)return goals;
 const {activeSession,...rest}=goals;
 return {...rest,sessions:[...goals.sessions,{...activeSession,endedAt:Math.max(now,activeSession.startedAt),endWords:words}]};
}
export function goalProgress(words:number,target:number){return {percent:Math.max(0,Math.min(100,words/target*100)),remaining:Math.max(0,target-words),reached:words>=target};}
export const sessionWords=(goals:WritingGoals,words:number)=>goals.activeSession ? words-goals.activeSession.startWords : 0;
export const formatNetWords=(words:number)=>`${words>=0 ? '+' : '−'}${Math.abs(words).toLocaleString(locale())}`;
export function writingGoalSummary(goals:WritingGoals|undefined,words:number):string {
 if(goals?.activeSession)return t("Session {0} / {1} words", formatNetWords(sessionWords(goals,words)), goals.activeSession.targetWords.toLocaleString(locale()));
 if(goals?.projectTarget)return t("Project {0} / {1} words", words.toLocaleString(locale()), goals.projectTarget.toLocaleString(locale()));
 return t("Writing goals");
}
