import type {GraphPoint} from './relationGraph';
export const graphDragThreshold=4;
export function isGraphDrag(start:GraphPoint,current:GraphPoint,screenScale=1){return Math.hypot(current.x-start.x,current.y-start.y)*screenScale>=graphDragThreshold;}
export function draggedGraphPoint(origin:GraphPoint,start:GraphPoint,current:GraphPoint,zoom:number,lockY=false):GraphPoint{
 const bound=(n:number)=>Math.max(-100000,Math.min(100000,n));
 return {x:bound(origin.x+(current.x-start.x)/zoom),y:lockY?origin.y:bound(origin.y+(current.y-start.y)/zoom)};
}
