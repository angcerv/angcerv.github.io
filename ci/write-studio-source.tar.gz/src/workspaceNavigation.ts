import type {Project} from './model';
export type WorkspaceView='home'|'manuscript'|'worldbuilding'|'timeline'|'maps'|'pending'|'plots'|'arcs'|'canvas';
export type WorldWorkspacePane='entries'|'reading'|'templates'|'network'|'genealogy'|'relationshipTypes'|'resources';
export function worldWorkspacePane(values:Record<string,unknown>,section:'entries'|'templates'):WorldWorkspacePane{
 if(values['world.relationsOpen'])return values['world.relationSection']==='genealogy'?'genealogy':values['world.relationSection']==='types'?'relationshipTypes':'network';
 if(values['world.resourcesOpen'])return 'resources';
 return section==='templates'?'templates':values['world.reading']?'reading':'entries';
}
export type WorkspaceRoute={bookId?:string;worldPane?:WorldWorkspacePane;worldFocusId?:string;view:WorkspaceView;selectedId:string;chapterId:string;manuscriptMode:'scene'|'chapter'|'board'|'planning';worldSection:'entries'|'templates';worldEntryId:string;plotId:string;arcId:string;timelineEventId:string;mapId:string;mapMarkerId:string;routeRequest?:{mapId:string;routeId:string};pendingIdeaId:string;toolsOpen:boolean;toolsTab:'scene'|'chapter'|'context';worldOpen:boolean;sidebar:boolean;worldTemplateRequest?:{id:string;token:number}};
export type ElementLocation={path:number[];id?:string;tag:string};
export type WorkspacePosition={scroll:{element:ElementLocation;top:number;left:number}[];details:{element:ElementLocation;open:boolean}[];focus?:ElementLocation;focusFallback?:ElementLocation;selection?:{start:number|null;end:number|null};editor?:{sceneId:string;from:number;to:number}};
export type WorkspaceVisit={route:WorkspaceRoute;memory:Record<string,unknown>;position:WorkspacePosition};
export type WorkspaceHistory={past:WorkspaceVisit[];future:WorkspaceVisit[]};
export const emptyWorkspaceHistory=():WorkspaceHistory=>({past:[],future:[]});
export function workspaceRouteKey(route:WorkspaceRoute){
 switch(route.view){
  case 'home':return 'home';
  case 'canvas':return 'canvas';
  case 'manuscript':return `manuscript:${route.bookId??''}:${route.manuscriptMode}:${route.manuscriptMode==='board'?'':['chapter','planning'].includes(route.manuscriptMode)?route.chapterId:route.selectedId}:${route.worldOpen?`entry:${route.worldEntryId}`:''}`;
  case 'worldbuilding':{
   const pane=route.worldPane??route.worldSection;
   if(pane==='network'||pane==='genealogy')return `world:${pane}:${route.worldFocusId??''}`;
   if(pane==='resources'||pane==='relationshipTypes')return `world:${pane}`;
   return `world:${pane}:${pane==='templates'?route.worldTemplateRequest?.id??'':route.worldEntryId}`;
  }
  case 'timeline':return `timeline:${route.timelineEventId}`;
  case 'maps':return `maps:${route.mapId}:${route.mapMarkerId}:${route.routeRequest?.routeId??''}`;
  case 'plots':return `plots:${route.plotId}`;
  case 'arcs':return `arcs:${route.arcId}`;
  case 'pending':return `pending:${route.pendingIdeaId}`;
 }
}
export function workspaceRouteExists(project:Project,route:WorkspaceRoute){
 if(route.view==='manuscript'&&route.bookId&&!project.books?.some(book=>book.id===route.bookId))return false;
 switch(route.view){
  case 'home':return true;
  case 'canvas':return true;
  case 'manuscript':return !route.selectedId||route.manuscriptMode==='board'||project.chapters.some(chapter=>chapter.id===route.selectedId||(['chapter','planning'].includes(route.manuscriptMode)&&chapter.id===route.chapterId)||chapter.scenes.some(scene=>scene.id===route.selectedId));
  case 'worldbuilding':if(route.worldPane&&['network','genealogy','relationshipTypes','resources'].includes(route.worldPane))return true;return route.worldSection==='entries'?(!route.worldEntryId||!!project.worldbuilding?.entries.some(entry=>entry.id===route.worldEntryId)):(!route.worldTemplateRequest?.id||!!project.worldbuilding?.templates.some(template=>template.id===route.worldTemplateRequest?.id));
  case 'plots':return !route.plotId||!!project.plots?.threads.some(plot=>plot.id===route.plotId);
  case 'arcs':return !route.arcId||!!project.plots?.arcs?.some(arc=>arc.id===route.arcId);
  case 'timeline':return !route.timelineEventId||!!project.timeline?.events.some(event=>event.id===route.timelineEventId);
  case 'maps':{const map=project.maps?.maps.find(map=>map.id===route.mapId);return !route.mapId||!!map&&(!route.mapMarkerId||map.markers.some(marker=>marker.id===route.mapMarkerId))&&(!route.routeRequest?.routeId||!!map.routes?.some(item=>item.id===route.routeRequest?.routeId));}
  case 'pending':return !route.pendingIdeaId||!!project.worldIdeas?.some(idea=>idea.id===route.pendingIdeaId);
 }
}
export function recordWorkspaceVisit(history:WorkspaceHistory,source:WorkspaceVisit):WorkspaceHistory{return {past:[...history.past,source].slice(-80),future:[]};}
export function stepWorkspaceHistory(history:WorkspaceHistory,current:WorkspaceVisit,direction:'back'|'forward',project:Project):{history:WorkspaceHistory;visit?:WorkspaceVisit}{
 const from=direction==='back'?history.past:history.future,remaining=[...from];let visit:WorkspaceVisit|undefined;
 while(remaining.length){const candidate=remaining.pop()!;if(workspaceRouteExists(project,candidate.route)){visit=candidate;break;}}
 if(!visit)return {history:direction==='back'?{...history,past:[] }:{...history,future:[]}};
 return {visit,history:direction==='back'?{past:remaining,future:[...history.future,current].slice(-80)}:{past:[...history.past,current].slice(-80),future:remaining}};
}
export type WorkspaceViewMemory={values:Record<string,unknown>;restoring?:boolean};
// One active workspace runtime. Values contain transient view preferences only;
// project data, editors and modal drafts are never stored in this memory.
let activeMemory:WorkspaceViewMemory|undefined;
export function activateWorkspaceMemory(memory:WorkspaceViewMemory|undefined){activeMemory=memory;}
export const isWorkspaceRestoring=()=>!!activeMemory?.restoring;
export function workspaceViewMemory(){return activeMemory;}
export function cloneWorkspaceMemory(memory:WorkspaceViewMemory){return structuredClone(memory.values);}
export function restoreWorkspaceMemory(memory:WorkspaceViewMemory,values:Record<string,unknown>){memory.values=structuredClone(values);}
export function elementLocation(root:HTMLElement,element:Element):ElementLocation|undefined{
 if(!root.contains(element))return;
 const path:number[]=[];let node=element;while(node!==root){const parent=node.parentElement;if(!parent)return;path.unshift(Array.prototype.indexOf.call(parent.children,node));node=parent;}
 return {path,id:element.id||undefined,tag:element.tagName};
}
export function locateElement(root:HTMLElement,location:ElementLocation,strictId=true):HTMLElement|undefined{
 if(location.id===root.id&&root.tagName===location.tag)return root;
 if(location.id){const target=root.ownerDocument.getElementById(location.id);if(target&&root.contains(target)&&target.tagName===location.tag)return target;if(strictId)return;}
 let node:Element=root;for(const index of location.path){const next=node.children[index];if(!next)return;node=next;}
 return node instanceof HTMLElement&&node.tagName===location.tag?node:undefined;
}
export function captureWorkspacePosition(root:HTMLElement|null):WorkspacePosition{
 const position:WorkspacePosition={scroll:[],details:[]};if(!root)return position;
 // Editor descendants and SVG geometry cannot own workspace scrolling. Prune
 // those branches instead of measuring every paragraph, map path and graph edge.
 const pending:Element[]=[root];
 while(pending.length){
  const element=pending.pop()!;
  if(!(element instanceof HTMLElement)||element.matches?.('[hidden],[inert]'))continue;
  if(!element.matches?.('[contenteditable=true]')){
   const children=element.children;
   for(let index=children.length-1;index>=0;index--){
    pending.push(children[index]);
   }
  }
  if(element.scrollTop||element.scrollLeft||element.scrollHeight>element.clientHeight+1||element.scrollWidth>element.clientWidth+1){const location=elementLocation(root,element);if(location)position.scroll.push({element:location,top:element.scrollTop,left:element.scrollLeft});}
  if(element instanceof HTMLDetailsElement){const location=elementLocation(root,element);if(location)position.details.push({element:location,open:element.open});}
 }
 const focus=root.ownerDocument.activeElement;
 if(focus){position.focus=elementLocation(root,focus);if(focus instanceof HTMLInputElement||focus instanceof HTMLTextAreaElement)position.selection={start:focus.selectionStart,end:focus.selectionEnd};}
 return position;
}
export function restoreWorkspacePosition(root:HTMLElement,position:WorkspacePosition,focus=false){
 for(const item of position.details){const element=locateElement(root,item.element);if(element instanceof HTMLDetailsElement)element.open=item.open;}
 for(const item of position.scroll){const element=locateElement(root,item.element);if(element){element.scrollTop=item.top;element.scrollLeft=item.left;}}
 if(focus&&(position.focus||position.focusFallback)){const element=(position.focus?locateElement(root,position.focus):undefined)??(position.focusFallback?locateElement(root,position.focusFallback):undefined);element?.focus({preventScroll:true});if(position.selection&&(element instanceof HTMLInputElement||element instanceof HTMLTextAreaElement)&&position.selection.start!==null&&position.selection.end!==null)try{element.setSelectionRange(position.selection.start,position.selection.end);}catch{/* Numeric controls do not expose text ranges. */}}
}
