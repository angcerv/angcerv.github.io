import type {MapDrawing} from './mapDrawing';
/** Latest-only frame publication: pointer events never build a render backlog. */
export function createDrawingPreview(publish:(drawing:MapDrawing)=>void,requestFrame:((callback:()=>void)=>number)|undefined=typeof requestAnimationFrame==='function'?callback=>globalThis.requestAnimationFrame(callback):undefined,cancelFrame:((id:number)=>void)|undefined=typeof cancelAnimationFrame==='function'?id=>globalThis.cancelAnimationFrame(id):undefined){
 let pending:MapDrawing|undefined,frame:number|undefined,epoch=0;
 return {
  schedule(drawing:MapDrawing){
   if(!requestFrame){publish(drawing);return;}
   pending=drawing;if(frame!==undefined)return;
   const scheduledEpoch=epoch;
   frame=requestFrame(()=>{if(scheduledEpoch!==epoch)return;frame=undefined;const latest=pending;pending=undefined;if(latest)publish(latest);});
  },
  cancel(){epoch++;if(frame!==undefined)cancelFrame?.(frame);frame=undefined;pending=undefined;},
 };
}
