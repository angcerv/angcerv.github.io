import {focusDialog} from './dialogFocus';
import {message,t,useLanguage,buttonLabel} from './i18n';
import {useDeferredValue,useEffect,useMemo,useRef,useState,useSyncExternalStore} from 'react';
import {Search,X} from 'lucide-react';
import type {Project} from './model';
import {buildProjectSearchIndex,matchRange,searchKindLabels,searchProjectIndex,searchScopes} from './globalSearch';
import type {SearchResult,SearchScope} from './globalSearch';
import Dropdown from './Dropdown';
import FieldHelp from './FieldHelp';
import {useWorkspaceState} from './useWorkspaceState';
import {continuityReviewRevision,subscribeContinuityReview} from './narrativeContinuity';
function Highlight({text,query}:{text:string;query:string}){
 const range=matchRange(text,query);return range?<>{text.slice(0,range[0])}<mark>{text.slice(range[0],range[1])}</mark>{text.slice(range[1])}</>:<>{text}</>;
}
export default function ProjectSearch({project,onClose,onOpen}:{project:Project;onClose:()=>void;onOpen:(result:SearchResult)=>void}){
 const dialog=useRef<HTMLDialogElement>(null),input=useRef<HTMLInputElement>(null),language=useLanguage(),revision=useSyncExternalStore(subscribeContinuityReview,continuityReviewRevision,continuityReviewRevision);
 const [query,setQuery]=useWorkspaceState('search.query',''),[scope,setScope]=useWorkspaceState<SearchScope>('search.scope','all'),[archived,setArchived]=useWorkspaceState('search.archived',true),[limit,setLimit]=useState(60),[retry,setRetry]=useState(0);
 const deferred=useDeferredValue(query),stale=deferred!==query;
 const prepared=useMemo(()=>{try{return {index:buildProjectSearchIndex(project),error:''};}catch(error){return {index:[],error:message(String(error))};}},[project,language,revision,retry]);
 const results=useMemo(()=>searchProjectIndex(prepared.index,deferred,{scope,includeArchived:archived}),[prepared.index,deferred,scope,archived]),shown=results.slice(0,limit);
 useEffect(()=>{const previous=document.activeElement as HTMLElement|null,node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous?.isConnected)previous.focus();};},[]);
 const resetFilters=()=>{setScope('all');setArchived(true);setLimit(60);};
 return <dialog ref={dialog} className="project-search" aria-labelledby="project-search-title" onCancel={event=>{event.preventDefault();onClose();}} onKeyDown={event=>{
  if(event.defaultPrevented||event.nativeEvent.isComposing||stale)return;
  const target=event.target as HTMLElement;
  if(target!==input.current&&!target.closest('.project-search-result'))return;
  const buttons=Array.from(dialog.current?.querySelectorAll<HTMLButtonElement>('.project-search-result')??[]);if(!buttons.length)return;
  if(event.key==='Enter'&&target===input.current){event.preventDefault();buttons[0].click();return;}
  if(!['ArrowDown','ArrowUp','Home','End'].includes(event.key)||((event.key==='Home'||event.key==='End')&&target===input.current))return;
  event.preventDefault();const index=buttons.indexOf(document.activeElement as HTMLButtonElement),next=event.key==='Home'?0:event.key==='End'?buttons.length-1:index<0?event.key==='ArrowUp'?buttons.length-1:0:(index+(event.key==='ArrowDown'?1:-1)+buttons.length)%buttons.length;buttons[next]?.focus();
 }}>
  <div className="project-search-heading"><h2 id="project-search-title">{t('Search project')}</h2><button type="button" className="icon-button ui-close-button" aria-label={t('Close project search')} title={t('Close project search')} onClick={onClose}><X size={18} aria-hidden="true"/></button></div>
  <label className="project-search-input"><Search size={17} aria-hidden="true"/><span className="visually-hidden">{t('Search all project content')}</span><input ref={input} type="search" aria-label={t('Search all project content')} placeholder={t('Search project…')} value={query} onChange={event=>{setQuery(event.target.value);setLimit(60);}}/></label>
  <div className="project-search-filters"><div className="ui-form-field"><label htmlFor="project-search-scope">{t('Search in')}</label><Dropdown id="project-search-scope" value={scope} options={Object.entries(searchScopes).map(([value,label])=>({value,label:buttonLabel(label)}))} onChange={value=>{setScope(value as SearchScope);setLimit(60);}}/></div><label className="project-search-archived"><input type="checkbox" checked={archived} onChange={event=>{setArchived(event.target.checked);setLimit(60);}}/>{t('Include archived content')}</label><FieldHelp label={t('Include archived content')} description={t('Includes archived entries and ideas marked Incorporated or Discarded.')}/></div>
  <div role="status" className="project-search-status">{prepared.error?t('Search unavailable'):stale?t('Searching…'):query.trim()?t('{0} results',results.length):t('Type to search.')}</div>
  {prepared.error&&<div className="project-search-error"><p className="prompt-error" role="alert">{t('Search could not be prepared.')} {prepared.error}</p><button type="button" className="quick-action quick-action-text" onClick={()=>setRetry(value=>value+1)}>{t('Retry')}</button></div>}
  <div className="project-search-results" aria-busy={stale}>{shown.map(result=><button type="button" className="project-search-result" key={`${result.kind}:${result.id}`} disabled={stale} onClick={()=>onOpen(result)} aria-label={t('Open search result: {0}',result.title)}><strong><Highlight text={result.title} query={deferred}/>{result.archived&&<small>{' '+t('· Archived')}</small>}</strong><small>{buttonLabel(searchKindLabels[result.kind])}{result.context!==buttonLabel(searchKindLabels[result.kind])&&<> · <Highlight text={result.context} query={deferred}/></>}</small>{result.excerpt&&<span><Highlight text={result.excerpt} query={deferred}/></span>}</button>)}{results.length>shown.length&&<button type="button" className="quick-action quick-action-text project-search-more" disabled={stale} onClick={()=>setLimit(value=>value+60)}>{t('Show more results')} ({results.length-shown.length})</button>}{!prepared.error&&query.trim()&&!stale&&!results.length&&<div className="ui-empty-state"><Search size={28} aria-hidden="true"/><p>{t('No matching content.')}</p>{(scope!=='all'||!archived)&&<button type="button" className="quick-action quick-action-text" onClick={resetFilters}>{t('Clear filters')}</button>}</div>}</div>
 </dialog>;
}
