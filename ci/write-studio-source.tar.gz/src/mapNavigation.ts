export type MapLocationRequest={mapId:string;token:number}&({markerId:string;routeId?:never}|{routeId:string;markerId?:never});
export type MapView={zoom:number;x:number;y:number};
export type Size={width:number;height:number};
export const fittedMapView:MapView={zoom:1,x:0,y:0};
export function fitMapSize(viewport:Size,image:Size):Size{
 const ratio=Math.min(Math.max(1,viewport.width-64)/Math.max(1,image.width),Math.max(1,viewport.height-64)/Math.max(1,image.height));
 return {width:Math.max(1,image.width*ratio),height:Math.max(1,image.height*ratio)};
}
export function constrainMapView(view:MapView,viewport:Size,fit:Size):MapView{
 const zoom=Math.min(8,Math.max(.5,view.zoom));
 const horizontal=Math.max(0,(fit.width*zoom+viewport.width)/2-Math.min(64,viewport.width/2));
 const vertical=Math.max(0,(fit.height*zoom+viewport.height)/2-Math.min(64,viewport.height/2));
 return {zoom,x:Math.min(horizontal,Math.max(-horizontal,view.x)),y:Math.min(vertical,Math.max(-vertical,view.y))};
}
/** Anchor is relative to the viewport centre; the same image point stays beneath it. */
export function zoomMapView(view:MapView,nextZoom:number,anchor:{x:number;y:number},viewport:Size,fit:Size):MapView{
 const zoom=Math.max(.5,Math.min(8,nextZoom)),ratio=zoom/view.zoom;
 return constrainMapView({zoom,x:anchor.x-(anchor.x-view.x)*ratio,y:anchor.y-(anchor.y-view.y)*ratio},viewport,fit);
}
export function focusMapPoint(view:MapView,point:{x:number;y:number},viewport:Size,fit:Size):MapView{
 return constrainMapView({...view,x:(.5-point.x)*fit.width*view.zoom,y:(.5-point.y)*fit.height*view.zoom},viewport,fit);
}
