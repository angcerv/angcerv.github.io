type HistoryKey = {
 key:string;ctrlKey?:boolean;metaKey?:boolean;shiftKey?:boolean;altKey?:boolean;
 defaultPrevented?:boolean;isComposing?:boolean;nativeEvent?:{isComposing?:boolean};
};
/** Local canvas history only. Owning editors still guard fields, dialogs and gestures. */
export function historyShortcut(event:HistoryKey):'undo'|'redo'|undefined {
 if(event.defaultPrevented||event.isComposing||event.nativeEvent?.isComposing||event.altKey||!(event.ctrlKey||event.metaKey))return;
 const key=event.key.toLowerCase();
 if(key==='z')return event.shiftKey?'redo':'undo';
 if(key==='y')return 'redo';
}
