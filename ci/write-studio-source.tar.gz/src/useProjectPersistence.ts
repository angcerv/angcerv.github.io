import {useEffect,useRef,useState} from 'react';
import type {Dispatch,SetStateAction} from 'react';
import type {Project} from './model';
import type {SavePhase} from './SaveProgressDialog';
import {chooseFolder,saveProject} from './storage';
import {readDraft,recoveryWriter} from './recovery';
import type {Draft} from './recovery';
import {reconcileAutosave} from './autosave';
import {message,t} from './i18n';

type Options={
 project:Project|null;path:string;selectedId:string;session:number;
 setProject:Dispatch<SetStateAction<Project|null>>;setPath:Dispatch<SetStateAction<string>>;
 remember:(path:string,project:Project,opened:boolean)=>Promise<void>;
 isAutosaveBlocked:()=>boolean;
};
/** Persistence lifecycle only. The shell owns navigation and recovery decisions.
 * The mutable state/lock are shared with shell operations to serialize native I/O. */
export function useProjectPersistence({project,path,selectedId,session,setProject,setPath,remember,isAutosaveBlocked}:Options){
  const [ready, setReady] = useState(false);
  const [recoverable, setRecoverable] = useState<Draft | null>(null);
  const [recoveryReadError, setRecoveryReadError] = useState(false);
  const [recoveryStatus, setRecoveryStatus] = useState('');
  const recoveryVersion = useRef(0);
  const [autosaving, setAutosaving] = useState(false);
  const [autosaveError, setAutosaveError] = useState('');
  const [dirty, setDirty] = useState(false);
  const [busy, setBusy] = useState(false);
  const [saveProgress,setSaveProgress]=useState<{phase:SavePhase;error:string}|null>(null);
  const [operation, setOperation] = useState(t("Working…"));
  const [error, setError] = useState('');
  const state = useRef({ project, path, dirty, busy });
  state.current = { project, path, dirty, busy };
  const locked = useRef(false);
  useEffect(() => {
    let disposed = false;
    void readDraft().then(draft => { if (!disposed) setRecoverable(draft); })
      .catch(e => { if (!disposed) { setRecoveryReadError(true); setError(t("Recovery could not be read: {0}", String(e))); } })
      .finally(() => { if (!disposed) setReady(true); });
    return () => { disposed = true; };
  }, []);
  function protectDraft(next: Project, selected = selectedId) {
    const version = ++recoveryVersion.current;
    setRecoveryStatus(t("Updating recovery copy…"));
    void recoveryWriter.enqueue({ project: next, path: state.current.path, selectedId: selected })
      .then(() => { if (version === recoveryVersion.current) setRecoveryStatus(t("Recovery copy updated")); })
      .catch(e => { if (version === recoveryVersion.current) setRecoveryStatus(t("Recovery failed: {0}", String(e))); });
  }
  async function clearDraft() {
    ++recoveryVersion.current;
    await recoveryWriter.enqueue(null);
    setRecoveryStatus('');
  }
  async function run<T,>(work: () => Promise<T>, label = t("Working…")): Promise<T | undefined> {
    if (locked.current) return; locked.current = true; setBusy(true); setOperation(label); setError('');
    try { return await work(); } catch (e) { setError(String(e)); return undefined; } finally { locked.current = false; setBusy(false); }
  }
  const autosaveTick=useRef<()=>void>(()=>{});
  autosaveTick.current=()=>{
    if (isAutosaveBlocked() || busy || autosaving || recoverable || !ready || autosaveError) return;
    if (!state.current.dirty || !state.current.project || !state.current.path) return;
    void autosave();
  };
  useEffect(() => {
    if (!project?.id || !path || !ready) return;
    const timer = window.setInterval(() => autosaveTick.current(), 30000);
    return () => window.clearInterval(timer);
  }, [project?.id, path, ready, session]);
  const lifecycleTick=useRef<(hidden:boolean)=>void>(()=>{});
  lifecycleTick.current=hidden=>{
    if(!ready||recoverable||recoveryReadError)return;
    if(hidden){
      const current=state.current;
      if(!locked.current&&current.dirty&&current.project)protectDraft(current.project);
    }else autosaveTick.current();
  };
  useEffect(()=>{
    if(typeof document==='undefined')return;
    let hidden=false;
    const visibility=()=>{const next=document.visibilityState==='hidden';if(next===hidden)return;hidden=next;lifecycleTick.current(next);};
    const pagehide=()=>{if(!hidden){hidden=true;lifecycleTick.current(true);}};
    const pageshow=()=>{if(document.visibilityState!=='hidden'){hidden=false;lifecycleTick.current(false);}};
    document.addEventListener('visibilitychange',visibility);
    window.addEventListener('pagehide',pagehide);window.addEventListener('pageshow',pageshow);
    return()=>{document.removeEventListener('visibilitychange',visibility);window.removeEventListener('pagehide',pagehide);window.removeEventListener('pageshow',pageshow);};
  },[]);
  async function autosave() {
    if (locked.current || !state.current.project || !state.current.dirty || !state.current.path) return;
    locked.current = true; setAutosaving(true); setAutosaveError('');
    const snapshot = state.current.project;
    try {
      const saved = await saveProject(state.current.path, snapshot, true);
      remember(state.current.path, saved, false);
      const result = reconcileAutosave(state.current.project!, snapshot, saved);
      state.current.project = result.project;
      setProject(result.project);
      if (result.hasNewEdits) protectDraft(result.project);
      else {
        await clearDraft();
        if (state.current.project === result.project) { state.current.dirty = false; setDirty(false); }
        else protectDraft(state.current.project!);
      }
    } catch (e) { setAutosaveError(String(e)); }
    finally { locked.current = false; setAutosaving(false); }
  }
  async function save(): Promise<boolean> {
    return (await run(async () => {
      const current = state.current; if (!current.project) return false;
      const destination = current.path || await chooseFolder(); if (!destination) return false;
      setSaveProgress({phase:'saving',error:''});
      const snapshot = state.current.project!;
      let saved: Project;
      try { saved = await saveProject(destination, snapshot); } catch (e) { setSaveProgress({phase:'saving',error:message(String(e))});setAutosaveError(String(e)); throw e; }
      setSaveProgress({phase:'finishing',error:''});
      remember(destination, saved, false);
      try { await clearDraft(); } catch(e) {setSaveProgress({phase:'finishing',error:message(String(e))});throw e;}
      setSaveProgress(null);
      const result = reconcileAutosave(state.current.project!, snapshot, saved);
      state.current = { project: result.project, path: destination, dirty: result.hasNewEdits, busy: true };
      setProject(result.project); setPath(destination); setDirty(result.hasNewEdits); setAutosaveError('');
      if (result.hasNewEdits) protectDraft(result.project);
      // A caller may close/switch projects after true; newer edits still need saving.
      return !result.hasNewEdits;
    }, t("Saving…"))) ?? false;
  }
  return {ready,recoverable,setRecoverable,recoveryReadError,setRecoveryReadError,recoveryStatus,setRecoveryStatus,
   autosaving,autosaveError,setAutosaveError,dirty,setDirty,busy,saveProgress,setSaveProgress,operation,error,setError,
   state,locked,run,save,protectDraft,clearDraft};
}
