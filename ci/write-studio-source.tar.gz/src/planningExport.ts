import {arcStages,arcStatuses,orderedArcBeats} from './characterArcs';
import {textReferencePlainText} from './textReferenceTokens';
import type { Project } from './model';
import { getSceneStatus, writingStatusLabels, suggestFolderName } from './model';
import { orderedPlotBeats } from './plotThreads';
import { t } from './i18n';
export type PlanningExportOptions={chapters:boolean;plots:boolean;arcs?:boolean};
// Treat planning notes as text, never as raw Markdown/HTML supplied by an entry.
const escape=(text:string)=>textReferencePlainText(text).replace(/\r\n?/g,'\n').replace(/[\\`*_[\]{}<>#!|~+\-.()]/g,'\\$&');
const heading=(text:string)=>escape(text.replace(/[\r\n]+/g,' '));
const quote=(text:string)=>escape(text).split('\n').map(line=>`> ${line}`).join('\n');
export const planningFilename=(title:string)=>`${suggestFolderName(title)}-${t('planning')}.md`;
export function planningMarkdown(project:Project,options:PlanningExportOptions={chapters:true,plots:true}):string{
 const includeArcs=options.arcs??options.plots;
 if(!options.chapters&&!options.plots&&!includeArcs)throw new Error(t('Choose at least one planning section.'));
 const parts=[`# ${heading(project.title||t('Untitled project'))}`,t('Story planning')];
 if(options.chapters){
  parts.push(`## ${t('Chapters and scenes')}`);
  if(!project.chapters.length)parts.push(t('No chapters yet.'));
  const bookByChapter=new Map((project.books??[]).flatMap(book=>book.chapterIds.map(id=>[id,book] as const)));
  const grouped=new Set(project.chapters.map(chapter=>bookByChapter.get(chapter.id)?.id).filter(Boolean)).size>1;
  project.chapters.forEach((chapter,index)=>{
   const book=bookByChapter.get(chapter.id);
   if(grouped&&(index===0||bookByChapter.get(project.chapters[index-1].id)?.id!==book?.id))parts.push(`### ${heading(book?.title??'')}`);
   parts.push(`${grouped?'####':'###'} ${index+1}. ${heading(chapter.title||t('Untitled chapter'))}`,`**${t('Chapter synopsis')}**`,quote(chapter.synopsis?.trim()?chapter.synopsis:t('No synopsis yet')));
   if(chapter.planning){
    for(const [field,label] of [['purpose','Chapter purpose'],['conflict','Central conflict'],['turn','Turning point'],['outcome','Chapter outcome'],['notes','Chapter planning notes']] as const)if(chapter.planning[field].trim())parts.push(`**${t(label)}**`,quote(chapter.planning[field]));
    if(chapter.planning.plotIds.length)parts.push(`**${t('Expected plots')}:** ${chapter.planning.plotIds.map(id=>heading(project.plots?.threads.find(plot=>plot.id===id)?.title??t('Deleted plot'))).join(' · ')}`);
    if(chapter.planning.arcIds.length)parts.push(`**${t('Expected character arcs')}:** ${chapter.planning.arcIds.map(id=>heading(project.plots?.arcs?.find(arc=>arc.id===id)?.title??t('Deleted arc'))).join(' · ')}`);
   }
   if(!chapter.scenes.length)parts.push(t('No scenes yet.'));
   chapter.scenes.forEach((scene,sceneIndex)=>{
    parts.push(`${grouped?'#####':'####'} ${index+1}.${sceneIndex+1}. ${heading(scene.title||t('Untitled scene'))}`,`- **${t('Writing status')}:** ${t(writingStatusLabels[getSceneStatus(scene)])}`);
    const plots=project.plots?.threads.filter(plot=>plot.beats.some(beat=>beat.sceneId===scene.id))??[];
    if(options.plots&&plots.length)parts.push(`- **${t('Plots')}:** ${plots.map(plot=>heading(plot.title||t('Untitled plot'))).join(' · ')}`);
    if(scene.planning)for(const [field,label] of [['goal','Scene goal'],['conflict','Scene conflict'],['change','What changes by the end?']] as const)if(scene.planning[field].trim())parts.push(`**${t(label)}**`,quote(scene.planning[field]));
    parts.push(`**${t('Scene synopsis')}**`,quote(scene.synopsis?.trim()?scene.synopsis:t('No synopsis yet')));
   });
  });
 }
 if(options.plots){
  parts.push(`## ${t('Plots')}`);
  if(!project.plots?.threads.length)parts.push(t('No plots yet.'));
  const statuses={planned:'Planned plot',active:'Active plot',resolved:'Resolved plot'};
  for(const plot of project.plots?.threads??[]){
   parts.push(`### ${heading(plot.title||t('Untitled plot'))}`,`- **${t('Plot status')}:** ${t(statuses[plot.status])}`,`**${t('Plot notes')}**`,quote(plot.notes.trim()?plot.notes:t('No plot notes yet.')),`#### ${t('Linked scenes in manuscript order')}`);
   const beats=orderedPlotBeats(project,plot);
   if(!beats.length)parts.push(t('No linked scenes'));
   for(const {beat,location} of beats){
    parts.push(`- **${location?`${heading(location.chapter.title||t('Untitled chapter'))} / ${heading(location.scene.title||t('Untitled scene'))}`:t('Deleted scene')}**`);
    if(!location)parts.push(quote(t('This scene was deleted. Its plot note is kept in case you recover it.')));
    parts.push(quote(beat.note.trim()?beat.note:t('No scene development note yet.')));
   }
  }
 }
 if(includeArcs&&(project.plots?.arcs?.length??0)>0){
  parts.push(`## ${t('Character arcs')}`);
  for(const arc of project.plots?.arcs??[]){
   parts.push(`### ${heading(arc.title||t('Untitled arc'))}`,`- **${t('Character')}:** ${heading(project.worldbuilding?.entries.find(entry=>entry.id===arc.entryId)?.title??t('Deleted entry'))}`,`- **${t('Arc status')}:** ${t(arcStatuses[arc.status])}`);
   for(const [field,label] of [['startingPoint','Starting point'],['desire','What do they want?'],['innerConflict','Inner conflict'],['resolution','Intended change'],['notes','Arc notes']] as const)if(arc[field].trim())parts.push(`**${t(label)}**`,quote(arc[field]));
   for(const {beat,location} of orderedArcBeats(project,arc)){
    parts.push(`#### ${location?`${heading(location.chapter.title)} / ${heading(location.scene.title)}`:t('Deleted scene')} · ${t(arcStages[beat.stage])}`);
    for(const [field,label] of [['note','What changes for this character?'],['goal','Goal in this scene'],['conflict','Conflict in this scene'],['relationships','Relationship changes']] as const)if(beat[field].trim())parts.push(`**${t(label)}**`,quote(beat[field]));
   }
  }
 }
 return parts.join('\n\n')+'\n';
}
