import {fieldGroups} from './templateSections';
import {longTextPlainText} from './longText';
import {parseStoryDate} from './timeline';
import {isStoryDate} from './ages';
import {isEntryReference} from './worldbuilding';
import type {Entry,Field,Template} from './worldbuilding';
export const loreOverviewId='lore-overview';
export function loreModeTarget(reading:boolean,currentSection:string){return reading?loreOverviewId:currentSection===loreOverviewId?'':currentSection;}
export const loreSectionId=(id:string)=>`lore-section-${id||'ungrouped'}`;
export function hasLoreValue(field:Field,value:Entry['values'][string]|undefined){
 if(value===undefined||value===null)return false;
 if(typeof value==='string')return !!(field.fieldType==='longText'?longTextPlainText(value):value).trim();
 if(Array.isArray(value))return value.length>0;
 if(typeof value==='object')return isEntryReference(value)||field.fieldType==='date'&&isStoryDate(value);
 return true;
}
/** Only explicit, short description fields can become an introduction. No inferred prose. */
export function loreIntroduction(template:Template,entry:Entry){
 return template.fields.find(field=>{
  const name=field.label.normalize('NFD').replace(/[\u0300-\u036f]/g,'').trim().toLowerCase();
  const value=entry.values[field.id];
  if(field.archived||!['shortText','longText'].includes(field.fieldType)||!['summary','description','resumen','descripcion'].includes(name)||typeof value!=='string')return false;
  const text=longTextPlainText(value).trim();return text.length>0&&text.length<=400&&!/\n\s*[-*] /.test(value);
 });
}
export function loreFieldLayout(field:Field,value:Entry['values'][string]|undefined){
 return field.fieldType==='longText'||typeof value==='string'&&(value.length>160||value.includes('\n'))?'prose':'fact';
}
export function loreGroups(template:Template,entry:Entry,reading:boolean){
 return fieldGroups(template,true).map(group=>({...group,fields:group.fields.filter(field=>!reading||hasLoreValue(field,entry.values[field.id]))})).filter(group=>group.fields.length>0);
}
export function loreArticleGroups(template:Template,entry:Entry){
 const introduction=loreIntroduction(template,entry);
 return loreGroups(template,entry,true).map(group=>({...group,fields:group.fields.filter(field=>field.id!==introduction?.id)})).filter(group=>group.fields.length);
}
/** Flush-on-blur controls remain in the same live project. Invalid local date drafts
 * must be corrected before unmounting their inputs, rather than silently discarded. */
export function prepareLoreNavigation(root:HTMLElement|null){
 if(!root)return true;
 for(const input of root.querySelectorAll<HTMLInputElement>('.world-entry-detail .story-date-input input')){
  try{parseStoryDate(input.value);}catch{input.focus();return false;}
 }
 const focused=root.ownerDocument.activeElement;
 if(focused instanceof HTMLElement&&root.contains(focused))focused.blur();
 return true;
}
export function revealLoreSection(root:HTMLElement,id:string){
 if(id===loreOverviewId){root.scrollTo({top:0,behavior:'instant'});return true;}
 const target=Array.from(root.querySelectorAll<HTMLElement>('[data-lore-section]')).find(element=>element.id===id);
 if(!target)return false;
 for(let element:HTMLElement|null=target;element&&element!==root;element=element.parentElement)if(element instanceof HTMLDetailsElement)element.open=true;
 root.scrollTo({top:root.scrollTop+target.getBoundingClientRect().top-root.getBoundingClientRect().top-18,behavior:'instant'});
 return true;
}
export function visibleLoreSection(root:HTMLElement){
 const top=root.getBoundingClientRect().top+60,sections=Array.from(root.querySelectorAll<HTMLElement>('[data-lore-section]'));
 const preceding=sections.filter(section=>section.getBoundingClientRect().top<=top);return (preceding[preceding.length-1]??sections[0])?.id??'';
}
