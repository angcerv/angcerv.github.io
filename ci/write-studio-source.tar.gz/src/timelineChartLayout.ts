import { daysInMonth } from './timeline';
import type { StoryDate, TimelineEvent } from './timeline';

// Integer Gregorian day coordinates relative to 0000-01-01. No Date/timezone or year-99 special cases.
export function storyDay(date: StoryDate, latest = false): number {
  const year = date.year, month = date.month ?? (latest ? 12 : 1);
  let value = 365 * year + Math.floor((year + 3) / 4) - Math.floor((year + 99) / 100) + Math.floor((year + 399) / 400);
  for (let previous = 1; previous < month; previous++) value += daysInMonth(year, previous);
  return value + (date.day ?? (latest ? daysInMonth(year, month) : 1)) - 1;
}
export function dateFromStoryDay(value: number): StoryDate {
  const day = Math.floor(value);
  let low = -2000000, high = 2000000;
  while (low + 1 < high) { const middle = Math.floor((low + high) / 2); if (storyDay({ year: middle }) <= day) low = middle; else high = middle; }
  let remaining = day - storyDay({ year: low }), month = 1;
  while (remaining >= daysInMonth(low, month) && month < 12) { remaining -= daysInMonth(low, month); month++; }
  return { year: low, month, day: remaining + 1 };
}
export type EventRange = { event: TimelineEvent; start: number; end: number; kind: 'point' | 'period'; partial: boolean };
export function eventRange(event: TimelineEvent): EventRange | null {
  if (!event.start) return null;
  const partial = event.start.day === undefined || (!!event.end && event.end.day === undefined);
  return { event, start: storyDay(event.start), end: storyDay(event.end ?? event.start, true), kind: event.end ? 'period' : 'point', partial };
}
export function chartDomain(events: TimelineEvent[], focusId?: string): { start: number; end: number } | null {
  const ranges = events.map(eventRange).filter((range): range is EventRange => range !== null);
  const focus = ranges.find(range => range.event.id === focusId);
  const visible = focus ? [focus] : ranges;
  if (!visible.length) return null;
  let start = Infinity, end = -Infinity;
  for (const range of visible) { start = Math.min(start, range.start); end = Math.max(end, range.end); }
  const padding = Math.max(3, Math.ceil((end - start) * .06));
  return { start: start - padding, end: end + padding };
}
export type ChartTick = { day: number; label: string };
const pad = (value: number) => String(value).padStart(2, '0');
export function chartTicks(start: number, end: number, count = 7): ChartTick[] {
  const span = Math.max(1, end - start), budget = Math.max(2, Math.min(32, Math.floor(count) || 7)), target = span / budget, ticks: ChartTick[] = [];
  const push = (day: number, label: string) => { if (day >= start && day <= end) ticks.push({ day, label }); };
  // Choose precision from the available label spacing, rather than fixed zoom cutoffs.
  if (target <= 14) {
    const step = [1, 2, 3, 5, 7, 10, 14].find(value => value >= target) ?? 14;
    for (let day = Math.ceil(start / step) * step; day <= end && ticks.length < 40; day += step) { const date = dateFromStoryDay(day); push(day, `${date.year}-${pad(date.month!)}-${pad(date.day!)}`); }
  } else if (target <= 365.2425 / 2) {
    const step = [1, 2, 3, 6].find(value => value >= target / 30.44) ?? 6;
    const first = dateFromStoryDay(start);
    for (let monthIndex = Math.ceil((first.year * 12 + first.month! - 1) / step) * step; ticks.length < 40; monthIndex += step) {
      const year = Math.floor(monthIndex / 12), month = monthIndex - year * 12 + 1, day = storyDay({ year, month });
      if (day > end) break; push(day, `${year}-${pad(month)}`);
    }
  } else {
    const years = target / 365.2425, power = 10 ** Math.floor(Math.log10(Math.max(1, years)));
    const step = [1, 2, 5, 10].map(value => value * power).find(value => value >= years) ?? power * 10;
    for (let year = Math.ceil(dateFromStoryDay(start).year / step) * step; ticks.length < 40; year += step) { const day = storyDay({ year }); if (day > end) break; push(day, String(year)); }
  }
  if (!ticks.length) {
    const day = Math.min(end, Math.max(start, Math.round((start + end) / 2))), date = dateFromStoryDay(day);
    ticks.push({ day, label: `${date.year}-${pad(date.month!)}-${pad(date.day!)}` });
  }
  return ticks;
}
