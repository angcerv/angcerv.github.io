import type {MapColor} from './maps';
import {textReferencePlainText} from './textReferenceTokens';
import { t } from './i18n';
export type StoryDate = { year: number; month?: number; day?: number };
export type TimelineEvent = { id: string; title: string; notes: string; dateLabel: string; start?: StoryDate; end?: StoryDate; sceneIds: string[]; entryIds: string[]; plotIds?: string[]; relations?: {relationId:string;entryIds:string[]}[] };
export type TimelineTrack = { color?:MapColor;description?:string;id: string; title: string; eventIds: string[] };
export type TimelineRelation = {id:string;title:string;templateIds:string[]};
export type Timeline = { calendar?:import('./storyCalendar').StoryCalendar; schemaVersion: 1 | 2 | 3 | 4 | 5 | 6; events: TimelineEvent[]; tracks?: TimelineTrack[]; relationTypes?:TimelineRelation[] };
export const emptyTimeline: Timeline = { schemaVersion: 1, events: [] };
export const daysInMonth = (year: number, month: number) => month === 2 ? (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0) ? 29 : 28) : [4,6,9,11].includes(month) ? 30 : 31;
export function parseStoryDate(value: string): StoryDate | undefined {
  if (!value.trim()) return undefined;
  const match = /^(-?\d{1,6})(?:-(\d{2})(?:-(\d{2}))?)?$/.exec(value.trim());
  if (!match) throw new Error(t("Use year, year-MM or year-MM-DD. Negative years are supported."));
  const year = Number(match[1]), month = match[2] ? Number(match[2]) : undefined, day = match[3] ? Number(match[3]) : undefined;
  if ((month !== undefined && (month < 1 || month > 12)) || (day !== undefined && (day < 1 || day > daysInMonth(year, month!)))) throw new Error(t("This date is not valid."));
  return { year, ...(month !== undefined ? { month } : {}), ...(day !== undefined ? { day } : {}) };
}
export function formatStoryDate(date?: StoryDate): string { return date ? `${date.year}${date.month !== undefined ? `-${String(date.month).padStart(2,'0')}` : ''}${date.day !== undefined ? `-${String(date.day).padStart(2,'0')}` : ''}` : ''; }
const bound = (date: StoryDate, latest = false) => date.year * 372 + ((date.month ?? (latest ? 12 : 1)) - 1) * 31 + (date.day ?? (latest ? daysInMonth(date.year, date.month ?? 12) : 1));
export function validatePeriod(start?: StoryDate, end?: StoryDate) { if (end && !start) throw new Error(t("Add a start date before an end date.")); if (start && end && bound(end, true) < bound(start)) throw new Error(t("The end must not precede the start.")); }
export function eventDateLabel(event: TimelineEvent): string { const date = event.start ? `${formatStoryDate(event.start)}${event.end ? ` → ${formatStoryDate(event.end)}` : ''}` : ''; return [event.dateLabel, date].filter(Boolean).join(' · ') || t("Date unknown"); }
export function sortedEvents(timeline: Timeline, mode: 'manual' | 'date' | 'dateDesc', query = ''): TimelineEvent[] {
  const needle = query.trim().toLocaleLowerCase();
  const events = timeline.events.filter(event => !needle || [event.title, event.notes, eventDateLabel(event)].some(text => textReferencePlainText(text).toLocaleLowerCase().includes(needle)));
  return mode === 'manual' ? events : events.map((event, index) => ({event,index})).sort((a,b) => (a.event.start&&b.event.start?(bound(a.event.start)-bound(b.event.start))*(mode==='dateDesc'?-1:1):a.event.start?-1:b.event.start?1:0) || a.index - b.index).map(item => item.event);
}
export function updateEvent(timeline: Timeline, event: TimelineEvent): Timeline { return { ...timeline, events: timeline.events.map(item => item.id === event.id ? event : item) }; }
export function moveEvent(timeline: Timeline, id: string, direction: -1 | 1): Timeline { const index = timeline.events.findIndex(event => event.id === id), next = index + direction; if (index < 0 || next < 0 || next >= timeline.events.length) return timeline; const events = [...timeline.events]; [events[index],events[next]] = [events[next],events[index]]; return {...timeline,events}; }

export type TimelineFilters = { bookId?:string; plotId?:string;trackId?:string;eventType?:'all'|'point'|'period'|'undated';unlinked?:boolean; entryId: string; sceneId: string; chapterId: string; from?: StoryDate; to?: StoryDate; includeUndated: boolean };
export const emptyTimelineFilters: TimelineFilters = { entryId: '', sceneId: '', chapterId: '', includeUndated: true };
/** All selected criteria must match. Partial dates and periods match by overlap. */
export function filterTimelineEvents(events: TimelineEvent[], filters: TimelineFilters, chapters: { id: string; scenes: { id: string }[] }[],tracks:TimelineTrack[]=[],books:{id:string;chapterIds:string[]}[]=[]): TimelineEvent[] {
  const chapterScenes = filters.chapterId ? new Set(chapters.find(chapter => chapter.id === filters.chapterId)?.scenes.map(scene => scene.id) ?? []) : undefined;
  const bookIds=filters.bookId?new Set(books.find(book=>book.id===filters.bookId)?.chapterIds??[]):undefined;
  const bookScenes=bookIds?new Set(chapters.filter(chapter=>bookIds.has(chapter.id)).flatMap(chapter=>chapter.scenes.map(scene=>scene.id))):undefined;
  return events.filter(event => {
    if(bookScenes&&!event.sceneIds.some(id=>bookScenes.has(id)))return false;
    if(filters.trackId&&!tracks.find(track=>track.id===filters.trackId)?.eventIds.includes(event.id))return false;
    if(filters.plotId&&!event.plotIds?.includes(filters.plotId))return false;
    if(filters.unlinked&&(event.sceneIds.length||timelineEventEntryIds(event).length||event.plotIds?.length))return false;
    if(filters.eventType==='undated'&&event.start||filters.eventType==='point'&&(!event.start||event.end)||filters.eventType==='period'&&!event.end)return false;
    if (filters.entryId && !timelineEventEntryIds(event).includes(filters.entryId)) return false;
    if (filters.sceneId && !event.sceneIds.includes(filters.sceneId)) return false;
    if (chapterScenes && !event.sceneIds.some(id => chapterScenes.has(id))) return false;
    if (!event.start) return filters.includeUndated;
    if (filters.from && bound(event.end ?? event.start, true) < bound(filters.from)) return false;
    if (filters.to && bound(event.start) > bound(filters.to, true)) return false;
    return true;
  });
}

export function saveTimelineEvent(timeline:Timeline,event:TimelineEvent,trackIds:string[]):Timeline{
 const events=timeline.events.some(item=>item.id===event.id)?timeline.events.map(item=>item.id===event.id?event:item):[...timeline.events,event];
 return {...timeline,schemaVersion:Math.max(timeline.schemaVersion,event.relations?.length?4:event.plotIds?.length?3:1) as Timeline['schemaVersion'],events,...(timeline.tracks?{tracks:timeline.tracks.map(track=>({...track,eventIds:trackIds.includes(track.id)?Array.from(new Set([...track.eventIds,event.id])):track.eventIds.filter(id=>id!==event.id)}))}:{})};
}
export function removeTimelineEvent(timeline:Timeline,id:string):Timeline{return {...timeline,events:timeline.events.filter(event=>event.id!==id),...(timeline.tracks?{tracks:timeline.tracks.map(track=>({...track,eventIds:track.eventIds.filter(eventId=>eventId!==id)}))}:{})};}
export function saveTimelineTrack(timeline:Timeline,track:TimelineTrack):Timeline{
 const ids=new Set(timeline.events.map(event=>event.id)),clean={...track,title:track.title.trim(),eventIds:[...new Set(track.eventIds)].filter(id=>ids.has(id))};
 return {...timeline,schemaVersion:Math.max(timeline.schemaVersion,track.color||track.description!==undefined?5:2) as Timeline['schemaVersion'],tracks:timeline.tracks?.some(item=>item.id===track.id)?timeline.tracks.map(item=>item.id===track.id?clean:item):[...(timeline.tracks??[]),clean]};
}

export function eventDateType(event:TimelineEvent):'single'|'period'{return event.end?'period':'single';}
export function eventHasIncompleteDate(event:TimelineEvent):boolean{return !!event.start&&(event.start.day===undefined||!!event.end&&event.end.day===undefined);}
export function eventDateDescription(event:TimelineEvent):string{return [t(eventDateType(event)==='period'?'Period':'Single date'),eventHasIncompleteDate(event)?t('Incomplete date'):''].filter(Boolean).join(' · ');}

export function timelineEventEntryIds(event:TimelineEvent):string[]{return [...new Set([...event.entryIds,...(event.relations??[]).flatMap(relation=>relation.entryIds)])];}
export function removeTimelineRelation(timeline:Timeline,id:string):Timeline{
 return {...timeline,relationTypes:timeline.relationTypes?.filter(relation=>relation.id!==id),events:timeline.events.map(event=>({...event,entryIds:[...new Set([...event.entryIds,...(event.relations??[]).filter(relation=>relation.relationId===id).flatMap(relation=>relation.entryIds)])],relations:event.relations?.filter(relation=>relation.relationId!==id)}))};
}

export function assignTimelineEvents(timeline:Timeline,trackId:string,eventIds:string[],assigned:boolean):Timeline{
 const existing=new Set(timeline.events.map(event=>event.id)),selected=new Set(eventIds.filter(id=>existing.has(id)));
 return {...timeline,tracks:timeline.tracks?.map(track=>track.id===trackId?{...track,eventIds:assigned?[...new Set([...track.eventIds,...selected])]:track.eventIds.filter(id=>!selected.has(id))}:track)};
}
export function moveTimelineTrack(timeline:Timeline,id:string,direction:number):Timeline{
 const tracks=[...(timeline.tracks??[])],index=tracks.findIndex(track=>track.id===id),to=index+direction;
 if(index<0||to<0||to>=tracks.length)return timeline;
 [tracks[index],tracks[to]]=[tracks[to],tracks[index]];return {...timeline,tracks};
}
export function duplicateTimelineTrack(timeline:Timeline,id:string,newId:string):Timeline{
 const track=timeline.tracks?.find(track=>track.id===id);if(!track)return timeline;
 let title=t('{0} (copy {1})',track.title,1),index=1;
 while(timeline.tracks?.some(track=>track.title.toLocaleLowerCase()===title.toLocaleLowerCase()))title=t('{0} (copy {1})',track.title,++index);
 return saveTimelineTrack(timeline,{...track,id:newId,title,eventIds:[...track.eventIds]});
}
