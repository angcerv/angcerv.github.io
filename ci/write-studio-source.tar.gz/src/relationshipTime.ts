import {daysInMonth} from './timeline';
import type {StoryDate} from './timeline';
import type {EntryRelation} from './entryRelations';
export type RelationshipStatus='active'|'ended'|'future'|'uncertain';
/** Partial dates represent inclusive ranges. Missing bounds never imply infinity. */
function range(date:StoryDate):[number,number]{return [date.year*372+((date.month??1)-1)*31+(date.day??1),date.year*372+((date.month??12)-1)*31+(date.day??daysInMonth(date.year,date.month??12))];}
export function relationshipStatus(link:Pick<EntryRelation,'start'|'end'>,at:StoryDate):RelationshipStatus{
 const [from,to]=range(at),start=link.start?range(link.start):undefined,end=link.end?range(link.end):undefined;
 if(start&&start[0]>to)return 'future';
 if(end&&end[1]<from)return 'ended';
 if(start&&end&&start[1]<=from&&end[0]>=to)return 'active';
 return 'uncertain';
}
export function connectionVisibleAt(link:EntryRelation,at?:StoryDate,showEnded=false){if(!at)return true;const status=relationshipStatus(link,at);return status==='active'||status==='uncertain'||showEnded&&status==='ended';}
export function relationshipStatusText(status:RelationshipStatus){return status==='active'?'Active at this date':status==='ended'?'Ended before this date':status==='future'?'Starts after this date':'Validity uncertain';}
export function derivedRelationshipStatus(paths:RelationshipStatus[][]):RelationshipStatus{
 const statuses=paths.map(path=>path.includes('future')?'future':path.includes('ended')?'ended':path.includes('uncertain')?'uncertain':'active');
 return statuses.includes('active')?'active':statuses.includes('uncertain')?'uncertain':statuses.includes('ended')?'ended':'future';
}
