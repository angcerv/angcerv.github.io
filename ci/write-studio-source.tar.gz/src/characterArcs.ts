import type {Project} from './model';
import type {ProjectPlots} from './plotThreads';
import {longTextPlainText} from './longText';
export const arcStatuses={planned:'Planned arc',active:'Active arc',resolved:'Completed arc'} as const;
export const arcStages={setup:'Starting point',catalyst:'Catalyst',struggle:'Struggle',choice:'Decisive choice',change:'Change',aftermath:'Aftermath'} as const;
export type ArcBeat={sceneId:string;stage:keyof typeof arcStages;note:string;goal:string;conflict:string;relationships:string};
export type CharacterArc={id:string;entryId:string;title:string;status:keyof typeof arcStatuses;startingPoint:string;desire:string;innerConflict:string;resolution:string;notes:string;beats:ArcBeat[]};
export const newCharacterArc=(id:string,entryId:string,title:string):CharacterArc=>({id,entryId,title,status:'planned',startingPoint:'',desire:'',innerConflict:'',resolution:'',notes:'',beats:[]});
export function saveCharacterArc(plots:ProjectPlots,arc:CharacterArc):ProjectPlots{
 return {...plots,schemaVersion:2,arcs:plots.arcs?.some(item=>item.id===arc.id)?plots.arcs.map(item=>item.id===arc.id?arc:item):[...(plots.arcs??[]),arc]};
}
export function removeCharacterArc(plots:ProjectPlots,id:string):ProjectPlots{return {...plots,arcs:plots.arcs?.filter(arc=>arc.id!==id)};}
export function linkArcScene(plots:ProjectPlots,id:string,sceneId:string,linked:boolean):ProjectPlots{
 const arc=plots.arcs?.find(item=>item.id===id);if(!arc||arc.beats.some(beat=>beat.sceneId===sceneId)===linked)return plots;
 return saveCharacterArc(plots,{...arc,beats:linked?[...arc.beats,{sceneId,stage:'struggle',note:'',goal:'',conflict:'',relationships:''}]:arc.beats.filter(beat=>beat.sceneId!==sceneId)});
}
export function orderedArcBeats(project:Project,arc:CharacterArc){
 const locations=new Map(project.chapters.flatMap(chapter=>chapter.scenes.map(scene=>({chapter,scene}))).map((location,index)=>[location.scene.id,{...location,index}]));
 return arc.beats.map(beat=>({beat,location:locations.get(beat.sceneId)})).sort((a,b)=>(a.location?.index??Infinity)-(b.location?.index??Infinity));
}
export function filterCharacterArcs(project:Project,query:string,status:keyof typeof arcStatuses|'all'){
 const needle=query.trim().toLocaleLowerCase();
 return (project.plots?.arcs??[]).filter(arc=>(status==='all'||arc.status===status)&&(!needle||[arc.title,project.worldbuilding?.entries.find(entry=>entry.id===arc.entryId)?.title??'',arc.startingPoint,arc.desire,arc.innerConflict,arc.resolution,arc.notes,...arc.beats.flatMap(beat=>[beat.note,beat.goal,beat.conflict,beat.relationships])].some(text=>longTextPlainText(text).toLocaleLowerCase().includes(needle))));
}
