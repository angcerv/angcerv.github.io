import {defaultSymbolPlacement} from './symbolPlacement';
import type {SymbolPlacementOptions} from './symbolPlacement';
import type {DrawingSymbol} from './mapDrawing';
import type {DrawingObject,DrawingStroke} from './mapDrawing';
import type {TerrainBrushShape} from './mapBrush';
import {isTerrainMaterial,terrainMaterials,textureIntensity,textureScaleValue,textureRotationValue} from './mapMaterials';
import type {TerrainMaterial} from './mapMaterials';
import {terrainOpacity} from './mapTerrain';

export type MaterialPreset={material:TerrainMaterial;color:string;intensity:number;size:number;shape:TerrainBrushShape;softness:number;opacity:number;contour:boolean;textureScale:number;textureRotation:number};
/** Bounded, most-recent-first recipes from actual paint; no geometry or separate content store. */
export function recentMaterialPresets(strokes:readonly DrawingStroke[],allowed:readonly TerrainMaterial[],limit=6):MaterialPreset[]{
 const result:MaterialPreset[]=[],seen=new Set<string>();
 for(let index=strokes.length-1;index>=0&&result.length<Math.max(0,Math.min(12,limit));index--){
  const stroke=strokes[index];if(stroke.erase||!stroke.points.length||!isTerrainMaterial(stroke.material)||!allowed.includes(stroke.material))continue;
  const color=stroke.color&&/^#[0-9a-f]{6}$/i.test(stroke.color)?stroke.color.toLowerCase():terrainMaterials[stroke.material].color;
  const preset:MaterialPreset={material:stroke.material,color,intensity:textureIntensity(stroke.textureIntensity),size:stroke.width,shape:stroke.brushShape??'circle',softness:stroke.softness??0,opacity:terrainOpacity(stroke.opacity),contour:!!stroke.closed,textureScale:textureScaleValue(stroke.textureScale),textureRotation:textureRotationValue(stroke.textureRotation)};
  const key=JSON.stringify(preset);if(seen.has(key))continue;seen.add(key);result.push(preset);
 }
 return result;
}
export type DrawingObjectStyle=Pick<DrawingObject,'kind'|'size'|'color'|'halo'|'rotation'|'lineWidth'|'fill'|'smooth'|'dashed'>;
/** Copy appearance only: identity, text, position, points and layer are deliberately excluded. */
export function drawingObjectStyle(object:DrawingObject):DrawingObjectStyle{
 const {kind,size,color,halo,rotation,lineWidth,fill,smooth,dashed}=object;
 return {kind,size,color:color??(kind==='label'?'#303c35':'#465648'),halo:kind==='label'?(halo??'#f5efd6'):halo,rotation,lineWidth,fill,smooth,dashed};
}

export type SymbolPreset={kind:DrawingSymbol;color?:string;size:number;rotation:number;placement:SymbolPlacementOptions};
export function recentSymbolPresets(objects:readonly DrawingObject[],allowed:readonly DrawingSymbol[],limit=6):SymbolPreset[]{
 const result:SymbolPreset[]=[],seen=new Set<string>();
 for(let index=objects.length-1;index>=0&&result.length<Math.max(0,Math.min(12,limit));index--){
  const object=objects[index];if(!allowed.some(kind=>kind===object.kind))continue;
  const settings=object.stamp,preset:SymbolPreset={kind:object.kind as DrawingSymbol,color:object.color,size:settings?.baseSize??object.size,rotation:settings?.baseRotation??object.rotation??0,placement:settings?{continuous:settings.continuous,density:settings.density,sizeVariation:settings.sizeVariation,rotationVariation:settings.rotationVariation}:{...defaultSymbolPlacement}};
  const key=preset.kind;if(seen.has(key))continue;seen.add(key);result.push(preset);
 }
 return result;
}
