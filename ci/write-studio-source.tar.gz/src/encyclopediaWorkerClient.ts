import type {Project} from './model';
import {encyclopediaSelection,encyclopediaExportLimit,encyclopediaExportTooLarge} from './encyclopediaExport';
import type {EncyclopediaOptions,EncyclopediaFormat} from './encyclopediaExport';
import {entryImageIds} from './visualResources';
import {encyclopediaExportImage} from './encyclopediaExportImage';
import {readEntryImage} from './entryImages';
import {getLanguage,t} from './i18n';
export async function runEncyclopediaWorker(project:Project,options:EncyclopediaOptions,format:EncyclopediaFormat,path:string,signal:AbortSignal):Promise<string>{
 signal.throwIfAborted();
 const images:Record<string,Blob>={};let total=0;
 if(format==='html'&&options.images){
  const ids=new Set(encyclopediaSelection(project,options).flatMap(category=>category.entries).flatMap(entryImageIds));
  for(const id of ids){
   signal.throwIfAborted();
   let onAbort:()=>void=()=>{};
   const aborted=new Promise<never>((_resolve,reject)=>{onAbort=()=>reject(signal.reason);signal.addEventListener('abort',onAbort,{once:true});});
   try{images[id]=await Promise.race([readEntryImage(path,project.id,id,false).then(blob=>encyclopediaExportImage(blob,signal)),aborted]);}
   catch{signal.throwIfAborted();throw new Error(t('An entry image could not be read. Retry or export without images.'));}
   finally{signal.removeEventListener('abort',onAbort);}
   signal.throwIfAborted();total+=images[id].size;
   if(total>encyclopediaExportLimit/2)throw new Error(t(encyclopediaExportTooLarge));
  }
 }
 // Do not clone manuscript, maps, history or other unrelated project data.
 const snapshot={title:project.title,worldbuilding:project.worldbuilding,entryRelations:project.entryRelations} as Project;
 return new Promise((resolve,reject)=>{
  const worker=new Worker(new URL('./encyclopediaExport.worker.ts',import.meta.url),{type:'module'});
  const finish=(error?:unknown,source?:string)=>{signal.removeEventListener('abort',abort);worker.terminate();if(error)reject(error);else resolve(source!);};
  const abort=()=>finish(new DOMException('Export cancelled','AbortError'));
  signal.addEventListener('abort',abort,{once:true});
  worker.onmessage=({data}:{data:{source?:string;error?:string}})=>finish(data.error?new Error(data.error):undefined,data.source);
  worker.onerror=event=>{event.preventDefault();finish(new Error(t('Could not export the encyclopedia')));};
  worker.onmessageerror=()=>finish(new Error(t('Could not export the encyclopedia')));
  try{worker.postMessage({project:snapshot,options,format,images,language:getLanguage()});}catch(error){finish(error);}
 });
}
