import {familyGenerations,orderCoupleMembers} from './genealogyFamilies';
import {connectionVisibleAt} from './relationshipTime';
import type {StoryDate} from './timeline';
import {parentConnections,availableRoles} from './entryRelations';
import type {EntryRelations} from './entryRelations';
import type {Worldbuilding} from './worldbuilding';

export function genealogyGraph(world:Worldbuilding,relations:EntryRelations,focusId:string,ancestors:number,descendants:number,showArchived=false,hideIsolated=false,at?:StoryDate,showEnded=false,memberIds?:string[]){
 if(!at)return buildGenealogyGraph(world,relations,focusId,ancestors,descendants,showArchived,hideIsolated,memberIds);
 const filtered=buildGenealogyGraph(world,{...relations,links:relations.links.filter(link=>connectionVisibleAt(link,at,showEnded))},focusId,ancestors,descendants,showArchived,hideIsolated,memberIds),layout=buildGenealogyGraph(world,relations,'',0,0,showArchived,hideIsolated);
 return {...filtered,manualBasePositions:Object.fromEntries(filtered.nodes.map(node=>[node.id,layout.manualBasePositions[node.id]??filtered.manualBasePositions[node.id]])),positions:Object.fromEntries(filtered.nodes.map(node=>[node.id,layout.positions[node.id]??filtered.positions[node.id]]))};
}
function buildGenealogyGraph(world:Worldbuilding,relations:EntryRelations,focusId:string,ancestors:number,descendants:number,showArchived:boolean,hideIsolated:boolean,memberIds?:string[]){
 const types=relations.types.filter(type=>type.genealogy&&!type.needsRoleReview),typeIds=new Set(types.map(type=>type.id));
 const participants=new Set(relations.links.filter(link=>typeIds.has(link.typeId)&&world.entries.some(entry=>entry.id===link.sourceId&&(showArchived||!entry.archived))&&world.entries.some(entry=>entry.id===link.targetId&&(showArchived||!entry.archived))).flatMap(link=>[link.sourceId,link.targetId]));
 const candidates=world.entries.filter(entry=>(showArchived||!entry.archived)&&(memberIds?.includes(entry.id)||participants.has(entry.id)||types.some(type=>availableRoles(type,entry).length>0))&&(!hideIsolated||memberIds?.includes(entry.id)||participants.has(entry.id)));
 const available=new Set(candidates.map(entry=>entry.id));
 const parents=parentConnections(relations).filter(edge=>available.has(edge.parentId)&&available.has(edge.childId));
 const partners=relations.links.filter(link=>types.some(type=>type.id===link.typeId&&['partner','formerPartner'].includes(type.genealogy?.kind??''))&&available.has(link.sourceId)&&available.has(link.targetId));
 // Sibling relationships are not transitive: two half-siblings can have unrelated siblings.
 const siblingPairs=new Map<string,{sourceId:string;targetId:string;explicit:boolean;parentIds:Set<string>}>();
 const pair=(a:string,b:string)=>JSON.stringify([a,b].sort());
 for(const link of relations.links)if(types.some(type=>type.id===link.typeId&&type.genealogy?.kind==='sibling')&&available.has(link.sourceId)&&available.has(link.targetId))siblingPairs.set(pair(link.sourceId,link.targetId),{sourceId:link.sourceId,targetId:link.targetId,explicit:true,parentIds:new Set()});
 const families=new Map<string,Set<string>>();for(const edge of parents){if(!families.has(edge.parentId))families.set(edge.parentId,new Set());families.get(edge.parentId)!.add(edge.childId);}
 for(const [parentId,children] of families){const ids=[...children];for(let i=0;i<ids.length;i++)for(let j=i+1;j<ids.length;j++){const key=pair(ids[i],ids[j]),existing=siblingPairs.get(key)??{sourceId:ids[i],targetId:ids[j],explicit:false,parentIds:new Set<string>()};existing.parentIds.add(parentId);siblingPairs.set(key,existing);}}
 const siblingEdges=[...siblingPairs.values()];
 const siblings=(id:string)=>{const ids=new Set(siblingEdges.flatMap(edge=>edge.sourceId===id?[edge.targetId]:edge.targetId===id?[edge.sourceId]:[]));return candidates.filter(node=>ids.has(node.id));};
 const care=relations.links.flatMap(link=>{const type=types.find(type=>type.id===link.typeId),meaning=type?.genealogy;if(!type||!meaning||!('parentRole' in meaning)||meaning.kind==='parent'||!available.has(link.sourceId)||!available.has(link.targetId))return [];return [{link,type,kind:meaning.kind,carerId:meaning.parentRole==='source'?link.sourceId:link.targetId,childId:meaning.parentRole==='source'?link.targetId:link.sourceId}];});
 const visible=new Set<string>();
 if(focusId&&available.has(focusId)){
  visible.add(focusId);
  for(const [depth,up] of [[ancestors,true],[descendants,false]] as const){let frontier=new Set([focusId]);for(let level=0;level<depth;level++){const next=new Set<string>();for(const edge of parents)if(frontier.has(up?edge.childId:edge.parentId))next.add(up?edge.parentId:edge.childId);for(const id of next)visible.add(id);frontier=next;}}
  // Partners and carers add direct context without expanding their ancestors or descendants.
  const family=new Set(visible);for(const link of [...partners,...siblingEdges,...care.map(edge=>edge.link)]){if(family.has(link.sourceId))visible.add(link.targetId);if(family.has(link.targetId))visible.add(link.sourceId);}
  // Keep the complete sibling group visible, even when only consecutive siblings
  // were connected. Visibility never creates transitive sibling relationships.
  const siblingAdjacency=new Map<string,Set<string>>();
  for(const link of siblingEdges){for(const [from,to] of [[link.sourceId,link.targetId],[link.targetId,link.sourceId]]){if(!siblingAdjacency.has(from))siblingAdjacency.set(from,new Set());siblingAdjacency.get(from)!.add(to);}}
  const pending=[...visible];for(let i=0;i<pending.length;i++)for(const id of siblingAdjacency.get(pending[i])??[])if(!visible.has(id)){visible.add(id);pending.push(id);}
 }else if(!focusId)for(const id of available)visible.add(id);
 if(memberIds){visible.clear();for(const id of memberIds)if(available.has(id))visible.add(id);}
 const nodes=candidates.filter(entry=>visible.has(entry.id)),edges=parents.filter(edge=>visible.has(edge.parentId)&&visible.has(edge.childId));
 const {generations,unit,hasCycle}=familyGenerations(candidates.map(node=>node.id),parents,partners,siblingEdges);
 // Lay out disconnected components separately; sharing a row never creates a link.
 const adjacency=new Map(candidates.map(node=>[node.id,new Set<string>()]));
 for(const link of [...parents.map(edge=>edge.link),...partners,...siblingEdges,...care.map(edge=>edge.link)]){adjacency.get(link.sourceId)?.add(link.targetId);adjacency.get(link.targetId)?.add(link.sourceId);}
 const components:string[][]=[],visited=new Set<string>();
 for(const node of [...candidates].sort((a,b)=>a.id.localeCompare(b.id))){if(visited.has(node.id))continue;const members=[node.id];visited.add(node.id);for(let i=0;i<members.length;i++)for(const id of adjacency.get(members[i])??[]){if(!visited.has(id)){visited.add(id);members.push(id);}}components.push(members);}
 function place(optimized:boolean){
 const positions:Record<string,{x:number;y:number}>={};let left=100;
 for(const members of components){const rows=new Map<number,string[]>();for(const id of members){const level=generations.get(id)!;rows.set(level,[...(rows.get(level)??[]),id]);}
 const width=Math.max(1,...Array.from(rows.values(),row=>row.length))*240;
 for(const [level,ids] of [...rows.entries()].sort(([a],[b])=>a-b)){
  const order=(id:string)=>{const placed=parents.filter(edge=>edge.childId===id&&positions[edge.parentId]).map(edge=>positions[edge.parentId].x);return placed.length?placed.reduce((a,b)=>a+b,0)/placed.length:Infinity;};
  const blocks=new Map<string,string[]>();for(const id of ids){const key=unit.get(id)!;blocks.set(key,[...(blocks.get(key)??[]),id]);}
 const blockOrder=(members:string[])=>{const values=members.map(order).filter(Number.isFinite);return values.length?values.reduce((a,b)=>a+b,0)/values.length:Infinity;};
 ids.splice(0,ids.length,...[...blocks.values()].sort((a,b)=>blockOrder(a)-blockOrder(b)||a[0].localeCompare(b[0])).flatMap(members=>optimized?orderCoupleMembers(members,partners):members.sort()));
  ids.forEach((id,index)=>positions[id]={x:left+width/2+(index-(ids.length-1)/2)*240,y:120+level*200});
 }
 left+=width+240;
 }
 return positions;
 }
 const positions=place(true),manualBasePositions=place(false);
 const visiblePositions=Object.fromEntries(Object.entries(positions).filter(([id])=>visible.has(id)));
 return {candidates,nodes,care:care.filter(edge=>visible.has(edge.carerId)&&visible.has(edge.childId)),parents:edges,partners:partners.filter(link=>visible.has(link.sourceId)&&visible.has(link.targetId)),positions:visiblePositions,manualBasePositions:Object.fromEntries(Object.entries(manualBasePositions).filter(([id])=>visible.has(id))),siblings,componentCount:components.filter(members=>members.some(id=>visible.has(id)&&participants.has(id))).length,isolatedCount:candidates.filter(node=>!participants.has(node.id)).length,siblingEdges:siblingEdges.filter(edge=>visible.has(edge.sourceId)&&visible.has(edge.targetId)&&(edge.explicit||![...edge.parentIds].some(id=>visible.has(id)))),hasCycle};
}
