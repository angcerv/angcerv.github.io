import {plainReferenceDocument,plainReferenceText,plainReferenceLimit,plainReferenceIndex} from './plainTextReferences';
import {EditorFormattingShortcuts,formattingShortcut,formattingAriaShortcut} from './editorFormatting';
import type {FormattingAction} from './editorFormatting';
import {focusDocumentFragment,applyFragmentRequest} from './decisionFragments';
import type {FragmentRequest} from './decisionFragments';
import {useContext} from 'react';
import {TextReferenceContext} from './textReferenceContext';
import {TextEntryLink,TextReferencePicker} from './TextReferenceUI';
import {EntryMentionNode} from './entryMentionNode';
import {TextSelection,NodeSelection} from '@tiptap/pm/state';
import {useEffect,useRef,useState} from 'react';
import {EditorContent,useEditor,useEditorState} from '@tiptap/react';
import type {Editor,JSONContent} from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import {Bold,Italic,Underline,List,Code,Link2,Unlink} from 'lucide-react';
import {longTextDocument,longTextMarkdown} from './longText';
import {t} from './i18n';

function renderNode(node:JSONContent,key:number):React.ReactNode{
 if(node.type==='entryMention'){let content:React.ReactNode=<TextEntryLink entryId={node.attrs?.entryId} label={node.attrs?.label??''}/>;for(const mark of node.marks??[]){if(mark.type==='bold')content=<strong>{content}</strong>;if(mark.type==='italic')content=<em>{content}</em>;if(mark.type==='underline')content=<u>{content}</u>;}return <span key={key}>{content}</span>;}
 if(node.type==='text'){
  let text:React.ReactNode=node.text;
  for(const mark of node.marks??[]){if(mark.type==='bold')text=<strong>{text}</strong>;if(mark.type==='italic')text=<em>{text}</em>;if(mark.type==='underline')text=<u>{text}</u>;}
  return <span key={key}>{text}</span>;
 }
 const children=(node.content??[]).map(renderNode);
 if(node.type==='hardBreak')return <br key={key}/>;
 if(node.type==='bulletList')return <ul key={key}>{children}</ul>;
 if(node.type==='listItem')return <li key={key}>{children}</li>;
 return <p key={key}>{children}</p>;
}
export function LongTextView({value}:{value:string}){return <div className="long-text-view">{longTextDocument(value).content?.map(renderNode)}</div>;}
// Empty padded contenteditable regions do not consistently acquire a text caret on click.
// Focus the real editor at its first text position without inserting content or scrolling.
export function focusEmptyLongText(editor:Editor|null,event:{button:number;preventDefault:()=>void}){
 if(event.button!==0||!editor||editor.isDestroyed||!editor.isEditable||!editor.isEmpty)return false;
 const view=editor.view;if(!view.dom.isConnected)return false;
 event.preventDefault();
 // Establish native focus first for WebKit, then synchronize the DOM text selection.
 view.dom.focus({preventScroll:true});
 view.dispatch(view.state.tr.setSelection(TextSelection.atStart(view.state.doc)));
 view.focus();return true;
}
export default function LongTextEditor({focusFragment,id,value,onChange,plain=false,maxLength,describedBy}:{plain?:boolean;maxLength?:number;describedBy?:string;focusFragment?:FragmentRequest;id:string;value:string;onChange:(value:string)=>void}){
 const context=useContext(TextReferenceContext),environment=useRef(context);environment.current=context;
 const [referencePicker,setReferencePicker]=useState(false),selection=useRef({from:0,to:0}),linkTrigger=useRef<HTMLButtonElement>(null);
 const [inputError,setInputError]=useState('');
 const [source,setSource]=useState(false),callback=useRef(onChange),last=useRef(value);callback.current=onChange;
 const editor=useEditor({immediatelyRender:false,extensions:[EditorFormattingShortcuts,EntryMentionNode,...(plain&&maxLength!==undefined?[plainReferenceLimit(maxLength,()=>setInputError(t('This field can contain up to {0} characters.',maxLength)))]:[]),StarterKit.configure({...(plain?{bold:false,italic:false,underline:false,bulletList:false,listItem:false,listKeymap:false}:{}),heading:false,blockquote:false,orderedList:false,code:false,codeBlock:false,strike:false,link:false,horizontalRule:false,trailingNode:false})],content:plain?plainReferenceDocument(value):longTextDocument(value),editorProps:{handleClick:(view,_pos,event)=>{const link=(event.target as HTMLElement)?.closest('[data-entry-reference]');const id=link?.getAttribute('data-entry-reference');if(id&&environment.current){const position=view.posAtDOM(link!,0);if(view.state.doc.nodeAt(position)?.type.name==='entryMention')view.dispatch(view.state.tr.setSelection(NodeSelection.create(view.state.doc,position)));environment.current.openEntry(id);return true;}return false;},handleKeyDown:(view,event)=>{if(event.key==='Enter'){const target=event.target as HTMLElement;const id=target?.closest?.('[data-entry-reference]')?.getAttribute('data-entry-reference');if(id&&environment.current){environment.current.openEntry(id);return true;}}if(event.altKey&&event.key==='Enter'){const node=view.state.selection.$from.nodeAfter;if(node?.type.name==='entryMention'&&environment.current){environment.current.openEntry(node.attrs.entryId);return true;}}return false;},attributes:{id,role:'textbox','aria-labelledby':`${id}-label`,'aria-multiline':'true',...(describedBy?{'aria-describedby':describedBy}:{}),spellcheck:'true'}},onUpdate:({editor})=>{const next=plain?plainReferenceText(editor.getJSON()):longTextMarkdown(editor.getJSON());setInputError('');last.current=next;callback.current(next);}});
 useEffect(()=>{if(editor&&focusFragment){setSource(false);applyFragmentRequest(focusFragment,()=>{const found=focusDocumentFragment(editor,focusFragment.fragment,plain?plainReferenceIndex(editor.getJSON()):undefined);if(!found)editor.view.dom.scrollIntoView({block:'center'});return true;});}},[editor,focusFragment]);
 useEffect(()=>{if(editor&&last.current!==value){last.current=value;editor.commands.setContent(plain?plainReferenceDocument(value):longTextDocument(value),{emitUpdate:false});}},[editor,value]);
 const state=useEditorState({editor,selector:({editor:e})=>({empty:e?.isEmpty,bold:e?.isActive('bold'),italic:e?.isActive('italic'),underline:e?.isActive('underline'),list:e?.isActive('bulletList'),reference:e?.isActive('entryMention')})});
 const actions=[{shortcut:'bold' as FormattingAction,label:t('Bold'),icon:Bold,active:state?.bold,run:()=>editor?.chain().focus().toggleBold().run()},{shortcut:'italic' as FormattingAction,label:t('Italic'),icon:Italic,active:state?.italic,run:()=>editor?.chain().focus().toggleItalic().run()},{shortcut:'underline' as FormattingAction,label:t('Underline'),icon:Underline,active:state?.underline,run:()=>editor?.chain().focus().toggleUnderline().run()},{shortcut:'bulletList' as FormattingAction,label:t('Bullet list'),icon:List,active:state?.list,run:()=>editor?.chain().focus().toggleBulletList().run()}];
 return <div className={`long-text-editor${plain?' long-text-editor-plain':''}`} data-empty={!!state?.empty}><div className="long-text-toolbar" role="group" aria-label={t(plain?'Linked entries':'Text formatting')}>{!plain&&actions.map(({label,icon:Icon,active,run,shortcut})=><button key={label} type="button" className="icon-button" title={`${label} (${formattingShortcut(shortcut)})`} aria-label={label} aria-keyshortcuts={formattingAriaShortcut(shortcut)} aria-pressed={!!active} disabled={source||!editor} onMouseDown={event=>event.preventDefault()} onClick={run}><Icon size={16}/></button>)}{context&&<><button ref={linkTrigger} type="button" className="icon-button" title={t('Link to an entry')} aria-label={t('Link to an entry')} aria-expanded={referencePicker} disabled={source||!editor} onMouseDown={e=>e.preventDefault()} onClick={()=>{if(editor){selection.current={from:editor.state.selection.from,to:editor.state.selection.to};setReferencePicker(!referencePicker);}}}><Link2 size={16}/></button><button type="button" className="icon-button" title={t('Remove reference')} aria-label={t('Remove reference')} disabled={source||!editor||!state?.reference} onMouseDown={e=>e.preventDefault()} onClick={()=>{if(editor){const node=editor.state.doc.nodeAt(editor.state.selection.from);if(node?.type.name==='entryMention')editor.chain().focus().insertContentAt({from:editor.state.selection.from,to:editor.state.selection.from+node.nodeSize},{type:'text',text:node.attrs.label}).run();}}}><Unlink size={16}/></button></>}{!plain&&<button type="button" className="icon-button long-text-source" title={t('Edit Markdown source')} aria-label={t('Edit Markdown source')} aria-pressed={source} onClick={()=>setSource(!source)}><Code size={16}/></button>}</div>{referencePicker&&<TextReferencePicker onClose={()=>{setReferencePicker(false);linkTrigger.current?.focus();}} onChoose={(entryId,title)=>{if(editor){const {from,to}=selection.current;const selected=editor.state.doc.nodeAt(from);const text=selected?.type.name==='entryMention'&&to-from===selected.nodeSize?selected.attrs.label:editor.state.doc.textBetween(from,to,' ',node=>node.type.name==='entryMention'?String(node.attrs.label):' ');const label=text.trim()?text:title||t('Untitled entry');editor.chain().focus().insertContentAt({from,to},{type:'entryMention',attrs:{entryId,label}}).run();}setReferencePicker(false);}}/>}{inputError&&<p className="prompt-error" role="alert">{inputError}</p>}{source?<textarea id={id} aria-labelledby={`${id}-label`} rows={6} value={value} onChange={event=>onChange(event.target.value)}/>:<EditorContent editor={editor} className="long-text-content" onPointerDownCapture={event=>focusEmptyLongText(editor,event)}/>}</div>;
}
