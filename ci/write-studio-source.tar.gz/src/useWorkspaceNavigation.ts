import {useCallback,useEffect,useLayoutEffect,useRef,useState} from 'react';
import type {RefObject} from 'react';
import type {Editor} from '@tiptap/react';
import type {Project} from './model';
import {activateWorkspaceMemory,worldWorkspacePane,cloneWorkspaceMemory,restoreWorkspaceMemory,captureWorkspacePosition,restoreWorkspacePosition,emptyWorkspaceHistory,workspaceRouteKey,workspaceRouteExists,recordWorkspaceVisit,stepWorkspaceHistory} from './workspaceNavigation';
import type {WorkspaceRoute,WorkspaceVisit,WorkspaceHistory,WorkspaceViewMemory} from './workspaceNavigation';
import {workspaceVisitLabel} from './workspaceVisitLabel';
import {prepareLoreNavigation} from './worldLore';
import {t} from './i18n';

type Options={project:Project|null;session:number;ready:boolean;busy:boolean;
 route:Omit<WorkspaceRoute,'worldPane'|'worldFocusId'>;sceneId?:string;
 sceneEditorRef:RefObject<Editor|null>;onRestoreRoute:(route:WorkspaceRoute)=>void;
};
/** Coordinate visit memory/history and bounded restoration; never snapshot project content.
 * The shell maps restored route IDs to its own screen selections. */
export function useWorkspaceNavigation({project,session,ready,busy,route,sceneId,sceneEditorRef,onRestoreRoute}:Options){
  const activeView=route.view;
  const viewMemory=useRef<WorkspaceViewMemory>({values:{}}),navigationSession=useRef(session),navigationHistory=useRef<WorkspaceHistory>(emptyWorkspaceHistory()),navigationCurrent=useRef<WorkspaceVisit|undefined>(undefined),restoringNavigation=useRef(false),navigationRestore=useRef<WorkspaceVisit|undefined>(undefined),navigationRoute=useRef<WorkspaceRoute|undefined>(undefined),navigationScrollFrame=useRef<number|undefined>(undefined);
  const navigationFrames=useRef(new Set<number>());
  const [navigationEpoch,setNavigationEpoch]=useState(0),[navigationRevision,setNavigationRevision]=useState(0);
  const refreshWorkspaceNavigation=useCallback(()=>setNavigationRevision(value=>value+1),[]);
  if(navigationSession.current!==session){cancelNavigationFrames();navigationSession.current=session;viewMemory.current.values={};viewMemory.current.restoring=false;navigationHistory.current=emptyWorkspaceHistory();navigationCurrent.current=undefined;navigationRestore.current=undefined;restoringNavigation.current=false;}
  activateWorkspaceMemory(viewMemory.current);
  function cancelNavigationFrames(){
    for(const frame of navigationFrames.current)cancelAnimationFrame(frame);
    navigationFrames.current.clear();navigationScrollFrame.current=undefined;
  }
  function scheduleNavigationFrame(callback:()=>void){
    const frame=requestAnimationFrame(()=>{navigationFrames.current.delete(frame);callback();});
    navigationFrames.current.add(frame);return frame;
  }
  useEffect(()=>()=>cancelNavigationFrames(),[]);

  function navigationBackLabel(current:Project){const visits=navigationHistory.current.past.filter(visit=>workspaceRouteExists(current,visit.route));return visits.length?t('Back to {0}',workspaceVisitLabel(current,visits[visits.length-1].route)):t('Workspace navigation');}
  function currentWorkspaceRoute():WorkspaceRoute{return {...route,worldPane:worldWorkspacePane(viewMemory.current.values,route.worldSection),worldFocusId:typeof viewMemory.current.values['world.networkFocusId']==='string'?viewMemory.current.values['world.networkFocusId'] as string:''};}
  navigationRoute.current=currentWorkspaceRoute();
  function captureWorkspaceVisit():WorkspaceVisit{
    const route=currentWorkspaceRoute(),position=captureWorkspacePosition(document.getElementById(`${activeView}-view`));
    const editor=sceneEditorRef.current;
    if(activeView==='manuscript'&&sceneId&&editor&&!editor.isDestroyed)position.editor={sceneId,from:editor.state.selection.from,to:editor.state.selection.to};
    return {route,memory:cloneWorkspaceMemory(viewMemory.current),position};
  }
  function captureNavigation(){
    if(!project||restoringNavigation.current||document.querySelector('dialog[open]'))return;
    const next=captureWorkspaceVisit();if(navigationCurrent.current&&workspaceRouteKey(next.route)===workspaceRouteKey(navigationCurrent.current.route))navigationCurrent.current=next;
  }
  function captureNavigationScroll(){if(navigationScrollFrame.current!==undefined||restoringNavigation.current)return;navigationScrollFrame.current=scheduleNavigationFrame(()=>{navigationScrollFrame.current=undefined;captureNavigation();});}
  const panelReady=useCallback(()=>setNavigationRevision(value=>value+1),[]);
  useLayoutEffect(()=>{
    if(!project||document.getElementById(`${activeView}-view`)?.querySelector('[data-panel-loading]'))return;
    const previous=navigationCurrent.current,route=currentWorkspaceRoute();
    const next=previous&&workspaceRouteKey(previous.route)===workspaceRouteKey(route)&&!restoringNavigation.current?{...previous,route,memory:cloneWorkspaceMemory(viewMemory.current)}:captureWorkspaceVisit();
    if(!restoringNavigation.current&&previous&&workspaceRouteKey(previous.route)!==workspaceRouteKey(next.route)){
      navigationHistory.current=recordWorkspaceVisit(navigationHistory.current,previous);setNavigationRevision(value=>value+1);
    }
    navigationCurrent.current=next;
    const restore=navigationRestore.current;if(!restore)return;navigationRestore.current=undefined;
    const restoreSession=session,expected=workspaceRouteKey(restore.route);let frame=0,cancelled=false;
    const apply=()=>{
      if(cancelled||navigationSession.current!==restoreSession||!navigationRoute.current||workspaceRouteKey(navigationRoute.current)!==expected){restoringNavigation.current=false;viewMemory.current.restoring=false;return;}
      const root=document.getElementById(`${restore.route.view}-view`);
      if(root)restoreWorkspacePosition(root,restore.position,frame===7);
      const saved=restore.position.editor,editor=sceneEditorRef.current;
      if(frame===7&&saved&&editor&&!editor.isDestroyed&&navigationRoute.current.selectedId===saved.sceneId){const size=editor.state.doc.content.size;editor.commands.setTextSelection({from:Math.max(1,Math.min(size,saved.from)),to:Math.max(1,Math.min(size,saved.to))});}
      if(++frame<8)scheduleNavigationFrame(apply);else {restoringNavigation.current=false;viewMemory.current.restoring=false;navigationCurrent.current=captureWorkspaceVisit();setNavigationRevision(value=>value+1);}
    };
    scheduleNavigationFrame(apply);
    // Subsequent ordinary renders must not cancel this bounded restoration pass.
    return ()=>{if(navigationSession.current!==restoreSession)cancelled=true;};
  });
  function navigateWorkspace(direction:'back'|'forward'){
    if(!project||busy||!ready||restoringNavigation.current||document.querySelector('dialog[open],[aria-modal="true"]'))return;
    if(!prepareLoreNavigation(document.getElementById(`${activeView}-view`)))return;
    const result=stepWorkspaceHistory(navigationHistory.current,captureWorkspaceVisit(),direction,project);navigationHistory.current=result.history;
    if(!result.visit){setNavigationRevision(value=>value+1);return;}
    restoreWorkspaceVisit(result.visit);
  }
  function restoreWorkspaceVisit(visit:WorkspaceVisit){
    if(!project)return;
    cancelNavigationFrames();
    const route={...visit.route};if(route.view==='manuscript'&&['chapter','planning'].includes(route.manuscriptMode)&&!project.chapters.some(chapter=>chapter.id===route.selectedId||chapter.scenes.some(scene=>scene.id===route.selectedId)))route.selectedId=route.chapterId;restoringNavigation.current=true;viewMemory.current.restoring=true;navigationRestore.current=visit;navigationCurrent.current=visit;
    restoreWorkspaceMemory(viewMemory.current,visit.memory);
    onRestoreRoute(route);setNavigationEpoch(value=>value+1);
  }
  useEffect(()=>{
    const key=(event:KeyboardEvent)=>{
      const target=event.target as HTMLElement|null,editing=!!target?.closest('input,textarea,[contenteditable=true]');
      const direction=event.metaKey&&!event.ctrlKey&&!event.altKey&&(event.key==='['||event.key===']')?(event.key==='['?'back':'forward'):event.altKey&&!event.metaKey&&!event.ctrlKey&&!editing&&(event.key==='ArrowLeft'||event.key==='ArrowRight')?(event.key==='ArrowLeft'?'back':'forward'):undefined;
      if(direction&&!event.shiftKey&&!event.defaultPrevented&&!event.isComposing&&!event.repeat){event.preventDefault();navigateWorkspace(direction);}
    };
    window.addEventListener('keydown',key);return()=>window.removeEventListener('keydown',key);
  });
  return {viewMemory,navigationHistory,navigationCurrent,restoringNavigation,navigationEpoch,setNavigationEpoch,
   navigationRevision,refreshWorkspaceNavigation,panelReady,navigationBackLabel,captureWorkspaceVisit,
   captureNavigation,captureNavigationScroll,navigateWorkspace,restoreWorkspaceVisit};
}
