import { t } from './i18n';
import Dropdown from './Dropdown';
import { mapColors } from './maps';
import type { ProjectPlots } from './plotThreads';
import { linkPlotScene } from './plotThreads';
export default function ScenePlotsPanel({plots,sceneId,onChange,onOpen}:{plots:ProjectPlots;sceneId:string;onChange:(plots:ProjectPlots)=>void;onOpen:(id:string)=>void}){
 const linked=plots.threads.filter(p=>p.beats.some(b=>b.sceneId===sceneId));
 return <section className="scene-plots-panel"><h3>{t('Plots')}</h3>{linked.map(p=><button key={p.id} type="button" onClick={()=>onOpen(p.id)}><span className="plot-color-dot" style={{background:mapColors[p.color]}}/>{p.title||t('Untitled plot')}</button>)}{!linked.length&&<p className="world-hint">{t('This scene is not linked to a plot yet.')}</p>}<label htmlFor="scene-link-plot">{t('Link to a plot')}</label><Dropdown id="scene-link-plot" value="" placeholder={t('Choose a plot')} options={plots.threads.filter(p=>!linked.includes(p)).map(p=>({value:p.id,label:p.title||t('Untitled plot')}))} onChange={id=>onChange(linkPlotScene(plots,id,sceneId,true))}/><button type="button" onClick={()=>onOpen('')}>{t('Manage plots')}</button></section>;
}
