import type { Worldbuilding } from './worldbuilding';
import type { Scene, IgnoredMention, ResolvedMention } from './model';
import { fromMarkdown } from './model';
export type Mention = { from:number; to:number; entryIds:string[]; label:string; resolved?:boolean };
type MentionNames=Map<string,{name:string;ids:string[]}>;
// Project snapshots are immutable. Canonical catalogues survive unrelated field edits;
// bounded catalogues avoid retaining every historical set of names.
const worldNames=new WeakMap<Worldbuilding,MentionNames>();
const catalogues=new Map<string,MentionNames>();
export function mentionNames(world:Worldbuilding):MentionNames {
 const known=worldNames.get(world);if(known)return known;
 const signature=JSON.stringify(world.entries.filter(entry=>!entry.archived).map(entry=>[entry.id,entry.title,entry.linkAliases??[]]));
 const reused=catalogues.get(signature);
 if(reused){catalogues.delete(signature);catalogues.set(signature,reused);worldNames.set(world,reused);return reused;}
 const names=new Map<string,{name:string;ids:string[]}>();
 for(const entry of world.entries){
  if(entry.archived)continue;
  for(const value of [entry.title,...(entry.linkAliases??[])]){
   const name=value.trim();if(!name)continue;
   const key=name.normalize('NFC'),existing=names.get(key);
   if(existing){if(!existing.ids.includes(entry.id))existing.ids.push(entry.id);}else names.set(key,{name,ids:[entry.id]});
  }
 }
 worldNames.set(world,names);catalogues.set(signature,names);
 if(catalogues.size>8)catalogues.delete(catalogues.keys().next().value!);
 return names;
}
const word=/[\p{L}\p{N}\p{M}_]/u;
export function findMentions(text:string,names:ReturnType<typeof mentionNames>):Mention[]{
 const matches:Mention[]=[];
 for(const {name,ids} of names.values()){
  const pattern=new RegExp(name.replace(/[.*+?^${}()|[\]\\]/g,'\\$&'),'gu');
  for(const match of text.matchAll(pattern)){
   const from=match.index!,to=from+match[0].length;
   const previous=from>=2?text.codePointAt(from-2):undefined;
   const before=from?text.slice(from-(previous!==undefined&&previous>0xffff?2:1),from):'';
   const next=text.codePointAt(to),after=next===undefined?'':String.fromCodePoint(next);
   if((before&&word.test(before))||(after&&word.test(after)))continue;
   matches.push({from,to,entryIds:ids,label:match[0]});
  }
 }
 matches.sort((a,b)=>a.from-b.from||b.to-a.to);
 const result:Mention[]=[];
 for(const match of matches)if(!result.length||match.from>=result[result.length-1].to)result.push(match);
 return result;
}

export function isIgnoredMention(mention:{from:number;to:number;label:string},ignored:IgnoredMention[]):boolean {
 return ignored.some(item=>item.from===mention.from&&item.to===mention.to&&item.text===mention.label);
}
export function paragraphMentions(text:string,offset:number,names:ReturnType<typeof mentionNames>,resolved:ResolvedMention[]=[]):Mention[]{
 const selected=resolved.filter(item=>item.from>=offset+1&&item.to<=offset+1+text.length&&item.to>item.from&&text.slice(item.from-offset-1,item.to-offset-1)===item.text).map(item=>({from:item.from,to:item.to,label:item.text,entryIds:[item.entryId],resolved:true}));
 const automatic=findMentions(text,names).map(item=>({...item,from:offset+1+item.from,to:offset+1+item.to})).filter(item=>!selected.some(choice=>choice.from<item.to&&choice.to>item.from));
 return [...automatic,...selected].sort((a,b)=>a.from-b.from);
}
type SceneParagraph={text:string;offset:number};
// Keep parsing shared across detection, snippets and exclusions. Weak keys do not
// retain old scenes; the content guard also handles callers editing a scene in place.
const parsedScenes=new WeakMap<Scene,{content:string;paragraphs:SceneParagraph[]}>();
function sceneParagraphs(scene:Scene):SceneParagraph[]{
 const previous=parsedScenes.get(scene);if(previous?.content===scene.content)return previous.paragraphs;
 let offset=0;
 const paragraphs=(fromMarkdown(scene.content).content??[]).map(paragraph=>{
  const text=(paragraph.content??[]).map(node=>node.type==='hardBreak'?'\n':node.text??'').join(''),item={text,offset};
  offset+=text.length+2;return item;
 });
 parsedScenes.set(scene,{content:scene.content,paragraphs});return paragraphs;
}
type CachedScene={content:string;decisions:string;all:Mention[];visible:Mention[]};
// Live immutable scenes retain their result without enlarging the bounded ID cache.
const liveSceneCaches=new WeakMap<Scene,{names:MentionNames;value:CachedScene}>();
const sceneCaches=new WeakMap<MentionNames,Map<string,CachedScene>>();
export function sceneMentions(scene:Scene,world:Worldbuilding,includeIgnored=false):Mention[]{
 const names=mentionNames(world);
 let cache=sceneCaches.get(names);if(!cache){cache=new Map();sceneCaches.set(names,cache);}
 const decisions=JSON.stringify([scene.resolvedMentions??[],scene.ignoredMentions??[]]);
 const live=liveSceneCaches.get(scene);
 const previous=live?.names===names?live.value:cache.get(scene.id);
 if(previous?.content===scene.content&&previous.decisions===decisions){
  liveSceneCaches.set(scene,{names,value:previous});
  return includeIgnored?previous.all:previous.visible;
 }
 const mentions:Mention[]=[];
 for(const {text,offset} of sceneParagraphs(scene)){
  for(const absolute of paragraphMentions(text,offset,names,scene.resolvedMentions)){
   mentions.push(absolute);
  }
 }
 const visible=mentions.filter(mention=>!isIgnoredMention(mention,scene.ignoredMentions??[]));
 const value={content:scene.content,decisions,all:mentions,visible};
 liveSceneCaches.set(scene,{names,value});
 cache.delete(scene.id);cache.set(scene.id,value);
 if(cache.size>2000)cache.delete(cache.keys().next().value!);
 return includeIgnored?mentions:visible;
}
export function nextMention(mentions:Mention[],previous?:{from:number;to:number}):Mention|undefined {
 return mentions.find(mention=>!previous||mention.from>previous.from)??mentions[0];
}
export function mentionContext(scene:Scene,from:number,to:number):string {
 for(const {text,offset} of sceneParagraphs(scene)){
  if(from>=offset+1&&to<=offset+text.length+1){const start=Math.max(0,from-offset-1-40),end=Math.min(text.length,to-offset-1+40);return `${start?'…':''}${text.slice(start,end)}${end<text.length?'…':''}`;}
 }
 return '';
}
export function sceneExcludedMentions(scene:Scene):Mention[]{
 const excluded:Mention[]=[];
 for(const {text,offset} of sceneParagraphs(scene)){
  for(const item of scene.ignoredMentions??[])if(item.from>=offset+1&&item.to<=offset+1+text.length&&item.to>item.from&&text.slice(item.from-offset-1,item.to-offset-1)===item.text)excluded.push({from:item.from,to:item.to,label:item.text,entryIds:[]});
 }
 return excluded;
}
export function sceneReferenceSummary(scene:Scene,world:Worldbuilding){
 const mentions=sceneMentions(scene,world),counts=new Map<string,number>();
 for(const mention of mentions)if(mention.entryIds.length===1)counts.set(mention.entryIds[0],(counts.get(mention.entryIds[0])??0)+1);
 const ids=[...new Set([...(scene.entryIds??[]),...counts.keys()])];
 return {references:ids.map(id=>({id,manual:!!scene.entryIds?.includes(id),count:counts.get(id)??0})),mentionCount:mentions.filter(mention=>mention.entryIds.length===1).length,ambiguous:mentions.filter(mention=>mention.entryIds.length>1),excluded:sceneExcludedMentions(scene)};
}
