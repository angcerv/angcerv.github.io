import {statusTone} from './semanticStatus';
import {Lightbulb,ArrowUpRight} from 'lucide-react';
import {t,buttonLabel} from './i18n';
import {relatedIdeas,ideaStatusLabels,ideaCategory,ideaCategoryLabels} from './worldIdeas';
import type {WorldIdea} from './worldIdeas';
export default function RelatedIdeas({embedded=false,ideas=[],kind,id,onOpen}:{embedded?:boolean;ideas?:WorldIdea[];kind:'entry'|'scene'|'plot';id:string;onOpen?:(id:string)=>void}){
 const items=relatedIdeas(ideas,kind,id);
 if(!items.length)return null;
 return <section className="related-ideas" aria-label={t('Ideas and decisions')}>{!embedded&&<h3><Lightbulb size={16}/>{t('Ideas and decisions')}<span>{items.length}</span></h3>}{items.map(idea=><button key={idea.id} type="button" disabled={!onOpen} onClick={()=>onOpen?.(idea.id)}><span><strong>{idea.title}</strong><small>{buttonLabel(ideaCategoryLabels[ideaCategory(idea)])} · <span className="semantic-status" data-semantic-tone={statusTone('idea',idea.status)}>{buttonLabel(ideaStatusLabels[idea.status])}</span></small></span><ArrowUpRight size={15}/></button>)}</section>;
}
