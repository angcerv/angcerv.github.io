import type {Book,Project} from './model';

// Chapter IDs retain their global identity: lore, timeline and references stay shared.
export function chapterBook(project:Project,chapterId:string):Book|undefined {
 return project.books?.find(book=>book.chapterIds.includes(chapterId));
}
export function selectionBook(project:Project,selectedId:string):Book|undefined {
 const chapter=project.chapters.find(c=>c.id===selectedId||c.scenes.some(s=>s.id===selectedId));
 return chapter?chapterBook(project,chapter.id):undefined;
}
export function bookChapters(project:Project,bookId:string){
 if(!project.books?.length)return project.chapters;
 const ids=new Set(project.books.find(book=>book.id===bookId)?.chapterIds??[]);
 return project.chapters.filter(chapter=>ids.has(chapter.id));
}
export function bookProject(project:Project,bookId:string):Project {
 if(!bookId||!project.books?.length)return project;
 return {...project,chapters:bookChapters(project,bookId)};
}
// Scoped planners may reorder/delete their own chapters, never another book's data.
export function mergeBookProject(project:Project,edited:Project,bookId:string):Project {
 if(!project.books?.length||!bookId)return edited;
 const owned=new Set(bookChapters(project,bookId).map(c=>c.id));
 const chapters=[...project.chapters];let index=0;
 const merged=chapters.flatMap(chapter=>owned.has(chapter.id)?(edited.chapters[index]?[edited.chapters[index++]]:[]):[chapter]);
 merged.push(...edited.chapters.slice(index));
 return {...project,plots:edited.plots,chapters:merged,books:project.books.map(book=>book.id===bookId?{...book,chapterIds:edited.chapters.map(c=>c.id)}:book)};
}
export function addBook(project:Project,title:string,id:string,firstBookId:string):Project {
 if(!title.trim())return project;
 const books=project.books?.length?project.books:[{id:firstBookId,title:project.title,chapterIds:project.chapters.map(c=>c.id)}];
 return {...project,books:[...books,{id,title:title.trim(),chapterIds:[]}]};
}
/** Move atomically, in manuscript order, appending after the destination chapters. */
export function transferChaptersBook(project:Project,chapterIds:string[],bookId:string):Project {
 const target=project.books?.find(book=>book.id===bookId),requested=new Set(chapterIds);
 if(!target||!requested.size||chapterIds.some(id=>!project.chapters.some(chapter=>chapter.id===id)||!chapterBook(project,id)))return project;
 const moving=project.chapters.filter(chapter=>requested.has(chapter.id)&&!target.chapterIds.includes(chapter.id));
 if(!moving.length)return project;
 const ids=new Set(moving.map(chapter=>chapter.id)),remaining=project.chapters.filter(chapter=>!ids.has(chapter.id));
 let insert=remaining.length;
 for(let i=remaining.length-1;i>=0;i--)if(target.chapterIds.includes(remaining[i].id)){insert=i+1;break;}
 return {...project,chapters:[...remaining.slice(0,insert),...moving,...remaining.slice(insert)],books:project.books!.map(book=>({...book,chapterIds:[...book.chapterIds.filter(id=>!ids.has(id)),...(book.id===bookId?moving.map(chapter=>chapter.id):[])]}))};
}
export function transferChapterBook(project:Project,chapterId:string,bookId:string):Project {
 return transferChaptersBook(project,[chapterId],bookId);
}

export type BookOrganization={books:Book[];chapterOrder:string[]};
export function bookOrganization(project:Project,firstBookId:string):BookOrganization {
 return {books:project.books?.length?project.books.map(book=>({...book,chapterIds:[...book.chapterIds]})):[{id:firstBookId,title:project.title,chapterIds:project.chapters.map(chapter=>chapter.id)}],chapterOrder:project.chapters.map(chapter=>chapter.id)};
}
/** Apply only organization metadata to the latest project, retaining every content object. */
export function applyBookOrganization(project:Project,draft:BookOrganization):Project|undefined {
 const ids=new Set(project.chapters.map(chapter=>chapter.id)),assigned=draft.books.flatMap(book=>book.chapterIds);
 if(!draft.books.length||new Set(draft.books.map(book=>book.id)).size!==draft.books.length||draft.books.some(book=>!book.id||!book.title.trim()||book.title.length>300))return;
 if(draft.chapterOrder.length!==ids.size||new Set(draft.chapterOrder).size!==ids.size||draft.chapterOrder.some(id=>!ids.has(id)))return;
 if(assigned.length!==ids.size||new Set(assigned).size!==ids.size||assigned.some(id=>!ids.has(id)))return;
 const byId=new Map(project.chapters.map(chapter=>[chapter.id,chapter]));
 const books=draft.books.map(book=>{const own=new Set(book.chapterIds);return {...book,title:book.title.trim(),chapterIds:draft.chapterOrder.filter(id=>own.has(id))};});
 return {...project,books,chapters:books.flatMap(book=>book.chapterIds.map(id=>byId.get(id)!))};
}
export function bookSelection(project:Project,bookId:string,remembered?:string):string {
 const chapters=bookChapters(project,bookId);
 return remembered&&chapters.some(chapter=>chapter.id===remembered||chapter.scenes.some(scene=>scene.id===remembered))?remembered:chapters[0]?.scenes[0]?.id??chapters[0]?.id??'';
}
export function bookSelectionAfterOrganization(project:Project,selectedId:string,bookId:string){
 const owner=selectionBook(project,selectedId)?.id,target=owner??project.books?.find(book=>book.id===bookId)?.id??project.books?.[0]?.id??'';
 return {bookId:target,selectedId:owner?selectedId:bookSelection(project,target)};
}
export function pruneBookChapters(project:Project):Project {
 if(!project.books?.length)return project;
 const ids=new Set(project.chapters.map(c=>c.id));
 if(project.books.every(b=>b.chapterIds.every(id=>ids.has(id))))return project;
 return {...project,books:project.books.map(book=>({...book,chapterIds:book.chapterIds.filter(id=>ids.has(id))}))};
}
export function removeEmptyBook(project:Project,bookId:string):Project {
 const book=project.books?.find(b=>b.id===bookId);
 if(!book||book.chapterIds.length||project.books!.length===1)return project;
 const books=project.books!.filter(b=>b.id!==bookId);
 return {...project,books:books.length?books:undefined};
}
export function moveBook(project:Project,bookId:string,direction:-1|1):Project {
 const books=[...(project.books??[])],i=books.findIndex(b=>b.id===bookId),j=i+direction;
 if(i<0||j<0||j>=books.length)return project;
 [books[i],books[j]]=[books[j],books[i]];return {...project,books};
}
export function bookChapterLabel(project:Project,chapterId:string):string {
 const chapter=project.chapters.find(c=>c.id===chapterId),book=chapterBook(project,chapterId);
 return [book?.title,chapter?.title].filter(Boolean).join(' · ');
}

// Book order groups the manuscript; chapter order inside a book remains the flat order.
export function orderBookChapters(project:Project):Project {
 if(!project.books?.length)return project;
 const assigned=new Set(project.books.flatMap(book=>book.chapterIds));
 return {...project,chapters:[...project.books.flatMap(book=>bookChapters(project,book.id)),...project.chapters.filter(chapter=>!assigned.has(chapter.id))]};
}
export function exportBookProject(project:Project,bookId:string):Project {
 const scoped=bookProject(orderBookChapters(project),bookId),book=project.books?.find(book=>book.id===bookId);
 if(!book)return scoped;
 const scenes=new Set(scoped.chapters.flatMap(chapter=>chapter.scenes.map(scene=>scene.id)));
 // Out-of-book beats are outside this export, not deleted scene references.
 const plots=project.plots?{...project.plots,threads:project.plots.threads.map(plot=>({...plot,beats:plot.beats.filter(beat=>scenes.has(beat.sceneId))})),arcs:project.plots.arcs?.map(arc=>({...arc,beats:arc.beats.filter(beat=>scenes.has(beat.sceneId))}))}:undefined;
 return {...scoped,title:book.title,plots};
}
