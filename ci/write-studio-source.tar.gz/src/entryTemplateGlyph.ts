import { FileText, MapPin, Package, UserRound } from 'lucide-react';
import type { Template } from './worldbuilding';
/** Custom template names stay free-form; unknown types get a neutral document glyph. */
export function entryTemplateGlyph(template?:Template){
 const name=(template?.title??'').normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase();
 if(/personaj|character|persona|people|person\b/.test(name)||template?.fields.some(field=>field.isBirthDate))return UserRound;
 if(/lugar|location|place|ciudad|city|region|planeta|planet|territor/.test(name))return MapPin;
 if(/objeto|object|item|artefact|artifact|arma|weapon/.test(name))return Package;
 return FileText;
}
