import type { CSSProperties } from 'react';
export type FocusPreferences={width:'narrow'|'balanced'|'wide';font:'serif'|'sans';fontSize:number;lineHeight:number};
export const defaultFocusPreferences:FocusPreferences={width:'balanced',font:'serif',fontSize:19,lineHeight:1.8};
export const focusPreferencesKey='write-studio.focus-preferences';
export function parseFocusPreferences(raw:string|null):FocusPreferences {
 try{const value:unknown=JSON.parse(raw ?? 'null');if(!value || typeof value!=='object')return {...defaultFocusPreferences};
 const data=value as Record<string,unknown>;
 return {width:data.width==='narrow' || data.width==='balanced' || data.width==='wide' ? data.width : 'balanced',font:data.font==='sans' ? 'sans':'serif',fontSize:typeof data.fontSize==='number' && Number.isFinite(data.fontSize) ? Math.round(Math.max(16,Math.min(28,data.fontSize))) : 19,lineHeight:typeof data.lineHeight==='number' && Number.isFinite(data.lineHeight) ? Math.round(Math.max(1.4,Math.min(2.2,data.lineHeight))*10)/10 : 1.8};
 }catch{return {...defaultFocusPreferences};}
}
export function focusWritingStyle(preferences:FocusPreferences):CSSProperties {
 return {'--focus-width':`${{narrow:560,balanced:700,wide:840}[preferences.width]}px`,'--focus-font-size':`${preferences.fontSize}px`,'--focus-line-height':preferences.lineHeight,'--focus-font':preferences.font==='serif' ? 'Georgia, "Times New Roman", serif' : '-apple-system, BlinkMacSystemFont, "Segoe UI", sans-serif'} as CSSProperties;
}
export function isFocusShortcut(event:{key:string;metaKey:boolean;ctrlKey:boolean;shiftKey:boolean;altKey:boolean}):boolean{return (event.metaKey||event.ctrlKey) && event.shiftKey && !event.altKey && event.key==='Enter';}
