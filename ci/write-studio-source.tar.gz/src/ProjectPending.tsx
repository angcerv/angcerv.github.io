import {pendingSectionItems,pendingSectionKinds,pendingSectionKind} from './pendingSections';
import type {PendingSection} from './pendingSections';
import {fragmentSources,sourceForFragment,locateFragment} from './decisionFragments';
import type {DecisionFragment} from './decisionFragments';
import {statusTone} from './semanticStatus';
import {useWorkspaceState} from './useWorkspaceState';
import {LongTextView} from './LongTextEditor';
import WorldIdeaEditor from './WorldIdeaEditor';
import {ideaStatusLabels,ideaUpdates} from './worldIdeas';
import type {WorldIdea} from './worldIdeas';
import { useEffect,useMemo,useRef, useState,useSyncExternalStore } from 'react';
import { ArrowUpRight, Check, MessageSquare, Link2, FilePenLine, PenLine, Search, X, ListTodo, Lightbulb, Pencil } from 'lucide-react';
import {t,useLanguage,buttonLabel} from './i18n';
import type { Project } from './model';
import type { PendingOrder, PendingItem, PendingKind } from './pendingItems';
import { projectPendingItems, filterPendingItems, sortPendingItems } from './pendingItems';
import {subscribeContinuityReview,continuityReviewRevision} from './narrativeContinuity';
import Dropdown from './Dropdown';
import EntrySection from './EntrySection';
import MentionChoiceDialog from './MentionChoiceDialog';
import { emptyWorld } from './worldbuilding';
export default function ProjectPending({active=true,onReviewContinuity,onOpenFragment,project,onOpen,onResolveComment,onResolveMention,onSaveIdea,onOpenEntry,onOpenScene,onOpenPlot,ideaId,onCloseIdea}:{active?:boolean;onReviewContinuity?:()=>void;onOpenFragment?:(fragment:DecisionFragment)=>void;ideaId?:string;onCloseIdea?:()=>void;onOpenScene?:(id:string)=>void;onOpenPlot?:(id:string)=>void;onSaveIdea?:(idea:WorldIdea)=>void;onOpenEntry?:(id:string)=>void;project:Project;onOpen:(item:PendingItem)=>void;onResolveComment:(sceneId:string,commentId:string)=>void;onResolveMention:(sceneId:string,range:{from:number;to:number},entryId:string)=>void}){
 const language=useLanguage(),[kind,setKind]=useWorkspaceState<PendingKind|'all'>('pending.kind','all'),[chapter,setChapter]=useWorkspaceState('pending.chapter',''),[query,setQuery]=useWorkspaceState('pending.query',''),[choice,setChoice]=useState<string|null>(null),[editingIdea,setEditingIdea]=useState<WorldIdea|null>(null),[ideaStatus,setIdeaStatus]=useWorkspaceState('pending.ideaStatus','active');
 const [section,setSection]=useWorkspaceState<PendingSection>('pending.section','review');
 const [sectionFilters,setSectionFilters]=useWorkspaceState<Record<string,{kind:PendingKind|'all';chapter:string;query:string;status:string}>>('pending.sectionFilters',{});
 useEffect(()=>{if(active&&ideaId)setEditingIdea(project.worldIdeas?.find(idea=>idea.id===ideaId)??null);},[active,ideaId]);
 const reviewRevision=useSyncExternalStore(subscribeContinuityReview,continuityReviewRevision,continuityReviewRevision);
 const allItems=useMemo(()=>projectPendingItems(project,section),[project,section,language,reviewRevision]);
 const items=useMemo(()=>pendingSectionItems(allItems,section),[allItems,section]);
 const activeKind=pendingSectionKind(section,kind);
 const reviewItems=section==='review'&&activeKind==='all'?items.filter(item=>item.kind!=='develop'):items;
 function changeSection(next:PendingSection){
  if(next===section)return;setSectionFilters({...sectionFilters,[section]:{kind,chapter,query,status:ideaStatus}});
  const saved=sectionFilters[next];setKind(saved?.kind??'all');setChapter(saved?.chapter??'');setQuery(saved?.query??'');setIdeaStatus(saved?.status??'active');setSection(next);
 }
 const [orders,setOrders]=useWorkspaceState<Partial<Record<PendingSection,PendingOrder>>>('pending.orders',{});
 const order=orders[section]??'default';
 const setOrder=(value:PendingOrder)=>setOrders(previous=>({...previous,[section]:value}));
 const fragmentSourceList=useMemo(()=>(project.worldIdeas??[]).some(idea=>idea.fragments?.length)?fragmentSources(project.worldbuilding??emptyWorld,project.chapters,project.plots):[],[project]);
 const chapterId=chapter==='__project'||project.chapters.some(c=>c.id===chapter)?chapter:'';
 const scoped=filterPendingItems(items,'all',chapterId,query,ideaStatus),results=sortPendingItems(filterPendingItems(reviewItems,activeKind,chapterId,query,ideaStatus),order,language);
 const container=useRef<HTMLDivElement>(null),pendingFocus=useRef<string|null>(null),[announcement,setAnnouncement]=useState('');
 const hasOpenItems=filterPendingItems(reviewItems,'all','','','active').length>0;
 useEffect(()=>{
  if(!active||pendingFocus.current===null)return;
  const target=[...(container.current?.querySelectorAll<HTMLElement>('[data-pending-id]')??[])].find(node=>node.dataset.pendingId===pendingFocus.current);
  (target?.querySelector<HTMLElement>('button')??container.current?.querySelector<HTMLElement>('.pending-categories button[aria-pressed=true]'))?.focus();
  pendingFocus.current=null;
 },[active,project]);
 function clearFilters(){setKind('all');setChapter('');setQuery('');setIdeaStatus('active');}
 const labels={all:t(section==='ideas'?'All ideas':'All review items'),comment:t('Review comments'),continuity:t('Continuity warnings'),review:t('Scenes to review'),develop:t('Scenes to develop'),idea:t('Worldbuilding ideas'),narrative:t('Narrative ideas')};
 const icons={comment:MessageSquare,continuity:Link2,review:FilePenLine,develop:PenLine,idea:Lightbulb,narrative:PenLine};
 const filtered=activeKind!=='all'||!!chapterId||!!query.trim()||(section==='ideas'&&ideaStatus!=='active');
 const filterCount=Number(!!chapterId)+Number(section==='ideas'&&ideaStatus!=='active');
 const currentChoice=items.find(item=>item.id===choice)?.issue;
 return <div ref={container} className="project-pending"><header className="ui-workspace-heading"><div><h1><ListTodo size={23}/>{t('Pending')}</h1></div><div className="pending-header-actions">{section==='review'&&onReviewContinuity&&<button type="button" className="quick-action quick-action-text" onClick={onReviewContinuity}><Link2 size={16}/>{t('Continuity review')}</button>}{onSaveIdea&&<button type="button" className="primary-button" onClick={()=>setEditingIdea({id:crypto.randomUUID(),title:'',description:'',status:'idea',entryIds:[],category:kind==='narrative'?'narrative':'worldbuilding'})}><Lightbulb size={16}/>{t('New idea or decision')}</button>}</div></header>
 <nav className="workspace-tabs workspace-tabs-internal module-navigation" aria-label={t('Pending sections')} role="tablist" onKeyDown={event=>{const next=event.key==='ArrowRight'||event.key==='ArrowLeft'?(section==='ideas'?'review':'ideas'):event.key==='Home'?'ideas':event.key==='End'?'review':null;if(next){event.preventDefault();changeSection(next);event.currentTarget.querySelector<HTMLButtonElement>(`[data-section="${next}"]`)?.focus();}}}><button type="button" role="tab" data-section="ideas" tabIndex={section==='ideas'?0:-1} aria-selected={section==='ideas'} onClick={()=>changeSection('ideas')}>{t('Ideas and decisions')}</button><button type="button" role="tab" data-section="review" tabIndex={section==='review'?0:-1} aria-selected={section==='review'} onClick={()=>changeSection('review')}>{t('Review')}</button></nav>
 <div className="pending-controls"><label className="pending-search"><Search size={16}/><span className="visually-hidden">{t('Search pending items')}</span><input type="search" value={query} onChange={e=>setQuery(e.target.value)} placeholder={t('Search pending items')}/></label><div className="ui-form-field"><label className="visually-hidden" htmlFor="pending-order">{t('Sort by')}</label><Dropdown id="pending-order" value={order} onChange={value=>setOrder(value as PendingOrder)} options={[{value:'default',label:t('Default order')},{value:'title-asc',label:t('Title (A–Z)')},{value:'title-desc',label:t('Title (Z–A)')},{value:'created-newest',label:t('Creation date (newest first)')},{value:'created-oldest',label:t('Creation date (oldest first)')},{value:'updated-newest',label:t('Last edited (newest first)')},{value:'updated-oldest',label:t('Last edited (oldest first)')}]}/></div></div>
 <EntrySection id="pending-filters" title={t('Filters')} variant="compact" keepMounted defaultOpen={filterCount>0} count={filterCount||undefined}><div className="pending-filter-fields"><div className="ui-form-field"><label htmlFor="pending-chapter">{t('Chapter')}</label><Dropdown id="pending-chapter" value={chapterId} onChange={setChapter} options={[{value:'',label:t('All chapters')},...project.chapters.map((c,i)=>({value:c.id,label:`${i+1}. ${c.title||t('Untitled chapter')}`})),{value:'__project',label:t('World, maps and timeline')}]} /></div>{section==='ideas'&&<div className="ui-form-field"><label htmlFor="pending-idea-status">{t('Idea status')}</label><Dropdown id="pending-idea-status" value={ideaStatus??'active'} onChange={value=>setIdeaStatus(value)} options={[{value:'active',label:t('Open ideas')},{value:'all',label:t('All idea statuses')},...Object.entries(ideaStatusLabels).map(([value,label])=>({value,label:buttonLabel(label),tone:statusTone('idea',value)}))]}/></div>}</div></EntrySection>
 {filterCount>0&&<div className="pending-active-filters">{chapterId&&<button type="button" className="quick-action quick-action-text" aria-label={t('Remove chapter filter')} onClick={()=>setChapter('')}>{chapterId==='__project'?t('World, maps and timeline'):project.chapters.find(c=>c.id===chapterId)?.title}<X size={14}/></button>}{section==='ideas'&&ideaStatus!=='active'&&<button type="button" className="quick-action quick-action-text" aria-label={t('Remove status filter')} onClick={()=>setIdeaStatus('active')}>{ideaStatus==='all'?t('All idea statuses'):t(ideaStatusLabels[ideaStatus as keyof typeof ideaStatusLabels])}<X size={14}/></button>}</div>}
 <div className="pending-categories" role="group" aria-label={t('Pending categories')}>{pendingSectionKinds(section).map(category=><button type="button" key={category} aria-pressed={activeKind===category} onClick={()=>setKind(category)}>{labels[category]}<span className="compact-count">{category==='all'?(section==='review'?scoped.filter(item=>item.kind!=='develop').length:scoped.length):scoped.filter(item=>item.kind===category).length}</span></button>)}</div>
 <p className="visually-hidden" role="status">{announcement}</p><div className="pending-result-summary"><p className="pending-results-count" role="status">{t(results.length===1?'{0} result':'{0} results',results.length)}</p>{filtered&&<button type="button" className="quick-action quick-action-text" onClick={clearFilters}>{t('Clear filters')}</button>}</div>
 <div className="pending-results">{results.map(item=>{const Icon=icons[item.kind];return <article key={item.id} data-pending-id={item.id}><div className="pending-item-icon semantic-icon" data-semantic-tone={item.idea?statusTone('idea',item.idea.status):item.issue?statusTone('continuity',item.issue.kind):item.kind==='review'?'review':item.kind==='comment'?'attention':'neutral'}><Icon size={18}/></div><div className="pending-item-body"><small>{labels[item.kind]}{item.idea&&<> · <span className="semantic-status" data-semantic-tone={statusTone('idea',item.idea.status)}>{t(ideaStatusLabels[item.idea.status])}</span></>}{!item.idea&&<> · {item.context}</>}</small><PendingItemText item={item}/>{(item.createdAt||item.updatedAt)&&<small className="pending-item-dates">{item.createdAt&&<>{t('Created')}: <PendingDate value={item.createdAt} language={language}/></>}{item.createdAt&&item.updatedAt&&' · '}{item.updatedAt&&<>{t('Last edited')}: <PendingDate value={item.updatedAt} language={language}/></>}</small>}{onOpenFragment&&!!item.idea?.fragments?.length&&<div className="pending-fragment-links">{item.idea.fragments.map(fragment=>{const source=sourceForFragment(fragmentSourceList,fragment),found=source&&locateFragment(source.text,fragment);return <button type="button" className="quick-action quick-action-text" key={fragment.id} disabled={!source} title={fragment.quote} onClick={()=>onOpenFragment(fragment)}><ArrowUpRight size={15}/><span><strong>{source?.title??t('Source unavailable')}</strong><span>{fragment.quote.length>160?fragment.quote.slice(0,160)+'…':fragment.quote}</span>{source&&!found&&<small>{t('Fragment changed or ambiguous')}</small>}</span></button>;})}</div>}{item.idea?.status==='decided'&&ideaUpdates(item.idea).length>0&&<p>{t('{0} of {1} updates reviewed',ideaUpdates(item.idea).filter(update=>update.done).length,ideaUpdates(item.idea).length)}</p>}{item.comment?.detached&&<small>{t('The original fragment was deleted. This comment has been kept.')}</small>}</div><div className="pending-item-actions">{item.comment&&item.sceneId&&<button type="button" className="quick-action resolve-action" title={t('Resolve comment')} aria-label={t('Resolve comment')} onClick={()=>{const index=results.indexOf(item);pendingFocus.current=results[index+1]?.id??results[index-1]?.id??'';onResolveComment(item.sceneId!,item.comment!.id);setAnnouncement(t('Comment resolved'));}}><Check size={16}/></button>}{item.issue?.candidateIds&&<button type="button" className="quick-action quick-action-text" onClick={()=>setChoice(item.id)}>{buttonLabel('Choose entry…')}</button>}<button id={`pending-open-${item.id}`} type="button" className="quick-action" aria-label={item.idea?t('Edit idea: {0}',item.title):t('Open pending item: {0}',item.title)} title={item.idea?t('Edit idea'):t('Open in context')} onClick={()=>item.idea?setEditingIdea(item.idea):onOpen(item)}>{item.idea?<Pencil size={16}/>:<ArrowUpRight size={16}/>}</button></div></article>;})}</div>
 {!results.length&&<div className="pending-empty ui-empty-state"><Check size={28}/><h2>{hasOpenItems||kind!=='all'||chapterId||query.trim()||ideaStatus!=='active'?t('No pending items match these filters.'):t('No pending items. You are up to date.')}</h2>{!hasOpenItems&&items.some(item=>item.idea)&&<button type="button" onClick={()=>{clearFilters();setIdeaStatus('all');}}>{t('View all ideas')}</button>}</div>}
 {active&&editingIdea&&onSaveIdea&&<WorldIdeaEditor onOpenFragment={onOpenFragment} key={editingIdea.id} idea={editingIdea} world={project.worldbuilding??emptyWorld} chapters={project.chapters} plots={project.plots} onOpenScene={onOpenScene} onOpenPlot={onOpenPlot} onSave={onSaveIdea} onClose={()=>{setEditingIdea(null);onCloseIdea?.();}} onOpenEntry={onOpenEntry}/>}
 {active&&currentChoice?.sceneId&&currentChoice.range&&currentChoice.candidateIds&&<MentionChoiceDialog world={project.worldbuilding??emptyWorld} ids={currentChoice.candidateIds} label={currentChoice.title} onClose={()=>setChoice(null)} onChoose={id=>{onResolveMention(currentChoice.sceneId!,currentChoice.range!,id);setChoice(null);}}/>}
 </div>;
}

function PendingItemText({item}:{item:PendingItem}){
 const [expanded,setExpanded]=useWorkspaceState(`pending.expanded.${item.id}`,false);
 const long=!!item.relatedContext||item.title.length>100||item.detail.length>180||[...item.title.matchAll(/\n/g),...item.detail.matchAll(/\n/g)].length>=2;
 const full=item.idea?<>{item.relatedContext&&<p className="pending-item-context">{item.relatedContext}</p>}<LongTextView value={item.idea.description}/>{item.idea.decision&&<section className="pending-decision"><strong>{t('Decision taken')}</strong><LongTextView value={item.idea.decision}/></section>}</>:<p>{item.detail}</p>;
 return <div className={`pending-item-text${long?' is-collapsible':''}${expanded?' is-expanded':''}`}>
  <h2>{item.title}</h2>
  {(item.detail||item.relatedContext)&&(long?<><div className="pending-text-preview" aria-hidden={expanded} inert={expanded}><div><p>{item.detail}</p></div></div><div className="pending-text-full" aria-hidden={!expanded} inert={!expanded}><div>{full}</div></div></>:full)}
  {long&&<button type="button" className="quick-action quick-action-text pending-expand" aria-expanded={expanded} onClick={()=>setExpanded(!expanded)}>{expanded?t('Show less'):t('Show more')}</button>}
 </div>;
}

function PendingDate({value,language}:{value?:string;language:string}){
 if(!value||!Number.isFinite(Date.parse(value)))return <>{t('Date unavailable')}</>;
 return <time dateTime={value}>{new Intl.DateTimeFormat(language,{dateStyle:'medium',timeStyle:'short'}).format(new Date(value))}</time>;
}
