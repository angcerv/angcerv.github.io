import {connectionVisibleAt} from './relationshipTime';
import {formatStoryDate} from './timeline';
import type {StoryDate} from './timeline';
import type {EntryRelations,EntryRelation} from './entryRelations';
import {normalizeEntryRelations} from './entryRelations';
import type {Worldbuilding,Entry} from './worldbuilding';
import type {Chapter} from './model';
import type {ProjectPlots} from './plotThreads';
import type {Timeline} from './timeline';
import {timelineEventEntryIds} from './timeline';
import {sceneMentions} from './mentionDetection';
export type GraphPoint={x:number;y:number};
export type GraphCamera=GraphPoint&{zoom:number};
export type GraphSettings={at?:StoryDate;showEnded?:boolean;focusId:string;depth:1|2;templateId:string;typeId:string;plotId:string;showArchived:boolean;showLabels:boolean};
export type RelationGraphView={id:string;name:string;settings:GraphSettings;positions:Record<string,GraphPoint>;camera:GraphCamera};
export const defaultGraphSettings:GraphSettings={focusId:'',depth:1,templateId:'',typeId:'',plotId:'',showArchived:false,showLabels:true};
export const defaultGraphCamera:GraphCamera={x:0,y:0,zoom:1};
export function plotEntryIds(world:Worldbuilding,chapters:Chapter[],plots:ProjectPlots|undefined,timeline:Timeline|undefined,plotId:string):Set<string>{
 const plot=plots?.threads.find(plot=>plot.id===plotId),ids=new Set<string>();if(!plot)return ids;
 const scenes=new Set(plot.beats.map(beat=>beat.sceneId));
 for(const scene of chapters.flatMap(chapter=>chapter.scenes).filter(scene=>scenes.has(scene.id))){
  for(const id of scene.entryIds??[])ids.add(id);
  for(const mention of sceneMentions(scene,world))if(mention.entryIds.length===1)ids.add(mention.entryIds[0]);
 }
 for(const event of timeline?.events??[])if(event.plotIds?.includes(plotId)||event.sceneIds.some(id=>scenes.has(id)))for(const id of timelineEventEntryIds(event))ids.add(id);
 return ids;
}
export function relationGraph(world:Worldbuilding,input:EntryRelations,settings:GraphSettings,context:{chapters?:Chapter[];plots?:ProjectPlots;timeline?:Timeline}={}){
 const relations=normalizeEntryRelations(input),plotIds=settings.plotId?plotEntryIds(world,context.chapters??[],context.plots,context.timeline,settings.plotId):undefined;
 let nodes=world.entries.filter(entry=>(settings.showArchived||!entry.archived)&&(!settings.templateId||entry.templateId===settings.templateId)&&(!plotIds||plotIds.has(entry.id)));
 const ids=new Set(nodes.map(entry=>entry.id)),typeIds=new Set(relations.types.map(type=>type.id));
 let links=relations.links.filter(link=>connectionVisibleAt(link,settings.at,settings.showEnded)&&(!settings.typeId||link.typeId===settings.typeId)&&typeIds.has(link.typeId)&&ids.has(link.sourceId)&&ids.has(link.targetId));
 if(settings.typeId){const connected=new Set(links.flatMap(link=>[link.sourceId,link.targetId]));nodes=nodes.filter(entry=>connected.has(entry.id));}
 if(settings.focusId){
  const visible=new Set<string>(nodes.some(entry=>entry.id===settings.focusId)?[settings.focusId]:[]);let frontier=[...visible];
  for(let depth=0;depth<settings.depth;depth++){
   const next=new Set<string>();for(const link of links){if(frontier.includes(link.sourceId)&&!visible.has(link.targetId))next.add(link.targetId);if(frontier.includes(link.targetId)&&!visible.has(link.sourceId))next.add(link.sourceId);}
   frontier=[...next];for(const id of frontier)visible.add(id);
  }
  nodes=nodes.filter(entry=>visible.has(entry.id));links=links.filter(link=>visible.has(link.sourceId)&&visible.has(link.targetId));
 }
 const missing=relations.links.filter(link=>!world.entries.some(entry=>entry.id===link.sourceId)||!world.entries.some(entry=>entry.id===link.targetId)).length;
 return {nodes,links,missing};
}
/** Deterministic compact components; saved/manual coordinates always win. */
export function graphPositions(nodes:Entry[],focusId:string,saved:Record<string,GraphPoint>={},links:EntryRelation[]=[]):Record<string,GraphPoint>{
 const sorted=[...nodes].sort((a,b)=>a.id.localeCompare(b.id)),ids=new Set(sorted.map(node=>node.id));
 const adjacent=new Map(sorted.map(node=>[node.id,new Set<string>()]));
 for(const link of links)if(ids.has(link.sourceId)&&ids.has(link.targetId)){adjacent.get(link.sourceId)!.add(link.targetId);adjacent.get(link.targetId)!.add(link.sourceId);}
 const visited=new Set<string>(),groups:string[][]=[];
 const starts=[...sorted].sort((a,b)=>(a.id===focusId?-1:b.id===focusId?1:adjacent.get(b.id)!.size-adjacent.get(a.id)!.size||a.id.localeCompare(b.id)));
 for(const node of starts){if(visited.has(node.id))continue;const group=[node.id];visited.add(node.id);for(let i=0;i<group.length;i++)for(const id of [...adjacent.get(group[i])!].sort())if(!visited.has(id)){visited.add(id);group.push(id);}groups.push(group);}
 // Pack disconnected components as bounded blocks rather than ever-growing rings.
 const columns=Math.max(1,Math.ceil(Math.sqrt(Math.max(1,nodes.length)*.65))),result:Record<string,GraphPoint>={};
 let col=0,row=0,rowHeight=0;
 const isolated=groups.filter(group=>group.length===1).flat();
 const packed=[...groups.filter(group=>group.length>1),...(isolated.length?[isolated]:[])];
 for(const group of packed){const width=Math.min(columns,Math.max(1,Math.ceil(Math.sqrt(group.length)))),height=Math.ceil(group.length/width);
  if(col+width>columns){col=0;row+=rowHeight+1;rowHeight=0;}
  group.forEach((id,i)=>{result[id]=saved[id]??{x:700+(col+i%width)*260,y:450+(row+Math.floor(i/width))*130};});
  col+=width+1;rowHeight=Math.max(rowHeight,height);
 }
 return result;
}
/** First entry favours reading; overview remains an explicit fit action. */
export function readableGraphCamera(positions:Record<string,GraphPoint>,focusId='',viewport?:{width:number;height:number},toolbarHeight=44):GraphCamera{
 const scale=viewport?Math.min(viewport.width/1400,viewport.height/900):1;
 const minimum=Math.min(3,1/Math.max(.01,scale));
 const inset=graphTopInset(viewport,toolbarHeight),fit=fitGraph(positions,inset);if(fit.zoom>=minimum)return fit;
 const point=positions[focusId]??Object.values(positions)[0];
 return point?{zoom:minimum,x:(focusId?700:220)-point.x*minimum,y:Math.max(focusId?450:180,inset+32*minimum+16)-point.y*minimum}:fit;
}

/** Reserve the actual floating toolbar height in SVG coordinates. */
export function graphTopInset(viewport?:{width:number;height:number},toolbarHeight=44){
 if(!viewport)return 96;
 const scale=Math.min(viewport.width/1400,viewport.height/900);if(scale<=0)return 96;
 return Math.max(0,Math.min(450,(toolbarHeight+16-(viewport.height-900*scale)/2)/scale));
}
export function fitGraph(positions:Record<string,GraphPoint>,topInset=96):GraphCamera{
 const points=Object.values(positions);if(!points.length)return {...defaultGraphCamera};
 const minX=Math.min(...points.map(p=>p.x))-110,maxX=Math.max(...points.map(p=>p.x))+110,minY=Math.min(...points.map(p=>p.y))-70,maxY=Math.max(...points.map(p=>p.y))+70;
 const zoom=Math.max(.15,Math.min(2,1400/(maxX-minX),(900-topInset)/(maxY-minY)));
 return {x:700-(minX+maxX)/2*zoom,y:(900+topInset)/2-(minY+maxY)/2*zoom,zoom};
}
export function graphCanvasPoint(clientX:number,clientY:number,rect:{left:number;top:number;width:number;height:number}):GraphPoint|null{
 const scale=Math.min(rect.width/1400,rect.height/900);if(!scale)return null;
 return {x:(clientX-rect.left-(rect.width-1400*scale)/2)/scale,y:(clientY-rect.top-(rect.height-900*scale)/2)/scale};
}
export function zoomGraph(camera:GraphCamera,zoom:number,anchor:GraphPoint={x:700,y:450}):GraphCamera{
 const next=Math.max(.15,Math.min(3,zoom)),ratio=next/camera.zoom;return {zoom:next,x:anchor.x-(anchor.x-camera.x)*ratio,y:anchor.y-(anchor.y-camera.y)*ratio};
}
export function graphEdge(link:EntryRelation,links:EntryRelation[],positions:Record<string,GraphPoint>){
 const source=positions[link.sourceId],target=positions[link.targetId];
 const siblings=links.filter(other=>[other.sourceId,other.targetId].sort().join(':')===[link.sourceId,link.targetId].sort().join(':')).sort((a,b)=>a.id.localeCompare(b.id));
 const offset=(siblings.findIndex(other=>other.id===link.id)-(siblings.length-1)/2)*54;
 const length=Math.max(1,Math.hypot(target.x-source.x,target.y-source.y)),direction=link.sourceId<link.targetId?1:-1;
 const control={x:(source.x+target.x)/2-(target.y-source.y)/length*offset*direction,y:(source.y+target.y)/2+(target.x-source.x)/length*offset*direction};
 return {path:`M ${source.x} ${source.y} Q ${control.x} ${control.y} ${target.x} ${target.y}`,label:{x:(source.x+target.x+2*control.x)/4,y:(source.y+target.y+2*control.y)/4}};
}
export function saveGraphView(input:EntryRelations,view:RelationGraphView):EntryRelations{
 const relations=normalizeEntryRelations(input);
 const views=relations.views??[],copy=structuredClone(view);return {...relations,schemaVersion:view.settings.at?Math.max(7,relations.schemaVersion) as EntryRelations['schemaVersion']:relations.schemaVersion>=4?relations.schemaVersion:3,views:views.some(other=>other.id===view.id)?views.map(other=>other.id===view.id?copy:other):[...views,copy]};
}

export function graphViewChanged(view:RelationGraphView,settings:GraphSettings,positions:Record<string,GraphPoint>,camera:GraphCamera){
 return [...new Set([...Object.keys(view.settings),...Object.keys(settings)])].filter(key=>key!=='at'&&key!=='showEnded').some(key=>view.settings[key as keyof GraphSettings]!==settings[key as keyof GraphSettings])||formatStoryDate(view.settings.at)!==formatStoryDate(settings.at)||!!view.settings.showEnded!==!!settings.showEnded||view.camera.x!==camera.x||view.camera.y!==camera.y||view.camera.zoom!==camera.zoom||Object.keys(view.positions).length!==Object.keys(positions).length||Object.entries(view.positions).some(([id,point])=>point.x!==positions[id]?.x||point.y!==positions[id]?.y);
}

/** Pan only as far as needed to reveal a selected node beside the detail overlay. */
export function revealGraphPoint(camera:GraphCamera,point:GraphPoint,rect:{width:number;height:number},compact=false,center=false):GraphCamera{
 const scale=Math.min(rect.width/1400,rect.height/900);if(!scale)return camera;
 const width=compact?rect.width:Math.max(1,rect.width-Math.min(320,rect.width-8)),height=compact?rect.height/2:rect.height;
 const offsetX=(rect.width-1400*scale)/2,offsetY=(rect.height-900*scale)/2;
 const x=offsetX+(camera.x+point.x*camera.zoom)*scale,y=offsetY+(camera.y+point.y*camera.zoom)*scale;
 const marginX=Math.min(100*camera.zoom*scale+12,width/2),marginY=Math.min(32*camera.zoom*scale+12,height/2);
 const targetX=center?width/2:Math.max(marginX,Math.min(width-marginX,x)),targetY=center?height/2:Math.max(marginY,Math.min(height-marginY,y));
 return targetX===x&&targetY===y?camera:{...camera,x:camera.x+(targetX-x)/scale,y:camera.y+(targetY-y)/scale};
}
