const key='write-studio.mobile-active-project';
const views=['home','manuscript','worldbuilding','timeline','maps','pending','plots','arcs','canvas'] as const;
export type ResumeView=typeof views[number];
export type ProjectResume={projectId:string;path:string;selectedId:string;view:ResumeView};
export function readProjectResume():ProjectResume|null{
 try{
  const value=JSON.parse(localStorage.getItem(key)??'null');
  if(!value||typeof value.projectId!=='string'||!value.projectId||typeof value.path!=='string'||!value.path||typeof value.selectedId!=='string'||!views.includes(value.view))return null;
  return {projectId:value.projectId,path:value.path,selectedId:value.selectedId,view:value.view};
 }catch{return null;}
}
export function rememberProjectResume(value:ProjectResume){
 try{localStorage.setItem(key,JSON.stringify({projectId:value.projectId,path:value.path,selectedId:value.selectedId,view:value.view}));}catch{/* Optional device-local navigation memory. */}
}
export function clearProjectResume(){try{localStorage.removeItem(key);}catch{/* Optional navigation memory. */}}
