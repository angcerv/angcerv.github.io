import type {Project} from './model';
import type {ContinuityIssue} from './continuity';
import {eventEntryAges} from './ages';
import {daysInMonth,eventDateLabel} from './timeline';
import type {StoryDate,TimelineEvent} from './timeline';
import {t} from './i18n';

// Bounds preserve partial-date uncertainty and astronomical years, including zero.
const bound=(date:StoryDate,last=false)=>date.year*372+((date.month??(last?12:1))-1)*31+(date.day??(last?daysInMonth(date.year,date.month??12):1));
export function reviewNarrativeContinuity(project:Project):ContinuityIssue[]{
 const issues:ContinuityIssue[]=[],events=project.timeline?.events??[];
 for(const event of events){
  for(const {entry,age} of eventEntryAges(project.worldbuilding,event))if(age.kind==='beforeBirth'){
   issues.push({id:`birth:${event.id}:${entry.id}`,kind:'age',title:t('Event before {0} was born',entry.title),context:event.title,excerpt:t('The entire event predates the earliest possible birth date. A linked entry may be background context rather than a participant.'),eventId:event.id,entryId:entry.id});
  }
 }
 const datedByScene=new Map<string,TimelineEvent[]>();
 for(const event of events)if(event.start)for(const id of event.sceneIds){const list=datedByScene.get(id)??[];list.push(event);datedByScene.set(id,list);}
 const scenes=project.chapters.flatMap(chapter=>chapter.scenes.map(scene=>({scene,chapter})));
 // Compare adjacent manuscript scenes only. Missing dates break the comparison;
 // overlapping ranges are not evidence of a reversed sequence.
 for(let i=1;i<scenes.length;i++){
  const before=scenes[i-1],after=scenes[i],left=datedByScene.get(before.scene.id),right=datedByScene.get(after.scene.id);
  if(!left?.length||!right?.length)continue;
  const earliestBefore=Math.min(...left.map(event=>bound(event.start!))),latestAfter=Math.max(...right.map(event=>bound(event.end??event.start!,true)));
  if(latestAfter>=earliestBefore)continue;
  issues.push({id:`sequence:${before.scene.id}:${after.scene.id}`,kind:'chronology',title:t('The next scene takes place earlier'),context:`${after.chapter.title} / ${after.scene.title}`,excerpt:t('“{0}” ({1}) precedes “{2}” ({3}) in the manuscript. This may be an intentional flashback.',before.scene.title,left.map(eventDateLabel).join('; '),after.scene.title,right.map(eventDateLabel).join('; ')),sceneId:after.scene.id,relatedSceneIds:[before.scene.id],eventId:right[0].id});
 }
 return issues;
}

// Review decisions are local to this project and computer, separate from the
// manuscript. Store source snapshots so edited evidence automatically resurfaces.
export function continuityEvidence(project:Project,issue:ContinuityIssue):string{
 const sceneIds=new Set([issue.sceneId,...(issue.relatedSceneIds??[])]),entryIds=new Set([issue.entryId,...(issue.candidateIds??[])]);
 const events=(project.timeline?.events??[]).filter(event=>event.id===issue.eventId||event.sceneIds.some(id=>sceneIds.has(id)));
 const entries=project.worldbuilding?.entries.filter(entry=>entryIds.has(entry.id));
 const templates=project.worldbuilding?.templates.filter(template=>entries?.some(entry=>entry.templateId===template.id));
 const source=JSON.stringify([issue.id,project.chapters.flatMap(chapter=>chapter.scenes.filter(scene=>sceneIds.has(scene.id))),entries,templates,events,project.maps?.maps.filter(map=>map.id===issue.mapId)]);
 let a=2166136261,b=5381;for(let i=0;i<source.length;i++){const code=source.charCodeAt(i);a=Math.imul(a^code,16777619);b=Math.imul(b,33)^code;}
 return `v1:${source.length}:${a>>>0}:${b>>>0}`;
}
const storageKey=(id:string)=>`write-studio.continuity.dismissed.${id}`;
export function loadContinuityDismissals(id:string):Record<string,string>{
 try{const value=JSON.parse(localStorage.getItem(storageKey(id))??'{}');if(!value||typeof value!=='object'||Array.isArray(value))return {};return Object.fromEntries(Object.entries(value).filter(([key,value])=>key.length<500&&typeof value==='string').slice(-5000)) as Record<string,string>;}catch{return {};}
}
const listeners=new Set<()=>void>();
let revision=0;
export const subscribeContinuityReview=(listener:()=>void)=>{listeners.add(listener);return()=>{listeners.delete(listener);};};
export const continuityReviewRevision=()=>revision;
export function saveContinuityDismissals(id:string,value:Record<string,string>){
 try{const serialized=JSON.stringify(value);if(localStorage.getItem(storageKey(id))===serialized)return;localStorage.setItem(storageKey(id),serialized);}catch{/* Keep decisions usable in this session if storage is unavailable. */}
 revision++;listeners.forEach(listener=>listener());
}
