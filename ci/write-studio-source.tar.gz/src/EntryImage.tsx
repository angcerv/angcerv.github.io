import {focusDialog} from './dialogFocus';
import { t } from './i18n';
import type { ReactNode } from 'react';
import { useEffect, useRef, useState } from 'react';
import { ImageOff, Image as ImageIcon, X } from 'lucide-react';
import { readEntryImage } from './entryImages';
type ImageProps={projectPath?:string;projectId?:string;imageId?:string;title:string};
function useImage({projectPath,projectId,imageId}:ImageProps,thumbnail:boolean,active=true) {
 const key=JSON.stringify([projectPath,projectId,imageId,thumbnail]);
 const [state,setState]=useState({key:'',url:'',error:''});
 useEffect(()=>{
  if(!active){setState({key:'',url:'',error:''});return;}
  if(!projectPath || !projectId || !imageId)return;
  let cancelled=false,url='';
  void readEntryImage(projectPath,projectId,imageId,thumbnail).then(blob=>{if(cancelled)return;url=URL.createObjectURL(blob);setState({key,url,error:''});}).catch(error=>{if(!cancelled)setState({key,url:'',error:String(error)});});
  return()=>{cancelled=true;if(url)URL.revokeObjectURL(url);};
 },[key,active]);
 return active && state.key===key ? state : {key,url:'',error:''};
}
export function EntryThumbnail({fallback,...props}:ImageProps&{fallback?:ReactNode}) {
 const ref=useRef<HTMLSpanElement>(null),[visible,setVisible]=useState(false);
 useEffect(()=>{const element=ref.current;if(!element || !props.imageId)return;const observer=new IntersectionObserver(items=>setVisible(items.some(item=>item.isIntersecting)),{rootMargin:'150px'});observer.observe(element);return()=>observer.disconnect();},[props.imageId]);
 const image=useImage(props,true,visible);
 return <span ref={ref} className="entry-thumbnail" aria-hidden="true">{image.url ? <img src={image.url} alt="" loading="lazy"/> : image.error ? <ImageOff size={17}/> : fallback??<ImageIcon size={17}/>}</span>;
}
function ImageViewer({onClose,...props}:ImageProps & {onClose:()=>void}) {
 const ref=useRef<HTMLDialogElement>(null),image=useImage(props,false);
 useEffect(()=>{const previous=document.activeElement as HTMLElement|null,dialog=ref.current;dialog?.showModal();focusDialog(dialog);return()=>{dialog?.close();if(previous?.isConnected)previous.focus();};},[]);
 return <dialog ref={ref} className="entry-image-viewer" aria-label={t("Image of {0}", props.title)} onCancel={event=>{event.preventDefault();onClose();}}><div className="entry-image-viewer-heading"><h2>{props.title}</h2><button title={t("Close image")} type="button" className="icon-button ui-close-button" aria-label={t("Close image")} onClick={onClose}><X size={18}/></button></div>{image.url ? <img src={image.url} alt={props.title}/> : <p role={image.error ? 'alert' : 'status'}>{image.error || t("Loading image…")}</p>}</dialog>;
}
export function EntryPortrait({editorial=false,lazy=false,...props}:ImageProps&{editorial?:boolean;lazy?:boolean}) {
 const visibilityRef=useRef<HTMLButtonElement>(null),[visible,setVisible]=useState(!lazy);
 useEffect(()=>{
  if(!lazy)return;
  if(typeof IntersectionObserver==='undefined'){setVisible(true);return;}
  const element=visibilityRef.current;if(!element)return;
  const observer=new IntersectionObserver(items=>{if(items.some(item=>item.isIntersecting)){setVisible(true);observer.disconnect();}},{rootMargin:'150px'});observer.observe(element);return()=>observer.disconnect();
 },[lazy,props.imageId]);
 const image=useImage(props,!editorial,!lazy||visible),[viewing,setViewing]=useState(false),[orientation,setOrientation]=useState('portrait');
 useEffect(()=>setViewing(false),[props.imageId]);
 if(!props.imageId)return null;
 return <><button type="button" ref={visibilityRef} className={`entry-portrait${editorial?' editorial-portrait':''}`} data-orientation={orientation} aria-label={t("Enlarge image of {0}", props.title)} title={t("Enlarge image")} onClick={()=>setViewing(true)}>{image.url ? <img src={image.url} alt={props.title} onLoad={event=>{const image=event.currentTarget;setOrientation(image.naturalWidth>image.naturalHeight*1.25?'landscape':image.naturalHeight>image.naturalWidth*1.25?'portrait':'square');}}/> : image.error ? <ImageOff size={24}/> : <ImageIcon size={24}/>}</button>{image.error && <p className="entry-image-error" role="status">{t("Image unavailable. Replace or remove it in Worldbuilding.")}</p>}{viewing && <ImageViewer {...props} onClose={()=>setViewing(false)}/>}</>;
}
