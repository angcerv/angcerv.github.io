import { fromMarkdown, getSceneStatus } from './model';
import type { Chapter, Project, Scene } from './model';
export type SceneLocation={scene:Scene;chapter:Chapter;index:number};
export type SceneChange={id:string;before?:SceneLocation;after?:SceneLocation;added:boolean;removed:boolean;moved:boolean;edited:boolean};
// Keep the longest ordered subsequence, so inserting/removing an item does not mark its neighbours as moved.
function stableIds(before:string[],after:string[]):Set<string>{
 const positions=new Map(before.map((id,i)=>[id,i])),tails:number[]=[],indices:number[]=[],previous:number[]=[],items=after.filter(id=>positions.has(id));
 items.forEach((id,i)=>{const value=positions.get(id)!;let low=0,high=tails.length;while(low<high){const mid=(low+high)>>>1;if(tails[mid]<value)low=mid+1;else high=mid;}previous[i]=low?indices[low-1]:-1;tails[low]=value;indices[low]=i;});
 const result=new Set<string>();let i=indices[tails.length-1];while(i!==undefined&&i>=0){result.add(items[i]);i=previous[i];}return result;
}
function locations(project:Project){return new Map(project.chapters.flatMap(chapter=>chapter.scenes.map((scene,index)=>[scene.id,{scene,chapter,index}] as const)));}
export function compareManuscripts(before:Project,after:Project){
 const old=locations(before),next=locations(after),stable=new Set<string>();
 for(const chapter of before.chapters){const target=after.chapters.find(item=>item.id===chapter.id);if(target)for(const id of stableIds(chapter.scenes.map(s=>s.id),target.scenes.map(s=>s.id)))stable.add(id);}
 const scenes:SceneChange[]=[...next.keys(),...Array.from(old.keys()).filter(id=>!next.has(id))].map(id=>{
  const a=old.get(id),b=next.get(id);return {id,before:a,after:b,added:!a,removed:!b,moved:!!a&&!!b&&(a.chapter.id!==b.chapter.id||!stable.has(id)),edited:!!a&&!!b&&(a.scene.content!==b.scene.content||a.scene.title!==b.scene.title||(a.scene.synopsis??'')!==(b.scene.synopsis??'')||getSceneStatus(a.scene)!==getSceneStatus(b.scene))};
 }).filter(item=>item.added||item.removed||item.moved||item.edited);
 const stableChapters=stableIds(before.chapters.map(c=>c.id),after.chapters.map(c=>c.id));
 const chapters=[...after.chapters.map(c=>c.id),...before.chapters.filter(c=>!after.chapters.some(n=>n.id===c.id)).map(c=>c.id)].flatMap(id=>{
  const a=before.chapters.find(c=>c.id===id),b=after.chapters.find(c=>c.id===id);const moved=!!a&&!!b&&!stableChapters.has(id);
  return !a||!b||moved||a.title!==b.title||(a.synopsis??'')!==(b.synopsis??'')?[{id,before:a,after:b,moved}]:[];
 });
 return {scenes,chapters,titleChanged:before.title!==after.title};
}
export function manuscriptText(markdown:string):string{
 return (fromMarkdown(markdown).content??[]).map(p=>(p.content??[]).map(n=>n.type==='hardBreak'?'\n':n.text??'').join('')).join('\n\n');
}
export type TextChange={kind:'equal'|'added'|'removed';text:string};
// Exact reconstruction with bounded memory/work; very large replacements keep shared edges.
export function diffText(before:string,after:string):TextChange[]{
 const tokenize=(text:string)=>text.match(/[\p{L}\p{N}\p{M}]+|\s+|[^\p{L}\p{N}\p{M}\s]/gu)??[];
 const a=tokenize(before),b=tokenize(after),parts:TextChange[]=[];
 function push(kind:TextChange['kind'],text:string){if(!text)return;const last=parts[parts.length-1];if(last?.kind===kind)last.text+=text;else parts.push({kind,text});}
 let start=0,endA=a.length,endB=b.length;
 while(start<endA&&start<endB&&a[start]===b[start])start++;
 while(endA>start&&endB>start&&a[endA-1]===b[endB-1]){endA--;endB--;}
 push('equal',a.slice(0,start).join(''));
 const n=endA-start,m=endB-start;
 if(!n||!m||n*m>1_000_000||n+m>20_000){push('removed',a.slice(start,endA).join(''));push('added',b.slice(start,endB).join(''));}
 else{
  const rows=Array.from({length:n+1},()=>new Uint32Array(m+1));
  for(let i=n-1;i>=0;i--)for(let j=m-1;j>=0;j--)rows[i][j]=a[start+i]===b[start+j]?rows[i+1][j+1]+1:Math.max(rows[i+1][j],rows[i][j+1]);
  let i=0,j=0;while(i<n||j<m){if(i<n&&j<m&&a[start+i]===b[start+j]){push('equal',a[start+i]);i++;j++;}else if(i<n&&(j===m||rows[i+1][j]>=rows[i][j+1]))push('removed',a[start+i++]);else push('added',b[start+j++]);}
 }
 push('equal',a.slice(endA).join(''));return parts;
}
