import {useCallback,useEffect,useState} from 'react';
import type {ReactNode} from 'react';
import WorldNavigation from './WorldNavigation';
import type {WorldSection} from './WorldNavigation';
import {t} from './i18n';
export type WorldHeaderNavigation={selected:WorldSection;rejected?:boolean;select:(section:WorldSection)=>boolean};
export type WorldHeaderSlot={target:HTMLElement|null;onNavigation:(navigation:WorldHeaderNavigation)=>void};
/** Identity and navigation stay mounted outside each workspace's loading boundary. */
export default function WorldWorkspace({active,mapsActive,initialSection,onSelectFromMaps,children}:{active:boolean;mapsActive:boolean;initialSection:WorldSection;onSelectFromMaps:(section:WorldSection)=>void;children:(header:WorldHeaderSlot)=>ReactNode}){
 const [requested,setRequested]=useState<WorldSection|null>(null);
 const publishNavigation=useCallback((next:WorldHeaderNavigation)=>{setNavigation(next);setRequested(current=>next.rejected||current===next.selected?null:current);},[]);
 useEffect(()=>{if(!active)setRequested(null);},[active]);
 const [target,setTarget]=useState<HTMLDivElement|null>(null),[navigation,setNavigation]=useState<WorldHeaderNavigation|null>(null);
 return <div className="world-workspace-shell world-workspace world-surface" hidden={!active}><header className="world-module-header ui-workspace-heading"><h2>{t('World')}</h2><WorldNavigation selected={mapsActive?'maps':requested??navigation?.selected??initialSection} onSelect={section=>{if(mapsActive||!navigation){setRequested(section==='maps'?null:section);onSelectFromMaps(section);}else if(navigation.select(section)){setRequested(section==='maps'||section===navigation.selected?null:section);}}}/><div className="world-header-actions" ref={setTarget} hidden={mapsActive} inert={mapsActive}/></header>{children({target,onNavigation:publishNavigation})}</div>;
}
