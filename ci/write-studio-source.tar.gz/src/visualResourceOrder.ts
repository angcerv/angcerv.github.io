import {locale} from './i18n';
import type {VisualResource} from './visualResources';
export const visualResourceOrders={oldest:'Oldest additions first',newest:'Newest additions first',alphabetical:'Title (A–Z)',reverseAlphabetical:'Title (Z–A)'};
export type VisualResourceOrder=keyof typeof visualResourceOrders;
export function sortVisualResources(resources:VisualResource[],order:string):VisualResource[]{
 // Resource storage appends new imports and retains position on edit/restore.
 // No timestamp is inferred for resources imported by older versions.
 if(order==='newest')return [...resources].reverse();
 if(order==='alphabetical'||order==='reverseAlphabetical'){
  const collator=new Intl.Collator(locale(),{sensitivity:'base',numeric:true});
  return [...resources].sort((a,b)=>(order==='alphabetical'?1:-1)*collator.compare(a.title,b.title));
 }
 return [...resources];
}
