import {useEffect,useState} from 'react';
import {LoaderCircle} from 'lucide-react';
import ProjectModal from './ProjectModal';
import {t} from './i18n';
export type SavePhase='saving'|'finishing';
export type ProjectLoadPhase='opening'|'creating'|'restoring'|'downloading'|'preparing';
export default function SaveProgressDialog({phase,error,onClose,onRetry,projectName}:{projectName?:string;phase:SavePhase|ProjectLoadPhase;error:string;onClose:()=>void;onRetry?:()=>void}){
 const loading=phase==='opening'||phase==='creating'||phase==='restoring'||phase==='downloading'||phase==='preparing';
 const label=t({saving:'Saving project…',finishing:'Finishing save…',opening:'Opening project…',creating:'Creating project…',restoring:'Restoring backup…',downloading:'Downloading project from iCloud…',preparing:'Preparing the writing workspace…'}[phase]);
 const opening=phase==='opening'||phase==='downloading'||phase==='preparing';
 const title=opening?(projectName?t('Opening {0}',projectName):t('Opening project…')):label;
 const status=phase==='opening'?t('Reading project data…'):phase==='downloading'||phase==='preparing'?label:undefined;
 return <ProjectModal titleAccessory={loading&&!error?<LoaderCircle className="save-progress-spinner" size={24} aria-hidden="true"/>:undefined} title={loading?(error?t('Could not open the project'):title):t(error?'Could not save the project':'Saving project…')} variant={loading?'confirmation':undefined} busy={!error} onClose={error?onClose:undefined} className={`save-progress-dialog${loading&&!error?' project-loading-dialog':''}`}>
  {error?<><p role="alert" className="prompt-error">{error}</p><footer>{onRetry&&<button type="button" className="primary-button" onClick={onRetry}>{t('Retry')}</button>}<button type="button" className={onRetry?'quick-action quick-action-text':'primary-button'} onClick={onClose}>{t('Close')}</button></footer></>:loading?<div className="project-loading-status" role="status" aria-busy="true" aria-label={status?undefined:title} tabIndex={-1}>{status&&<p>{status}</p>}</div>:<div className="save-progress-content" aria-busy="true" role="status" aria-label={loading?label:undefined} tabIndex={-1}><LoaderCircle className="save-progress-spinner" size={30} aria-hidden="true"/>{!loading&&<p>{label}</p>}</div>}
 </ProjectModal>;
}

/** Fast opens keep their card feedback; only sustained work takes modal focus. */
export function ProjectLoadingDialog(props:{phase:ProjectLoadPhase;projectName?:string}){
 const immediate=props.phase==='creating'||props.phase==='restoring';
 const [visible,setVisible]=useState(immediate);
 useEffect(()=>{if(immediate)return;const timer=window.setTimeout(()=>setVisible(true),900);return()=>window.clearTimeout(timer);},[immediate]);
 return visible?<SaveProgressDialog {...props} error="" onClose={()=>{}}/>:null;
}
