import {usePinchZoom} from './usePinchZoom';
import {pinchCamera} from './pinchGesture';
import {useContext,useEffect,useRef,useState} from 'react';
import type {PointerEvent as ReactPointerEvent} from 'react';
import {Plus,StickyNote,Link2,Group,MoreHorizontal,Pencil,Trash2,GripVertical,ZoomIn,ZoomOut,Undo2,Redo2,ArrowUpRight} from 'lucide-react';
import {t,buttonLabel} from './i18n';
import type {Project} from './model';
import type {CanvasKind,CanvasNode,CanvasEdge,IdeaCanvas} from './ideaCanvas';
import {canvasTarget,canvasExcerpt,canvasNodeBounds,canvasResizeMinimum,resizeCanvasNode,resetCanvasNodeSize,nextCanvasPosition,canvasEdgePoints,canvasWidth,canvasHeight,saveCanvas,removeCanvasNode,moveCanvasNode,convertCanvasNote} from './ideaCanvas';
import {isGraphDrag,draggedGraphPoint} from './graphGesture';
import {useWorkspaceState} from './useWorkspaceState';
import {TextReferenceContext} from './textReferenceContext';
import {consultationSource} from './SourceConsultation';
import {AreaResize} from './PanelResize';
import Dropdown from './Dropdown';
import ActionMenu from './ActionMenu';
import ProjectModal from './ProjectModal';
import LongTextEditor from './LongTextEditor';
import {EntryPortrait} from './EntryImage';
import {emptyWorld} from './worldbuilding';
import {visualResources} from './visualResources';
import FieldHelp from './FieldHelp';
import './styles/idea-canvas.css';

const newCardLabels:Record<CanvasKind,string>={note:'New note',group:'New group',entry:'Link entry',scene:'Link scene',event:'Link event',idea:'Link idea',plot:'Link plot',image:'Add image'};
const kindLabels:Record<CanvasKind,string>={note:'Note',group:'Group',entry:'Entry',scene:'Scene',event:'Event',idea:'Idea',plot:'Plot',image:'Image'};
type Props={active?:boolean;project:Project;path:string;onChange:(project:Project)=>void};
type Draft={mode:'board';id?:string;title:string}|{mode:'node';node:CanvasNode}|{mode:'edge';edge:CanvasEdge}|{mode:'convert';node:CanvasNode;kind:'idea'|'entry';templateId:string}|{mode:'deleteBoard';id:string};
type Drag={pointerId:number;start:{x:number;y:number};node:CanvasNode;board:IdeaCanvas;handle:HTMLButtonElement;zoom:number;moved:boolean};
export default function IdeaCanvasEditor({active=true,project,path,onChange}:Props){
 const references=useContext(TextReferenceContext),viewport=useRef<HTMLDivElement>(null);
 const [selectedId,setSelectedId]=useWorkspaceState('canvas.board','');
 const [zoom,setZoom]=useWorkspaceState('canvas.zoom',1);
 const [draft,setDraft]=useState<Draft|null>(null),[preview,setPreview]=useState<IdeaCanvas|null>(null);
 const resizing=useRef<{board:IdeaCanvas;nodeId:string}|null>(null);
 const drag=useRef<Drag|null>(null),undo=useRef<IdeaCanvas[]>([]),redo=useRef<IdeaCanvas[]>([]);
 const [,setHistoryRevision]=useState(0);
 const [discard,setDiscard]=useState(false);
 const boards=project.ideaCanvases?.boards??[],board=boards.find(item=>item.id===selectedId)??boards[0],display=preview?.id===board?.id?preview:board;
 const latest=useRef({project,board});latest.current={project,board};
 function cancelDrag(){
  const current=drag.current;drag.current=null;resizing.current=null;setPreview(null);
  if(current?.handle.hasPointerCapture(current.pointerId))current.handle.releasePointerCapture(current.pointerId);
 }
 useEffect(()=>{if(!active)cancelDrag();},[active]);
 function changeZoom(value:number){
  const panel=viewport.current,center=panel?{x:(panel.scrollLeft+panel.clientWidth/2)/zoom,y:(panel.scrollTop+panel.clientHeight/2)/zoom}:null;
  setZoom(value);
  if(panel&&center)requestAnimationFrame(()=>{panel.scrollLeft=center.x*value-panel.clientWidth/2;panel.scrollTop=center.y*value-panel.clientHeight/2;});
 }
 usePinchZoom(viewport,{enabled:active&&!!board,context:board?.id,start:()=>{cancelDrag();return {x:-(viewport.current?.scrollLeft??0),y:-(viewport.current?.scrollTop??0),zoom};},update:(snapshot,{ratio,start,center})=>{
  const panel=viewport.current;if(!panel)return;const rect=panel.getBoundingClientRect();
  const next=pinchCamera(snapshot,ratio,{x:start.x-rect.left,y:start.y-rect.top},{x:center.x-rect.left,y:center.y-rect.top},.4,1.6);setZoom(next.zoom);
  requestAnimationFrame(()=>{if(viewport.current===panel){panel.scrollLeft=-next.x;panel.scrollTop=-next.y;}});
 },cancel:snapshot=>{setZoom(snapshot.zoom);const panel=viewport.current;if(panel)requestAnimationFrame(()=>{panel.scrollLeft=-snapshot.x;panel.scrollTop=-snapshot.y;});}});
 function requestDraftClose(){
  if(!draft)return;
  let changed=false;
  if(draft.mode==='board')changed=draft.title.trim()!==(boards.find(item=>item.id===draft.id)?.title??'').trim();
  if(draft.mode==='node'){
   const original=board?.nodes.find(node=>node.id===draft.node.id);
   const values=(node?:CanvasNode)=>JSON.stringify([node?.title.trim()??'',node?.text??'',node?.targetId??'',node?.groupId??'']);
   changed=values(draft.node)!==values(original);
  }
  if(draft.mode==='edge'){
   const original=board?.edges.find(edge=>edge.id===draft.edge.id);
   const values=(edge?:CanvasEdge)=>JSON.stringify([edge?.from??'',edge?.to??'',edge?.label.trim()??'']);
   changed=values(draft.edge)!==values(original);
  }
  if(changed)setDiscard(true);else setDraft(null);
 }
 function select(id:string){cancelDrag();setSelectedId(id);undo.current=[];redo.current=[];setHistoryRevision(value=>value+1);}
 function commit(next:IdeaCanvas){const current=latest.current;if(!current.board)return;undo.current=[...undo.current,current.board].slice(-30);redo.current=[];setHistoryRevision(value=>value+1);onChange(saveCanvas(current.project,next));}
 function travelHistory(direction:'undo'|'redo'){
  const from=direction==='undo'?undo:redo,to=direction==='undo'?redo:undo,next=from.current.pop();
  if(!next||!board||next.id!==board.id)return;
  to.current.push(board);setHistoryRevision(value=>value+1);onChange(saveCanvas(project,next));
 }
 function newNode(kind:CanvasKind){
  if(!board||board.nodes.length>=500)return;
  const offset={x:(viewport.current?.scrollLeft??0)/zoom+40,y:(viewport.current?.scrollTop??0)/zoom+40};
  setDraft({mode:'node',node:{id:crypto.randomUUID(),kind,...nextCanvasPosition(board,offset),title:'',text:''}});
 }
 function startDrag(event:ReactPointerEvent<HTMLButtonElement>,node:CanvasNode){
  if(event.button!==0||!board)return;
  event.currentTarget.focus({preventScroll:true});
  event.currentTarget.setPointerCapture(event.pointerId);
  drag.current={pointerId:event.pointerId,start:{x:event.clientX,y:event.clientY},node,board,handle:event.currentTarget,zoom,moved:false};
 }
 function dragMove(event:ReactPointerEvent<HTMLButtonElement>){
  const current=drag.current;if(!current||current.pointerId!==event.pointerId)return;
  const point={x:event.clientX,y:event.clientY};if(!current.moved&&!isGraphDrag(current.start,point))return;
  current.moved=true;const position=draggedGraphPoint(current.node,current.start,point,current.zoom);
  setPreview(moveCanvasNode(current.board,current.node.id,position.x,position.y));
 }
 function finishDrag(event:ReactPointerEvent<HTMLButtonElement>,cancel=false){
  const current=drag.current;if(!current||current.pointerId!==event.pointerId)return;
  drag.current=null;setPreview(null);
  if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId);
  if(!cancel&&current.moved&&latest.current.board?.id===current.board.id){
   const position=draggedGraphPoint(current.node,current.start,{x:event.clientX,y:event.clientY},current.zoom);
   commit(moveCanvasNode(latest.current.board,current.node.id,position.x,position.y));
  }
 }
 function consult(node:CanvasNode){if(node.targetId&&node.kind!=='image'&&node.kind!=='note'&&node.kind!=='group')references?.consultSource?.(consultationSource(node.kind,node.targetId));}
 function saveDraft(event:React.FormEvent){
  event.preventDefault();if(!draft)return;
  if(draft.mode==='board'){
   const title=draft.title.trim();if(!title)return;
   const current=boards.find(item=>item.id===draft.id);
   const next=current?{...current,title}:{id:crypto.randomUUID(),title,nodes:[],edges:[]};
   onChange(saveCanvas(project,next));select(next.id);
  }else if(draft.mode==='node'&&board){
   const node={...draft.node,title:draft.node.title.trim()};if(node.text.length>200000)return;
   if((node.kind==='note'||node.kind==='group')&&!node.title||!['note','group'].includes(node.kind)&&!node.targetId)return;
   commit({...board,nodes:board.nodes.some(item=>item.id===node.id)?board.nodes.map(item=>item.id===node.id?node:item):[...board.nodes,node]});
  }else if(draft.mode==='edge'&&board){
   const edge=draft.edge;if(!edge.from||!edge.to||edge.from===edge.to||board.edges.some(item=>item.id!==edge.id&&item.from===edge.from&&item.to===edge.to))return;
   commit({...board,edges:board.edges.some(item=>item.id===edge.id)?board.edges.map(item=>item.id===edge.id?edge:item):[...board.edges,edge]});
  }else if(draft.mode==='convert'&&board){
   const next=convertCanvasNote(project,board.id,draft.node.id,draft.kind,draft.templateId);
   if(next===project)return;
   undo.current=[];redo.current=[];setHistoryRevision(value=>value+1);onChange(next);
  }else if(draft.mode==='deleteBoard'){
   onChange({...project,ideaCanvases:{schemaVersion:project.ideaCanvases?.schemaVersion??1,boards:boards.filter(item=>item.id!==draft.id)}});select('');
  }
  setDraft(null);
 }
 const targetChoices=(kind:CanvasKind)=>{
  if(kind==='entry')return (project.worldbuilding?.entries??[]).filter(item=>!item.archived);
  if(kind==='scene')return project.chapters.flatMap(chapter=>chapter.scenes.map(scene=>({...scene,title:chapter.title+' / '+scene.title})));
  if(kind==='event')return project.timeline?.events??[];
  if(kind==='idea')return project.worldIdeas??[];
  if(kind==='plot')return project.plots?.threads??[];
  if(kind==='image')return visualResources(project.worldbuilding??emptyWorld);
  return [];
 };
 const nodeChoices=board?.nodes.map(node=>({value:node.id,label:canvasTarget(project,node).title||t('Untitled')}))??[];
 const conversionTemplates=(project.worldbuilding?.templates??[]).filter(template=>template.fields.some(field=>!field.archived&&field.fieldType==='longText'));
 const noteTooLong=draft?.mode==='node'&&draft.node.text.length>200000;
 const nodeDialogTitle=draft?.mode==='node'?(board?.nodes.some(node=>node.id===draft.node.id)?'Edit card':newCardLabels[draft.node.kind]):'Edit card';
 const invalidEdge=draft?.mode==='edge'&&(!draft.edge.from||!draft.edge.to||draft.edge.from===draft.edge.to||board?.edges.some(edge=>edge.id!==draft.edge.id&&edge.from===draft.edge.from&&edge.to===draft.edge.to));
 return <div className="idea-canvas-editor">
  <header className="idea-canvas-heading ui-workspace-heading"><h1><StickyNote size={20} aria-hidden="true"/>{t('Idea canvases')}</h1><button type="button" className="primary-button" disabled={boards.length>=200} onClick={()=>setDraft({mode:'board',title:''})}><Plus size={15}/>{t('New canvas')}</button></header>
  {board?<><div className="idea-canvas-toolbar">
   <Dropdown id="idea-canvas-choice" aria-label={t('Canvas')} value={board.id} options={boards.map(item=>({value:item.id,label:item.title}))} onChange={select}/>
   <button type="button" className="quick-action quick-action-text" disabled={board.nodes.length>=500} onClick={()=>newNode('note')}><StickyNote size={16}/>{t('Add note')}</button>
   <ActionMenu label={t('Add to canvas')} disabled={board.nodes.length>=500} actions={(['entry','scene','event','idea','plot','image','group'] as const).map(kind=>({label:buttonLabel(kindLabels[kind]),icon:kind==='group'?<Group size={15}/>:<Link2 size={15}/>,onClick:()=>newNode(kind)}))}><Plus size={16}/>{t('Add to canvas')}</ActionMenu>
   <button type="button" className="quick-action" title={t('Connect cards')} aria-label={t('Connect cards')} disabled={board.nodes.length<2||board.edges.length>=2000} onClick={()=>setDraft({mode:'edge',edge:{id:crypto.randomUUID(),from:'',to:'',label:''}})}><Link2 size={16}/></button>
   <button type="button" className="quick-action" title={t('Undo')} aria-label={t('Undo')} disabled={!undo.current.length} onClick={()=>travelHistory('undo')}><Undo2 size={16}/></button>
   <button type="button" className="quick-action" title={t('Redo')} aria-label={t('Redo')} disabled={!redo.current.length} onClick={()=>travelHistory('redo')}><Redo2 size={16}/></button>
   <div className="idea-canvas-zoom"><button type="button" className="quick-action" aria-label={t('Zoom out')} title={t('Zoom out')} disabled={zoom<=0.4} onClick={()=>changeZoom(Math.max(0.4,Math.round((zoom-0.1)*10)/10))}><ZoomOut size={16}/></button><button type="button" className="quick-action quick-action-text" aria-label={t('Reset zoom')} onClick={()=>changeZoom(1)}>{Math.round(zoom*100)}%</button><button type="button" className="quick-action" aria-label={t('Zoom in')} title={t('Zoom in')} disabled={zoom>=1.6} onClick={()=>changeZoom(Math.min(1.6,Math.round((zoom+0.1)*10)/10))}><ZoomIn size={16}/></button></div>
   <FieldHelp variant="toolbar" label={t('Canvas navigation')} description={t('Scroll to explore. Drag a card by its handle, or focus the handle and use the arrow keys. Shift moves it further. Connections here do not change canonical relationships.')}/>
   <ActionMenu iconOnly label={t('Canvas actions')} actions={[{label:t('Rename'),icon:<Pencil size={15}/>,onClick:()=>setDraft({mode:'board',id:board.id,title:board.title})},{label:t('Delete canvas'),icon:<Trash2 size={15}/>,danger:true,onClick:()=>setDraft({mode:'deleteBoard',id:board.id})}]}><MoreHorizontal size={17}/></ActionMenu>
  </div>
  {!board.nodes.length&&<p className="world-hint">{t('Add a note or link existing content to start this canvas.')}</p>}
  <div ref={viewport} id="idea-canvas-scroll" className="idea-canvas-viewport" tabIndex={0} aria-label={t('Canvas: {0}',board.title)} onKeyDown={event=>{if(event.key==='Escape'&&(drag.current||resizing.current)){event.preventDefault();cancelDrag();}}}>
   <div style={{width:canvasWidth*zoom,height:canvasHeight*zoom}}><div className="idea-canvas-paper" style={{width:canvasWidth,height:canvasHeight,transform:`scale(${zoom})`}}>

    <svg className="idea-canvas-edges" width={canvasWidth} height={canvasHeight} aria-hidden="true"><defs><marker id="idea-canvas-arrow" markerWidth="8" markerHeight="8" refX="7" refY="4" orient="auto"><path d="M0,0 L8,4 L0,8 Z"/></marker></defs>{display?.edges.map(edge=>{const from=display.nodes.find(node=>node.id===edge.from),to=display.nodes.find(node=>node.id===edge.to);if(!from||!to)return null;const ports=canvasEdgePoints(from,to,display);return <line key={edge.id} x1={ports.from.x} y1={ports.from.y} x2={ports.to.x} y2={ports.to.y} markerEnd="url(#idea-canvas-arrow)"/>;})}</svg>
    {display?.edges.map(edge=>{const from=display.nodes.find(node=>node.id===edge.from),to=display.nodes.find(node=>node.id===edge.to);if(!from||!to)return null;return <button type="button" key={edge.id} className="idea-canvas-edge-label" style={{left:canvasEdgePoints(from,to,display).label.x,top:canvasEdgePoints(from,to,display).label.y}} aria-label={t('Edit connection: {0} → {1}',canvasTarget(project,from).title,canvasTarget(project,to).title)} onClick={()=>setDraft({mode:'edge',edge})}>{edge.label||<Link2 size={14}/>}</button>;})}
    {display?.nodes.slice().sort((a,b)=>Number(b.kind==='group')-Number(a.kind==='group')).map(node=>{const target=canvasTarget(project,node),bounds=canvasNodeBounds(display,node),minimum=canvasResizeMinimum(display,node);return <article key={node.id} className={`idea-canvas-card${node.kind==='group'?' is-group':''}${target.missing?' is-missing':''}`} style={{left:bounds.x,top:bounds.y,width:bounds.width,height:bounds.height}} aria-label={target.title}>
     <header><button type="button" className="idea-canvas-handle" aria-label={t('Move {0}',target.title)} title={t('Move {0}',target.title)} onPointerDown={event=>startDrag(event,node)} onPointerMove={dragMove} onPointerUp={event=>finishDrag(event)} onPointerCancel={event=>finishDrag(event,true)} onLostPointerCapture={event=>finishDrag(event,true)} onKeyDown={event=>{const delta=event.shiftKey?40:10;if(drag.current||resizing.current)return;if(!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(event.key)||!board)return;event.preventDefault();commit(moveCanvasNode(board,node.id,node.x+(event.key==='ArrowRight'?delta:event.key==='ArrowLeft'?-delta:0),node.y+(event.key==='ArrowDown'?delta:event.key==='ArrowUp'?-delta:0)));}}><GripVertical size={16}/></button>{node.kind==='group'?<><h2>{target.title||t('Untitled')}</h2><FieldHelp variant="toolbar" label={target.title||t('Group')} description={canvasExcerpt(target.text,200000)}/></>:<small>{t(kindLabels[node.kind])}</small>}
      <ActionMenu variant="row" animated iconOnly label={t('Card actions')} actions={[{label:t('Edit card'),icon:<Pencil size={14}/>,onClick:()=>setDraft({mode:'node',node})},...(node.kind==='note'?[{label:t('Convert to pending idea'),onClick:()=>setDraft({mode:'convert',node,kind:'idea',templateId:''})},{label:t('Convert to entry'),disabled:!conversionTemplates.length,disabledReason:t('Create a template with a long text field first.'),onClick:()=>setDraft({mode:'convert',node,kind:'entry',templateId:conversionTemplates[0]?.id??''})}]:[]),{label:t('Reset size'),disabled:node.width===undefined&&node.height===undefined,onClick:()=>commit(resetCanvasNodeSize(board,node.id))},{label:t('Remove from canvas'),icon:<Trash2 size={14}/>,danger:true,onClick:()=>commit(removeCanvasNode(board,node.id))}]}><MoreHorizontal size={15}/></ActionMenu>
     </header>{node.kind!=='group'&&<h2>{target.title||t('Untitled')}</h2>}
     {node.kind==='group'?null:node.kind==='image'&&!target.missing?<EntryPortrait lazy projectPath={path} projectId={project.id} imageId={node.targetId} title={target.title}/>:<p>{canvasExcerpt(target.text,Math.min(12000,Math.ceil(bounds.width/6)*Math.ceil(bounds.height/16)))}</p>}
     {node.groupId&&<small className="idea-canvas-membership">{board.nodes.find(item=>item.id===node.groupId)?.title}</small>}
     {!['note','group','image'].includes(node.kind)&&<button type="button" className="quick-action quick-action-text idea-canvas-consult" disabled={target.missing} onClick={()=>consult(node)}>{t('Consult')}<ArrowUpRight size={13}/></button>}
     <AreaResize label={t('Resize {0}',target.title)} width={bounds.width} height={bounds.height} zoom={zoom} minimumWidth={minimum.width} minimumHeight={minimum.height} maximumWidth={canvasWidth-bounds.x} maximumHeight={canvasHeight-bounds.y} disabled={!active}
      onPreview={size=>{if(!resizing.current)resizing.current={board,nodeId:node.id};const current=resizing.current;setPreview(resizeCanvasNode(current.board,current.nodeId,size.width,size.height));}}
      onCommit={size=>{resizing.current=null;setPreview(null);if(active&&latest.current.board?.id===board.id)commit(resizeCanvasNode(latest.current.board,node.id,size.width,size.height));}}
      onCancel={()=>{resizing.current=null;setPreview(null);}}/>
    </article>;})}
   </div></div>
  </div></>:<div className="ui-empty-state"><StickyNote size={28}/><p>{t('Organize ideas freely with notes, groups and linked cards.')}</p><button type="button" className="primary-button" onClick={()=>setDraft({mode:'board',title:''})}>{t('New canvas')}</button></div>}
  {active&&draft&&<ProjectModal className="idea-canvas-dialog" title={t(draft.mode==='board'?(draft.id?'Rename canvas':'New canvas'):draft.mode==='edge'?'Connect cards':draft.mode==='convert'?(draft.kind==='idea'?'Convert to pending idea':'Convert to entry'):draft.mode==='deleteBoard'?'Delete canvas':nodeDialogTitle)} onClose={requestDraftClose}>
   <form hidden={discard} inert={discard} onSubmit={saveDraft}>
    {draft.mode==='board'&&<div className="ui-form-field"><label htmlFor="canvas-title">{t('Title')}</label><input id="canvas-title" required maxLength={300} value={draft.title} onChange={event=>setDraft({...draft,title:event.target.value})}/></div>}
    {draft.mode==='node'&&<>
     {['note','group'].includes(draft.node.kind)?<><div className="ui-form-field"><label htmlFor="canvas-note-title">{t('Title')}</label><input id="canvas-note-title" required maxLength={300} value={draft.node.title} onChange={event=>setDraft({...draft,node:{...draft.node,title:event.target.value}})}/></div><div className="ui-form-field"><label id="canvas-note-text-label" htmlFor="canvas-note-text">{t('Notes')}</label><LongTextEditor id="canvas-note-text" value={draft.node.text} onChange={text=>setDraft({...draft,node:{...draft.node,text}})}/></div></>:<div className="ui-form-field"><label id="canvas-target-label" htmlFor="canvas-target">{t(kindLabels[draft.node.kind])}</label><Dropdown id="canvas-target" aria-labelledby="canvas-target-label" searchable value={draft.node.targetId??''} selectedLabel={draft.node.targetId?canvasTarget(project,draft.node).title:t(draft.node.kind==='entry'?'No entry selected':'No selection')} options={targetChoices(draft.node.kind).map(item=>({value:item.id,label:item.title||t('Untitled')}))} onChange={targetId=>setDraft({...draft,node:{...draft.node,targetId}})}/>{!targetChoices(draft.node.kind).length&&<p className="world-hint">{t('No content available. Create it in its workspace first.')}</p>}</div>}
     {draft.node.kind!=='group'&&<div className="ui-form-field"><label id="canvas-node-group-label" htmlFor="canvas-node-group">{t('Group')}</label><Dropdown id="canvas-node-group" aria-labelledby="canvas-node-group-label" value={draft.node.groupId??''} options={[{value:'',label:t('None')},...board!.nodes.filter(node=>node.kind==='group').map(node=>({value:node.id,label:node.title}))]} onChange={groupId=>setDraft({...draft,node:{...draft.node,groupId:groupId||undefined}})}/></div>}
    </>}
    {draft.mode==='edge'&&<><div className="ui-form-field"><label id="canvas-edge-from-label" htmlFor="canvas-edge-from">{t('From card')}</label><Dropdown id="canvas-edge-from" aria-labelledby="canvas-edge-from-label" searchable value={draft.edge.from} options={nodeChoices} onChange={from=>setDraft({...draft,edge:{...draft.edge,from}})}/></div><div className="ui-form-field"><label id="canvas-edge-to-label" htmlFor="canvas-edge-to">{t('To card')}</label><Dropdown id="canvas-edge-to" aria-labelledby="canvas-edge-to-label" searchable value={draft.edge.to} options={nodeChoices.filter(option=>option.value!==draft.edge.from)} onChange={to=>setDraft({...draft,edge:{...draft.edge,to}})}/></div><div className="ui-form-field"><label htmlFor="canvas-edge-label">{t('Connection label')}</label><input id="canvas-edge-label" maxLength={300} value={draft.edge.label} onChange={event=>setDraft({...draft,edge:{...draft.edge,label:event.target.value}})}/></div>{invalidEdge&&draft.edge.to&&<p className="prompt-error" role="alert">{t('Choose two different cards without an existing connection in that direction.')}</p>}{board!.edges.some(edge=>edge.id===draft.edge.id)&&<button type="button" className="danger-button" onClick={()=>{commit({...board!,edges:board!.edges.filter(edge=>edge.id!==draft.edge.id)});setDraft(null);}}>{t('Delete connection')}</button>}</>}
    {draft.mode==='convert'&&<><p className="world-hint">{t('The note becomes a linked card. Its title and text are saved in the new content.')}</p>{draft.kind==='entry'&&<div className="ui-form-field"><label id="canvas-convert-template-label" htmlFor="canvas-convert-template">{t('Template')}</label><Dropdown id="canvas-convert-template" aria-labelledby="canvas-convert-template-label" value={draft.templateId} options={conversionTemplates.map(template=>({value:template.id,label:template.title}))} onChange={templateId=>setDraft({...draft,templateId})}/><p className="world-hint">{t('Text field: {0}',conversionTemplates.find(template=>template.id===draft.templateId)?.fields.find(field=>!field.archived&&field.fieldType==='longText')?.label||t('Untitled field'))}</p></div>}</>}
    {draft.mode==='deleteBoard'&&<p>{t('This deletes the canvas and its notes. Linked project content is kept.')}</p>}
    {noteTooLong&&<p className="prompt-error" role="alert">{t('The note is too long (maximum 200,000 characters).')}</p>}<div className="welcome-actions"><button type="button" onClick={requestDraftClose} className="quick-action quick-action-text">{t('Cancel')}</button><button type="submit" className={draft.mode==='deleteBoard'?'danger-button':'primary-button'} disabled={!!noteTooLong||!!invalidEdge||draft.mode==='node'&&!['note','group'].includes(draft.node.kind)&&!draft.node.targetId}>{buttonLabel(draft.mode==='deleteBoard'?'Delete canvas':draft.mode==='convert'?'Convert':'Save')}</button></div>
   </form>
  </ProjectModal>}
  {active&&discard&&<ProjectModal title={t('Discard unsaved changes?')} variant="confirmation" onClose={()=>setDiscard(false)}><p>{t('Unsaved changes will be lost if you discard them.')}</p><div className="welcome-actions"><button type="button" className="quick-action quick-action-text" onClick={()=>setDiscard(false)}>{t('Keep editing')}</button><button type="button" className="danger-button" onClick={()=>{setDiscard(false);setDraft(null);}}>{t('Discard changes')}</button></div></ProjectModal>}
 </div>;
}
