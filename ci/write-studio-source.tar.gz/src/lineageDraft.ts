import type {FamilyLineage} from './entryRelations';
/** Membership order does not constitute an edit. A blank new form is clean. */
export function lineageDraftChanged(draft:FamilyLineage|null,original?:FamilyLineage):boolean{
 if(!draft)return false;
 if(!original)return !!draft.name.trim()||draft.memberIds.length>0;
 return draft.name.trim()!==original.name.trim()||new Set(draft.memberIds).size!==new Set(original.memberIds).size||draft.memberIds.some(id=>!original.memberIds.includes(id));
}
