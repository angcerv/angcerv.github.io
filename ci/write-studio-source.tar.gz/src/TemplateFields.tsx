import {createDragPreview} from './dragPreview';
import FieldHelp from './FieldHelp';
import {focusDialog} from './dialogFocus';
import {TextReferenceTools} from './TextReferenceUI';
import ProjectModal from './ProjectModal';
import TemplateSectionsEditor from './TemplateSectionsEditor';
import { fieldGroups, placeField, moveWithinSection } from './templateSections';
import { t } from './i18n';
import { PicklistOptions } from './PicklistFields';
import FieldCreateDialog from './FieldCreateDialog';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { Archive, ArchiveRestore, GripVertical, Plus, Pencil, X, Trash2 } from 'lucide-react';
import Dropdown from './Dropdown';
import { convertToLongText, addField, setBirthDateField, deleteField, fieldUsageCount, fieldLabels, isPicklist, updateField, referenceReviewCount } from './worldbuilding';
import type { Field, Worldbuilding } from './worldbuilding';
function DeleteFieldDialog({label,blocked,onCancel,onConfirm,onRemovedFocus}:{label:string;blocked:boolean;onCancel:()=>void;onConfirm:()=>void;onRemovedFocus:()=>void}) {
 const previous=useRef(typeof document==='undefined'?null:document.activeElement as HTMLElement|null);
 useEffect(()=>()=>{if(previous.current&&!previous.current.isConnected)onRemovedFocus();},[]);
 return <ProjectModal title={t('Delete field?')} variant="confirmation" onClose={onCancel}>{blocked?<p className="prompt-error" role="alert">{t('This field is used by entries. Archive it to keep their values.')}</p>:<p>{t('Remove empty field “{0}”? No entry has a value in this field. Existing entries are kept.',label)}</p>}<div className="welcome-actions"><button type="button" onClick={onCancel} className="quick-action quick-action-text">{t('Cancel')}</button><button type="button" className="danger-button" disabled={blocked} onClick={onConfirm}>{t('Delete field')}</button></div></ProjectModal>;
}

export function FieldEditDialog({label,onClose,children}:{label:string;onClose:()=>void;children:React.ReactNode}) {
 const dialog=useRef<HTMLDialogElement>(null),previous=useRef(typeof document==='undefined'?null:document.activeElement as HTMLElement|null);
 useEffect(()=>{const node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous.current?.isConnected)previous.current.focus();};},[]);
 const content=<dialog ref={dialog} className="field-create-dialog field-edit-dialog" aria-labelledby="field-edit-title" onCancel={event=>{event.preventDefault();onClose();}}><header><h2 id="field-edit-title">{t('Edit field {0}',label)}</h2><button title={t("Close")} type="button" className="icon-button ui-close-button" aria-label={t('Close')} onClick={onClose}><X size={18}/></button></header><div className="field-create-body">{children}</div></dialog>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}
function reviewSummary(count:number){return count===1?t('1 existing link needs review. Values have been kept.'):t('{0} existing links need review. Values have been kept.',count);}
function ReferenceTemplateSetting({world,templateId,field,onChange}:{world:Worldbuilding;templateId:string;field:Field;onChange:(world:Worldbuilding)=>void}) {
 const id=`reference-template-${field.id}`,count=referenceReviewCount(world,templateId,field);
 return <div className="reference-template-setting"><label id={`${id}-label`} htmlFor={id}>{t('Link to')}</label><Dropdown id={id} aria-labelledby={`${id}-label`} value={field.targetTemplateId??''} selectedLabel={t('Missing template')} onChange={value=>onChange(updateField(world,templateId,field.id,{targetTemplateId:value||undefined}))} options={[{value:'',label:t('Any template')},...world.templates.map(template=>({value:template.id,label:template.title||t('Untitled template')}))]}/>{count>0&&<p className="reference-review" role="status">{reviewSummary(count)}</p>}</div>;
}
export default function TemplateFields({world,template,onChange}:{world:Worldbuilding;template:Worldbuilding['templates'][number];onChange:(world:Worldbuilding)=>void}) {
 const [adding,setAdding]=useState(false),[editing,setEditing]=useState(''),[deleting,setDeleting]=useState('');
 const addButton=useRef<HTMLButtonElement>(null);
 const fieldList=useRef<HTMLDivElement>(null);
 const gesture=useRef<{id:string;pointerId:number;x:number;y:number;active:boolean;preview?:ReturnType<typeof createDragPreview>;target?:{sectionId?:string;beforeId?:string;marker:string}}|null>(null);
 useEffect(()=>()=>{gesture.current?.preview?.remove();},[]);
 const [dragged,setDragged]=useState(''),[over,setOver]=useState(''),[announcement,setAnnouncement]=useState('');
 function moveField(id:string,sectionId?:string,beforeId?:string){onChange(placeField(world,template.id,id,sectionId,beforeId));setDragged('');setOver('');setAnnouncement(t('Field order updated.'));requestAnimationFrame(()=>document.getElementById(`field-edit-${id}`)?.focus());}
 function clearDrag(){gesture.current?.preview?.remove();gesture.current=null;setDragged('');setOver('');}
 function pointerMove(event:React.PointerEvent<HTMLButtonElement>){
  const current=gesture.current;if(!current||current.pointerId!==event.pointerId)return;
  if(!current.active&&Math.hypot(event.clientX-current.x,event.clientY-current.y)<5)return;
  event.preventDefault();current.active=true;current.preview?.move(event.clientX,event.clientY);setDragged(current.id);
  const hit=document.elementFromPoint(event.clientX,event.clientY);
  const group=hit?.closest<HTMLElement>('[data-field-group]');
  if(!group||!fieldList.current?.contains(group)){current.target=undefined;setOver('');return;}
  const sectionId=group.dataset.fieldGroup||undefined;
  const row=hit?.closest<HTMLElement>('[data-field-id]');
  if(row?.dataset.fieldId===current.id){current.target=undefined;setOver('');return;}
  if(row){
   const id=row.dataset.fieldId!,rect=row.getBoundingClientRect(),after=event.clientY>=rect.top+rect.height/2;
   const siblings=fieldGroups(template).find(item=>(item.id||undefined)===sectionId)!.fields;
   current.target={sectionId,beforeId:after?siblings[siblings.findIndex(item=>item.id===id)+1]?.id:id,marker:`${id}:${after?'after':'before'}`};
  }else current.target={sectionId,marker:`group-${sectionId??''}`};
  setOver(current.target.marker);
  // Keep long lists usable while the handle owns pointer capture.
  for(let node:HTMLElement|null=group;node;node=node.parentElement){
   if(node.scrollHeight<=node.clientHeight||!/(auto|scroll)/.test(getComputedStyle(node).overflowY))continue;
   const rect=node.getBoundingClientRect();if(event.clientY<rect.top+40)node.scrollTop-=14;else if(event.clientY>rect.bottom-40)node.scrollTop+=14;break;
  }
 }
 function pointerUp(event:React.PointerEvent<HTMLButtonElement>){
  const current=gesture.current;if(!current||current.pointerId!==event.pointerId)return;
  if(current.active){pointerMove(event);const target=current.target;if(target)moveField(current.id,target.sectionId,target.beforeId);}
  clearDrag();if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId);
 }
 function reorder(id:string,direction:-1|1){const next=moveWithinSection(world,template.id,id,direction);if(next!==world){onChange(next);setAnnouncement(t('Field order updated.'));}}

 return <>
  {deleting&&<DeleteFieldDialog blocked={fieldUsageCount(world,template.id,deleting)>0||!template.fields.some(field=>field.id===deleting)} label={template.fields.find(field=>field.id===deleting)?.label||t('Untitled field')} onCancel={()=>setDeleting('')} onRemovedFocus={()=>addButton.current?.focus({preventScroll:true})} onConfirm={()=>{onChange(deleteField(world,template.id,deleting));if(editing===deleting)setEditing('');setDeleting('');}}/>}
  {adding&&<FieldCreateDialog world={world} sections={template.sections} onCancel={()=>setAdding(false)} onSave={(name,type,target,options,birthDate,section,description)=>{onChange(addField(world,template.id,name,type,target,options,birthDate,section,description));setAdding(false);}}/>}
  <p id="field-reorder-help" className="visually-hidden">{t('Drag a field handle or use its arrow keys to change field order.')}</p><span className="visually-hidden" role="status">{announcement}</span>
  <TemplateSectionsEditor world={world} template={template} onChange={onChange}/><div className="world-fields-heading"><div className="world-fields-title"><h3>{t('Fields')}</h3><button ref={addButton} type="button" className="primary-button" aria-label={t('Add field')} title={t('Add field')} aria-haspopup="dialog" onClick={()=>setAdding(true)}><Plus size={16}/>{t('Add field')}</button><FieldHelp variant="toolbar" label={t('Fields')} description={t('Drag to reorder · arrow keys on the handle')}/></div></div>
  {!template.fields.length&&<p className="world-empty-fields">{t('No fields yet. Add one to shape your entries.')}</p>}
  <div ref={fieldList} className="world-template-fields">{fieldGroups(template).filter(group=>group.id||group.fields.length||template.sections?.length).map(group=><section key={group.id} data-field-group={group.id} className="template-field-group"><div className={`template-field-group-heading${over===`group-${group.id}`?' drag-over':''}`}><h4>{group.title}</h4><span>{group.fields.length}</span></div><div className="template-section-fields">{group.fields.map(field=>{
   const used=fieldUsageCount(world,template.id,field.id);
   const review=field.fieldType==='reference'?referenceReviewCount(world,template.id,field):0;
   const open=editing===field.id,region=`field-settings-${field.id}`,label=field.label||t('Untitled field');
   return <div key={field.id} data-field-id={field.id} className={`world-template-field${field.archived?' archived':''}${dragged===field.id?' dragging':''}${over===`${field.id}:before`?' drop-before':''}${over===`${field.id}:after`?' drop-after':''}${open?' editing':''}`}>
    <div className="template-field-row"><button type="button" className="field-drag-handle" draggable={false} aria-label={t('Reorder {0}',label)} aria-describedby="field-reorder-help" title={t('Drag to reorder, or use arrow keys')} onDragStart={event=>event.preventDefault()} onPointerDown={event=>{if(event.button!==0||!event.isPrimary||gesture.current)return;event.preventDefault();event.currentTarget.focus();event.currentTarget.setPointerCapture(event.pointerId);gesture.current={id:field.id,pointerId:event.pointerId,x:event.clientX,y:event.clientY,active:false,preview:createDragPreview(event.currentTarget.closest?.('[data-field-id]')??null,event.clientX,event.clientY)};}} onPointerMove={pointerMove} onPointerUp={pointerUp} onPointerCancel={clearDrag} onLostPointerCapture={clearDrag} onKeyDown={event=>{if(event.key==='Escape'){clearDrag();event.preventDefault();return;}if(['ArrowUp','ArrowLeft','ArrowDown','ArrowRight'].includes(event.key)){event.preventDefault();reorder(field.id,['ArrowUp','ArrowLeft'].includes(event.key)?-1:1);}}}><GripVertical size={17}/></button>
     <div className="template-field-identity"><strong>{label}</strong>{field.fieldType==='date'&&field.isBirthDate&&<small>{t('Birth date')}</small>}{isPicklist(field.fieldType)&&<small>{t('{0} options',(field.options??[]).filter(option=>!option.archived).length)}</small>}{field.fieldType==='reference'&&<small>{t('Link to')}: {field.targetTemplateId?world.templates.find(template=>template.id===field.targetTemplateId)?.title||t('Missing template'):t('Any template')}</small>}{review>0&&!open&&<small className="reference-review">{reviewSummary(review)}</small>}</div>
     <span className="template-field-type">{t(fieldLabels[field.fieldType])}</span>{field.archived&&<span className="template-field-archived">{t('Archived')}</span>}
     <div className="template-field-actions"><button type="button" id={`field-edit-${field.id}`} className="icon-button" aria-label={t('Edit field {0}',label)} title={t('Edit field')} aria-haspopup="dialog" onClick={()=>setEditing(open?'':field.id)}><Pencil size={15}/></button><button type="button" className="icon-button" aria-label={field.archived?t('Restore field'):t('Archive field (values are kept)')} title={field.archived?t('Restore field'):t('Archive field (values are kept)')} onClick={()=>onChange(updateField(world,template.id,field.id,{archived:!field.archived}))}>{field.archived?<ArchiveRestore size={15}/>:<Archive size={15}/>}</button><button type="button" className="icon-button template-field-delete destructive-action" aria-label={t('Delete field {0}',label)} title={used?t('This field is used by entries. Archive it to keep their values.'):t('Delete empty field')} disabled={used>0} onClick={()=>setDeleting(field.id)}><Trash2 size={15}/></button></div>
    </div>
    {open&&<FieldEditDialog label={label} onClose={()=>setEditing('')}><section className="template-field-settings" id={region} aria-label={t('Edit field {0}',label)}><label htmlFor={`field-label-${field.id}`}>{t('Field name')}</label><input id={`field-label-${field.id}`} value={field.label} placeholder={t('Untitled field')} onChange={event=>onChange(updateField(world,template.id,field.id,{label:event.target.value}))}/><label htmlFor={`field-description-${field.id}`}>{t('Description (optional)')}</label><><textarea id={`field-description-${field.id}`} rows={3} value={field.description??''} placeholder={t('Explain what this field means or how to fill it in.')} onChange={event=>onChange(updateField(world,template.id,field.id,{description:event.target.value}))}/><TextReferenceTools targetId={`field-description-${field.id}`} value={field.description??''} onChange={event=>onChange(updateField(world,template.id,field.id,{description:event.target.value}))}/></><p className="world-hint">{t('Shown from the information icon next to the field in entries.')}</p>{field.fieldType==='shortText'&&<div className="field-text-conversion"><button type="button" onClick={()=>onChange(convertToLongText(world,template.id,field.id))}>{t('Convert field to long text')}</button><p className="world-hint">{t('Keeps all values in every entry. Long text supports formatting.')}</p></div>}{field.fieldType==='date'&&<div className="birth-date-setting"><label><input type="checkbox" checked={!!field.isBirthDate} onChange={event=>onChange(setBirthDateField(world,template.id,event.target.checked?field.id:undefined))}/>{t('Use as birth date for age calculations')}</label><p className="world-hint">{t('One birth date field per template. Selecting this replaces the previous assignment without changing values.')}{field.archived?` ${t('Archived birth date fields do not calculate ages.')}`:''}</p></div>}{isPicklist(field.fieldType)&&<PicklistOptions options={field.options??[]} onChange={options=>onChange(updateField(world,template.id,field.id,{options}))}/>} {field.fieldType==='reference'&&<ReferenceTemplateSetting world={world} templateId={template.id} field={field} onChange={onChange}/>}<div className="field-section-setting"><label id={`field-section-label-${field.id}`} htmlFor={`field-section-${field.id}`}>{t('Section (optional)')}</label><Dropdown id={`field-section-${field.id}`} aria-labelledby={`field-section-label-${field.id}`} value={field.sectionId??''} options={[{value:'',label:t('No section')},...(template.sections??[]).map(section=>({value:section.id,label:section.title}))]} onChange={section=>moveField(field.id,section||undefined)}/></div></section></FieldEditDialog>}
   </div>;
  })}{!group.fields.length&&<p className="world-hint template-section-empty">{t('Move fields here using their section setting or drag a handle onto this heading.')}</p>}</div></section>)}</div>
  {template.fields.length>0&&<button type="button" className="template-add-field quick-action quick-action-text" aria-haspopup="dialog" onClick={()=>setAdding(true)}><Plus size={15}/>{t('Add field')}</button>}
 </>;
}
