import { locale, t } from './i18n';
import { storyDay } from './timelineChartLayout';
import { routeDistances } from './maps';
import type { WorldMap, MapRoute } from './maps';
/** Partial dates only raise warnings when even the widest possible interval is too short. */
export function reviewRouteTravel(map:WorldMap,route:MapRoute){
 if(!route.departure||!route.arrival)return null;
 const availableDays=storyDay(route.arrival,true)-storyDay(route.departure);
 const exact=route.departure.day!==undefined&&route.arrival.day!==undefined;
 if(availableDays<0)return {kind:'reversed' as const,availableDays,exact};
 const segments=routeDistances(map,route);
 if(!segments||!map.scale)return null;
 const distanceKm=segments.reduce((sum,distance)=>sum+distance,0),requiredDays=distanceKm/map.scale.travelKmPerDay;
 return {kind:requiredDays>availableDays+1e-9?'short' as const:'fits' as const,availableDays,requiredDays,distanceKm,exact};
}

export function travelReviewText(result:NonNullable<ReturnType<typeof reviewRouteTravel>>){
 if(result.kind==='reversed')return t('Arrival precedes departure. Review the travel dates.');
 return (!result.exact?t('With partial dates, the available time is the maximum possible.')+' ':'')+t('The route covers {0} km and needs about {1} days at the configured pace; {2} days are available.',formatTravelNumber(result.distanceKm),formatTravelNumber(result.requiredDays),formatTravelNumber(result.availableDays));
}

function formatTravelNumber(value:number){return new Intl.NumberFormat(locale(),{maximumFractionDigits:1}).format(value);}
