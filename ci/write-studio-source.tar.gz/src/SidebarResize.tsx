import { t } from './i18n';
export default function SidebarResize({ width, onChange }: { width: number; onChange: (width: number) => void }) {
  const clamp = (value: number) => Math.max(180, Math.min(340, value));
  return <div className="sidebar-resize" role="separator" aria-label={t("Resize manuscript navigation")} aria-orientation="vertical" aria-valuemin={180} aria-valuemax={340} aria-valuenow={width} tabIndex={0} onKeyDown={event => {
    if (!['ArrowLeft', 'ArrowRight', 'Home', 'End'].includes(event.key)) return;
    event.preventDefault(); onChange(event.key === 'Home' ? 180 : event.key === 'End' ? 340 : clamp(width + (event.key === 'ArrowRight' ? 16 : -16)));
  }} onPointerDown={event => { event.currentTarget.setPointerCapture(event.pointerId); }} onPointerMove={event => { if (event.currentTarget.hasPointerCapture(event.pointerId)) { const left = event.currentTarget.parentElement?.getBoundingClientRect().left ?? 0; onChange(clamp(event.clientX - left)); } }} onPointerUp={event => { if (event.currentTarget.hasPointerCapture(event.pointerId)) event.currentTarget.releasePointerCapture(event.pointerId); }} />;
}
