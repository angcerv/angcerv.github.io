import {t,buttonLabel} from './i18n';
import { useEffect, useId, useLayoutEffect, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { createPortal } from 'react-dom';
import { Check, ChevronDown } from 'lucide-react';
import { initialOption, matchingOption, nextEnabled, normalizeOptionText } from './dropdownNavigation';
import type { DropdownOption } from './dropdownNavigation';

type Props = {
  id: string; value: string; options: DropdownOption[]; onChange: (value: string) => void;
  density?:'relationship';icon?: ReactNode; variant?: 'input' | 'add' | 'badge' | 'navigation';
  searchable?: boolean; searchLabel?: string;
  disabled?: boolean; required?: boolean; placeholder?: string; selectedLabel?: string;
  'aria-invalid'?:boolean;'aria-label'?: string; 'aria-labelledby'?: string; 'aria-describedby'?: string;
};
type Position = { left: number; width: number; maxHeight: number; top?: number; bottom?: number; side: 'top' | 'bottom' };

export default function Dropdown({ id, value, options: allOptions, onChange, searchable:requestedSearch = false, searchLabel = t("Search options"), disabled = false, required = false, placeholder = buttonLabel("Choose…"), selectedLabel, icon, density,variant = 'input', ...aria }: Props) {
  const searchable=requestedSearch||density==='relationship'&&allOptions.length>8;
  const listId = useId();
  const [query, setQuery] = useState('');
  const options = searchable && query.trim() ? allOptions.filter(option => normalizeOptionText(option.searchText??option.label).includes(normalizeOptionText(query.trim()))) : allOptions;
  const searchInput = useRef<HTMLInputElement>(null);
  const trigger = useRef<HTMLButtonElement>(null);
  const popup = useRef<HTMLDivElement>(null);
  const search = useRef({ text: '', time: 0 });
  const [open, setOpen] = useState(false);
  const [active, setActive] = useState(-1);
  const [position, setPosition] = useState<Position | null>(null);
  const unavailable = disabled || allOptions.every(option => option.disabled);
  const selected = allOptions.find(option => option.value === value);
  const optionId = (index: number) => `${listId}-option-${index}`;
  function blocked() { return !trigger.current || trigger.current.matches(':disabled') || !!trigger.current.closest('[hidden], [inert]'); }
  function reveal(preferLast = false) {
    if (unavailable || blocked()) return;
    setQuery('');
    search.current = { text: '', time: 0 };
    setActive(initialOption(options, value, preferLast)); setOpen(true);
  }
  function choose(index: number) {
    if (!blocked() && options[index] && !options[index].disabled && options[index].value !== value) onChange(options[index].value);
    setOpen(false); trigger.current?.focus();
  }
  useLayoutEffect(() => {
    if (!open) return;
    const place = () => {
      if (blocked()) { setOpen(false); return; }
      const rect = trigger.current!.getBoundingClientRect();
      if (rect.bottom < 0 || rect.top > window.innerHeight) { setOpen(false); return; }
      const below = window.innerHeight - rect.bottom - 12, above = rect.top - 12;
      const side = below >= 200 || below >= above ? 'bottom' : 'top';
      const width = Math.min(Math.max(rect.width, variant==='badge'||variant==='navigation'?240:180), window.innerWidth - 16);
      setPosition({ left: Math.max(8, Math.min(rect.left, window.innerWidth - width - 8)), width, maxHeight: Math.max(0, Math.min(280, (side === 'bottom' ? below : above)-6,window.innerHeight-16)), ...(side === 'bottom' ? { top: rect.bottom + 6 } : { bottom: window.innerHeight - rect.top + 6 }), side });
    };
    place();
    const onScroll = (event: Event) => { if (!popup.current?.contains(event.target as Node)) setOpen(false); };
    window.addEventListener('resize', place);
    window.addEventListener('scroll', onScroll, true);
    return () => { window.removeEventListener('resize', place); window.removeEventListener('scroll', onScroll, true); };
  }, [open,variant]);
  useEffect(() => { if (open && searchable && position) searchInput.current?.focus(); }, [open, searchable, !!position]);
  useEffect(() => {
    if (!open) return;
    const outside = (event: Event) => {
      if (!trigger.current?.contains(event.target as Node) && !popup.current?.contains(event.target as Node)) setOpen(false);
    };
    document.addEventListener('pointerdown', outside, true);
    document.addEventListener('focusin', outside);
    // A portalled menu must also close when its source fieldset becomes disabled/inert.
    const observer = new MutationObserver(() => { if (blocked()) setOpen(false); });
    for (let node: HTMLElement | null = trigger.current; node; node = node.parentElement) observer.observe(node, { attributes: true, attributeFilter: ['disabled', 'hidden', 'inert'] });
    return () => { document.removeEventListener('pointerdown', outside, true); document.removeEventListener('focusin', outside); observer.disconnect(); };
  }, [open]);
  useEffect(() => {
    if (!open) return;
    if (!options[active] || options[active].disabled) { setActive(initialOption(options, value)); return; }
    document.getElementById(optionId(active))?.scrollIntoView({ block: 'nearest' });
  }, [open, active, options, value, listId]);
  const Container=variant==='badge'?'span':'div';
  return <Container className={`dropdown${variant === 'add' ? ' dropdown-add' : variant==='badge'?' dropdown-badge':variant==='navigation'?' dropdown-navigation':''}${density?' dropdown-relationship':''}`}>
    <button {...aria} id={id} ref={trigger} type="button" title={selected?.label??selectedLabel??placeholder} role="combobox" className="dropdown-trigger" data-semantic-tone={variant==='badge'?selected?.tone:undefined} disabled={unavailable} aria-haspopup="listbox" aria-expanded={open} aria-controls={open ? listId : undefined} aria-activedescendant={open && active >= 0 ? optionId(active) : undefined} aria-required={required || undefined} onClick={() => { if (open) setOpen(false); else reveal(); }} onKeyDown={event => {
      if (event.key === 'Escape' && open) { event.preventDefault(); event.stopPropagation(); setOpen(false); return; }
      if (event.key === 'Tab') { setOpen(false); return; }
      if (['ArrowDown', 'ArrowUp', 'Home', 'End'].includes(event.key)) {
        event.preventDefault();
        if (!open) reveal(event.key === 'ArrowUp' || event.key === 'End');
        if (event.key === 'Home') setActive(nextEnabled(options, -1, 1));
        else if (event.key === 'End') setActive(nextEnabled(options, 0, -1));
        else if (open) setActive(nextEnabled(options, active, event.key === 'ArrowDown' ? 1 : -1));
        return;
      }
      if (event.key === 'Enter' || event.key === ' ') {
        event.preventDefault(); if (open) choose(active); else reveal(); return;
      }
      if (event.key.length === 1 && !event.metaKey && !event.ctrlKey && !event.altKey) {
        event.preventDefault();
        const now = Date.now();
        const previous = now - search.current.time < 700 ? search.current.text : '';
        const text = previous + event.key;
        search.current = { text, time: now };
        const prefix = Array.from(text).every(character => character.toLocaleLowerCase() === event.key.toLocaleLowerCase()) ? event.key : text;
        const start = open ? active : options.findIndex(option => option.value === value && !option.disabled);
        const index = matchingOption(options, prefix, prefix.length === 1 ? start + 1 : start);
        if (index >= 0) { setActive(index); setOpen(true); }
      }
    }}>{icon && <span className="dropdown-icon" aria-hidden="true">{icon}</span>}<span className="dropdown-value" data-semantic-tone={selected?.tone}>{selected?.label ?? selectedLabel ?? placeholder}</span><ChevronDown size={15} className="dropdown-chevron" aria-hidden="true" /></button>
    {open && position && createPortal(<div ref={popup} className={`dropdown-menu${density?' dropdown-menu-relationship':''}`} aria-label={aria['aria-label']} aria-labelledby={aria['aria-labelledby']} data-side={position.side} style={{ left: position.left, width: position.width, maxHeight: position.maxHeight, top: position.top, bottom: position.bottom }}>
      {searchable && <input ref={searchInput} className="dropdown-search" type="search" role="combobox" aria-label={searchLabel} aria-expanded="true" aria-controls={listId} aria-activedescendant={active >= 0 ? optionId(active) : undefined} value={query} onChange={event => { setQuery(event.target.value); setActive(-1); }} onKeyDown={event => {
        if (event.key === 'Escape') { event.preventDefault(); event.stopPropagation(); setOpen(false); trigger.current?.focus(); }
        else if (event.key === 'Tab') {
          event.preventDefault(); setOpen(false);
          const controls = Array.from((trigger.current?.closest('dialog[open]') ?? document).querySelectorAll<HTMLElement>('button,input,textarea,select,a[href],[tabindex="0"]')).filter(element => !element.matches(':disabled') && !element.closest('[hidden],[inert]') && element.getClientRects().length > 0 && !popup.current?.contains(element));
          const index = controls.indexOf(trigger.current!);
          (controls[index + (event.shiftKey ? -1 : 1)] ?? trigger.current)?.focus();
        }
        else if (event.key === 'Enter') { event.preventDefault(); if (active >= 0) choose(active); }
        else if (['ArrowDown','ArrowUp'].includes(event.key)) { event.preventDefault(); setActive(nextEnabled(options, active, event.key === 'ArrowUp' ? -1 : 1)); }
      }} />}
      <div id={listId} role="listbox" aria-label={aria['aria-label']} aria-labelledby={aria['aria-labelledby']}>
      {options.map((option, index) => <div id={optionId(index)} key={option.value} role="option" title={option.label} aria-selected={option.value === value} aria-disabled={option.disabled || undefined} className={`dropdown-option${index === active ? ' highlighted' : ''}`} onPointerMove={() => { if (!option.disabled) setActive(index); }} onMouseDown={event => event.preventDefault()} onClick={() => { if (!option.disabled) choose(index); }}><span className={option.tone?'semantic-label':undefined} data-semantic-tone={option.tone}>{option.label}</span>{option.value === value && <Check size={14} aria-hidden="true" />}</div>)}
      </div>{options.length === 0 && <p className="dropdown-empty" role="status">{t("No matching entries.")}</p>}
    </div>, trigger.current?.closest('dialog[open],[data-relationship-options]') ?? document.body)}
  </Container>;
}
