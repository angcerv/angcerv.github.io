import {bookChapterLabel} from './books';
import {longTextPlainText} from './longText';
import {textReferencePlainText} from './textReferenceTokens';
import {projectPendingItems} from './pendingItems';
import type {PendingItem} from './pendingItems';
import { t } from './i18n';
import { eventDateLabel } from './timeline';
import { fromMarkdown } from './model';
import type { Project } from './model';
import { displayFieldValue } from './worldbuilding';
export const searchScopes={all:'All sections',manuscript:'Manuscript',worldbuilding:'Worldbuilding',plots:'Plots',arcs:'Character arcs',timeline:'Timeline',planning:'Planning',pending:'Pending',maps:'Maps'} as const;
export type SearchScope=keyof typeof searchScopes;
export const searchKindLabels={chapter:'Chapters',scene:'Scenes',entry:'Entries',event:'Events',arc:'Character arcs',chapterPlan:'Chapter planning',scenePlan:'Scene intention',plot:'Plots',idea:'Ideas and decisions',pending:'Pending',map:'Maps',route:'Map routes',marker:'Map markers'} as const;
export type SearchResult = {kind:keyof typeof searchKindLabels;id:string;title:string;context:string;excerpt:string;archived:boolean;synopsis?:boolean;sceneId?:string;mapId?:string;pending?:PendingItem};
export type SearchOptions={scope?:SearchScope;includeArchived?:boolean};
type SearchField={text:string;synopsis?:boolean;sceneId?:string;context?:string};
export type ProjectSearchDocument={result:Omit<SearchResult,'excerpt'>;fields:SearchField[];folded:string[];title:string};
const scopes:Record<SearchResult['kind'],SearchScope>={chapter:'manuscript',scene:'manuscript',entry:'worldbuilding',event:'timeline',arc:'arcs',chapterPlan:'planning',scenePlan:'planning',plot:'plots',idea:'pending',pending:'pending',map:'maps',route:'maps',marker:'maps'};
const fold = (value: string) => value.normalize('NFD').replace(/\p{M}/gu, '').toLocaleLowerCase();
export function matchRange(text: string, query: string): [number, number] | null {
  const needle = fold(query.trim());
  if (!needle) return null;
  let folded = '', offset = 0;
  const positions: number[] = [];
  for (const character of text) {
    const value = fold(character);
    for (let i = 0; i < value.length; i++) positions.push(offset);
    folded += value; offset += character.length;
  }
  const index = folded.indexOf(needle);
  if (index < 0) return null;
  const start = positions[index], last = positions[index + needle.length - 1];
  return [start, last + (text.codePointAt(last)! > 0xffff ? 2 : 1)];
}
function snippet(text: string, query: string): string {
  const compact = textReferencePlainText(text).replace(/\s+/gu, ' ').trim();
  const range = matchRange(compact, query);
  const start = Math.max(0, (range?.[0] ?? 0) - 65), end = Math.min(compact.length, Math.max(start + 180, range?.[1] ?? 0));
  return `${start ? '…' : ''}${compact.slice(start, end)}${end < compact.length ? '…' : ''}`;
}
/** Parse rich text and derive pending items once per project snapshot, not per key. */
export function buildProjectSearchIndex(project:Project):ProjectSearchDocument[]{
 const index:ProjectSearchDocument[]=[],world=project.worldbuilding;
 function add(result:Omit<SearchResult,'excerpt'>,fields:(string|SearchField)[]){
  const values=fields.map(value=>typeof value==='string'?{text:value}:value).filter(field=>field.text.trim());
  const all=[{text:result.title},...values,{text:result.context}];
  index.push({result,fields:all,folded:all.map(field=>fold(textReferencePlainText(field.text))),title:fold(textReferencePlainText(result.title))});
 }
 const location=new Map(project.chapters.flatMap(chapter=>chapter.scenes.map(scene=>[scene.id,`${bookChapterLabel(project,chapter.id)||t('Untitled chapter')} / ${scene.title||t('Untitled scene')}`] as const)));
 const beatFields=(sceneId:string,texts:string[],parent:string)=>texts.map(text=>({text:longTextPlainText(text),sceneId,context:`${parent} · ${location.get(sceneId)??t('Deleted scene')}`}));
 for(const chapter of project.chapters){
  add({kind:'chapter',id:chapter.id,title:chapter.title||t('Untitled chapter'),context:[t('Chapter'),project.books?.find(book=>book.chapterIds.includes(chapter.id))?.title].filter(Boolean).join(' · '),archived:false},[{text:textReferencePlainText(chapter.synopsis??''),synopsis:true}]);
  if(chapter.planning)add({kind:'chapterPlan',id:chapter.id,title:chapter.title||t('Untitled chapter'),context:[t('Chapter planning'),project.books?.find(book=>book.chapterIds.includes(chapter.id))?.title].filter(Boolean).join(' · '),archived:false},[chapter.planning.purpose,chapter.planning.conflict,chapter.planning.turn,chapter.planning.outcome,chapter.planning.notes].map(longTextPlainText));
  for(const scene of chapter.scenes){
   const text=fromMarkdown(scene.content).content?.map(paragraph=>paragraph.content?.map(node=>node.type==='hardBreak'?'\n':node.text??'').join('')??'').join('\n\n')??'';
   add({kind:'scene',id:scene.id,title:scene.title||t('Untitled scene'),context:bookChapterLabel(project,chapter.id)||t('Untitled chapter'),archived:false},[{text:textReferencePlainText(scene.synopsis??''),synopsis:true},text,chapter.title]);
   if(scene.planning)add({kind:'scenePlan',id:scene.id,title:scene.title||t('Untitled scene'),context:`${t('Scene intention')} · ${bookChapterLabel(project,chapter.id)}`,archived:false},[scene.planning.goal,scene.planning.conflict,scene.planning.change].map(longTextPlainText));
  }
 }
 for(const entry of world?.entries??[]){
  const template=world?.templates.find(template=>template.id===entry.templateId);
  const fields=(template?.fields??[]).flatMap(field=>{const value=entry.values[field.id];if(value===null||value===undefined||value==='')return [];const text=typeof value==='boolean'?`${value} · ${displayFieldValue(field,value,world)}`:displayFieldValue(field,value,world);return [`${field.label}${field.archived?` · ${t('Archived field')}`:''}: ${text}`];});
  add({kind:'entry',id:entry.id,title:entry.title||t('Untitled entry'),context:template?.title||t('Untitled template'),archived:entry.archived},[...(entry.linkAliases??[]),...fields]);
 }
 for(const event of project.timeline?.events??[])add({kind:'event',id:event.id,title:event.title||t('Untitled event'),context:`${t('Timeline')} · ${eventDateLabel(event)}`,archived:false},[longTextPlainText(event.notes),eventDateLabel(event)]);
 for(const plot of project.plots?.threads??[])add({kind:'plot',id:plot.id,title:plot.title||t('Untitled plot'),context:t('Plots'),archived:false},[longTextPlainText(plot.notes),...plot.beats.flatMap(beat=>beatFields(beat.sceneId,[beat.note],plot.title))]);
 for(const arc of project.plots?.arcs??[]){
  const character=world?.entries.find(entry=>entry.id===arc.entryId)?.title??t('Deleted entry');
  add({kind:'arc',id:arc.id,title:arc.title||t('Untitled arc'),context:`${t('Character arcs')} · ${character}`,archived:false},[character,...[arc.startingPoint,arc.desire,arc.innerConflict,arc.resolution,arc.notes].map(longTextPlainText),...arc.beats.flatMap(beat=>beatFields(beat.sceneId,[beat.note,beat.goal,beat.conflict,beat.relationships],arc.title))]);
 }
 const pending=projectPendingItems(project);
 for(const item of pending){
  if(item.idea){add({kind:'idea',id:item.idea.id,title:item.title,context:item.context,archived:!['idea','deciding','decided'].includes(item.idea.status),pending:item},[longTextPlainText(item.idea.description),longTextPlainText(item.idea.decision??''),...(item.idea.fragments??[]).map(fragment=>fragment.quote)]);}
  else add({kind:'pending',id:item.id,title:item.title,context:item.context,archived:false,pending:item},[textReferencePlainText(item.detail)]);
 }
 for(const map of project.maps?.maps??[]){
  add({kind:'map',id:map.id,title:map.title||t('Untitled map'),context:t('Maps'),archived:false},[longTextPlainText(map.notes)]);
  for(const marker of map.markers)add({kind:'marker',id:marker.id,mapId:map.id,title:marker.title||t('Untitled marker'),context:map.title||t('Untitled map'),archived:false},[longTextPlainText(marker.notes),world?.entries.find(entry=>entry.id===marker.entryId)?.title??'']);
  for(const route of map.routes??[])add({kind:'route',id:route.id,mapId:map.id,title:route.title||t('Untitled route'),context:map.title||t('Untitled map'),archived:false},[longTextPlainText(route.notes)]);
 }
 return index;
}
export function searchProjectIndex(index:ProjectSearchDocument[],query:string,options:SearchOptions={}):SearchResult[]{
 const needle=fold(query.trim());if(!needle)return [];
 const matches=index.flatMap((document,order)=>{
  if(options.scope&&options.scope!=='all'&&scopes[document.result.kind]!==options.scope||options.includeArchived===false&&document.result.archived)return [];
  const match=document.folded.findIndex(text=>text.includes(needle));if(match<0)return [];
  const field=document.fields[match],excerptField=match===0?document.fields.find((_,i)=>i>0&&document.folded[i].includes(needle))??document.fields[1]:field;
  const score=document.title===needle?100:document.title.startsWith(needle)?80:match===0?60:30;
  return [{order,score,result:{...document.result,context:field.context??document.result.context,excerpt:snippet(excerptField?.text??'',query),...(field.synopsis?{synopsis:true,context:`${document.result.context} · ${t(document.result.kind==='chapter'?'Chapter synopsis':'Scene synopsis')}`} :{}),...(field.sceneId?{sceneId:field.sceneId}:{})}}];
 });
 return matches.sort((a,b)=>b.score-a.score||a.order-b.order).map(item=>item.result);
}
export function searchProject(project:Project,query:string,options:SearchOptions={}):SearchResult[]{return query.trim()?searchProjectIndex(buildProjectSearchIndex(project),query,options):[];}
