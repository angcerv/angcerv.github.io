import {focusDialog} from './dialogFocus';
import { useEffect, useRef } from 'react';
import { createPortal } from 'react-dom';
import { t } from './i18n';
import type { MentionAction } from './manuscriptMentions';
export default function MentionActionDialog({action,onApply,onClose,onReset}:{action:MentionAction;onApply:()=>void;onClose:()=>void;onReset?:()=>void}){
 const dialog=useRef<HTMLDialogElement>(null),previous=useRef(document.activeElement as HTMLElement|null);
 useEffect(()=>{const node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous.current?.isConnected)previous.current.focus();};},[]);
 return createPortal(<dialog ref={dialog} className="field-create-dialog" aria-labelledby="mention-action-title" onCancel={event=>{event.preventDefault();onClose();}}><header><h2 id="mention-action-title">{action.text}</h2></header><div className="field-create-body"><p>{t('This changes only this occurrence. Other mentions and manual links are kept.')}</p></div><footer>{onReset&&<button type="button" onClick={onReset} className="quick-action quick-action-text">{t('Use automatic matching')}</button>}<button type="button" onClick={onClose} className="quick-action quick-action-text">{t('Cancel')}</button><button type="button" className="primary-button" onClick={onApply}>{action.ignored?t('Restore link'):t('Unlink this mention')}</button></footer></dialog>,document.body);
}
