import {partnershipLabel} from './partnership';
import type {VisualResource} from './visualResources';
import {entryImageIds,visualResources,visualResourceDescription} from './visualResources';
import type {JSONContent} from '@tiptap/react';
import type {Project} from './model';
import {suggestFolderName} from './model';
import {emptyWorld,displayFieldValue,isEntryReference} from './worldbuilding';
import type {Entry,Field,Template} from './worldbuilding';
import {fieldGroups} from './templateSections';
import {hasLoreValue,loreIntroduction} from './worldLore';
import {longTextDocument} from './longText';
import {textReferences} from './textReferenceTokens';
import {connectionDateLabel,emptyEntryRelations,entryConnections,isFormerPartner} from './entryRelations';
import {locale,t,getLanguage} from './i18n';
export const encyclopediaExportLimit=32*1024*1024;
export const encyclopediaExportTooLarge='This single-file encyclopedia is too large. Choose ZIP with separate images instead.';
export type EncyclopediaFormat='zip'|'html'|'md';
export type EncyclopediaOptions={templateIds:string[];archivedEntries:boolean;archivedFields:boolean;relations:boolean;backlinks:boolean;images:boolean};
export const missingTemplateCategory='__missing-template__';
export function encyclopediaCategories(project:Project){
 const world=project.worldbuilding??emptyWorld;
 return [...world.templates.map(template=>({id:template.id,title:template.title||t('Untitled template')})),...(world.entries.some(entry=>!world.templates.some(template=>template.id===entry.templateId))?[{id:missingTemplateCategory,title:t('Missing template')}]:[])];
}
export const defaultEncyclopediaOptions=(project:Project):EncyclopediaOptions=>({templateIds:encyclopediaCategories(project).map(category=>category.id),archivedEntries:false,archivedFields:false,relations:true,backlinks:true,images:true});
export function encyclopediaSelection(project:Project,options:EncyclopediaOptions){
 const world=project.worldbuilding??emptyWorld;
 return encyclopediaCategories(project).filter(category=>options.templateIds.includes(category.id)).map(category=>({...category,entries:world.entries.filter(entry=>(options.archivedEntries||!entry.archived)&&(category.id===missingTemplateCategory?!world.templates.some(template=>template.id===entry.templateId):entry.templateId===category.id)).sort((a,b)=>a.title.localeCompare(b.title,locale(),{numeric:true,sensitivity:'base'})||a.id.localeCompare(b.id))})).filter(category=>category.entries.length);
}
export function encyclopediaPackageImages(project:Project,options:EncyclopediaOptions){
 if(!options.images)return [];
 return [...new Set(encyclopediaSelection(project,options).flatMap(category=>category.entries).flatMap(entryImageIds))].sort().map((id,index)=>({id,filename:`images/image-${index+1}.png`}));
}
export const encyclopediaFilename=(title:string,format:EncyclopediaFormat)=>`${suggestFolderName(title)}-${t('encyclopedia')}.${format}`;
const html=(value:string)=>value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');
const md=(value:string)=>value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/[\\`*_[\]{}#!|~+\-.()]/g,'\\$&');
const oneLine=(value:string)=>value.replace(/[\r\n]+/g,' ');
const anchor=(id:string)=>`entry-${encodeURIComponent(id)}`;
function fallbackTemplate(entry:Entry):Template{
 return {schemaVersion:1,id:entry.templateId,title:t('Missing template'),fields:Object.keys(entry.values).map(id=>({id,label:id,archived:false,fieldType:typeof entry.values[id]==='string'?'longText':isEntryReference(entry.values[id])?'reference':typeof entry.values[id]==='boolean'?'boolean':typeof entry.values[id]==='object'&&!Array.isArray(entry.values[id])?'date':'shortText'}))};
}
export function exportEncyclopedia(project:Project,options:EncyclopediaOptions,format:EncyclopediaFormat,images:Record<string,string>={}):string{
 const packaged=format==='zip';
 if(packaged){images=Object.fromEntries(encyclopediaPackageImages(project,options).map(image=>[image.id,image.filename]));format='html';}
 const imageSource=(id:string)=>packaged?!!images[id]:/^data:image\/(?:png|jpeg|webp);base64,[A-Za-z0-9+/=]+$/.test(images[id]??'');
 const categories=encyclopediaSelection(project,options),entries=categories.flatMap(category=>category.entries),selected=new Set(entries.map(entry=>entry.id)),world=project.worldbuilding??emptyWorld,byId=new Map(world.entries.map(entry=>[entry.id,entry]));
 if(!entries.length)throw new Error(t('Select at least one category with entries to export.'));
 const resources=new Map(visualResources(world).map(resource=>[resource.id,resource]));
 const imageDescription=(resource:VisualResource)=>visualResourceDescription(resource,resource.variantOf?resources.get(resource.variantOf)?.title:undefined);
 const escape=format==='html'?html:md;
 const title=(text:string)=>escape(oneLine(text));
 const heading=(level:number,text:string)=>format==='html'?`<h${level}>${title(text)}</h${level}>`:`${'#'.repeat(level)} ${title(text)}`;
 function reference(id:string,label?:string){
  const target=byId.get(id),name=escape(label??target?.title??t('Missing entry'));
  if(selected.has(id))return format==='html'?`<a href="#${anchor(id)}">${name}</a>`:`[${name}](#${anchor(id)})`;
  const reason=t(target?'Not included in this export':'Missing entry');
  return format==='html'?`<span class="unavailable">${name} <small>(${html(reason)})</small></span>`:`${name} (${md(reason)})`;
 }
 function renderNode(node:JSONContent):string{
  if(node.type==='entryMention'||node.type==='text'){
   let output=node.type==='entryMention'?reference(node.attrs?.entryId,node.attrs?.label??''):escape(node.text??'');
   for(const mark of node.marks??[]){if(mark.type==='bold')output=format==='html'?`<strong>${output}</strong>`:`**${output}**`;if(mark.type==='italic')output=format==='html'?`<em>${output}</em>`:`_${output}_`;if(mark.type==='underline')output=`<u>${output}</u>`;}
   return output;
  }
  if(node.type==='hardBreak')return format==='html'?'<br>':'  \n';
  const children=(node.content??[]).map(renderNode);
  if(format==='html'){const tag=node.type==='paragraph'?'p':node.type==='bulletList'?'ul':node.type==='listItem'?'li':'';return tag?`<${tag}>${children.join('')}</${tag}>`:children.join('');}
  if(node.type==='doc'||node.type==='listItem')return children.join('\n\n');
  if(node.type==='bulletList')return children.map(child=>'- '+child.replace(/\n/g,'\n  ')).join('\n');
  return children.join('');
 }
 function plain(value:string){
  let result='',offset=0;for(const ref of textReferences(value)){result+=escape(value.slice(offset,ref.from))+reference(ref.entryId,ref.label);offset=ref.to;}return result+escape(value.slice(offset));
 }
 const prose=(value:string)=>{const content=renderNode(longTextDocument(value));return format==='html'?`<div class="entry-prose">${content}</div>`:content;};
 const data=(field:Field,value:Entry['values'][string]|undefined)=>{
  if(isEntryReference(value))return reference(value.entryId);
  if(typeof value==='string'&&field.fieldType==='longText')return prose(value);
  if(typeof value==='string'&&field.fieldType==='shortText')return plain(value).replace(/\n/g,format==='html'?'<br>':'  \n');
  return escape(displayFieldValue(field,value,world));
 };
 const paragraph=(value:string)=>format==='html'?`<p>${value}</p>`:value;
 const list=(values:string[])=>format==='html'?`<ul>${values.map(value=>`<li>${value}</li>`).join('')}</ul>`:values.map(value=>'- '+value).join('\n');
 const templates=new Map(entries.map(entry=>[entry.id,world.templates.find(template=>template.id===entry.templateId)??fallbackTemplate(entry)]));
 const fieldsFor=(entry:Entry)=>templates.get(entry.id)!.fields.filter(field=>(options.archivedFields||!field.archived)&&hasLoreValue(field,entry.values[field.id]));
 const backlinks=new Map<string,Set<string>>();
 if(options.backlinks)for(const entry of entries)for(const field of fieldsFor(entry)){
  const value=entry.values[field.id],targets=isEntryReference(value)?[value.entryId]:typeof value==='string'&&['shortText','longText'].includes(field.fieldType)?textReferences(value).map(ref=>ref.entryId):[];
  for(const id of targets)if(selected.has(id)&&id!==entry.id){const sources=backlinks.get(id)??new Set<string>();sources.add(entry.id);backlinks.set(id,sources);}
 }
 let outputSize=0;
 const parts:string[]=[];
 const append=(...values:string[])=>{for(const value of values){outputSize+=value.length+2;if(outputSize>encyclopediaExportLimit)throw new Error(t(packaged||format==='md'?'The encyclopedia text is too large. Select fewer categories.':encyclopediaExportTooLarge));parts.push(value);}};
 append(heading(1,project.title||t('Untitled project')),paragraph(escape(t('World encyclopedia'))),heading(2,t('Contents')));
 for(const category of categories){
  append(heading(3,category.title),list(category.entries.map(entry=>reference(entry.id,entry.title||t('Untitled entry')))));
 }
 for(const category of categories){
  append(heading(2,category.title));
  for(const entry of category.entries){
   const template=templates.get(entry.id)!,intro=loreIntroduction(template,entry),activeFields=fieldsFor(entry),groups=fieldGroups(template,!options.archivedFields).map(group=>({...group,fields:group.fields.filter(field=>activeFields.some(active=>active.id===field.id)&&field.id!==intro?.id)})).filter(group=>group.fields.length);
   if(format==='html')append(`<article id="${anchor(entry.id)}" class="entry">`);else append(`<a id="${anchor(entry.id)}"></a>`);
   append(heading(3,entry.title||t('Untitled entry')));
   if(entry.archived)append(paragraph(escape(t('Archived'))));
   if(entry.linkAliases?.length)append(paragraph(`${escape(t('Also known as'))}: ${escape(entry.linkAliases.join(' · '))}`));
   if(format==='html'&&options.images&&entry.imageId&&imageSource(entry.imageId))append(`<img class="portrait" src="${images[entry.imageId]}" alt="${html(entry.title)}">`);
   if(format==='html'&&options.images&&entry.imageId&&images[entry.imageId]){const main=resources.get(entry.imageId);if(main&&(imageDescription(main)||main.title!==entry.title))append(`<p class="image-caption">${html(main.title)}${imageDescription(main)?` · ${html(imageDescription(main))}`:''}</p>`);}
   if(format==='html'&&options.images){for(const id of entryImageIds(entry).filter(id=>id!==entry.imageId)){if(imageSource(id)){const resource=resources.get(id);append(`<figure class="gallery-image"><img src="${images[id]}" alt="${html(resource?.title??entry.title)}"><figcaption>${html(resource?.title??entry.title)}${resource&&imageDescription(resource)?` · ${html(imageDescription(resource))}`:''}</figcaption></figure>`);}}}
   if(intro)append(prose(entry.values[intro.id] as string));
   for(const group of groups){
    append(heading(4,group.title));
    for(const field of group.fields){append(heading(5,field.label||t('Untitled field')),data(field,entry.values[field.id]));}
   }
   if(!activeFields.length)append(paragraph(escape(t('This entry has no filled fields yet.'))));
   if(options.relations){
    const lineages=(project.entryRelations?.lineages??[]).filter(lineage=>lineage.memberIds.includes(entry.id));
    if(lineages.length)append(heading(4,t('Family lineages')),list(lineages.map(lineage=>escape(lineage.name))));
    const connections=entryConnections(project.entryRelations??emptyEntryRelations,entry.id);
    if(connections.length)append(heading(4,t('Entry relationships')),list(connections.map(({entryId,type,link,currentRole,relatedRole})=>{
     const role=type.needsRoleReview?t('Roles pending review'):type.symmetric?(isFormerPartner(type,link)?t('Former partners'):currentRole):`${t('Role')}: ${currentRole} · ${relatedRole}`;
     return `${escape(role)}: ${reference(entryId)}${partnershipLabel(link)?` · ${escape(t(partnershipLabel(link)!))}`:''}${connectionDateLabel(link)?` · ${escape(connectionDateLabel(link))}`:''}`;
    })));
   }
   const sources=backlinks.get(entry.id);if(sources?.size)append(heading(4,t('Referenced by')),list([...sources].map(id=>reference(id))));
   if(format==='html')append(`<a class="back-to-index" href="#contents">${html(t('Back to contents'))}</a></article>`);
  }
 }
 if(format==='md')return parts.join('\n\n')+'\n';
 const content=parts.join('\n').replace(`<h2>${html(t('Contents'))}</h2>`,`<h2 id="contents">${html(t('Contents'))}</h2>`);
 return `<!doctype html>\n<html lang="${getLanguage()}"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta http-equiv="Content-Security-Policy" content="default-src 'none'; img-src ${packaged?"'self' file:":'data:'}; style-src 'unsafe-inline'; base-uri 'none'; form-action 'none'"><title>${html(project.title)} · ${html(t('World encyclopedia'))}</title><style>${encyclopediaStyles}</style></head><body><main>${content}</main></body></html>`;
}
const encyclopediaStyles=`.image-caption{clear:both;font-size:12px;color:#68757b}.gallery-image{clear:both;margin:24px 0;break-inside:avoid}.gallery-image img{max-width:100%;max-height:500px;object-fit:contain}.gallery-image figcaption{font-size:12px;color:#68757b}:root{color-scheme:light;font-family:system-ui,-apple-system,sans-serif;color:#283238;background:#f4f5f3}*{box-sizing:border-box}body{margin:0}main{max-width:1000px;margin:0 auto;padding:54px 60px;background:white;min-height:100vh}h1,h2,h3{font-family:Georgia,serif;font-weight:500;line-height:1.2}h1{font-size:40px;margin:0 0 12px}h2{font-size:28px;border-bottom:1px solid #dbe2e1;padding-bottom:10px;margin:44px 0 18px}h3{font-size:25px;margin:0 0 16px}h4{font-family:Georgia,serif;font-size:24px;font-weight:600;line-height:1.3;color:#235d63;background:#edf3f2;border-left:4px solid #235d63;border-radius:0 8px 8px 0;padding:12px 16px;margin:36px 0 24px;overflow-wrap:anywhere}h5{font-family:system-ui,-apple-system,sans-serif;font-size:12px;font-weight:700;line-height:1.6;text-transform:uppercase;letter-spacing:.09em;color:#59676d;margin:26px 0 10px;overflow-wrap:anywhere}.entry-prose{border-left:1px solid #dbe2e1;padding-left:18px}.entry-prose>:first-child{margin-top:0}.entry-prose strong{font-weight:650;color:#283238}p,li{font-size:14px;line-height:1.85;overflow-wrap:anywhere}p{margin:8px 0 14px}a{color:#235d63;text-decoration-thickness:1px;text-underline-offset:3px}ul{padding-left:22px}.entry{padding:28px 0 40px;border-bottom:1px solid #dbe2e1;display:flow-root;scroll-margin-top:24px}.portrait{float:right;width:210px;max-height:280px;object-fit:contain;margin:0 0 22px 28px;border-radius:8px}.back-to-index{display:block;clear:both;font-size:11px;margin-top:24px}.unavailable{color:#68757b}.unavailable small{font-size:.8em}a:focus-visible{outline:2px solid #235d63;outline-offset:3px}@media(max-width:650px){main{padding:26px 20px}.portrait{float:none;display:block;margin:0 0 20px;max-width:100%}h1{font-size:30px}}@media print{:root{background:white}main{padding:0;max-width:none}.entry{border:0;padding-top:12px}.entry+.entry{break-before:page}h2{break-before:page}h2,h3,h4,h5{break-after:avoid}.portrait{max-height:220px}.back-to-index{display:none}a{color:inherit}h1{font-size:30px}@page{size:A4;margin:20mm}}`;
export async function encyclopediaImageData(project:Project,options:EncyclopediaOptions,read:(imageId:string)=>Promise<Blob>):Promise<Record<string,string>>{
 const result:Record<string,string>={};if(!options.images)return result;let total=0;
 for(const id of new Set(encyclopediaSelection(project,options).flatMap(category=>category.entries).flatMap(entryImageIds)))if(!result[id]){
  let blob:Blob;try{blob=await read(id);}catch{throw new Error(t('An entry image could not be read. Retry or export without images.'));}
  total+=blob.size;if(total>encyclopediaExportLimit/2)throw new Error(t(encyclopediaExportTooLarge));
  const bytes=new Uint8Array(await blob.arrayBuffer());let binary='';for(let i=0;i<bytes.length;i+=8192)binary+=String.fromCharCode(...bytes.subarray(i,i+8192));
  const type=['image/png','image/jpeg','image/webp'].includes(blob.type)?blob.type:'image/png';
  result[id]=`data:${type};base64,${btoa(binary)}`;
 }
 return result;
}
