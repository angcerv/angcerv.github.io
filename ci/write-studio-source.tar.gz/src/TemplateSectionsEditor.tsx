import {focusDialog} from './dialogFocus';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { ArrowUp, ArrowDown, Plus, Settings2, Trash2, X } from 'lucide-react';
import { t, message } from './i18n';
import { addSection, renameSection, deleteSection, reorderSection } from './templateSections';
import type { Template, TemplateSection, Worldbuilding } from './worldbuilding';

function SectionName({section,onRename}:{section:TemplateSection;onRename:(title:string)=>boolean}) {
 const [title,setTitle]=useState(section.title);
 useEffect(()=>setTitle(section.title),[section.title]);
 return <input aria-label={t('Section name')} value={title} onChange={event=>setTitle(event.target.value)} onBlur={()=>{if(title!==section.title&&!onRename(title))setTitle(section.title);}} onKeyDown={event=>{if(event.key==='Enter'){event.preventDefault();event.currentTarget.blur();}}}/>;
}
export function SectionsDialog({world,template,onChange,onClose}:{world:Worldbuilding;template:Template;onChange:(world:Worldbuilding)=>void;onClose:()=>void}) {
 const dialog=useRef<HTMLDialogElement>(null);
 const previous=useRef(typeof document==='undefined'?null:document.activeElement as HTMLElement|null);
 const [name,setName]=useState(''),[error,setError]=useState('');
 useEffect(()=>{const node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous.current?.isConnected)previous.current.focus();};},[]);
 function perform(work:()=>Worldbuilding){try{onChange(work());setError('');return true;}catch(error){setError(String(error));return false;}}
 const content=<dialog ref={dialog} className="field-create-dialog template-sections-dialog" aria-labelledby="template-sections-title" onCancel={event=>{event.preventDefault();onClose();}}>
  <header><h2 id="template-sections-title">{t('Manage sections')}</h2><button title={t("Close")} type="button" className="icon-button ui-close-button" aria-label={t('Close')} onClick={onClose}><X size={18}/></button></header>
  <div className="template-sections-body"><p className="world-hint">{t('Group related fields. Deleting a section moves its fields to No section without removing values.')}</p>
   <div className="template-section-list">{(template.sections??[]).map((section,index)=><div key={section.id}>
    <SectionName section={section} onRename={title=>perform(()=>renameSection(world,template.id,section.id,title))}/>
    <button type="button" className="icon-button" aria-label={t('Move section up')} disabled={!index} onClick={()=>perform(()=>reorderSection(world,template.id,section.id,-1))}><ArrowUp size={14}/></button>
    <button type="button" className="icon-button" aria-label={t('Move section down')} disabled={index===(template.sections?.length??0)-1} onClick={()=>perform(()=>reorderSection(world,template.id,section.id,1))}><ArrowDown size={14}/></button>
    <button type="button" className="icon-button destructive-action" aria-label={t('Delete section {0}',section.title)} title={t('Fields and their values will be kept.')} onClick={()=>perform(()=>deleteSection(world,template.id,section.id))}><Trash2 size={14}/></button>
   </div>)}</div>
   <form className="template-section-add" onSubmit={event=>{event.preventDefault();if(perform(()=>addSection(world,template.id,name)))setName('');}}><input aria-label={t('New section name')} placeholder={t('New section name')} value={name} onChange={event=>setName(event.target.value)}/><button type="submit" disabled={!name.trim()}><Plus size={14}/>{t('Add section')}</button></form>
   {error&&<p role="alert" className="prompt-error">{message(error)}</p>}
  </div>
 </dialog>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}
export default function TemplateSectionsEditor({world,template,onChange}:{world:Worldbuilding;template:Template;onChange:(world:Worldbuilding)=>void}) {
 const [open,setOpen]=useState(false);
 return <><button type="button" className="template-sections-trigger" aria-label={t('Manage sections')} aria-haspopup="dialog" aria-expanded={open} onClick={()=>setOpen(true)}><strong>{t('Sections')}</strong><span>{template.sections?.length??0}<Settings2 size={16}/></span></button>{open&&<SectionsDialog world={world} template={template} onChange={onChange} onClose={()=>setOpen(false)}/>}</>;
}
