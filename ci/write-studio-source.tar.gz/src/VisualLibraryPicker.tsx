import {useId,useRef,useState} from 'react';
import {Check,Search,X} from 'lucide-react';
import ProjectModal from './ProjectModal';
import Dropdown from './Dropdown';
import {EntryThumbnail,EntryPortrait} from './EntryImage';
import {VisualResourceDetails,visualUsageSummary} from './VisualResourceDetails';
import {visualResourceUsage} from './visualResourceUsage';
import {filterVisualResources,visualResources,visualCategoryLabels} from './visualResources';
import type {Worldbuilding} from './worldbuilding';
import {t,message} from './i18n';

export default function VisualLibraryPicker({world,excluded,projectPath,projectId,onClose,onChoose}:{world:Worldbuilding;excluded:string[];projectPath?:string;projectId?:string;onClose:()=>void;onChoose:(ids:string[])=>void}){
 const id=useId(),previewTrigger=useRef<HTMLButtonElement|null>(null);
 const [error,setError]=useState('');
 const [query,setQuery]=useState(''),[category,setCategory]=useState(''),[usage,setUsage]=useState('all');
 const [selected,setSelected]=useState<string[]>([]),[previewId,setPreviewId]=useState('');
 const all=visualResources(world),available=all.filter(resource=>!excluded.includes(resource.id));
 const resources=filterVisualResources(available,query,category).filter(resource=>usage==='all'||(usage==='linked')===!!visualResourceUsage(world,resource.id).length);
 const validSelected=selected.filter(imageId=>available.some(resource=>resource.id===imageId));
 const preview=available.find(resource=>resource.id===previewId);
 const filtered=!!(query.trim()||category||usage!=='all');
 function clearFilters(){setQuery('');setCategory('');setUsage('all');}
 function toggle(imageId:string){setPreviewId(imageId);setSelected(current=>current.includes(imageId)?current.filter(value=>value!==imageId):[...current,imageId]);}
 return <ProjectModal title={t('Add images from library')} onClose={onClose} className="visual-library-picker">
  <div className="visual-picker-filters visual-library">
   <div className="ui-form-field visual-picker-search"><label htmlFor={`${id}-search`}>{t('Search visual resources')}</label><span><Search size={16} aria-hidden="true"/><input id={`${id}-search`} type="search" value={query} onChange={event=>setQuery(event.target.value)}/></span></div>
   <div className="ui-form-field"><label htmlFor={`${id}-category`}>{t('Image category')}</label><Dropdown id={`${id}-category`} value={category} options={[{value:'',label:t('All image categories')},{value:'unclassified',label:t('Unclassified')},...Object.entries(visualCategoryLabels).map(([value,label])=>({value,label:t(label)}))]} onChange={setCategory}/></div>
   <div className="ui-form-field"><label htmlFor={`${id}-usage`}>{t('Resource links')}</label><Dropdown id={`${id}-usage`} value={usage} onChange={setUsage} options={[{value:'all',label:t('All resources')},{value:'linked',label:t('With current links')},{value:'unlinked',label:t('Without current links')}]}/></div>
  </div>
  <div className="visual-picker-summary"><span role="status">{t('{0} images',resources.length)}</span><div>{filtered&&<button type="button" className="quick-action quick-action-text" onClick={clearFilters}>{t('Clear filters')}</button>}<button type="button" className="quick-action quick-action-text" disabled={!resources.some(resource=>!validSelected.includes(resource.id))} onClick={()=>setSelected(current=>[...new Set([...current,...resources.map(resource=>resource.id)])])}>{t('Select visible images')}</button></div></div>
  {error&&<p className="prompt-error" role="alert">{error}</p>}
  <div className={`visual-picker-body${preview?' has-preview':''}`}>
   <div className="visual-picker-results">
    <div className="visual-picker-grid">{resources.map(resource=><button type="button" key={resource.id} className="visual-picker-card" aria-pressed={validSelected.includes(resource.id)} onClick={event=>{previewTrigger.current=event.currentTarget;toggle(resource.id);}} title={resource.title}>
     <EntryThumbnail projectPath={projectPath} projectId={projectId} imageId={resource.id} title={resource.title}/><span className="visual-picker-check" aria-hidden="true">{validSelected.includes(resource.id)&&<Check size={16}/>}</span><span className="visual-picker-name">{resource.title}</span>{validSelected[0]===resource.id&&<small>{t('Main image')}</small>}{resource.category&&<small>{t(visualCategoryLabels[resource.category])}</small>}
    </button>)}</div>
    {!resources.length&&<p className="ui-empty-state ui-empty-state-compact">{t(available.length?'No matching images.':'No images available.')}</p>}
   </div>
   {preview&&<aside className="visual-picker-preview" aria-label={t('Image details')}><div className="visual-picker-preview-heading"><h3>{preview.title}</h3><button type="button" className="icon-button ui-close-button" title={t('Close preview')} aria-label={t('Close preview')} onClick={()=>{setPreviewId('');if(previewTrigger.current?.isConnected)previewTrigger.current.focus();}}><X size={16}/></button></div><EntryPortrait projectPath={projectPath} projectId={projectId} imageId={preview.id} title={preview.title}/><VisualResourceDetails resource={preview} resources={all}/>{visualUsageSummary(visualResourceUsage(world,preview.id))}</aside>}
  </div>
  <footer className="visual-picker-footer"><div><span role="status">{t('{0} images selected',validSelected.length)}</span><small>{t('The first selected image will be the main image.')}</small>{validSelected.length>0&&<button type="button" className="quick-action quick-action-text" onClick={()=>setSelected([])}>{t('Clear selection')}</button>}</div><div><button type="button" onClick={onClose}>{t('Cancel')}</button><button type="button" className="primary-button" disabled={!validSelected.length} onClick={()=>{setError('');try{onChoose(validSelected);}catch(error){setError(message(String(error)));}}}>{t('Add to gallery ({0})',validSelected.length)}</button></div></footer>
 </ProjectModal>;
}
