import type {MapView,Size} from './mapNavigation';
import type {DrawingCamera} from './drawingEditorView';
/** Transient screen-space camera shared by the two map tools; never project data. */
export type MapWorkCamera={centerX:number;centerY:number;scale:number};
export function elementsWorkCamera(view:MapView,fit:Size,image:Size):MapWorkCamera{
 const scale=fit.width*view.zoom/image.width;
 return {centerX:.5-view.x/(image.width*scale),centerY:.5-view.y/(image.height*scale),scale};
}
export function workElementsCamera(camera:MapWorkCamera,fit:Size,image:Size):MapView{
 return {zoom:camera.scale*image.width/fit.width,x:(.5-camera.centerX)*image.width*camera.scale,y:(.5-camera.centerY)*image.height*camera.scale};
}
export function drawingWorkCamera(camera:DrawingCamera,zoom:number,viewport:Size,image:Size):MapWorkCamera{
 const scale=camera.scale*zoom;
 return {centerX:(viewport.width/2-camera.x)/(image.width*scale),centerY:(viewport.height/2-camera.y)/(image.height*scale),scale};
}
export function workDrawingCamera(camera:MapWorkCamera,viewport:Size,image:Size):DrawingCamera{
 return {scale:camera.scale,x:viewport.width/2-camera.centerX*image.width*camera.scale,y:viewport.height/2-camera.centerY*image.height*camera.scale};
}
/** Keep background workspaces out of keyboard navigation without moving their DOM. */
export function isolateMapWorkspace(root:HTMLElement){
 const previous:{node:HTMLElement;inert:boolean}[]=[];
 let current=root;
 while(current.parentElement){
  const parent=current.parentElement;
  for(const sibling of parent.children)if(sibling!==current&&sibling instanceof HTMLElement){previous.push({node:sibling,inert:sibling.inert});sibling.inert=true;}
  if(parent.classList.contains('app-shell'))break;
  if(parent===document.body)break;
  current=parent;
 }
 return ()=>{for(const {node,inert} of previous)node.inert=inert;};
}
