import { t } from './i18n';
import type { Project, Scene } from './model';
export type SceneRecoveryMode='text'|'copy'|'deleted';
export type SceneRecoveryRequest={source:Project;sceneId:string;mode:SceneRecoveryMode;chapterId:string};
export function recoverScene(current:Project,request:SceneRecoveryRequest):{project:Project;sceneId:string}{
 const {source,sceneId,mode,chapterId}=request;
 if(current.id!==source.id)throw new Error(t('This version belongs to another project.'));
 const oldChapter=source.chapters.find(c=>c.scenes.some(s=>s.id===sceneId)),old=oldChapter?.scenes.find(s=>s.id===sceneId);
 if(!old||!oldChapter)throw new Error(t('The historical scene could not be found.'));
 const existing=current.chapters.flatMap(c=>c.scenes).find(s=>s.id===sceneId);
 const entryIds=new Set(current.worldbuilding?.entries.map(e=>e.id)??[]);
 const mentions={ignoredMentions:old.ignoredMentions?.map(m=>({...m})),resolvedMentions:old.resolvedMentions?.filter(m=>entryIds.has(m.entryId)).map(m=>({...m}))};
 if(mode==='text'){
  if(!existing)throw new Error(t('This scene no longer exists. Recover it as a deleted scene instead.'));
  return {project:{...current,chapters:current.chapters.map(c=>({...c,scenes:c.scenes.map(s=>s.id===sceneId?{...s,content:old.content,reviewComments:s.content===old.content?s.reviewComments:s.reviewComments?.map(c=>({...c,from:0,to:0,detached:true})),...mentions}:s)}))},sceneId};
 }
 if(mode==='deleted'&&existing)throw new Error(t('This scene already exists. Recover it as a copy instead.'));
 const target=current.chapters.find(c=>c.id===chapterId);
 if(!target&&chapterId!=='original')throw new Error(t('Choose an existing destination chapter.'));
 if(chapterId==='original'&&current.chapters.some(c=>c.id===oldChapter.id))throw new Error(t('Choose an existing destination chapter.'));
 const id=mode==='copy'?crypto.randomUUID():old.id;
 let title=old.title;
 if(mode==='copy'){
  const base=t('{0} (recovered copy)',title||t('Untitled scene')),titles=new Set(current.chapters.flatMap(c=>c.scenes.map(s=>s.title)));title=base;let i=2;while(titles.has(title))title=`${base} ${i++}`;
 }
 const scene:Scene={...old,id,title,reviewComments:old.reviewComments?.map(c=>({...c,id:mode==='copy'?crypto.randomUUID():c.id})),entryIds:old.entryIds?.filter(id=>entryIds.has(id)),...mentions};
 let chapters=current.chapters.map(c=>({...c,scenes:[...c.scenes]}));
 if(target){
  const destination=chapters.find(c=>c.id===target.id)!;
  let index=destination.scenes.length;
  if(mode==='copy'&&destination.scenes.some(s=>s.id===sceneId))index=destination.scenes.findIndex(s=>s.id===sceneId)+1;
  else if(target.id===oldChapter.id){
   const oldIndex=oldChapter.scenes.findIndex(s=>s.id===sceneId);
   const following=oldChapter.scenes.slice(oldIndex+1).find(s=>destination.scenes.some(n=>n.id===s.id));
   const preceding=oldChapter.scenes.slice(0,oldIndex).reverse().find(s=>destination.scenes.some(n=>n.id===s.id));
   if(following)index=destination.scenes.findIndex(s=>s.id===following.id);else if(preceding)index=destination.scenes.findIndex(s=>s.id===preceding.id)+1;
  }
  destination.scenes.splice(index,0,scene);
 }else{
  const restored={id:oldChapter.id,title:oldChapter.title,synopsis:oldChapter.synopsis,scenes:[scene]};
  const oldIndex=source.chapters.findIndex(c=>c.id===oldChapter.id);
  const following=source.chapters.slice(oldIndex+1).find(c=>chapters.some(n=>n.id===c.id));
  const index=following?chapters.findIndex(c=>c.id===following.id):chapters.length;chapters.splice(index,0,restored);
 }
 let books=current.books;
 if(!target&&books?.length){
  const historical=source.books?.find(book=>book.chapterIds.includes(oldChapter.id));
  const owner=books.find(book=>book.id===historical?.id)??(!historical?books[0]:undefined);
  books=owner?books.map(book=>book.id===owner.id?{...book,chapterIds:[...book.chapterIds,oldChapter.id]}:book):[...books,{...historical!,chapterIds:[oldChapter.id]}];
 }
 return {project:{...current,chapters,...(books?{books}:{})},sceneId:id};
}
