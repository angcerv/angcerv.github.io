import {t} from './i18n';
/** One normalized drawing value, exposed as both a slider and a precise percentage. */
export function drawingRange({id,label,value,min,max,step,onChange,unit='percent'}:{unit?:'percent'|'degrees';id:string;label:string;value:number;min:number;max:number;step:number;onChange:(value:number)=>void}){
 const factor=unit==='degrees'?1:100,suffix=unit==='degrees'?'°':'%';
 return <div className="ui-form-field drawing-range-field"><label htmlFor={id}>{label} <span>({suffix})</span></label><div><input id={id} type="range" min={min} max={max} step={step} value={value} onChange={event=>onChange(Number(event.target.value))}/><input id={id+'-number'} type="number" aria-label={t(unit==='degrees'?'{0} (°)':'{0} (%)',label)} min={min*factor} max={max*factor} step={step*factor} value={Number((value*factor).toFixed(3))} onChange={event=>{const next=event.target.valueAsNumber/factor;if(Number.isFinite(next)&&next>=min&&next<=max)onChange(next);}}/></div></div>;
}
