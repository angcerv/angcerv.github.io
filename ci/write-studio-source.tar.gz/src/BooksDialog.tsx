import {useEffect,useRef,useState} from 'react';
import {ArrowLeft,ArrowUp,ArrowDown,ArrowRightLeft,Check,MoreHorizontal,Pencil,Plus,Trash2,X} from 'lucide-react';
import type {CSSProperties} from 'react';
import type {Project} from './model';
import {addBook,applyBookOrganization,bookOrganization,moveBook,removeEmptyBook,transferChaptersBook} from './books';
import type {BookOrganization} from './books';
import ProjectModal from './ProjectModal';
import Dropdown from './Dropdown';
import ActionMenu from './ActionMenu';
import FieldHelp from './FieldHelp';
import {t,buttonLabel} from './i18n';

type Rename={id:string;value:string}|null;
const chapterCount=(count:number)=>t(count===1?'1 chapter':'{0} chapters',count);
const sceneCount=(count:number)=>t(count===1?'1 scene':'{0} scenes',count);
export default function BooksDialog({project,bookId,createOnOpen=false,onSave,onClose}:{project:Project;bookId?:string;createOnOpen?:boolean;onSave:(project:Project)=>void|boolean;onClose:()=>void}){
 const [initial]=useState(()=>{
  const base=bookOrganization(project,crypto.randomUUID());
  if(!createOnOpen)return {base,draft:base,selected:base.books.find(book=>book.id===bookId)?.id??base.books[0].id,rename:null as Rename};
  const id=crypto.randomUUID(),title=t('Book {0}',base.books.length+1);
  return {base,draft:{...base,books:[...base.books,{id,title,chapterIds:[]}]},selected:id,rename:{id,value:title} as Rename};
 });
 const [organization,setOrganization]=useState<BookOrganization>(initial.draft),[selected,setSelected]=useState(initial.selected),[renaming,setRenaming]=useState<Rename>(initial.rename);
 const [chapterIds,setChapterIds]=useState<string[]>([]),[detail,setDetail]=useState(createOnOpen),[moving,setMoving]=useState(false),[destination,setDestination]=useState('');
 const [notice,setNotice]=useState(''),[error,setError]=useState('');
 const renameInput=useRef<HTMLInputElement>(null),detailHeading=useRef<HTMLHeadingElement>(null),chapterList=useRef<HTMLDivElement>(null),chapterFocus=useRef(''),allCheckbox=useRef<HTMLInputElement>(null),bookList=useRef<HTMLElement>(null),focusRequest=useRef('');
 const books=organization.books,book=books.find(item=>item.id===selected)??books[0];
 const byId=new Map(project.chapters.map(chapter=>[chapter.id,chapter]));
 const chapters=organization.chapterOrder.filter(id=>book.chapterIds.includes(id)).flatMap(id=>byId.get(id)?[byId.get(id)!]:[]);
 const selectedIds=chapters.filter(chapter=>chapterIds.includes(chapter.id)).map(chapter=>chapter.id),canTransfer=books.length>1;
 const pending={...organization,books:books.map(item=>renaming?.id===item.id?{...item,title:renaming.value}:item)};
 const valid=pending.books.every(item=>!!item.title.trim()&&item.title.length<=300),changed=JSON.stringify(pending)!==JSON.stringify(initial.base);
 useEffect(()=>{renameInput.current?.focus();renameInput.current?.select();},[renaming?.id]);
 useEffect(()=>{if(allCheckbox.current)allCheckbox.current.indeterminate=selectedIds.length>0&&selectedIds.length<chapters.length;},[selectedIds.length,chapters.length]);
 function snapshot(){
  if(!valid){if(!renaming)setError(t('Give every book a title.'));renameInput.current?.focus();return;}
  const next=applyBookOrganization(project,pending);
  if(!next)setError(t('Chapters changed while organizing books. Close and reopen the organizer.'));
  return next;
 }
 function stage(next:Project){setOrganization(bookOrganization(next,books[0].id));setRenaming(null);setError('');}
 function focusBook(id:string){focusRequest.current=id;}
 useEffect(()=>{if(chapterFocus.current){const row=chapterList.current?.querySelector<HTMLElement>(`[data-chapter-id="${chapterFocus.current}"]`);chapterFocus.current='';focusRequest.current='';row?.focus({preventScroll:true});row?.scrollIntoView({block:'nearest'});return;}if(!focusRequest.current||renaming)return;const button=bookList.current?.querySelector<HTMLElement>(`[data-book-id="${focusRequest.current}"]`);focusRequest.current='';(button?.getClientRects().length?button:detailHeading.current)?.focus();},[organization,renaming,selected,detail]);
 function finishRename(){const next=snapshot();if(!next)return false;stage(next);focusBook(book.id);return true;}
 function chooseBook(id:string){if(renaming&&!finishRename())return;setSelected(id);setDetail(true);focusBook(id);setChapterIds([]);setMoving(false);setNotice('');}
 function renameBook(id:string){const next=snapshot();if(!next)return;stage(next);setSelected(id);setDetail(true);setChapterIds([]);setMoving(false);setRenaming({id,value:next.books!.find(item=>item.id===id)!.title});}
 function newBook(){const current=snapshot();if(!current)return;const id=crypto.randomUUID(),next=addBook(current,t('Book {0}',books.length+1),id,books[0].id);stage(next);setSelected(id);setDetail(true);setChapterIds([]);setMoving(false);setNotice('');setRenaming({id,value:next.books!.find(item=>item.id===id)!.title});}
 function reorderBook(id:string,direction:-1|1){const current=snapshot();if(!current)return;const next=moveBook(current,id,direction);stage(next);setNotice(t('Book moved to position {0}.',next.books!.findIndex(item=>item.id===id)+1));}
 function removeBook(id:string){const current=snapshot();if(!current)return;const next=removeEmptyBook(current,id);if(next===current)return;stage(next);setMoving(false);setDestination('');if(next.books!.length===1)setChapterIds([]);if(selected===id){const index=books.findIndex(item=>item.id===id);const nextId=next.books![Math.min(index,next.books!.length-1)].id;setSelected(nextId);focusBook(nextId);setChapterIds([]);setMoving(false);}setNotice(t('Empty book removed.'));}
 function startMove(ids:string[]){if(!canTransfer||!ids.length)return;setChapterIds(ids);setDestination('');setMoving(true);setNotice('');}
 function moveSelection(){const current=snapshot();if(!current||!destination||destination===book.id||!selectedIds.length)return;const next=transferChaptersBook(current,selectedIds,destination);if(next===current)return;stage(next);setSelected(destination);chapterFocus.current=selectedIds[0];setChapterIds(selectedIds);setMoving(false);const title=next.books!.find(item=>item.id===destination)!.title;setNotice(selectedIds.length===1?t('Chapter moved to {0}.',title):t('{0} chapters moved to {1}.',selectedIds.length,title));}
 return <ProjectModal title={t('Organize books')} titleAccessory={<FieldHelp variant="toolbar" label={t('Books')} description={t('Books share the world, maps and timeline. Each chapter belongs to one book.')}/>} onClose={onClose} className="books-dialog"><form onSubmit={event=>{event.preventDefault();if(!valid||!changed||moving)return;const next=snapshot();if(next&&onSave(next)===false)setError(t('Chapters changed while organizing books. Close and reopen the organizer.'));}}>
  <div className="books-toolbar"><div className="books-project"><span>{t('Project')}</span><strong title={project.title}>{project.title}</strong></div><button type="button" className="quick-action quick-action-text" onClick={newBook}><Plus size={18} aria-hidden="true"/>{t('New book')}</button></div>
  <div className="books-layout" data-detail={detail} style={{'--books-wide-rows':Math.max(books.length,chapters.length),'--book-list-rows':books.length,'--chapter-list-rows':chapters.length} as CSSProperties}>
   <section className="books-sidebar" aria-label={t('Books')}><h3>{t('Books')} <span>{books.length}</span></h3><nav ref={bookList} className="books-list" aria-label={t('Choose a book to organize')}><ol>{books.map((item,index)=><li key={item.id} className={item.id===book.id?'is-selected':undefined}><button type="button" className="book-choice" data-book-id={item.id} aria-pressed={item.id===book.id} onClick={()=>chooseBook(item.id)}><span className="book-position">{index+1}</span><span className="book-choice-copy"><strong>{item.title||t('Untitled book')}</strong><small>{chapterCount(item.chapterIds.length)}</small></span></button><ActionMenu iconOnly label={t('Options for book {0}: {1}',index+1,item.title)} actions={[
    {label:t('Rename book'),icon:<Pencil size={18}/>,onClick:()=>renameBook(item.id)},
    {label:t('Move book up'),icon:<ArrowUp size={18}/>,disabled:index===0,onClick:()=>reorderBook(item.id,-1)},
    {label:t('Move book down'),icon:<ArrowDown size={18}/>,disabled:index===books.length-1,onClick:()=>reorderBook(item.id,1)},
    {label:t('Remove empty book'),icon:<Trash2 size={18}/>,danger:true,disabled:books.length===1||!!item.chapterIds.length,disabledReason:buttonLabel(books.length===1?'Keep at least one book.':'Move chapters before removing this book.'),onClick:()=>removeBook(item.id)},
   ]}><MoreHorizontal size={18} aria-hidden="true"/></ActionMenu></li>)}</ol></nav></section>
   <section className="books-chapter-pane" aria-label={t('Chapters of {0}',book.title)}><header className="book-detail-heading"><button type="button" className="quick-action quick-action-text books-back" onClick={()=>{if(renaming&&!finishRename())return;setDetail(false);focusBook(book.id);setMoving(false);}}><ArrowLeft size={18} aria-hidden="true"/>{t('Books')}</button>
    {renaming?.id===book.id?<div className="book-title-edit"><label htmlFor="organizer-book-title">{t('Book title')}</label><div><input ref={renameInput} id="organizer-book-title" maxLength={300} value={renaming.value} aria-invalid={!renaming.value.trim()} onChange={event=>{setRenaming({id:book.id,value:event.target.value});setError('');}} onKeyDown={event=>{if(event.key==='Enter'){event.preventDefault();event.stopPropagation();finishRename();}else if(event.key==='Escape'){event.preventDefault();event.stopPropagation();setRenaming(null);setError('');focusBook(book.id);}}}/><button type="button" className="quick-action" aria-label={t('Apply book title')} title={t('Apply book title')} disabled={!renaming.value.trim()} onClick={finishRename}><Check size={18}/></button><button type="button" className="quick-action" aria-label={t('Cancel rename')} title={t('Cancel rename')} onClick={()=>{setRenaming(null);setError('');focusBook(book.id);}}><X size={18}/></button></div>{!renaming.value.trim()&&<p className="prompt-error" role="alert">{t('Give every book a title.')}</p>}</div>:<div className="book-detail-title"><div><h3 ref={detailHeading} tabIndex={-1}>{book.title}</h3><p>{chapterCount(chapters.length)}</p></div><button type="button" className="quick-action" aria-label={t('Rename book')} title={t('Rename book')} onClick={()=>renameBook(book.id)}><Pencil size={18}/></button></div>}
   </header>
   {canTransfer&&!!chapters.length&&<div className="books-selection-toolbar"><label><input ref={allCheckbox} type="checkbox" checked={selectedIds.length===chapters.length} onChange={event=>setChapterIds(event.target.checked?chapters.map(chapter=>chapter.id):[])}/>{t('Select all chapters')}</label>{!!selectedIds.length&&<button type="button" className="quick-action quick-action-text" onClick={()=>startMove(selectedIds)}><ArrowRightLeft size={18} aria-hidden="true"/>{buttonLabel(selectedIds.length===1?'Move chapter…':'Move {0} chapters…',selectedIds.length)}</button>}</div>}
   {moving&&<div className="books-move-panel"><div className="ui-form-field"><label htmlFor="book-move-destination">{t('Move selected chapters to')}</label><Dropdown id="book-move-destination" value={destination} searchable placeholder={t('Choose a destination book')} options={books.flatMap((item,index)=>item.id===book.id?[]:[{value:item.id,label:`${index+1} · ${item.title}`,searchText:item.title}])} onChange={setDestination}/></div><div><button type="button" className="quick-action quick-action-text" onClick={()=>setMoving(false)}>{t('Cancel')}</button><button type="button" className="primary-button" disabled={!destination||!selectedIds.length} onClick={moveSelection}>{buttonLabel(selectedIds.length===1?'Move chapter':'Move chapters')}</button></div></div>}
   <div ref={chapterList} className="books-chapter-scroll" tabIndex={0} aria-label={t('Chapter list')}>
    {chapters.length?<ol className="book-chapters">{chapters.map((chapter,index)=>{
     const identity=<><span className="book-chapter-number">{index+1}</span><span className="book-chapter-copy"><strong>{chapter.title||t('Untitled chapter')}</strong><small>{sceneCount(chapter.scenes.length)}</small></span></>;
     return <li key={chapter.id} data-chapter-id={chapter.id} tabIndex={-1} className={selectedIds.includes(chapter.id)?'is-selected':undefined}>{canTransfer?<label className="book-chapter-selection"><input type="checkbox" aria-label={t('Select chapter {0}: {1}',index+1,chapter.title||t('Untitled chapter'))} checked={selectedIds.includes(chapter.id)} onChange={event=>{setChapterIds(ids=>event.target.checked?[...ids,chapter.id]:ids.filter(id=>id!==chapter.id));setNotice('');}}/>{identity}</label>:<div className="book-chapter-selection">{identity}</div>}{canTransfer&&<ActionMenu iconOnly label={t('Options for chapter {0}: {1}',index+1,chapter.title||t('Untitled chapter'))} actions={[{label:t('Move to another book'),icon:<ArrowRightLeft size={18}/>,onClick:()=>startMove(selectedIds.includes(chapter.id)?selectedIds:[chapter.id])}]}><MoreHorizontal size={18} aria-hidden="true"/></ActionMenu>}</li>;
    })}</ol>:<div className="ui-empty-state"><p>{t('No chapters yet.')}</p></div>}

   </div>
   </section>
  </div>
  <div className="books-feedback" aria-live="polite" aria-atomic="true">{error?<p className="prompt-error" role="alert">{error}</p>:notice?<p role="status">{notice}</p>:null}</div>
  <footer className="books-footer"><small>{t('Changes apply when you save.')}</small><div><button type="button" className="quick-action quick-action-text" onClick={onClose}>{t('Cancel')}</button><button type="submit" className="primary-button" disabled={!valid||!changed||moving}>{t('Save')}</button></div></footer>
 </form></ProjectModal>;
}
