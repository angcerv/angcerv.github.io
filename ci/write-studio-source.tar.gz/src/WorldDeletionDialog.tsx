import {focusDialog} from './dialogFocus';
import type {EntryRelations} from './entryRelations';
import {timelineEventEntryIds} from './timeline';
import {t,buttonLabel} from './i18n';
import { entryMapLocations } from './maps';
import type { ProjectMaps } from './maps';
import type { Timeline } from './timeline';
import type { Chapter } from './model';
import { scenesForEntry } from './sceneLinks';
import { useEffect, useRef } from 'react';
import { incomingEntryLinks, templateEntryCount } from './worldbuilding';
import type { Worldbuilding } from './worldbuilding';

export default function WorldDeletionDialog({ relations,maps, world, target, chapters = [], timeline, onCancel, onConfirm }: {
  relations?:EntryRelations;maps?:ProjectMaps; world: Worldbuilding;
  chapters?: Chapter[]; timeline?: Timeline;
  target: { kind: 'entry' | 'template'; id: string };
  onCancel: () => void;
  onConfirm: () => void;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => { const element = dialog.current; element?.showModal();focusDialog(element); return () => element?.close(); }, []);
  const record = (target.kind === 'entry' ? world.entries : world.templates).find(item => item.id === target.id);
  const links = target.kind === 'entry' ? incomingEntryLinks(world, target.id) : world.templates.filter(template => template.id !== target.id).flatMap(template => template.fields.filter(field => field.targetTemplateId === target.id).map(field => `${template.title || t("Untitled template")} / ${field.label || t("Untitled field")}`));
  const blocked = !record || (target.kind === 'template' && templateEntryCount(world, target.id) > 0);
  return <dialog ref={dialog} className="world-delete-dialog" aria-labelledby="world-delete-title" aria-describedby="world-delete-description" onCancel={event => { event.preventDefault(); onCancel(); }}>
    <h2 id="world-delete-title">{t("Delete") + " "}{t(target.kind==='entry'?'Entry':t("Template"))}?</h2>
    <p id="world-delete-description">“{record?.title || t("Untitled {0}", target.kind)}{t("” will be removed from this project. This action cannot be undone in the editor. Save the project to keep this change.")}</p>
    {links.length > 0 && <><p>{target.kind === 'entry' ? t("These references will show Missing entry until you replace or clear them:") : t("These field rules will show Allowed template is missing until you choose another template:")}</p><ul>{links.map((link, index) => <li key={index}>{link}</li>)}</ul></>}
    {target.kind === 'entry' && scenesForEntry(chapters, target.id).length > 0 && <><p>{t("These scene links will show Missing entry until removed:")}</p><ul>{scenesForEntry(chapters, target.id).map(({ chapter, scene }) => <li key={scene.id}>{chapter.title} / {scene.title}</li>)}</ul></>}
    {target.kind === 'entry' && timeline?.events.some(event => timelineEventEntryIds(event).includes(target.id)) && <><p>{t("These timeline events will keep a Missing entry link:")}</p><ul>{timeline.events.filter(event => timelineEventEntryIds(event).includes(target.id)).map(event => <li key={event.id}>{event.title || t("Untitled event")}</li>)}</ul></>}
    {target.kind==='entry' && entryMapLocations(maps,target.id).length>0 && <><p>{t("These map markers will keep a Missing entry link:")}</p><ul>{entryMapLocations(maps,target.id).map(({map,marker})=><li key={marker.id}>{map.title || t("Untitled map")} / {marker.title || record?.title || t("Untitled marker")}</li>)}</ul></>}
    {target.kind==='entry'&&relations?.links.some(link=>link.sourceId===target.id||link.targetId===target.id)&&<p>{t('{0} connections will be removed from both entries. The other entries are kept.',relations.links.filter(link=>link.sourceId===target.id||link.targetId===target.id).length)}</p>}
    {blocked && <p>{t("This template still has associated entries, including archived entries, or the item is no longer available.")}</p>}
    <div className="world-form-actions"><button type="button" onClick={onCancel} className="quick-action quick-action-text">{t("Cancel")}</button><button type="button" className="danger-button" disabled={blocked} onClick={onConfirm}>{t("Delete") + " "}{buttonLabel(target.kind==='entry'?'Entry':t("Template"))}</button></div>
  </dialog>;
}
