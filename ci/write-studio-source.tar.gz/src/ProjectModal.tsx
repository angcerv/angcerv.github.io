import {focusDialog} from './dialogFocus';
import { useEffect, useId, useRef } from 'react';
import type { ReactNode } from 'react';
import { X } from 'lucide-react';
import { t } from './i18n';

// Native modal focus containment, with an explicit escape policy for recovery.
export default function ProjectModal({title,busy=false,onClose,children,className='',titleAccessory,variant}:{title:string;variant?:'confirmation';titleAccessory?:ReactNode;busy?:boolean;onClose?:()=>void;children:ReactNode;className?:string}) {
 const ref=useRef<HTMLDialogElement>(null),id=useId();
 useEffect(()=>{const previous=document.activeElement as HTMLElement|null;const dialog=ref.current;dialog?.showModal();focusDialog(dialog,true);return()=>{dialog?.close();if(previous?.isConnected)previous.focus({preventScroll:true});};},[]);
 return <dialog ref={ref} className={`prompt project-modal ${className}${variant==='confirmation'?' ui-confirmation-dialog':''}`} aria-labelledby={id} onCancel={event=>{event.preventDefault();if(!busy)onClose?.();}}><header className="ui-dialog-heading">{titleAccessory?<div className="ui-dialog-title"><h2 id={id}>{title}</h2>{titleAccessory}</div>:<h2 id={id}>{title}</h2>}{onClose&&<button type="button" className="icon-button ui-close-button" title={t('Close')} aria-label={t('Close')} disabled={busy} onClick={onClose}><X size={18}/></button>}</header>{children}</dialog>;
}
