import type {Worldbuilding} from './worldbuilding';
import type {ProjectMaps} from './maps';
import type {IdeaCanvases} from './ideaCanvas';
import {t} from './i18n';
export type VisualUsageContext={maps?:ProjectMaps;ideaCanvases?:IdeaCanvases};
export type VisualUse={kind:'entry'|'map'|'trashedMap'|'canvas'|'variant';id:string;title:string};
/** Current canonical links only. Retained history protects files separately in native storage. */
export function visualResourceUsage(world:Worldbuilding,id:string,context:VisualUsageContext={}):VisualUse[]{
 const uses:VisualUse[]=[];
 for(const entry of world.entries)if(entry.imageId===id||entry.imageIds?.includes(id))uses.push({kind:'entry',id:entry.id,title:entry.title||t('Untitled entry')});
 for(const map of context.maps?.maps??[])if(map.imageId===id)uses.push({kind:'map',id:map.id,title:map.title||t('Untitled map')});
 for(const {map} of context.maps?.trash??[])if(map.imageId===id)uses.push({kind:'trashedMap',id:map.id,title:map.title||t('Untitled map')});
 for(const board of context.ideaCanvases?.boards??[])if(board.nodes.some(node=>node.kind==='image'&&node.targetId===id))uses.push({kind:'canvas',id:board.id,title:board.title||t('Untitled board')});
 for(const resource of world.visualResources??[])if(resource.variantOf===id)uses.push({kind:'variant',id:resource.id,title:resource.title});
 return uses;
}
export function visualRemovalProblem(uses:VisualUse[]):string{
 if(uses.some(use=>use.kind==='variant'))return t('Unlink this image’s variants before removing it.');
 if(uses.some(use=>use.kind==='entry'))return t('Unlink this image from its entries first.');
 if(uses.some(use=>use.kind==='map'))return t('This image is used by maps. Replace their image or permanently delete those maps first.');
 if(uses.some(use=>use.kind==='trashedMap'))return t('This image is used by a map in the trash. Restore or permanently delete that map first.');
 if(uses.some(use=>use.kind==='canvas'))return t('Unlink this image from its planning boards first.');
 return '';
}
