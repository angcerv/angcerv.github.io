import {validRegionGeometry} from './mapRegions';
import type {DrawingPoint} from './mapDrawing';
export type TerrainMask={points:DrawingPoint[];holes?:DrawingPoint[][];inverted?:boolean};
export function validTerrainMask(mask:TerrainMask){return validRegionGeometry(mask);}
/** Retain geometry, never a live region link: later edits cannot change existing paint. */
export function snapshotTerrainMask(mask:TerrainMask):TerrainMask{return {points:mask.points.map(p=>({...p})),...(mask.holes?.length?{holes:mask.holes.map(r=>r.map(p=>({...p})))}:{}),...(mask.inverted?{inverted:true}:{})};}
export function terrainMaskPath(mask:TerrainMask,width:number,height:number,invert=mask.inverted){
 const n=(v:number)=>Number(v.toFixed(3));
 return (invert?`M0 0H${width}V${height}H0Z`:'')+[mask.points,...mask.holes??[]].map(ring=>ring.map((p,i)=>`${i?'L':'M'}${n(p.x*width)} ${n(p.y*height)}`).join('')+'Z').join('');
}
export function clipTerrainGeometry(geometry:string,mask:TerrainMask|undefined,width:number,height:number,id:string){
 return !mask?geometry:`<defs><clipPath id="${id}" clipPathUnits="userSpaceOnUse"><path d="${terrainMaskPath(mask,width,height)}" clip-rule="evenodd"/></clipPath></defs><g clip-path="url(#${id})">${geometry}</g>`;
}

/** Saved editing helpers; strokes retain independent geometry snapshots. */
export type SavedTerrainMask=TerrainMask&{id:string;title:string;layerId?:string};
