import type {Entry} from './worldbuilding';
export type EditorialStatus='notStarted'|'developing'|'inReview'|'defined';
export const editorialLabels:Record<EditorialStatus,string>={notStarted:'To develop',developing:'In development',inReview:'To review',defined:'Defined'};
export function matchesEditorial(entry:Entry,filter:string){return !filter||(filter==='unclassified'?!entry.editorialStatus:entry.editorialStatus===filter);}

export type CanonStatus='confirmed'|'provisional'|'alternative';
export const canonLabels:Record<CanonStatus,string>={confirmed:'Confirmed canon',provisional:'Provisional',alternative:'Alternative'};
export function matchesCanon(entry:Entry,filter:string){return !filter||(filter==='unclassified'?!entry.canonStatus:entry.canonStatus===filter);}
