import {useContext,useMemo} from 'react';
import TextReferenceBacklinks from './TextReferenceBacklinks';
import type {TextReferenceSource} from './textReferenceIndex';
import {TextReferenceContext} from './textReferenceContext';
import {entryUsageGroups} from './entryUsage';
import EntryAppearances from './EntryAppearances';
import {entryAppearances} from './entryAppearanceIndex';
import RelatedIdeas from './RelatedIdeas';
import {relatedIdeas} from './worldIdeas';
import type {WorldIdea} from './worldIdeas';
import type {Chapter} from './model';
import type {Worldbuilding} from './worldbuilding';
import {t} from './i18n';
export default function EntryUsageSummary({blocked=false,isSourceDisabled,onOpenSource,entryId,chapters,world,onOpenScene,onOpenMention,ideas=[],onOpenIdea,appearanceId}:{blocked?:boolean;isSourceDisabled?:(source:TextReferenceSource)=>boolean;onOpenSource?:(source:TextReferenceSource)=>void;entryId:string;chapters:Chapter[];world:Worldbuilding;onOpenScene?:(id:string)=>void;onOpenMention?:(id:string,range:{from:number;to:number})=>void;ideas?:WorldIdea[];onOpenIdea?:(id:string)=>void;appearanceId?:string}){
 const context=useContext(TextReferenceContext),appearance=useMemo(()=>entryAppearances(chapters,world,entryId),[chapters,world,entryId]);
 const groups=useMemo(()=>context?entryUsageGroups(context.project,context.index,entryId):[],[context,entryId]);
 const openSource=onOpenSource??context?.openSource;
 const activeIdeas=relatedIdeas(context?.project.worldIdeas??ideas,'entry',entryId);
 return <section className="entry-usage-summary"><h3>{t('Where this entry is used')}</h3><details id={appearanceId} data-lore-section={appearanceId?true:undefined}><summary>{t('Manuscript appearances')} <span className="compact-count">{appearance.sceneCount}</span></summary><EntryAppearances embedded chapters={chapters} world={world} entryId={entryId} onOpenScene={blocked?undefined:onOpenScene} onOpenMention={blocked?undefined:onOpenMention}/></details>{activeIdeas.length>0&&<details><summary>{t('Ideas and decisions')} <span className="compact-count">{activeIdeas.length}</span></summary><RelatedIdeas embedded ideas={activeIdeas} kind="entry" id={entryId} onOpen={blocked?undefined:onOpenIdea??(openSource?(id=>openSource({kind:'idea',id,entryId,label:'',field:'',excerpt:'',count:1})):undefined)}/></details>}{groups.map(group=><details key={group.label}><summary>{t(group.label)} <span className="compact-count">{group.items.length}</span></summary><TextReferenceBacklinks entryId={entryId} sources={group.items.map(({source,fields})=>({...source,field:fields.join(' · ')}))} showHeading={false} isSourceDisabled={isSourceDisabled} onOpen={openSource} disabled={blocked}/></details>)}</section>;
}
