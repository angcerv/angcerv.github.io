import {eventDateLabel} from './timeline';
import type {TimelineEvent} from './timeline';
import {t} from './i18n';
export default function CalendarEventButton({event,selected,onSelect}:{event:TimelineEvent;selected:boolean;onSelect:(id:string)=>void}){
 return <button type="button" className="calendar-event-button" aria-pressed={selected} onClick={()=>onSelect(event.id)}><strong>{event.title||t('Untitled event')}</strong><small>{eventDateLabel(event)}</small></button>;
}
