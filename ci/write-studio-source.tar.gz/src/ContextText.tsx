import {useWorkspaceState} from './useWorkspaceState';
import {Check,Pencil} from 'lucide-react';
import {t,buttonLabel} from './i18n';
import LongTextEditor,{LongTextView} from './LongTextEditor';
import {longTextPlainText} from './longText';
export default function ContextText({id,label,value,onChange}:{id:string;label:string;value:string;onChange:(value:string)=>void}){
 const [editing,setEditing]=useWorkspaceState(`context.editing.${id}`,false);
 return <div className="context-text"><header><h4 id={`${id}-label`}>{label}</h4><button type="button" className="icon-button" aria-label={buttonLabel(editing?'Finish editing {0}':'Edit {0}',label)} title={buttonLabel(editing?'Finish editing {0}':'Edit {0}',label)} aria-expanded={editing} aria-controls={editing?id:undefined} onClick={()=>setEditing(!editing)}>{editing?<Check size={14}/>:<Pencil size={14}/>}</button></header>{editing?<LongTextEditor id={id} value={value} onChange={onChange}/>:longTextPlainText(value).trim()?<LongTextView value={value}/>:<p className="context-placeholder">{t('Not defined yet.')}</p>}</div>;
}
