import { t } from './i18n';
import { ArrowUpRight } from 'lucide-react';
import Dropdown from './Dropdown';
import { referenceChoices, referenceLabel, referenceReviewMessage } from './worldbuilding';
import type { EntryReference, Worldbuilding } from './worldbuilding';

export function ReferenceLink({ world, reference, onNavigate, targetTemplateId }: { world: Worldbuilding; reference: EntryReference; targetTemplateId?: string; onNavigate: (id: string) => void }) {
  const target = world.entries.find(entry => entry.id === reference.entryId);
  const review = referenceReviewMessage(world, targetTemplateId, reference);
  if (!target) return <span className="reference-display"><span className="reference-missing" title={reference.entryId}>{t("Missing entry")}</span>{review && <span className="reference-review" role="status">{review}</span>}</span>;
  return <span className="reference-display"><button type="button" className="reference-link" onClick={() => onNavigate(target.id)} title={t("Open {0}", target.title || t("Untitled entry"))}><span>{referenceLabel(world, target.id)}</span><ArrowUpRight size={14} aria-hidden="true" /></button>{review && <span className="reference-review" role="status">{review}</span>}</span>;
}
export default function EntryReferencePicker({ id, label, world, reference, onChange, onNavigate, targetTemplateId }: {
  id: string; label: string; world: Worldbuilding; reference?: EntryReference | null; targetTemplateId?: string;
  onChange: (value: EntryReference | null) => void; onNavigate: (id: string) => void;
}) {
  const target = world.entries.find(entry => entry.id === reference?.entryId);
  return <div className="entry-reference-picker">{targetTemplateId && <p className="world-hint">{t("Link to:") + " "}{world.templates.find(template => template.id === targetTemplateId)?.title || t("Missing template")}</p>}
    <Dropdown searchable searchLabel={t("Search entries for {0}", label || 'reference')} id={id} aria-labelledby={`${id}-label`} value={reference?.entryId ?? ''} selectedLabel={reference ? referenceLabel(world, reference.entryId) : t("None")} options={referenceChoices(world, '', targetTemplateId)} onChange={entryId => onChange(entryId ? { entryId } : null)} />
    {!reference && referenceReviewMessage(world, targetTemplateId) && <p className="reference-review" role="status">{referenceReviewMessage(world, targetTemplateId)}</p>}
    {reference && <div className="reference-status"><ReferenceLink world={world} reference={reference} onNavigate={onNavigate} targetTemplateId={targetTemplateId} />{!target && <p className="world-hint">{t("Choose a replacement or select None to clear this link.")}</p>}{target?.archived && <p className="world-hint">{t("This entry is archived. The existing link is kept.")}</p>}</div>}
  </div>;
}
