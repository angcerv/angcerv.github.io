import {message,t,getLanguage,setLanguage,buttonLabel} from './i18n';
import Dropdown from './Dropdown';
import FieldHelp from './FieldHelp';
import {Download} from 'lucide-react';
import { useState } from 'react';
import ProjectModal from './ProjectModal';
import type { Settings } from './storage';

type Props = {
  onExport?:()=>void;
  theme: string; onTheme: (theme: string) => void;
  kind: 'new' | 'settings'; settings: Settings | null; busy: boolean; error: string;
  name: string; folderName: string;
  onName: (value: string) => void; onFolderName: (value: string) => void;
  onChooseDirectory: () => void; onCreate: () => void; onClose: () => void;
};
export default function ProjectDialogs(props: Props) {
  const { kind, settings, busy, error, name, folderName, onName, onFolderName, onChooseDirectory, onCreate, onClose } = props;
  const directory = settings?.projectsDirectory;
  const [editingFolder, setEditingFolder] = useState(false);
  const destination=directory?`${directory.replace(/[\\/]+$/,'')}${directory.includes('\\')?'\\':'/'}${folderName}`:'';
  return <ProjectModal className="project-dialog" title={kind === 'new' ? t("New project") : t("Settings")} busy={busy} onClose={onClose}>
    <form onSubmit={event => { event.preventDefault(); if (kind === 'new' && !busy && directory) onCreate(); }}>
      <fieldset disabled={busy} className="dialog-fields">
        {kind === 'new' && <><div className="ui-form-field"><label htmlFor="project-name">{t("Project name")}</label><input id="project-name" value={name} maxLength={120} required onChange={event => onName(event.target.value)} placeholder={t("My next story")} /></div>
          <div className="folder-name-summary"><span>{t("Folder:") + " "}<strong>{folderName}</strong></span><button type="button" className="quick-action quick-action-text" aria-expanded={editingFolder} aria-controls="project-folder-editor" onClick={() => { const input = document.getElementById('project-folder-name') as HTMLInputElement | null; if (editingFolder && input && !input.reportValidity()) return; setEditingFolder(!editingFolder); }}>{buttonLabel(editingFolder?"Done":"Change folder name…")}</button></div><div id="project-folder-editor" className="ui-section-disclosure-collapse" data-open={editingFolder} inert={!editingFolder} aria-hidden={!editingFolder}><div><div className="ui-form-field"><label htmlFor="project-folder-name">{t("Folder name")}</label><input id="project-folder-name" disabled={!editingFolder} value={folderName} maxLength={80} pattern="[a-z0-9]((?:[a-z0-9]|-)*[a-z0-9])?" required onChange={event => onFolderName(event.target.value)} aria-describedby="folder-name-help" /></div><p id="folder-name-help" className="field-hint">{t("Renaming the project later keeps this folder name.")}</p></div></div></>}
        <span className="field-label" id="projects-directory-label">{t(kind==='new'?"Create in:":"Default projects folder")}</span><div className="directory-setting" role="group" aria-labelledby="projects-directory-label"><span className="directory-path" title={settings?.localProjects&&!settings.externalProjects?undefined:(kind==='new'?destination:directory) ?? ''}>{settings?.localProjects&&!settings.externalProjects?t("On this device"):(kind==='new'?destination:directory) || t("Choose a folder to get started")}</span><button type="button" className="quick-action quick-action-text" onClick={onChooseDirectory}>{directory ? buttonLabel("Change…") : buttonLabel("Choose…")}</button></div>
        {settings?.externalProjects&&<p className="field-hint">{t("Use one device at a time and wait for iCloud to finish syncing before switching devices.")}</p>}
        {kind==='settings'&&<p className="field-hint">{t(settings?.localProjects&&!settings.externalProjects?"Projects are stored on this device.":"New projects are created here. Existing projects stay in their current folders.")}</p>}
        {kind === 'settings' && <><div className="settings-language ui-form-field"><label htmlFor="application-language">{t("Language")}<FieldHelp label={t("Language")} description={t("Language changes apply to the interface. Your writing and project content stay in their original language.")}/></label><Dropdown id="application-language" aria-label={t("Language")} value={getLanguage()} options={[{value:'en',label:t("English")},{value:'es',label:t("Spanish")}]} onChange={value=>setLanguage(value as 'en'|'es')}/></div><fieldset className="appearance-setting"><legend>{t("Appearance")}</legend><label><input type="radio" name="appearance" value="light" checked={props.theme === 'light'} onChange={() => props.onTheme('light')} />{t("Light")}</label><label><input type="radio" name="appearance" value="dark" checked={props.theme === 'dark'} onChange={() => props.onTheme('dark')} />{t("Dark")}</label></fieldset></>}
        {kind==='settings'&&props.onExport&&<section className="project-export-setting"><h3>{t('Project content')}</h3><button type="button" className="quick-action quick-action-text" onClick={props.onExport}><Download size={16}/>{buttonLabel('Export…')}</button></section>}
        {error && <p role="alert" className="prompt-error">{message(error)}</p>}
        <div className="welcome-actions"><button type="button" onClick={onClose} className="quick-action quick-action-text">{kind === 'new' ? t("Cancel") : t("Done")}</button>{kind === 'new' && <button type="submit" className="primary-button" disabled={!directory || !name.trim() || !folderName}>{busy ? buttonLabel("Creating…") : t("Create project")}</button>}</div>
      </fieldset>
    </form>
  </ProjectModal>;
}
