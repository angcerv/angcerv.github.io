import type {Project} from './model';
import {patchScene} from './manuscript';
import {sortedEvents} from './timeline';
import {projectPendingItems} from './pendingItems';
import type {PendingItem} from './pendingItems';
export type ScenePlan={schemaVersion:1;goal:string;conflict:string;change:string};
export const emptyScenePlan:ScenePlan={schemaVersion:1,goal:'',conflict:'',change:''};
export function patchScenePlan(project:Project,sceneId:string,patch:Partial<Omit<ScenePlan,'schemaVersion'>>):Project{
 const scene=project.chapters.flatMap(chapter=>chapter.scenes).find(scene=>scene.id===sceneId);if(!scene)return project;
 return patchScene(project,sceneId,{planning:{...(scene.planning??emptyScenePlan),...patch,schemaVersion:1}});
}
export function sceneWritingContext(project:Project,sceneId:string,items:PendingItem[]=projectPendingItems(project)){
 const chapter=project.chapters.find(chapter=>chapter.scenes.some(scene=>scene.id===sceneId)),scene=chapter?.scenes.find(scene=>scene.id===sceneId);if(!chapter||!scene)return;
 const plots=(project.plots?.threads??[]).flatMap(plot=>{const beat=plot.beats.find(beat=>beat.sceneId===sceneId);return beat?[{plot,beat}]:[];});
 const arcs=(project.plots?.arcs??[]).flatMap(arc=>{const beat=arc.beats.find(beat=>beat.sceneId===sceneId);return beat?[{arc,beat,entry:project.worldbuilding?.entries.find(entry=>entry.id===arc.entryId)}]:[];});
 const events=sortedEvents({schemaVersion:1,events:(project.timeline?.events??[]).filter(event=>event.sceneIds.includes(sceneId))},'date');
 const pending=items.filter(item=>{
  if(item.idea&&!['idea','deciding','decided'].includes(item.idea.status))return false;
  return item.sceneId===sceneId||item.issue?.relatedSceneIds?.includes(sceneId)||!!item.issue?.eventId&&events.some(event=>event.id===item.issue?.eventId)||item.idea?.sceneIds?.includes(sceneId)||item.idea?.plotIds?.some(id=>plots.some(({plot})=>plot.id===id));
 });
 return {chapter,scene,plots,arcs,events,pending};
}
