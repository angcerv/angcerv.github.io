import ActionMenu from './ActionMenu';
import type { Ref } from 'react';
import { Search, ListChecks, ClipboardList, FileText, BookOpen, PanelsTopLeft, MessageSquare, History, Plus, Info, Maximize2, LibraryBig } from 'lucide-react';
import {t,buttonLabel} from './i18n';

type Props={onFind?:()=>void;commentCount?:number;onComments?:()=>void;onCheckpoints?:()=>void;mode?:'scene'|'chapter'|'board'|'planning';onMode?:(mode:'scene'|'chapter'|'board'|'planning')=>void;hasChapter:boolean;hasScene:boolean;toolsOpen:boolean;worldOpen:boolean;toolsTrigger:Ref<HTMLButtonElement>;onAddScene:()=>void;onToggleTools:()=>void;onFocus:()=>void;onToggleWorld:()=>void};
export default function ManuscriptActions({onFind,hasChapter,hasScene,toolsOpen,worldOpen,toolsTrigger,onAddScene,onToggleTools,onFocus,onToggleWorld,mode,onMode,onCheckpoints,onComments,commentCount=0}:Props){
 if(!hasChapter)return null;
 const reading=mode!=='board'&&mode!=='planning';
 const reviewCount=reading?commentCount:0;
 return <div className="manuscript-actions" role="toolbar" aria-label={t('Editor actions')}>
  <div className="manuscript-leading-actions"><div className="manuscript-content-actions" role="group" aria-label={t('Content actions')}>
   <button type="button" className="manuscript-action manuscript-add-scene" title={t('New scene')} onClick={onAddScene}><Plus size={15} aria-hidden="true"/><span>{t('New scene')}</span></button>
   {onFind&&reading&&<button type="button" className="manuscript-action" title={t('Find and replace')} aria-label={t('Find and replace')} onClick={onFind}><Search size={16}/></button>}
   {(onComments||onCheckpoints)&&<ActionMenu label={t('Review tools')+(reviewCount>0?` · ${reviewCount}`:'')} actions={[...(onComments&&reading?[{label:t('Review comments')+` · ${commentCount}`,icon:<MessageSquare size={15}/>,onClick:onComments}]:[]),...(onCheckpoints?[{label:t('Revision checkpoints'),icon:<History size={15}/>,onClick:onCheckpoints}]:[])]}><ListChecks size={15}/><span>{t('Review')}</span><span className="compact-count" data-empty={reviewCount===0} aria-hidden="true">{reviewCount>99?'99+':reviewCount||''}</span></ActionMenu>}
  </div>
  {reading&&<div className="manuscript-view-actions" role="group" aria-label={t('View and panels')}>
   <button ref={toolsTrigger} disabled={!reading} type="button" className="manuscript-action" aria-label={hasScene?t('Writing context'):t('Chapter details')} title={hasScene?t('Writing context'):t('Chapter details')} aria-expanded={toolsOpen} aria-controls="manuscript-tools" onClick={onToggleTools}><Info size={16} aria-hidden="true"/><span>{t('Context')}</span></button>
   <button disabled={!reading||!hasScene} type="button" className="manuscript-action" title={t('Focus mode (⌘⇧Enter / Ctrl+Shift+Enter)')} aria-label={t('Enter focus mode')} onClick={onFocus}><Maximize2 size={16} aria-hidden="true"/></button>
   <button disabled={!reading||!hasScene} type="button" className="manuscript-action" title={t('Toggle scene references')} aria-label={t('Toggle scene references')} aria-expanded={worldOpen} aria-controls="scene-world-reference-panel" onClick={onToggleWorld}><LibraryBig size={15} aria-hidden="true"/></button>
  </div>}</div>
  {onMode&&<div className="manuscript-view-selector"><div className="manuscript-reading-mode" role="group" aria-label={t(reading?'Reading view':'Chapter planning')}>{(reading?[{id:'scene',label:'Scene',Icon:FileText,disabled:!hasScene},{id:'chapter',label:'Complete chapter',Icon:BookOpen,disabled:false}]:[{id:'planning',label:'Outline',Icon:ClipboardList,disabled:false},{id:'board',label:'Scene board',Icon:PanelsTopLeft,disabled:false}]).map(({id,label,Icon,disabled})=><button type="button" key={id} aria-pressed={mode===id} disabled={disabled} title={buttonLabel(label)} aria-label={buttonLabel(label)} onClick={()=>onMode(id as NonNullable<Props['mode']>)}><Icon size={16}/><span>{t(id==='chapter'?'Chapter':label)}</span></button>)}</div>{reading&&<button type="button" className="manuscript-action" title={t('Plan this chapter')} aria-label={t('Plan this chapter')} onClick={()=>onMode('planning')}><ClipboardList size={16}/></button>}</div>}

 </div>;
}
