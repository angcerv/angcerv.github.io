import {focusDialog} from './dialogFocus';
import DecisionFragments from './DecisionFragmentEditor';
import type {DecisionFragment} from './decisionFragments';
import {statusTone} from './semanticStatus';
import Dropdown from './Dropdown';
import EntrySection from './EntrySection';
import ProjectModal from './ProjectModal';
import {X,Unlink} from 'lucide-react';
import type {Chapter} from './model';
import type {ProjectPlots} from './plotThreads';
import LongTextEditor from './LongTextEditor';
import {useEffect,useRef,useState} from 'react';
import {createPortal} from 'react-dom';
import {message,t,buttonLabel} from './i18n';
import type {Worldbuilding} from './worldbuilding';
import {ideaStatusLabels,ideaCategory,ideaCategoryLabels,ideaUpdates,ideaDecisionError} from './worldIdeas';
import type {WorldIdea,WorldIdeaStatus,IdeaCategory,DecisionUpdate} from './worldIdeas';
export default function WorldIdeaEditor({onOpenFragment,idea,world,onSave,onClose,onOpenEntry,chapters=[],plots,onOpenScene,onOpenPlot}:{onOpenFragment?:(fragment:DecisionFragment)=>void;chapters?:Chapter[];plots?:ProjectPlots;onOpenScene?:(id:string)=>void;onOpenPlot?:(id:string)=>void;idea:WorldIdea;world:Worldbuilding;onSave:(idea:WorldIdea)=>void;onClose:()=>void;onOpenEntry?:(id:string)=>void}){
 const [draft,setDraft]=useState(()=>({...idea,updates:(idea.updates??[]).map(update=>({...update})),category:ideaCategory(idea),entryIds:[...idea.entryIds],sceneIds:[...(idea.sceneIds??[])],plotIds:[...(idea.plotIds??[])]})),[error,setError]=useState(''),dialog=useRef<HTMLDialogElement>(null);
 const [confirmClose,setConfirmClose]=useState(false);
 useEffect(()=>{const previous=document.activeElement as HTMLElement|null,d=dialog.current;d?.showModal();focusDialog(d);return()=>{d?.close();if(previous?.isConnected)previous.focus();};},[]);
 useEffect(()=>{if(error){const alert=dialog.current?.querySelector<HTMLElement>('[role=alert]');alert?.focus();alert?.scrollIntoView({block:'nearest'});}},[error]);
 const updates=ideaUpdates(draft),showDecision=!!draft.decision||draft.status==='decided'||draft.status==='incorporated';
 function changeLinks(key:'entryIds'|'sceneIds'|'plotIds',ids:string[]){const next={...draft,[key]:ids};setDraft({...next,updates:ideaUpdates(next)});}
 function changeUpdates(next:DecisionUpdate[]){setDraft({...draft,updates:next,status:draft.status==='incorporated'?'decided':draft.status});}
 function requestClose(){if(ideaDraftSignature(draft)!==ideaDraftSignature(idea))setConfirmClose(true);else onClose();}
 function commit(){if(confirmClose)return false;try{const problem=ideaDecisionError(draft,idea);if(problem){setError(t(problem));return false;}onSave({...draft,title:draft.title.trim(),updates:ideaUpdates(draft)});setError('');return true;}catch(error){setError(message(String(error)));return false;}}
 const content=<><dialog ref={dialog} className="world-idea-dialog" aria-labelledby="world-idea-title" onCancel={e=>{e.preventDefault();if(!confirmClose)requestClose();}}><form onSubmit={e=>{e.preventDefault();if(draft.title.trim()&&commit())onClose();}}>
 <header className="ui-dialog-heading"><h2 id="world-idea-title">{t('Idea or decision')}</h2><button type="button" className="icon-button ui-close-button" aria-label={t('Close')} title={t('Close')} onClick={requestClose}><X size={18} aria-hidden="true"/></button></header>
 <div className="world-idea-body">{error&&<p className="prompt-error" role="alert" tabIndex={-1}>{error}</p>}<label>{t('Title')}<input required maxLength={300} value={draft.title} onChange={e=>setDraft({...draft,title:e.target.value})}/></label>

 <div className="world-idea-metadata"><div className="ui-form-field"><label htmlFor="idea-category">{t('Idea category')}</label><Dropdown id="idea-category" aria-label={t('Idea category')} value={draft.category} onChange={category=>setDraft({...draft,category:category as IdeaCategory})} options={Object.entries(ideaCategoryLabels).map(([value,label])=>({value,label:buttonLabel(label)}))}/></div>
 <div className="ui-form-field"><label htmlFor="idea-status">{t('Idea status')}</label><Dropdown id="idea-status" aria-label={t('Idea status')} value={draft.status} onChange={status=>setDraft({...draft,status:status as WorldIdeaStatus})} options={Object.entries(ideaStatusLabels).map(([value,label])=>({value,label:buttonLabel(label),tone:statusTone('idea',value)}))}/></div>
 </div> <div className="world-idea-description"><label id="world-idea-description-label" htmlFor="world-idea-description">{t('Description')}</label><LongTextEditor id="world-idea-description" value={draft.description} onChange={description=>setDraft({...draft,description})}/></div>{showDecision&&<section className="idea-decision"><div className="world-idea-description"><label id="world-idea-decision-label" htmlFor="world-idea-decision">{t('Decision taken')}</label><LongTextEditor id="world-idea-decision" value={draft.decision??''} onChange={decision=>setDraft({...draft,decision})}/></div><p className="world-hint">{t('Select the related items that need changes. Mark them reviewed after applying the decision.')}</p><p role="status">{t('{0} of {1} updates reviewed',updates.filter(update=>update.done).length,updates.length)}</p>{draft.status==='decided'&&<p className="world-hint">{t('This decision stays in Pending until you mark it as Incorporated.')}</p>}</section>}<div className="world-idea-relations"><IdeaLinkedChoices updateKind="entry" updates={updates} onUpdates={showDecision?changeUpdates:undefined} title={t('Related entries')} searchLabel={t('Search entries')} options={world.entries.map(entry=>({id:entry.id,title:entry.title||t('Untitled entry'),available:!entry.archived}))} selected={draft.entryIds} onChange={ids=>changeLinks('entryIds',ids)} missingLabel={t('Deleted entry')} onOpen={onOpenEntry?id=>{if(commit()){onClose();onOpenEntry(id);}}:undefined} canOpen={!!draft.title.trim()}/>
 <IdeaLinkedChoices updateKind="scene" updates={updates} onUpdates={showDecision?changeUpdates:undefined} title={t('Related scenes')} options={chapters.flatMap(chapter=>chapter.scenes.map(scene=>({id:scene.id,title:`${chapter.title} / ${scene.title}`})))} selected={draft.sceneIds} onChange={ids=>changeLinks('sceneIds',ids)} missingLabel={t('Deleted scene')} onOpen={onOpenScene? id=>{if(commit()){onClose();onOpenScene(id);}}:undefined} canOpen={!!draft.title.trim()}/>
 <IdeaLinkedChoices updateKind="plot" updates={updates} onUpdates={showDecision?changeUpdates:undefined} title={t('Related plots')} options={(plots?.threads??[]).map(plot=>({id:plot.id,title:plot.title}))} selected={draft.plotIds} onChange={ids=>changeLinks('plotIds',ids)} missingLabel={t('Deleted plot')} onOpen={onOpenPlot? id=>{if(commit()){onClose();onOpenPlot(id);}}:undefined} canOpen={!!draft.title.trim()}/>

 <EntrySection title={t('Affected fragments')} variant="compact" keepMounted defaultOpen={!!draft.fragments?.length} count={draft.fragments?.length||undefined}><DecisionFragments idea={draft} world={world} chapters={chapters} plots={plots} onChange={fragments=>setDraft({...draft,fragments})} onOpen={onOpenFragment?fragment=>{if(commit()){onClose();onOpenFragment(fragment);}}:undefined}/></EntrySection>
 </div></div><footer><button type="button" onClick={requestClose} className="quick-action quick-action-text">{t('Cancel')}</button><button className="primary-button" disabled={confirmClose||!draft.title.trim()} type="submit">{buttonLabel(showDecision?'Save decision':'Save idea')}</button></footer>
 </form></dialog>{confirmClose&&<ProjectModal title={t('Discard changes')} variant="confirmation" onClose={()=>setConfirmClose(false)}><p>{t('Unsaved changes will be lost if you discard them.')}</p><div className="welcome-actions"><button type="button" className="quick-action quick-action-text" onClick={()=>setConfirmClose(false)}>{t('Keep editing')}</button><button type="button" className="danger-button" onClick={onClose}>{t('Discard changes')}</button></div></ProjectModal>}</>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}

export function IdeaLinkedChoices({title,options,selected,onChange,missingLabel,onOpen,canOpen,searchLabel,updateKind,updates=[],onUpdates}:{title:string;options:{id:string;title:string;available?:boolean}[];selected:string[];onChange:(ids:string[])=>void;missingLabel:string;onOpen?:(id:string)=>void;canOpen:boolean;searchLabel?:string;updateKind?:DecisionUpdate['kind'];updates?:DecisionUpdate[];onUpdates?:(updates:DecisionUpdate[])=>void}){
 const [query,setQuery]=useState('');
 const normalize=(value:string)=>value.normalize('NFD').replace(/\p{M}/gu,'').toLocaleLowerCase().replace(/\s+/gu,' ').trim();
 const available=options.filter(option=>option.available!==false&&!selected.includes(option.id));
 const results=available.filter(option=>normalize(option.title).includes(normalize(query)));
 return <fieldset><legend>{title}</legend>
 {selected.length>0&&<><p className="idea-relation-heading">{t('Linked')}</p><div className="idea-linked-entries">{selected.map(id=>{const option=options.find(item=>item.id===id),change=updates.find(update=>update.kind===updateKind&&update.id===id);return <div key={id}><span>{option?.title??missingLabel}</span>{onUpdates&&updateKind&&<div className="idea-update-controls"><label><input type="checkbox" checked={!!change} aria-label={t('Needs changes: {0}',option?.title??missingLabel)} onChange={event=>onUpdates(event.target.checked?[...updates,{kind:updateKind,id,done:false}]:updates.filter(update=>update.kind!==updateKind||update.id!==id))}/>{t('Needs changes')}</label>{change&&<label><input type="checkbox" checked={change.done} aria-label={t('Changes reviewed: {0}',option?.title??missingLabel)} onChange={event=>onUpdates(updates.map(update=>update.kind===updateKind&&update.id===id?{...update,done:event.target.checked}:update))}/>{t('Reviewed')}</label>}</div>}{option&&onOpen&&<button type="button" className="quick-action quick-action-text" disabled={!canOpen} onClick={()=>onOpen(id)}>{t('Save and open')}</button>}<button type="button" className="quick-action" aria-label={t('Unlink {0}',option?.title??missingLabel)} title={t('Unlink')} onClick={event=>{event?.currentTarget.closest('fieldset')?.querySelector<HTMLButtonElement>('.ui-section-disclosure-toggle')?.focus();onChange(selected.filter(value=>value!==id));}}><Unlink size={16} aria-hidden="true"/></button></div>;})}</div></>}
 <EntrySection title={t('Add links')} variant="compact" keepMounted defaultOpen={false}><input type="search" aria-label={searchLabel??t('Search {0}',title)} placeholder={searchLabel??t('Search {0}',title)} value={query} onChange={e=>setQuery(e.target.value)}/>
 <div className="idea-entry-choices">{results.map(option=><label key={option.id}><input type="checkbox" checked={false} onChange={e=>{if(e.target.checked){e.currentTarget?.closest('fieldset')?.querySelector<HTMLInputElement>('input[type=search]')?.focus();onChange([...selected,option.id]);}}}/>{option.title}</label>)}{!results.length&&<p className="ui-empty-state ui-empty-state-compact">{query.trim()?t('No matching items.'):t('No more items available.')}</p>}</div>
 </EntrySection></fieldset>;
}

// Compare persisted fields, ignoring optional empty collections and link order.
export function ideaDraftSignature(idea:WorldIdea){
 return JSON.stringify({title:idea.title.trim(),description:idea.description,category:ideaCategory(idea),status:idea.status,decision:idea.decision??'',entryIds:[...idea.entryIds].sort(),sceneIds:[...(idea.sceneIds??[])].sort(),plotIds:[...(idea.plotIds??[])].sort(),updates:ideaUpdates(idea).sort((a,b)=>`${a.kind}:${a.id}`.localeCompare(`${b.kind}:${b.id}`)),fragments:idea.fragments??[]});
}
