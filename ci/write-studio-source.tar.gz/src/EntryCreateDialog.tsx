import {focusDialog} from './dialogFocus';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { t } from './i18n';
import Dropdown from './Dropdown';
import type { Worldbuilding } from './worldbuilding';

export default function EntryCreateDialog({world,initialTemplateId,onSave,onCancel}:{world:Worldbuilding;initialTemplateId:string;onSave:(name:string,templateId:string)=>void;onCancel:()=>void}){
 const dialog=useRef<HTMLDialogElement>(null),input=useRef<HTMLInputElement>(null),previous=useRef(typeof document==='undefined'?null:document.activeElement as HTMLElement|null);
 const [name,setName]=useState(''),[templateId,setTemplateId]=useState(world.templates.some(template=>template.id===initialTemplateId)?initialTemplateId:world.templates[0]?.id??'');
 const valid=!!name.trim()&&world.templates.some(template=>template.id===templateId);
 useEffect(()=>{const node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous.current?.isConnected)previous.current.focus();};},[]);
 const content=<dialog ref={dialog} className="field-create-dialog entry-create-dialog" aria-labelledby="entry-create-title" onCancel={event=>{event.preventDefault();onCancel();}}>
  <header><h2 id="entry-create-title">{t('New entry')}</h2><button title={t("Close")} type="button" className="icon-button ui-close-button" aria-label={t('Close')} onClick={onCancel}><X size={18}/></button></header>
  <form onSubmit={event=>{event.preventDefault();if(valid)onSave(name.trim(),templateId);}}><div className="field-create-body">
   <label htmlFor="new-entry-name">{t('Entry name')}</label><input ref={input} id="new-entry-name" required value={name} onChange={event=>setName(event.target.value)}/>
   <label id="new-entry-template-label" htmlFor="new-entry-template">{t('Template')}</label><Dropdown id="new-entry-template" aria-labelledby="new-entry-template-label" value={templateId} required onChange={setTemplateId} options={world.templates.map(template=>({value:template.id,label:template.title||t('Untitled template')}))}/>
  </div><footer><button type="button" className="field-cancel-button quick-action quick-action-text" onClick={onCancel}>{t('Cancel')}</button><button type="submit" className="primary-button" disabled={!valid}>{t('Create')}</button></footer></form>
 </dialog>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}
