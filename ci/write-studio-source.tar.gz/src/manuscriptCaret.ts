import {Extension} from '@tiptap/core';
import {Plugin} from '@tiptap/pm/state';

// Keep the paragraph's reading line-height, but give its editable inline text
// normal font metrics so the native caret does not fill the interline space.
// This is a view wrapper only: the document schema, Markdown and history stay intact.
export const ManuscriptCaret=Extension.create({
 name:'manuscriptCaret',
 addProseMirrorPlugins(){
  return [new Plugin({props:{nodeViews:{paragraph(_node,view){
   const document=view.dom.ownerDocument;
   const dom=document.createElement('p'),contentDOM=document.createElement('span');
   contentDOM.className='manuscript-inline-text';
   dom.appendChild(contentDOM);
   return {dom,contentDOM};
  }}}})];
 }
});
