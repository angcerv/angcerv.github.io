export type MarkerLabelOffset={angle:number;distance:number};
export const markerLabelMinDistance=8,markerLabelMaxDistance=96;
export const markerLabelFont='500 13px system-ui, sans-serif';
const angle=(n:number)=>((n%360)+360)%360;
/** Separation is the shortest distance between the icon edge and the label rectangle. */
export function markerLabelCenter(offset:MarkerLabelOffset,width:number,height:number){
 const radians=offset.angle*Math.PI/180,c=Math.cos(radians),s=Math.sin(radians),target=16+Math.max(markerLabelMinDistance,Math.min(markerLabelMaxDistance,offset.distance));
 let low=0,high=target+Math.hypot(width,height);
 for(let i=0;i<32;i++){const mid=(low+high)/2,d=Math.hypot(Math.max(0,Math.abs(mid*c)-width/2),Math.max(0,Math.abs(mid*s)-height/2));if(d<target)low=mid;else high=mid;}
 return {x:c*high,y:s*high};
}
export function markerLabelOffset(center:{x:number;y:number},width:number,height:number):MarkerLabelOffset{
 const distance=Math.hypot(Math.max(0,Math.abs(center.x)-width/2),Math.max(0,Math.abs(center.y)-height/2))-16;
 return {angle:angle(Math.atan2(center.y,center.x)*180/Math.PI),distance:Math.max(markerLabelMinDistance,Math.min(markerLabelMaxDistance,distance))};
}
export function markerLabelLeader(x:number,y:number,width:number,height:number){
 const cx=x+width/2,cy=y+height/2,edge=Math.max(0,cx?1-width/2/Math.abs(cx):0,cy?1-height/2/Math.abs(cy):0),dx=cx*edge,dy=cy*edge,distance=Math.hypot(dx,dy);
 return distance>29?{x1:dx/distance*18,y1:dy/distance*18,x2:dx-dx/distance*2,y2:dy-dy/distance*2}:undefined;
}
/** Used only by the live canvas. Pure layout/export can supply their own measurement. */
let measurementDocument:Document|undefined,context:CanvasRenderingContext2D|null|undefined;
const widths=new Map<string,number>();
export function browserMarkerLabelWidth(text:string){
 if(typeof document==='undefined')return conservativeMarkerLabelWidth(text);
 if(document!==measurementDocument){measurementDocument=document;context=undefined;widths.clear();}
 if(context===undefined){try{context=document.createElement('canvas').getContext('2d');}catch{context=null;}}
 if(!context||typeof context.measureText!=='function')return conservativeMarkerLabelWidth(text);
 const cached=widths.get(text);if(cached!==undefined)return cached;
 context.font=markerLabelFont;const width=Math.ceil(context.measureText(text).width)+2;
 if(!Number.isFinite(width))return conservativeMarkerLabelWidth(text);
 widths.set(text,width);if(widths.size>1000)widths.delete(widths.keys().next().value!);return width;
}
export function conservativeMarkerLabelWidth(text:string){return Array.from(text).reduce((sum,c)=>sum+(/[il.,' ]/.test(c)?4:/[MW@]/.test(c)||c.charCodeAt(0)>255?13:9),0);}
/** Explicit line breaks keep layout and rendering identical; ordinary names are never ellipsized. */
export function wrapMarkerLabel(text:string,maximum:number,measure:(text:string)=>number){
 const lines:string[]=[];let line='';
 for(const word of text.split(' ')){
  const candidate=line?line+' '+word:word;
  if(measure(candidate)<=maximum){line=candidate;continue;}
  if(line){lines.push(line);line='';}
  for(const char of Array.from(word)){if(line&&measure(line+char)>maximum){lines.push(line);line='';}line+=char;}
 }
 if(line||!lines.length)lines.push(line);
 if(lines.length>3){lines.length=3;let last=Array.from(lines[2]);while(last.length&&measure(last.join('')+'…')>maximum)last.pop();lines[2]=last.join('')+'…';}
 return lines;
}
