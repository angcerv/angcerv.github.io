import { useId, useRef, useState } from 'react';
import type { ReactNode } from 'react';
import { ChevronDown } from 'lucide-react';
export default function EntrySection({defaultOpen=true,id,title,count,children,variant,keepMounted=false,summary}:{keepMounted?:boolean;summary?:string;defaultOpen?:boolean;id?:string;title:string;count?:number;children:ReactNode;variant?:'compact'}){
 const [open,setOpen]=useState(defaultOpen);
 const generatedId=useId(),bodyId=`${id??generatedId}-body`,visited=useRef(defaultOpen);
 if(open)visited.current=true;
 if(variant==='compact')return <div id={id} className="ui-section-disclosure"><button type="button" className="ui-section-disclosure-toggle" aria-expanded={open} aria-controls={bodyId} onClick={()=>setOpen(!open)}><ChevronDown size={15} aria-hidden="true"/><span>{title}</span>{summary&&<span className="ui-section-disclosure-summary">{summary}</span>}{count!==undefined&&<span>{count}</span>}</button><div className="ui-section-disclosure-collapse" data-open={open}><div id={bodyId} inert={!open} aria-hidden={!open}>{(keepMounted||visited.current)&&children}</div></div></div>;
 return <details id={id} data-lore-section={id?true:undefined} className="entry-field-section" open={open} onToggle={event=>setOpen(event.currentTarget.open)}><summary><ChevronDown size={15}/><h3>{title}</h3><span>{count}</span></summary><div className="entry-section-body">{children}</div></details>;
}
