import {useState} from 'react';
import ProjectModal from './ProjectModal';
import Dropdown from './Dropdown';
import {deferPanel} from './DeferredPanel';
import {t,buttonLabel} from './i18n';
import {emptyWorld} from './worldbuilding';
import type {Project} from './model';
import type {EntryPackage} from './entryTransfer';
import {projectExportKinds,projectExportLabels} from './projectExport';
import type {ProjectExportKind,ProjectExportRequest} from './projectExport';
const Manuscript=deferPanel(()=>import('./ExportDialog'));
const Planning=deferPanel(()=>import('./PlanningExportDialog'));
const Encyclopedia=deferPanel(()=>import('./EncyclopediaExportDialog'));
const Entries=deferPanel(()=>import('./EntryTransferDialog'));
const Templates=deferPanel(()=>import('./TemplateExportPanel'));
export default function ProjectExportDialog({project,path,request,initialBookId='',onExportEntries,onExportTemplates,onLoadEntries,onImportEntries,externalError='',onClearError,onClose}:{onClearError?:()=>void;project:Project;path:string;request:ProjectExportRequest;initialBookId?:string;onExportEntries:(ids:string[])=>Promise<boolean>;onExportTemplates:(ids:string[])=>Promise<boolean>;onLoadEntries:()=>Promise<EntryPackage|null>;onImportEntries:(packet:EntryPackage,ids:string[])=>Promise<boolean>;externalError?:string;onClose:()=>void}){
 const [kind,setKind]=useState<ProjectExportKind|''>(request.kind??''),[visited,setVisited]=useState<ProjectExportKind[]>(request.kind?[request.kind]:[]),[busy,setBusy]=useState(false);
 const close=()=>{if(!busy)onClose();};
 return <ProjectModal title={t('Export project content')} busy={busy} onClose={close} className="project-export-dialog"><div className="ui-form-field"><label htmlFor="project-export-kind">{t('Content to export')}</label><Dropdown id="project-export-kind" value={kind} disabled={busy} placeholder={t('Choose what to export')} options={projectExportKinds.map(value=>({value,label:buttonLabel(projectExportLabels[value])}))} onChange={value=>{if(busy||!projectExportKinds.includes(value as ProjectExportKind))return;onClearError?.();setKind(value as ProjectExportKind);setVisited(previous=>previous.includes(value as ProjectExportKind)?previous:[...previous,value as ProjectExportKind]);}}/></div>
  {visited.map(type=><div key={type} className="project-export-panel" hidden={type!==kind} inert={type!==kind}>
   {type==='manuscript'&&<Manuscript embedded onBusyChange={setBusy} project={project} initialBookId={initialBookId} onClose={close}/>}
   {type==='planning'&&<Planning embedded onBusyChange={setBusy} project={project} initialBookId={initialBookId} onClose={close}/>}
   {type==='encyclopedia'&&<Encyclopedia embedded onBusyChange={setBusy} project={project} path={path} onClose={close}/>}
   {type==='entries'&&<>{!path&&<p className="field-hint">{t('Save the project before exporting entries.')}</p>}<Entries canExport={!!path} embedded onBusyChange={setBusy} mode="export" initialId="" initialIds={request.kind==='entries'?request.ids:undefined} world={project.worldbuilding??emptyWorld} relations={project.entryRelations} onLoad={onLoadEntries} onExport={onExportEntries} onImport={onImportEntries} externalError={externalError} onClose={close}/></>}
   {type==='templates'&&<Templates onBusyChange={setBusy} world={project.worldbuilding??emptyWorld} initialIds={request.kind==='templates'?request.ids:undefined} onExport={onExportTemplates} externalError={externalError}/>}
  </div>)}
 </ProjectModal>;
}
