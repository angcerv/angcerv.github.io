import {drawingObjectBounds,drawingLayerEditable,moveDrawingObjects} from './mapDrawing';
import type {DrawingObject,DrawingPoint,MapDrawing} from './mapDrawing';
import type {MapLayer} from './maps';
export type DrawingArrangement='left'|'center-x'|'right'|'top'|'center-y'|'bottom'|'distribute-x'|'distribute-y';
/** Grid is an editor overlay; snapping never alters paint, panning or sampling coordinates. */
export function snapDrawingPoint(point:DrawingPoint,width:number,height:number,spacing:number):DrawingPoint{
 const step=Math.max(4,Math.min(512,Number.isFinite(spacing)?spacing:64));
 return {x:Math.max(0,Math.min(1,Math.round(point.x*width/step)*step/width)),y:Math.max(0,Math.min(1,Math.round(point.y*height/step)*step/height))};
}
export function arrangeDrawingObjects(drawing:MapDrawing,ids:string[],layers:MapLayer[],mode:DrawingArrangement):DrawingObject[]{
 const targets=drawing.objects.filter(o=>ids.includes(o.id)&&drawingLayerEditable(layers,o.layerId));
 if(targets.length<(mode.startsWith('distribute')?3:2))return drawing.objects;
 const horizontal=['left','center-x','right','distribute-x'].includes(mode),axis=horizontal?'x':'y',extent=horizontal?'width':'height',dimension=horizontal?drawing.width:drawing.height;
 const bounds=targets.map(object=>({object,b: drawingObjectBounds(object,drawing.width,drawing.height)}));
 const start=Math.min(...bounds.map(({b})=>b[axis])),end=Math.max(...bounds.map(({b})=>b[axis]+b[extent]));
 const deltas=new Map<string,DrawingPoint>();
 if(mode.startsWith('distribute')){
  bounds.sort((a,b)=>a.b[axis]-b.b[axis]||drawing.objects.indexOf(a.object)-drawing.objects.indexOf(b.object));
  const gap=(end-start-bounds.reduce((sum,{b})=>sum+b[extent],0))/(bounds.length-1);let next=start;
  for(const {object,b} of bounds){deltas.set(object.id,{x:horizontal?(next-b[axis])/dimension:0,y:horizontal?0:(next-b[axis])/dimension});next+=b[extent]+gap;}
 }else for(const {object,b} of bounds){const offset=mode==='left'||mode==='top'?start-b[axis]:mode==='right'||mode==='bottom'?end-b[axis]-b[extent]:(start+end-b[extent])/2-b[axis];deltas.set(object.id,{x:horizontal?offset/dimension:0,y:horizontal?0:offset/dimension});}
 let result=drawing.objects;for(const [id,delta] of deltas)if(Math.abs(delta.x)>1e-12||Math.abs(delta.y)>1e-12)result=moveDrawingObjects(result,[id],delta);return result;
}
export function reorderDrawingObject(objects:DrawingObject[],id:string,direction:'up'|'down',layers:MapLayer[]):DrawingObject[]{
 const index=objects.findIndex(o=>o.id===id),object=objects[index];if(!object||!drawingLayerEditable(layers,object.layerId))return objects;
 const peers=objects.map((o,i)=>o.layerId===object.layerId?i:-1).filter(i=>i>=0),position=peers.indexOf(index),other=peers[position+(direction==='up'?1:-1)];if(other===undefined)return objects;
 const next=[...objects];[next[index],next[other]]=[next[other],next[index]];return next;
}
export function moveDrawingObjectsToLayer(objects:DrawingObject[],ids:string[],layerId:string,layers:MapLayer[]):DrawingObject[]{
 if(layerId&&!layers.some(layer=>layer.id===layerId)||!drawingLayerEditable(layers,layerId||undefined))return objects;
 let changed=false;const next=objects.map(o=>{if(!ids.includes(o.id)||!drawingLayerEditable(layers,o.layerId)||(o.layerId??'')===layerId)return o;changed=true;return {...o,layerId:layerId||undefined};});return changed?next:objects;
}
