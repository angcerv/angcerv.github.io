import {workspaceRouteExists} from './workspaceNavigation';
import type {WorkspaceVisit} from './workspaceNavigation';
import type {Project} from './model';
import {fromMarkdown,getSceneStatus} from './model';
import type {ContinuityIssue,ContinuityKind} from './continuity';
import {reviewContinuity} from './continuity';
import {fragmentDocumentIndex,fragmentRange,makeFragment} from './decisionFragments';
import type {DecisionFragment} from './decisionFragments';
import {continuityEvidence,loadContinuityDismissals} from './narrativeContinuity';
import type {ReviewComment} from './reviewComments';
import {countSceneWords} from './writingGoals';
import {t} from './i18n';
export type ReviewSubject=
 |{kind:'comment';sceneId:string;commentId:string}
 |{kind:'review'|'develop';sceneId:string}
 |{kind:'continuity';issueId:string;issueKind:ContinuityKind;sceneId?:string;entryId?:string;eventId?:string;mapId?:string;routeId?:string;markerId?:string;fragment?:DecisionFragment};
export type ReviewState={title:string;context:string;detail:string;status:'pending'|'resolved'|'dismissed'|'missing'|'unavailable';statusLabel:string;sceneId?:string;range?:{from:number;to:number};comment?:ReviewComment;issue?:ContinuityIssue};
export function continuityReviewSubject(project:Project,issue:ContinuityIssue):ReviewSubject{
 const scene=project.chapters.flatMap(chapter=>chapter.scenes).find(scene=>scene.id===issue.sceneId);
 let fragment:DecisionFragment|undefined;
 if(scene&&issue.range){
  const index=fragmentDocumentIndex(fromMarkdown(scene.content)),from=index.positions.findIndex(position=>position.from===issue.range!.from),last=index.positions.findIndex(position=>position.to===issue.range!.to);
  if(from>=0&&last>=from)fragment=makeFragment({key:scene.id,kind:'scene',targetId:scene.id,title:scene.title,...index},from,last+1);
 }
 return {kind:'continuity',issueId:issue.id,issueKind:issue.kind,sceneId:issue.sceneId,entryId:issue.entryId,eventId:issue.eventId,mapId:issue.mapId,routeId:issue.routeId,markerId:issue.markerId,fragment};
}
export function currentReview(project:Project,subject:ReviewSubject,issues?:ContinuityIssue[]):ReviewState{
 const chapter=project.chapters.find(chapter=>chapter.scenes.some(scene=>scene.id===subject.sceneId)),scene=chapter?.scenes.find(scene=>scene.id===subject.sceneId);
 const base={title:scene?.title||t('Review item'),context:chapter?`${chapter.title} / ${scene?.title??''}`:'',detail:'',sceneId:scene?.id};
 const missing=():ReviewState=>({...base,status:'missing',statusLabel:t('Source unavailable')});
 if(subject.kind==='comment'){
  const comment=scene?.reviewComments?.find(comment=>comment.id===subject.commentId);if(!comment)return missing();
  const index=fragmentDocumentIndex(fromMarkdown(scene!.content)),start=index.positions.findIndex(position=>position.from===comment.from),end=index.positions.findIndex(position=>position.to===comment.to);
  const attached=!comment.detached&&start>=0&&end>=start&&index.text.slice(start,end+1)===comment.quote;
  return {...base,title:comment.text,detail:comment.quote,comment,...(attached?{range:{from:comment.from,to:comment.to}}:{}),status:comment.resolved?'resolved':attached?'pending':'unavailable',statusLabel:t(comment.resolved?'Comment resolved':attached?'Pending':'The original fragment is unavailable.')};
 }
 if(subject.kind==='review'||subject.kind==='develop'){
  if(!scene)return missing();
  const pending=subject.kind==='review'?getSceneStatus(scene)==='inReview':getSceneStatus(scene)!=='finished'&&(!scene.synopsis?.trim()||countSceneWords(scene.content)===0);
  return {...base,status:pending?'pending':'resolved',statusLabel:t(pending?'Pending':'Scene updated')};
 }
 if(subject.kind!=='continuity')return missing();
 if(subject.sceneId&&!scene||subject.entryId&&!project.worldbuilding?.entries.some(entry=>entry.id===subject.entryId)||subject.eventId&&!project.timeline?.events.some(event=>event.id===subject.eventId))return missing();
 const map=project.maps?.maps.find(map=>map.id===subject.mapId);
 if(subject.mapId&&(!map||subject.routeId&&!map.routes?.some(route=>route.id===subject.routeId)||subject.markerId&&!map.markers.some(marker=>marker.id===subject.markerId)))return missing();
 const currentIssues=issues??reviewContinuity(project);
 let issue:ContinuityIssue|undefined;
 if(subject.fragment&&scene){
  const source={key:scene.id,kind:'scene' as const,targetId:scene.id,title:scene.title,...fragmentDocumentIndex(fromMarkdown(scene.content))},range=fragmentRange(source,subject.fragment);
  if(!range&&source.text.includes(subject.fragment.quote))return {...base,detail:subject.fragment.quote,status:'unavailable',statusLabel:t('Fragment changed or ambiguous')};
  issue=range?currentIssues.find(issue=>issue.kind===subject.issueKind&&issue.sceneId===scene.id&&issue.range?.from===range.from&&issue.range.to===range.to):undefined;
 }else issue=currentIssues.find(issue=>issue.id===subject.issueId&&issue.kind===subject.issueKind);
 if(!issue)return {...base,title:scene?.title||project.worldbuilding?.entries.find(entry=>entry.id===subject.entryId)?.title||project.timeline?.events.find(event=>event.id===subject.eventId)?.title||map?.routes?.find(route=>route.id===subject.routeId)?.title||map?.title||base.title,detail:subject.fragment?.quote??'',status:'resolved',statusLabel:t('Warning no longer detected')};
 const dismissed=loadContinuityDismissals(project.id)[issue.id]===continuityEvidence(project,issue);
 return {...base,title:issue.title,context:issue.context,detail:issue.excerpt??'',issue,range:issue.range,status:dismissed?'dismissed':'pending',statusLabel:t(dismissed?'Warning dismissed':'Pending')};
}

/** Restore view preferences and positions against live data, never a project snapshot. */
export function reviewReturnVisit(project:Project,origin:WorkspaceVisit):WorkspaceVisit{
 if(!workspaceRouteExists(project,origin.route))return {...origin,route:{...origin.route,view:'pending',pendingIdeaId:''},position:{scroll:[],details:[]}};
 // The manuscript may have changed while correcting the item. Restore the list
 // and its focus, rather than selecting old numeric text offsets.
 return origin.position.editor?{...origin,position:{...origin.position,editor:undefined}}:origin;
}
