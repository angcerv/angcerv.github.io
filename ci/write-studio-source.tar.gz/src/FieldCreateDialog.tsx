import {focusDialog} from './dialogFocus';
import {TextReferenceTools} from './TextReferenceUI';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import {message,t,buttonLabel} from './i18n';
import Dropdown from './Dropdown';
import { fieldLabels, isPicklist } from './worldbuilding';
import type { FieldType, PickOption, TemplateSection, Worldbuilding } from './worldbuilding';
import { parseOptions } from './PicklistFields';
export default function FieldCreateDialog({world,sections=[],onSave,onCancel}:{world:Worldbuilding;sections?:TemplateSection[];onSave:(name:string,type:FieldType,target:string|undefined,options:PickOption[]|undefined,birthDate:boolean,sectionId?:string,description?:string)=>void;onCancel:()=>void}) {
 const dialog=useRef<HTMLDialogElement>(null),input=useRef<HTMLInputElement>(null);
 const previous=useRef(typeof document==='undefined'?null:document.activeElement as HTMLElement|null);
 const [name,setName]=useState(''),[type,setType]=useState<FieldType>('shortText'),[target,setTarget]=useState(''),[optionText,setOptionText]=useState(''),[error,setError]=useState(''),[birthDate,setBirthDate]=useState(false),[section,setSection]=useState(''),[description,setDescription]=useState('');
 useEffect(()=>{const node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous.current?.isConnected)previous.current.focus();};},[]);
 function submit(){
  if(!name.trim())return;
  try {const options=isPicklist(type)?parseOptions(optionText):undefined;if(options&&!options.length)throw new Error(t('Add at least one option.'));onSave(name.trim(),type,type==='reference'?target||undefined:undefined,options,type==='date'&&birthDate,section||undefined,description.trim()||undefined);}catch(error){setError(String(error));}
 }
 const content=<dialog ref={dialog} className="field-create-dialog" aria-labelledby="field-create-title" onCancel={event=>{event.preventDefault();onCancel();}}>
  <header><h2 id="field-create-title">{t('Add a field')}</h2><button title={t("Close")} type="button" className="icon-button ui-close-button" aria-label={t('Close')} onClick={onCancel}><X size={18}/></button></header>
  <form onSubmit={event=>{event.preventDefault();submit();}}><div className="field-create-body">
   <label htmlFor="new-field-name">{t('Field name')}</label><input ref={input} id="new-field-name" required value={name} onChange={event=>{setName(event.target.value);setError('');}}/>
   <label htmlFor="new-field-description">{t('Description (optional)')}</label><><textarea id="new-field-description" rows={3} value={description} placeholder={t('Explain what this field means or how to fill it in.')} onChange={event=>setDescription(event.target.value)}/><TextReferenceTools targetId="new-field-description" value={description} onChange={event=>setDescription(event.target.value)}/></><p className="field-create-hint">{t('Shown from the information icon next to the field in entries.')}</p>
   <label id="new-field-type-label" htmlFor="new-field-type">{t('Field type')}</label><Dropdown id="new-field-type" aria-labelledby="new-field-type-label" value={type} options={Object.entries(fieldLabels).map(([value,label])=>({value,label:buttonLabel(label)}))} onChange={value=>{setType(value as FieldType);setError('');}}/>

   {type==='reference' &&<><label id="new-reference-template-label" htmlFor="new-reference-template">{t('Link to')}</label><Dropdown id="new-reference-template" aria-labelledby="new-reference-template-label" value={target} options={[{value:'',label:t('Any template')},...world.templates.map(template=>({value:template.id,label:template.title||t('Untitled template')}))]} onChange={setTarget}/></>}
   {type==='date'&&<div className="birth-date-setting"><label><input type="checkbox" checked={birthDate} onChange={event=>setBirthDate(event.target.checked)}/>{t('Use as birth date for age calculations')}</label><p className="field-create-hint">{t('One birth date field per template. Selecting this replaces the previous assignment without changing values.')}</p></div>}
   {isPicklist(type)&&<><label htmlFor="new-field-options">{t('Options · one per line')}</label><textarea id="new-field-options" rows={5} required value={optionText} onChange={event=>{setOptionText(event.target.value);setError('');}}/><p className="field-create-hint">{t('You can rename or archive these options later without losing selections.')}</p></>}
   <div className="field-section-setting"><label id="new-field-section-label" htmlFor="new-field-section">{t('Section (optional)')}</label><Dropdown id="new-field-section" aria-labelledby="new-field-section-label" value={section} onChange={setSection} options={[{value:'',label:t('No section')},...sections.map(section=>({value:section.id,label:section.title}))]}/></div>
   {error&&<p className="prompt-error" role="alert">{message(error)}</p>}
  </div><footer><button type="button" className="field-cancel-button quick-action quick-action-text" onClick={onCancel}>{t('Cancel')}</button><button type="submit" className="primary-button" disabled={!name.trim()||(isPicklist(type)&&!optionText.trim())}>{t('Save field')}</button></footer></form>
 </dialog>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}
