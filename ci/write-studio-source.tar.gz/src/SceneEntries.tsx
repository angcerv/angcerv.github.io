import { t } from './i18n';
import { useState } from 'react';
import { Unlink, ArrowUpRight } from 'lucide-react';
import type { Scene } from './model';
import type { Worldbuilding } from './worldbuilding';
import { searchEntries, referenceLabel } from './worldbuilding';
import { linkSceneEntry, unlinkSceneEntry } from './sceneLinks';

export default function SceneEntries({ scene, world, onChange, onOpen }: { scene: Scene; world: Worldbuilding; onChange: (scene: Scene) => void; onOpen: (id: string) => void }) {
  const [query, setQuery] = useState('');
  const linked = scene.entryIds ?? [];
  const choices = searchEntries(world, query).filter(entry => !linked.includes(entry.id));
  return <section className="scene-entries" aria-label={t("Scene references")}>
    <div className="scene-entry-chips">{linked.map(id => <div className="scene-entry-chip" key={id}>{world.entries.some(entry => entry.id === id) ? <button type="button" onClick={() => onOpen(id)}>{referenceLabel(world, id)}<ArrowUpRight size={13} /></button> : <span className="reference-missing">{t("Missing entry")}</span>}<button type="button" aria-label={t("Unlink {0} from scene", referenceLabel(world, id))} title={t("Unlink from scene")} onClick={() => onChange(unlinkSceneEntry(scene, id))}><Unlink size={13} /></button></div>)}</div>
    <label htmlFor="scene-entry-search">{t("Link entry…")}</label><input id="scene-entry-search" type="search" placeholder={t("Search entries…")} value={query} onChange={event => setQuery(event.target.value)} />
    <div className="scene-entry-choices">{choices.map(entry => <button type="button" key={entry.id} onClick={() => onChange(linkSceneEntry(scene, world, entry.id))}><span>{entry.title || t("Untitled entry")}</span><small>{world.templates.find(template => template.id === entry.templateId)?.title}</small><span>{t("Link")}</span></button>)}</div>
    {choices.length === 0 && <p className="world-hint">{query ? t("No matching entries available.") : world.entries.length ? t("No more active entries to link.") : t("Create entries in Worldbuilding, then link them here.")}</p>}
  </section>;
}
