import {t} from './i18n';
import {validCalendarOccurrence} from './storyCalendar';
import type {StoryCalendar} from './storyCalendar';
export type CalendarElementKind='months'|'weekdays'|'eras'|'seasons'|'holidays';
export type CalendarElementRequest={kind:CalendarElementKind;index?:number};
export type CalendarElementDraft={name:string;days:string;month:string;day:string;duration:string;startYear:string;description:string};
export function newCalendarElementDraft(calendar:StoryCalendar,{kind,index}:CalendarElementRequest):CalendarElementDraft{
 const result={name:'',days:'30',month:'1',day:'1',duration:'1',startYear:'0',description:''};
 if(index===undefined)return result;
 if(kind==='weekdays')return {...result,name:calendar.weekdays[index]??''};
 const item=calendar[kind]?.[index];return item?{...result,...Object.fromEntries(Object.entries(item).map(([key,value])=>[key,String(value??'')]))}:result;
}
export function calendarElementPatch(calendar:StoryCalendar,{kind,index}:CalendarElementRequest,draft:CalendarElementDraft):Partial<StoryCalendar>{
 const items=calendar[kind]??[],name=draft.name.trim(),limit={months:24,weekdays:20,eras:32,seasons:32,holidays:256}[kind];
 if(index!==undefined&&(!Number.isInteger(index)||index<0||index>=items.length))throw new Error(t('This calendar element no longer exists.'));
 if(index===undefined&&items.length>=limit)throw new Error(t('The calendar has reached the limit for these elements.'));
 if(!name||name.length>80)throw new Error(t('Enter a name of up to 80 characters.'));
 const names=kind==='weekdays'?calendar.weekdays:(calendar[kind]??[]).map(item=>item.name);
 if(names.some((value,i)=>i!==index&&value.trim().toLocaleLowerCase()===name.toLocaleLowerCase()))throw new Error(t('An element with this name already exists in this section.'));
 const number=(value:string,min:number,max:number)=>{const number=Number(value);if(!value.trim()||!Number.isInteger(number)||number<min||number>max)throw new Error(t('Check the dates and lengths. Use whole numbers within the indicated ranges.'));return number;};
 if(kind==='weekdays')return {weekdays:index===undefined?[...calendar.weekdays,name]:calendar.weekdays.map((value,i)=>i===index?name:value)};
 if(kind==='months'){
  if(calendar.mode==='gregorian'&&index===undefined)throw new Error(t('Gregorian calendars keep the twelve standard month lengths and leap-year rules.'));
  const item={name,days:calendar.mode==='gregorian'?calendar.months[index!].days:number(draft.days,1,1000)};
  return {months:index===undefined?[...calendar.months,item]:calendar.months.map((value,i)=>i===index?item:value)};
 }
 if(kind==='eras'){
  if(draft.description.length>4000)throw new Error(t('Enter a description of up to 4000 characters.'));
  const item={name,startYear:number(draft.startYear,-999999,999999),...(draft.description.trim()?{description:draft.description.trim()}:{})};
  if(calendar.eras.some((era,i)=>i!==index&&era.startYear===item.startYear))throw new Error(t('Another era already begins in this world year.'));
  return {eras:index===undefined?[...calendar.eras,item]:calendar.eras.map((value,i)=>i===index?item:value)};
 }
 const item={name,month:number(draft.month,1,calendar.months.length),day:number(draft.day,1,1000),...(draft.description.trim()?{description:draft.description.trim()}:{})};
 if(draft.description.length>4000||!validCalendarOccurrence(item,calendar,kind==='holidays'))throw new Error(t(kind==='holidays'?'This date does not exist in the calendar. Choose a valid month and day.':'Season starts must be valid every year. Choose a valid month and day.'));
 if(kind==='seasons'){
  const seasons=calendar.seasons??[];if(seasons.some((season,i)=>i!==index&&season.month===item.month&&season.day===item.day))throw new Error(t('Another season already begins on this date.'));
  return {seasons:index===undefined?[...seasons,item]:seasons.map((value,i)=>i===index?item:value)};
 }
 const holiday={...item,duration:number(draft.duration,1,calendar.months.reduce((sum,month)=>sum+month.days,0))},holidays=calendar.holidays??[];
 return {holidays:index===undefined?[...holidays,holiday]:holidays.map((value,i)=>i===index?holiday:value)};
}
