import {longTextPlainText} from './longText';
import type { Project } from './model';
export type WorldIdeaStatus='idea'|'deciding'|'decided'|'incorporated'|'discarded';
export type IdeaCategory='worldbuilding'|'narrative';
export const ideaCategoryLabels:Record<IdeaCategory,string>={worldbuilding:'Worldbuilding ideas',narrative:'Narrative ideas'};
export const ideaCategory=(idea:WorldIdea):IdeaCategory=>idea.category??'worldbuilding';
export type DecisionUpdate={kind:'entry'|'scene'|'plot';id:string;done:boolean};
export type WorldIdea={createdAt?:string;updatedAt?:string;fragments?:import('./decisionFragments').DecisionFragment[];decision?:string;updates?:DecisionUpdate[];category?:IdeaCategory;sceneIds?:string[];plotIds?:string[];id:string;title:string;description:string;status:WorldIdeaStatus;entryIds:string[]};
export const ideaStatusLabels:Record<WorldIdeaStatus,string>={idea:'Idea',deciding:'To decide',decided:'Decided · pending incorporation',incorporated:'Incorporated',discarded:'Discarded'};
export function saveWorldIdea(project:Project,idea:WorldIdea):Project {
 const previous=project.worldIdeas?.find(item=>item.id===idea.id),now=new Date().toISOString();
 const next={...idea,createdAt:previous?previous.createdAt:now,updatedAt:now,title:idea.title.trim(),category:ideaCategory(idea),entryIds:[...new Set(idea.entryIds)],sceneIds:[...new Set(idea.sceneIds??[])],plotIds:[...new Set(idea.plotIds??[])]};
 if(!Object.prototype.hasOwnProperty.call(ideaCategoryLabels,next.category))throw new Error('Invalid idea category.');
 if(!next.title)throw new Error('An idea needs a title.');
 if(!Object.prototype.hasOwnProperty.call(ideaStatusLabels,next.status))throw new Error('Invalid idea status.');
 if((next.fragments?.length??0)>256||next.fragments?.some(fragment=>!['entry','scene','plot'].includes(fragment.kind)||!fragment.id||!fragment.targetId||!fragment.quote.trim()||fragment.quote.length>10000||fragment.prefix.length>40||fragment.suffix.length>40||fragment.kind==='entry'&&!fragment.fieldId)||new Set(next.fragments?.map(fragment=>fragment.id)).size!==(next.fragments?.length??0))throw new Error('Invalid decision fragment.');
 if(!next.decision?.trim())delete next.decision;
 const error=ideaDecisionError(next,project.worldIdeas?.find(item=>item.id===next.id));if(error)throw new Error(error);
 if(next.updates)next.updates=ideaUpdates(next);
 const ideas=project.worldIdeas??[];
 return {...project,worldIdeas:ideas.some(item=>item.id===next.id)?ideas.map(item=>item.id===next.id?next:item):[...ideas,next]};
}

export function relatedIdeas(ideas:WorldIdea[],kind:'entry'|'scene'|'plot',id:string){
 return ideas.filter(idea=>['idea','deciding','decided'].includes(idea.status)&&(kind==='entry'?idea.entryIds:kind==='scene'?idea.sceneIds:idea.plotIds)?.includes(id));
}

export function ideaUpdates(idea:WorldIdea):DecisionUpdate[]{
 const keys=new Set<string>();return (idea.updates??[]).filter(update=>{
  const ids=update.kind==='entry'?idea.entryIds:update.kind==='scene'?idea.sceneIds:update.kind==='plot'?idea.plotIds:[];
  const key=`${update.kind}:${update.id}`;if(!ids?.includes(update.id)||keys.has(key))return false;keys.add(key);return true;
 }).map(update=>({...update}));
}
export function ideaDecisionError(idea:WorldIdea,previous?:WorldIdea):string {
 const hasDecision=!!longTextPlainText(idea.decision??'').trim();
 if((idea.status==='decided'||idea.status==='incorporated'&&(previous?.status!=='incorporated'||!!previous?.decision||!!previous?.updates?.length||!!idea.decision||!!idea.updates?.length))&&!hasDecision)return 'Write the decision before marking it as decided or incorporated.';
 if(idea.status==='incorporated'&&ideaUpdates(idea).some(update=>!update.done))return 'Review the required changes before marking this decision as incorporated.';
 return '';
}
