import type {Ref} from 'react';
import {X} from 'lucide-react';
import {t} from './i18n';

export default function MapToolPanelHeading({title,onClose,level=2,headingRef}:{headingRef?:Ref<HTMLHeadingElement>;title:string;onClose:()=>void;level?:2|3}){
 const Heading=level===2?'h2':'h3';
 return <header className="map-panel-heading map-tool-panel-heading"><Heading ref={headingRef} tabIndex={headingRef?-1:undefined}>{title}</Heading><button type="button" className="icon-button ui-close-button" title={t('Close panel')} aria-label={t('Close panel')} onClick={onClose}><X size={16} aria-hidden="true"/></button></header>;
}
