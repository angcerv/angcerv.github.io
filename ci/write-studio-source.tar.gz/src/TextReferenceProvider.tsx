import {focusDialog} from './dialogFocus';
import {entryConnections} from './entryRelations';
import EntryUsageSummary from './EntryUsageSummary';
import {useEffect,useLayoutEffect,useMemo,useRef,useState} from 'react';
import type {ReactNode} from 'react';
import {createPortal} from 'react-dom';
import {X,ArrowLeft,ArrowUpRight} from 'lucide-react';
import type {Project} from './model';
import {TextReferenceContext} from './textReferenceContext';
import type {TextReferenceSource} from './textReferenceIndex';
import {indexProjectTextReferences} from './textReferenceIndex';
import {LongTextView} from './LongTextEditor';
import {displayFieldValue,emptyWorld,isEntryReference} from './worldbuilding';
import {TextEntryLink,ReferenceText} from './TextReferenceUI';
import {t,useLanguage} from './i18n';
import {SourceConsultation,consultableSource,consultationExists} from './SourceConsultation';
import {hasLoreValue} from './worldLore';
export default function TextReferenceProvider({project,children,onOpenSource}:{project?:Project|null;children:ReactNode;onOpenSource:(source:TextReferenceSource)=>void}){
 const language=useLanguage();
 const [history,setHistory]=useState<TextReferenceSource[]>([]),index=useMemo(()=>project?indexProjectTextReferences(project):[],[project,language]);
 useEffect(()=>setHistory([]),[project?.id]);
 const environment=useMemo(()=>project?{project,world:project.worldbuilding??emptyWorld,index,openEntry:(id:string)=>setHistory(previous=>[...previous.slice(-63),{kind:'entry',id,entryId:id,label:'',field:'',excerpt:'',count:1}]),consultSource:(source:TextReferenceSource)=>{if(consultableSource(source))setHistory(previous=>[...previous.slice(-63),source]);else onOpenSource(source);},openSource:onOpenSource}:null,[project,index,onOpenSource]);
 return <TextReferenceContext.Provider value={environment}>{children}{project&&history.length>0&&<ReferencePreview key={project.id} project={project} source={history[history.length-1]} canBack={history.length>1} onBack={()=>setHistory(previous=>previous.slice(0,-1))} onClose={()=>setHistory([])} onSource={source=>{if(consultableSource(source))setHistory(previous=>[...previous.slice(-63),source]);else {setHistory([]);onOpenSource(source);}}} onNavigate={source=>{setHistory([]);onOpenSource(source);}}/>}</TextReferenceContext.Provider>;
}
function ReferencePreview({project,source,canBack,onBack,onClose,onSource,onNavigate}:{project:Project;source:TextReferenceSource;onNavigate:(source:TextReferenceSource)=>void;canBack:boolean;onBack:()=>void;onClose:()=>void;onSource:(source:TextReferenceSource)=>void}){
 const dialog=useRef<HTMLDialogElement>(null),[blocked,setBlocked]=useState(false);
 const positions=useRef(new Map<string,number>());
 const visit=source.kind+':'+source.id;
 useLayoutEffect(()=>{
  const panel=dialog.current;if(!panel)return;
  panel.scrollTop=positions.current.get(visit)??0;
  focusDialog(panel);
  return()=>{positions.current.set(visit,panel.scrollTop);if(positions.current.size>64)positions.current.delete(positions.current.keys().next().value!);};
 },[visit]);
 const consult=(next:TextReferenceSource)=>{if(!blocked||consultableSource(next))onSource(next);};

 useEffect(()=>{
  const panel=dialog.current,previous=document.activeElement as HTMLElement|null;
  const nested=!!document.querySelector('dialog[open]');
  if(nested)panel?.showModal();else panel?.show();
  focusDialog(panel);
  setBlocked(nested);
  return()=>{
   // React may already have detached the dialog; don't steal focus from writing.
   const active=document.activeElement,restore=panel?.contains(active)||active===document.body;
   panel?.close();
   if(restore&&previous?.isConnected)previous.focus({preventScroll:true});
  };
 },[]);
 const id=source.id;
 const world=project.worldbuilding??emptyWorld,entry=world.entries.find(entry=>entry.id===id),template=world.templates.find(template=>template.id===entry?.templateId);
 const connections=source.kind==='entry'&&project.entryRelations?entryConnections(project.entryRelations,id):[];
 const content=<dialog ref={dialog} className={blocked?'text-reference-preview':'text-reference-preview text-reference-consultation'} onKeyDown={event=>{if(event.key==='Escape'){event.preventDefault();event.stopPropagation();onClose();}}} aria-labelledby="text-reference-preview-title" onCancel={event=>{event.preventDefault();onClose();}}><header>{canBack&&<button type="button" className="icon-button" title={t('Back to previous consultation')} aria-label={t('Back to previous consultation')} onClick={onBack}><ArrowLeft size={17} aria-hidden="true"/></button>}<div><small>{source.kind==='entry'?template?.title:null}</small><h2 tabIndex={-1} id="text-reference-preview-title">{source.kind==='entry'?(entry?.title??t('Missing entry')):<SourceConsultation project={project} source={source} titleOnly/>}</h2></div><button title={t("Close")} type="button" className="icon-button ui-close-button" aria-label={t('Close')} onClick={onClose}><X size={18}/></button></header>{blocked&&<p className="world-hint">{t('Close the current editor before navigating to another source.')}</p>}<button type="button" className="quick-action quick-action-text" disabled={blocked||!consultationExists(project,source)} onClick={()=>onNavigate(source)}><ArrowUpRight size={14}/>{t('Go to source')}</button>{source.kind!=='entry'?<SourceConsultation key={source.kind+source.id} project={project} source={source} onConsult={consult}/>:entry?<><div className="text-reference-preview-fields">{(template?.fields??[]).filter(field=>!field.archived).map(field=>{const value=entry.values[field.id];if(!hasLoreValue(field,value))return null;return <section key={field.id}><h3>{field.label}</h3>{isEntryReference(value)?<TextEntryLink entryId={value.entryId} label={world.entries.find(e=>e.id===value.entryId)?.title??t('Missing entry')}/>:typeof value==='string'&&field.fieldType==='longText'?<LongTextView value={value}/>:typeof value==='string'&&field.fieldType==='shortText'?<p><ReferenceText value={value}/></p>:<p>{displayFieldValue(field,value,world)}</p>}</section>;})}</div>{connections.length>0&&<section className="text-reference-preview-fields"><h3>{t('Entry relationships')}</h3>{connections.map(({link,entryId,currentRole,relatedRole,type})=><p key={link.id}><span>{type.needsRoleReview?t('Roles pending review'):type.symmetric?currentRole:currentRole+' · '+relatedRole}: </span><TextEntryLink entryId={entryId} label={world.entries.find(entry=>entry.id===entryId)?.title??t('Missing entry')}/></p>)}</section>}<EntryUsageSummary isSourceDisabled={source=>blocked&&!consultableSource(source)} entryId={id} chapters={project.chapters} world={world} onOpenSource={consult} onOpenScene={sceneId=>consult({kind:'scene',id:sceneId,entryId:id,label:'',field:'',excerpt:'',count:1})} onOpenMention={(sceneId,range)=>consult({kind:'scene',id:sceneId,range,entryId:id,label:'',field:'',excerpt:'',count:1})}/></>:<p>{t('The reference is kept. Replace it or remove the link to keep its text.')}</p>}</dialog>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}
