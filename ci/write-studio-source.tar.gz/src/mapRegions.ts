import type {MapColor,ProjectMaps,WorldMap} from './maps';
import {mapLayerLocked,mapLayerVisible,updateMap,mapColors} from './maps';
import type {Worldbuilding} from './worldbuilding';
export type RegionPoint={x:number;y:number};
export type MapRegion={id:string;title:string;color:MapColor;points:RegionPoint[];holes?:RegionPoint[][];labelPosition?:RegionPoint;entryId?:string;layerId?:string};
/** Closing uses a screen-pixel target so zoom and image aspect ratio do not change its hit area. */
export function regionStartHit(points:readonly RegionPoint[],point:RegionPoint,width:number,height:number,radius=22){
 const start=points[0];return !!start&&width>0&&height>0&&Math.hypot((point.x-start.x)*width,(point.y-start.y)*height)<=radius;
}
export function validRegionPoints(points:RegionPoint[]){
 if(points.length<3||points.length>128||points.some(p=>!Number.isFinite(p.x)||!Number.isFinite(p.y)||p.x<0||p.x>1||p.y<0||p.y>1)||new Set(points.map(p=>p.x+':'+p.y)).size!==points.length)return false;
 const cross=(a:RegionPoint,b:RegionPoint,c:RegionPoint)=>(b.x-a.x)*(c.y-a.y)-(b.y-a.y)*(c.x-a.x);
 const on=(a:RegionPoint,b:RegionPoint,c:RegionPoint)=>Math.abs(cross(a,b,c))<1e-12&&c.x>=Math.min(a.x,b.x)&&c.x<=Math.max(a.x,b.x)&&c.y>=Math.min(a.y,b.y)&&c.y<=Math.max(a.y,b.y);
 for(let i=0;i<points.length;i++)for(let j=i+1;j<points.length;j++){
  if(j===i+1||i===0&&j===points.length-1)continue;
  const a=points[i],b=points[(i+1)%points.length],c=points[j],d=points[(j+1)%points.length];
  if(cross(a,b,c)*cross(a,b,d)<0&&cross(c,d,a)*cross(c,d,b)<0||on(a,b,c)||on(a,b,d)||on(c,d,a)||on(c,d,b))return false;
 }
 return Math.abs(points.reduce((sum,p,i)=>sum+p.x*points[(i+1)%points.length].y-p.y*points[(i+1)%points.length].x,0))>1e-10;
}
// Boundaries must be disjoint; a hole may neither touch the outside nor another hole.
export function pointInRing(point:RegionPoint,ring:RegionPoint[]){
 let inside=false;
 for(let i=0,j=ring.length-1;i<ring.length;j=i++){
  const a=ring[j],b=ring[i],cross=(b.x-a.x)*(point.y-a.y)-(b.y-a.y)*(point.x-a.x);
  if(Math.abs(cross)<1e-12&&point.x>=Math.min(a.x,b.x)&&point.x<=Math.max(a.x,b.x)&&point.y>=Math.min(a.y,b.y)&&point.y<=Math.max(a.y,b.y))return false;
  if((a.y>point.y)!==(b.y>point.y)&&point.x<(b.x-a.x)*(point.y-a.y)/(b.y-a.y)+a.x)inside=!inside;
 }
 return inside;
}
function ringsIntersect(a:RegionPoint[],b:RegionPoint[]){
 const cross=(p:RegionPoint,q:RegionPoint,r:RegionPoint)=>(q.x-p.x)*(r.y-p.y)-(q.y-p.y)*(r.x-p.x);
 const on=(p:RegionPoint,q:RegionPoint,r:RegionPoint)=>Math.abs(cross(p,q,r))<1e-12&&r.x>=Math.min(p.x,q.x)&&r.x<=Math.max(p.x,q.x)&&r.y>=Math.min(p.y,q.y)&&r.y<=Math.max(p.y,q.y);
 return a.some((p,i)=>b.some((r,j)=>{const q=a[(i+1)%a.length],s=b[(j+1)%b.length];return cross(p,q,r)*cross(p,q,s)<0&&cross(r,s,p)*cross(r,s,q)<0||on(p,q,r)||on(p,q,s)||on(r,s,p)||on(r,s,q);}));
}
export function validRegionGeometry(region:Pick<MapRegion,'points'|'holes'>){
 const holes=region.holes??[];
 return validRegionPoints(region.points)&&holes.length<=16&&holes.every((hole,i)=>validRegionPoints(hole)&&pointInRing(hole[0],region.points)&&!ringsIntersect(hole,region.points)&&holes.slice(0,i).every(other=>!ringsIntersect(hole,other)&&!pointInRing(hole[0],other)&&!pointInRing(other[0],hole)));
}
export function regionContour(region:MapRegion,index=-1){return index<0?region.points:region.holes?.[index]??region.points;}
export function withRegionContour(region:MapRegion,points:RegionPoint[],index=-1):MapRegion{return index<0?{...region,points}:{...region,holes:region.holes?.map((hole,i)=>i===index?points:hole)};}
export function regionPath(region:Pick<MapRegion,'points'|'holes'>){return [region.points,...region.holes??[]].map(ring=>'M'+ring.map(p=>`${p.x*1000},${p.y*1000}`).join('L')+'Z').join('');}
export function saveMapRegion(maps:ProjectMaps,mapId:string,region:MapRegion):ProjectMaps{
 const map=maps.maps.find(item=>item.id===mapId),previous=map?.regions?.find(item=>item.id===region.id);
 if(region.labelPosition&&(!Number.isFinite(region.labelPosition.x)||!Number.isFinite(region.labelPosition.y)||region.labelPosition.x<0||region.labelPosition.x>1||region.labelPosition.y<0||region.labelPosition.y>1))return maps;
 if(!map||region.title.length>300||!Object.prototype.hasOwnProperty.call(mapColors,region.color)||!validRegionGeometry(region)||mapLayerLocked(map,previous?.layerId)||mapLayerLocked(map,region.layerId)||region.layerId&&!map.layers?.some(layer=>layer.id===region.layerId))return maps;
 if(!previous&&(map.regions?.length??0)>=200)return maps;
 return updateMap({...maps,schemaVersion:Math.max(maps.schemaVersion,region.holes?.length?19:17) as ProjectMaps['schemaVersion']},{...map,regions:previous?map.regions!.map(item=>item.id===region.id?region:item):[...(map.regions??[]),region]});
}
export function removeMapRegion(maps:ProjectMaps,mapId:string,id:string){
 const map=maps.maps.find(item=>item.id===mapId),region=map?.regions?.find(item=>item.id===id);
 return !map||!region||mapLayerLocked(map,region.layerId)?maps:updateMap(maps,{...map,regions:map.regions?.filter(item=>item.id!==id)});
}
export function visibleMapRegions(map:WorldMap,world?:Worldbuilding,templateId=''){
 return (map.regions??[]).filter(region=>{
  if(!mapLayerVisible(map,region.layerId))return false;
  const entry=world?.entries.find(item=>item.id===region.entryId);
  return !templateId||(templateId==='__unlinked'?!entry:entry?.templateId===templateId);
 }).slice().sort((a,b)=>(map.layers?.findIndex(layer=>layer.id===a.layerId)??-1)-(map.layers?.findIndex(layer=>layer.id===b.layerId)??-1));
}
export const regionPoints=(points:RegionPoint[])=>points.map(p=>p.x*1000+','+p.y*1000).join(' ');
