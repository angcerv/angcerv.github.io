import type {GraphPoint} from './relationGraph';
export const genealogyCard={halfWidth:100,halfHeight:32,gap:12};
export type RoutingBox={left:number;right:number;top:number;bottom:number};
export type GenealogyRoute={points:GraphPoint[];path:string;label?:GraphPoint;labelWidth?:number;compactLabel?:boolean;blocked:boolean};
type Segment={a:GraphPoint;b:GraphPoint;group?:string};
type Endpoint={point:GraphPoint;stub:GraphPoint;owner?:string};
const between=(value:number,a:number,b:number)=>value>Math.min(a,b)+.01&&value<Math.max(a,b)-.01;
export function segmentHitsBox(a:GraphPoint,b:GraphPoint,r:RoutingBox){
 if(a.x===b.x)return between(a.x,r.left,r.right)&&Math.max(a.y,b.y)>r.top+.01&&Math.min(a.y,b.y)<r.bottom-.01;
 if(a.y===b.y)return between(a.y,r.top,r.bottom)&&Math.max(a.x,b.x)>r.left+.01&&Math.min(a.x,b.x)<r.right-.01;
 return true;
}
function overlap(a:RoutingBox,b:RoutingBox){return a.left<b.right&&a.right>b.left&&a.top<b.bottom&&a.bottom>b.top;}
function segments(points:GraphPoint[]){return points.slice(1).map((b,i)=>({a:points[i],b}));}
function clean(points:GraphPoint[]){const result:GraphPoint[]=[];for(const point of points){if(result[result.length-1]?.x===point.x&&result[result.length-1]?.y===point.y)continue;while(result.length>1){const a=result[result.length-2]!,b=result[result.length-1]!;if((a.x===b.x&&b.x===point.x)||(a.y===b.y&&b.y===point.y))result.pop();else break;}result.push(point);}return result;}
/** Small corner radius stays within the obstacle clearance reserved by the router. */
export function routedPath(points:GraphPoint[]){if(!points.length)return '';let path=`M ${points[0].x} ${points[0].y}`;for(let i=1;i<points.length-1;i++){const a=points[i-1],b=points[i],c=points[i+1],before=Math.hypot(b.x-a.x,b.y-a.y),after=Math.hypot(c.x-b.x,c.y-b.y),r=Math.min(6,before/2,after/2);if(!r)continue;const p={x:b.x+(a.x-b.x)*r/before,y:b.y+(a.y-b.y)*r/before},q={x:b.x+(c.x-b.x)*r/after,y:b.y+(c.y-b.y)*r/after};path+=` L ${p.x} ${p.y} Q ${b.x} ${b.y} ${q.x} ${q.y}`;}const end=points[points.length-1]!;return path+` L ${end.x} ${end.y}`;}
export function labelWidth(text:string,icon=false){return Math.max(52,Array.from(text).reduce((width,char)=>width+(/[MW@#%]/.test(char)?12:/[^\u0000-\u024f]/.test(char)?16:8),0)+24+(icon?24:0));}

export function createGenealogyRouter(positions:Record<string,GraphPoint>){
 const cards=Object.entries(positions).map(([id,p])=>({id,left:p.x-100,right:p.x+100,top:p.y-32,bottom:p.y+32}));
 const obstacles=cards.map(r=>({...r,left:r.left-12,right:r.right+12,top:r.top-12,bottom:r.bottom+12}));
 const occupied:Segment[]=[],labels:RoutingBox[]=[];
 const clear=(a:GraphPoint,b:GraphPoint)=>!obstacles.some(r=>segmentHitsBox(a,b,r))&&!labels.some(r=>segmentHitsBox(a,b,r));
 function cost(points:GraphPoint[],group?:string){let score=(points.length-2)*16;for(const {a,b} of segments(points)){score+=Math.abs(a.x-b.x)+Math.abs(a.y-b.y);for(const prior of occupied){if(group&&prior.group===group)continue;
  if(a.x===b.x&&prior.a.x===prior.b.x&&Math.abs(a.x-prior.a.x)<4||a.y===b.y&&prior.a.y===prior.b.y&&Math.abs(a.y-prior.a.y)<4){const vertical=a.x===b.x,from=Math.max(Math.min(vertical?a.y:a.x,vertical?b.y:b.x),Math.min(vertical?prior.a.y:prior.a.x,vertical?prior.b.y:prior.b.x)),to=Math.min(Math.max(vertical?a.y:a.x,vertical?b.y:b.x),Math.max(vertical?prior.a.y:prior.a.x,vertical?prior.b.y:prior.b.x));if(to>from)score+=500+(to-from)*4;}
  else if(a.x===b.x&&prior.a.y===prior.b.y&&between(a.x,prior.a.x,prior.b.x)&&between(prior.a.y,a.y,b.y)||a.y===b.y&&prior.a.x===prior.b.x&&between(a.y,prior.a.y,prior.b.y)&&between(prior.a.x,a.x,b.x))score+=70;
 }}return score;}
 function core(start:GraphPoint,end:GraphPoint,group?:string,preferredY?:number){
  const available=(a:GraphPoint,b:GraphPoint)=>clear(a,b)&&!occupied.some(s=>{if(group&&group===s.group)return false;if(a.x===b.x&&s.a.x===s.b.x&&Math.abs(a.x-s.a.x)<3)return Math.min(Math.max(a.y,b.y),Math.max(s.a.y,s.b.y))-Math.max(Math.min(a.y,b.y),Math.min(s.a.y,s.b.y))>2;if(a.y===b.y&&s.a.y===s.b.y&&Math.abs(a.y-s.a.y)<3)return Math.min(Math.max(a.x,b.x),Math.max(s.a.x,s.b.x))-Math.max(Math.min(a.x,b.x),Math.min(s.a.x,s.b.x))>2;return false;});
  const xs=[start.x,end.x,...obstacles.flatMap(r=>[r.left-8,r.right+8]),...labels.flatMap(r=>[r.left-8,r.right+8])],ys=[start.y,end.y,...obstacles.flatMap(r=>[r.top-8,r.bottom+8]),...labels.flatMap(r=>[r.top-8,r.bottom+8]),...(preferredY===undefined?[]:[preferredY])];
  const nearest=(values:number[],center:number)=>[...new Set(values)].sort((a,b)=>Math.abs(a-center)-Math.abs(b-center)||a-b).slice(0,28);
  const bounds={left:Math.min(...xs)-36,right:Math.max(...xs)+36,top:Math.min(...ys)-36,bottom:Math.max(...ys)+36};
  const xTracks=[...nearest(xs,(start.x+end.x)/2),bounds.left,bounds.right],yTracks=[...(preferredY===undefined?[]:[preferredY]),...nearest(ys,(start.y+end.y)/2),bounds.top,bounds.bottom];
  const candidates:GraphPoint[][]=[[start,{x:end.x,y:start.y},end],[start,{x:start.x,y:end.y},end]];
  for(const y of yTracks)candidates.push([start,{x:start.x,y}, {x:end.x,y},end]);
  for(const x of xTracks)candidates.push([start,{x,y:start.y},{x,y:end.y},end]);
  let best:GraphPoint[]|undefined,score=Infinity;
  for(const raw of candidates){const points=clean(raw);if(!segments(points).every(({a,b})=>available(a,b)))continue;const value=cost(points,group);if(value<score){score=value;best=points;}}
  if(best)return best;
  // Bounded rectilinear visibility search for multi-obstacle corridors.
  const X=[...new Set([start.x,end.x,...xTracks])].sort((a,b)=>a-b),Y=[...new Set([start.y,end.y,...yTracks])].sort((a,b)=>a-b),encode=(x:number,y:number)=>y*X.length+x;
  const origin=encode(X.indexOf(start.x),Y.indexOf(start.y)),goal=encode(X.indexOf(end.x),Y.indexOf(end.y)),distance=new Map([[origin,0]]),previous=new Map<number,number>(),open=new Set([origin]),done=new Set<number>();let steps=0;
  while(open.size&&steps++<1600){let current=-1,rank=Infinity;for(const id of open){const p={x:X[id%X.length],y:Y[Math.floor(id/X.length)]},value=distance.get(id)!+Math.abs(p.x-end.x)+Math.abs(p.y-end.y);if(value<rank){rank=value;current=id;}}if(current===goal){const result:GraphPoint[]=[];for(let id:number|undefined=current;id!==undefined;id=previous.get(id))result.push({x:X[id%X.length],y:Y[Math.floor(id/X.length)]});return clean(result.reverse());}
   open.delete(current);done.add(current);const x=current%X.length,y=Math.floor(current/X.length),a={x:X[x],y:Y[y]};for(const [dx,dy] of [[-1,0],[1,0],[0,-1],[0,1]]){const nx=x+dx,ny=y+dy;if(nx<0||ny<0||nx>=X.length||ny>=Y.length)continue;const next=encode(nx,ny),b={x:X[nx],y:Y[ny]};if(done.has(next)||!available(a,b))continue;const value=distance.get(current)!+cost([a,b],group)+8;if(value<(distance.get(next)??Infinity)){distance.set(next,value);previous.set(next,current);open.add(next);}}
  }return undefined;
 }
 function label(points:GraphPoint[],text:string,icon=false){const width=labelWidth(text,icon),height=30;const choices=segments(points).sort((a,b)=>Math.hypot(b.a.x-b.b.x,b.a.y-b.b.y)-Math.hypot(a.a.x-a.b.x,a.a.y-a.b.y));
  for(const segment of choices){for(const ratio of [.5,.35,.65,.2,.8]){const p={x:segment.a.x+(segment.b.x-segment.a.x)*ratio,y:segment.a.y+(segment.b.y-segment.a.y)*ratio},box={left:p.x-width/2-6,right:p.x+width/2+6,top:p.y-height/2-6,bottom:p.y+height/2+6};if(cards.some(card=>overlap(box,card))||labels.some(prior=>overlap(box,prior))||occupied.some(prior=>segmentHitsBox(prior.a,prior.b,box)))continue;labels.push(box);return p;}}
  return undefined;
 }
 function route(start:Endpoint,end:Endpoint,group?:string,preferredY?:number,text?:string,icon=false):GenealogyRoute{
  // Endpoint stubs may touch their own card, never another card.
  if(cards.some(r=>r.id!==start.owner&&segmentHitsBox(start.point,start.stub,r))||cards.some(r=>r.id!==end.owner&&segmentHitsBox(end.point,end.stub,r)))return {points:[],path:'',blocked:true};
  const inside=core(start.stub,end.stub,group,preferredY);if(!inside)return {points:[],path:'',blocked:true};const points=clean([start.point,...inside,end.point]);
  let at=text?label(points,text,icon):undefined;let compactLabel=false;if(text&&icon&&!at){at=label(points,'',true);compactLabel=!!at;}for(const segment of segments(points))occupied.push({...segment,group});return {points,path:routedPath(points),label:at,labelWidth:at?labelWidth(compactLabel?'':text??'',icon):undefined,compactLabel,blocked:false};
 }
 function port(id:string,side:'left'|'right'|'top'|'bottom',offset=0):Endpoint{const p=positions[id],dx=side==='left'?-1:side==='right'?1:0,dy=side==='top'?-1:side==='bottom'?1:0;return {point:{x:p.x+dx*100+(dy?offset:0),y:p.y+dy*32+(dx?offset:0)},stub:{x:p.x+dx*132+(dy?offset:0),y:p.y+dy*64+(dx?offset:0)},owner:id};}
 function betweenNodes(source:string,target:string,text:string,kind:'partner'|'sibling'|'care',icon=false){const a=positions[source],b=positions[target];if(!a||!b||Math.abs(a.x-b.x)<1&&Math.abs(a.y-b.y)<1)return {points:[],path:'',blocked:true} as GenealogyRoute;
  const preferred:(typeof sides[number])[]=kind==='partner'||kind==='sibling'?['top','bottom',a.x<=b.x?'right':'left',a.x<=b.x?'left':'right']:[a.y<=b.y?'bottom':'top','right','left','top'];
  let fallback:GenealogyRoute|undefined;
  for(const side of [...new Set(preferred)]){const opposite=kind==='care'?(side==='bottom'?'top':side==='top'?'bottom':side==='left'?'right':'left'):side;
   const hash=Array.from(source+'|'+target+'|'+text).reduce((value,char)=>(value*31+char.charCodeAt(0))>>>0,0),offset=((hash%5)-2)*7,start=port(source,side,offset),end=port(target,opposite,offset),y=side==='top'?Math.min(a.y,b.y)-80:side==='bottom'?Math.max(a.y,b.y)+80:undefined,result=route(start,end,undefined,y,text,icon);if(result.blocked)continue;if(result.label)return result;fallback??=result;break;}
  return fallback??{points:[],path:'',blocked:true};
 }
 const sides=['left','right','top','bottom'] as const;
 function toPoint(id:string,point:GraphPoint,side:'top'|'bottom',group:string,reverse=false,text?:string){const p={point,stub:point},node=port(id,side);return reverse?route(p,node,group,undefined,text):route(node,p,group,undefined,text);}
 function rail(left:number,right:number,preferred:number,min:number,max:number,group:string){
  const options=[preferred,min,max,...obstacles.flatMap(r=>[r.top-8,r.bottom+8]),...labels.flatMap(r=>[r.top-8,r.bottom+8]),...occupied.filter(s=>s.a.y===s.b.y).flatMap(s=>[s.a.y-14,s.a.y+14])].filter(y=>y>=min&&y<=max);
  let best:{y:number;path:string}|undefined,score=Infinity;
  for(const y of options){const a={x:left,y},b={x:right,y};if(!clear(a,b)||occupied.some(s=>s.group!==group&&s.a.y===s.b.y&&Math.abs(s.a.y-y)<6&&Math.max(s.a.x,s.b.x)>left&&Math.min(s.a.x,s.b.x)<right))continue;const value=Math.abs(y-preferred)*2+cost([a,b],group);if(value<score){score=value;best={y,path:`M ${left} ${y} H ${right}`};}}
  if(best)occupied.push({a:{x:left,y:best.y},b:{x:right,y:best.y},group});return best;
 }

 return {betweenNodes,toPoint,rail,label,cards,checkpoint:()=>({segments:occupied.length,labels:labels.length}),rollback:(mark:{segments:number;labels:number})=>{occupied.splice(mark.segments);labels.splice(mark.labels);}};
}
