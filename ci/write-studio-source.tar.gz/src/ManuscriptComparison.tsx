import {statusTone} from './semanticStatus';
import SceneRecoveryActions from './SceneRecoveryActions';
import type { SceneRecoveryRequest } from './sceneRecovery';
import { useEffect, useMemo, useState } from 'react';
import Dropdown from './Dropdown';
import { t, message } from './i18n';
import { readVersion } from './storage';
import type { ProjectVersion } from './storage';
import { getSceneStatus, writingStatusLabels } from './model';
import type { Project } from './model';
import { compareManuscripts, diffText, manuscriptText } from './manuscriptDiff';
import type { SceneChange, SceneLocation } from './manuscriptDiff';
export function TextDiff({before,after}:{before:string;after:string}){
 const changes=useMemo(()=>diffText(before,after),[before,after]);
 return <div className="manuscript-text-diff">{changes.map((part,index)=>part.kind==='added'?<ins key={index} aria-label={t('Added text')}>{part.text}</ins>:part.kind==='removed'?<del key={index} aria-label={t('Removed text')}>{part.text}</del>:<span key={index}>{part.text}</span>)}</div>;
}
function location(item:SceneLocation){return t('Chapter {0} · Scene {1}',item.chapter.title||t('Untitled chapter'),item.index+1);}
type Recovery={current:Project;source:Project;disabled:boolean;onRecover:(request:SceneRecoveryRequest)=>Promise<void>};
function SceneDifference({change,recovery}:{change:SceneChange;recovery?:Recovery}){
 const [open,setOpen]=useState(false),a=change.before?.scene,b=change.after?.scene;
 const before=a?.content??'',after=b?.content??'';
 return <details className="manuscript-scene-diff" onToggle={event=>setOpen(event.currentTarget.open)}><summary><strong>{(b??a)?.title||t('Untitled scene')}</strong><span className="comparison-badges">{change.added&&<span>{t('Scene added')}</span>}{change.removed&&<span>{t('Scene removed')}</span>}{change.moved&&<span>{t('Scene moved')}</span>}{change.edited&&<span>{t('Scene edited')}</span>}</span></summary>
  {change.before&&<p className="comparison-location">{t('Before: {0}',location(change.before))}</p>}{change.after&&<p className="comparison-location">{t('After: {0}',location(change.after))}</p>}
  {open&&<><div className="scene-diff-metadata">{a&&b&&a.title!==b.title&&<p>{t('Scene title')}: <del>{a.title}</del> → <ins>{b.title}</ins></p>}{(a?.synopsis??'')!==(b?.synopsis??'')&&<><h4>{t('Synopsis')}</h4><TextDiff before={a?.synopsis??''} after={b?.synopsis??''}/></>}{a&&b&&getSceneStatus(a)!==getSceneStatus(b)&&<p>{t('Writing status')}: <span className="semantic-status" data-semantic-tone={statusTone('writing',getSceneStatus(a))}>{t(writingStatusLabels[getSceneStatus(a)])}</span> → <span className="semantic-status" data-semantic-tone={statusTone('writing',getSceneStatus(b))}>{t(writingStatusLabels[getSceneStatus(b)])}</span></p>}</div>
   {before!==after||change.added||change.removed?<><h4>{t('Text changes')}</h4><TextDiff before={manuscriptText(before)} after={manuscriptText(after)}/>{before!==after&&manuscriptText(before)===manuscriptText(after)&&<p>{t('Only text formatting changed.')}</p>}{before!==after&&<details className="comparison-markdown"><summary>{t('Inspect formatting changes (Markdown)')}</summary><TextDiff before={before} after={after}/></details>}</>:<p className="world-hint">{t('Scene text is unchanged.')}</p>}
   {recovery&&a&&<SceneRecoveryActions source={recovery.source} scene={a} current={recovery.current} disabled={recovery.disabled} onRecover={recovery.onRecover}/>}
  </>}
 </details>;
}
export function ManuscriptChanges({before,after,recovery}:{before:Project;after:Project;recovery?:Recovery}){
 const changes=useMemo(()=>compareManuscripts(before,after),[before,after]);
 return <div className="manuscript-changes"><div className="comparison-counts" role="status">{t('{0} added · {1} removed · {2} moved · {3} edited scenes',changes.scenes.filter(s=>s.added).length,changes.scenes.filter(s=>s.removed).length,changes.scenes.filter(s=>s.moved).length,changes.scenes.filter(s=>s.edited).length)}</div>
  <p className="comparison-legend"><ins>{t('Added text')}</ins><del>{t('Removed text')}</del></p>
  {changes.titleChanged&&<p>{t('Project title')}: <del>{before.title}</del> → <ins>{after.title}</ins></p>}
  {!!changes.chapters.length&&<div className="comparison-chapters"><h4>{t('Chapter changes')}</h4>{changes.chapters.map(c=><details key={c.id}><summary>{(c.after??c.before)?.title||t('Untitled chapter')} · {!c.before?t('Chapter added'):!c.after?t('Chapter removed'):c.moved?t('Chapter moved'):t('Chapter edited')}</summary>{c.before&&c.after&&c.before.title!==c.after.title&&<p><del>{c.before.title}</del> → <ins>{c.after.title}</ins></p>}{(c.before?.synopsis??'')!==(c.after?.synopsis??'')&&<><h4>{t('Synopsis')}</h4><TextDiff before={c.before?.synopsis??''} after={c.after?.synopsis??''}/></>}{c.moved&&<p>{t('Chapter position: {0} → {1}',before.chapters.findIndex(ch=>ch.id===c.id)+1,after.chapters.findIndex(ch=>ch.id===c.id)+1)}</p>}</details>)}</div>}
  {changes.scenes.map(change=><SceneDifference key={change.id} change={change} recovery={recovery}/>)}
  {!changes.scenes.length&&!changes.chapters.length&&!changes.titleChanged&&<p>{t('No manuscript changes between these versions.')}</p>}
 </div>;
}
export default function ManuscriptComparison({before,current,versions,path,disabled,onRecover}:{before:Project;current:Project;versions:ProjectVersion[];path:string;disabled:boolean;onRecover?:(request:SceneRecoveryRequest)=>Promise<void>}){
 const [target,setTarget]=useState('current'),[saved,setSaved]=useState<Project|null>(null),[error,setError]=useState(''),[loading,setLoading]=useState(false);
 useEffect(()=>{let disposed=false;setSaved(null);setError('');setLoading(target!=='current');if(target!=='current')void readVersion(path,Number(target)).then(value=>{if(!disposed)setSaved(value);}).catch(e=>{if(!disposed)setError(String(e));}).finally(()=>{if(!disposed)setLoading(false);});return()=>{disposed=true;};},[target,path]);
 const after=target==='current'?current:saved?.revision===Number(target)?saved:null;
 return <div className="manuscript-comparison"><label htmlFor="comparison-target">{t('Compare with')}</label><Dropdown id="comparison-target" aria-label={t('Compare with')} disabled={disabled} value={target} onChange={setTarget} options={[{value:'current',label:t('Current manuscript (including unsaved changes)')},...versions.filter(v=>v.revision!==before.revision).map(v=>({value:String(v.revision),label:v.checkpointName?`${v.checkpointName} · ${t('Version')} ${v.revision}`:`${t('Version')} ${v.revision}`}))]}/><p className="world-hint">{t('Changes are shown from the selected checkpoint to the comparison target. Comparing does not modify your project.')}</p>{error&&<p role="alert">{message(error)} <button type="button" onClick={()=>setTarget('current')}>{t('Compare with current manuscript')}</button></p>}{loading?<p role="status">{t('Loading…')}</p>:after&&<ManuscriptChanges before={before} after={after} recovery={onRecover?{source:before,current,disabled,onRecover}:undefined}/>}</div>;
}
