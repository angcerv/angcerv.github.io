import {Heart,Link2,Pause,Scissors,HeartHandshake,Unlink} from 'lucide-react';
import type {PartnershipStatus} from './partnership';
import {partnershipLabels} from './partnership';
import {t} from './i18n';
export function PartnershipIcon({status,former=false,size=16}:{status?:PartnershipStatus;former?:boolean;size?:number}){
 const Icon=status==='dating'?Heart:status==='married'?Link2:status==='separated'?Pause:status==='divorced'?Scissors:former?Unlink:HeartHandshake;
 return <Icon size={size} strokeWidth={1.7} aria-hidden="true"/>;
}
export default function PartnershipSymbol({status,former=false,x,y}:{status?:PartnershipStatus;former?:boolean;x:number;y:number}){
 const Icon=status==='dating'?Heart:status==='married'?Link2:status==='separated'?Pause:status==='divorced'?Scissors:former?Unlink:HeartHandshake;
 const label=status?t(partnershipLabels[status]):t(former?'Former partners':'Partners');
 return <g transform={`translate(${x} ${y})`} className="genealogy-partnership-symbol" aria-hidden="true"><title>{label}</title><rect x={-14} y={-14} width={28} height={28} rx={5}/><g transform="translate(-10 -10)"><Icon size={20} strokeWidth={1.7}/></g></g>;
}
