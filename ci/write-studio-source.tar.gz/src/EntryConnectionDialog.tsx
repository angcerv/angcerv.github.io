import {supportsPartnership,partnershipLabels} from './partnership';
import type {PartnershipStatus} from './partnership';
import {useState} from 'react';
import {ArrowRight,ArrowLeftRight,ChevronDown} from 'lucide-react';
import FieldHelp from './FieldHelp';
import {changeConnectionSelection,connectionDraftChanged} from './connectionDraft';
import Dropdown from './Dropdown';
import RelationDialog from './RelationDialog';
import {formatStoryDate,parseStoryDate} from './timeline';
import {t,buttonLabel} from './i18n';
import {availableRoles,connectionCandidates,connectionFromEntry,connectionProblem,normalizeEntryRelations,relationTypeName,templateAllowsRole,saveEntryConnection,connectionDateProblem} from './entryRelations';
import type {EntryRelations,EntryRelation,ConnectionSelection,RelationRole} from './entryRelations';
import type {Worldbuilding,Entry} from './worldbuilding';
export const connectionProblemText={dates:'Review the connection dates.',ancestry:'This connection would create an ancestry cycle.',missing:'Choose an available entry.',self:'An entry cannot be connected to itself.',review:'Confirm the legacy roles in Relationships first.',incompatible:'These templates are not compatible with the selected roles.',duplicate:'This connection already exists.'};
export default function EntryConnectionDialog({world,entry,relations:input,connection,onSave,onCancel,parentFor=false}:{world:Worldbuilding;entry:Entry;relations:EntryRelations;connection?:EntryRelation;parentFor?:boolean;onSave:(relations:EntryRelations)=>void;onCancel:()=>void}){
 const relations=normalizeEntryRelations(input),otherId=connection?(connection.sourceId===entry.id?connection.targetId:connection.sourceId):'';
 const parentTypes=parentFor?relations.types.filter(type=>type.genealogy?.kind==='parent'&&!type.needsRoleReview&&availableRoles(type,entry).includes(type.genealogy.parentRole==='source'?'target':'source')):[];
 const preferred=parentTypes.length===1?parentTypes[0]:undefined;
 const initialSelection:ConnectionSelection={typeId:connection?.typeId??preferred?.id??'',role:connection?(connection.sourceId===entry.id?'source':'target'):preferred?.genealogy?.kind==='parent'?(preferred.genealogy.parentRole==='source'?'target':'source'):'',templateId:world.entries.find(other=>other.id===otherId)?.templateId??'',entryId:otherId};
 const [selection,setSelection]=useState<ConnectionSelection>(initialSelection);
 const [partnershipStatus,setPartnershipStatus]=useState<PartnershipStatus|''>(connection?.partnershipStatus??'');
 const [selectionNotice,setSelectionNotice]=useState('');
 const [start,setStart]=useState(formatStoryDate(connection?.start)),[end,setEnd]=useState(formatStoryDate(connection?.end));
 const [validityExpanded,setValidityExpanded]=useState(!!(connection?.start||connection?.end));
 let dates:Pick<EntryRelation,'start'|'end'>={},startError='',endError='';
 try{const date=parseStoryDate(start);if(date)dates.start=date;}catch(error){startError=error instanceof Error?error.message:String(error);}
 try{const date=parseStoryDate(end);if(date)dates.end=date;}catch(error){endError=error instanceof Error?error.message:String(error);}
 if(!startError&&!endError)endError=connectionDateProblem(dates)??'';
 const dateError=startError||endError;
 const type=relations.types.find(type=>type.id===selection.typeId),roles=type?availableRoles(type,entry):[];
 const role=type?.symmetric?'source':selection.role||(roles.length===1?roles[0]:'');
 const templates=type&&role?world.templates.filter(template=>templateAllowsRole(type,template.id,role==='source'?'target':'source')):[];
 const chooseRole=!parentFor&&(roles.length>1||!!selection.role&&!roles.includes(selection.role));
 const candidates=type&&role?templates.flatMap(template=>connectionCandidates(relations,world,entry,type,role,template.id,connection?.id)):[];
 const problem=type&&role&&selection.entryId?connectionProblem(relations,world,connectionFromEntry(type.id,entry.id,selection.entryId,role,connection?.id)):undefined;
 const valid=!!type&&!!role&&roles.includes(role)&&candidates.some(other=>other.id===selection.entryId)&&!problem&&!dateError;
 function choose(id:string,nextRole?:RelationRole){
  const nextType=relations.types.find(type=>type.id===id);if(parentFor&&nextType?.genealogy?.kind==='parent')nextRole=nextType.genealogy.parentRole==='source'?'target':'source';
  const next=changeConnectionSelection(relations,world,entry,selection,id,nextRole,connection?.id);
  setSelectionNotice(selection.entryId&&!next.entryId?'The previous entry is unavailable for these roles. Choose another entry.':'');setSelection(next);
 }
 const baseline=initialSelection;
 const related=world.entries.find(item=>item.id===selection.entryId);
 return <RelationDialog className="connection-dialog" variant="form" dirty={connectionDraftChanged(selection,baseline,start,end,formatStoryDate(connection?.start),formatStoryDate(connection?.end))||partnershipStatus!==(connection?.partnershipStatus??'')} title={t(parentFor?'Assign parent':connection?'Edit connection':'New connection')} onClose={onCancel}>
 <form className="entry-connection-form" onSubmit={event=>{event.preventDefault();if(valid&&type&&role){const next=saveEntryConnection(relations,world,entry.id,role,type.id,selection.entryId,connection?.id,{...dates,partnershipStatus:supportsPartnership(type)&&partnershipStatus?partnershipStatus:undefined});if(next!==relations)onSave(next);}}}>
  <div className="connection-origin"><strong>{entry.title||t('Untitled entry')}</strong><span>{world.templates.find(template=>template.id===entry.templateId)?.title}</span></div>
  <div className="ui-form-field"><label htmlFor="connection-type">{t('Relationship type')}</label>
   <Dropdown density="relationship" id="connection-type" aria-label={t('Relationship type')} value={selection.typeId} onChange={id=>{if(id!==selection.typeId)choose(id);}} options={(parentFor?parentTypes:relations.types).filter(type=>!type.needsRoleReview&&availableRoles(type,entry).length||type.id===connection?.typeId).map(type=>({value:type.id,label:relationTypeName(type),disabled:!!type.needsRoleReview}))}/>
   {!type&&<small className="field-hint">{t('Choose a relationship type to continue.')}</small>}
  </div>
  {type&&!type.symmetric&&<div className="connection-role-pair">
   <div className="ui-form-field"><label htmlFor={chooseRole?'connection-role':undefined}>{t('Role of {0}',entry.title)}</label>
    {chooseRole?<Dropdown density="relationship" id="connection-role" aria-invalid={!!selection.role&&!roles.includes(selection.role)} aria-label={t('Role of {0}',entry.title)} value={role} onChange={value=>{if(value!==selection.role)choose(selection.typeId,value as RelationRole);}} options={roles.map(role=>({value:role,label:role==='source'?type.title:type.inverseTitle}))}/>:<span>{role==='source'?type.title:type.inverseTitle}</span>}
    {!role&&<small className="field-hint">{t('Choose the role of this entry to continue.')}</small>}
   </div><ArrowRight size={16} aria-hidden="true"/><div className="ui-form-field"><span className="connection-role-label">{t('Related entry role')}</span><span>{role?(role==='source'?type.inverseTitle:type.title):'—'}</span></div>
  </div>}
  <div className="ui-form-field"><label htmlFor="connection-entry">{t('Related entry')}{templates.length===1?` · ${templates[0].title}`:''}</label>
   <Dropdown density="relationship" id="connection-entry" aria-invalid={!!problem} aria-describedby={problem?'connection-entry-error':selectionNotice?'connection-entry-notice':undefined} aria-label={t('Related entry')} searchable value={selection.entryId} disabled={!templates.length||!role||!!type?.needsRoleReview} onChange={value=>{setSelection({...selection,entryId:value});setSelectionNotice('');}} options={candidates.map(other=>({value:other.id,label:(other.title||t('Untitled entry'))+(templates.length>1?` · ${world.templates.find(template=>template.id===other.templateId)?.title??t('Missing template')}`:''),searchText:other.title}))}/>
   {selectionNotice&&<small id="connection-entry-notice" className="field-hint" role="status">{t(selectionNotice)}</small>}
   {problem&&<p id="connection-entry-error" className="prompt-error" role="alert">{t(connectionProblemText[problem])}</p>}
   {type&&role&&!candidates.length?<small className="field-hint">{t('No compatible entries without an equivalent connection.')}</small>:type&&role&&!related&&<small className="field-hint">{t('Choose the related entry to save the connection.')}</small>}
  </div>
  {type?.genealogy?.kind==='parent'&&role&&related&&<p className="connection-direction-preview" role="status">{t('{0} is a parent of {1}.',type.genealogy.parentRole===role?entry.title:related.title,type.genealogy.parentRole===role?related.title:entry.title)}</p>}
  {type&&type.genealogy?.kind!=='parent'&&role&&related&&!problem&&<div className="connection-direction-preview" role="status"><span>{entry.title} <small>({role==='source'?type.title:type.inverseTitle})</small></span>{type.symmetric?<ArrowLeftRight size={16} aria-hidden="true"/>:<ArrowRight size={16} aria-hidden="true"/>}<span>{related.title}{!type.symmetric&&<small> ({role==='source'?type.inverseTitle:type.title})</small>}</span></div>}
  {supportsPartnership(type)&&<div className="ui-form-field"><label htmlFor="connection-partnership">{t('Partnership status (optional)')}<FieldHelp label={t('Partnership status')} description={t('This describes this connection. Dates control its validity; no dates or parentage are inferred.')}/></label><Dropdown id="connection-partnership" value={partnershipStatus} onChange={value=>setPartnershipStatus(value as PartnershipStatus|'')} options={[{value:'',label:t('Not specified')},...Object.entries(partnershipLabels).map(([value,label])=>({value,label:buttonLabel(label)}))]}/></div>}
  <section className="connection-validity">
   <div className="connection-validity-heading"><button type="button" className="quick-action quick-action-text" aria-expanded={validityExpanded} aria-controls="connection-validity-fields" onClick={()=>setValidityExpanded(!validityExpanded)}><ChevronDown size={16} aria-hidden="true" className="connection-validity-chevron" data-expanded={validityExpanded}/>{buttonLabel(validityExpanded||start||end?'Validity (optional)':'Add validity')}</button>{!validityExpanded&&(start||end)&&<span className="field-hint">{start||'…'} — {end||'…'}</span>}<FieldHelp label={t('Date format')} description={t('Year, month or complete date. Negative years and year 0 are supported.')}/></div>
   <div id="connection-validity-fields" className="connection-validity-expansion" data-expanded={validityExpanded} inert={!validityExpanded}><div className="connection-validity-content"><fieldset disabled={!validityExpanded}><legend className="sr-only">{t('Validity (optional)')}</legend><div className="relation-role-fields"><div className="ui-form-field"><label htmlFor="connection-start">{t('Start date (optional)')}</label><input id="connection-start" value={start} maxLength={13} aria-invalid={!!startError} aria-describedby={startError?'connection-start-error':undefined} onChange={event=>setStart(event.target.value)}/>{startError&&<p id="connection-start-error" className="prompt-error" role="alert">{t(startError)}</p>}</div>
   <div className="ui-form-field"><label htmlFor="connection-end">{t('End date (optional)')}</label><input id="connection-end" value={end} maxLength={13} aria-invalid={!!endError} aria-describedby={endError?'connection-end-error':undefined} onChange={event=>setEnd(event.target.value)}/>{endError&&<p id="connection-end-error" className="prompt-error" role="alert">{t(endError)}</p>}</div></div>
   </fieldset></div></div>
   {!validityExpanded&&dateError&&<p className="prompt-error" role="alert">{t(dateError)}</p>}
  </section>
  {type?.needsRoleReview&&<p className="prompt-error" role="alert">{t(connectionProblemText.review)}</p>}
  <div className="relation-connection-footer"><button type="button" data-relation-cancel onClick={onCancel} className="quick-action quick-action-text">{t('Cancel')}</button><button type="submit" className="primary-button" disabled={!valid}>{t('Save connection')}</button></div>
 </form></RelationDialog>;
}
