import {bookChapterLabel} from './books';
import {history,closeHistory} from '@tiptap/pm/history';
import type {ManuscriptHistory} from './manuscriptHistory';
import {getSchema} from '@tiptap/core';
import StarterKit from '@tiptap/starter-kit';
import {EditorState} from '@tiptap/pm/state';
import type {Transaction} from '@tiptap/pm/state';
import {fromMarkdown,toMarkdown} from './model';
import type {Project,Scene} from './model';
import {fragmentDocumentIndex} from './decisionFragments';
import {createCommentPlugin,commentKey} from './reviewComments';
import {createMentionPlugin,mentionPluginKey} from './manuscriptMentions';
import {emptyWorld} from './worldbuilding';
export type ManuscriptMatch={sceneId:string;chapterId:string;title:string;from:number;to:number;before:string;quote:string;after:string;content:string};
export type FindOptions={query:string;scope:'scene'|'chapter'|'book'|'project';bookId?:string;sceneId?:string;chapterId?:string;caseSensitive:boolean;wholeWord:boolean};
export const manuscriptSchema=getSchema([StarterKit.configure({heading:false,blockquote:false,bulletList:false,orderedList:false,listItem:false,code:false,codeBlock:false})]);
// Scene objects are immutable; unchanged scenes retain their visible-text index.
const searchIndexes=new WeakMap<Scene,{content:string;index:ReturnType<typeof fragmentDocumentIndex>}>();
function searchIndex(scene:Scene){
 const cached=searchIndexes.get(scene);if(cached?.content===scene.content)return cached.index;
 const index=fragmentDocumentIndex(fromMarkdown(scene.content));searchIndexes.set(scene,{content:scene.content,index});return index;
}
export function findManuscript(project:Project,options:FindOptions):ManuscriptMatch[]{
 if(!options.query||/[\r\n]/.test(options.query))return [];
 const escaped=options.query.replace(/[.*+?^${}()|[\]\\]/g,'\\$&');
 const pattern=new RegExp(escaped,options.caseSensitive?'gu':'giu'),word=/[\p{L}\p{N}\p{M}_]/u;
 const matches:ManuscriptMatch[]=[];
 for(const chapter of project.chapters){if(options.scope==='book'&&!project.books?.find(book=>book.id===options.bookId)?.chapterIds.includes(chapter.id))continue;if(options.scope==='chapter'&&chapter.id!==options.chapterId)continue;
 for(const scene of chapter.scenes){if(options.scope==='scene'&&scene.id!==options.sceneId)continue;
 const {text,positions}=searchIndex(scene);
 for(const match of text.matchAll(pattern)){const start=match.index!,end=start+match[0].length;
 if(options.wholeWord&&(word.test(Array.from(text.slice(Math.max(0,start-2),start)).slice(-1)[0]??'')||word.test(Array.from(text.slice(end,end+2))[0]??'')))continue;
 matches.push({sceneId:scene.id,chapterId:chapter.id,title:`${bookChapterLabel(project,chapter.id)} / ${scene.title}`,from:positions[start].from,to:positions[end-1].to,before:text.slice(Math.max(0,start-45),start),quote:match[0],after:text.slice(end,end+45),content:scene.content});
 }} }return matches;
}
export function replacementTransaction(state:EditorState,matches:ManuscriptMatch[],replacement:string):Transaction{
 let tr=state.tr;
 for(const match of [...matches].sort((a,b)=>b.from-a.from)){
 if(tr.doc.textBetween(match.from,match.to,'\n','\n')!==match.quote)throw new Error('Search results changed. Search again.');
 tr=replacement?tr.insertText(replacement,match.from,match.to):tr.delete(match.from,match.to);
 }return tr;
}
export function replaceManuscript(project:Project,matches:ManuscriptMatch[],replacement:string,cache?:ManuscriptHistory):Project{
 if(/[\r\n]/.test(replacement))throw new Error('Use a single line for replacement.');
 return {...project,chapters:project.chapters.map(chapter=>({...chapter,scenes:chapter.scenes.map(scene=>{
 const selected=matches.filter(m=>m.sceneId===scene.id);if(!selected.length)return scene;
 if(selected.some(m=>m.content!==scene.content))throw new Error('Search results changed. Search again.');
 let state=EditorState.create({schema:manuscriptSchema,doc:manuscriptSchema.nodeFromJSON(fromMarkdown(scene.content)),plugins:[history(),createCommentPlugin(scene.reviewComments??[],()=>{}),createMentionPlugin(project.worldbuilding??emptyWorld,()=>{},scene.ignoredMentions??[],()=>{},scene.resolvedMentions??[])]});
 state=cache?.restore(scene.id,state)??state;
 let next=state.apply(closeHistory(replacementTransaction(state,selected,replacement)));
 next=next.apply(closeHistory(next.tr));
 cache?.remember(scene.id,next);
 return {...scene,content:toMarkdown(next.doc.toJSON()),reviewComments:commentKey.getState(next)?.comments??[],ignoredMentions:mentionPluginKey.getState(next)?.ignored??[],resolvedMentions:mentionPluginKey.getState(next)?.resolved??[]} satisfies Scene;
 })}))};
}
