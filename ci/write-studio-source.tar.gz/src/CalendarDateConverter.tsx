import CalendarDateContext from './CalendarDateContext';
import {useId,useState} from 'react';
import Dropdown from './Dropdown';
import {t,message} from './i18n';
import {parseStoryDate,formatStoryDate} from './timeline';
import type {StoryDate} from './timeline';
import {calendarFromStoryDate,storyDateFromCalendar,calendarDateLabel,parseCalendarDate} from './storyCalendar';
import type {StoryCalendar} from './storyCalendar';
export default function CalendarDateConverter({calendar,onStart,onEnd}:{calendar:StoryCalendar;onStart?:(date:StoryDate)=>void;onEnd?:(date:StoryDate)=>void}){
 const id=useId();
 const [direction,setDirection]=useState('world'),[value,setValue]=useState('0-01-01');let result='',error='',canonical:StoryDate|undefined;
 try{if(value.trim()){
  if(direction==='world'){canonical=storyDateFromCalendar(parseCalendarDate(value,calendar),calendar);result=formatStoryDate(canonical);}
  else{canonical=parseStoryDate(value);if(!canonical?.month||!canonical.day)throw new Error(t('Enter a complete, valid date.'));result=formatStoryDate(calendarFromStoryDate(canonical,calendar));}
 }}catch(reason){error=message(String(reason));}
 return <div className="calendar-converter"><label>{t('Convert dates')}<Dropdown id={`${id}-direction`} aria-label={t('Convert dates')} value={direction} options={[{value:'world',label:t('World calendar → stored date')},{value:'stored',label:t('Stored date → world calendar')}]} onChange={setDirection}/></label><label>{t('Complete date (year-month-day)')}<input value={value} aria-describedby={error?`${id}-error`:undefined} onKeyDown={event=>{if(event.key==='Enter')event.preventDefault();}} onChange={event=>setValue(event.target.value)} aria-invalid={!!error}/></label>{error&&<p id={`${id}-error`} role="alert" className="prompt-error">{error}</p>}{result&&canonical&&<><output aria-live="polite">{result}<small>{calendarDateLabel(canonical,calendar)}</small></output><CalendarDateContext date={canonical} calendar={calendar}/>{onStart&&<button type="button" className="quick-action quick-action-text" onClick={()=>onStart(canonical!)}>{t('Use as start date')}</button>}{onEnd&&<button type="button" className="quick-action quick-action-text" onClick={()=>onEnd(canonical!)}>{t('Use as end date')}</button>}</>}</div>;
}
