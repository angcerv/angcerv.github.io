import MapToolPanelHeading from './MapToolPanelHeading';
import {useEffect,useRef} from 'react';
import type {ReactNode,Ref} from 'react';
import {Paintbrush,Shapes,Castle,Type,Layers,PanelRightClose} from 'lucide-react';
import {t,buttonLabel} from './i18n';
export type DrawingCategory='select'|'terrain'|'shapes'|'symbols'|'text'|'layers'|'settings';
export const drawingCategoryLabels:Record<DrawingCategory,string>={select:'Select and move',terrain:'Terrain',shapes:'Lines and shapes',symbols:'Symbols',text:'Labels',layers:'Layers and elements',settings:'Map settings'};
export function DrawingToolRail({category,onChoose,active=true,children,leading}:{leading?:ReactNode;children?:ReactNode;active?:boolean;category:DrawingCategory;onChoose:(category:DrawingCategory)=>void}){
 return <nav className="drawing-tool-rail" aria-label={t('Drawing tools')}>{leading}{([{id:'terrain',Icon:Paintbrush},{id:'shapes',Icon:Shapes},{id:'symbols',Icon:Castle},{id:'text',Icon:Type}] as const).map(({id,Icon})=><button key={id} type="button" className="quick-action map-tool-rail-button" title={buttonLabel(drawingCategoryLabels[id])} aria-label={buttonLabel(drawingCategoryLabels[id])} aria-pressed={active&&category===id} onClick={()=>onChoose(id)}><Icon size={19} aria-hidden="true"/><span>{t(({terrain:'Terrain',shapes:'Shapes',symbols:'Symbols',text:'Text',layers:'Layers'} as const)[id])}</span></button>)}{children}</nav>;
}

export function DrawingOptionsPanel({open,title,onClose,children,headingRef}:{headingRef?:Ref<HTMLHeadingElement>;open:boolean;title:string;onClose:()=>void;children:ReactNode}){
 const content=useRef<HTMLDivElement>(null);
 useEffect(()=>{if(open&&content.current)content.current.scrollTop=0;},[open,title]);
 return <aside id="drawing-options-panel" className={`drawing-editor-panel drawing-options${open?' is-open':''}`} inert={!open} aria-hidden={!open} aria-label={title}><div><MapToolPanelHeading title={title} onClose={onClose} level={3} headingRef={headingRef}/><div ref={content} className="map-drawing-tools">{children}</div></div></aside>;
}
export function DrawingSelectionInspector({open,onClose,children,title='Selection properties',variant='properties',help}:{help?:ReactNode;variant?:'properties'|'layers';title?:string;open:boolean;onClose?:()=>void;children:ReactNode}){
 return <aside id={variant==='layers'?'drawing-layers-panel':undefined} className={`drawing-editor-panel ${variant==='layers'?'drawing-layers':'drawing-inspector'}${open?' is-open':''}`} inert={!open} aria-hidden={!open} aria-label={t(title)}><div><header><h3>{variant==='layers'&&<Layers size={16} aria-hidden="true"/>}{t(title)}</h3>{help}{onClose&&<button type="button" className="quick-action" title={t('Close panel')} aria-label={t('Close panel')} onClick={onClose}><PanelRightClose size={16}/></button>}</header><div className="drawing-inspector-content">{children}</div></div></aside>;
}
