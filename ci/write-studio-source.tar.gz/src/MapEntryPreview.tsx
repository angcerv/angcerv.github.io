import FieldHelp from './FieldHelp';
import { ExternalLink } from 'lucide-react';
import { t } from './i18n';
import type { Chapter } from './model';
import type { Entry, Worldbuilding } from './worldbuilding';
import { displayFieldValue, isEntryReference } from './worldbuilding';
import { fieldGroups } from './templateSections';
import { ReferenceLink } from './EntryReference';
import { EntryThumbnail } from './EntryImage';
import EntryUsageSummary from './EntryUsageSummary';
import {LongTextView} from './LongTextEditor';
import {ReferenceText} from './TextReferenceUI';

type Props={onEditEntry?:(id:string)=>void;entry:Entry;world:Worldbuilding;chapters:Chapter[];path:string;projectId:string;onOpenEntry:(id:string)=>void;onOpenScene?:(id:string)=>void;onOpenMention?:(sceneId:string,range:{from:number;to:number})=>void};
export default function MapEntryPreview({onEditEntry,entry,world,chapters,path,projectId,onOpenEntry,onOpenScene,onOpenMention}:Props){
 const template=world.templates.find(template=>template.id===entry.templateId);
 return <section className="map-linked-entry" aria-label={t('Linked entry preview')}>
  <header><EntryThumbnail projectPath={path} projectId={projectId} imageId={entry.imageId} title={entry.title}/><div><h2>{entry.title||t('Untitled entry')}</h2><p className="world-hint">{template?.title||t('Missing template')}{entry.archived?t(' · Archived entry'):''}</p></div></header>
  <button type="button" className="map-entry-link" onClick={()=>(onEditEntry??onOpenEntry)(entry.id)}><ExternalLink size={14}/>{t('Edit entry')}</button>
  {template&&<details className="map-entry-values"><summary>{t('Entry details')}</summary><div>{fieldGroups(template,true).filter(group=>group.fields.length).map(group=><div key={group.id}>{(template.sections?.length??0)>0&&<h3>{group.title}</h3>}<dl>{group.fields.map(field=><div key={field.id}><dt><span className="entry-field-label">{field.label||t('Untitled field')}<FieldHelp label={field.label||t('Untitled field')} description={field.description}/></span></dt><dd>{isEntryReference(entry.values[field.id])?<ReferenceLink world={world} reference={entry.values[field.id] as {entryId:string}} onNavigate={onOpenEntry} targetTemplateId={field.targetTemplateId}/>:field.fieldType==='longText'&&typeof entry.values[field.id]==='string'?<LongTextView value={entry.values[field.id] as string}/>:field.fieldType==='shortText'&&typeof entry.values[field.id]==='string'?<ReferenceText value={entry.values[field.id] as string}/>:displayFieldValue(field,entry.values[field.id],world)}</dd></div>)}</dl></div>)}</div></details>}
  <EntryUsageSummary chapters={chapters} world={world} entryId={entry.id} onOpenScene={onOpenScene} onOpenMention={onOpenMention}/>
 </section>;
}
