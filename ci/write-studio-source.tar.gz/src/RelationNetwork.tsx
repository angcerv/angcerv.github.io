import {usePinchZoom} from './usePinchZoom';
import {pinchCamera} from './pinchGesture';
import {isGraphDrag,draggedGraphPoint} from './graphGesture';
import ActionMenu from './ActionMenu';
import {workspaceViewMemory} from './workspaceNavigation';
import {useWorkspaceState} from './useWorkspaceState';
import RelationshipOptions from './RelationshipOptions';
import RelationshipTimeOptions from './RelationshipTimeOptions';
import {relationshipStatus,relationshipStatusText} from './relationshipTime';
import {renderGraphToolbar,renderRelationInspector,renderRelationshipList} from './RelationViewParts';
import GraphConnectionLabel from './GraphConnectionLabel';
import {useEffect,useMemo,useRef,useState} from 'react';
import {Plus,Save,Trash2,Pencil,MoreHorizontal} from 'lucide-react';
import Dropdown from './Dropdown';
import FieldHelp from './FieldHelp';
import RelationDialog from './RelationDialog';
import EntryConnectionDialog from './EntryConnectionDialog';
import {entryTemplateGlyph} from './entryTemplateGlyph';
import {normalizeEntryRelations,relationTypeName,removeEntryConnection} from './entryRelations';
import type {EntryRelations} from './entryRelations';
import {defaultGraphSettings,fitGraph,graphTopInset,readableGraphCamera,graphCanvasPoint,graphEdge,graphPositions,graphViewChanged,relationGraph,saveGraphView,zoomGraph,revealGraphPoint} from './relationGraph';
import type {GraphCamera,GraphPoint,GraphSettings,RelationGraphView} from './relationGraph';
import type {Worldbuilding} from './worldbuilding';
import type {Chapter} from './model';
import type {ProjectPlots} from './plotThreads';
import type {Timeline} from './timeline';
import {t,buttonLabel} from './i18n';

type Props={typeRequest?:{id:string;token:number};projectPath?:string;projectId?:string;world:Worldbuilding;relations:EntryRelations;chapters:Chapter[];plots?:ProjectPlots;timeline?:Timeline;initialFocusId?:string;onChange:(relations:EntryRelations)=>void;onWorldChange:(world:Worldbuilding)=>void;onOpenEntry:(id:string)=>void;onManage:()=>void;onBrowseEntries?:()=>void};
type Selection={kind:'entry'|'connection';id:string}|null;
type Gesture={moved?:boolean;pointerId:number;kind:'node'|'pan';id?:string;start:GraphPoint;point?:GraphPoint;camera:GraphCamera;positions:Record<string,GraphPoint>};
export default function RelationNetwork({typeRequest,projectPath,projectId,world,relations:input,chapters,plots,timeline,initialFocusId='',onChange,onWorldChange,onOpenEntry,onManage,onBrowseEntries}:Props){
 const relations=useMemo(()=>normalizeEntryRelations(input),[input]);
 const scope=`relationships.network.${initialFocusId||'all'}`;
 const freshCamera=!workspaceViewMemory()?.values[`${scope}.camera`];
 const [settings,setSettings]=useWorkspaceState<GraphSettings>(`${scope}.settings`,{...defaultGraphSettings,focusId:initialFocusId,showArchived:!!world.entries.find(entry=>entry.id===initialFocusId)?.archived});
 const [positions,setPositions]=useWorkspaceState<Record<string,GraphPoint>>(`${scope}.positions`,()=>graphPositions(relationGraph(world,relations,settings,{chapters,plots,timeline}).nodes,settings.focusId,{},relations.links)),[camera,setCamera]=useWorkspaceState<GraphCamera>(`${scope}.camera`,()=>readableGraphCamera(graphPositions(relationGraph(world,relations,settings,{chapters,plots,timeline}).nodes,settings.focusId,{},relations.links)));
 const [selected,setSelected]=useWorkspaceState<Selection>(`${scope}.selected`,initialFocusId?{kind:'entry',id:initialFocusId}:null),[viewId,setViewId]=useWorkspaceState(`${scope}.viewId`,''),[naming,setNaming]=useState(false),[name,setName]=useState(''),[removingView,setRemovingView]=useState(false),[editing,setEditing]=useState(''),[unlinking,setUnlinking]=useState('');
 const [inspectorOpen,setInspectorOpen]=useWorkspaceState(`${scope}.inspector`,!!initialFocusId),[legend,setLegend]=useWorkspaceState(`${scope}.legend`,false),[renaming,setRenaming]=useState(false),[pendingView,setPendingView]=useState<string|null>(null);
 const surface=useRef<SVGSVGElement>(null),gesture=useRef<Gesture|null>(null);
 const graph=useMemo(()=>relationGraph(world,relations,settings,{chapters,plots,timeline}),[world,relations,settings,chapters,plots,timeline]);
 const points=useMemo(()=>graphPositions(graph.nodes,settings.focusId,positions,graph.links),[graph.nodes,graph.links,settings.focusId,positions]);
 const entry=selected?.kind==='entry'?world.entries.find(entry=>entry.id===selected.id):undefined;
 const connection=selected?.kind==='connection'?relations.links.find(link=>link.id===selected.id):undefined;
 const source=world.entries.find(entry=>entry.id===connection?.sourceId);
 const saved=relations.views?.find(view=>view.id===viewId),snapshot={settings,positions:{...positions,...points},camera};
 const [explorationStart,setExplorationStart]=useWorkspaceState(`${scope}.baseline`,()=>({settings,positions,camera}));
 const dirty=!!saved&&graphViewChanged(saved,settings,snapshot.positions,camera);
 const explorationDirty=!saved&&graphViewChanged({id:'',name:'',...explorationStart},settings,snapshot.positions,camera);
 const invalidFilter=!!settings.focusId&&!world.entries.some(entry=>entry.id===settings.focusId)||!!settings.templateId&&!world.templates.some(template=>template.id===settings.templateId)||!!settings.typeId&&!relations.types.some(type=>type.id===settings.typeId)||!!settings.plotId&&!plots?.threads.some(plot=>plot.id===settings.plotId);
 function changeSettings(patch:Partial<GraphSettings>){const next={...settings,...patch};setPositions({...positions,...points});setSettings(next);const visible=relationGraph(world,relations,next,{chapters,plots,timeline});if(selected&&!((selected.kind==='entry'?visible.nodes:visible.links).some(item=>item.id===selected.id)))setSelected(null);}
 useEffect(()=>{if(typeRequest)changeSettings({typeId:typeRequest.id});},[typeRequest?.token]);
 function fitVisible(){const rect=surface.current?.getBoundingClientRect(),height=surface.current?.parentElement?.querySelector<HTMLElement>('.relation-network-canvas-tools')?.getBoundingClientRect().height;setCamera(fitGraph(points,graphTopInset(rect,height)));}
 function centerSelection(){const point=entry?points[entry.id]:connection&&points[connection.sourceId]&&points[connection.targetId]?{x:(points[connection.sourceId].x+points[connection.targetId].x)/2,y:(points[connection.sourceId].y+points[connection.targetId].y)/2}:undefined;if(point){const rect=surface.current?.getBoundingClientRect(),compact=(surface.current?.closest?.('.world-relationship-workspace')?.clientWidth??rect?.width??1400)<700;setCamera(rect&&inspectorOpen?revealGraphPoint(camera,point,rect,compact,true):{...camera,x:700-point.x*camera.zoom,y:450-point.y*camera.zoom});}}
 function revealPoint(point:GraphPoint|undefined){const rect=surface.current?.getBoundingClientRect();if(!point||!rect)return;const compact=(surface.current?.closest?.('.world-relationship-workspace')?.clientWidth??rect.width)<700;setCamera(revealGraphPoint(camera,point,rect,compact));}
 function selectEntry(id:string){setSelected({kind:'entry',id});setInspectorOpen(true);revealPoint(points[id]);}
 function requestView(id:string){if(dirty||explorationDirty){setPendingView(id);return;}loadView(id);}

 function loadView(id:string){
  const view=relations.views?.find(view=>view.id===id);setViewId(view?.id??'');setSelected(null);
  if(view){setSettings({...view.settings});setPositions(structuredClone(view.positions));setCamera({...view.camera});}
  else {const arranged=graphPositions(relationGraph(world,relations,defaultGraphSettings,{chapters,plots,timeline}).nodes,'',{},relations.links),framed=readableGraphCamera(arranged,'',surface.current?.getBoundingClientRect());setExplorationStart({settings:{...defaultGraphSettings},positions:arranged,camera:framed});setSettings({...defaultGraphSettings});setPositions(arranged);setCamera(framed);}
 }
 function storeView(title:string,id=viewId){
  const nextId=id||crypto.randomUUID();const view:RelationGraphView={id:nextId,name:title.trim(),...snapshot};onChange(saveGraphView(relations,view));setViewId(nextId);setNaming(false);
 }
 function canvasPoint(event:{clientX:number;clientY:number}){const rect=surface.current?.getBoundingClientRect();return rect?graphCanvasPoint(event.clientX,event.clientY,rect):null;}
 useEffect(()=>{const svg=surface.current;if(!svg)return;const wheel=(event:WheelEvent)=>{event.preventDefault();if(gesture.current)return;const anchor=graphCanvasPoint(event.clientX,event.clientY,svg.getBoundingClientRect());if(anchor)setCamera(previous=>zoomGraph(previous,previous.zoom*Math.exp(-event.deltaY*.0015),anchor));};svg.addEventListener('wheel',wheel,{passive:false});return()=>svg.removeEventListener('wheel',wheel);},[]);
 function move(event:{pointerId:number;clientX:number;clientY:number}){
  const active=gesture.current,point=canvasPoint(event);if(!active||active.pointerId!==event.pointerId||!point)return;
  const rect=surface.current?.getBoundingClientRect(),screenScale=rect?Math.min(rect.width/1400,rect.height/900):1;
  if(!active.moved&&!isGraphDrag(active.start,point,screenScale))return;
  active.moved=true;
  if(active.kind==='pan')setCamera({...active.camera,x:active.camera.x+point.x-active.start.x,y:active.camera.y+point.y-active.start.y});
  else if(active.point&&active.id){setSelected({kind:'entry',id:active.id});setPositions({...active.positions,[active.id]:draggedGraphPoint(active.point,active.start,point,active.camera.zoom)});}
 }
 function finish(cancel=false){const active=gesture.current;if(!active)return;gesture.current=null;
  if(cancel){setCamera(active.camera);setPositions(active.positions);}
  else if(active.moved)draggedAt.current=Date.now();
  else if(active.kind==='node'&&active.id)selectEntry(active.id);
  else {setSelected(null);setInspectorOpen(false);}
  if(surface.current?.hasPointerCapture(active.pointerId))surface.current.releasePointerCapture(active.pointerId);
 }
 usePinchZoom(surface,{start:()=>gesture.current?.camera??camera,update:(snapshot,{ratio,start,center})=>{
  const rect=surface.current?.getBoundingClientRect();if(!rect)return;const a=graphCanvasPoint(start.x,start.y,rect),b=graphCanvasPoint(center.x,center.y,rect);if(a&&b)setCamera(pinchCamera(snapshot,ratio,a,b,.15,3));
 },cancel:setCamera});
 const duplicateName=relations.views?.some(view=>(!renaming||view.id!==viewId)&&view.name.trim().toLocaleLowerCase()===name.trim().toLocaleLowerCase());
 const selectConnection=(id:string)=>{setSelected({kind:'connection',id});setInspectorOpen(true);const link=relations.links.find(link=>link.id===id);if(link)revealPoint(points[link.targetId]);};
 useEffect(()=>{if(inspectorOpen){const list=surface.current?.parentElement?.querySelector<HTMLDetailsElement>('.relation-accessible-list');if(list){const restore=list.contains(document.activeElement);list.open=false;if(restore)surface.current?.parentElement?.parentElement?.querySelector<HTMLElement>('.relation-network-inspector button')?.focus();}}},[inspectorOpen]);
 const draggedAt=useRef(0);
 const firstFrame=useRef(freshCamera);
 useEffect(()=>{if(!firstFrame.current||!surface.current)return;const rect=surface.current.getBoundingClientRect();if(!rect.width||!rect.height)return;firstFrame.current=false;const next=readableGraphCamera(points,settings.focusId,rect,surface.current.parentElement?.querySelector<HTMLElement>('.relation-network-canvas-tools')?.getBoundingClientRect().height);setCamera(next);setExplorationStart({settings,positions:{...positions,...points},camera:next});});
 return <section className="relation-network" aria-label={t('Relationship network')}>
  <header className="relation-network-heading"><div><h2>{t('Relationship network')}</h2><span role="status"><span aria-label={t('Visible entries: {0} of {1}',graph.nodes.length,world.entries.length)}>{t('Entries')} {graph.nodes.length}/{world.entries.length}</span> · <span aria-label={t('Visible connections: {0} of {1}',graph.links.length,relations.links.length)}>{t('Connections')} {graph.links.length}/{relations.links.length}</span></span></div></header>
  <div className="relation-main-toolbar"><div className="relation-network-filters">
   <div className="relation-filter-field relation-focus-filter"><label htmlFor="relationship-focus">{t('Entry neighbourhood')}</label><Dropdown density="relationship" id="relationship-focus" aria-label={t('Center on an entry')} searchable value={settings.focusId} selectedLabel={t('Missing entry')} onChange={value=>changeSettings({focusId:value})} options={[{value:'',label:t('Whole network')},...world.entries.filter(entry=>settings.showArchived||!entry.archived).map(entry=>({value:entry.id,label:entry.title||t('Untitled entry')}))]}/><FieldHelp label={t('Entry neighbourhood')} description={t('Limits the network to this entry and its direct connections, or two levels. Use Center selection to move the camera without changing filters.')}/></div>
   {settings.focusId&&<div className="relation-depth" role="group" aria-label={t('Relationship depth')}>{([1,2] as const).map(depth=><button type="button" key={depth} aria-pressed={settings.depth===depth} onClick={()=>changeSettings({depth})}>{depth===1?t('1 level'):t('{0} levels',depth)}</button>)}</div>}
   <RelationshipOptions iconOnly label={t('Filters')}>    <div className="relation-filter-field"><label htmlFor="relationship-template-filter">{t('Template')}</label><Dropdown density="relationship" searchable id="relationship-template-filter" aria-label={t('Filter by template')} value={settings.templateId} selectedLabel={t('Missing template')} onChange={value=>changeSettings({templateId:value})} options={[{value:'',label:t('All templates')},...world.templates.map(template=>({value:template.id,label:template.title}))]}/></div>
   <div className="relation-filter-field"><label htmlFor="relationship-type-filter">{t('Relationship type')}</label><Dropdown density="relationship" searchable id="relationship-type-filter" aria-label={t('Filter by relationship type')} value={settings.typeId} selectedLabel={t('Missing relationship type')} onChange={value=>changeSettings({typeId:value})} options={[{value:'',label:t('All relationship types')},...relations.types.map(type=>({value:type.id,label:relationTypeName(type)}))]}/></div>
   <div className="relation-filter-field relation-plot-filter"><label htmlFor="relationship-plot-filter">{t('Plot')}</label><Dropdown density="relationship" searchable id="relationship-plot-filter" aria-label={t('Related to plot')} value={settings.plotId} selectedLabel={t('Missing plot')} onChange={value=>changeSettings({plotId:value})} options={[{value:'',label:t('All plots')},...(plots?.threads??[]).map(plot=>({value:plot.id,label:plot.title}))]}/><FieldHelp label={t('Related to plot')} description={t('Includes entries linked to scenes or events in this plot. Lines always represent saved connections.')}/></div>
   </RelationshipOptions>

  </div><div className="relation-view-actions" role="group" aria-label={t('Saved relationship views')}>
   <label htmlFor="relationship-saved-view">{t('View')}</label><div className="relation-view-controls">
   <Dropdown density="relationship" searchable id="relationship-saved-view" aria-label={t('Saved relationship views')} aria-describedby={dirty||explorationDirty?'relationship-view-dirty':undefined} value={viewId} onChange={requestView} options={[{value:'',label:t('Temporary exploration')},...(relations.views??[]).map(view=>({value:view.id,label:view.name}))]}/>
   <span className="relation-view-change">{(dirty||explorationDirty)&&<small id="relationship-view-dirty" className="relation-view-dirty" role="status" title={t(saved?'Unsaved view changes':'Modified temporary exploration')}>{t('Not saved')}<span className="visually-hidden"> · {t(saved?'Save to keep the changes to this view.':'Save this exploration as a named view to keep it.')}</span></small>}</span>
   <button type="button" className="quick-action" aria-label={buttonLabel(saved?'Update saved view':'Save view')} title={buttonLabel(saved?'Update saved view':'Save view')} onClick={()=>{if(saved)storeView(saved.name);else{setRenaming(false);setName('');setNaming(true);}}}><Save size={18}/></button>
   <ActionMenu iconOnly label={t('View options')} actions={[
    {label:t('Save as new view'),icon:<Plus size={16}/>,onClick:()=>{setRenaming(false);setName('');setNaming(true);}},
    {label:t('Rename view'),icon:<Pencil size={16}/>,disabled:!saved,onClick:()=>{setRenaming(true);setName(saved?.name??'');setNaming(true);}},
    {label:t('Delete saved view'),icon:<Trash2 size={16}/>,disabled:!saved,danger:true,onClick:()=>setRemovingView(true)},
   ]}><MoreHorizontal size={18} aria-hidden="true"/></ActionMenu>
  </div></div>
  <RelationshipTimeOptions id="network-at-date" at={settings.at} showEnded={!!settings.showEnded} onChange={(at,showEnded)=>changeSettings({at,showEnded:at?showEnded:undefined})}/></div>
  <div className="relation-network-checkboxes"><label className="relation-archive-filter"><input type="checkbox" checked={settings.showArchived} onChange={event=>changeSettings({showArchived:event.target.checked})}/><span>{t('Show archived entries')}</span></label></div>
  {(settings.focusId||settings.templateId||settings.typeId||settings.plotId||settings.showArchived)&&<div className="relation-filter-chips" aria-label={t('Active filters')}>{([['focusId',t('Entry neighbourhood'),world.entries.find(item=>item.id===settings.focusId)?.title],['templateId',t('Template'),world.templates.find(item=>item.id===settings.templateId)?.title],['typeId',t('Relationship type'),relations.types.find(item=>item.id===settings.typeId)&&relationTypeName(relations.types.find(item=>item.id===settings.typeId)!)],['plotId',t('Plot'),plots?.threads.find(item=>item.id===settings.plotId)?.title]] as const).filter(([key])=>settings[key]).map(([key,label,value])=><button key={key} type="button" title={t('Clear filter {0}',label)} onClick={()=>changeSettings({[key]:''})}>{label}: {value??t('Missing entry')} ×</button>)}{settings.showArchived&&<span>{t('Show archived entries')}</span>}<button type="button" onClick={()=>changeSettings({...defaultGraphSettings,showLabels:settings.showLabels,at:undefined,showEnded:undefined})}>{t('Clear filters')}</button></div>}
  {!relations.links.length&&!!world.entries.length&&<p className="world-hint relation-empty-summary">{t('No connections yet. Select an entry and choose New connection.')} <button type="button" disabled={!world.entries.some(entry=>!entry.archived)} onClick={()=>{changeSettings({...defaultGraphSettings});const first=world.entries.find(entry=>!entry.archived);if(first)selectEntry(first.id);}}>{t('Choose an entry to connect')}</button></p>}

  {invalidFilter&&<p className="relation-review-notice" data-semantic-tone="attention">{t('This view contains a missing filter or focus entry. Choose an available value to update it.')}</p>}
  {graph.missing>0&&<button type="button" className="relation-review-link" onClick={onManage}>{t('{0} connections with missing entries · review',graph.missing)}</button>}
  <div className="relation-network-layout" data-details={inspectorOpen&&!!(entry||connection)}><div className="relation-network-canvas">
   {renderGraphToolbar({zoom:camera.zoom,onZoom:zoom=>setCamera(zoomGraph(camera,zoom)),onFit:fitVisible,onCenter:centerSelection,onArrange:()=>{const arranged=graphPositions(graph.nodes,settings.focusId,{},graph.links);setPositions({...positions,...arranged});setCamera(readableGraphCamera(arranged,settings.focusId,surface.current?.getBoundingClientRect()));},labels:settings.showLabels,onLabels:()=>setSettings({...settings,showLabels:!settings.showLabels}),legend,onLegend:()=>setLegend(!legend),details:inspectorOpen,onDetails:()=>{if(!inspectorOpen)revealPoint(entry?points[entry.id]:connection?points[connection.targetId]:undefined);setInspectorOpen(!inspectorOpen);},hasSelection:!!(entry||connection)})}
   {legend&&<div className="relation-graph-legend"><strong>{t('Legend')}</strong><p>↔ {t('Same name on both sides')}</p><p>⇢ {t('Different participant roles')}</p>{settings.at&&<><p>┄ {t('Ended before this date')}</p><p>┈ {t('Validity uncertain')}</p></>}</div>}

   <svg ref={surface} className="relation-network-svg" viewBox="0 0 1400 900" aria-label={t('Relationship network canvas')} tabIndex={0} onKeyDown={event=>{if(event.key==='Escape'){finish(true);setSelected(null);}}} onPointerDown={event=>{
    if(event.button!==0||!event.isPrimary)return;const point=canvasPoint(event);if(!point)return;
    const node=(event.target as Element).closest('[data-graph-entry]'),edge=(event.target as Element).closest('[data-graph-connection]');if(edge)return;
    const id=node?.getAttribute('data-graph-entry')??'';
    if(id){(node as SVGElement).focus?.({preventScroll:true});gesture.current={pointerId:event.pointerId,kind:'node',id,start:point,point:points[id],camera,positions};}
    else{gesture.current={pointerId:event.pointerId,kind:'pan',start:point,camera,positions};}
    event.preventDefault();surface.current?.setPointerCapture(event.pointerId);
   }} onPointerMove={move} onPointerUp={event=>{move(event);finish();}} onPointerCancel={()=>finish(true)} onLostPointerCapture={()=>{if(gesture.current)finish(true);}}>
    <g transform={`translate(${camera.x} ${camera.y}) scale(${camera.zoom})`}>
     {graph.links.map(link=>{const type=relations.types.find(type=>type.id===link.typeId)!;const edge=graphEdge(link,graph.links,points),active=selected?.kind==='connection'&&selected.id===link.id,first=world.entries.find(entry=>entry.id===link.sourceId),second=world.entries.find(entry=>entry.id===link.targetId),description=`${first?.title}${type.needsRoleReview?'':` (${type.title})`} ${type.symmetric?'↔':'→'} ${second?.title}${type.needsRoleReview?'':` (${type.inverseTitle})`}`;return <g key={link.id} data-graph-connection={link.id} className={`relation-graph-edge${settings.at?` temporal-${relationshipStatus(link,settings.at)}`:''}${active?' is-selected':''}${entry&&(link.sourceId===entry.id||link.targetId===entry.id)?' is-related':''}${type.needsRoleReview?' needs-review':''}${!type.symmetric&&!type.needsRoleReview?' is-directed':''}`} role="button" tabIndex={0} aria-label={t('Select connection {0}',description)} onClick={()=>selectConnection(link.id)} onKeyDown={event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();event.stopPropagation();selectConnection(link.id);}}}><title>{description} · {relationTypeName(type)}{type.needsRoleReview?` · ${t('Roles pending review')}`:''}{settings.at?` · ${t(relationshipStatusText(relationshipStatus(link,settings.at)))}`:''}</title><path d={edge.path} className="relation-graph-edge-line"/><path d={edge.path} className="relation-graph-edge-hit"/>{(active||settings.showLabels&&graph.links.length<=18)&&<GraphConnectionLabel x={edge.label.x} y={edge.label.y} text={`${type.symmetric?'↔':'→'} ${relationTypeName(type)}`}/>}</g>;})}
     {graph.nodes.map(node=>{const point=points[node.id],template=world.templates.find(template=>template.id===node.templateId),Glyph=entryTemplateGlyph(template),active=selected?.kind==='entry'&&selected.id===node.id||!!connection&&(connection.sourceId===node.id||connection.targetId===node.id);return <g key={node.id} data-graph-entry={node.id} transform={`translate(${point.x} ${point.y})`} role="button" tabIndex={0} className={`relation-graph-node${active?' is-selected':''}${node.id===settings.focusId?' is-focus':''}`} aria-label={t('Select entry {0}',node.title)} onClick={event=>{if((!event||event.detail===0)&&Date.now()-draggedAt.current>250)selectEntry(node.id);}} onDoubleClick={()=>{if(Date.now()-draggedAt.current>350)changeSettings({focusId:node.id});}} onKeyDown={event=>{if(event.key==='Enter'||event.key===' '){event.preventDefault();selectEntry(node.id);}const delta:{[key:string]:GraphPoint}={ArrowLeft:{x:-20,y:0},ArrowRight:{x:20,y:0},ArrowUp:{x:0,y:-20},ArrowDown:{x:0,y:20}};if(delta[event.key]){event.preventDefault();event.stopPropagation();setPositions({...positions,[node.id]:{x:Math.max(-100000,Math.min(100000,point.x+delta[event.key].x)),y:Math.max(-100000,Math.min(100000,point.y+delta[event.key].y))}});}}}><title>{node.title} · {template?.title}</title><rect x="-90" y="-32" width="180" height="64" rx="10"/><clipPath id={`relation-node-label-${node.id}`}><rect x="-48" y="-23" width="128" height="47"/></clipPath><g transform="translate(-76 -12)"><Glyph size={18} strokeWidth={1.5}/></g><text x="-48" y="-2" clipPath={`url(#relation-node-label-${node.id})`} className="relation-node-name">{(node.title||t('Untitled entry')).length>21?`${node.title.slice(0,20)}…`:node.title||t('Untitled entry')}</text><text x="-48" y="17" clipPath={`url(#relation-node-label-${node.id})`} className="relation-node-template">{(template?.title??t('Missing template')).slice(0,24)}</text></g>;})}
    </g>
   </svg>{!graph.nodes.length&&<div className="relation-network-empty"><p>{t(world.entries.length?'No entries match these network filters.':'Create entries before connecting your world.')}</p>{world.entries.length?<button type="button" onClick={()=>changeSettings({...defaultGraphSettings})}>{t('Clear filters')}</button>:onBrowseEntries&&<button type="button" onClick={onBrowseEntries}>{t('Go to entries')}</button>}</div>}
  {renderRelationshipList({onOpen:()=>setInspectorOpen(false),world,relations,entryIds:graph.nodes.map(node=>node.id),linkIds:graph.links.map(link=>link.id),onEntry:selectEntry,onConnection:selectConnection,at:settings.at})}
  </div><aside className="relation-network-inspector" hidden={!inspectorOpen||!(entry||connection)} aria-label={t('Network selection details')}>
   {renderRelationInspector({world,relations,entry,connection,onWorldChange,onChange,onSelectEntry:selectEntry,onCenter:centerSelection,onOpenEntry,onManage,onEdit:setEditing,onUnlink:setUnlinking,onClose:()=>setInspectorOpen(false),projectPath,projectId,at:settings.at,visibleLinkIds:graph.links.map(link=>link.id)})}
  </aside></div>

  {pendingView!==null&&<RelationDialog variant="confirmation" title={t('Leave modified view?')} onClose={()=>setPendingView(null)}><p>{t('The saved view is unchanged. Keep exploring or discard this exploration to switch views.')}</p><div className="relation-connection-footer"><button type="button" onClick={()=>setPendingView(null)} className="quick-action quick-action-text">{t('Keep exploring')}</button><button type="button" onClick={()=>{loadView(pendingView);setPendingView(null);}} className="quick-action quick-action-text">{t('Switch view')}</button></div></RelationDialog>}

  {naming&&<RelationDialog dirty={name!==(renaming?saved?.name??'':'')} title={t(renaming?'Rename view':'Save relationship view')} onClose={()=>setNaming(false)}><form className="entry-connection-form" onSubmit={event=>{event.preventDefault();if(name.trim()&&!duplicateName){if(renaming&&saved){onChange({...relations,views:relations.views?.map(view=>view.id===saved.id?{...view,name:name.trim()}:view)});setNaming(false);}else storeView(name,'');}}}><label htmlFor="relationship-view-name">{t('View name')}</label><input id="relationship-view-name" required maxLength={80} value={name} onChange={event=>setName(event.target.value)}/>{duplicateName&&<p role="alert">{t('A view with this name already exists.')}</p>}<div className="relation-connection-footer"><button type="button" data-relation-cancel onClick={()=>setNaming(false)} className="quick-action quick-action-text">{t('Cancel')}</button><button type="submit" className="primary-button" disabled={!name.trim()||duplicateName}>{t('Save view')}</button></div></form></RelationDialog>}
  {removingView&&saved&&<RelationDialog variant="confirmation" title={t('Delete saved view?')} onClose={()=>setRemovingView(false)}><p>{saved.name}</p><p>{t('Only this saved layout and its filters are removed. Connections are kept.')}</p><div className="relation-connection-footer"><button type="button" onClick={()=>setRemovingView(false)} className="quick-action quick-action-text">{t('Cancel')}</button><button type="button" className="danger-button" onClick={()=>{onChange({...relations,views:relations.views?.filter(view=>view.id!==viewId)});setViewId('');setRemovingView(false);}}>{t('Delete saved view')}</button></div></RelationDialog>}
  {editing&&source&&<EntryConnectionDialog entry={source} world={world} relations={relations} connection={relations.links.find(link=>link.id===editing)} onSave={next=>{onChange(next);setEditing('');}} onCancel={()=>setEditing('')}/>}
  {unlinking&&<RelationDialog variant="confirmation" title={t('Unlink entries?')} onClose={()=>setUnlinking('')}><p>{t('Only this connection is removed. Both entries are kept.')}</p><div className="relation-connection-footer"><button type="button" onClick={()=>setUnlinking('')} className="quick-action quick-action-text">{t('Cancel')}</button><button type="button" className="danger-button" onClick={()=>{onChange(removeEntryConnection(relations,unlinking));setUnlinking('');setSelected(null);}}>{t('Unlink entries')}</button></div></RelationDialog>}
 </section>;
}
