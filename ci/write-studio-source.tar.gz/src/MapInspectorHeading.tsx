import type {ReactNode} from 'react';
export default function MapInspectorHeading({back,icon,title,help}:{back?:ReactNode;icon:ReactNode;title:ReactNode;help:ReactNode}){
 return <header className="map-inspector-heading"><div>{back}</div><h2>{icon}<span>{title}</span></h2><div>{help}</div></header>;
}
