import { seaColor } from './mapDrawing';
import { t } from './i18n';
import { invoke } from '@tauri-apps/api/core';
export const storeEntryImage = (path:string,projectId:string,imageId:string,image:number[],thumbnail:number[]) => invoke<void>('store_entry_image',{path,projectId,imageId,image,thumbnail});
export function imageDimensions(width:number,height:number,max:number) {
 if(!Number.isFinite(width) || !Number.isFinite(height) || width<=0 || height<=0)throw new Error(t("The image has invalid dimensions."));
 const scale=Math.min(1,max/Math.max(width,height));return {width:Math.max(1,Math.round(width*scale)),height:Math.max(1,Math.round(height*scale))};
}
export async function importVisualImage(path:string,projectId:string,isCurrent:()=>boolean):Promise<{id:string;title:string;originalFilename?:string}|null> {
 const selected=await invoke<{bytes:number[];name?:string}|null>('choose_entry_image');
 if(!selected || !isCurrent())return null;
 return prepareVisualImage(path,projectId,isCurrent,selected);
}
type SelectedImage={bytes:number[];name?:string};
async function prepareVisualImage(path:string,projectId:string,isCurrent:()=>boolean,selected:SelectedImage){
 const bitmap=await createImageBitmap(new Blob([new Uint8Array(selected.bytes)],{type:'application/octet-stream'})).catch(()=>{throw new Error(t("This image could not be opened. Try another PNG, JPEG or WebP."));});
 try {
  if(bitmap.width*bitmap.height>40_000_000)throw new Error(t("Choose an image smaller than 40 megapixels."));
  const encode=async(max:number)=>{
   const size=imageDimensions(bitmap.width,bitmap.height,max),canvas=document.createElement('canvas');canvas.width=size.width;canvas.height=size.height;
   const context=canvas.getContext('2d');if(!context)throw new Error(t("Image processing is unavailable."));
   context.imageSmoothingQuality='high';context.drawImage(bitmap,0,0,size.width,size.height);
   const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(value=>value ? resolve(value) : reject(new Error(t("The image could not be prepared."))),'image/png'));
   return Array.from(new Uint8Array(await blob.arrayBuffer()));
  };
  const image=await encode(2048),thumbnail=await encode(256);
  if(!isCurrent())return null;
  const imageId=crypto.randomUUID();await storeEntryImage(path,projectId,imageId,image,thumbnail);return {id:imageId,originalFilename:selected.name,title:selected.name?.replace(/\.[^.]+$/,'').trim()||t('Untitled image')};
 } finally {bitmap.close();}
}
// Prepare sequentially to bound bitmap/canvas memory; callers commit the batch once.
export async function importVisualImages(path:string,projectId:string,isCurrent:()=>boolean,maxCount=256){
 const selected=await invoke<SelectedImage[]|null>('choose_entry_images',{maxCount});
 if(!selected||!isCurrent())return [];
 const resources=[];
 for(const image of selected){
  if(!isCurrent())return [];
  const resource=await prepareVisualImage(path,projectId,isCurrent,image);
  if(!resource||!isCurrent())return [];
  resources.push(resource);
 }
 return resources;
}
// Cache only thumbnail blobs, bounded to 48 items. Object URLs belong to each mounted view.
const thumbnails=new Map<string,Promise<Blob>>();
export function readEntryImage(path:string,projectId:string,imageId:string,thumbnail:boolean):Promise<Blob> {
 const key=JSON.stringify([path,projectId,imageId]);
 if(thumbnail && thumbnails.has(key)){const cached=thumbnails.get(key)!;thumbnails.delete(key);thumbnails.set(key,cached);return cached;}
 const result=invoke<number[]>('read_entry_image',{path,projectId,imageId,thumbnail}).then(bytes=>new Blob([new Uint8Array(bytes)],{type:'image/png'}));
 if(thumbnail){thumbnails.set(key,result);if(thumbnails.size>48)thumbnails.delete(thumbnails.keys().next().value!);void result.catch(()=>{if(thumbnails.get(key)===result)thumbnails.delete(key);});}
 return result;
}

export async function createMapBaseImage(path:string,projectId:string):Promise<string> {
 const encode=async(width:number,height:number)=>{
  const canvas=document.createElement('canvas');canvas.width=width;canvas.height=height;
  const context=canvas.getContext('2d');if(!context)throw new Error(t('Image processing is unavailable.'));
  context.fillStyle=seaColor;context.fillRect(0,0,width,height);
  const blob=await new Promise<Blob>((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(new Error(t('The image could not be prepared.'))),'image/png'));
  return Array.from(new Uint8Array(await blob.arrayBuffer()));
 };
 const image=await encode(1600,1000),thumbnail=await encode(256,160),imageId=crypto.randomUUID();
 await storeEntryImage(path,projectId,imageId,image,thumbnail);return imageId;
}

export async function importEntryImage(path:string,projectId:string,isCurrent:()=>boolean):Promise<string|null>{return (await importVisualImage(path,projectId,isCurrent))?.id??null;}
