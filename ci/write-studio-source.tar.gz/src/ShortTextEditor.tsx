import type {FragmentRequest} from './decisionFragments';
import LongTextEditor from './LongTextEditor';
import {textReferencePlainText} from './textReferenceTokens';
import {t} from './i18n';
export const SHORT_TEXT_LIMIT=200;
// Limits count visible names, never the UUID/encoding stored for a reference.
export function acceptsShortText(previous:string,next:string){const length=textReferencePlainText(next).length;return length<=SHORT_TEXT_LIMIT||length<textReferencePlainText(previous).length;}
export default function ShortTextEditor({focusFragment,id,value,onChange,onConvert}:{focusFragment?:FragmentRequest;id:string;value:string;onChange:(value:string)=>void;onConvert:()=>void}){
 const length=textReferencePlainText(value).length,over=length>SHORT_TEXT_LIMIT;
 return <div className="short-text-editor"><LongTextEditor plain maxLength={SHORT_TEXT_LIMIT} describedBy={`${id}-limit`} focusFragment={focusFragment} id={id} value={value} onChange={onChange}/><div id={`${id}-limit`} className={over?'short-text-limit over-limit':length>=SHORT_TEXT_LIMIT*.85?'short-text-limit near-limit':'short-text-limit'}><span>{t('{0}/{1} characters',length,SHORT_TEXT_LIMIT)}</span>{over&&<button type="button" onClick={onConvert}>{t('Convert field to long text')}</button>}</div>{over&&<small>{t('Existing text is kept. Converting updates this field in every entry of the template.')}</small>}</div>;
}
