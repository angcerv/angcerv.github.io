import FieldHelp from './FieldHelp';
import { X } from 'lucide-react';
import Dropdown from './Dropdown';
import {t,buttonLabel} from './i18n';
import type { Chapter } from './model';
import type { MapRoute } from './maps';
export default function RouteManuscriptLinks({route,chapters,onChange,onOpenScene,onOpenChapter}:{route:MapRoute;chapters:Chapter[];onChange:(patch:Partial<MapRoute>)=>void;onOpenScene?:(id:string)=>void;onOpenChapter?:(id:string)=>void}){
 const scenes=chapters.flatMap(chapter=>chapter.scenes.map(scene=>({chapter,scene})));
 return <div className="route-manuscript-links"><h3>{t('Linked manuscript')}<FieldHelp label={t('Linked manuscript')} description={t('Chapter routes also appear in the details of its scenes. Unlinking keeps the route and manuscript intact.')}/></h3>
 {(['chapter','scene'] as const).map(kind=>{const key=kind==='scene'?'sceneIds':'chapterIds',ids=route[key]??[],open=kind==='scene'?onOpenScene:onOpenChapter;
 return <div key={kind}>{ids.map(id=>{const chapter=chapters.find(c=>c.id===id),item=scenes.find(item=>item.scene.id===id),exists=kind==='chapter'?!!chapter:!!item,title=kind==='chapter'?(chapter?.title||t('Missing chapter')):(item?`${item.chapter.title} · ${item.scene.title}`:t('Missing scene'));
 return <div className="route-manuscript-row" key={id}><button type="button" className="route-manuscript-open" disabled={!exists||!open} onClick={()=>open?.(id)}>{title}</button><button type="button" className="icon-button" aria-label={t('Unlink {0}',title)} title={t('Unlink')} onClick={()=>onChange({[key]:ids.filter(value=>value!==id)})}><X size={14}/></button></div>;})}
 <label htmlFor={`route-link-${kind}`}>{t(kind==='scene'?'Link a scene':'Link a chapter')}</label><Dropdown id={`route-link-${kind}`} value="" placeholder={buttonLabel(kind==='scene'?'Choose a scene':'Choose a chapter')} options={kind==='scene'?scenes.filter(item=>!ids.includes(item.scene.id)).map(({chapter,scene})=>({value:scene.id,label:`${chapter.title} · ${scene.title}`})):chapters.filter(c=>!ids.includes(c.id)).map(c=>({value:c.id,label:c.title||t('Untitled chapter')}))} onChange={id=>{if(id&&!ids.includes(id))onChange({[key]:[...ids,id]});}}/>
 </div>;})}

 </div>;
}
