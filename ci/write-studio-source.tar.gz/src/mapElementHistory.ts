import type {WorldMap} from './maps';
type Elements=Pick<WorldMap,'markers'|'routes'|'regions'>;
type Step={before:Elements;after:Elements;bytes:number;group:string;time:number};
const snapshot=(map:WorldMap):Elements=>({markers:map.markers,routes:map.routes,regions:map.regions});
// Native saves omit empty optional collections and may reorder object keys.
// Compare their meaning so an ordinary save is not treated as an external edit.
const serialize=(value:unknown)=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
const signature=(map:WorldMap)=>serialize({markers:map.markers,routes:(map.routes??[]).map(route=>({...route,sceneIds:route.sceneIds??[],chapterIds:route.chapterIds??[]})),regions:(map.regions??[]).map(region=>({...region,holes:region.holes??[]}))});
// Shared layers affect drawing ownership too: never restore them through this history.
const context=(map:WorldMap)=>serialize([map.id,map.imageId,map.drawing?.width,map.drawing?.height,map.imageFrame,(map.layers??[]).map(layer=>({...layer,locked:!!layer.locked}))]);
function textGroup(before:Elements,after:Elements){
 const changes:string[]=[];
 for(const kind of ['markers','routes','regions'] as const){
  const a=before[kind]??[],b=after[kind]??[];
  if(a.length!==b.length)return '';
  for(let i=0;i<a.length;i++){
   if(a[i].id!==b[i].id)return '';
   for(const key of new Set([...Object.keys(a[i]),...Object.keys(b[i])])){
    const left=a[i] as unknown as Record<string,unknown>,right=b[i] as unknown as Record<string,unknown>;
    if(JSON.stringify(left[key])!==JSON.stringify(right[key])){if(key!=='title'&&key!=='notes')return '';changes.push(`${kind}.${a[i].id}.${key}`);}
   }
  }
 }
 return changes.length===1?changes[0]:'';
}
/** Session-only, bounded geographic edits. Snapshots share immutable project data. */
export class MapElementHistory{
 private past:Step[]=[];
 private future:Step[]=[];
 private expected='';
 private scope='';
 private groupOpen=false;
 private observed?:WorldMap;
 sync(map:WorldMap){if(this.observed===map)return;this.observed=map;const scope=context(map),value=signature(map);if(scope!==this.scope||value!==this.expected){this.past=[];this.future=[];this.groupOpen=false;}this.scope=scope;this.expected=value;}
 breakGroup(){this.groupOpen=false;}
 get canUndo(){return this.past.length>0;}
 get canRedo(){return this.future.length>0;}
 record(before:WorldMap,after:WorldMap,now=Date.now()){
  this.sync(before);
  if(context(before)!==context(after)){this.sync(after);return;}
  const a=snapshot(before),b=snapshot(after),value=signature(after);
  if(this.expected===value)return;
  const group=textGroup(a,b),last=this.past[this.past.length-1],bytes=JSON.stringify(a).length+value.length;
  if(this.groupOpen&&group&&last?.group===group&&now-last.time<750){last.after=b;last.bytes=JSON.stringify(last.before).length+value.length;last.time=now;}
  else this.past.push({before:a,after:b,bytes,group,time:now});
  this.future=[];this.expected=value;this.observed=after;this.groupOpen=!!group;
  while(this.past.length>50||this.past.reduce((sum,step)=>sum+step.bytes,0)>8_000_000)this.past.shift();
 }
 move(map:WorldMap,direction:'undo'|'redo'):WorldMap{
  this.sync(map);this.breakGroup();const source=direction==='undo'?this.past:this.future,target=direction==='undo'?this.future:this.past,step=source.pop();if(!step)return map;
  target.push(step);const next={...map,...(direction==='undo'?step.before:step.after)};this.expected=signature(next);this.observed=next;return next;
 }
}
