/** Content meaning only: never infer status from arbitrary labels or interaction state. */
export type SemanticTone='neutral'|'progress'|'review'|'success'|'attention'|'error'|'info';
type StatusDomain='canon'|'editorial'|'writing'|'plot'|'arc'|'idea'|'relationship'|'continuity';
const domains:Record<StatusDomain,Record<string,SemanticTone>>={
 canon:{confirmed:'success',provisional:'attention',alternative:'info'},
 editorial:{notStarted:'neutral',developing:'progress',inReview:'review',defined:'success'},
 writing:{notStarted:'neutral',draft:'progress',inReview:'review',finished:'success'},
 plot:{planned:'neutral',active:'progress',resolved:'success'},
 arc:{planned:'neutral',active:'progress',resolved:'success'},
 idea:{idea:'neutral',deciding:'attention',decided:'review',incorporated:'success',discarded:'neutral'},
 relationship:{active:'neutral',ended:'neutral',future:'neutral',uncertain:'attention'},
 continuity:{broken:'error',ambiguous:'attention',age:'attention',chronology:'attention',travel:'attention',unused:'info'},
};
export function statusTone(domain:keyof typeof domains,value:string):SemanticTone|undefined{return domains[domain]?.[value];}
