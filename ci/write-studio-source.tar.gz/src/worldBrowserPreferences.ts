type BrowserScope='world'|'maps';
const key=(projectId:string,scope:BrowserScope)=>`write-studio.${scope}-browser.${projectId}`;
export const browserWidthMinimum=220,browserWidthMaximum=460,browserWidthDefault=280;
export function clampBrowserWidth(value:number){return Number.isFinite(value)?Math.max(browserWidthMinimum,Math.min(browserWidthMaximum,value)):browserWidthDefault;}
export function readBrowserWidth(projectId:string,scope:BrowserScope='world'){const fallback=scope==='maps'?240:browserWidthDefault;try{const stored=localStorage.getItem(key(projectId,scope));return stored===null?fallback:clampBrowserWidth(Number(stored));}catch{return fallback;}}
export function rememberBrowserWidth(projectId:string,width:number,scope:BrowserScope='world'){try{localStorage.setItem(key(projectId,scope),String(clampBrowserWidth(width)));}catch{/* Remains adjustable for this session. */}}
