import type {PendingItem,PendingKind} from './pendingItems';
export type PendingSection='ideas'|'review';
export function pendingSectionItems(items:PendingItem[],section:PendingSection){return items.filter(item=>section==='ideas'?!!item.idea:!item.idea);}
export function pendingSectionKinds(section:PendingSection):Array<PendingKind|'all'>{return section==='ideas'?['all','idea','narrative']:['all','comment','continuity','review','develop'];}
export function pendingSectionKind(section:PendingSection,kind:PendingKind|'all'){return pendingSectionKinds(section).includes(kind)?kind:'all';}
