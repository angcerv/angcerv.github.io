import type {Project} from './model';
import type {TextReferenceSource} from './textReferenceIndex';
import {LongTextView} from './LongTextEditor';
import {ReferenceText} from './TextReferenceUI';
import {eventDateLabel,timelineEventEntryIds} from './timeline';
import {ideaStatusLabels} from './worldIdeas';
import {t,buttonLabel} from './i18n';

export function consultableSource(source:TextReferenceSource){
 return ['entry','event','idea','plot','arc','scene','scenePlan','chapter','chapterPlan'].includes(source.kind);
}
export function consultationSource(kind:TextReferenceSource['kind'],id:string):TextReferenceSource{
 return {kind,id,entryId:'',label:'',field:'',excerpt:'',count:1};
}
export function consultationExists(project:Project,source:TextReferenceSource){
 const {kind,id}=source;
 if(kind==='entry')return !!project.worldbuilding?.entries.some(item=>item.id===id);
 if(kind==='event')return !!project.timeline?.events.some(item=>item.id===id);
 if(kind==='idea')return !!project.worldIdeas?.some(item=>item.id===id);
 if(kind==='plot')return !!project.plots?.threads.some(item=>item.id===id);
 if(kind==='arc')return !!project.plots?.arcs?.some(item=>item.id===id);
 if(kind==='scene'||kind==='scenePlan')return project.chapters.some(chapter=>chapter.scenes.some(item=>item.id===id));
 return project.chapters.some(item=>item.id===id);
}
export function SourceConsultation({project,source,titleOnly=false,onConsult}:{project:Project;source:TextReferenceSource;titleOnly?:boolean;onConsult?:(source:TextReferenceSource)=>void}){
 const {kind,id}=source,scenes=project.chapters.flatMap(chapter=>chapter.scenes);
 const event=kind==='event'?project.timeline?.events.find(item=>item.id===id):undefined;
 const idea=kind==='idea'?project.worldIdeas?.find(item=>item.id===id):undefined;
 const plot=kind==='plot'?project.plots?.threads.find(item=>item.id===id):undefined;
 const arc=kind==='arc'?project.plots?.arcs?.find(item=>item.id===id):undefined;
 const scene=['scene','scenePlan'].includes(kind)?scenes.find(item=>item.id===id):undefined;
 const chapter=['chapter','chapterPlan'].includes(kind)?project.chapters.find(item=>item.id===id):undefined;
 const item=event??idea??plot??arc??scene??chapter;
 if(titleOnly)return <>{item?.title||t(item?'Untitled':'Missing source')}</>;
 if(!item)return <p role="status">{t('Missing source')}</p>;
 const text=(label:string,value?:string,translate=true)=>value?.trim()?<section key={label}><h3>{translate?t(label):label}</h3><LongTextView value={value}/></section>:null;
 const links=(label:string,kind:TextReferenceSource['kind'],ids:string[],items:{id:string;title:string}[])=>ids.length?<section><h3>{t(label)}</h3><div className="text-reference-list">{ids.map(id=>{const target=items.find(item=>item.id===id);return <button type="button" className="reference-link" key={id} disabled={!target} onClick={()=>onConsult?.(consultationSource(kind,id))}>{target?.title||buttonLabel(target?'Untitled':'Missing source')}</button>;})}</div></section>:null;
 const entries=project.worldbuilding?.entries??[];
 return <div className="text-reference-preview-fields">
 {event&&<><p>{eventDateLabel(event)}</p>{text('Notes',event.notes)}{links('Worldbuilding entries','entry',timelineEventEntryIds(event),entries)}{links('Linked scenes','scene',event.sceneIds,scenes)}{links('Linked plots','plot',event.plotIds??[],project.plots?.threads??[])}</>}
 {idea&&<><p>{t(ideaStatusLabels[idea.status])}</p>{text('Description',idea.description)}{text('Decision',idea.decision)}{links('Worldbuilding entries','entry',idea.entryIds,entries)}{links('Linked scenes','scene',idea.sceneIds??[],scenes)}{links('Linked plots','plot',idea.plotIds??[],project.plots?.threads??[])}</>}
 {plot&&<>{text('Notes',plot.notes)}{links('Linked scenes','scene',plot.beats.map(beat=>beat.sceneId),scenes)}{plot.beats.map(beat=>text(scenes.find(scene=>scene.id===beat.sceneId)?.title||t('Missing scene'),beat.note,false))}</>}
 {arc&&<>{links('Character','entry',[arc.entryId],entries)}{text('Starting point',arc.startingPoint)}{text('Desire',arc.desire)}{text('Inner conflict',arc.innerConflict)}{text('Resolution',arc.resolution)}{text('Notes',arc.notes)}{links('Linked scenes','scene',arc.beats.map(beat=>beat.sceneId),scenes)}</>}
 {scene&&<>{scene.synopsis&&<section><h3>{t('Scene synopsis')}</h3><p><ReferenceText value={scene.synopsis}/></p></section>}{Object.entries(scene.planning??{}).filter(([key,value])=>key!=='schemaVersion'&&typeof value==='string').map(([key,value])=>text(({goal:'Goal in this scene',conflict:'Conflict in this scene',change:'What changes in this scene?'} as Record<string,string>)[key]??key,typeof value==='string'?value:''))}{text('Manuscript',scene.content)}{links('Worldbuilding entries','entry',scene.entryIds??[],entries)}</>}
 {chapter&&<>{text('Chapter synopsis',chapter.synopsis)}{Object.entries(chapter.planning??{}).filter(([key,value])=>key!=='schemaVersion'&&typeof value==='string').map(([key,value])=>text(({purpose:'Chapter purpose',conflict:'Conflict',turn:'Turning point',outcome:'Outcome',notes:'Notes'} as Record<string,string>)[key]??key,typeof value==='string'?value:''))}{links('Linked scenes','scene',chapter.scenes.map(scene=>scene.id),scenes)}</>}
 </div>;
}
