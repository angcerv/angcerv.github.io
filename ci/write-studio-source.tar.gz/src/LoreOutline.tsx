import SectionIndex from './SectionIndex';
import type {IndexSection} from './SectionIndex';
import {useEffect,useState} from 'react';
import type {RefObject} from 'react';
import {List,ChevronLeft,ChevronRight} from 'lucide-react';
import {revealLoreSection,visibleLoreSection} from './worldLore';
import {t} from './i18n';
export type LoreSection=IndexSection;
export default function LoreOutline({sections,root,context,onVisible,reading=false}:{reading?:boolean;sections:LoreSection[];root:RefObject<HTMLDivElement|null>;context:string;onVisible:(id:string)=>void}){
 const [active,setActive]=useState(''),[open,setOpen]=useState(()=>reading||typeof window!=='undefined'&&!!window.matchMedia?.('(min-width:1250px)').matches);
 useEffect(()=>{const element=root.current;if(!element)return;let frame=0;const update=()=>{cancelAnimationFrame(frame);frame=requestAnimationFrame(()=>{const id=visibleLoreSection(element);setActive(id);onVisible(id);});};update();element.addEventListener('scroll',update,{passive:true});element.addEventListener('toggle',update,true);const observer=typeof ResizeObserver==='undefined'?undefined:new ResizeObserver(update);const content=element.querySelector('.world-entry-detail,.lore-article');if(content)observer?.observe(content);return()=>{cancelAnimationFrame(frame);element.removeEventListener('scroll',update);element.removeEventListener('toggle',update,true);observer?.disconnect();};},[context,sections.map(section=>section.id).join('|')]);
 if(!sections.length)return null;
 return <aside className={`lore-outline${reading?' lore-outline-editorial':''}`} data-open={open} onKeyDown={event=>{if(event.key==='Escape'&&open){event.preventDefault();setOpen(false);event.currentTarget.querySelector<HTMLButtonElement>('.lore-outline-toggle')?.focus();}}}><button type="button" className="lore-outline-toggle" aria-expanded={open} aria-controls="lore-outline-links" onClick={()=>setOpen(!open)}><List size={16}/>{t('Sections')}{open?<ChevronRight size={14}/>:<ChevronLeft size={14}/>}</button><div className="lore-outline-drawer"><SectionIndex id="lore-outline-links" hidden={!open} label={t('Entry sections')} sections={sections} active={active} onSelect={id=>{if(root.current&&revealLoreSection(root.current,id)){setActive(id);onVisible(id);}}}/></div></aside>;
}
