export function visibleChapterScene(scenes:{id:string;top:number;bottom:number}[],viewport:{top:number;height:number;atEnd:boolean}):string|undefined{
 if(!scenes.length)return;
 const visible=scenes.filter(scene=>scene.bottom>viewport.top&&scene.top<viewport.top+viewport.height);
 if(!visible.length)return;
 if(viewport.atEnd)return visible[visible.length-1].id;
 const line=viewport.top+Math.min(120,viewport.height*.25);
 return (visible.find(scene=>scene.top<=line&&scene.bottom>line)??visible.find(scene=>scene.top>line)??visible[visible.length-1]).id;
}
