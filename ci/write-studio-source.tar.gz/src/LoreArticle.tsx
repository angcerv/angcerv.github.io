import LoreContents from './LoreContents';
import {partnershipLabel} from './partnership';
import {VisualResourceDetails} from './VisualLibrary';
import {EntryStatuses} from './EntryEditorialControl';
import {EntryGallery} from './VisualLibrary';
import {ReferenceText} from './TextReferenceUI';
import EntryUsageSummary from './EntryUsageSummary';

import type {WorldIdea} from './worldIdeas';
import {ArrowLeft,ArrowUpRight,BookOpen} from 'lucide-react';
import {t} from './i18n';
import {loreGroups,loreSectionId,loreOverviewId,loreIntroduction,loreFieldLayout,loreArticleGroups} from './worldLore';
import {displayFieldValue,isEntryReference} from './worldbuilding';
import type {Worldbuilding,Entry} from './worldbuilding';
import type {EntryRelations} from './entryRelations';
import {entryConnections,connectionDateLabel,isFormerPartner} from './entryRelations';
import {LongTextView} from './LongTextEditor';
import {EntryPortrait} from './EntryImage';
import {ReferenceLink} from './EntryReference';


import type {Chapter} from './model';
export function LoreIndex({world,entries,onNavigate,onBack,canBack=false}:{world:Worldbuilding;entries:Entry[];onNavigate:(id:string)=>void;onBack?:()=>void;canBack?:boolean}){
 return <article className="lore-article lore-world-index">{canBack&&<button type="button" className="lore-back" onClick={onBack}><ArrowLeft size={15}/>{t('Back to previous article')}</button>}<h1><BookOpen size={24}/>{t('World index')}</h1><LoreContents world={world} entries={entries} onNavigate={onNavigate}/></article>;
}
export default function LoreArticle({onOpenLineage,worldIdeas,onOpenIdea,world,entry,relations,projectPath,projectId,chapters,onNavigate,onEdit,onBack,canBack,onOpenScene,onOpenMention}:{onOpenLineage?:(id:string)=>void;worldIdeas?:WorldIdea[];onOpenIdea?:(id:string)=>void;world:Worldbuilding;entry:Entry;relations:EntryRelations;projectPath?:string;projectId?:string;chapters:Chapter[];onNavigate:(id:string)=>void;onEdit:()=>void;onBack:()=>void;canBack:boolean;onOpenScene?:(id:string)=>void;onOpenMention?:(sceneId:string,range:{from:number;to:number})=>void}){
 const template=world.templates.find(template=>template.id===entry.templateId),groups=template?loreGroups(template,entry,true):[],connections=entryConnections(relations,entry.id),lineages=(relations.lineages??[]).filter(lineage=>lineage.memberIds.includes(entry.id));
 const mainResource=world.visualResources?.find(resource=>resource.id===entry.imageId);
 const introduction=template?loreIntroduction(template,entry):undefined;
 const bodyGroups=template?loreArticleGroups(template,entry):[];
 return <article className="lore-article" aria-label={t('Read entry')}>{canBack&&<button type="button" className="lore-back" onClick={onBack}><ArrowLeft size={15}/>{t('Back to previous article')}</button>}<header id={loreOverviewId} data-lore-section className={`lore-article-heading${entry.imageId?' has-image':''}`}><div className="lore-hero-copy"><p className="lore-category">{template?.title??t('Missing template')}{entry.archived&&<> · <span className="semantic-status" data-semantic-tone="neutral">{t('Archived')}</span></>}</p><h1>{entry.title||t('Untitled entry')}</h1><EntryStatuses entry={entry}/>{!!entry.linkAliases?.length&&<p className="lore-alias-summary">{t('Also known as')}: {entry.linkAliases.join(' · ')}</p>}</div>{entry.imageId&&<figure className="lore-hero-image"><EntryPortrait editorial projectPath={projectPath} projectId={projectId} imageId={entry.imageId} title={mainResource?.title??entry.title}/>{mainResource&&<figcaption>{mainResource.title!==entry.title&&<strong>{mainResource.title}</strong>}<VisualResourceDetails resource={mainResource} resources={world.visualResources??[]}/></figcaption>}</figure>}{introduction&&<div className="lore-introduction"><LongTextView value={entry.values[introduction.id] as string}/></div>}</header>
 {bodyGroups.map(group=><section key={group.id} id={loreSectionId(group.id)} data-lore-section className="lore-content-section"><h2>{group.title}</h2><dl>{group.fields.map(field=>{const value=entry.values[field.id];return <div key={field.id} className={`lore-data lore-data-${field.fieldType} lore-${loreFieldLayout(field,value)}`}><dt>{field.label||t('Untitled field')}</dt><dd>{isEntryReference(value)?<ReferenceLink world={world} reference={value} onNavigate={onNavigate} targetTemplateId={field.targetTemplateId}/>:field.fieldType==='longText'&&typeof value==='string'?<LongTextView value={value}/>:typeof value==='string'&&/^https?:\/\/\S+$/i.test(value)?<a href={value} target="_blank" rel="noopener noreferrer" className="lore-external-link">{value}<ArrowUpRight size={13}/><span className="visually-hidden">{t('External link')}</span></a>:typeof value==='string'&&field.fieldType==='shortText'?<ReferenceText value={value}/>:displayFieldValue(field,value,world)}</dd></div>;})}</dl></section>)}
 {!groups.length&&<div className="lore-empty"><p>{t('This entry has no filled fields yet.')}</p><button type="button" onClick={onEdit}>{t('Edit entry')}</button></div>}
 {!!entry.imageIds?.some(id=>id!==entry.imageId)&&<div id="lore-gallery" data-lore-section className="lore-content-section"><EntryGallery key={`gallery-${entry.id}`} readonly world={world} entry={entry} projectPath={projectPath} projectId={projectId}/></div>}
 <EntryUsageSummary appearanceId="lore-appearances" entryId={entry.id} world={world} chapters={chapters} ideas={worldIdeas} onOpenIdea={onOpenIdea} onOpenScene={onOpenScene} onOpenMention={onOpenMention}/>
 {(connections.length>0||lineages.length>0)&&<section id="lore-relations" data-lore-section className="lore-content-section"><h2>{t('Entry relationships')}</h2>{lineages.length>0&&<><h3>{t('Family lineages')}</h3><ul className="lore-connections">{lineages.map(lineage=><li key={lineage.id}>{onOpenLineage?<button type="button" onClick={()=>onOpenLineage(lineage.id)}>{lineage.name}</button>:lineage.name}</li>)}</ul></>}<ul className="lore-connections">{connections.map(({link,type,entryId,currentRole,relatedRole})=>{const target=world.entries.find(entry=>entry.id===entryId);return <li key={link.id}><span>{type.needsRoleReview?t('Roles pending review'):type.symmetric?(isFormerPartner(type,link)?t('Former partners'):currentRole):`${t('Role')}: ${currentRole} · ${relatedRole}`}: </span>{target?<button type="button" onClick={()=>onNavigate(target.id)}>{target.title||t('Untitled entry')}</button>:<span role="status" className="semantic-label" data-semantic-tone="error">{t('Missing entry')}</span>}{partnershipLabel(link)&&<small>{t(partnershipLabel(link)!)}</small>}{connectionDateLabel(link)&&<small>{connectionDateLabel(link)}</small>}</li>;})}</ul></section>}

 </article>;
}
