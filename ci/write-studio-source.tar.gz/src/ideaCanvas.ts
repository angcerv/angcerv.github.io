import type {Project} from './model';
import {saveWorldIdea} from './worldIdeas';
import {longTextPlainText} from './longText';
import {t} from './i18n';
import {visualResources} from './visualResources';

export type CanvasKind='note'|'group'|'entry'|'scene'|'event'|'idea'|'plot'|'image';
export type CanvasNode={id:string;kind:CanvasKind;x:number;y:number;width?:number;height?:number;title:string;text:string;targetId?:string;groupId?:string};
export type CanvasEdge={id:string;from:string;to:string;label:string};
export type IdeaCanvas={id:string;title:string;nodes:CanvasNode[];edges:CanvasEdge[]};
export type IdeaCanvases={schemaVersion:1|2;boards:IdeaCanvas[]};
export const emptyCanvases:IdeaCanvases={schemaVersion:1,boards:[]};
export const canvasWidth=6000,canvasHeight=4000,canvasCardWidth=240,canvasCardHeight=190;
export function canvasPosition(x:number,y:number){return {x:Math.max(0,Math.min(canvasWidth-canvasCardWidth,Math.round(x))),y:Math.max(0,Math.min(canvasHeight-canvasCardHeight,Math.round(y)))};}
export function saveCanvas(project:Project,board:IdeaCanvas):Project{
 board=fitCanvasGroups(board);
 const data=project.ideaCanvases??emptyCanvases;
 return {...project,ideaCanvases:{...data,schemaVersion:board.nodes.some(node=>node.width!==undefined||node.height!==undefined)?2:data.schemaVersion,boards:data.boards.some(item=>item.id===board.id)?data.boards.map(item=>item.id===board.id?board:item):[...data.boards,board]}};
}
export function removeCanvasNode(board:IdeaCanvas,id:string):IdeaCanvas{
 return {...board,nodes:board.nodes.filter(node=>node.id!==id).map(node=>node.groupId===id?{...node,groupId:undefined}:node),edges:board.edges.filter(edge=>edge.from!==id&&edge.to!==id)};
}
export function canvasNodeSize(node:CanvasNode){
 return {width:node.width??(node.kind==='group'?320:canvasCardWidth),height:node.height??(node.kind==='group'?240:canvasCardHeight)};
}
export function canvasGroupBounds(board:IdeaCanvas,node:CanvasNode){
 const size=canvasNodeSize(node);
 const members=board.nodes.filter(item=>item.groupId===node.id);
 const x=Math.max(0,Math.min(node.x,...members.map(item=>item.x-16)));
 const y=Math.max(0,Math.min(node.y,...members.map(item=>item.y-48)));
 const right=Math.min(canvasWidth,Math.max(node.x+size.width,...members.map(item=>item.x+canvasNodeSize(item).width+16)));
 const bottom=Math.min(canvasHeight,Math.max(node.y+size.height,...members.map(item=>item.y+canvasNodeSize(item).height+16)));
 return {x,y,width:right-x,height:bottom-y};
}
/** Explicit frames expand with their members; membership never follows geometry. */
export function fitCanvasGroups(board:IdeaCanvas):IdeaCanvas{
 let changed=false;
 const nodes=board.nodes.map(node=>{
  if(node.kind!=='group'||node.width===undefined&&node.height===undefined)return node;
  const bounds=canvasGroupBounds(board,node);
  if(bounds.x===node.x&&bounds.y===node.y&&bounds.width===node.width&&bounds.height===node.height)return node;
  changed=true;return {...node,...bounds};
 });
 return changed?{...board,nodes}:board;
}
export function canvasResizeMinimum(board:IdeaCanvas,node:CanvasNode){
 const minimum=canvasNodeSize({...node,width:undefined,height:undefined});
 if(node.kind!=='group')return minimum;
 const bounds=canvasGroupBounds(board,node),members=board.nodes.filter(item=>item.groupId===node.id);
 return {width:Math.min(canvasWidth-bounds.x,Math.max(minimum.width,...members.map(item=>item.x+canvasNodeSize(item).width+16-bounds.x))),height:Math.min(canvasHeight-bounds.y,Math.max(minimum.height,...members.map(item=>item.y+canvasNodeSize(item).height+16-bounds.y)))};
}
export function canvasNodeBounds(board:IdeaCanvas,node:CanvasNode){
 return node.kind==='group'?canvasGroupBounds(board,node):{x:node.x,y:node.y,...canvasNodeSize(node)};
}
export function moveCanvasNode(board:IdeaCanvas,id:string,x:number,y:number):IdeaCanvas{
 const node=board.nodes.find(node=>node.id===id);if(!node)return board;
 const moving=board.nodes.filter(item=>item.id===id||node.kind==='group'&&item.groupId===id);
 const bounds=moving.map(item=>canvasNodeBounds(board,item));
 const dx=Math.max(-Math.min(...bounds.map(item=>item.x)),Math.min(x-node.x,canvasWidth-Math.max(...bounds.map(item=>item.x+item.width))));
 const dy=Math.max(-Math.min(...bounds.map(item=>item.y)),Math.min(y-node.y,canvasHeight-Math.max(...bounds.map(item=>item.y+item.height))));
 return fitCanvasGroups({...board,nodes:board.nodes.map(item=>moving.includes(item)?{...item,x:Math.round(item.x+dx),y:Math.round(item.y+dy)}:item)});
}
export function resizeCanvasNode(board:IdeaCanvas,id:string,width:number,height:number):IdeaCanvas{
 const node=board.nodes.find(node=>node.id===id);if(!node||!Number.isFinite(width)||!Number.isFinite(height))return board;
 const bounds=canvasNodeBounds(board,node),minimum=canvasResizeMinimum(board,node);
 const size={width:Math.round(Math.max(Math.min(minimum.width,canvasWidth-bounds.x),Math.min(width,canvasWidth-bounds.x))),height:Math.round(Math.max(Math.min(minimum.height,canvasHeight-bounds.y),Math.min(height,canvasHeight-bounds.y)))};
 return fitCanvasGroups({...board,nodes:board.nodes.map(item=>item.id===id?{...item,x:bounds.x,y:bounds.y,...size}:item)});
}
export function resetCanvasNodeSize(board:IdeaCanvas,id:string):IdeaCanvas{
 return {...board,nodes:board.nodes.map(node=>{
  if(node.id!==id)return node;
  const {width:unusedWidth,height:unusedHeight,...rest}=node;return rest;
 })};
}

export function canvasTarget(project:Project,node:CanvasNode):{title:string;text:string;missing:boolean}{
 if(node.kind==='note'||node.kind==='group')return {title:node.title,text:node.text,missing:false};
 const id=node.targetId;
 if(node.kind==='entry'){const entry=project.worldbuilding?.entries.find(item=>item.id===id),template=project.worldbuilding?.templates.find(item=>item.id===entry?.templateId);const field=template?.fields.find(field=>!field.archived&&field.fieldType==='longText'&&typeof entry?.values[field.id]==='string'&&String(entry.values[field.id]).trim());return {title:entry?.title??t('Missing entry'),text:field?String(entry?.values[field.id]??''):'',missing:!entry};}
 if(node.kind==='scene'){const scene=project.chapters.flatMap(chapter=>chapter.scenes).find(item=>item.id===id);return {title:scene?.title??t('Missing scene'),text:scene?.synopsis??'',missing:!scene};}
 if(node.kind==='event'){const event=project.timeline?.events.find(item=>item.id===id);return {title:event?.title??t('Missing source'),text:event?.notes??'',missing:!event};}
 if(node.kind==='idea'){const idea=project.worldIdeas?.find(item=>item.id===id);return {title:idea?.title??t('Missing source'),text:idea?.decision??idea?.description??'',missing:!idea};}
 if(node.kind==='plot'){const plot=project.plots?.threads.find(item=>item.id===id);return {title:plot?.title??t('Missing plot'),text:plot?.notes??'',missing:!plot};}
 const image=project.worldbuilding?visualResources(project.worldbuilding).find(item=>item.id===id):undefined;
 return {title:image?.title??t('Missing image'),text:image?.caption??'',missing:!image};
}
export function canvasExcerpt(text:string,limit=350){return longTextPlainText(text).slice(0,limit);}
export function convertCanvasNote(project:Project,boardId:string,nodeId:string,kind:'idea'|'entry',templateId?:string):Project{
 const board=project.ideaCanvases?.boards.find(item=>item.id===boardId),node=board?.nodes.find(item=>item.id===nodeId);
 if(!board||!node||node.kind!=='note'||!node.title.trim())return project;
 const id=crypto.randomUUID();let next=project;
 if(kind==='idea')next=saveWorldIdea(project,{id,title:node.title,description:node.text,status:'idea',category:'narrative',entryIds:[],sceneIds:[],plotIds:[]});
 else{
  const world=project.worldbuilding,template=world?.templates.find(item=>item.id===templateId),field=template?.fields.find(item=>!item.archived&&item.fieldType==='longText');
  if(!world||!template||!field)return project;
  next={...project,worldbuilding:{...world,entries:[...world.entries,{id,schemaVersion:world.schemaVersion,templateId:template.id,title:node.title.trim(),archived:false,values:{[field.id]:node.text}}]}};
 }
 return saveCanvas(next,{...board,nodes:board.nodes.map(item=>item.id===nodeId?{...item,kind,targetId:id,title:'',text:''}:item)});
}

export function nextCanvasPosition(board:IdeaCanvas,origin:{x:number;y:number}){
 for(let row=0;row<20;row++)for(let col=0;col<20;col++){
  const point=canvasPosition(origin.x+col*280,origin.y+row*220);
  if(!board.nodes.some(node=>node.x<point.x+260&&node.x+canvasNodeSize(node).width+20>point.x&&node.y<point.y+210&&node.y+canvasNodeSize(node).height+20>point.y))return point;
 }
 return canvasPosition(origin.x,origin.y);
}
export function canvasEdgePoints(from:CanvasNode,to:CanvasNode,board?:IdeaCanvas){
 const bounds=(node:CanvasNode)=>board?canvasNodeBounds(board,node):{x:node.x,y:node.y,...canvasNodeSize(node)};
 const source=bounds(from),target=bounds(to);
 const a={x:source.x+source.width/2,y:source.y+source.height/2},b={x:target.x+target.width/2,y:target.y+target.height/2};
 const dx=b.x-a.x,dy=b.y-a.y;
 const port=(center:{x:number;y:number},size:{width:number;height:number},sign:number)=>{
  const distance=Math.max(Math.abs(dx)/(size.width/2+4),Math.abs(dy)/(size.height/2+4));
  if(!distance)return center;
  return {x:center.x+sign*dx/distance,y:center.y+sign*dy/distance};
 };
 return {from:port(a,source,1),to:port(b,target,-1),label:{x:(a.x+b.x)/2,y:(a.y+b.y)/2}};
}
