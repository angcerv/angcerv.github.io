import {useContext} from 'react';
import {ArrowUpRight} from 'lucide-react';
import {TextReferenceContext} from './textReferenceContext';
import type {TextReferenceSource} from './textReferenceIndex';
import {t} from './i18n';
export default function TextReferenceBacklinks({entryId,sources:provided,showHeading=true,onOpen,disabled=false,isSourceDisabled}:{entryId:string;sources?:TextReferenceSource[];showHeading?:boolean;onOpen?:(source:TextReferenceSource)=>void;disabled?:boolean;isSourceDisabled?:(source:TextReferenceSource)=>boolean}){
 const context=useContext(TextReferenceContext);
 if(!context&&!provided)return null;
 const sources=provided??context!.index.filter(source=>source.entryId===entryId&&!(source.kind==='entry'&&source.id===entryId)),open=onOpen??context?.openSource;
 return <section className="text-reference-backlinks" aria-label={t('Where this entry is used')}>{showHeading&&<h3>{t('Where this entry is used')} <span>{sources.length}</span></h3>}{!sources.length&&<p>{t('No text references yet.')}</p>}{sources.map((source,index)=><button type="button" key={`${source.kind}:${source.id}:${source.field}:${index}`} disabled={disabled||!open||isSourceDisabled?.(source)} onClick={()=>open?.(source)}><span><strong>{source.label}</strong><small>{source.field} · {source.count}</small>{source.excerpt&&<span>{source.excerpt}</span>}</span><ArrowUpRight size={14}/></button>)}</section>;
}
