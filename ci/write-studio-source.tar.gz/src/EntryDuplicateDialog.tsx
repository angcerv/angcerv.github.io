import {focusDialog} from './dialogFocus';
import { useEffect, useRef, useState } from 'react';
import { createPortal } from 'react-dom';
import { X } from 'lucide-react';
import { t } from './i18n';
import { entryCopyName } from './worldbuilding';
import type { Entry, Worldbuilding } from './worldbuilding';

export default function EntryDuplicateDialog({world,entry,onSave,onCancel}:{world:Worldbuilding;entry:Entry;onSave:(title:string,copyAliases:boolean)=>void;onCancel:()=>void}){
 const dialog=useRef<HTMLDialogElement>(null),input=useRef<HTMLInputElement>(null),previous=useRef(typeof document==='undefined'?null:document.activeElement as HTMLElement|null);
 const [title,setTitle]=useState(()=>entryCopyName(world,entry)),[copyAliases,setCopyAliases]=useState(false);
 useEffect(()=>{const node=dialog.current;node?.showModal();focusDialog(node);return()=>{node?.close();if(previous.current?.isConnected)previous.current.focus();};},[]);
 const content=<dialog ref={dialog} className="field-create-dialog" aria-labelledby="duplicate-entry-title" onCancel={event=>{event.preventDefault();onCancel();}}>
  <header><h2 id="duplicate-entry-title">{t('Duplicate entry')}</h2><button title={t("Close")} type="button" className="icon-button ui-close-button" aria-label={t('Close')} onClick={onCancel}><X size={18}/></button></header>
  <form onSubmit={event=>{event.preventDefault();if(title.trim())onSave(title.trim(),copyAliases);}}><div className="field-create-body"><p className="field-create-hint">{t('Copy of “{0}”',entry.title||t('Untitled entry'))}</p><label htmlFor="duplicate-entry-name">{t('Entry name')}</label><input id="duplicate-entry-name" ref={input} required value={title} onChange={event=>setTitle(event.target.value)}/><p className="field-create-hint">{t('Copies all field values and the main image. Existing scene, map and timeline links stay with the original.')}</p>
  {!!entry.linkAliases?.length&&<label className="duplicate-entry-aliases"><input type="checkbox" checked={copyAliases} onChange={event=>setCopyAliases(event.target.checked)}/><span>{t('Copy link aliases (may create ambiguous mentions)')}</span></label>}
  </div><footer><button type="button" className="field-cancel-button quick-action quick-action-text" onClick={onCancel}>{t('Cancel')}</button><button type="submit" className="primary-button" disabled={!title.trim()}>{t('Create copy')}</button></footer></form>
 </dialog>;
 return typeof document==='undefined'?content:createPortal(content,document.body);
}
