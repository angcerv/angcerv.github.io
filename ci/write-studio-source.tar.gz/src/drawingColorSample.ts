import {drawingSvg} from './mapDrawing';
import type {MapDrawing} from './mapDrawing';
import type {MapLayer} from './maps';
import {t} from './i18n';

/** Sample artwork only, independently of camera, selection handles and editor chrome. */
export async function sampleDrawingColor(drawing:MapDrawing,layers:MapLayer[],source:string,point:{x:number;y:number},signal:AbortSignal):Promise<string|undefined>{
 const canvas=document.createElement('canvas');canvas.width=1;canvas.height=1;
 const context=canvas.getContext('2d',{willReadFrequently:true});
 if(!context)throw new Error(t('Image processing is unavailable.'));
 const images:HTMLImageElement[]=[];
 const abort=()=>{for(const image of images)image.src='';};signal.addEventListener('abort',abort,{once:true});
 async function paint(url:string){
  if(signal.aborted)return;
  const image=new Image();images.push(image);image.src=url;await image.decode();
  if(signal.aborted)return;
  const x=Math.min(image.naturalWidth-1,Math.max(0,Math.floor(point.x*image.naturalWidth)));
  const y=Math.min(image.naturalHeight-1,Math.max(0,Math.floor(point.y*image.naturalHeight)));
  context!.drawImage(image,x,y,1,1,0,0,1,1);
 }
 try{
  if(source&&!drawing.background)await paint(source);
  await paint(`data:image/svg+xml;charset=utf-8,${encodeURIComponent(drawingSvg(drawing,true,layers))}`);
  if(signal.aborted)return;
  const [r,g,b,a]=context.getImageData(0,0,1,1).data;
  if(!a)throw new Error(t('There is no color at this point.'));
  return '#'+[r,g,b].map(value=>value.toString(16).padStart(2,'0')).join('');
 }catch(error){if(!signal.aborted)throw error;}
 finally{signal.removeEventListener('abort',abort);abort();canvas.width=0;canvas.height=0;}
}
