import {longTextPlainText} from './longText';
import type { WorldIdea } from './worldIdeas';
import { ideaStatusLabels,ideaCategory,ideaCategoryLabels } from './worldIdeas';
import type { Project } from './model';
import type { ReviewComment } from './reviewComments';
import type { ContinuityIssue } from './continuity';
import {continuityEvidence,loadContinuityDismissals} from './narrativeContinuity';
import { reviewContinuity } from './continuity';
import { getSceneStatus } from './model';
import { countSceneWords } from './writingGoals';
import { t } from './i18n';
export type PendingKind='comment'|'continuity'|'review'|'develop'|'idea'|'narrative';
export type PendingItem={createdAt?:string;updatedAt?:string;id:string;kind:PendingKind;title:string;context:string;relatedContext?:string;detail:string;chapterIds?:string[];chapterId?:string;sceneId?:string;comment?:ReviewComment;issue?:ContinuityIssue;idea?:WorldIdea};
export function projectPendingItems(project:Project,scope:'all'|'ideas'|'review'='all'):PendingItem[]{
 const items:PendingItem[]=[],chapters=new Map<string,string>();
 for(const chapter of project.chapters)for(const scene of chapter.scenes){
  chapters.set(scene.id,chapter.id);
  if(scope==='ideas')continue;
  const context=`${chapter.title||t('Untitled chapter')} / ${scene.title||t('Untitled scene')}`;
  for(const comment of scene.reviewComments??[])if(!comment.resolved)items.push({id:`comment:${comment.id}`,kind:'comment',title:comment.text,context,detail:comment.quote,chapterId:chapter.id,sceneId:scene.id,comment});
  const status=getSceneStatus(scene);
  if(status==='inReview')items.push({id:`review:${scene.id}`,kind:'review',title:scene.title||t('Untitled scene'),context,detail:t('This scene is marked In review.'),chapterId:chapter.id,sceneId:scene.id});
  if(status!=='finished'){
   const noText=countSceneWords(scene.content)===0,noSynopsis=!scene.synopsis?.trim();
   if(noText||noSynopsis)items.push({id:`develop:${scene.id}`,kind:'develop',title:scene.title||t('Untitled scene'),context,detail:noText&&noSynopsis?t('No text or synopsis yet.'):noText?t('No text yet.'):t('No synopsis yet'),chapterId:chapter.id,sceneId:scene.id});
  }
 }
 if(scope!=='ideas'){
 const dismissed=loadContinuityDismissals(project.id);
 for(const issue of reviewContinuity(project))if(issue.kind!=='unused'&&dismissed[issue.id]!==continuityEvidence(project,issue))items.push({id:`continuity:${issue.id}`,kind:'continuity',title:issue.title,context:issue.context,detail:issue.excerpt??(issue.kind==='ambiguous'?t('Ambiguous mentions'):t('Broken links')),chapterId:issue.sceneId?chapters.get(issue.sceneId):undefined,sceneId:issue.sceneId,issue});
 }
 if(scope!=='review')for(const idea of project.worldIdeas??[]){
  const sceneIds=new Set([...(idea.sceneIds??[]),...(project.plots?.threads.filter(plot=>idea.plotIds?.includes(plot.id)).flatMap(plot=>plot.beats.map(beat=>beat.sceneId))??[])]);
  const chapterIds=[...new Set([...sceneIds].flatMap(id=>chapters.has(id)?[chapters.get(id)!]:[]))];
  const sceneNames=(idea.sceneIds??[]).map(id=>{const chapter=project.chapters.find(c=>c.scenes.some(s=>s.id===id)),scene=chapter?.scenes.find(s=>s.id===id);return scene?`${chapter!.title} / ${scene.title}`:t('Deleted scene');});
  const relatedContext=[...idea.entryIds.map(id=>project.worldbuilding?.entries.find(e=>e.id===id)?.title??t('Deleted entry')),...sceneNames,...(idea.plotIds??[]).map(id=>project.plots?.threads.find(plot=>plot.id===id)?.title??t('Deleted plot'))].join(' · ');
  items.push({id:`idea:${idea.id}`,kind:ideaCategory(idea)==='narrative'?'narrative':'idea',title:idea.title,detail:[longTextPlainText(idea.description),...(idea.decision?[t('Decision taken')+': '+longTextPlainText(idea.decision)]:[]),...(idea.fragments??[]).map(fragment=>fragment.quote)].join('\n\n'),relatedContext,context:[t(ideaCategoryLabels[ideaCategory(idea)]),t(ideaStatusLabels[idea.status]),relatedContext].filter(Boolean).join(' · '),idea,chapterIds});
 }

 return items.map(item=>({...item,...(item.idea?{createdAt:item.idea.createdAt,updatedAt:item.idea.updatedAt}:project.pendingDates?.[item.id])}));
}
export function filterPendingItems(items:PendingItem[],kind:PendingKind|'all',chapterId:string,query:string,ideaStatus:string='active'):PendingItem[]{
 const needle=query.trim().toLocaleLowerCase();return items.filter(item=>(kind==='all'||item.kind===kind)&&(!item.idea||ideaStatus==='all'||(ideaStatus==='active'?['idea','deciding','decided'].includes(item.idea.status):item.idea.status===ideaStatus))&&(!chapterId||(chapterId==='__project'?(!item.chapterId&&!item.chapterIds?.length):item.chapterId===chapterId||!!item.chapterIds?.includes(chapterId)))&&(!needle||[item.title,item.context,item.detail].some(value=>value.toLocaleLowerCase().includes(needle))));
}

export type PendingOrder='default'|'created-newest'|'created-oldest'|'updated-newest'|'updated-oldest'|'title-asc'|'title-desc';
export function sortPendingItems(items:PendingItem[],order:PendingOrder,language:string):PendingItem[]{
 if(order==='default')return items;
 const collator=new Intl.Collator(language,{numeric:true,sensitivity:'base'});
 return [...items].sort((a,b)=>{
  if(order==='title-asc'||order==='title-desc')return collator.compare(a.title,b.title)*(order==='title-desc'?-1:1);
  const field=order.startsWith('created-')?'createdAt':'updatedAt';
  const left=Date.parse(a[field]??a.idea?.[field]??''),right=Date.parse(b[field]??b.idea?.[field]??'');
  if(!Number.isFinite(left))return Number.isFinite(right)?1:0;
  if(!Number.isFinite(right))return -1;
  return (left-right)*(order.endsWith('newest')?-1:1);
 });
}
