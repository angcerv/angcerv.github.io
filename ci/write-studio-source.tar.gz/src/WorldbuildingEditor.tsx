import {createPortal} from 'react-dom';
import type {WorldHeaderSlot} from './WorldWorkspace';
import type {IdeaCanvases} from './ideaCanvas';
import ProjectModal from './ProjectModal';
import RelationshipOptions from './RelationshipOptions';
import type {WorldView} from './worldSavedAccess';
import {worldBrowserHeight} from './worldBrowserLayout';
import LoreContents from './LoreContents';
import WorldNavigation from './WorldNavigation';
import type {WorldSection} from './WorldNavigation';
import type {FragmentRequest} from './decisionFragments';
import {statusTone} from './semanticStatus';
import EntryEditorial,{EntryStatuses} from './EntryEditorialControl';
import {editorialLabels,matchesEditorial,canonLabels,matchesCanon} from './entryEditorial';
import WorldSavedAccess,{useWorldSavedAccess} from './WorldSavedShortcuts';
import VisualLibrary,{EntryGallery} from './VisualLibrary';
import {normalizeOptionText} from './dropdownNavigation';
import PanelResize from './PanelResize';
import {browserWidthMinimum,browserWidthMaximum,readBrowserWidth,rememberBrowserWidth,clampBrowserWidth} from './worldBrowserPreferences';
import type {CSSProperties} from 'react';
import {isWorkspaceRestoring} from './workspaceNavigation';
import {useWorkspaceState} from './useWorkspaceState';
import EntryUsageSummary from './EntryUsageSummary';

import type {WorldIdea} from './worldIdeas';
import {readEntryOrder,rememberEntryOrder,sortEntries} from './entryOrdering';
import type {EntryOrder} from './entryOrdering';
import {entryAppearances} from './entryAppearanceIndex';
import LoreArticle,{LoreIndex} from './LoreArticle';
import LoreOutline from './LoreOutline';
import {loreGroups,loreArticleGroups,loreSectionId,loreOverviewId,loreModeTarget,prepareLoreNavigation,revealLoreSection} from './worldLore';
import {birthDateField} from './ages';
import Genealogy from './Genealogy';
import RelationNetwork from './RelationNetwork';
import type {ProjectPlots} from './plotThreads';
import RelationshipLibrary,{TemplateRelationships} from './RelationshipLibrary';
import {emptyEntryRelations} from './entryRelations';
import LongTextEditor from './LongTextEditor';
import ShortTextEditor from './ShortTextEditor';
import {convertToLongText} from './worldbuilding';
import EntryRelationsPanel from './EntryRelationsPanel';
import type {EntryRelations} from './entryRelations';
import EntryTransferDialog from './EntryTransferDialog';
import type {EntryPackage} from './entryTransfer';
import { entryTemplateGlyph } from './entryTemplateGlyph';
import EntryDuplicateDialog from './EntryDuplicateDialog';
import EntryCreateDialog from './EntryCreateDialog';
import FieldHelp from './FieldHelp';

import EntryLinkAliases from './EntryLinkAliases';
import EntrySection from './EntrySection';
import { fieldGroups } from './templateSections';
import StoryDateInput from './StoryDateInput';
import EntryAgePreview from './EntryAge';
import { isStoryDate } from './ages';
import TemplateImportDialog from './TemplateImportDialog';
import { importTemplates } from './templateTransfer';
import type { TemplatePackage } from './templateTransfer';
import type { RecentProject } from './storage';
import {t,buttonLabel} from './i18n';
import { PicklistInput } from './PicklistFields';
import { isPicklist, displayFieldValue } from './worldbuilding';
import {  } from './maps';
import type { ProjectMaps } from './maps';
import { EntryThumbnail } from './EntryImage';
import type { Timeline } from './timeline';
import type { Chapter } from './model';
import Dropdown from './Dropdown';
import { useEffect, useRef, useState } from 'react';
import TemplateFields from './TemplateFields';
import { Check,ArrowDownAZ,ArrowUpAZ,ArrowDownWideNarrow,ArrowUpWideNarrow,Bookmark, Archive, Plus, Trash2, Download, Upload, Copy, SlidersHorizontal, X, History, Network, GitBranch, PanelLeft, BookOpen, MoreHorizontal } from 'lucide-react';
import { addEntry, duplicateEntry, addTemplate, searchEntries, updateEntry, updateTemplate, isEntryReference, deleteEntry, deleteTemplate, templateEntryCount } from './worldbuilding';
import type { Entry, EntryValue, Worldbuilding } from './worldbuilding';
import ActionMenu from './ActionMenu';
import WorldDeletionDialog from './WorldDeletionDialog';
import EntryReferencePicker, { ReferenceLink } from './EntryReference';

function EntryFields({ focusFragment,world, entry, onChange, onNavigate }: { focusFragment?:FragmentRequest;world: Worldbuilding; entry: Entry; onChange: (world: Worldbuilding) => void; onNavigate: (id: string) => void }) {
  const template = world.templates.find(t => t.id === entry.templateId);
  if (!template) return null;
  const setValue = (fieldId: string, value: EntryValue) => onChange(updateEntry(world, { ...entry, values: { ...entry.values, [fieldId]: value } }));
  const archived = template.fields.filter(field => field.archived);
  return <div className="world-entry-sections">{fieldGroups(template,true).filter(group=>group.fields.length).map(group=><EntrySection key={group.id} id={loreSectionId(group.id)} title={group.title} count={group.fields.length}><div className="world-entry-fields">{group.fields.map(field => {
    const value = entry.values[field.id];
    const id = `world-value-${entry.id}-${field.id}`;
    return <div key={field.id} className={`world-field field-${field.fieldType}`}><div className="entry-field-label"><label id={`${id}-label`} htmlFor={id}>{field.label || t("Untitled field")}</label><FieldHelp label={field.label||t("Untitled field")} description={field.description}/></div>
      {field.fieldType==='date'?<StoryDateInput id={id} value={isStoryDate(value)?value:undefined} onChange={date=>setValue(field.id,date)}/>:isPicklist(field.fieldType) ? <PicklistInput field={field} value={value} id={id} onChange={next=>setValue(field.id,next)}/> : field.fieldType === 'reference' ? <EntryReferencePicker id={id} label={field.label} world={world} reference={isEntryReference(value) ? value : null} targetTemplateId={field.targetTemplateId} onChange={next => setValue(field.id, next)} onNavigate={onNavigate} />
      : field.fieldType === 'longText' ? <LongTextEditor focusFragment={focusFragment?.fragment.fieldId===field.id?focusFragment:undefined} key={id} id={id} value={typeof value === 'string' ? value : ''} onChange={value => setValue(field.id, value)} />
      : field.fieldType === 'boolean' ? <input id={id} type="checkbox" checked={value === true} onChange={event => setValue(field.id, event.target.checked)} />
      : field.fieldType === 'number' ? <input id={id} type="number" step="any" value={typeof value === 'number' ? value : ''} onChange={event => { const number = event.target.valueAsNumber; setValue(field.id, Number.isFinite(number) ? number : null); }} />
      : <ShortTextEditor focusFragment={focusFragment?.fragment.fieldId===field.id?focusFragment:undefined} id={id} value={typeof value === 'string' ? value : ''} onChange={value=>setValue(field.id,value)} onConvert={()=>onChange(convertToLongText(world,template.id,field.id))} />}
    </div>;
  })}</div></EntrySection>)}{!template.fields.some(field => !field.archived) && <p className="world-hint">{t("Add fields in Templates to describe this entry.")}</p>}
    {archived.length > 0 && <details className="archived-values"><summary>{t("Archived fields (")}{archived.length})</summary>{archived.map(field => { const value = entry.values[field.id]; return <div key={field.id}><div className="entry-field-label"><strong>{field.label || t("Untitled field")}</strong><FieldHelp label={field.label||t("Untitled field")} description={field.description}/></div><p>{isEntryReference(value) ? <ReferenceLink world={world} reference={value} onNavigate={onNavigate} targetTemplateId={field.targetTemplateId} /> : value === undefined || value === null ? t("Empty") : displayFieldValue(field,value,world)}</p></div>; })}</details>}
  </div>;
}
export default function WorldbuildingEditor({ sectionRequest,onSectionRequestHandled,headerSlot,ideaCanvases,onResourcesChange,onMapsChange,onOpenMaps,onWorkspaceChange,onEntryHistory,fragmentRequest,onImportVisualResource,onRequestEntryExport,templateRequest,worldIdeas,onOpenIdea,saveState,onRetrySave,plots,entryRelations,onRelationsChange, onLoadEntries,onExportEntries,onImportEntries, onLoadTemplates, onExportTemplates, recentProjects, transferError, maps, onImportEntryImage, projectPath, projectId, world, onChange, timeline, chapters = [], onOpenScene, onOpenMention, tab, setTab, entryId, setEntryId, openRequest = 0 }: { sectionRequest?:{section:WorldSection;token:number};onSectionRequestHandled?:(token:number)=>void;headerSlot?:WorldHeaderSlot;ideaCanvases?:IdeaCanvases;onResourcesChange?:(world:Worldbuilding,maps?:ProjectMaps)=>void;onMapsChange?:(maps:ProjectMaps)=>void;onOpenMaps?:()=>void;onWorkspaceChange?:()=>void;onEntryHistory?:(id:string)=>void;fragmentRequest?:FragmentRequest;onImportVisualResource?:()=>Promise<string|null>;onRequestEntryExport?:(id:string)=>void;templateRequest?:{id:string;token:number};worldIdeas?:WorldIdea[];onOpenIdea?:(id:string)=>void;saveState?:{dirty:boolean;busy:boolean;error:string};onRetrySave?:()=>Promise<boolean>;plots?:ProjectPlots;entryRelations?:EntryRelations;onRelationsChange?:(relations:EntryRelations)=>void; onLoadEntries?:()=>Promise<EntryPackage|null>;onExportEntries?:(ids:string[])=>Promise<boolean>;onImportEntries?:(packet:EntryPackage,ids:string[])=>Promise<boolean>; onLoadTemplates?:(source:'file'|'project',path?:string)=>Promise<TemplatePackage|null>; onExportTemplates?:(ids:string[],all?:boolean)=>Promise<void>; recentProjects?:RecentProject[]; transferError?:string; maps?:ProjectMaps; onOpenMap?:(mapId:string,markerId:string)=>void; onImportEntryImage?:(entryId:string)=>Promise<void>; projectPath?: string; projectId?: string; timeline?: Timeline; chapters?: Chapter[]; onOpenScene?: (id: string) => void;onOpenMention?:(sceneId:string,range:{from:number;to:number})=>void; world: Worldbuilding; onChange: (world: Worldbuilding) => void; onReturn: () => void; tab: 'entries' | 'templates'; setTab: (tab: 'entries' | 'templates') => void; entryId: string; setEntryId: (id: string) => void; openRequest?: number }) {
  useEffect(()=>{if(fragmentRequest){setReading(false);setBrowserOpen(false);}},[fragmentRequest]);
  const savedAccess=useWorldSavedAccess(projectId||projectPath||'');
  const [duplicating,setDuplicating]=useState('');
  const [importingTemplates,setImportingTemplates]=useState(false);
  const [transferNotice,setTransferNotice]=useState('');
  const contentRef = useRef<HTMLDivElement>(null);
  const templateChoices=[...world.templates].sort((a,b)=>a.title.localeCompare(b.title,undefined,{numeric:true,sensitivity:'base'}));
  const [deleting, setDeleting] = useState<{ kind: 'entry' | 'template'; id: string } | null>(null);
  const [templateId, setTemplateId] = useWorkspaceState('world.templateId','');
  const [templateQuery, setTemplateQuery] = useWorkspaceState('world.templateQuery','');
  const matchingTemplates=templateChoices.filter(item=>normalizeOptionText(item.title).includes(normalizeOptionText(templateQuery.trim())));
  const [filter, setFilter] = useWorkspaceState('world.filter','');
  const [query, setQuery] = useWorkspaceState('world.query','');
  const [favoritesOnly,setFavoritesOnly]=useWorkspaceState('world.favoritesOnly',false);
  const [canonFilter,setCanonFilter]=useWorkspaceState('world.canonFilter','');
  const [editorialFilter,setEditorialFilter]=useWorkspaceState('world.editorialFilter','');
  const [showArchived, setShowArchived] = useWorkspaceState('world.showArchived',false);
  const templateCounts=new Map<string,number>();
  for(const item of world.entries)if(item.archived===showArchived)templateCounts.set(item.templateId,(templateCounts.get(item.templateId)??0)+1);
  const [templateBrowserOpen,setTemplateBrowserOpen]=useWorkspaceState('world.templateBrowserOpen',true);
  const [discardTemplate,setDiscardTemplate]=useState(false);
  function closeTemplateCreate(){if(name.trim())setDiscardTemplate(true);else setCreating(null);}
  function compactBrowser(){return (contentRef.current?.closest('.world-workspace')?.clientWidth??contentRef.current?.clientWidth??Infinity)<=700;}
  function focusDetail(selector:string){requestAnimationFrame(()=>{const target=contentRef.current?.querySelector<HTMLElement>(selector);if(target){target.tabIndex=-1;target.focus({preventScroll:true});}});}
  function selectTemplate(id:string){setTemplateId(id);setCreating(null);setTemplateBrowserOpen(false);if(compactBrowser())focusDetail('.world-template-detail');}
  const [creating, setCreating] = useState<'template' | 'entry' | null>(null);
  const [name, setName] = useState('');
  const [entryTemplateId, setEntryTemplateId] = useState('');
  const template = world.templates.find(item => item.id === templateId) ?? world.templates[0];
  const entry = world.entries.find(item => item.id === entryId);
  const effectiveFilter=world.templates.some(item=>item.id===filter)?filter:'';
  const filteredEntries = searchEntries(world, query, effectiveFilter, showArchived, 'name').filter(item=>matchesEditorial(item,editorialFilter)&&matchesCanon(item,canonFilter)&&(!favoritesOnly||savedAccess.saved.entries.includes(item.id)));
  const additionalFilterCount=Number(showArchived)+Number(!!editorialFilter)+Number(!!canonFilter)+Number(favoritesOnly);
  const scopeTotal=world.entries.filter(item=>item.archived===showArchived&&(!effectiveFilter||item.templateId===effectiveFilter)).length;
  const entryOrderLabels:Record<EntryOrder,string>={alphabetical:'Name: A–Z',reverseAlphabetical:'Name: Z–A',recentlyModified:'Recently modified',oldestModified:'Oldest modifications first'};
  function changeAdditionalFilters(patch:Partial<Pick<WorldView,'archived'|'editorial'|'canon'|'favoritesOnly'>>){
    if(!canNavigate())return;
    if(patch.archived!==undefined)setShowArchived(patch.archived);
    if(patch.editorial!==undefined)setEditorialFilter(patch.editorial);
    if(patch.canon!==undefined)setCanonFilter(patch.canon);
    if(patch.favoritesOnly!==undefined)setFavoritesOnly(patch.favoritesOnly);
    setEntryId('');
  }
  const duplicateSource=world.entries.find(item=>item.id===duplicating);
  useEffect(() => { if (contentRef.current) contentRef.current.scrollTop = 0; }, [tab, entryId, template?.id]);
  // Explicit navigation from the reference pane reveals the chosen entry in the list.
  useEffect(() => { if (openRequest&&!isWorkspaceRestoring()) { setResourcesOpen(false);setBrowserOpen(false);setQuery(''); setFilter('');setEditorialFilter('');setCanonFilter('');setFavoritesOnly(false); setShowArchived(!!world.entries.find(item => item.id === entryId)?.archived); } }, [openRequest]);
  function navigateEntry(id: string, fromBrowser = false) { const target = world.entries.find(item => item.id === id); if (!target||!canNavigate()) return;setResourcesOpen(false); if(reading&&id!==entryId)setLoreHistory(previous=>[...previous,{id:entryId,section:visibleSection.current}]);pendingSection.current='';pendingArticleFocus.current=reading;setEntryId(id); setTab('entries');setRelationsOpen(false);if(!fromBrowser||compactBrowser())setBrowserOpen(false);if(fromBrowser&&compactBrowser()&&!reading)focusDetail('.world-entry-detail'); if(!fromBrowser){setQuery('');setFilter('');setEditorialFilter('');setCanonFilter('');setFavoritesOnly(false);} setShowArchived(target.archived); }
  function startCreate(kind: 'template' | 'entry') {
    if(!canNavigate())return;if(kind==='template')setReading(false);
    setCreating(kind); setName(''); setEntryTemplateId(filter || template?.id || '');
  }
  function create() {
    if(creating!=='template'||!name.trim())return;
    const result=addTemplate(world,name);onChange(result.world);selectTemplate(result.templateId);setTemplateQuery('');setTab('templates');setName('');
  }
  function createEntry(name:string,templateId:string){
    const result=addEntry(world,templateId,name);if(!result)return;
    onChange(result.world);setReading(false);setEntryId(result.entryId);setTab('entries');setQuery('');setEditorialFilter('');setCanonFilter('');setFavoritesOnly(false);setFilter(templateId);setShowArchived(false);setCreating(null);setBrowserOpen(false);if(compactBrowser())focusDetail('.world-entry-detail');
  }
  const [entryTransfer,setEntryTransfer]=useState<'import'|'export'|null>(null);
  const [relationsOpen,setRelationsOpen]=useWorkspaceState('world.relationsOpen',false);
  function openLineage(id:string){if(!canNavigate())return;setLineageRequest({id,token:Date.now()});setReading(false);setRelationSection('genealogy');setResourcesOpen(false);setRelationsOpen(true);}
  const [lineageRequest,setLineageRequest]=useState<{id:string;token:number}>();
  const [relationSection,setRelationSection]=useWorkspaceState<'network'|'types'|'genealogy'>('world.relationSection','network'),[networkFocusId,setNetworkFocusId]=useWorkspaceState('world.networkFocusId','');
  useEffect(()=>{if(openRequest&&!isWorkspaceRestoring())setRelationsOpen(false);},[openRequest]);
  const [entryOrder,setEntryOrder]=useWorkspaceState<EntryOrder>('world.entryOrder',readEntryOrder);
  const results=sortEntries(filteredEntries,entryOrder);
  const [relationTypeRequest,setRelationTypeRequest]=useState<{id:string;token:number}>();
  const [reading,setReading]=useWorkspaceState('world.reading',false),[browserOpen,setBrowserOpen]=useWorkspaceState('world.browserOpen',false),[navigationError,setNavigationError]=useState(''),[loreHistory,setLoreHistory]=useWorkspaceState<{id:string;section:string}[]>('world.loreHistory',[]);
  const visibleSection=useRef(''),pendingSection=useRef(''),lastEntry=useRef(entryId),pendingArticleFocus=useRef(false);
  useEffect(()=>{if(!isWorkspaceRestoring()&&templateRequest&&world.templates.some(template=>template.id===templateRequest.id)){setResourcesOpen(false);selectTemplate(templateRequest.id);setTemplateQuery('');setReading(false);setResourcesOpen(false);setRelationsOpen(false);setTab('templates');}},[templateRequest?.token]);
  useEffect(()=>{if(entry)lastEntry.current=entry.id;},[entry?.id]);
  useEffect(()=>{const frame=requestAnimationFrame(()=>{if(pendingSection.current&&contentRef.current)revealLoreSection(contentRef.current,pendingSection.current);pendingSection.current='';if(pendingArticleFocus.current){const heading=contentRef.current?.querySelector<HTMLElement>('.lore-article h1');if(heading){heading.tabIndex=-1;heading.focus({preventScroll:true});}pendingArticleFocus.current=false;}});return()=>cancelAnimationFrame(frame);},[reading,entryId]);
  function canNavigate(){if(!prepareLoreNavigation(contentRef.current)){setNavigationError(t('Correct the invalid date before leaving this entry.'));return false;}setNavigationError('');return true;}
  function changeMode(next:boolean){if(!canNavigate())return;if(compactBrowser())setBrowserOpen(false);setResourcesOpen(false);if(next===reading&&!relationsOpen&&tab==='entries')return;pendingSection.current=loreModeTarget(next,visibleSection.current);pendingArticleFocus.current=next;if(next){setRelationsOpen(false);setTab('entries');if(!entryId&&world.entries.some(item=>item.id===lastEntry.current)){setEntryId(lastEntry.current);setFilter('');setQuery('');setShowArchived(!!world.entries.find(item=>item.id===lastEntry.current)?.archived);}}setReading(next);setCreating(null);}
  function goBack(){if(!canNavigate())return;const previous=loreHistory[loreHistory.length-1];if(!previous)return;setLoreHistory(loreHistory.slice(0,-1));pendingSection.current=previous.section;pendingArticleFocus.current=true;setEntryId(previous.id);setBrowserOpen(false);}
  const [browserWidth,setBrowserWidth]=useState(()=>readBrowserWidth(projectId??'default'));


  useEffect(()=>{setBrowserWidth(readBrowserWidth(projectId??'default'));},[projectId]);
  function resizeBrowser(value:number){const width=clampBrowserWidth(value);setBrowserWidth(width);rememberBrowserWidth(projectId??'default',width);}
  const [resourcesOpen,setResourcesOpen]=useWorkspaceState('world.resourcesOpen',false);
  useEffect(()=>onWorkspaceChange?.(),[relationsOpen,relationSection,resourcesOpen,reading,networkFocusId,onWorkspaceChange]);
  function selectWorldSection(section:WorldSection){
    if(!canNavigate())return false;
    if(section==='maps'){onOpenMaps?.();return true;}
    setResourcesOpen(section==='resources');setRelationsOpen(section==='relations'||section==='types');setCreating(null);
    if(section==='relations'||section==='types'){setReading(false);setRelationSection(section==='types'?'types':'network');if(section==='relations')setNetworkFocusId('');}
    if(section==='entries'||section==='templates'){setTab(section);if(section==='templates')setReading(false);}
    return true;
  }
  const headerSelection=resourcesOpen?'resources':relationsOpen?relationSection==='types'?'types':'relations':tab;
  const headerSelect=useRef(selectWorldSection);headerSelect.current=selectWorldSection;
  useEffect(()=>{if(sectionRequest){if(!headerSelect.current(sectionRequest.section))headerSlot?.onNavigation({selected:headerSelection,rejected:true,select:section=>headerSelect.current(section)});onSectionRequestHandled?.(sectionRequest.token);}},[sectionRequest?.token]);
  useEffect(()=>{headerSlot?.onNavigation({selected:headerSelection,select:section=>headerSelect.current(section)});},[headerSlot?.onNavigation,headerSelection]);
  const entryTemplate=entry?world.templates.find(template=>template.id===entry.templateId):undefined;
  const outline=entry&&entryTemplate?[...(reading?[{id:loreOverviewId,title:t('Article overview')}]:[]),...(reading?loreArticleGroups(entryTemplate,entry):loreGroups(entryTemplate,entry,false)).map(group=>({id:loreSectionId(group.id),title:group.title})),...(reading&&entry.imageIds?.some(id=>id!==entry.imageId)?[{id:'lore-gallery',title:t('Image gallery')}]:[]),...(!reading||entryRelations?.links.some(link=>link.sourceId===entry.id||link.targetId===entry.id)||entryRelations?.lineages?.some(lineage=>lineage.memberIds.includes(entry.id))?[{id:'lore-relations',title:t('Entry relationships')}]:[]),...(!reading||entryAppearances(chapters,world,entry.id).sceneCount>0?[{id:'lore-appearances',title:t('Manuscript appearances')}]:[])]:[];
  useEffect(()=>{
    const root=contentRef.current;if(!root||typeof ResizeObserver==='undefined')return;
    const update=()=>{
      if(!root.clientWidth||!root.clientHeight)return;
      const browser=root.querySelector<HTMLElement>('.world-entry-browser,.world-template-browser');if(!browser||!browser.getClientRects().length)return;
      const height=worldBrowserHeight(root.getBoundingClientRect(),browser.getBoundingClientRect().top,parseFloat(getComputedStyle(root).paddingTop)||0);
      if(height!==undefined)root.style.setProperty('--world-browser-height',`${height}px`);
    };
    update();const observer=new ResizeObserver(update);observer.observe(root);
    return()=>observer.disconnect();
  },[tab,reading,creating,relationsOpen,resourcesOpen]);
 const headerControls=<>{!resourcesOpen&&!relationsOpen&&tab==='templates'&&<button type="button" className="lore-browser-toggle quick-action quick-action-text" aria-expanded={templateBrowserOpen} aria-controls="world-template-browser" onClick={()=>setTemplateBrowserOpen(!templateBrowserOpen)}><PanelLeft size={17}/>{t('Browse templates')}</button>}{!resourcesOpen&&!relationsOpen&&tab==='entries'&&<button type="button" className="lore-browser-toggle quick-action" aria-label={buttonLabel(reading?'World index':'Browse entries')} title={buttonLabel(reading?'World index':'Browse entries')} aria-expanded={browserOpen} aria-controls="lore-entry-browser" data-reading={reading} onClick={()=>setBrowserOpen(!browserOpen)}><PanelLeft size={17} aria-hidden="true"/></button>}{resourcesOpen?null:relationsOpen?<button type="button" className="quick-action" aria-label={t('Read world entries')} title={t('Open the entry encyclopedia')} onClick={()=>changeMode(true)}><BookOpen size={17}/></button>:tab==='entries'?<div className="world-reading-mode" role="group" aria-label={t('Entry mode')}><button type="button" aria-pressed={!reading} onClick={()=>changeMode(false)}>{t('Edit')}</button><button type="button" aria-pressed={reading} onClick={()=>changeMode(true)}>{t('Read')}</button></div>:null}{reading&&!resourcesOpen&&!relationsOpen&&tab==='entries'&&entry&&onEntryHistory&&<button type="button" className="quick-action" title={t('Entry history')} aria-label={t('Entry history')} onClick={()=>onEntryHistory(entry.id)}><History size={17}/></button>}{!resourcesOpen&&!relationsOpen&&tab==='entries'&&<button type="button" className="quick-action" title={buttonLabel('Import entries…')} aria-label={buttonLabel('Import entries…')} disabled={!onLoadEntries} onClick={()=>{if(canNavigate())setEntryTransfer('import');}}><Upload size={16}/></button>}{!resourcesOpen&&!relationsOpen&&tab==='templates'&&<button type="button" className="quick-action" title={buttonLabel('Import or copy templates…')} aria-label={buttonLabel('Import or copy templates…')} disabled={!onLoadTemplates} onClick={()=>{if(!canNavigate())return;setTransferNotice('');setImportingTemplates(true);}}><Upload size={16}/></button>}{reading&&!resourcesOpen&&!relationsOpen&&tab==='entries'&&entry&&onRequestEntryExport&&<button type="button" className="quick-action" title={buttonLabel('Export this entry…')} aria-label={buttonLabel('Export this entry…')} onClick={()=>{if(canNavigate())onRequestEntryExport(entry.id);}}><Download size={16}/></button>}</>;
 const workspaceHeader=headerSlot?(headerSlot.target?createPortal(headerControls,headerSlot.target):null):<header className={`world-module-header ui-workspace-heading${reading&&!relationsOpen&&!resourcesOpen?' lore-reading-header':''}`}><h2>{t('World')}</h2><WorldNavigation selected={headerSelection} onSelect={selectWorldSection}/>{headerControls}</header>;
  return <>
    {duplicateSource&&<EntryDuplicateDialog key={duplicateSource.id} world={world} entry={duplicateSource} onCancel={()=>setDuplicating('')} onSave={(title,aliases)=>{const result=duplicateEntry(world,duplicateSource.id,title,aliases);if(!result)return;onChange(result.world);setReading(false);setEntryId(result.entryId);setTab('entries');setQuery('');setEditorialFilter('');setCanonFilter('');setFilter(duplicateSource.templateId);setShowArchived(false);setDuplicating('');setBrowserOpen(false);if(compactBrowser())focusDetail('.world-entry-detail');}}/>}
    {creating==='template'&&<ProjectModal title={t('New template')} className="world-template-create-dialog" onClose={closeTemplateCreate}><form className="ui-dialog-form" hidden={discardTemplate} inert={discardTemplate} onSubmit={event=>{event.preventDefault();create();}}><div className="ui-form-field"><label htmlFor="world-new-name">{t('Template name')}</label><input id="world-new-name" type="text" required value={name} onChange={event=>setName(event.target.value)}/></div><div className="welcome-actions"><button type="button" onClick={closeTemplateCreate} className="quick-action quick-action-text">{t('Cancel')}</button><button type="submit" className="primary-button" disabled={!name.trim()}>{t('Create')}</button></div></form></ProjectModal>}
    {discardTemplate&&creating==='template'&&<ProjectModal title={t('Discard unsaved changes?')} variant="confirmation" onClose={()=>setDiscardTemplate(false)}><p>{t('Unsaved changes will be lost if you discard them.')}</p><div className="welcome-actions"><button type="button" className="quick-action quick-action-text" onClick={()=>setDiscardTemplate(false)}>{t('Keep editing')}</button><button type="button" className="danger-button" onClick={()=>{setDiscardTemplate(false);setCreating(null);}}>{t('Discard changes')}</button></div></ProjectModal>}
    {creating==='entry'&&<EntryCreateDialog world={world} initialTemplateId={entryTemplateId} onSave={createEntry} onCancel={()=>setCreating(null)}/>}
    {importingTemplates && onLoadTemplates && <TemplateImportDialog world={world} currentPath={projectPath} recents={recentProjects} error={transferError} onLoad={onLoadTemplates} onClose={()=>setImportingTemplates(false)} onImport={(packet,roots,names)=>{
      const result=importTemplates(world,packet,roots,names);onChange(result.world);selectTemplate(result.templateId);setTemplateQuery('');setTab('templates');setCreating(null);setImportingTemplates(false);setTransferNotice(t('{0} templates imported. Save the project to keep them.',result.count));
    }}/>}
    {deleting && <WorldDeletionDialog relations={entryRelations} maps={maps} timeline={timeline} chapters={chapters} world={world} target={deleting} onCancel={() => setDeleting(null)} onConfirm={() => {
      const next = deleting.kind === 'entry' ? deleteEntry(world, deleting.id) : deleteTemplate(world, deleting.id);
      if (next !== world) { onChange(next); if (deleting.kind === 'entry') setEntryId(''); else { setTemplateId(''); setFilter(''); setCreating(null); } }
      setDeleting(null);
    }} />}

    {entryTransfer&&onLoadEntries&&onExportEntries&&onImportEntries&&<EntryTransferDialog relations={entryRelations} world={world} initialId={entryId} mode={entryTransfer} onLoad={onLoadEntries} onExport={onExportEntries} onImport={onImportEntries} externalError={transferError} onClose={()=>setEntryTransfer(null)}/>}{workspaceHeader}
    {navigationError&&<p role="alert" className="lore-save-notice">{navigationError}</p>}
    {saveState?.error&&<div role="alert" className="lore-save-notice">{t('Changes remain in this project. Saving failed: {0}',saveState.error)}<button type="button" disabled={saveState.busy} onClick={()=>{void onRetrySave?.();}}>{t('Retry save')}</button></div>}
    {transferNotice && <p className="template-transfer-notice" role="status">{transferNotice}<button type="button" onClick={()=>setTransferNotice('')}>{t('Dismiss notification')}</button></p>}
    {relationsOpen?<div className="world-relationship-workspace"><div className="relationship-view-tabs workspace-tabs workspace-tabs-internal module-navigation" role="group" aria-label={t('Relationship view')}><button type="button" aria-current={relationSection==='network'?'page':undefined} aria-pressed={relationSection==='network'} onClick={()=>setRelationSection('network')}><Network size={16} aria-hidden="true"/>{t('Network')}</button><button type="button" aria-current={relationSection==='genealogy'?'page':undefined} aria-pressed={relationSection==='genealogy'} onClick={()=>setRelationSection('genealogy')}><GitBranch size={16} aria-hidden="true"/>{t('Genealogy')}</button></div><div hidden={relationSection!=='network'}><RelationNetwork onBrowseEntries={()=>{setRelationsOpen(false);setTab('entries');}} typeRequest={relationTypeRequest} projectPath={projectPath} projectId={projectId} key={networkFocusId||'all'} initialFocusId={networkFocusId} world={world} relations={entryRelations??emptyEntryRelations} chapters={chapters} plots={plots} timeline={timeline} onChange={next=>onRelationsChange?.(next)} onWorldChange={onChange} onOpenEntry={id=>{navigateEntry(id);setRelationsOpen(false);}} onManage={()=>setRelationSection('types')}/></div><div hidden={relationSection!=='genealogy'}><Genealogy lineageRequest={lineageRequest} onWorldChange={onChange} projectPath={projectPath} projectId={projectId} key={networkFocusId||'all'} initialFocusId={networkFocusId} world={world} relations={entryRelations??emptyEntryRelations} onChange={next=>onRelationsChange?.(next)} onOpenEntry={id=>{navigateEntry(id);setRelationsOpen(false);}} onManage={()=>setRelationSection('types')}/></div><div hidden={relationSection!=='types'}><RelationshipLibrary onBrowseType={id=>{setRelationTypeRequest({id,token:(relationTypeRequest?.token??0)+1});setRelationSection('network');}} world={world} relations={entryRelations??emptyEntryRelations} onChange={next=>onRelationsChange?.(next)}/></div></div>:resourcesOpen?<VisualLibrary maps={maps} ideaCanvases={ideaCanvases} onResourcesChange={onResourcesChange} onMapsChange={onMapsChange} world={world} projectPath={projectPath} projectId={projectId} onChange={onChange} onImport={onImportVisualResource}/>:<div ref={contentRef} style={{'--world-browser-width':`${browserWidth}px`} as CSSProperties} className={`world-scroll world-editor-content ${tab}-view${reading?' reading':''}${browserOpen?' world-browser-open':''}${templateBrowserOpen?' world-template-browser-open':''}`}>

      {tab === 'entries' ? <>

          <div id="lore-entry-browser" className="world-entry-browser"><PanelResize className="world-browser-resize" side="left" label={t('Resize world navigation')} width={browserWidth} minimum={browserWidthMinimum} maximum={browserWidthMaximum} onChange={resizeBrowser}/><div className="world-browser-scroll" id="world-entry-browser-scroll">{reading?<><button type="button" className="lore-index-link" onClick={()=>{if(!canNavigate())return;if(entryId)setLoreHistory(previous=>[...previous,{id:entryId,section:visibleSection.current}]);pendingArticleFocus.current=true;setEntryId('');setBrowserOpen(false);}}>{t('World index')}</button><LoreContents world={world} selectedId={entryId} onNavigate={id=>navigateEntry(id,true)}/></>:<><div className="world-browser-controls">
 <div className="world-entry-search"><label className="visually-hidden" htmlFor="world-search">{t('Search entries by name')}</label><input id="world-search" type="search" placeholder={t('Search entries by name…')} value={query} onChange={event=>setQuery(event.target.value)}/>{query&&<button type="button" className="icon-button quick-action ui-close-button" aria-label={t('Clear search')} title={t('Clear search')} onClick={()=>setQuery('')}><X size={14}/></button>}</div>
 <div className="world-browser-filters"><label id="world-template-filter-label" className="visually-hidden" htmlFor="world-template-filter">{t('Filter by template')}</label><Dropdown searchable searchLabel={t('Search templates')} id="world-template-filter" aria-labelledby="world-template-filter-label" value={effectiveFilter} onChange={value=>{if(!canNavigate())return;setFilter(value);setEntryId('');}} options={[{value:'',label:t('All templates')},...templateChoices.map(item=>({value:item.id,searchText:item.title||t('Untitled template'),label:`${item.title||t('Untitled template')} · ${templateCounts.get(item.id)??0}`}))]}/><button type="button" className="quick-action primary-button world-create-entry" title={t(world.templates.length?'New entry':'New template')} aria-label={t(world.templates.length?'New entry':'New template')} aria-haspopup="dialog" onClick={()=>startCreate(world.templates.length?'entry':'template')}><Plus size={16}/></button></div>
 <div className="world-filter-toolbar">
 <RelationshipOptions animated label={t('Filters')+(additionalFilterCount?` · ${additionalFilterCount}`:'')} icon={<SlidersHorizontal size={16}/>} triggerClassName="quick-action quick-action-text world-filters-toggle" popupClassName="world-entry-filter-panel" width={320}>
 <div className="ui-form-field"><label htmlFor="world-entry-status">{t('Entry status')}</label><Dropdown id="world-entry-status" value={showArchived?'archived':'active'} options={[{value:'active',label:t('Active')},{value:'archived',label:t('Archived')}]} onChange={value=>changeAdditionalFilters({archived:value==='archived'})}/></div>
 <label className="world-favorites-only"><input type="checkbox" checked={favoritesOnly} onChange={event=>changeAdditionalFilters({favoritesOnly:event.target.checked})}/>{t('Favorites only')}</label>
 <div className="ui-form-field"><label htmlFor="world-editorial-filter">{t('Editorial status')}</label><Dropdown id="world-editorial-filter" value={editorialFilter} onChange={value=>changeAdditionalFilters({editorial:value})} options={[{value:'',label:t('All editorial states')},{value:'unclassified',label:t('Unclassified')},...Object.entries(editorialLabels).map(([value,label])=>({value,label:buttonLabel(label),tone:statusTone('editorial',value)}))]}/></div>
 <div className="ui-form-field"><label htmlFor="world-canon-filter">{t('Canon status')}</label><Dropdown id="world-canon-filter" value={canonFilter} onChange={value=>changeAdditionalFilters({canon:value})} options={[{value:'',label:t('All canon states')},{value:'unclassified',label:t('Unclassified')},...Object.entries(canonLabels).map(([value,label])=>({value,label:buttonLabel(label),tone:statusTone('canon',value)}))]}/></div>
 <button type="button" className="quick-action quick-action-text" disabled={!additionalFilterCount} onClick={()=>changeAdditionalFilters({archived:false,editorial:'',canon:'',favoritesOnly:false})}>{t('Clear filters')}</button>
 </RelationshipOptions>
 <ActionMenu animated iconOnly label={`${t('Sort entries')}: ${t(entryOrderLabels[entryOrder])}`} actions={Object.entries(entryOrderLabels).map(([value,label])=>({label:t(label),selected:entryOrder===value,icon:entryOrder===value?<Check size={14}/>:undefined,onClick:()=>{setEntryOrder(value as EntryOrder);rememberEntryOrder(value as EntryOrder);}}))}>{entryOrder==='reverseAlphabetical'?<ArrowUpAZ size={16}/>:entryOrder==='recentlyModified'?<ArrowDownWideNarrow size={16}/>:entryOrder==='oldestModified'?<ArrowUpWideNarrow size={16}/>:<ArrowDownAZ size={16}/>}</ActionMenu>
 <WorldSavedAccess key={projectId||projectPath||'current'} access={savedAccess} templates={world.templates} view={{query,templateId:effectiveFilter,archived:showArchived,editorial:editorialFilter,canon:canonFilter,favoritesOnly,order:entryOrder}} onApply={view=>{if(!canNavigate())return;setQuery(view.query);setFilter(world.templates.some(item=>item.id===view.templateId)?view.templateId:'');setShowArchived(view.archived);setEditorialFilter(view.editorial);setCanonFilter(view.canon??'');setFavoritesOnly(!!view.favoritesOnly);setEntryOrder(view.order);rememberEntryOrder(view.order);setEntryId('');}}/>
 </div>
 {additionalFilterCount>0&&<div className="world-applied-filters" aria-label={t('Applied filters')}>
 {showArchived&&<button type="button" className="quick-action quick-action-text" aria-label={t('Clear archived filter')} onClick={()=>changeAdditionalFilters({archived:false})}>{t('Archived')}<X size={14}/></button>}
 {favoritesOnly&&<button type="button" className="quick-action quick-action-text" aria-label={t('Clear favorites filter')} onClick={()=>changeAdditionalFilters({favoritesOnly:false})}>{t('Favorites only')}<X size={14}/></button>}
 {editorialFilter&&<button type="button" className="quick-action quick-action-text" aria-label={t('Clear editorial filter')} onClick={()=>changeAdditionalFilters({editorial:''})}><span>{t('Editorial status')}: {buttonLabel(editorialFilter==='unclassified'?'Unclassified':editorialLabels[editorialFilter as keyof typeof editorialLabels])}</span><X size={14}/></button>}
 {canonFilter&&<button type="button" className="quick-action quick-action-text" aria-label={t('Clear canon filter')} onClick={()=>changeAdditionalFilters({canon:''})}><span>{t('Canon status')}: {buttonLabel(canonFilter==='unclassified'?'Unclassified':canonLabels[canonFilter as keyof typeof canonLabels])}</span><X size={14}/></button>}
 </div>}
 {savedAccess.error&&<p className="prompt-error" role="alert">{savedAccess.error}</p>}
 <p className="world-hint lore-result-count" role="status">{results.length===scopeTotal?t(scopeTotal===1?'{0} entry':'{0} entries',scopeTotal):t('{0} of {1} entries',results.length,scopeTotal)}</p>
</div>
<div className="world-entry-list" id="world-entry-list-scroll" aria-label={t("Worldbuilding entries")}>{results.map(item => {const Glyph=entryTemplateGlyph(world.templates.find(template=>template.id===item.templateId));return <button type="button" key={item.id} className={entryId === item.id ? 'selected' : ''} aria-pressed={entryId === item.id} onClick={() => navigateEntry(item.id,true)}><EntryThumbnail projectPath={projectPath} projectId={projectId} imageId={item.imageId} title={item.title} fallback={<Glyph size={19} strokeWidth={1.5}/>}/><span className="entry-list-title">{item.title || t("Untitled entry")}</span><small>{world.templates.find(t => t.id === item.templateId)?.title || t("Untitled template")}</small><EntryStatuses entry={item} compact/><span className="world-entry-preview">{(world.templates.find(template=>template.id===item.templateId)?.fields??[]).filter(field=>!field.archived).map(field=>displayFieldValue(field,item.values[field.id],world)).find(value=>value&&value!=='—'&&value.trim()!==item.title.trim())||''}</span></button>;})}{results.length === 0 && <div className="world-hint"><p>{query || effectiveFilter || additionalFilterCount ? t("No matching entries.") : showArchived ? t("No archived entries.") : t("No entries yet.")}</p>{(query||filter||additionalFilterCount>0) && <button type="button" className="quick-action quick-action-text" onClick={() => {setQuery('');setFilter('');changeAdditionalFilters({archived:false,editorial:'',canon:'',favoritesOnly:false});}}>{t("Clear filters")}</button>}</div>}</div></>}
          </div></div>
          {entry ? reading?<LoreArticle onOpenLineage={openLineage} worldIdeas={worldIdeas} onOpenIdea={onOpenIdea} world={world} entry={entry} relations={entryRelations??emptyEntryRelations} projectPath={projectPath} projectId={projectId} chapters={chapters} onNavigate={navigateEntry} onEdit={()=>changeMode(false)} onBack={goBack} canBack={!!loreHistory.length} onOpenScene={onOpenScene} onOpenMention={onOpenMention}/>:<section key={`entry-${entry.id}`} className="world-entry-detail" aria-label={t("Entry details")}><div className="world-detail-heading"><EntryThumbnail projectPath={projectPath} projectId={projectId} imageId={entry.imageId} title={entry.title} fallback={(()=>{const Glyph=entryTemplateGlyph(entryTemplate);return <Glyph size={25} strokeWidth={1.5}/>;})()}/><div className="world-entry-identity"><div className="entry-title-row"><input aria-label={t("Entry title")} value={entry.title} placeholder={t("Untitled entry")} onChange={event => onChange(updateEntry(world, { ...entry, title: event.target.value }))} /><div className="world-entry-actions">{(projectId||projectPath)&&<button type="button" className="quick-action" aria-pressed={savedAccess.saved.entries.includes(entry.id)} aria-label={buttonLabel(savedAccess.saved.entries.includes(entry.id)?'Remove current entry from favorites':'Add current entry to favorites')} title={buttonLabel(savedAccess.saved.entries.includes(entry.id)?'Remove current entry from favorites':'Add current entry to favorites')} onClick={()=>savedAccess.save({...savedAccess.saved,entries:savedAccess.saved.entries.includes(entry.id)?savedAccess.saved.entries.filter(id=>id!==entry.id):[...savedAccess.saved.entries,entry.id].slice(-100)})}><Bookmark size={16} aria-hidden="true" fill={savedAccess.saved.entries.includes(entry.id)?'currentColor':'none'}/></button>}<ActionMenu iconOnly label={t("Entry actions")} actions={[
            ...(onRequestEntryExport?[{label:buttonLabel('Export this entry…'),icon:<Download size={14}/>,onClick:()=>{if(canNavigate())onRequestEntryExport(entry.id);}}]:[]),
            { label: entry.archived ? t("Restore entry") : t("Archive entry"), icon: <Archive size={14} />, onClick: () => { onChange(updateEntry(world, { ...entry, archived: !entry.archived })); setShowArchived(!entry.archived); } },
            { label:t('Entry history'),icon:<History size={14}/>,disabled:!onEntryHistory,onClick:()=>onEntryHistory?.(entry.id) },
            { label:buttonLabel('Duplicate entry…'),icon:<Copy size={14}/>,onClick:()=>setDuplicating(entry.id) },
            { label: t("Delete entry"), icon: <Trash2 size={14} />, danger: true, onClick: () => setDeleting({ kind: 'entry', id: entry.id }) },
          ]}><MoreHorizontal size={17}/></ActionMenu></div></div><div className="world-entry-template-row"><button type="button" className="entry-template-link" onClick={() => { if(!canNavigate())return;setReading(false);selectTemplate(entry.templateId);setTemplateQuery('');setTab('templates'); setCreating(null); }}>{world.templates.find(t => t.id === entry.templateId)?.title || t("Untitled template")}{" " + t("· Edit template")}</button>{entry.archived && <span className="semantic-status" data-semantic-tone="neutral">{t("Archived")}</span>}</div><EntryEditorial entry={entry} onChange={next=>onChange(updateEntry(world,next))}/>{!!entry.linkAliases?.length&&<p className="lore-alias-summary">{t('Also known as')}: {entry.linkAliases.join(' · ')}</p>}{saveState&&(saveState.busy||saveState.dirty)&&<small className="lore-save-state" role="status">{saveState.busy?t('Saving…'):saveState.dirty?t('Changes pending save'):t('Saved')}</small>}</div></div><EntrySection variant="compact" defaultOpen={false} title={t('Link aliases')} count={entry.linkAliases?.length||undefined}><div className="entry-metadata-row"><EntryLinkAliases key={`aliases-${entry.id}`} world={world} entry={entry} onChange={onChange} embedded/></div></EntrySection><EntryGallery key={`gallery-${entry.id}`} world={world} entry={entry} projectPath={projectPath} projectId={projectId} onChange={onChange} onImport={onImportEntryImage?()=>onImportEntryImage(entry.id):undefined}/><EntryFields focusFragment={fragmentRequest?.fragment.targetId===entry.id?fragmentRequest:undefined} key={`fields-${entry.id}`} world={world} entry={entry} onChange={onChange} onNavigate={navigateEntry} /><EntryUsageSummary appearanceId="lore-appearances" entryId={entry.id} world={world} chapters={chapters} ideas={worldIdeas} onOpenIdea={onOpenIdea} onOpenScene={onOpenScene} onOpenMention={onOpenMention}/><section id="lore-relations" data-lore-section><EntryRelationsPanel onOpenLineage={openLineage} key={`relationships-${entry.id}`} world={world} entry={entry} relations={entryRelations} onChange={next=>onRelationsChange?.(next)} onNavigate={navigateEntry} onManage={()=>{if(!canNavigate())return;setReading(false);setRelationSection('types');setResourcesOpen(false);setRelationsOpen(true);}} onView={()=>{if(!canNavigate())return;setReading(false);setNetworkFocusId(entry.id);setRelationSection('network');setResourcesOpen(false);setRelationsOpen(true);}}/></section><details className="lore-age-tool" hidden={!birthDateField(world,entry)}><summary>{t('Age at a story date')}</summary><EntryAgePreview key={`age-${entry.id}`} world={world} entry={entry}/></details></section> : reading?entryId?<article className="lore-article"><h1>{t('Missing entry')}</h1>{!!loreHistory.length&&<button type="button" onClick={goBack}>{t('Back to previous article')}</button>}<button type="button" onClick={()=>setEntryId('')}>{t('World index')}</button></article>:<LoreIndex world={world} entries={world.entries} onNavigate={id=>navigateEntry(id,true)} onBack={goBack} canBack={!!loreHistory.length}/>:world.templates.length===0?<div className="world-no-selection ui-empty-state"><h3>{t("Create your first template")}</h3><p>{t("Define fields before adding entries.")}</p><button type="button" className="primary-button" onClick={() => startCreate('template')}><Plus size={14} />{t("New template")}</button></div>:<div className="world-no-selection ui-empty-state"><BookOpen aria-hidden="true"/><h3>{t("Choose an entry")}</h3>{world.entries.length>0&&<button type="button" className="quick-action quick-action-text world-empty-browse" onClick={()=>setBrowserOpen(true)}><PanelLeft size={16}/>{t('Browse entries')}</button>}<button type="button" className="primary-button" onClick={()=>startCreate('entry')}><Plus size={16} aria-hidden="true"/>{t("New entry")}</button></div>}
          {entry&&<LoreOutline key={`outline:${reading}`} reading={reading} sections={outline} root={contentRef} context={`${entry.id}:${reading}`} onVisible={id=>{visibleSection.current=id;}}/>}
      </> : <>
        <nav id="world-template-browser" className="world-template-browser" aria-label={t("Templates")}><PanelResize className="world-browser-resize" side="left" label={t('Resize world navigation')} width={browserWidth} minimum={browserWidthMinimum} maximum={browserWidthMaximum} onChange={resizeBrowser}/><div className="world-browser-scroll" id="world-template-browser-scroll"><div className="world-browser-heading"><button type="button" className="world-add-button primary-button" onClick={() => startCreate('template')}><Plus size={14} />{t("New template")}</button></div><label className="visually-hidden" htmlFor="world-template-search">{t("Search templates")}</label><input id="world-template-search" type="search" placeholder={t("Search templates…")} value={templateQuery} onChange={event => setTemplateQuery(event.target.value)} /><div className="world-entry-list">{matchingTemplates.map(item => <button type="button" key={item.id} aria-pressed={template?.id === item.id} onClick={() => { selectTemplate(item.id); }}><span>{item.title || t("Untitled template")}</span><small>{item.fields.filter(field => !field.archived).length}{" " + t("fields ·") + " "}{templateEntryCount(world, item.id)}{" " + t("entries")}</small></button>)}</div>{world.templates.length === 0 ? <p className="world-hint">{t("Create your first template to start adding entries.")}</p> : !matchingTemplates.length && <p className="world-hint">{t("No matching templates.")}</p>}</div></nav>
        {template ? <section key={`template-${template.id}`} className="world-template-detail" aria-label={t("Template details")}><header className="world-template-heading"><div className="ui-form-field world-template-name"><label htmlFor="world-template-title">{t("Template name")}</label><input id="world-template-title" value={template.title} placeholder={t("Untitled template")} onChange={event => onChange(updateTemplate(world, { ...template, title: event.target.value }))} /></div>
          <div className="world-template-overview"><dl className="world-template-counts"><div><dt>{t("active fields")}</dt><dd>{template.fields.filter(field => !field.archived).length}</dd></div><div><dt>{t("entries, including archived")}</dt><dd>{templateEntryCount(world, template.id)}</dd></div></dl><FieldHelp label={t("Template details")} description={t("Field changes apply to all entries using this template.")}/></div></header>
          <div className="world-detail-toolbar"><button type="button" className="quick-action" title={buttonLabel('Export template…')} aria-label={buttonLabel('Export template…')} disabled={!onExportTemplates} onClick={()=>{void onExportTemplates?.([template.id]);}}><Download size={16}/></button><button type="button" className="quick-action quick-action-text" onClick={() => { setBrowserOpen(true);setTab('entries'); setFilter(template.id); setQuery(''); setShowArchived(false); setEntryId(''); }}>{t("View entries")}</button><button type="button" className="quick-action quick-action-text" aria-haspopup="dialog" onClick={() => { setTab('entries'); setCreating('entry'); setEntryTemplateId(template.id); setName(''); }}> <Plus size={14} />{t("New entry with this template")}</button></div>
          <TemplateRelationships template={template} world={world} relations={entryRelations??emptyEntryRelations} onChange={next=>onRelationsChange?.(next)} onManage={()=>{if(!canNavigate())return;setReading(false);setRelationSection('types');setResourcesOpen(false);setRelationsOpen(true);}}/>
          <TemplateFields key={template.id} world={world} template={template} onChange={onChange} />
          <div className="world-template-delete"><button type="button" disabled={templateEntryCount(world, template.id) > 0} onClick={() => setDeleting({ kind: 'template', id: template.id })} className="destructive-action"><Trash2 size={15} />{t("Delete template")}</button><p className="world-hint">{templateEntryCount(world, template.id) > 0 ? t("Delete all {0} associated entries first, including archived entries.", templateEntryCount(world, template.id)) : t("Only templates without entries can be deleted.")}</p></div>
        </section> : <div className="world-no-selection ui-empty-state"><h3>{t("Give your world a structure")}</h3><p>{t("Create a template for characters, places, or anything your story needs.")}</p><button type="button" onClick={() => startCreate('template')}><Plus size={14} />{t("New template")}</button></div>}
      </>}
    </div>}
  </>;
}
