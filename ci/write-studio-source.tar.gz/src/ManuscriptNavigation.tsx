import ActionMenu from './ActionMenu';
import { t } from './i18n';
import { useEffect, useState } from 'react';
import { ChevronRight, Plus, SlidersHorizontal, Pencil, MoreHorizontal, Trash2 } from 'lucide-react';
import SceneWritingStatus from './SceneWritingStatus';
import type { Chapter } from './model';
type Props = { onDeleteScene?:(id:string)=>void; chapters: Chapter[]; selectedId: string; onChapter: (id: string) => void;onChapterTools?:(id:string)=>void; onScene: (id: string) => void; onSceneTools: (id: string) => void; onAddScene: (chapter: Chapter) => void };
export default function ManuscriptNavigation({onDeleteScene,chapters,selectedId,onChapter,onScene,onSceneTools,onAddScene,onChapterTools}:Props) {
 const [collapsed,setCollapsed]=useState<Set<string>>(()=>new Set()),[query,setQuery]=useState(''),[searchCollapsed,setSearchCollapsed]=useState<Set<string>>(()=>new Set());
 const normalize=(value:string)=>value.normalize('NFD').replace(/[\u0300-\u036f]/g,'').toLocaleLowerCase();
 const needle=normalize(query.trim());
 const matches=(chapter:Chapter)=>!needle||normalize(chapter.title).includes(needle)||chapter.scenes.some(scene=>normalize(scene.title).includes(needle));
 // Navigation from search or another module reveals the selected scene.
 useEffect(()=>{const parent=chapters.find(chapter=>chapter.scenes.some(scene=>scene.id===selectedId));if(parent)setCollapsed(current=>{if(!current.has(parent.id))return current;const next=new Set(current);next.delete(parent.id);return next;});},[selectedId]);
 function toggle(id:string) {(needle?setSearchCollapsed:setCollapsed)(current=>{const next=new Set(current);if(next.has(id))next.delete(id);else next.add(id);return next;});}
 return <><div className="manuscript-navigation-search"><label className="visually-hidden" htmlFor="manuscript-search">{t("Search chapters and scenes")}</label><input id="manuscript-search" type="search" placeholder={t("Search chapters and scenes…")} value={query} onChange={event=>{setQuery(event.target.value);setSearchCollapsed(new Set());}}/></div><nav className="chapter-list" aria-label={t("Chapters")}>{chapters.map((chapter,index)=>{
  if(!matches(chapter))return null;
  const expanded=!(needle?searchCollapsed:collapsed).has(chapter.id), name=chapter.title || t("Untitled chapter"),scenes=!needle||normalize(chapter.title).includes(needle)?chapter.scenes:chapter.scenes.filter(scene=>normalize(scene.title).includes(needle));
  return <div className="manuscript-chapter-group" key={chapter.id}>
   <div className={`navigation-row chapter-row${selectedId===chapter.id ? ' selected' : ''}`}>
    <button type="button" className="chapter-toggle" aria-label={`${expanded ? t("Collapse") : t("Expand")} ${name}`} aria-expanded={expanded} aria-controls={`chapter-scenes-${chapter.id}`} onClick={()=>toggle(chapter.id)}><ChevronRight size={15} aria-hidden="true"/></button>
    <button type="button" className="chapter-item" title={name} aria-current={selectedId===chapter.id ? 'page' : undefined} onClick={()=>onChapter(chapter.id)}><span className="chapter-number">{index+1}</span><span className="chapter-name">{name}</span></button>
    <button type="button" className="row-action" title={t("Chapter tools")} aria-label={t("Tools for chapter {0}", name)} onClick={()=>(onChapterTools??onChapter)(chapter.id)}><SlidersHorizontal size={13}/></button>
    <button type="button" className="row-action" title={t("New scene in this chapter")} aria-label={t("New scene in {0}", name)} onClick={()=>{setCollapsed(current=>{const next=new Set(current);next.delete(chapter.id);return next;});onAddScene(chapter);}}><Plus size={13}/></button>
   </div>
   <div className="chapter-scenes" id={`chapter-scenes-${chapter.id}`} hidden={!expanded}>{scenes.map(scene=><div className={`navigation-row scene-row${scene.id===selectedId ? ' selected' : ''}`} key={scene.id}><button type="button" className="scene-item" title={scene.title||t("Untitled scene")} aria-current={scene.id===selectedId ? 'page' : undefined} onClick={()=>onScene(scene.id)}><SceneWritingStatus scene={scene} compact/><span className="scene-navigation-title">{scene.title || t("Untitled scene")}</span></button><ActionMenu variant="row" animated iconOnly label={t('Options for scene {0}',scene.title||t('Untitled scene'))} actions={[{label:t('Edit details'),icon:<Pencil size={15}/>,onClick:()=>onSceneTools(scene.id)},...(onDeleteScene?[{label:t('Delete scene'),icon:<Trash2 size={15}/>,danger:true,onClick:()=>onDeleteScene(scene.id)}]:[])]}><MoreHorizontal size={15} aria-hidden="true"/></ActionMenu></div>)}</div>
  </div>;
 })}{!chapters.some(matches)&&<p className="navigation-empty">{t("No matching chapters or scenes.")}</p>}</nav></>;
}
