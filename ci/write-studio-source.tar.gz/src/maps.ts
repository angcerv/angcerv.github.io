import type {MarkerLabelOffset} from './mapMarkerLabels';
import type { MapDrawing } from './mapDrawing';
import type { StoryDate } from './timeline';
import { t } from './i18n';
import type { Worldbuilding } from './worldbuilding';
export const mapColors = { teal: '#0D9488', amber: '#D97706', blue: '#0284C7', rose: '#E11D48', violet: '#7C3AED', stone: '#64748B' };
export type MapColor = keyof typeof mapColors;
export type MapIcon = 'pin' | 'city' | 'castle' | 'forest' | 'flag' | 'planet' | 'star' | 'moon' | 'satellite' | 'spaceship';
export type MapMarker = { labelOffset?:MarkerLabelOffset; id:string; title:string; notes:string; x:number; y:number; color:MapColor; icon:MapIcon; entryId?:string; layerId?:string };
export type WorldMap = { id:string; title:string; notes:string; imageId:string;imageFrame?:{x:number;y:number;width:number;height:number}; markers:MapMarker[]; regions?:import('./mapRegions').MapRegion[]; routes?:MapRoute[]; layers?:MapLayer[]; scale?:MapScale; drawing?:MapDrawing };
export type TrashedMap={map:WorldMap;deletedAt:number};
export type ProjectMaps = { schemaVersion:1|2|3|4|5|6|7|8|9|10|11|12|13|14|15|16|17|18|19|20|21|22|23|24|25|26|27|28; trash?:TrashedMap[]; maps:WorldMap[] };
export const emptyMaps:ProjectMaps = { schemaVersion:1, maps:[] };
export function mapPoint(clientX:number,clientY:number,rect:{left:number;top:number;width:number;height:number}) {
 if(rect.width<=0 || rect.height<=0)return null;
 return {x:Math.min(1,Math.max(0,(clientX-rect.left)/rect.width)),y:Math.min(1,Math.max(0,(clientY-rect.top)/rect.height))};
}
export function markerLabel(marker:MapMarker,world?:Worldbuilding) {
 return marker.title.trim() || world?.entries.find(entry=>entry.id===marker.entryId)?.title || t("Untitled marker");
}
export function entryMapLocations(maps:ProjectMaps|undefined,entryId:string) {
 return (maps?.maps ?? []).flatMap(map=>map.markers.filter(marker=>marker.entryId===entryId).map(marker=>({map,marker})));
}
export function updateMap(maps:ProjectMaps,map:WorldMap):ProjectMaps { return {...maps,schemaVersion:map.drawing?.strokes.some(stroke=>stroke.materialMask)?Math.max(28,maps.schemaVersion) as ProjectMaps['schemaVersion']:map.drawing?.strokes.some(stroke=>stroke.mask)?Math.max(27,maps.schemaVersion) as ProjectMaps['schemaVersion']:(map.drawing?.strokes.some(stroke=>stroke.textureScale!==undefined||stroke.textureRotation!==undefined)||map.drawing?.objects.some(object=>object.stamp))?Math.max(26,maps.schemaVersion) as ProjectMaps['schemaVersion']:map.drawing?.strokes.some(stroke=>stroke.opacity!==undefined)?Math.max(25,maps.schemaVersion) as ProjectMaps['schemaVersion']:map.drawing?.strokes.some(stroke=>stroke.brushShape==='irregular')?Math.max(24,maps.schemaVersion) as ProjectMaps['schemaVersion']:map.drawing?.strokes.some(stroke=>stroke.brushShape!==undefined||stroke.softness!==undefined)?Math.max(23,maps.schemaVersion) as ProjectMaps['schemaVersion']:map.markers.some(marker=>marker.labelOffset)?Math.max(22,maps.schemaVersion) as ProjectMaps['schemaVersion']:(map.drawing?.strokes.some(stroke=>stroke.erase||stroke.closed)||map.drawing?.objects.some(object=>object.kind==='path'))?Math.max(21,maps.schemaVersion) as ProjectMaps['schemaVersion']:map.markers.some(marker=>['planet','star','moon','satellite','spaceship'].includes(marker.icon))?Math.max(18,maps.schemaVersion) as ProjectMaps['schemaVersion']:maps.schemaVersion,maps:maps.maps.map(item=>item.id===map.id ? map : item)}; }

export type MapRoute={id:string;title:string;color:MapColor;markerIds:string[];notes:string;layerId?:string;sceneIds?:string[];chapterIds?:string[];departure?:StoryDate;arrival?:StoryDate};
export function filterMapMarkers(map:WorldMap,world:Worldbuilding,templateId:string):MapMarker[]{
 return map.markers.filter(marker=>{const entry=world.entries.find(entry=>entry.id===marker.entryId);return !templateId||(templateId==='__unlinked'?!entry:entry?.templateId===templateId);});
}
export function visibleMapRoutes(map:WorldMap,markers:MapMarker[]):MapRoute[]{
 const ids=new Set(markers.map(marker=>marker.id));return (map.routes??[]).filter(route=>mapLayerVisible(map,route.layerId)&&route.markerIds.every(id=>ids.has(id)));
}
export function addMapRoute(maps:ProjectMaps,mapId:string,title:string,markerIds:string[],color:MapColor='teal'):{maps:ProjectMaps;routeId:string}|null{
 const map=maps.maps.find(map=>map.id===mapId);if(!map||!title.trim()||markerIds.length<2||new Set(markerIds).size!==markerIds.length||markerIds.some(id=>!map.markers.some(marker=>marker.id===id)))return null;
 const route:MapRoute={id:crypto.randomUUID(),title:title.trim(),color,markerIds:[...markerIds],notes:''};
 return {maps:updateMap({...maps,schemaVersion:maps.schemaVersion===1?2:maps.schemaVersion},{...map,routes:[...(map.routes??[]),route]}),routeId:route.id};
}
export function updateMapRoute(maps:ProjectMaps,mapId:string,route:MapRoute):ProjectMaps{
 const map=maps.maps.find(map=>map.id===mapId);if(!map?.routes?.some(item=>item.id===route.id)||route.markerIds.length<2||new Set(route.markerIds).size!==route.markerIds.length||route.markerIds.some(id=>!map.markers.some(marker=>marker.id===id)))return maps;
 return updateMap(maps,{...map,routes:map.routes.map(item=>item.id===route.id?{...route,markerIds:[...route.markerIds]}:item)});
}
export function deleteMapMarker(maps:ProjectMaps,mapId:string,markerId:string):ProjectMaps{
 const map=maps.maps.find(map=>map.id===mapId);if(!map?.markers.some(marker=>marker.id===markerId))return maps;
 return updateMap(maps,{...map,markers:map.markers.filter(marker=>marker.id!==markerId),...(map.routes?{routes:map.routes.map(route=>({...route,markerIds:route.markerIds.filter(id=>id!==markerId)})).filter(route=>route.markerIds.length>=2)}:{})});
}
export function routePoints(route:MapRoute,markers:MapMarker[]):string{
 const byId=new Map(markers.map(marker=>[marker.id,marker]));if(route.markerIds.some(id=>!byId.has(id)))return '';return route.markerIds.map(id=>byId.get(id)).filter((marker):marker is MapMarker=>!!marker).map(marker=>`${marker.x*1000},${marker.y*1000}`).join(' ');
}

export type MapLayer={id:string;title:string;visible:boolean;locked?:boolean};
export function mapLayerVisible(map:WorldMap,layerId?:string):boolean{return !layerId||map.layers?.find(layer=>layer.id===layerId)?.visible!==false;}
export function visibleLayerMarkers(map:WorldMap,markers:MapMarker[]):MapMarker[]{return markers.filter(marker=>mapLayerVisible(map,marker.layerId));}
export function addMapLayer(maps:ProjectMaps,mapId:string,title:string):{maps:ProjectMaps;layerId:string}|null{
 const map=maps.maps.find(m=>m.id===mapId);if(!map||!title.trim())return null;
 const layer={id:crypto.randomUUID(),title:title.trim(),visible:true};
 return {maps:updateMap({...maps,schemaVersion:maps.schemaVersion>=3?maps.schemaVersion:3},{...map,layers:[...(map.layers??[]),layer]}),layerId:layer.id};
}
export function setMapLayerVisible(maps:ProjectMaps,mapId:string,layerId:string,visible:boolean):ProjectMaps{
 const map=maps.maps.find(m=>m.id===mapId);if(!map?.layers?.some(l=>l.id===layerId))return maps;
 return updateMap(maps,{...map,layers:map.layers.map(l=>l.id===layerId?{...l,visible}:l)});
}
export function removeMapLayer(maps:ProjectMaps,mapId:string,layerId:string):ProjectMaps{
 const map=maps.maps.find(m=>m.id===mapId);if(!map?.layers?.some(l=>l.id===layerId))return maps;
 return updateMap(maps,{...map,layers:map.layers.filter(l=>l.id!==layerId),...(map.regions?{regions:map.regions.map(region=>region.layerId===layerId?{...region,layerId:undefined}:region)}:{}),...(map.drawing?{drawing:{...map.drawing,strokes:map.drawing.strokes.map(s=>s.layerId===layerId?{...s,layerId:undefined}:s),objects:map.drawing.objects.map(o=>o.layerId===layerId?{...o,layerId:undefined}:o)}}:{}),markers:map.markers.map(m=>m.layerId===layerId?{...m,layerId:undefined}:m),...(map.routes?{routes:map.routes.map(r=>r.layerId===layerId?{...r,layerId:undefined}:r)}:{})});
}

export type MapScale={from:{x:number;y:number};to:{x:number;y:number};aspectRatio:number;distanceKm:number;travelKmPerDay:number};
export function scaledDistance(scale:MapScale,a:{x:number;y:number},b:{x:number;y:number}):number {
 const length=(a:{x:number;y:number},b:{x:number;y:number})=>Math.hypot((b.x-a.x)*scale.aspectRatio,b.y-a.y);
 const reference=length(scale.from,scale.to);
 return reference>0?length(a,b)/reference*scale.distanceKm:0;
}
export function routeDistances(map:WorldMap,route:MapRoute):number[]|null {
 if(!map.scale)return null;
 const stops=route.markerIds.map(id=>map.markers.find(m=>m.id===id));
 if(stops.some(m=>!m))return null;
 return stops.slice(1).map((stop,index)=>scaledDistance(map.scale!,stops[index]!,stop!));
}

export function linkRouteTarget(maps:ProjectMaps,mapId:string,routeId:string,kind:'scene'|'chapter',id:string,linked:boolean):ProjectMaps {
 const map=maps.maps.find(m=>m.id===mapId),route=map?.routes?.find(r=>r.id===routeId);
 if(!map||!route||!id)return maps;
 const key=kind==='scene'?'sceneIds':'chapterIds',ids=route[key]??[];
 return updateMapRoute({...maps,schemaVersion:maps.schemaVersion>=5?maps.schemaVersion:5},mapId,{...route,[key]:linked?Array.from(new Set([...ids,id])):ids.filter(value=>value!==id)});
}

export function mapLayerLocked(map:WorldMap,layerId?:string){return !!layerId&&map.layers?.find(layer=>layer.id===layerId)?.locked===true;}
export function setMapLayerLocked(maps:ProjectMaps,mapId:string,layerId:string,locked:boolean):ProjectMaps{
 const map=maps.maps.find(map=>map.id===mapId);if(!map?.layers?.some(layer=>layer.id===layerId))return maps;
 return updateMap({...maps,schemaVersion:maps.schemaVersion>=11?maps.schemaVersion:11},{...map,layers:map.layers.map(layer=>layer.id===layerId?{...layer,locked}:layer)});
}

// Stored back to front: later layers are painted above earlier layers.
export function reorderMapLayers(layers:MapLayer[],id:string,direction:'up'|'down'):MapLayer[]{
 const index=layers.findIndex(layer=>layer.id===id),target=index+(direction==='up'?1:-1);
 if(index<0||target<0||target>=layers.length)return layers;
 const next=[...layers];[next[index],next[target]]=[next[target],next[index]];return next;
}

export function trashMap(maps:ProjectMaps,id:string,now=Date.now()):ProjectMaps {
 const map=maps.maps.find(item=>item.id===id);if(!map)return maps;
 return {...maps,schemaVersion:maps.schemaVersion>=16?maps.schemaVersion:16,maps:maps.maps.filter(item=>item.id!==id),trash:[...(maps.trash??[]),{map,deletedAt:now}]};
}
export function restoreMap(maps:ProjectMaps,id:string):ProjectMaps {
 const item=maps.trash?.find(item=>item.map.id===id);if(!item||maps.maps.some(map=>map.id===id))return maps;
 return {...maps,maps:[...maps.maps,item.map],trash:maps.trash?.filter(item=>item.map.id!==id)};
}
export function permanentlyRemoveMap(maps:ProjectMaps,id:string):ProjectMaps {
 return maps.trash?.some(item=>item.map.id===id)?{...maps,trash:maps.trash.filter(item=>item.map.id!==id)}:maps;
}
