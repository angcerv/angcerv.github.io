import {Pencil,Trash2} from 'lucide-react';
import FieldHelp from './FieldHelp';
import {t} from './i18n';
export default function CalendarElementList({items,onEdit,onRemove}:{items:{name:string;details?:string;description?:string;error?:string;removable?:boolean}[];onEdit:(index:number)=>void;onRemove:(index:number)=>void}){
 return <div className="calendar-element-list">{items.map((item,index)=><div className="calendar-element-row" key={index}><div className="calendar-element-copy"><strong>{item.name}</strong>{item.details&&<small>{item.details}</small>}{item.error&&<p className="prompt-error" role="alert">{item.error}</p>}</div>{item.description&&<FieldHelp label={t('About {0}',item.name)} description={item.description}/>}<button type="button" className="quick-action" title={t('Edit {0}',item.name)} aria-label={t('Edit {0}',item.name)} onClick={()=>onEdit(index)}><Pencil size={15}/></button><button type="button" className="quick-action destructive-action" disabled={item.removable===false} title={t('Remove {0}',item.name)} aria-label={t('Remove {0}',item.name)} onClick={()=>onRemove(index)}><Trash2 size={15}/></button></div>)}</div>;
}
