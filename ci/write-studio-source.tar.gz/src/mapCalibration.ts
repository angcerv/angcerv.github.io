import type {MapScale} from './maps';
export type CalibrationReference=Pick<MapScale,'from'|'to'|'aspectRatio'>;
export type CalibrationEnd='from'|'to';
export function initialCalibration(scale:MapScale|undefined,aspectRatio?:number):CalibrationReference{
 return scale?{from:{...scale.from},to:{...scale.to},aspectRatio:scale.aspectRatio}:{from:{x:.25,y:.5},to:{x:.75,y:.5},aspectRatio:aspectRatio??1};
}
export function validCalibration(reference:CalibrationReference){
 const points=[reference.from,reference.to];
 return Number.isFinite(reference.aspectRatio)&&reference.aspectRatio>0&&points.every(p=>Number.isFinite(p.x)&&Number.isFinite(p.y)&&p.x>=0&&p.x<=1&&p.y>=0&&p.y<=1)&&(reference.from.x!==reference.to.x||reference.from.y!==reference.to.y);
}
export function moveCalibrationEnd(reference:CalibrationReference,end:CalibrationEnd,point:{x:number;y:number}):CalibrationReference{
 if(!Number.isFinite(point.x)||!Number.isFinite(point.y))return reference;
 return {...reference,[end]:{x:Math.max(0,Math.min(1,point.x)),y:Math.max(0,Math.min(1,point.y))}};
}
