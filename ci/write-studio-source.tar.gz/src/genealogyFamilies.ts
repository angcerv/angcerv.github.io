import type {GraphPoint} from './relationGraph';
type Parent={parentId:string;childId:string;lineage:string;link:{id:string}};
/** Collapsing couples for layout must never create a generation cycle. */
export function familyGenerations(ids:string[],parents:{parentId:string;childId:string}[],partners:{sourceId:string;targetId:string}[],siblings:{sourceId:string;targetId:string}[]=[]){
 let unit=new Map(ids.map(id=>[id,id]));
 function levels(map:Map<string,string>){
  const units=[...new Set(map.values())],children=new Map(units.map(id=>[id,new Set<string>()])),degree=new Map(units.map(id=>[id,0])),generation=new Map(units.map(id=>[id,0]));
  for(const edge of parents){const a=map.get(edge.parentId),b=map.get(edge.childId);if(!a||!b)continue;if(a===b)return null;if(!children.get(a)!.has(b)){children.get(a)!.add(b);degree.set(b,degree.get(b)!+1);}}
  const queue=units.filter(id=>!degree.get(id));for(let i=0;i<queue.length;i++)for(const child of children.get(queue[i])!){generation.set(child,Math.max(generation.get(child)!,generation.get(queue[i])!+1));degree.set(child,degree.get(child)!-1);if(!degree.get(child))queue.push(child);}
  return queue.length===units.length?generation:null;
 }
 const hasCycle=!levels(unit);
 for(const pair of [...partners].sort((a,b)=>[a.sourceId,a.targetId].sort().join(':').localeCompare([b.sourceId,b.targetId].sort().join(':')))){
  const a=unit.get(pair.sourceId),b=unit.get(pair.targetId);if(!a||!b||a===b)continue;
  const candidate=new Map([...unit].map(([id,group])=>[id,group===b?a:group]));if(levels(candidate))unit=candidate;
 }
 const coupleUnit=unit;
 for(const pair of siblings){const a=unit.get(pair.sourceId),b=unit.get(pair.targetId);if(!a||!b||a===b)continue;const candidate=new Map([...unit].map(([id,group])=>[id,group===b?a:group]));if(levels(candidate))unit=candidate;}
 const byUnit=levels(unit);
 const generations=new Map(ids.map(id=>[id,byUnit?.get(unit.get(id)!)??0]));
 return {generations,unit:coupleUnit,hasCycle};
}
/** Sibling branches group exact recorded parent sets, not surnames or couples. */
export function genealogyFamilies(parents:Parent[],positions:Record<string,GraphPoint>,allParents:Parent[]=parents){
 const registered=new Map<string,Set<string>>();for(const edge of allParents){if(!registered.has(edge.childId))registered.set(edge.childId,new Set());registered.get(edge.childId)!.add(edge.parentId);}
 const byChild=new Map<string,Parent[]>();for(const edge of parents)byChild.set(edge.childId,[...(byChild.get(edge.childId)??[]),edge]);
 const groups=new Map<string,{key:string;parentIds:string[];children:{id:string;edges:Parent[]}[]}>();
 for(const [child,edges] of byChild){const parentIds=[...new Set(edges.map(edge=>edge.parentId))].sort(),key=JSON.stringify([...(registered.get(child)??[])].sort());if(!positions[child]||parentIds.some(id=>!positions[id]))continue;
  const group=groups.get(key)??{key,parentIds,children:[]};group.children.push({id:child,edges});groups.set(key,group);
 }
 const lanes=new Map<string,string[]>();
 for(const group of groups.values()){const top=Math.max(...group.parentIds.map(id=>positions[id].y+32)),bottom=Math.min(...group.children.map(child=>positions[child.id].y-32)),band=JSON.stringify([top,bottom]);lanes.set(band,[...(lanes.get(band)??[]),group.key].sort());}
 return [...groups.values()].map(group=>{
  const all=[...group.parentIds,...group.children.map(child=>child.id)],top=Math.max(...group.parentIds.map(id=>positions[id].y+32)),bottom=Math.min(...group.children.map(child=>positions[child.id].y-32)),band=lanes.get(JSON.stringify([top,bottom]))!,railY=top+(bottom-top)*(band.indexOf(group.key)+1)/(band.length+1);
  const left=Math.min(...all.map(id=>positions[id].x)),right=Math.max(...all.map(id=>positions[id].x));
  const trunk=`M ${left} ${railY} H ${right} `+group.parentIds.map(id=>`M ${positions[id].x} ${positions[id].y+32} V ${railY}`).join(' ');
  return {...group,railY,trunk,children:group.children.map(child=>({...child,path:`M ${positions[child.id].x} ${railY} V ${positions[child.id].y-32}`}))};
 });
}

/** Stable path ordering makes chain couples adjacent without inventing partners. */
export function orderCoupleMembers(ids:string[],partners:{sourceId:string;targetId:string}[]){
 const allowed=new Set(ids),adjacent=new Map(ids.map(id=>[id,new Set<string>()]));for(const pair of partners)if(allowed.has(pair.sourceId)&&allowed.has(pair.targetId)){adjacent.get(pair.sourceId)!.add(pair.targetId);adjacent.get(pair.targetId)!.add(pair.sourceId);}
 const remaining=new Set([...ids].sort()),result:string[]=[];
 while(remaining.size){const last=result[result.length-1],neighbors=last?[...adjacent.get(last)!].filter(id=>remaining.has(id)):[];const next=(neighbors.length?neighbors:[...remaining]).sort((a,b)=>adjacent.get(a)!.size-adjacent.get(b)!.size||a.localeCompare(b))[0];remaining.delete(next);result.push(next);}
 return result;
}
