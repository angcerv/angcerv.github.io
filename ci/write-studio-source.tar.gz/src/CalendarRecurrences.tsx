import {Plus} from 'lucide-react';
import CalendarElementList from './CalendarElementList';
import {t} from './i18n';
import {validCalendarOccurrence} from './storyCalendar';
import type {StoryCalendar,CalendarHoliday} from './storyCalendar';
import type {CalendarElementRequest} from './calendarElementDraft';
export default function CalendarRecurrences({calendar,onChange,onEdit,sectionIds}:{sectionIds?:{seasons:string;holidays:string};calendar:StoryCalendar;onChange:(patch:Partial<StoryCalendar>)=>void;onEdit:(request:CalendarElementRequest)=>void}){
 function rows(kind:'seasons'|'holidays'){
  const items=calendar[kind]??[],holiday=kind==='holidays';
  return <section id={sectionIds?.[kind]} data-calendar-section={sectionIds?'':undefined}><h3>{t(holiday?'Holidays':'Seasons')}</h3><p>{t(holiday?'Holidays repeat each year and may span several days, including the next year. February 29 occurs only in leap years.':'Each season begins on its annual start date and lasts until the next season. The last season continues into the next year.')}</p><CalendarElementList items={items.map(item=>({name:item.name,description:item.description,details:`${item.day} ${calendar.months[item.month-1]?.name??t('Missing month')}${holiday?` · ${t('{0} days',(item as CalendarHoliday).duration)}`:''}`,error:validCalendarOccurrence(item,calendar,holiday)?undefined:t(holiday?'This date does not exist in the calendar. Choose a valid month and day.':'Season starts must be valid every year. Choose a valid month and day.')}))} onEdit={index=>onEdit({kind,index})} onRemove={index=>onChange({[kind]:items.filter((_,i)=>i!==index)})}/><button type="button" className="quick-action quick-action-text" disabled={items.length>=(holiday?256:32)} onClick={()=>onEdit({kind})}><Plus size={15}/>{t(holiday?'Add holiday':'Add season')}</button></section>;
 }
 return <>{rows('seasons')}{rows('holidays')}</>;
}
