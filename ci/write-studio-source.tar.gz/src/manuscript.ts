import type { Project, Scene } from './model';

// Structural edits only change ordering and ownership. IDs and scene content stay intact.
export function moveChapter(project: Project, chapterId: string, direction: -1 | 1): Project {
  const index = project.chapters.findIndex(chapter => chapter.id === chapterId);
  const destination = index + direction;
  if (index < 0 || destination < 0 || destination >= project.chapters.length) return project;
  const chapters = [...project.chapters];
  [chapters[index], chapters[destination]] = [chapters[destination], chapters[index]];
  return { ...project, chapters };
}
export function moveScene(project: Project, sceneId: string, direction: -1 | 1): Project {
  const chapter = project.chapters.find(item => item.scenes.some(scene => scene.id === sceneId));
  if (!chapter) return project;
  const index = chapter.scenes.findIndex(scene => scene.id === sceneId);
  const destination = index + direction;
  if (destination < 0 || destination >= chapter.scenes.length) return project;
  const scenes = [...chapter.scenes];
  [scenes[index], scenes[destination]] = [scenes[destination], scenes[index]];
  return { ...project, chapters: project.chapters.map(item => item.id === chapter.id ? { ...item, scenes } : item) };
}
export function transferScene(project: Project, sceneId: string, chapterId: string): Project {
  const source = project.chapters.find(chapter => chapter.scenes.some(scene => scene.id === sceneId));
  const target = project.chapters.find(chapter => chapter.id === chapterId);
  const scene = source?.scenes.find(item => item.id === sceneId);
  if (!source || !target || !scene || source.id === target.id) return project;
  return { ...project, chapters: project.chapters.map(chapter => {
    if (chapter.id === source.id) return { ...chapter, scenes: chapter.scenes.filter(item => item.id !== sceneId) };
    if (chapter.id === target.id) return { ...chapter, scenes: [...chapter.scenes, scene] };
    return chapter;
  }) };
}

// Resolve the scene by its stable ID, regardless of which editor is currently active.
export function patchScene(project:Project,sceneId:string,patch:Partial<Omit<Scene,'id'>>):Project {
 const chapter=project.chapters.find(chapter=>chapter.scenes.some(scene=>scene.id===sceneId));if(!chapter)return project;
 return {...project,chapters:project.chapters.map(item=>item.id===chapter.id?{...item,scenes:item.scenes.map(scene=>scene.id===sceneId?{...scene,...patch}:scene)}:item)};
}

// Move a scene before a stable destination ID (or to the chapter's end).
export function placeScene(project:Project,sceneId:string,chapterId:string,beforeId=''):Project{
 const source=project.chapters.find(c=>c.scenes.some(s=>s.id===sceneId)),target=project.chapters.find(c=>c.id===chapterId),scene=source?.scenes.find(s=>s.id===sceneId);
 if(!source||!target||!scene||beforeId===sceneId||(beforeId&&!target.scenes.some(s=>s.id===beforeId)))return project;
 const remaining=target.scenes.filter(s=>s.id!==sceneId),index=beforeId?remaining.findIndex(s=>s.id===beforeId):remaining.length;
 const scenes=[...remaining.slice(0,index),scene,...remaining.slice(index)];
 if(source.id===target.id&&scenes.every((s,i)=>s===target.scenes[i]))return project;
 return {...project,chapters:project.chapters.map(c=>c.id===target.id?{...c,scenes}:c.id===source.id?{...c,scenes:c.scenes.filter(s=>s.id!==sceneId)}:c)};
}
