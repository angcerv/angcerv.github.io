import type { Chapter } from './model';
import type { Worldbuilding } from './worldbuilding';
import { sceneMentions } from './mentionDetection';
/** Manuscript order, with manual and confirmed text references combined once per scene. */
export function entryAppearances(chapters:Chapter[],world:Worldbuilding,entryId:string){
 const groups=chapters.map(chapter=>({chapter,scenes:chapter.scenes.flatMap(scene=>{
  const mentions=sceneMentions(scene,world).filter(mention=>mention.entryIds.length===1&&mention.entryIds[0]===entryId);
  const manual=!!scene.entryIds?.includes(entryId);
  return manual||mentions.length?[{scene,manual,mentions}]:[];
 })})).filter(group=>group.scenes.length>0);
 return {groups,chapterCount:groups.length,sceneCount:groups.reduce((sum,group)=>sum+group.scenes.length,0),mentionCount:groups.reduce((sum,group)=>sum+group.scenes.reduce((count,item)=>count+item.mentions.length,0),0)};
}
