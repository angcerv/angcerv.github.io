import type {ReactNode} from 'react';
import {useLayoutEffect,useRef,useState} from 'react';

export default function GraphConnectionLabel({text,x,y,icon}:{text:string;x:number;y:number;icon?:ReactNode}){
 const label=useRef<SVGTextElement>(null),[width,setWidth]=useState(()=>Math.max(40,Array.from(text).length*8+18+(icon?22:0)));
 useLayoutEffect(()=>{const measured=label.current?.getComputedTextLength();if(measured&&Number.isFinite(measured))setWidth(Math.ceil(measured)+18+(icon?22:0));},[text,!!icon]);
 return <g className="relation-graph-label" transform={`translate(${x} ${y})`}><rect x={-width/2} y={-13} width={width} height={26} rx={icon?6:13}/>{icon&&<g className="relation-label-icon" transform={`translate(${-width/2+8} -8)`}>{icon}</g>}<text ref={label} x={icon?-width/2+30:0} textAnchor={icon?'start':'middle'} dominantBaseline="central">{text}</text></g>;
}
