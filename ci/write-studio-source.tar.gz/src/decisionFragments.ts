import type {JSONContent} from '@tiptap/react';
import {fromMarkdown} from './model';
import type {Chapter} from './model';
import {longTextDocument} from './longText';
import type {Worldbuilding} from './worldbuilding';
import type {ProjectPlots} from './plotThreads';
export type DecisionFragment={id:string;kind:'entry'|'scene'|'plot';targetId:string;fieldId?:string;quote:string;prefix:string;suffix:string};
export type FragmentRequest={fragment:DecisionFragment;token:number};
export type FragmentSource={key:string;kind:DecisionFragment['kind'];targetId:string;fieldId?:string;title:string;text:string;positions?:{from:number;to:number}[]};
/** Preserve document positions including marks, hard breaks, paragraphs and inline references. */
export function fragmentDocumentIndex(doc:JSONContent){
 let text='';const positions:{from:number;to:number}[]=[];
 function append(value:string,pos:number,size?:number){for(let i=0;i<value.length;i++){text+=value[i];positions.push({from:pos+(size===undefined?i:0),to:pos+(size===undefined?i+1:size)});}}
 function size(node:JSONContent):number{return node.type==='text'?(node.text?.length??0):node.type==='hardBreak'||node.type==='entryMention'?1:2+(node.content??[]).reduce((n,c)=>n+size(c),0);}
 function walk(node:JSONContent,pos:number){
  if(node.type==='text'){append(node.text??'',pos);return;}
  if(node.type==='hardBreak'){append('\n',pos,1);return;}
  if(node.type==='entryMention'){append(String(node.attrs?.label??''),pos,1);return;}
  if(['paragraph','heading'].includes(node.type??'')&&text.length)append('\n',pos,0);
  let offset=node.type==='doc'?pos:pos+1;for(const child of node.content??[]){walk(child,offset);offset+=size(child);}
 }
 walk(doc,0);return {text,positions};
}
export function fragmentSources(world:Worldbuilding,chapters:Chapter[],plots?:ProjectPlots):FragmentSource[]{
 const result:FragmentSource[]=[];
 for(const entry of world.entries){const template=world.templates.find(t=>t.id===entry.templateId);for(const field of template?.fields??[]){const value=entry.values[field.id];if(!['shortText','longText'].includes(field.fieldType)||typeof value!=='string'||!value.trim())continue;const index=field.fieldType==='longText'?fragmentDocumentIndex(longTextDocument(value)):{text:value};result.push({key:`entry:${entry.id}:${field.id}`,kind:'entry',targetId:entry.id,fieldId:field.id,title:`${entry.title} · ${field.label}`, ...index});}}
 for(const chapter of chapters)for(const scene of chapter.scenes){const index=fragmentDocumentIndex(fromMarkdown(scene.content));if(index.text.trim())result.push({key:`scene:${scene.id}`,kind:'scene',targetId:scene.id,title:`${chapter.title} / ${scene.title}`,...index});}
 for(const plot of plots?.threads??[]){const index=fragmentDocumentIndex(longTextDocument(plot.notes));if(index.text.trim())result.push({key:`plot:${plot.id}`,kind:'plot',targetId:plot.id,title:plot.title,...index});}
 return result;
}
export function sourceForFragment(sources:FragmentSource[],fragment:DecisionFragment){return sources.find(source=>source.kind===fragment.kind&&source.targetId===fragment.targetId&&source.fieldId===fragment.fieldId);}
export function locateFragment(text:string,fragment:Pick<DecisionFragment,'quote'|'prefix'|'suffix'>):{from:number;to:number}|undefined{
 if(!fragment.quote)return;const matches:number[]=[];let start=0;
 while(start<=text.length){const at=text.indexOf(fragment.quote,start);if(at<0)break;matches.push(at);start=at+1;}
 const contextual=matches.filter(at=>(!fragment.prefix||text.slice(Math.max(0,at-fragment.prefix.length),at)===fragment.prefix)&&(!fragment.suffix||text.slice(at+fragment.quote.length,at+fragment.quote.length+fragment.suffix.length)===fragment.suffix));
 const at=contextual.length===1?contextual[0]:matches.length===1?matches[0]:undefined;return at===undefined?undefined:{from:at,to:at+fragment.quote.length};
}
export function fragmentRange(source:FragmentSource,fragment:DecisionFragment){const match=locateFragment(source.text,fragment);if(!match)return;return source.positions?{from:source.positions[match.from].from,to:source.positions[match.to-1].to}:match;}
export function makeFragment(source:FragmentSource,from:number,to:number):DecisionFragment|undefined{
 if(from<0||to<=from||to>source.text.length||to-from>10000||!source.text.slice(from,to).trim())return;
 return {id:crypto.randomUUID(),kind:source.kind,targetId:source.targetId,...(source.fieldId?{fieldId:source.fieldId}:{}),quote:source.text.slice(from,to),prefix:source.text.slice(Math.max(0,from-40),from).replace(/^[\uDC00-\uDFFF]/u,''),suffix:source.text.slice(to,to+40).replace(/[\uD800-\uDBFF]$/u,'')};
}

export function focusDocumentFragment(editor:import('@tiptap/react').Editor,fragment:DecisionFragment,sourceIndex?:ReturnType<typeof fragmentDocumentIndex>):boolean{
 const index=sourceIndex??fragmentDocumentIndex(editor.getJSON()),range=fragmentRange({key:'',kind:fragment.kind,targetId:fragment.targetId,title:'',...index},fragment);
 if(!range)return false;
 for(let parent=editor.view.dom.parentElement;parent;parent=parent.parentElement)if(parent instanceof HTMLDetailsElement)parent.open=true;
 editor.chain().focus().setTextSelection(range).scrollIntoView().run();return true;
}

const handledFragmentRequests=new WeakSet<FragmentRequest>();
export function applyFragmentRequest(request:FragmentRequest,apply:()=>boolean){if(!handledFragmentRequests.has(request)&&apply())handledFragmentRequests.add(request);}
