/** Limited thematic palettes. Material identity is independent of application/theme colors. */
export const terrainMaterials={
 sea:{label:'Sea',color:'#408599',dark:'#2b6478',light:'#78a9b3',seed:11},
 earth:{label:'Earth',color:'#ad9670',dark:'#8c7552',light:'#c1ad88',seed:23},
 sand:{label:'Sand',color:'#dbc38c',dark:'#b79d68',light:'#eddbac',seed:37},
 grass:{label:'Grass',color:'#819565',dark:'#526d44',light:'#a3b17f',seed:41},
 rock:{label:'Rock',color:'#98988a',dark:'#646c60',light:'#bcbdae',seed:53},
 mud:{label:'Mud',color:'#867055',dark:'#5e4e3c',light:'#a18a68',seed:67},
 pavement:{label:'Ground',color:'#d8d4ca',dark:'#a2a49f',light:'#eeeae0',seed:79},
 cityWater:{label:'Water',color:'#9bcad9',dark:'#6098ad',light:'#d1e7e9',seed:83},
 park:{label:'Parks',color:'#a5c29b',dark:'#6e9269',light:'#d0ddbc',seed:89},
 asphalt:{label:'Streets',color:'#717b85',dark:'#505c67',light:'#bac2c4',seed:97},
 alloy:{label:'Ground',color:'#44576d',dark:'#2d4054',light:'#8599ac',seed:101},
 canal:{label:'Water',color:'#276a81',dark:'#1b4b65',light:'#70b4c2',seed:107},
 district:{label:'Urban zones',color:'#677294',dark:'#464f72',light:'#a1acc4',seed:109},
 transit:{label:'Transit ways',color:'#57b9c6',dark:'#317e91',light:'#c4e1da',seed:127},
 nebula:{label:'Nebulae',color:'#5f417b',dark:'#3e2b59',light:'#ad83b7',seed:131},
 spaceRegion:{label:'Space regions',color:'#253d66',dark:'#182b4b',light:'#7093ba',seed:137},
 deepSpace:{label:'Deep space',color:'#101629',dark:'#17223a',light:'#9eb3cf',seed:139},
} as const;
export type TerrainMaterial=keyof typeof terrainMaterials;
export function isTerrainMaterial(value:unknown):value is TerrainMaterial{return typeof value==='string'&&Object.prototype.hasOwnProperty.call(terrainMaterials,value);}
const n=(value:number)=>Number(value.toFixed(3));
export function textureIntensity(value=.75){return Number.isFinite(value)?Math.max(0,Math.min(1,value)):.75;}
/** Uniform map-space detail scale, never brush/gesture/zoom dependent. */
export function materialScale(width:number,height:number){return n(Math.max(.5,Math.min(2,Math.min(width,height)/1000)));}
function randomSource(seed:number){return ()=>{seed=(Math.imul(seed,1664525)+1013904223)>>>0;return seed/4294967296;};}
const motifSize=448,grainSize=577,toneSize=733;
/** Copy only motifs crossing a tile boundary; opposite edges therefore join exactly. */
function wrapped(x:number,y:number,radius:number,size:number,art:string,rotation=0){
 const copies:string[]=[];
 for(const dx of [0,...(x<radius?[size]:[]),...(x>size-radius?[-size]:[])])for(const dy of [0,...(y<radius?[size]:[]),...(y>size-radius?[-size]:[])]){
  copies.push(`<g transform="translate(${n(x+dx)} ${n(y+dy)}) rotate(${n(rotation)})">${art}</g>`);
 }
 return copies.join('');
}
function motifs(kind:TerrainMaterial){
 const material=terrainMaterials[kind],random=randomSource(material.seed),items:string[]=[];
 const count={sea:48,earth:84,sand:58,grass:100,rock:60,mud:56,pavement:70,cityWater:48,park:64,asphalt:68,alloy:72,canal:56,district:64,transit:48,nebula:38,spaceRegion:40,deepSpace:74}[kind];
 const columns=Math.ceil(Math.sqrt(count)),rows=Math.ceil(count/columns),{dark,light,color}=material;
 for(let i=0;i<count;i++){
  const x=((i%columns)+.15+random()*.7)*motifSize/columns,y=(Math.floor(i/columns)+.15+random()*.7)*motifSize/rows;
  const r=n(6+random()*8),wide=n(12+random()*10),height=n(2+random()*2);
  let art:string,rotation=0;
  if(kind==='sea'||kind==='cityWater'||kind==='canal'){
   art=`<g data-atlas-detail="waves" stroke="none"><path d="M-${wide} 1q${wide} -${height*2} ${wide*2} 0q-${wide} ${height+2} -${wide*2} 0Z" fill="${dark}" opacity=".19"/><path d="M-${wide} -1q${wide} -${height} ${wide*2} 0" fill="none" stroke="${light}" stroke-width="1.4" stroke-linecap="round" opacity=".63"/><path d="M-${n(wide*.6)} 4q${n(wide*.6)} -2 ${n(wide*1.2)} 0" fill="none" stroke="${light}" stroke-width=".65" opacity=".38"/>${i%4===0?`<path d="m-5 -5 6-1m4 1 3 0" stroke="${light}" stroke-width=".7" opacity=".6"/>`:''}</g>`;
   rotation=-6+random()*12;
  }else if(kind==='sand'){
   art=`<g data-atlas-detail="dunes" stroke="none"><path d="M-${wide} 5Q0 -${r} ${wide} 2Q4 4 -${wide} 5Z" fill="${dark}" opacity=".28"/><path d="M-${wide} 5Q0 -${r} ${wide} 2Q0 -${n(r*.35)} -${wide} 5Z" fill="${light}" opacity=".75"/><path d="M-${n(wide*.6)} 9q${n(wide*.7)} -4 ${n(wide*1.4)} -1m-${wide} 4 10-1" fill="none" stroke="${dark}" stroke-width=".65" opacity=".36"/></g>`;rotation=-14+random()*28;
  }else if(kind==='grass'||kind==='park'){
   art=`<g data-atlas-detail="blades" stroke="none"><path d="M-12 5q-2-7 7-9 5-6 12 0 9 2 6 8-6 5-13 1-8 4-12 0Z" fill="${dark}" opacity=".16"/><path d="M-11 1q5-6 10-4t9 2q-6 0-10 4Z" fill="${light}" opacity=".52"/><path d="M-6 5q-1-6-5-7m6 7q0-8 3-11m0 11q3-6 6-7m-2 8q3-4 7-5" fill="none" stroke="${dark}" stroke-width=".8" opacity=".62"/><path d="M-5 3q0-4 1-5m6 6 2-3" stroke="${light}" stroke-width="1.1"/>${kind==='park'&&i%5===0?`<circle cx="9" cy="-3" r="1.1" fill="${light}"/>`:''}</g>`;rotation=-22+random()*44;
  }else if(kind==='rock'){
   art=`<g data-atlas-detail="facets" stroke="${dark}" stroke-width=".65" stroke-linejoin="round"><path d="m-${r} 2 ${n(r*.35)} -${n(r*.85)} ${r} -2 ${n(r*.7)} ${n(r*.8)} -${n(r*.4)} ${n(r*.85)} -${r} 2Z" fill="${color}"/><path d="m-${r} 2 ${n(r*.35)} -${n(r*.85)} ${n(r*.6)} ${n(r*.55)} -${n(r*.2)} ${n(r*.85)}Z" fill="${light}" stroke="none"/><path d="m-${n(r*.05)} -${n(r*.3)} ${n(r*.4)} -${n(r*.7)} ${n(r*.7)} ${n(r*.8)} -${n(r*.4)} ${n(r*.85)}Z" fill="${dark}" opacity=".48" stroke="none"/><path d="m-${n(r*.65)} -${n(r*.85)} ${n(r*.6)} ${n(r*.55)} -${n(r*.2)} ${n(r*.85)}m-${n(r*.9)} 4 3 1m${r} -1 3-1" fill="none" opacity=".55"/></g>`;rotation=-35+random()*70;
  }else if(kind==='mud'){
   art=i%3===0?`<g data-atlas-detail="puddles" stroke="none"><path d="M-${r} 1q-2-5 ${r}-4t${r} 5q-4 4-${r} 2t-${r}-3Z" fill="${dark}" opacity=".34"/><path d="M-${n(r*.7)} 0q${n(r*.7)}-3 ${n(r*1.4)} 0" fill="none" stroke="${light}" stroke-width="1" opacity=".7"/><path d="m0 3 4-1" stroke="${color}" stroke-width="1.5"/></g>`:`<g data-atlas-detail="cracks"><path d="M-${r} 1l${n(r*.7)}-3 ${n(r*.6)} 4 ${n(r*.7)}-2m-${n(r*.7)}-2 2-4" fill="none" stroke="${dark}" stroke-width=".8" opacity=".5"/><path d="m-${r} 2 4-1m4 3 4-1" fill="none" stroke="${light}" stroke-width=".6" opacity=".45"/></g>`;rotation=-30+random()*60;
  }else if(kind==='pavement'||kind==='alloy'||kind==='district'){
   const size=kind==='district'?18:24;
   art=`<g data-atlas-detail="${kind==='pavement'?'paving':kind==='alloy'?'panels':'blocks'}" stroke-width=".7" stroke-linejoin="round"><path d="M-${size}-10h${size*2}v20h-${size*2}Z" fill="${i%3?light:dark}" fill-opacity=".13" stroke="${dark}" stroke-opacity=".45"/><path d="M-${size-1} 9V-9h${size*2-2}" fill="none" stroke="${light}" opacity=".65"/><path d="M0-9v18M-${size} 10h${size*2}" fill="none" stroke="${dark}" opacity=".3"/>${kind==='alloy'?`<path d="M-17-6h9m16 12h9" fill="none" stroke="${light}" opacity=".8"/><circle cx="-20" cy="6" r=".8" fill="${dark}" stroke="none"/>`:kind==='district'?`<path d="M-12-5h7v10h-7Zm17 0h7v10H5Z" fill="${dark}" fill-opacity=".3" stroke="${dark}" stroke-opacity=".4"/><path d="M-11-4h5m12 0h5" stroke="${light}" opacity=".65"/>`:`<path d="m-17 4 4-3 3 2m18-8 4-1" fill="none" stroke="${dark}" opacity=".25"/>`}</g>`;
  }else if(kind==='asphalt'||kind==='transit'){
   art=`<g data-atlas-detail="${kind==='asphalt'?'road-markings':'transit-lanes'}" fill="none" stroke-linecap="round"><path d="M-23-5H23M-23 5H23" stroke="${dark}" stroke-width="1" opacity=".38"/><path d="M-21-4H21" stroke="${light}" stroke-width=".7" opacity=".35"/>${kind==='transit'?`<path d="M-17 0h12m7 0h12" stroke="${light}" stroke-width="1.5" opacity=".75"/><path d="M-18 2h12" stroke="${color}" stroke-width=".6"/>`:i%3===0?`<path d="M-17 0h9m7 0h9" stroke="${light}" stroke-width="1.1" opacity=".5"/>`:`<path d="m-14-1 7 2 4-2 5 3" stroke="${dark}" stroke-width=".6" opacity=".35"/>`}</g>`;
  }else if(kind==='nebula'){
   art=`<g data-atlas-detail="cosmic-clouds" stroke="none"><path d="M-28 7-15-4-2-7 10-3 26-10 20 0 8 5-3 3-16 8Z" fill="${dark}" opacity=".11"/><path d="M-24 1-9-5 2-4 10-6 20-8 11-1 0 0-12-1Z" fill="${light}" opacity=".14"/><circle cx="-8" cy="2" r=".65" fill="${light}" opacity=".7"/><circle cx="18" cy="-10" r=".45" fill="${light}" opacity=".6"/></g>`;rotation=-45+random()*90;
  }else if(kind==='spaceRegion'||kind==='deepSpace'){
   art=`<g data-atlas-detail="${kind==='deepSpace'?'stars':'constellations'}" fill="${light}" stroke="none"><circle r="${n(.5+random()*.6)}" opacity=".85"/><circle cx="12" cy="-9" r=".5" opacity=".45"/>${i%5===0?`<circle r="2.4" opacity=".12"/><path d="M-2.5 0h5M0-2.5v5" stroke="${light}" stroke-width=".5" opacity=".65"/>`:''}${kind==='spaceRegion'?`<path d="M-18 9q7-15 17-6t23-3q-6 15-19 10t-21-1Z" fill="${dark}" opacity=".2"/>`:''}</g>`;rotation=random()*360;
  }else{
   art=`<g data-atlas-detail="soil" stroke="none"><path d="M-10 3q-3-5 3-7 7-3 14 1l4 6-10 2Z" fill="${light}" opacity=".3"/><path d="m-4 0 4-2 4 1-1 4-5 1Z" fill="${dark}" opacity=".4"/><path d="m-4 0 4-2 4 1" fill="none" stroke="${light}" stroke-width=".8"/><ellipse cx="9" cy="6" rx="1.2" ry=".7" fill="${dark}" opacity=".5"/><path d="m-12 7 5-1 4 1" fill="none" stroke="${dark}" stroke-width=".6" opacity=".35"/></g>`;rotation=-30+random()*60;
  }
  if(!['pavement','alloy','district','asphalt','transit'].includes(kind))art=`<g transform="scale(${n(.68+random()*.5)})">${art}</g>`;
  items.push(wrapped(x,y,36,motifSize,art,rotation));
 }
 return items.join('');
}
function grain(kind:TerrainMaterial){
 const {seed,dark,light}=terrainMaterials[kind],random=randomSource(seed+103),items:string[]=[];
 for(let i=0;i<180;i++){
  const x=random()*grainSize,y=random()*grainSize,r=n(.28+random()*.42);
  items.push(wrapped(x,y,2,grainSize,`<ellipse rx="${r}" ry="${n(r*.65)}" fill="${i%3===0?light:dark}" opacity="${kind==='sand'?.5:.24}"/>`));
 }
 return items.join('');
}
function tones(kind:TerrainMaterial){
 const {seed,dark,light}=terrainMaterials[kind],random=randomSource(seed+307),items:string[]=[];
 const water=kind==='sea'||kind==='cityWater'||kind==='canal',cosmic=kind==='nebula'||kind==='deepSpace'||kind==='spaceRegion';
 for(let i=0;i<24;i++){
  const x=random()*toneSize,y=random()*toneSize,rx=n(36+random()*22),ry=n((water?9:cosmic?25:18)+random()*10);
  // Broad paint masses, smaller reflected light and fine motifs use independent periods.
  const art=`<g data-atlas-paint="wash" stroke="none" opacity="${cosmic?.45:1}"><path d="M-${rx} 0Q-${rx} -${ry} -${n(rx*.3)} -${n(ry*.75)}Q${n(rx*.2)} -${n(ry*1.2)} ${rx} -${n(ry*.15)}Q${n(rx*.8)} ${ry} ${n(rx*.2)} ${n(ry*.65)}Q-${n(rx*.4)} ${ry} -${rx} 0Z" fill="${i%2?dark:light}"/><path d="M-${n(rx*.7)} -2Q-${n(rx*.2)} -${n(ry*.8)} ${n(rx*.6)} -${n(ry*.25)}Q${n(rx*.1)} -2 -${n(rx*.7)} -2Z" fill="${light}" opacity=".45"/></g>`;
  items.push(wrapped(x,y,64,toneSize,art,water?-5+random()*10:-30+random()*60));
 }
 return items.join('');
}
export type TexturePlacement={textureScale?:number;textureRotation?:number};
export function textureScaleValue(value=1){return Number.isFinite(value)?Math.max(.25,Math.min(4,value)):1;}
export function textureRotationValue(value=0){return Number.isFinite(value)?((value%360)+360)%360:0;}
export function materialPatternId(kind:TerrainMaterial,placement:TexturePlacement={}){const scale=textureScaleValue(placement.textureScale),rotation=textureRotationValue(placement.textureRotation);return `ws-terrain-${kind}${scale===1&&rotation===0?'':`-s${String(scale).replace('.','_')}-r${String(rotation).replace('.','_')}`}`;}
const artworkCache=new Map<TerrainMaterial,{motifs:string;grain:string;tones:string}>();
const definitionsCache=new Map<string,string>();
export function materialDefinitions(materials:TerrainMaterial[],scale=1,origin?:{x:number;y:number},placement:TexturePlacement={}):string{
 if(!materials.length)return '';
 scale=n(Number.isFinite(scale)?Math.max(.5,Math.min(2,scale)):1);
 const factor=textureScaleValue(placement.textureScale),rotation=textureRotationValue(placement.textureRotation);
 const kinds=[...new Set(materials)].sort(),key=`${kinds.join(',')}:${n(scale)}:${origin?.x??0}:${origin?.y??0}:${factor}:${rotation}`,previous=definitionsCache.get(key);if(previous)return previous;
 const definitions=kinds.map(kind=>{
  let art=artworkCache.get(kind);if(!art){art={motifs:motifs(kind),grain:grain(kind),tones:tones(kind)};artworkCache.set(kind,art);}
  const id=materialPatternId(kind,placement),transform=`patternUnits="userSpaceOnUse" patternTransform="${origin?`translate(${n(origin.x)} ${n(origin.y)}) `:''}${rotation?`rotate(${rotation}) `:''}scale(${n(scale*factor)})"`;
  // Incommensurate tile periods keep small recurring motifs from forming a repeated patch.
  return `<pattern id="${id}-grain" ${transform} width="${grainSize}" height="${grainSize}">${art.grain}</pattern><pattern id="${id}-tone" ${transform} width="${toneSize}" height="${toneSize}">${art.tones}</pattern><pattern id="${id}" ${transform} width="${motifSize}" height="${motifSize}">${art.motifs}</pattern>`;
 }).join('');
 const result=`<defs>${definitions}</defs>`;
 if(definitionsCache.size>=32)definitionsCache.delete(definitionsCache.keys().next().value!);
 definitionsCache.set(key,result);return result;
}
/** Shared by previews and map rendering: intensity never fades or replaces the base. */
export function materialSurface(kind:TerrainMaterial,intensity:number,width:number,height:number,color:string=terrainMaterials[kind].color,origin?:{x:number;y:number},placement:TexturePlacement={}){
 const id=materialPatternId(kind,placement),detail=textureIntensity(intensity),position=origin?` x="${n(origin.x)}" y="${n(origin.y)}"`: '';
 return `<rect${position} width="${n(width)}" height="${n(height)}" fill="${color}"/><rect${position} width="${n(width)}" height="${n(height)}" fill="url(#${id}-tone)" opacity=".16"/>${detail?`<g data-material-detail="${kind}" opacity="${n(detail)}"><rect${position} width="${n(width)}" height="${n(height)}" fill="url(#${id}-grain)"/><rect${position} width="${n(width)}" height="${n(height)}" fill="url(#${id})"/></g>`:''}`;
}
const swatchCache=new Map<string,string>();
export function materialSwatch(kind:TerrainMaterial,intensity=.75,scale=1,color?:string,placement:TexturePlacement={}):string{
 scale=n(Number.isFinite(scale)?Math.max(.5,Math.min(2,scale)):1);
 const key=`${kind}:${textureIntensity(intensity)}:${n(scale)}:${color??''}:${materialPatternId(kind,placement)}`,cached=swatchCache.get(key);if(cached)return cached;
 const width=160*scale,height=96*scale;
 const svg=`<svg xmlns="http://www.w3.org/2000/svg" width="80" height="48" viewBox="0 0 ${n(width)} ${n(height)}">${materialDefinitions([kind],scale,undefined,placement)}${materialSurface(kind,intensity,width,height,color,undefined,placement)}</svg>`;
 const result=`data:image/svg+xml;charset=utf-8,${encodeURIComponent(svg)}`;
 if(swatchCache.size>=128)swatchCache.delete(swatchCache.keys().next().value!);
 swatchCache.set(key,result);return result;
}
