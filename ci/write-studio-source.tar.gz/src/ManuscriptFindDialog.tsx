import {useDeferredValue,useEffect,useMemo,useRef,useState} from 'react';
import {ArrowLeft,ArrowRight,ChevronDown,X} from 'lucide-react';
import Dropdown from './Dropdown';
import {t,message,buttonLabel} from './i18n';
import type {Project} from './model';
import {findManuscript} from './manuscriptSearch';
import type {FindOptions,ManuscriptMatch} from './manuscriptSearch';
export default function ManuscriptSearch({project,sceneId,chapterId,bookId,onClose,onOpen,onReplace}:{project:Project;bookId?:string;sceneId?:string;chapterId?:string;onClose:()=>void;onOpen:(match:ManuscriptMatch)=>void;onReplace:(matches:ManuscriptMatch[],replacement:string)=>void}){
 const panel=useRef<HTMLElement>(null),advance=useRef<{sceneId:string;from:number}|null>(null);
 const [{sceneId:searchSceneId,chapterId:searchChapterId,bookId:searchBookId}]=useState({sceneId,chapterId,bookId});
 const [replaceOpen,setReplaceOpen]=useState(false);
 const openRef=useRef(onOpen);openRef.current=onOpen;
 const [query,setQuery]=useState(''),[replacement,setReplacement]=useState(''),[scope,setScope]=useState<FindOptions['scope']>(sceneId?'scene':chapterId?'chapter':'project'),[caseSensitive,setCase]=useState(false),[wholeWord,setWhole]=useState(false),[index,setIndex]=useState(0),[error,setError]=useState(''),[notice,setNotice]=useState('');
 const deferred=useDeferredValue(query),stale=deferred!==query;
 const matches=useMemo(()=>findManuscript(project,{query:deferred,scope,sceneId:searchSceneId,chapterId:searchChapterId,bookId:searchBookId,caseSensitive,wholeWord}),[project,deferred,scope,searchSceneId,searchChapterId,searchBookId,caseSensitive,wholeWord]);
 const current=Math.min(index,Math.max(0,matches.length-1)),match=matches[current];
 useEffect(()=>{const previous=document.activeElement as HTMLElement|null;panel.current?.querySelector<HTMLElement>('h2')?.focus({preventScroll:true});return()=>{if(previous?.isConnected)previous.focus({preventScroll:true});};},[]);
 useEffect(()=>{if(match&&!stale)openRef.current(match);},[match?.sceneId,match?.from,match?.to,match?.content,stale]);
 useEffect(()=>{
  const target=advance.current;if(!target)return;advance.current=null;
  const scenes=project.chapters.flatMap(chapter=>chapter.scenes),sceneIndex=scenes.findIndex(scene=>scene.id===target.sceneId);
  const next=matches.findIndex(result=>result.sceneId===target.sceneId?result.from>=target.from:scenes.findIndex(scene=>scene.id===result.sceneId)>sceneIndex);
  setIndex(next<0?0:next);
 },[project,matches]);
 function navigate(direction:number){
  if(stale||!matches.length)return;
  const next=(current+direction+matches.length)%matches.length;
  if(next===current)openRef.current(matches[next]);else setIndex(next);
 }
 function replace(all:boolean){
  const selected=(all?matches:match?[match]:[]).filter(result=>result.quote!==replacement);
  if(!selected.length)return;
  try{
   advance.current=!all&&match?{sceneId:match.sceneId,from:match.from+replacement.length}:null;
   onReplace(selected,replacement);setError('');setNotice(t('Replaced {0} matches.',selected.length));
  }catch(e){advance.current=null;setError(message(String(e)));}
 }
 return <section ref={panel} className="manuscript-search" aria-labelledby="manuscript-search-title" onKeyDown={e=>{if(e.key==='Escape'&&!e.defaultPrevented){e.preventDefault();e.stopPropagation();onClose();}}}>
 <h2 className="visually-hidden" tabIndex={-1} id="manuscript-search-title">{t('Find and replace')}</h2>
 <div className="manuscript-find-row">
 <button type="button" className="quick-action manuscript-replace-toggle" aria-label={t('Replace with')} title={t('Replace with')} aria-expanded={replaceOpen} aria-controls="manuscript-replace-panel" onClick={()=>setReplaceOpen(!replaceOpen)}><ChevronDown size={14}/></button> <div className="ui-form-field"><label htmlFor="manuscript-find">{t('Find text')}</label><div className="project-search-input"><input id="manuscript-find" value={query} onChange={e=>{setQuery(e.target.value);setIndex(0);setNotice('');}} onKeyDown={e=>{if(e.key==='Enter'&&!e.nativeEvent.isComposing&&!stale&&matches.length){e.preventDefault();navigate(e.shiftKey?-1:1);}}}/></div></div> <div className="manuscript-find-navigation"><span role="status">{stale?t('Searching…'):query?(matches.length?t('Match {0} of {1}',current+1,matches.length):t('No matching content.')):t('Type to search.')}</span>{([-1,1] as const).map(direction=><button type="button" className="icon-button" key={direction} disabled={stale||!matches.length} aria-label={buttonLabel(direction<0?'Previous match':'Next match')} title={buttonLabel(direction<0?'Previous match':'Next match')} onClick={()=>navigate(direction)}>{direction<0?<ArrowLeft size={16}/>:<ArrowRight size={16}/>}</button>)}</div><button className="icon-button ui-close-button" type="button" aria-label={t('Close')} title={t('Close')} onClick={onClose}><X size={18}/></button></div>
 <div className="manuscript-find-options"> <div className="project-search-filters"><div className="ui-form-field"><label htmlFor="manuscript-find-scope">{t('Search in')}</label><Dropdown id="manuscript-find-scope" value={scope} options={[{value:'scene',label:t('Scene'),disabled:!searchSceneId},{value:'chapter',label:t('Chapter'),disabled:!searchChapterId},...(project.books?.length?[{value:'book',label:t('Current book'),disabled:!searchBookId}]:[]),{value:'project',label:buttonLabel(project.books?.length?'All books':'Entire manuscript')}]} onChange={value=>{setScope(value as FindOptions['scope']);setIndex(0);}}/></div><label><input type="checkbox" checked={caseSensitive} onChange={e=>{setCase(e.target.checked);setIndex(0);}}/>{t('Match case')}</label><label><input type="checkbox" checked={wholeWord} onChange={e=>{setWhole(e.target.checked);setIndex(0);}}/>{t('Whole words')}</label></div> {match&&!stale&&<p className="manuscript-find-location" title={match.title}>{match.title}</p>}</div>
 <div id="manuscript-replace-panel" className="manuscript-replace-panel" data-open={replaceOpen} inert={!replaceOpen} aria-hidden={!replaceOpen}><div><div className="manuscript-replace-row"><div className="ui-form-field"><label htmlFor="manuscript-replacement">{t('Replace with')}</label><div className="project-search-input"><input id="manuscript-replacement" value={replacement} onChange={e=>setReplacement(e.target.value)}/></div></div> <div className="world-form-actions"><button type="button" className="quick-action quick-action-text" disabled={stale||!match||match.quote===replacement} onClick={()=>replace(false)}>{t('Replace match')}</button><button type="button" className="primary-button" disabled={stale||!matches.some(result=>result.quote!==replacement)} onClick={()=>replace(true)}>{t('Replace all ({0})',matches.length)}</button></div>
</div></div></div> {error&&<p className="prompt-error" role="alert">{error}</p>}{notice&&<p className="export-success" role="status">{notice}</p>}
 </section>;
}
