import {useEffect,useRef} from 'react';
import {readProjectResume,rememberProjectResume} from './projectResume';
import type {ProjectResume,ResumeView} from './projectResume';
export function useProjectResume({enabled,ready,blocked,projectId,path,selectedId,view,onResume}:{enabled:boolean;ready:boolean;blocked:boolean;projectId?:string;path:string;selectedId:string;view:ResumeView;onResume:(resume:ProjectResume)=>void}){
 const attempted=useRef(false);
 useEffect(()=>{
  if(!enabled||!ready||blocked||attempted.current)return;
  attempted.current=true;
  if(projectId)return;
  const resume=readProjectResume();if(resume)onResume(resume);
 },[enabled,ready,blocked,projectId,onResume]);
 useEffect(()=>{
  if(enabled&&projectId&&path)rememberProjectResume({projectId,path,selectedId,view});
 },[enabled,projectId,path,selectedId,view]);
}
