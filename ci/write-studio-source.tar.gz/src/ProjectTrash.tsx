import {focusDialog} from './dialogFocus';
import {useLayoutEffect,useRef,useState} from 'react';
import {LayoutGrid,List,RotateCcw,Trash2,Search,Image as ImageIcon,Map as MapIcon} from 'lucide-react';
import type {Worldbuilding} from './worldbuilding';
import type {ProjectMaps} from './maps';
import type {IdeaCanvases} from './ideaCanvas';
import type {TrashItem,TrashSelection} from './visualTrashActions';
import {projectTrashItems,trashKey,applyProjectTrash} from './visualTrashActions';
import {visualResources,visualTrashDays} from './visualResources';
import {visualResourceUsage,visualRemovalProblem} from './visualResourceUsage';
import {VisualResourceDetails,visualUsageSummary} from './VisualResourceDetails';
import {useWorkspaceState} from './useWorkspaceState';
import {EntryPortrait} from './EntryImage';
import ProjectModal from './ProjectModal';
import Dropdown from './Dropdown';
import EntrySection from './EntrySection';
import FieldHelp from './FieldHelp';
import {t,message} from './i18n';
type Props={world:Worldbuilding;maps?:ProjectMaps;ideaCanvases?:IdeaCanvases;projectPath?:string;projectId?:string;onChange:(world:Worldbuilding)=>void;onMapsChange?:(maps:ProjectMaps)=>void;onResourcesChange?:(world:Worldbuilding,maps?:ProjectMaps)=>void;onClose:()=>void};
export default function ProjectTrash({world,maps,ideaCanvases,projectPath,projectId,onChange,onMapsChange,onResourcesChange,onClose}:Props){
 const [pending,setPending]=useState<TrashSelection[]|null>(null),[error,setError]=useState('');
 const pendingOrigin=useRef<HTMLButtonElement|null>(null),items=useRef<HTMLDivElement>(null);
 const [view,setView]=useWorkspaceState<'grid'|'list'>('visual.trash.view','grid'),[query,setQuery]=useState(''),[kind,setKind]=useState('all'),[selection,setSelection]=useState<string[]>([]);
 const all=projectTrashItems(world,maps),byKey=new Map(all.map(item=>[trashKey(item),item]));
 const needle=query.trim().normalize('NFD').replace(/\p{M}/gu,'').toLocaleLowerCase();
 const visible=all.filter(item=>(kind==='all'||item.kind===kind)&&(!needle||[item.title,item.kind==='image'?world.visualResources?.find(resource=>resource.id===item.id)?.originalFilename:''].filter(Boolean).join(' ').normalize('NFD').replace(/\p{M}/gu,'').toLocaleLowerCase().includes(needle)));
 const canEdit=(item:TrashSelection)=>item.kind==='image'||!!onMapsChange||!!onResourcesChange;
 const selected=all.filter(item=>selection.includes(trashKey(item))&&canEdit(item)),visibleEditable=visible.filter(canEdit);
 const allVisible=!!visibleEditable.length&&visibleEditable.every(item=>selection.includes(trashKey(item))),someVisible=visibleEditable.some(item=>selection.includes(trashKey(item)));
 const context={maps,ideaCanvases};
 useLayoutEffect(()=>{if(pending){const dialog=pendingOrigin.current?.closest<HTMLDialogElement>('dialog');if(dialog)focusDialog(dialog,true);return;}if(pendingOrigin.current){if(pendingOrigin.current.isConnected)pendingOrigin.current.focus({preventScroll:true});else items.current?.focus({preventScroll:true});}},[pending]);
 function deletionProblem(targets:TrashSelection[]){
  if(!targets.length)return '';
  try{const next=applyProjectTrash(world,maps,targets,'delete',context);if(next.world!==world&&next.maps!==maps&&!onResourcesChange)return t('Mixed image and map operations are unavailable here.');return '';}
  catch(error){return message(String(error));}
 }
 const bulkProblem=deletionProblem(selected),pendingProblem=pending?deletionProblem(pending):'';
 function perform(targets:TrashSelection[],action:'restore'|'delete'){
  try{
   const next=applyProjectTrash(world,maps,targets,action,context);
   if(next.world!==world&&next.maps!==maps){if(!onResourcesChange)throw new Error(t('Mixed image and map operations are unavailable here.'));onResourcesChange(next.world,next.maps);}
   else if(next.world!==world)onChange(next.world);
   else if(next.maps!==maps){if(onResourcesChange)onResourcesChange(next.world,next.maps);else if(next.maps&&onMapsChange)onMapsChange(next.maps);else throw new Error(t('Maps are unavailable.'));}
   const completed=new Set(targets.map(trashKey));setSelection(current=>current.filter(key=>!completed.has(key)));setError('');setPending(null);
  }catch(error){setError(message(String(error)));}
 }
 function toggle(item:TrashItem){const key=trashKey(item);setSelection(current=>current.includes(key)?current.filter(value=>value!==key):[...current,key]);}
 function confirm(targets:TrashSelection[],origin:HTMLButtonElement){pendingOrigin.current=origin;setError('');setPending(targets.map(({kind,id})=>({kind,id})));}
 const hiddenSelected=selected.filter(item=>!visible.some(visible=>trashKey(visible)===trashKey(item))).length;
 const pendingItems=(pending??[]).map(item=>byKey.get(trashKey(item)));
 return <ProjectModal variant={pending?'confirmation':undefined} title={pending?(pending.length===1?t('Delete permanently?'):t('Delete {0} items permanently?',pending.length)):t('Trash')} titleAccessory={pending?<FieldHelp variant="toolbar" label={t('Delete permanently')} description={t('Files required by history or backups are retained. Your original file is never changed.')}/>:undefined} onClose={()=>pending?setPending(null):onClose()} className="visual-trash-dialog">
 {error&&<p className="prompt-error" role="alert">{error}</p>}
 {pending&&<div className="visual-trash-confirm"><div className="visual-trash-confirm-body">
 <div className="visual-trash-delete-warning"><span className="visual-trash-delete-icon"><Trash2 size={22} aria-hidden="true"/></span><div><p>{t(pending.length===1?'This item will be removed from the project.':'These items will be removed from the project.')}</p><p>{t(pending.length===1?'You cannot restore it from the trash after deletion.':'You cannot restore them from the trash after deletion.')}</p></div></div>
 <div className="visual-trash-delete-counts">{(['image','map'] as const).map(kind=>{const count=pending.filter(item=>item.kind===kind).length,Icon=kind==='image'?ImageIcon:MapIcon;return count>0&&<span key={kind}><Icon size={15} aria-hidden="true"/>{t(kind==='image'?(count===1?'{0} image':'{0} images'):(count===1?'{0} map':'{0} maps'),count)}</span>;})}</div>
 <EntrySection variant="compact" defaultOpen={pending.length===1} title={t('Review selected items')}><div className="visual-trash-delete-list" role="region" aria-label={t('Selected items to delete')} tabIndex={0}><ul>{pendingItems.map((item,index)=>{const Icon=pending[index].kind==='image'?ImageIcon:MapIcon;return <li key={trashKey(pending[index])}><Icon size={17} aria-hidden="true"/><span>{item?.title??t('Missing resource')}</span></li>;})}</ul></div></EntrySection>
 {pendingProblem&&<p className="prompt-error" role="alert">{pendingProblem}</p>}</div><footer><button type="button" onClick={()=>setPending(null)} className="quick-action quick-action-text">{t('Cancel')}</button><button type="button" className="danger-button" disabled={!!pendingProblem} onClick={()=>perform(pending,'delete')}>{t('Delete permanently')}</button></footer></div>}

 <div className="visual-trash-content" hidden={!!pending} inert={!!pending}>
 <div className="visual-trash-info"><p className="world-hint">{t('Deleted images and maps stay here for 30 days. Expired unused items are removed when opening or saving the project.')}</p></div>
 <div className="visual-trash-filters"><div className="ui-form-field visual-library-search"><label htmlFor="visual-trash-search">{t('Search trash')}</label><span><Search size={16} aria-hidden="true"/><input id="visual-trash-search" type="search" value={query} onChange={event=>setQuery(event.target.value)}/></span></div><div className="ui-form-field"><label htmlFor="visual-trash-kind">{t('Resource type')}</label><Dropdown id="visual-trash-kind" value={kind} onChange={setKind} options={[{value:'all',label:t('All items')},{value:'image',label:t('Images')},{value:'map',label:t('Maps')}]}/></div><div className="ui-form-field visual-trash-view"><label id="visual-trash-view-label">{t('Trash view')}</label><div className="workspace-tabs" role="group" aria-labelledby="visual-trash-view-label" aria-label={t('Trash view')}>{([{value:'grid',label:'Grid view',Icon:LayoutGrid},{value:'list',label:'List view',Icon:List}] as const).map(({value,label,Icon})=><button type="button" key={value} className="quick-action" title={t(label)} aria-label={t(label)} aria-pressed={view===value} onClick={()=>setView(value)}><Icon size={16} aria-hidden="true"/></button>)}</div></div></div>
 <div className="visual-trash-bulk"><div className="visual-trash-selection"><label><input type="checkbox" aria-label={t('Select all visible items')} checked={allVisible} disabled={!visibleEditable.length} ref={node=>{if(node)node.indeterminate=someVisible&&!allVisible;}} onChange={()=>setSelection(current=>allVisible?current.filter(key=>!visibleEditable.some(item=>trashKey(item)===key)):[...new Set([...current,...visibleEditable.map(trashKey)])])}/>{t('Select all visible items')}</label><span role="status">{t('{0} selected',selected.length)}</span></div><div className="visual-trash-actions"><button type="button" className="quick-action quick-action-text" disabled={!selected.length} onClick={()=>perform(selected,'restore')}><RotateCcw size={16}/>{t('Restore selected')}</button><button type="button" className="quick-action quick-action-text danger-button" disabled={!selected.length||!!bulkProblem} title={bulkProblem||t('Delete selected permanently')} onClick={event=>confirm(selected,event.currentTarget)}><Trash2 size={16}/>{t('Delete selected permanently')}</button>{selection.length>0&&<button type="button" className="quick-action quick-action-text" onClick={()=>setSelection([])}>{t('Clear selection')}</button>}</div></div>
 {hiddenSelected>0&&<p className="world-hint">{t('{0} selected items are outside these filters.',hiddenSelected)}</p>}{bulkProblem&&<p className="world-hint" role="status">{bulkProblem}</p>}
 <div ref={items} className="visual-trash-items" tabIndex={0} role="region" aria-label={t('Deleted items')}><div className={`visual-trash-collection ${view==='list'?'is-list':'is-grid'}`}>
 {visible.map(item=>{const key=trashKey(item),resource=item.kind==='image'?world.visualResources?.find(resource=>resource.id===item.id):undefined,map=item.kind==='map'?maps?.trash?.find(record=>record.map.id===item.id)?.map:undefined,uses=item.kind==='image'?visualResourceUsage(world,item.id,context):[],problem=item.kind==='image'?visualRemovalProblem(uses):'';return <article key={key} data-selected={selection.includes(key)}><label className="visual-trash-select"><input type="checkbox" aria-label={t('Select {0}',item.title)} disabled={!canEdit(item)} checked={selection.includes(key)} onChange={()=>toggle(item)}/><span className="visually-hidden">{t('Select {0}',item.title)}</span></label><div className="visual-trash-preview"><EntryPortrait lazy projectPath={projectPath} projectId={projectId} imageId={item.imageId} title={item.title}/></div><div className="visual-trash-copy"><h3>{item.title}</h3><small>{t(item.kind==='image'?'Image':'Map')} · {t('{0} days remaining',visualTrashDays(item))}</small>{map&&<small>{t('{0} markers · {1} routes',map.markers.length,map.routes?.length??0)}</small>}{map?.drawing&&<small>{t('Includes map drawing and layers')}</small>}{resource?.originalFilename&&view==='list'&&<small>{t('Original filename')}: {resource.originalFilename}</small>}{resource&&<VisualResourceDetails compact resource={resource} resources={visualResources(world,true)}/>} {!!uses.length&&visualUsageSummary(uses)}</div><div className="visual-resource-actions"><button type="button" className="quick-action quick-action-text" disabled={!canEdit(item)} onClick={()=>perform([item],'restore')}><RotateCcw size={16}/>{t('Restore')}</button><button type="button" className="quick-action danger-button" disabled={!canEdit(item)||!!problem} aria-label={t('Permanently delete {0}',item.title)} title={problem||t('Delete permanently')} onClick={event=>confirm([item],event.currentTarget)}><Trash2 size={16}/></button></div></article>;})}
 </div>{!visible.length&&<p className="ui-empty-state ui-empty-state-compact">{t(all.length?'No items match these filters.':'Trash is empty.')}</p>}</div></div></ProjectModal>;
}
