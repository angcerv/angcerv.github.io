import {textReferenceAt,encodeTextReference} from './textReferenceTokens';
import type { JSONContent } from '@tiptap/react';

// Long entry fields use a separate Markdown codec from the manuscript.
// Unknown syntax stays literal; no HTML is executed and opening a field never rewrites it.
export function longTextDocument(source: string): JSONContent {
 return {type:'doc',content:parseBlocks(source.replace(/\r\n?/g,'\n').split('\n'))};
}
function parseBlocks(lines:string[],depth=0):JSONContent[]{
 const content:JSONContent[]=[];
 for(let i=0;i<lines.length;){
  if(/^[-*] /.test(lines[i])&&depth<32){
   const items:JSONContent[]=[];
   while(i<lines.length&&/^[-*] /.test(lines[i])){
    const item=[lines[i++].slice(2)];
    while(i<lines.length){
     if(lines[i].startsWith('  ')){item.push(lines[i++].slice(2));continue;}
     if(lines[i]===''&&i+1<lines.length&&lines[i+1].startsWith('  ')){item.push(lines[i++]);continue;}
     break;
    }
    items.push({type:'listItem',content:parseBlocks(item,depth+1)});
   }
   content.push({type:'bulletList',content:items});
  }else{
   const paragraph=[lines[i++]];
   while(i<lines.length&&lines[i]!==''&&paragraph[0]!==''&&!/^[-*] /.test(lines[i]))paragraph.push(lines[i++]);
   content.push({type:'paragraph',content:inlineDocument(paragraph.join('\n'))});
  }
  // One blank line separates blocks. Additional blank lines are empty paragraphs.
  if(i<lines.length&&lines[i]==='')i++;
 }
 return content.length?content:[{type:'paragraph',content:[]}];
}
export function inlineDocument(source:string,depth=0):JSONContent[]{
 const result:JSONContent[]=[];let buffer='';
 const flush=()=>{if(buffer){result.push({type:'text',text:buffer});buffer='';}};
 for(let i=0;i<source.length;){
  if(source[i]==='\\'&&i+1<source.length&&/[\\`*_[\]{}<>#!|~\-+.()]/.test(source[i+1])){buffer+=source[i+1];i+=2;continue;}
  if(source[i]==='\n'){flush();result.push({type:'hardBreak'});i++;continue;}
  const reference=source.startsWith('[[entry:',i)?textReferenceAt(source,i):undefined;
  if(reference){flush();result.push({type:'entryMention',attrs:{entryId:reference.entryId,label:reference.label}});i=reference.to;continue;}
  const token=source.startsWith('**',i)?'**':source.startsWith('<u>',i)?'<u>':source[i]==='_'?'_':'';
  const close=token==='<u>'?'</u>':token;let end=-1;
  if(token)for(let j=i+token.length;j<source.length;j++){if(source[j]==='\\'){j++;continue;}const linked=source.startsWith('[[entry:',j)?textReferenceAt(source,j):undefined;if(linked){j=linked.to-1;continue;}if(source.startsWith(close,j)){end=j;break;}}
  if(token&&end>i+token.length&&depth<32){
   flush();const mark={type:token==='**'?'bold':token==='_'?'italic':'underline'};
   result.push(...inlineDocument(source.slice(i+token.length,end),depth+1).map(node=>['text','entryMention'].includes(node.type??'')?{...node,marks:[mark,...(node.marks??[])]}:node));i=end+close.length;
  }else buffer+=source[i++];
 }
 flush();return result;
}

function inlineMarkdown(nodes:JSONContent[]):string{
 return nodes.map(node=>{
  if(node.type==='hardBreak')return '\n';
  let text=node.type==='entryMention'?encodeTextReference(node.attrs?.entryId,node.attrs?.label??''):(node.text??'').replace(/[\\*_<>\-\[\]]/g,'\\$&');
  if(node.marks?.some(mark=>mark.type==='underline'))text=`<u>${text}</u>`;
  if(node.marks?.some(mark=>mark.type==='italic'))text=`_${text}_`;
  if(node.marks?.some(mark=>mark.type==='bold'))text=`**${text}**`;
  return text;
 }).join('');
}
function blockMarkdown(node:JSONContent):string{
 if(node.type==='bulletList')return (node.content??[]).map(item=>{
  const body=(item.content??[]).map(blockMarkdown).join('\n\n');
  return '- '+body.replace(/\n/g,'\n  ');
 }).join('\n');
 return inlineMarkdown(node.content??[]);
}
export function longTextMarkdown(doc:JSONContent):string{
 return (doc.content??[]).map(blockMarkdown).join('\n\n');
}
export function longTextPlainText(source:string):string{
 const visit=(node:JSONContent):string=>node.type==='entryMention'?node.attrs?.label??'':node.type==='text'?node.text??'':node.type==='hardBreak'?'\n':(node.content??[]).map(visit).join(['doc','bulletList','listItem'].includes(node.type??'')?'\n':'');
 return visit(longTextDocument(source));
}
