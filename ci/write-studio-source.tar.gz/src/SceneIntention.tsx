import ContextText from './ContextText';
import type {ScenePlan} from './sceneContext';
import {t} from './i18n';
export default function SceneIntention({sceneId,plan,onChange}:{sceneId:string;plan:ScenePlan;onChange:(patch:Partial<Omit<ScenePlan,'schemaVersion'>>)=>void}){
 return <div className="scene-intention-fields">{([{key:'goal',label:'Scene goal'},{key:'conflict',label:'Scene conflict'},{key:'change',label:'What changes by the end?'}] as const).map(({key,label})=><ContextText key={`${sceneId}:${key}`} id={`context-${sceneId}-${key}`} label={t(label)} value={plan[key]} onChange={value=>onChange({[key]:value})}/>)}</div>;
}
