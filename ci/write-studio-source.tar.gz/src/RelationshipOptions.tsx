import {useEffect,useId,useLayoutEffect,useRef,useState} from 'react';
import type {ReactNode} from 'react';
import {createPortal} from 'react-dom';
import {ChevronDown,SlidersHorizontal} from 'lucide-react';
import {floatingPanelPosition} from './floatingPanelPosition';

export default function RelationshipOptions({label,children,iconOnly=false,width=340,icon,popupClassName='',triggerClassName='',animated=false,triggerContent,closeOnSelect=false}:{closeOnSelect?:boolean;triggerContent?:ReactNode;label:string;children:ReactNode;iconOnly?:boolean;animated?:boolean;width?:number;icon?:ReactNode;popupClassName?:string;triggerClassName?:string}){
 const id=useId(),[open,setOpen]=useState(false),[position,setPosition]=useState<ReturnType<typeof floatingPanelPosition>|null>(null);
 const trigger=useRef<HTMLButtonElement>(null),popup=useRef<HTMLDivElement>(null);
 const [closing,setClosing]=useState(false),exitTimer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
 function changeOpen(next:boolean){
  clearTimeout(exitTimer.current);
  if(!next&&open&&animated){setClosing(true);exitTimer.current=setTimeout(()=>setClosing(false),160);}else setClosing(false);
  setOpen(next);
 }
 useEffect(()=>()=>clearTimeout(exitTimer.current),[]);
 function close(restore=false){changeOpen(false);if(restore)trigger.current?.focus({preventScroll:true});}
 useLayoutEffect(()=>{
  if(!open)return;
  const place=()=>{const rect=trigger.current?.getBoundingClientRect();if(trigger.current?.closest('[hidden],[inert]')||rect&&(rect.bottom<0||rect.top>window.innerHeight)){changeOpen(false);return;}if(rect)setPosition(floatingPanelPosition(rect,{width:window.innerWidth,height:window.innerHeight},width,360));};
  place();const scroll=(event:Event)=>{if(!popup.current?.contains(event.target as Node))place();};
  window.addEventListener('resize',place);window.addEventListener('scroll',scroll,true);
  return()=>{window.removeEventListener('resize',place);window.removeEventListener('scroll',scroll,true);};
 },[open,width]);
 useEffect(()=>{
  if(!open||!position)return;
  popup.current?.querySelector<HTMLElement>('button:not(:disabled),input:not(:disabled),[tabindex="0"]')?.focus();
  const outside=(event:Event)=>{if(!trigger.current?.contains(event.target as Node)&&!popup.current?.contains(event.target as Node))changeOpen(false);};
  const observer=new MutationObserver(()=>{if(trigger.current?.matches(':disabled')||trigger.current?.closest('[hidden],[inert]'))changeOpen(false);});for(let node:HTMLElement|null=trigger.current;node;node=node.parentElement)observer.observe(node,{attributes:true,attributeFilter:['disabled','hidden','inert']});
  document.addEventListener('pointerdown',outside,true);document.addEventListener('focusin',outside);
  return()=>{observer.disconnect();document.removeEventListener('pointerdown',outside,true);document.removeEventListener('focusin',outside);};
 },[open,!!position]);
 return <div className="relation-secondary-filters" onKeyDown={event=>{if(event.key==='Escape'&&open){event.preventDefault();event.stopPropagation();close(true);}}}>
  <button type="button" ref={trigger} className={`${iconOnly?'quick-action relationship-options-icon':'relationship-options-trigger'} ${triggerClassName}`} aria-label={label} title={label} aria-expanded={open} aria-haspopup="dialog" aria-controls={open?id:undefined} onClick={()=>changeOpen(!open)}>{iconOnly?(icon??<SlidersHorizontal size={16} aria-hidden="true"/>):<>{icon}{triggerContent??label}<ChevronDown size={14}/></>}</button>
  {(open||closing)&&position&&createPortal(<div ref={popup} id={id} role="dialog" aria-label={label} inert={!open} aria-hidden={!open} data-relationship-options onClick={event=>{if(closeOnSelect&&(event.target as HTMLElement).closest('button:not(:disabled)'))close(true);}} className={`world-surface relationship-options-popover relation-filter-options ${popupClassName}${animated?' is-animated':''}${closing?' is-closing':''}`} style={{position:'fixed',...position}}>{children}</div>,trigger.current?.closest('dialog[open]')??document.body)}
 </div>;
}
