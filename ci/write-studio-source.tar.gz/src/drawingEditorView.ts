import type {MapDrawing} from './mapDrawing';
import type {MapLayer} from './maps';
export type DrawingCamera={scale:number;x:number;y:number};
export function fitDrawingCamera(viewport:{width:number;height:number},drawing:{width:number;height:number}):DrawingCamera{
 const scale=Math.max(.0001,Math.min(Math.max(1,viewport.width-48)/drawing.width,Math.max(1,viewport.height-48)/drawing.height));
 return {scale,x:(viewport.width-drawing.width*scale)/2,y:(viewport.height-drawing.height*scale)/2};
}
export function zoomDrawingCamera(camera:DrawingCamera,oldZoom:number,nextZoom:number,anchor:{x:number;y:number}):DrawingCamera{
 const ratio=nextZoom/oldZoom;return {...camera,x:anchor.x-(anchor.x-camera.x)*ratio,y:anchor.y-(anchor.y-camera.y)*ratio};
}
export function preserveDrawingCamera(camera:DrawingCamera,previous:{left:number;top:number},next:{left:number;top:number}):DrawingCamera{
 return {...camera,x:camera.x+previous.left-next.left,y:camera.y+previous.top-next.top};
}
export function drawingDraftChanged(drawing:MapDrawing,layers:MapLayer[],baseline:{drawing:MapDrawing;layers:MapLayer[]}){
 const serialize=(value:unknown)=>JSON.stringify(value,(_key,item)=>item&&typeof item==='object'&&!Array.isArray(item)?Object.fromEntries(Object.keys(item).sort().map(key=>[key,item[key]])):item);
 const snapshot=(value:MapDrawing,items:MapLayer[])=>({drawing:value,layers:items.map(layer=>({...layer,locked:!!layer.locked}))});
 return serialize(snapshot(drawing,layers))!==serialize(snapshot(baseline.drawing,baseline.layers));
}
export function drawingTextTarget(target:EventTarget|null){
 return typeof Element!=='undefined'&&target instanceof Element&&!!target.closest('input,textarea,select,[contenteditable="true"],[role="combobox"]');
}

/** Select a native resize axis in screen space, including rotated symbol corners. */
export function drawingResizeCursor(dx:number,dy:number,rotation=0){
 const direction=((Math.round((Math.atan2(dy,dx)*180/Math.PI+rotation)/45)%4)+4)%4;
 return (['ew-resize','nwse-resize','ns-resize','nesw-resize'] as const)[direction];
}
