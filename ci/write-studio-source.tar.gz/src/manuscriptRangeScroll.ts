import type {Editor} from '@tiptap/react';

/** Reveal a document range without moving keyboard focus out of a modeless tool. */
export function scrollManuscriptRange(editor:Editor,container:HTMLElement|null,range:{from:number;to:number}):boolean{
 if(!container||editor.isDestroyed||!container.contains(editor.view.dom)||range.from<1||range.to<range.from||range.to>editor.state.doc.content.size)return false;
 const start=editor.view.coordsAtPos(range.from),end=editor.view.coordsAtPos(range.to);
 const viewport=container.getBoundingClientRect();
 if(container.clientHeight<=0)return false;
 // Center short matches; keep the beginning visible for ranges taller than the viewport.
 const height=Math.min(Math.max(start.bottom,end.bottom)-start.top,container.clientHeight/2);
 const target=container.scrollTop+start.top-viewport.top-container.clientTop-(container.clientHeight-height)/2;
 container.scrollTop=Math.max(0,Math.min(target,Math.max(0,container.scrollHeight-container.clientHeight)));
 return true;
}
