import type {ScenePlan} from './sceneContext';
import type {ChapterPlan} from './chapterPlanning';
import type { WorldIdea } from './worldIdeas';
import type {EntryRelations} from './entryRelations';
import type { ProjectPlots } from './plotThreads';
import type { ReviewComment } from './reviewComments';
import type { ProjectMaps } from './maps';
import type { WritingGoals } from './writingGoals';
import type { Timeline } from './timeline';
import type { Worldbuilding } from './worldbuilding';
import type { JSONContent } from '@tiptap/react';
export type WritingStatus = 'notStarted' | 'draft' | 'inReview' | 'finished';
export const writingStatusLabels: Record<WritingStatus, string> = { notStarted: 'Not started', draft: 'Draft', inReview: 'In review', finished: 'Finished' };
export const getSceneStatus = (scene: Scene): WritingStatus => scene.writingStatus ?? (scene.content.trim() ? 'draft' : 'notStarted');
export type IgnoredMention = {from:number;to:number;text:string};
export type ResolvedMention = IgnoredMention & {entryId:string};
export type Scene = { planning?:ScenePlan; reviewComments?:ReviewComment[]; id: string; title: string; content: string; synopsis?: string; writingStatus?: WritingStatus; entryIds?: string[]; ignoredMentions?:IgnoredMention[]; resolvedMentions?:ResolvedMention[] };
export type Chapter = { planning?:ChapterPlan; id: string; title: string; synopsis?: string; scenes: Scene[] };
export type Book = {id:string;title:string;chapterIds:string[]};
export type Project = { pendingDates?:Record<string,import('./pendingDates').PendingDates>; ideaCanvases?:import('./ideaCanvas').IdeaCanvases; books?:Book[]; worldIdeas?:WorldIdea[]; entryRelations?:EntryRelations; plots?:ProjectPlots; schemaVersion: 1; id: string; title: string; revision: number; chapters: Chapter[]; maps?: ProjectMaps; writingGoals?: WritingGoals; worldbuilding?: Worldbuilding; timeline?: Timeline };
export type OpenProject = { path: string; project: Project };
export const newScene = (): Scene => ({ id: crypto.randomUUID(), title: 'Scene 1', content: '' });
export const newProject = (title = 'Untitled project'): Project => ({ schemaVersion: 1, id: crypto.randomUUID(), title, revision: 0, chapters: [{ id: crypto.randomUUID(), title: 'Chapter 1', scenes: [newScene()] }] });

// Canonical Markdown subset: paragraphs, escaped text, strong, emphasis, hard breaks.
// Empty paragraphs are retained by the exact paragraph separators.
export function toMarkdown(doc: JSONContent): string {
  return (doc.content ?? []).map(p => (p.content ?? []).map(n => {
    if (n.type === 'hardBreak') return '  \n';
    let text = (n.text ?? '').replace(/[\\`*_[\]{}<>#!|~\-+.()]/g, '\\$&');
    if (n.marks?.some(m => m.type === 'italic')) text = `_${text}_`;
    if (n.marks?.some(m => m.type === 'bold')) text = `**${text}**`;
    return text;
  }).join('')).join('\n\n');
}
export function fromMarkdown(source: string): JSONContent {
  if (source.includes('\r')) throw new Error('Unsupported Markdown line endings. Use LF line endings.');
  return { type: 'doc', content: source.split('\n\n').map(paragraph => {
    const content: JSONContent[] = [];
    let bold = false, italic = false, buffer = '';
    const flush = () => { if (buffer) { content.push({ type: 'text', text: buffer, marks: [...(bold ? [{ type: 'bold' }] : []), ...(italic ? [{ type: 'italic' }] : [])] }); buffer = ''; } };
    for (let i = 0; i < paragraph.length;) {
      if (paragraph[i] === '\\') { if (i + 1 >= paragraph.length) throw new Error('Invalid Markdown escape.'); buffer += paragraph[i + 1]; i += 2; }
      else if (paragraph.startsWith('  \n', i)) { flush(); content.push({ type: 'hardBreak' }); i += 3; }
      else if (paragraph.startsWith('**', i)) { flush(); bold = !bold; i += 2; }
      else if (paragraph[i] === '_') { flush(); italic = !italic; i++; }
      else if (paragraph[i] === '\n') throw new Error('Unsupported Markdown line break.');
      else { buffer += paragraph[i]; i++; }
    }
    flush();
    if (bold || italic) throw new Error('Unbalanced Markdown formatting.');
    return { type: 'paragraph', content };
  }) };
}

// Folder names are independent of the display title and the stable project UUID.
export function suggestFolderName(title: string): string {
  const slug = title.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLowerCase()
    .replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 80).replace(/-+$/g, '');
  return /^(con|prn|aux|nul|com[1-9]|lpt[1-9])$/.test(slug) ? `${slug}-project` : slug || 'project';
}
