import {isGraphDrag} from './graphGesture';
import {MoveDiagonal2} from 'lucide-react';
import {useEffect,useRef} from 'react';
import {t} from './i18n';
export default function PanelResize({side,width,onChange,label,minimum:minimumProp,maximum:maximumProp,className=''}:{side:'left'|'right';width:number;onChange:(width:number)=>void;label?:string;minimum?:number;maximum?:number;className?:string}){
 const drag=useRef<{x:number;width:number}|null>(null),minimum=minimumProp??(side==='left'?200:260),maximum=maximumProp??(side==='left'?340:480);
 const update=(value:number)=>onChange(Math.max(minimum,Math.min(maximum,value)));
 return <div className={`panel-resize timeline-resize timeline-resize-${side} ${className}`} role="separator" tabIndex={0} aria-label={label??t(side==='left'?'Resize timeline navigation':'Resize event inspector')} aria-orientation="vertical" aria-valuemin={minimum} aria-valuemax={maximum} aria-valuenow={width} onKeyDown={event=>{if(!['ArrowLeft','ArrowRight','Home','End','Escape'].includes(event.key))return;event.preventDefault();if(event.key==='Escape'){if(drag.current){update(drag.current.width);drag.current=null;}return;}update(event.key==='Home'?minimum:event.key==='End'?maximum:width+(event.key==='ArrowRight'?1:-1)*(side==='right'?-16:16));}} onPointerDown={event=>{if(event.button!==0)return;event.preventDefault();event.currentTarget.focus();drag.current={x:event.clientX,width};event.currentTarget.setPointerCapture(event.pointerId);}} onPointerMove={event=>{if(drag.current&&event.currentTarget.hasPointerCapture(event.pointerId))update(drag.current.width+(event.clientX-drag.current.x)*(side==='right'?-1:1));}} onPointerUp={event=>{drag.current=null;if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId);}} onPointerCancel={()=>{if(drag.current)update(drag.current.width);drag.current=null;}} onLostPointerCapture={()=>{drag.current=null;}}/>;
}

/** Two-axis resize handle: previews stay local until pointer release. */
export function AreaResize({label,width,height,zoom=1,minimumWidth,minimumHeight,maximumWidth,maximumHeight,onPreview,onCommit,onCancel,disabled=false}:{label:string;width:number;height:number;zoom?:number;minimumWidth:number;minimumHeight:number;maximumWidth:number;maximumHeight:number;onPreview:(size:{width:number;height:number})=>void;onCommit:(size:{width:number;height:number})=>void;onCancel:()=>void;disabled?:boolean}){
 const handle=useRef<HTMLButtonElement>(null);
 const gesture=useRef<{pointerId:number;x:number;y:number;width:number;height:number;zoom:number;moved:boolean}|null>(null);
 const bound=(w:number,h:number)=>({width:Math.round(Math.max(Math.min(minimumWidth,maximumWidth),Math.min(maximumWidth,w))),height:Math.round(Math.max(Math.min(minimumHeight,maximumHeight),Math.min(maximumHeight,h)))});
 const cancel=(target:HTMLButtonElement)=>{
  const current=gesture.current;gesture.current=null;
  if(current){onCancel();if(target.hasPointerCapture(current.pointerId))target.releasePointerCapture(current.pointerId);}
 };
 useEffect(()=>{if(disabled&&handle.current)cancel(handle.current);},[disabled]);
 useEffect(()=>()=>{const current=gesture.current;gesture.current=null;if(current&&handle.current?.hasPointerCapture(current.pointerId))handle.current.releasePointerCapture(current.pointerId);},[]);
 return <button ref={handle} type="button" className="area-resize" disabled={disabled} aria-label={label} title={label} aria-description={t('Size: {0} × {1}',width,height)}
 onPointerDown={event=>{if(event.button!==0||disabled)return;event.preventDefault();event.stopPropagation();event.currentTarget.focus({preventScroll:true});gesture.current={pointerId:event.pointerId,x:event.clientX,y:event.clientY,width,height,zoom,moved:false};event.currentTarget.setPointerCapture(event.pointerId);}}
 onPointerMove={event=>{if(disabled){cancel(event.currentTarget);return;}const current=gesture.current;if(!current||current.pointerId!==event.pointerId)return;if(!current.moved&&!isGraphDrag({x:current.x,y:current.y},{x:event.clientX,y:event.clientY}))return;current.moved=true;onPreview(bound(current.width+(event.clientX-current.x)/current.zoom,current.height+(event.clientY-current.y)/current.zoom));}}
 onPointerUp={event=>{if(disabled){cancel(event.currentTarget);return;}const current=gesture.current;if(!current||current.pointerId!==event.pointerId)return;gesture.current=null;if(event.currentTarget.hasPointerCapture(event.pointerId))event.currentTarget.releasePointerCapture(event.pointerId);if(current.moved)onCommit(bound(current.width+(event.clientX-current.x)/current.zoom,current.height+(event.clientY-current.y)/current.zoom));}}
 onPointerCancel={event=>cancel(event.currentTarget)} onLostPointerCapture={event=>cancel(event.currentTarget)}
 onKeyDown={event=>{
  if(event.key==='Escape'&&gesture.current){event.preventDefault();event.stopPropagation();cancel(event.currentTarget);return;}
  if(gesture.current||!['ArrowLeft','ArrowRight','ArrowUp','ArrowDown','Home','End'].includes(event.key))return;
  event.preventDefault();event.stopPropagation();const step=event.shiftKey?40:10;
  onCommit(bound(event.key==='Home'?minimumWidth:event.key==='End'?maximumWidth:width+(event.key==='ArrowRight'?step:event.key==='ArrowLeft'?-step:0),event.key==='Home'?minimumHeight:event.key==='End'?maximumHeight:height+(event.key==='ArrowDown'?step:event.key==='ArrowUp'?-step:0)));
 }}><MoveDiagonal2 size={14} aria-hidden="true"/></button>;
}
