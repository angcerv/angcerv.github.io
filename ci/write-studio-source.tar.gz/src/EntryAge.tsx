import FieldHelp from './FieldHelp';
import { useState } from 'react';
import { t } from './i18n';
import { ageAtDate, ageExplanation, ageLabel, birthDateField, entryBirthDate, eventEntryAges } from './ages';
import { formatStoryDate } from './timeline';
import type { StoryDate, TimelineEvent } from './timeline';
import type { Entry, Worldbuilding } from './worldbuilding';
import type { AgeResult } from './ages';
import StoryDateInput from './StoryDateInput';
export function AgeBadge({result}:{result:AgeResult}){return <span className={`entry-age-badge age-${result.kind}`} title={ageExplanation(result)}>{ageLabel(result)}</span>;}
export function TimelineEntryAge({world,entry,event}:{world:Worldbuilding|undefined;entry:Entry;event:TimelineEvent}) {
 return birthDateField(world,entry)?<AgeBadge result={ageAtDate(entryBirthDate(world,entry),event.start,event.end)}/>:null;
}
export function EventAges({world,event}:{world:Worldbuilding|undefined;event:TimelineEvent}){
 const ages=eventEntryAges(world,event);return ages.length?<span className="event-entry-ages">{ages.map(({entry,age})=><span key={entry.id} className="event-entry-age" title={`${entry.title} · ${ageLabel(age)} · ${ageExplanation(age)}`}><span>{entry.title||t('Untitled entry')}</span><AgeBadge result={age}/></span>)}</span>:null;
}
export default function EntryAgePreview({world,entry}:{world:Worldbuilding;entry:Entry}) {
 const [at,setAt]=useState<StoryDate|undefined>();
 const field=birthDateField(world,entry);if(!field)return null;
 const birth=entryBirthDate(world,entry);
 return <section className="entry-age-preview" aria-label={t('Age at a story date')}><header><div className="entry-age-title"><h3>{t('Age at a story date')}</h3><FieldHelp label={t('Age at a story date')} description={t('Choose a story date. Ages never use the real current date.')+' '+t('Year, month or complete date. Negative years and year 0 are supported.')}/></div><AgeBadge result={ageAtDate(birth,at)}/></header><p className="entry-age-birth">{t('Birth date')}: {birth?formatStoryDate(birth):t('Not set')}</p><div className="entry-age-date"><label className="visually-hidden" htmlFor={`age-at-${entry.id}`}>{t('Calculate age at')}</label><StoryDateInput compact id={`age-at-${entry.id}`} value={at} onChange={date=>setAt(date??undefined)}/></div>{!birth&&<p className="world-hint">{t('Fill in the birth date field to calculate ages in this entry and the timeline.')}</p>}</section>;
}
