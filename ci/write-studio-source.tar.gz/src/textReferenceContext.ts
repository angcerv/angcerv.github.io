import {createContext} from 'react';
import type {Project} from './model';
import type {Worldbuilding} from './worldbuilding';
import type {TextReferenceSource} from './textReferenceIndex';
export type TextReferenceEnvironment={world:Worldbuilding;project:Project;openEntry:(id:string)=>void;openSource:(source:TextReferenceSource)=>void;consultSource?:(source:TextReferenceSource)=>void;index:TextReferenceSource[]};
export const TextReferenceContext=createContext<TextReferenceEnvironment|null>(null);
