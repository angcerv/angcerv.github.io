import {useState} from 'react';
import type {Dispatch,SetStateAction} from 'react';
import {workspaceViewMemory} from './workspaceNavigation';
/** Match useState's semantics while remembering only explicitly named view state.
 * Restoring a visit remounts the workspace from this memory, retaining live data. */
export function useWorkspaceState<T>(key:string,initial:T|(()=>T),remember=true):[T,Dispatch<SetStateAction<T>>]{
 const memory=remember?workspaceViewMemory():undefined;
 const [value,setValue]=useState<T>(memory?()=>Object.prototype.hasOwnProperty.call(memory.values,key)?memory.values[key] as T:typeof initial==='function'?(initial as ()=>T)():initial:initial);
 if(!memory)return [value,setValue];
 memory.values[key]=value;
 return [value,next=>setValue(previous=>{const result=typeof next==='function'?(next as (previous:T)=>T)(previous):next;if(memory)memory.values[key]=result;return result;})];
}
