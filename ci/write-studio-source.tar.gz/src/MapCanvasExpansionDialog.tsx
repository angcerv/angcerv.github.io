import {useState} from 'react';
import ProjectModal from './ProjectModal';
import FieldHelp from './FieldHelp';
import {t} from './i18n';
import type {WorldMap} from './maps';
import {expandMapCanvas,maxMapCanvasSize} from './mapCanvasExpansion';
import type {CanvasMargins} from './mapCanvasExpansion';
export default function MapCanvasExpansionDialog({map,onClose,onApply}:{map:WorldMap;onClose:()=>void;onApply:(map:WorldMap)=>void}){
 const [margins,setMargins]=useState<CanvasMargins>({top:0,right:0,bottom:0,left:0});
 const next=expandMapCanvas(map,margins),width=(map.drawing?.width??0)+margins.left+margins.right,height=(map.drawing?.height??0)+margins.top+margins.bottom;
 return <ProjectModal title={t('Expand canvas')} onClose={onClose} titleAccessory={<FieldHelp label={t('Expand canvas')} description={t('Add space without stretching the drawing. Markers, regions, routes and scale keep their position on the artwork.')}/>}><form onSubmit={event=>{event.preventDefault();if(next)onApply(next);}}>
 <div className="map-field-grid">{(['top','right','bottom','left'] as const).map(side=><div className="ui-form-field" key={side}><label htmlFor={`canvas-margin-${side}`}>{t(({top:'Top',right:'Right',bottom:'Bottom',left:'Left'} as const)[side])} (px)</label><input id={`canvas-margin-${side}`} type="number" min={0} max={maxMapCanvasSize} step={1} required value={Number.isNaN(margins[side])?'':margins[side]} onChange={event=>setMargins({...margins,[side]:event.target.value===''?NaN:Number(event.target.value)})}/></div>)}</div>
 <p role="status">{t('Canvas size: {0} × {1} px',Number.isFinite(width)?width:'—',Number.isFinite(height)?height:'—')}</p>
 {(width>maxMapCanvasSize||height>maxMapCanvasSize)&&<p className="prompt-error" role="alert">{t('The canvas can be at most {0} × {0} px.',maxMapCanvasSize)}</p>}
 <div className="welcome-actions"><button type="button" className="quick-action quick-action-text" onClick={onClose}>{t('Cancel')}</button><button className="primary-button" type="submit" disabled={!next}>{t('Expand canvas')}</button></div>
 </form></ProjectModal>;
}
