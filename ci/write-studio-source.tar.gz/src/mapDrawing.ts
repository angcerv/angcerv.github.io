import type {TerrainMask} from './terrainMask';
import {brushDefinitions} from './mapBrush';
import type {TerrainBrushShape} from './mapBrush';
import {drawingPath} from './mapDrawingPaths';
import {medievalSymbols} from './mapIllustration';
import {isTerrainMaterial,materialDefinitions,materialPatternId,materialScale} from './mapMaterials';
import {materialMaskDefinitions,renderTerrainStrokes} from './mapTerrain';
import type {TerrainMaterial} from './mapMaterials';
import type { MapLayer } from './maps';
import type { MapTheme } from './mapThemes';
import { themeSymbols } from './mapThemeSymbols';
export type DrawingPoint={x:number;y:number};
export type BrushKind='land'|'water'|'park'|'road'|'nebula'|'region';
export type MaterialMaskTarget='land'|'water'|TerrainMaterial;
export type MaterialMask={id:string;target:MaterialMaskTarget;groups:number[][];waterBackground:boolean};
export type DrawingStroke={materialMask?:MaterialMask;mask?:TerrainMask;textureScale?:number;textureRotation?:number;opacity?:number;brushShape?:TerrainBrushShape;softness?:number;erase?:boolean;closed?:boolean;material?:TerrainMaterial;textureIntensity?:number;kind:BrushKind;width:number;points:DrawingPoint[];color?:string;layerId?:string};
export const drawingSymbols=['mountain','forest','village','tower','ruins'] as const;
export type DrawingSymbol=typeof drawingSymbols[number]|keyof typeof themeSymbols;
export type SymbolPlacementSettings={continuous:boolean;density:number;sizeVariation:number;rotationVariation:number;baseSize:number;baseRotation:number};
export type DrawingObject={stamp?:SymbolPlacementSettings;id:string;kind:DrawingSymbol|'label'|'line'|'ellipse'|'path';points?:DrawingPoint[];smooth?:boolean;dashed?:boolean;x:number;y:number;size:number;text?:string;color?:string;halo?:string;endX?:number;endY?:number;lineWidth?:number;fill?:string;layerId?:string;rotation?:number};
export type MapDrawing={masks?:import('./terrainMask').SavedTerrainMask[];textureFrame?:{x:number;y:number;width:number;height:number};width:number;height:number;strokes:DrawingStroke[];objects:DrawingObject[];theme?:MapTheme;background?:string;terrainColors?:Partial<Record<BrushKind,string>>};
export const seaColor='#b9d9df',landColor='#d9d0a4';
export const emptyDrawing=(width=1600,height=1000):MapDrawing=>({width,height,strokes:[],objects:[]});
const escape=(text:string)=>text.replace(/[\u0000-\u0008\u000b\u000c\u000e-\u001f]/g,'').replace(/[&<>"']/g,char=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[char]!));
const n=(value:number)=>Number(value.toFixed(3));
/** Original vector symbols, drawn in a shared 64×64 coordinate system. */
export const symbolArtwork:Record<DrawingSymbol,string>={
 ...themeSymbols,
 ...medievalSymbols,
};
export function isDrawingSymbol(object:DrawingObject){return object.kind!=='label'&&object.kind!=='path'&&!isDrawingShape(object);}
export function normalizeRotation(degrees:number){return ((degrees%360)+360)%360;}
export function rotationPointerAngle(object:DrawingObject,position:DrawingPoint,width:number,height:number){return Math.atan2((position.y-object.y)*height,(position.x-object.x)*width)*180/Math.PI+90;}
export function rotateDrawingObject(object:DrawingObject,position:DrawingPoint,startAngle:number,width:number,height:number,snap=false):DrawingObject{
 if(!isDrawingSymbol(object)||Math.hypot((position.x-object.x)*width,(position.y-object.y)*height)<1)return object;
 const degrees=(object.rotation??0)+rotationPointerAngle(object,position,width,height)-startAngle;
 return {...object,rotation:normalizeRotation(snap?Math.round(degrees/15)*15:degrees)};
}
export function isDrawingShape(object:DrawingObject){return object.kind==='line'||object.kind==='ellipse';}
export function shapeEnd(start:DrawingPoint,end:DrawingPoint,width:number,height:number,circle=false):DrawingPoint{
 if(!circle)return end;
 const sx=end.x<start.x?-1:1,sy=end.y<start.y?-1:1;
 const pixels=Math.min(Math.max(Math.abs(end.x-start.x)*width,Math.abs(end.y-start.y)*height),(sx>0?1-start.x:start.x)*width,(sy>0?1-start.y:start.y)*height);
 return {x:start.x+sx*pixels/width,y:start.y+sy*pixels/height};
}
export function moveDrawingObject(object:DrawingObject,position:DrawingPoint):DrawingObject{
 if(object.kind==='path'){
  const points=object.points??[],xs=points.map(p=>p.x),ys=points.map(p=>p.y),dx=Math.max(-Math.min(...xs),Math.min(1-Math.max(...xs),position.x-object.x)),dy=Math.max(-Math.min(...ys),Math.min(1-Math.max(...ys),position.y-object.y));
  return {...object,x:object.x+dx,y:object.y+dy,points:points.map(p=>({x:p.x+dx,y:p.y+dy}))};
 }
 if(!isDrawingShape(object))return {...object,...position};
 const dx=Math.max(-Math.min(object.x,object.endX!),Math.min(1-Math.max(object.x,object.endX!),position.x-object.x));
 const dy=Math.max(-Math.min(object.y,object.endY!),Math.min(1-Math.max(object.y,object.endY!),position.y-object.y));
 return {...object,x:object.x+dx,y:object.y+dy,endX:object.endX!+dx,endY:object.endY!+dy};
}
export function validDrawingShape(object:DrawingObject,width=1,height=1,minimum=0){
 if(object.kind==='path')return !!object.points&&object.points.length>=2&&object.points.some(p=>Math.hypot((p.x-object.points![0].x)*width,(p.y-object.points![0].y)*height)>minimum);
 if(!isDrawingShape(object))return true;
 const dx=Math.abs(object.endX!-object.x)*width,dy=Math.abs(object.endY!-object.y)*height;
 return object.kind==='line'?Math.hypot(dx,dy)>minimum:dx>minimum&&dy>minimum;
}
export function shapeBounds(object:DrawingObject,width:number,height:number){return {x:Math.min(object.x,object.endX!)*width,y:Math.min(object.y,object.endY!)*height,width:Math.abs(object.endX!-object.x)*width,height:Math.abs(object.endY!-object.y)*height};}
export function drawingLayerVisible(layers:MapLayer[]|undefined,id?:string){return !id||layers?.find(layer=>layer.id===id)?.visible!==false;}
export function drawingLayerEditable(layers:MapLayer[]|undefined,id?:string){return drawingLayerVisible(layers,id)&&(!id||!layers?.find(layer=>layer.id===id)?.locked);}
/** Stable pattern payload for the editor; keep it outside changing brush geometry. */
export function drawingMaterialDefinitions(drawing:MapDrawing,layers?:MapLayer[]){
 const materials=drawing.strokes.filter(stroke=>drawingLayerVisible(layers,stroke.layerId)&&isTerrainMaterial(stroke.material)).map(stroke=>stroke.material!);
 const scale=materialScale(drawing.textureFrame?.width??drawing.width,drawing.textureFrame?.height??drawing.height),variants=new Map<string,DrawingStroke>();
 for(const stroke of drawing.strokes)if(drawingLayerVisible(layers,stroke.layerId)&&isTerrainMaterial(stroke.material)&&materialPatternId(stroke.material,stroke)!==materialPatternId(stroke.material))variants.set(materialPatternId(stroke.material,stroke),stroke);
 return materialMaskDefinitions(drawing)+materialDefinitions(materials,scale,drawing.textureFrame)+[...variants.values()].map(stroke=>materialDefinitions([stroke.material!],scale,drawing.textureFrame,stroke)).join('')+brushDefinitions(drawing.strokes.some(stroke=>stroke.materialMask)?drawing.strokes:drawing.strokes.filter(stroke=>drawingLayerVisible(layers,stroke.layerId)));
}
type DrawingParts={patterns:string;background:string;layers:{id?:string;terrain:string;objects:string}[]};
const partsCache=new WeakMap<MapDrawing,{layers?:MapLayer[];labels:boolean;editing:boolean;parts:DrawingParts}>();
/** Committed layers retain their DOM while a live stroke changes above its own terrain. */
export function drawingParts(drawing:MapDrawing,showLabels=true,layers?:MapLayer[],editing=false):DrawingParts {
 const cached=partsCache.get(drawing);if(cached&&cached.layers===layers&&cached.labels===showLabels&&cached.editing===editing)return cached.parts;
 const {width:w,height:h}=drawing;
 const definitions=drawingMaterialDefinitions(drawing,layers);
 let terrainLayer=0;
 const priorTerrain:DrawingStroke[]=[];
 const renderStrokes=(items:DrawingStroke[])=>{
  const result=renderTerrainStrokes(items,w,h,`ws-map-terrain-${terrainLayer++}`,priorTerrain,drawing.background===seaColor&&(drawing.theme??'medieval')==='medieval',materialScale(drawing.textureFrame?.width??w,drawing.textureFrame?.height??h));
  priorTerrain.push(...items);return result;
 };
 const renderObjects=(items:DrawingObject[])=>items.map(object=>{
  const x=n(object.x*w),y=n(object.y*h),size=n(object.size*w);
  if(object.kind==='path'){
   const d=drawingPath(object.points??[],w,h,object.smooth),strokeWidth=n((object.lineWidth??.003)*w);
   return `<g data-art-id="${escape(object.id)}"${editing&&!drawingLayerEditable(layers,object.layerId)?' pointer-events="none"':''}><path d="${d}" fill="none" stroke="${object.color??'#465648'}" stroke-width="${strokeWidth}"${object.dashed?` stroke-dasharray="${n(strokeWidth*3)} ${n(strokeWidth*2)}"`:''} stroke-linecap="round" stroke-linejoin="round"/><path d="${d}" fill="none" stroke="transparent" stroke-width="${Math.max(strokeWidth,12)}"/></g>`;
  }
  if(isDrawingShape(object)){
   const x2=n(object.endX!*w),y2=n(object.endY!*h),color=object.color??'#465648',strokeWidth=n((object.lineWidth??.003)*w),hitWidth=Math.max(strokeWidth,12);
   const geometry=object.kind==='line'?`line x1="${x}" y1="${y}" x2="${x2}" y2="${y2}"`:`ellipse cx="${n((x+x2)/2)}" cy="${n((y+y2)/2)}" rx="${n(Math.abs(x2-x)/2)}" ry="${n(Math.abs(y2-y)/2)}"`;
   return `<g data-art-id="${escape(object.id)}"${editing&&!drawingLayerEditable(layers,object.layerId)?' pointer-events="none"':''}><${geometry} fill="${object.kind==='ellipse'?(object.fill??'none'):'none'}" stroke="${color}" stroke-width="${strokeWidth}" stroke-linecap="round"/><${geometry} fill="${object.kind==='line'?'none':'transparent'}" stroke="transparent" stroke-width="${hitWidth}"/></g>`;
  }
  if(object.kind==='label')return showLabels?`<g data-art-id="${escape(object.id)}"${editing&&!drawingLayerEditable(layers,object.layerId)?' pointer-events="none"':''}><text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="middle" font-family="Georgia,serif" font-size="${size}" fill="${object.color??'#303c35'}" stroke="${object.halo??'#f5efd6'}" stroke-width="${n(size*.13)}" stroke-linejoin="round" paint-order="stroke" style="white-space:pre">${escape(object.text??'')}</text></g>`:'';
  return `<g data-art-id="${escape(object.id)}"${editing&&!drawingLayerEditable(layers,object.layerId)?' pointer-events="none"':''} transform="rotate(${n(object.rotation??0)} ${x} ${y}) translate(${n(x-size/2)} ${n(y-size/2)}) scale(${n(size/64)})" stroke="#465648" stroke-width="2" stroke-linejoin="round" stroke-linecap="round">${symbolArtwork[object.kind as DrawingSymbol]}</g>`;
 }).join('');
 const background=drawing.background?`<rect width="${w}" height="${h}" fill="${drawing.background}"/>`:'';
 const ids=layers?[undefined,...layers.filter(layer=>layer.visible).map(layer=>layer.id)]:[undefined];
 const parts={patterns:definitions,background,layers:ids.map(id=>({id,terrain:renderStrokes(layers?drawing.strokes.filter(stroke=>stroke.layerId===id):drawing.strokes),objects:renderObjects(layers?drawing.objects.filter(object=>object.layerId===id):drawing.objects)}))};
 partsCache.set(drawing,{layers,labels:showLabels,editing,parts});return parts;
}
export function drawingContent(drawing:MapDrawing,showLabels=true,layers?:MapLayer[],editing=false,includeMaterialPatterns=true):string {
 const parts=drawingParts(drawing,showLabels,layers,editing);
 return (includeMaterialPatterns?parts.patterns:'')+parts.background+parts.layers.map(layer=>layer.terrain+layer.objects).join('');
}
export function drawingSvg(drawing:MapDrawing,showLabels=true,layers?:MapLayer[]){return `<svg xmlns="http://www.w3.org/2000/svg" width="${drawing.width}" height="${drawing.height}" viewBox="0 0 ${drawing.width} ${drawing.height}">${drawingContent(drawing,showLabels,layers)}</svg>`;}
const urlCache=new WeakMap<MapDrawing,{layers?:MapLayer[];labels?:string;plain?:string}>();
export function drawingDataUrl(drawing:MapDrawing,showLabels=true,layers?:MapLayer[]){const previous=urlCache.get(drawing),cached=previous?.layers===layers?previous??{}:{layers},key=showLabels?'labels':'plain';if(!cached[key]){cached[key]=`data:image/svg+xml;charset=utf-8,${encodeURIComponent(drawingSvg(drawing,showLabels,layers))}`;urlCache.set(drawing,cached);}return cached[key]!;}
export function drawingPoint(clientX:number,clientY:number,rect:{left:number;top:number;width:number;height:number}):DrawingPoint|null{
 return rect.width>0&&rect.height>0?{x:Math.max(0,Math.min(1,(clientX-rect.left)/rect.width)),y:Math.max(0,Math.min(1,(clientY-rect.top)/rect.height))}:null;
}

export function resizeDrawingObject(object:DrawingObject,position:DrawingPoint,handle:'start'|'end',width:number,height:number):DrawingObject{
 if(isDrawingShape(object)){
  const next=handle==='start'?{...object,x:position.x,y:position.y}:{...object,endX:position.x,endY:position.y};
  return validDrawingShape(next,width,height,2)?next:object;
 }
 const angle=-(object.rotation??0)*Math.PI/180,dx=(position.x-object.x)*width,dy=(position.y-object.y)*height;
 const radius=Math.max(Math.abs(dx*Math.cos(angle)-dy*Math.sin(angle)),Math.abs(dx*Math.sin(angle)+dy*Math.cos(angle)))/width;
 return {...object,size:Math.max(.005,Math.min(.25,radius*2))};
}
export function duplicateDrawingObject(object:DrawingObject):DrawingObject{
 const x=object.x+(Math.max(object.x,object.endX??object.x,...(object.points?.map(p=>p.x)??[]))>.95?-.025:.025),y=object.y+(Math.max(object.y,object.endY??object.y,...(object.points?.map(p=>p.y)??[]))>.95?-.025:.025);
 return {...moveDrawingObject(object,{x:Math.max(0,Math.min(1,x)),y:Math.max(0,Math.min(1,y))}),id:crypto.randomUUID()};
}

/** Apply one bounded translation to the whole set, preserving relative positions. */
export function moveDrawingObjects(objects:DrawingObject[],ids:string[],delta:DrawingPoint):DrawingObject[]{
 const targets=objects.filter(object=>ids.includes(object.id));if(!targets.length)return objects;
 const xs=targets.flatMap(object=>object.kind==='path'?object.points!.map(p=>p.x):isDrawingShape(object)?[object.x,object.endX!]:[object.x]),ys=targets.flatMap(object=>object.kind==='path'?object.points!.map(p=>p.y):isDrawingShape(object)?[object.y,object.endY!]:[object.y]);
 const dx=Math.max(-Math.min(...xs),Math.min(1-Math.max(...xs),delta.x)),dy=Math.max(-Math.min(...ys),Math.min(1-Math.max(...ys),delta.y));
 if(!dx&&!dy)return objects;
 return objects.map(object=>ids.includes(object.id)?{...object,x:object.x+dx,y:object.y+dy,...(object.kind==='path'?{points:object.points!.map(p=>({x:p.x+dx,y:p.y+dy}))}:isDrawingShape(object)?{endX:object.endX!+dx,endY:object.endY!+dy}:{})}:object);
}
export function drawingObjectBounds(object:DrawingObject,width:number,height:number){
 if(object.kind==='path'){const xs=object.points!.map(p=>p.x*width),ys=object.points!.map(p=>p.y*height),x=Math.min(...xs),y=Math.min(...ys);return {x,y,width:Math.max(...xs)-x,height:Math.max(...ys)-y};}
 if(isDrawingShape(object))return shapeBounds(object,width,height);
 const angle=(object.rotation??0)*Math.PI/180,side=object.size*width;
 const w=object.kind==='label'?side*Math.max(1,Array.from(object.text??'').length*.6):side*(Math.abs(Math.cos(angle))+Math.abs(Math.sin(angle))),h=object.kind==='label'?side:w;
 return {x:object.x*width-w/2,y:object.y*height-h/2,width:w,height:h};
}
export function drawingObjectsInRect(drawing:MapDrawing,start:DrawingPoint,end:DrawingPoint,layers:MapLayer[]):string[]{
 const x=Math.min(start.x,end.x)*drawing.width,y=Math.min(start.y,end.y)*drawing.height,right=Math.max(start.x,end.x)*drawing.width,bottom=Math.max(start.y,end.y)*drawing.height;
 return drawing.objects.filter(object=>{if(!drawingLayerEditable(layers,object.layerId))return false;const b=drawingObjectBounds(object,drawing.width,drawing.height);return b.x<=right&&b.x+b.width>=x&&b.y<=bottom&&b.y+b.height>=y;}).map(object=>object.id);
}
