import {t} from './i18n';
import type {WorldMap} from './maps';
export type CanvasMargins={top:number;right:number;bottom:number;left:number};
export const maxMapCanvasSize=4096;
/** Add map-space pixels, preserving physical sizes, links and calibration. */
export function expandMapCanvas(map:WorldMap,margins:CanvasMargins):WorldMap|null{
 const old=map.drawing;if(!old||Object.values(margins).some(n=>!Number.isInteger(n)||n<0)||!Object.values(margins).some(n=>n>0))return null;
 const width=old.width+margins.left+margins.right,height=old.height+margins.top+margins.bottom;
 if(width>maxMapCanvasSize||height>maxMapCanvasSize)return null;
 const point=<T extends {x:number;y:number}>(p:T):T=>({...p,x:(p.x*old.width+margins.left)/width,y:(p.y*old.height+margins.top)/height});
 const ratio=old.width/width,frame=map.imageFrame??{x:0,y:0,width:1,height:1};
 return {...map,imageFrame:{...point(frame),width:frame.width*ratio,height:frame.height*old.height/height},
 drawing:{...old,width,height,textureFrame:{x:(old.textureFrame?.x??0)+margins.left,y:(old.textureFrame?.y??0)+margins.top,width:old.textureFrame?.width??old.width,height:old.textureFrame?.height??old.height},strokes:old.strokes.map(stroke=>({...stroke,width:stroke.width*ratio,points:stroke.points.map(point),...(stroke.mask?{mask:{...stroke.mask,points:stroke.mask.points.map(point),...(stroke.mask.holes?{holes:stroke.mask.holes.map(ring=>ring.map(point))}:{})}}:{})})),objects:old.objects.map(object=>({...point(object),size:object.size*ratio,...(object.stamp?{stamp:{...object.stamp,baseSize:object.stamp.baseSize*ratio}}:{}),...(object.points?{points:object.points.map(point)}:{}),...(object.endX!==undefined&&object.endY!==undefined?{endX:(object.endX*old.width+margins.left)/width,endY:(object.endY*old.height+margins.top)/height}:{}),...(object.lineWidth!==undefined?{lineWidth:object.lineWidth*ratio}:{})}))},
 markers:map.markers.map(point),regions:map.regions?.map(region=>({...region,points:region.points.map(point),...(region.holes?{holes:region.holes.map(hole=>hole.map(point))}:{}),...(region.labelPosition?{labelPosition:point(region.labelPosition)}:{})})),
 ...(map.scale?{scale:{...map.scale,from:point(map.scale.from),to:point(map.scale.to),aspectRatio:map.scale.aspectRatio*(width/old.width)/(height/old.height)}}:{})};
}
/** Prepare the original image in its retained frame without changing its stored asset. */
export async function framedMapImage(blob:Blob,map:WorldMap):Promise<Blob>{
 if(!map.imageFrame||!map.drawing)return blob;
 const url=URL.createObjectURL(blob);
 try{
  const image=new Image();image.src=url;await image.decode();
  const canvas=document.createElement('canvas');canvas.width=map.drawing.width;canvas.height=map.drawing.height;
  const ctx=canvas.getContext('2d');if(!ctx)throw new Error(t('Image processing is unavailable.'));
  const frame=map.imageFrame;ctx.drawImage(image,frame.x*canvas.width,frame.y*canvas.height,frame.width*canvas.width,frame.height*canvas.height);
  return await new Promise<Blob>((resolve,reject)=>canvas.toBlob(value=>value?resolve(value):reject(new Error(t('Image processing is unavailable.'))),'image/png'));
 }finally{URL.revokeObjectURL(url);}
}
