import {t} from './i18n';
import type {EntryRelationType} from './entryRelations';
export type RelationshipPreset='romantic-interest'|'guardian'|'partner'|'former-partner'|'step-parent';
export const relationshipPresetNames:Record<RelationshipPreset,string>={'romantic-interest':'Romantic interest',guardian:'Guardian / ward',partner:'Partners','former-partner':'Former partners','step-parent':'Step-parent / stepchild'};
export const relationshipPresetDescriptions:Record<RelationshipPreset,string>={
 'romantic-interest':'This model starts as directional romantic interest in the network only. It does not imply a couple, an ex-partner or kinship.',
 guardian:'This model starts as guardian / ward, without implying filiation.',
 partner:'This model starts as a symmetric couple relationship in genealogy.',
 'former-partner':'This model starts as a symmetric former-partner relationship in genealogy.',
 'step-parent':'This model starts as step-parent / stepchild, distinct from biological or adoptive filiation.'
};
export function relationshipPreset(preset:RelationshipPreset):EntryRelationType{
 const base={id:'',name:t(relationshipPresetNames[preset]),sourceTemplateIds:[],targetTemplateIds:[]};
 if(preset==='romantic-interest')return {...base,title:t('Interested person'),inverseTitle:t('Person of interest'),symmetric:false};
 if(preset==='guardian')return {...base,title:t('Guardian'),inverseTitle:t('Ward'),symmetric:false,genealogy:{kind:'guardian',parentRole:'source'}};
 if(preset==='step-parent')return {...base,title:t('Step-parent'),inverseTitle:t('Stepchild'),symmetric:false,genealogy:{kind:'stepParent',parentRole:'source'}};
 return {...base,title:base.name,inverseTitle:base.name,symmetric:true,genealogy:{kind:preset==='partner'?'partner':'formerPartner'}};
}
