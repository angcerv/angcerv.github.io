import {useEffect,useMemo,useState} from 'react';
import {X,Plus} from 'lucide-react';
import CalendarDateContext from './CalendarDateContext';
import CalendarEventButton from './CalendarEventButton';
import {calendarDayEvents,calendarEventRanges,storedCalendarDate,normalizeCalendarPosition} from './calendarBrowse';
import {calendarWorldDateLabel} from './storyCalendar';
import type {StoryCalendar} from './storyCalendar';
import type {StoryDate,TimelineEvent} from './timeline';
import {formatStoryDate} from './timeline';
import {t} from './i18n';
export default function CalendarDayInspector({calendar,date,events,selectedId,onSelectEvent,onClose,onCreate}:{calendar:StoryCalendar;date?:StoryDate;events:TimelineEvent[];selectedId:string;onSelectEvent:(id:string)=>void;onClose:()=>void;onCreate?:()=>void}){
 const normalized=date?normalizeCalendarPosition(calendar,{year:date.year,month:date.month??1,day:date.day??1,page:0}):undefined;
 const day=normalized?{year:normalized.year,month:normalized.month,day:normalized.day}:undefined;
 const [shown,setShown]=useState(50),ranges=useMemo(()=>calendarEventRanges(events),[events]),matches=day?calendarDayEvents(day,calendar,ranges.exact):[],stored=day?storedCalendarDate(day,calendar):undefined;
 useEffect(()=>setShown(50),[day?.year,day?.month,day?.day]);
 return <aside className="timeline-inspector calendar-day-inspector" aria-label={t('Day details')}><header><h2 data-inspector-heading tabIndex={-1}>{t('Day details')}</h2><button type="button" aria-label={t('Hide day details')} title={t('Hide day details')} onClick={onClose}><X size={17}/></button></header><div className="timeline-inspector-body">{day?<><h3 className="calendar-day-title">{calendarWorldDateLabel(day,calendar)}</h3>{stored?<p className="calendar-day-stored">{t('Stored date: {0}',formatStoryDate(stored))}</p>:<p className="prompt-error">{t('This date is outside the stored timeline range.')}</p>}<CalendarDateContext date={day} calendar={calendar} worldDate/>{onCreate&&stored&&<button type="button" className="quick-action quick-action-text" onClick={onCreate}><Plus size={15}/>{t('New event on this day')}</button>}<h3 className="calendar-day-events-heading">{t('Events')} <span className="compact-count">{matches.length}</span></h3>{matches.length?<>{matches.slice(0,shown).map(event=><CalendarEventButton key={event.id} event={event} selected={event.id===selectedId} onSelect={onSelectEvent}/>)}{matches.length>shown&&<button type="button" className="quick-action quick-action-text" onClick={()=>setShown(shown+50)}>{t('Show more events')}</button>}</>:<p className="ui-empty-state ui-empty-state-compact">{t('No matching events on this day.')}</p>}</>:<p className="ui-empty-state ui-empty-state-compact">{t('Select a day to inspect it.')}</p>}</div></aside>;
}
