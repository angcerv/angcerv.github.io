export function menuNavigationIndex(key:string,current:number,count:number) {
 if(!count)return -1;
 if(key==='Home')return 0;
 if(key==='End')return count-1;
 if(current<0)return key==='ArrowUp'?count-1:0;
 return (current+(key==='ArrowUp'?-1:1)+count)%count;
}
