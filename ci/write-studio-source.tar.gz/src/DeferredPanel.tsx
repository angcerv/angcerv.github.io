import {Component,Suspense,lazy,memo,useEffect,useMemo,useRef,useState} from 'react';
import type {ComponentType,ReactNode} from 'react';
import {t} from './i18n';
import {LoaderCircle} from 'lucide-react';

class PanelLoadBoundary extends Component<{onRetry:()=>void;onSettled?:()=>void;children:ReactNode},{failed:boolean}>{
 state={failed:false};
 static getDerivedStateFromError(){return {failed:true};}
 componentDidCatch(){this.props.onSettled?.();}
 render(){return this.state.failed?<div className="ui-empty-state" role="alert"><p>{t('This panel could not be loaded.')}</p><button type="button" className="quick-action quick-action-text" onClick={this.props.onRetry}>{t('Retry')}</button></div>:this.props.children;}
}

function PanelReady({onReady,children}:{onReady?:()=>void;children:ReactNode}){
 useEffect(()=>{onReady?.();},[onReady]);
 return children;
}

/** Load a workspace on first use, then keep its existing mount/drafts on navigation. */
export function deferPanel<P extends object>(load:()=>Promise<{default:ComponentType<P>}>){
 return function DeferredPanel({deferUntil=false,onPanelReady,...props}:P&{deferUntil?:boolean;onPanelReady?:()=>void}){
  const visited=useRef(false),[attempt,setAttempt]=useState(0);
  // Deactivate once to release inspectors, then avoid background recalculation.
  // React receives the latest props again as soon as the workspace is active.
  const Panel=useMemo(()=>memo(lazy(load),(previous,next)=>
   (previous as {active?:boolean}).active===false&&(next as {active?:boolean}).active===false
  ),[attempt]);
  if(!deferUntil)visited.current=true;
  if(!visited.current)return null;
  return <PanelLoadBoundary key={attempt} onSettled={onPanelReady} onRetry={()=>setAttempt(value=>value+1)}><Suspense fallback={<div className="ui-panel-loading" data-panel-loading="" role="status"><LoaderCircle className="ui-loading-spinner" size={28} aria-hidden="true"/><span className="visually-hidden">{t('Loading…')}</span></div>}><PanelReady onReady={onPanelReady}><Panel {...props as P}/></PanelReady></Suspense></PanelLoadBoundary>;
 };
}
