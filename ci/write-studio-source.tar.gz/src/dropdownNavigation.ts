import type {SemanticTone} from './semanticStatus';
export type DropdownOption = { value: string; label: string; searchText?:string; disabled?: boolean; tone?:SemanticTone };
export function nextEnabled(options: DropdownOption[], current: number, direction: -1 | 1): number {
  if (!options.length) return -1;
  for (let step = 1; step <= options.length; step++) {
    const index = ((current + direction * step) % options.length + options.length) % options.length;
    if (!options[index].disabled) return index;
  }
  return -1;
}
export function initialOption(options: DropdownOption[], value: string, preferLast = false): number {
  const selected = options.findIndex(option => option.value === value && !option.disabled);
  return selected >= 0 ? selected : nextEnabled(options, preferLast ? 0 : -1, preferLast ? -1 : 1);
}
export function normalizeOptionText(value: string): string { return value.normalize('NFKD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase(); }
export function matchingOption(options: DropdownOption[], query: string, start: number): number {
  const prefix = normalizeOptionText(query);
  if (!prefix || !options.length) return -1;
  for (let step = 0; step < options.length; step++) {
    const index = ((start + step) % options.length + options.length) % options.length;
    if (!options[index].disabled && normalizeOptionText(options[index].searchText??options[index].label).startsWith(prefix)) return index;
  }
  return -1;
}
