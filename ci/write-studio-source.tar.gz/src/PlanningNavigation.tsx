import {t,buttonLabel} from './i18n';
import {ClipboardList,GitBranch,UserRound,StickyNote} from 'lucide-react';
export default function PlanningNavigation({selected,onSelect}:{selected:'chapters'|'plots'|'arcs'|'canvas';onSelect:(value:'chapters'|'plots'|'arcs'|'canvas')=>void}){
 return <nav className="workspace-tabs workspace-tabs-internal module-navigation" aria-label={t('Planning sections')}>{([{id:'chapters',label:'Chapters and scenes',Icon:ClipboardList},{id:'plots',label:'Plots',Icon:GitBranch},{id:'arcs',label:'Character arcs',Icon:UserRound},{id:'canvas',label:'Idea canvases',Icon:StickyNote}] as const).map(({id,label,Icon})=><button type="button" key={id} aria-current={selected===id?'page':undefined} onClick={()=>onSelect(id)}><Icon size={16}/>{buttonLabel(label)}</button>)}</nav>;
}
