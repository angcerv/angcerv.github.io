import {useEffect} from 'react';
import type {ReactNode} from 'react';
import {BookOpen,LibraryBig,MoreHorizontal,Plus} from 'lucide-react';
import type {Project} from './model';
import {bookSelection,selectionBook} from './books';
import {useWorkspaceState} from './useWorkspaceState';
import Dropdown from './Dropdown';
import ActionMenu from './ActionMenu';
import {t} from './i18n';
export default function BookNavigation({project,bookId,selectedId='',onSelect,onManage,inline=false,labelAction,selectorAction}:{project:Project;bookId:string;selectedId?:string;onSelect:(id:string,selection?:string)=>void;onManage:(create?:boolean)=>void;inline?:boolean;labelAction?:ReactNode;selectorAction?:ReactNode}){
 const [selections,setSelections]=useWorkspaceState<Record<string,string>>('manuscript.bookSelections',{});
 useEffect(()=>{if(bookId&&selectedId&&selectionBook(project,selectedId)?.id===bookId&&selections[bookId]!==selectedId)setSelections(current=>({...current,[bookId]:selectedId}));},[bookId,selectedId]);
 const book=project.books?.find(book=>book.id===bookId),name=book?.title??project.title;
 function select(id:string){
  if(id===bookId)return;
  if(bookId&&selectedId)setSelections(current=>({...current,[bookId]:selectedId}));
  onSelect(id,bookSelection(project,id,selections[id]));
 }
 const selector=(project.books?.length??0)>1?<Dropdown id={inline?'active-book-inline':'active-book'} aria-label={t('Active book')} variant="navigation" icon={<BookOpen size={17}/>} searchable value={bookId} options={project.books!.map((item,index)=>({value:item.id,label:`${index+1} · ${item.title}`,searchText:item.title}))} onChange={select}/>:<span className="book-navigation-name" title={name}><BookOpen size={17} aria-hidden="true"/><span>{name}</span></span>;
 const menu=<ActionMenu iconOnly label={t('Book options')} actions={[{label:t('Manage books'),icon:<LibraryBig size={18}/>,onClick:()=>onManage()},{label:t('New book'),icon:<Plus size={18}/>,onClick:()=>onManage(true)}]}><MoreHorizontal size={18} aria-hidden="true"/></ActionMenu>;
 return inline?<div className="book-navigation book-navigation-inline" aria-label={t('Active book')}><div className="book-navigation-current"><span className="book-navigation-label">{t('Book')}</span>{labelAction}{selector}</div>{menu}</div>:<div className="book-navigation" aria-label={t('Active book')}><div className="book-navigation-heading"><span className="book-navigation-label">{t('Book')}</span><div className="book-navigation-label-actions">{menu}{labelAction}</div></div><div className="book-navigation-current">{selector}{selectorAction}</div></div>;
}
