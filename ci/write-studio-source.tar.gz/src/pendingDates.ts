import type {Project,Scene} from './model';
import {getSceneStatus} from './model';
import {reviewContinuity} from './continuity';
import {continuityEvidence} from './narrativeContinuity';
import {countSceneWords} from './writingGoals';

export type PendingDates={createdAt?:string;updatedAt?:string};
// Evidence stays in memory. Only dates belong in the saved project.
const snapshots=new WeakMap<Project,Map<string,string>>();
const sceneSnapshots=new WeakMap<Scene,Map<string,string>>();
function fingerprint(value:unknown):string{
 const text=JSON.stringify(value);let a=2166136261,b=5381;
 for(let i=0;i<text.length;i++){const code=text.charCodeAt(i);a=Math.imul(a^code,16777619);b=Math.imul(b,33)^code;}
 return `${text.length}:${a>>>0}:${b>>>0}`;
}
function snapshot(project:Project):Map<string,string>{
 const cached=snapshots.get(project);if(cached)return cached;
 const result=new Map<string,string>();
 for(const chapter of project.chapters)for(const scene of chapter.scenes){
  let evidence=sceneSnapshots.get(scene);
  if(!evidence){
   evidence=new Map<string,string>();
   for(const comment of scene.reviewComments??[])if(!comment.resolved)evidence.set(`comment:${comment.id}`,fingerprint([comment.text,comment.quote,!!comment.detached]));
   const status=getSceneStatus(scene);
   if(status==='inReview')evidence.set(`review:${scene.id}`,fingerprint([scene.title,scene.content,scene.synopsis,scene.planning]));
   if(status!=='finished'&&(countSceneWords(scene.content)===0||!scene.synopsis?.trim()))evidence.set(`develop:${scene.id}`,fingerprint([scene.title,scene.content,scene.synopsis,scene.planning]));
   sceneSnapshots.set(scene,evidence);
  }
  for(const [id,value] of evidence)result.set(id,value);
 }
 // Include dismissed warnings too: local filters and dismissal decisions are not edits.
 for(const issue of reviewContinuity(project))if(issue.kind!=='unused')result.set(`continuity:${issue.id}`,continuityEvidence(project,issue));
 snapshots.set(project,result);return result;
}
export function stampPendingDates(before:Project|undefined,next:Project,now=new Date().toISOString()):Project{
 if(!before||before.id!==next.id)return next;
 // Idea edits, navigation and other unrelated metadata do not scan the manuscript.
 if(before.chapters===next.chapters&&before.worldbuilding===next.worldbuilding&&before.maps===next.maps&&before.timeline===next.timeline&&before.plots===next.plots&&before.entryRelations===next.entryRelations)return next;
 const previous=snapshot(before),current=snapshot(next),dates:Record<string,PendingDates>={};
 for(const [id,evidence] of current){
  const old=before.pendingDates?.[id];
  if(!previous.has(id))dates[id]={createdAt:now,updatedAt:now};
  else if(previous.get(id)!==evidence)dates[id]={...old,updatedAt:now};
  else if(old)dates[id]=old;
 }
 const result={...next,pendingDates:Object.keys(dates).length?dates:undefined};
 snapshots.set(result,current);return result;
}
