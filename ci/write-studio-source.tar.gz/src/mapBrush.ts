import type {DrawingPoint,DrawingStroke} from './mapDrawing';
export type TerrainBrushShape='circle'|'star'|'irregular';
const n=(value:number)=>Number(value.toFixed(3));
export const enhancedBrush=(stroke:DrawingStroke)=>!stroke.closed&&((stroke.brushShape!==undefined&&stroke.brushShape!=='circle')||(stroke.softness??0)>0);
const token=(softness:number)=>Math.round(Math.max(0,Math.min(1,softness))*1000);
export function starBrushPoints(x=0,y=0,rx=1,ry=rx){return Array.from({length:10},(_,i)=>{const angle=-Math.PI/2+i*Math.PI/5,r=i%2?.48:1;return `${n(x+Math.cos(angle)*rx*r)},${n(y+Math.sin(angle)*ry*r)}`;}).join(' ');}
/** Shallow, uneven lobes form an organic edge without deep star-shaped notches. */
export function irregularBrushPoints(x=0,y=0,rx=1,ry=rx){return Array.from({length:96},(_,i)=>{const a=-Math.PI/2+i*Math.PI*2/96,r=(.91+.035*Math.sin(3*a+.4)+.02*Math.cos(7*a+1.3)+.028*Math.sin(13*a+.8)+.017*Math.cos(19*a+.2))/1.01;return `${n(x+Math.cos(a)*rx*r)},${n(y+Math.sin(a)*ry*r)}`;}).join(' ');}
export function polygonBrushPoints(shape:TerrainBrushShape,x=0,y=0,rx=1,ry=rx){return shape==='irregular'?irregularBrushPoints(x,y,rx,ry):starBrushPoints(x,y,rx,ry);}
/** Resample by map-space arc length, independent of pointer event frequency. */
export function brushDabs(points:DrawingPoint[],width:number,height:number,radius:number){
 if(!points.length)return [];
 const segments=points.slice(1).map((point,i)=>Math.hypot((point.x-points[i].x)*width,(point.y-points[i].y)*height)),total=segments.reduce((sum,n)=>sum+n,0),spacing=Math.max(1,radius*.4,total/4094);
 const result=[{x:points[0].x*width,y:points[0].y*height}];let walked=0,next=spacing;
 for(let i=0;i<segments.length;i++){const length=segments[i];if(!length)continue;while(next<=walked+length&&result.length<4095){const t=(next-walked)/length;result.push({x:(points[i].x+(points[i+1].x-points[i].x)*t)*width,y:(points[i].y+(points[i+1].y-points[i].y)*t)*height});next+=spacing;}walked+=length;}
 const last=points[points.length-1],end={x:last.x*width,y:last.y*height},previous=result[result.length-1];if(Math.hypot(end.x-previous.x,end.y-previous.y)>1e-6)result.push(end);return result;
}
export function brushFootprint(stroke:DrawingStroke,width:number,height:number){
 const id=stroke.brushShape&&stroke.brushShape!=='circle'?`ws-brush-${stroke.brushShape}`:`ws-brush-soft-${token(stroke.softness??0)}`,radius=stroke.width*width/2;
 return `<g data-brush-shape="${stroke.brushShape??'circle'}">${brushDabs(stroke.points,width,height,radius).map(p=>`<use href="#${id}-ink-white" transform="translate(${n(p.x)} ${n(p.y)}) scale(${n(radius)})"/>`).join('')}</g>`;
}
export function brushInk(geometry:string,paint:string){return geometry.replace(/(?:fill|stroke)="white"/g,value=>value.replace('white',paint)).replace(/-ink-white/g,paint==='black'?'-ink-black':'-ink-white');}
const cachedDefinitions=new Map<string,string>();
export function brushDefinitions(strokes:DrawingStroke[]){
 const ids=[...new Set(strokes.filter(enhancedBrush).map(stroke=>stroke.brushShape&&stroke.brushShape!=='circle'?stroke.brushShape:String(token(stroke.softness??0))))].sort();if(!ids.length)return '';
 const key=ids.join(','),cached=cachedDefinitions.get(key);if(cached)return cached;
 const body=ids.map(id=>(['white','black'] as const).map(ink=>{
  if(id==='star'||id==='irregular')return `<polygon id="ws-brush-${id}-ink-${ink}" points="${polygonBrushPoints(id)}" fill="${ink}"/>`;
  const core=1-Number(id)/1000,name=`ws-brush-soft-${id}-ink-${ink}`,gradient=`${name}-gradient`;
  const stops=Array.from({length:5},(_,i)=>{const t=i/4,opacity=1-t*t*(3-2*t);return `<stop offset="${n((core+(1-core)*t)*100)}%" stop-color="${ink}" stop-opacity="${n(opacity)}"/>`;}).join('');
  return `<radialGradient id="${gradient}"><stop offset="0%" stop-color="${ink}"/>${stops}</radialGradient><circle id="${name}" r="1" fill="url(#${gradient})"/>`;
 }).join('')).join('');
 const result=`<defs>${body}</defs>`;cachedDefinitions.set(key,result);if(cachedDefinitions.size>64)cachedDefinitions.delete(cachedDefinitions.keys().next().value!);return result;
}
