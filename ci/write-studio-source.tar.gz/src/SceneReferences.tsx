import { useState } from 'react';
import { Plus, Unlink, Pin, RotateCcw, LibraryBig } from 'lucide-react';
import {t,buttonLabel} from './i18n';
import type { Scene } from './model';
import type { Worldbuilding } from './worldbuilding';
import type { MentionCommand } from './manuscriptMentions';
import type { Mention } from './mentionDetection';
import { referenceLabel } from './worldbuilding';
import { linkSceneEntry, unlinkSceneEntry } from './sceneLinks';
import { sceneReferenceSummary, sceneMentions, nextMention, mentionContext } from './mentionDetection';
import MentionChoiceDialog from './MentionChoiceDialog';

type Props={selectedEntryId?:string;scene:Scene;world:Worldbuilding;onChange?:(scene:Scene)=>void;onOpen:(id:string)=>void;onLink:()=>void;onJump?:(range:{from:number;to:number})=>void;onCommand?:(command:MentionCommand)=>void};
export default function SceneReferences({selectedEntryId,scene,world,onChange,onOpen,onLink,onJump,onCommand}:Props){
 const {references,mentionCount,ambiguous,excluded}=sceneReferenceSummary(scene,world);
 const [choice,setChoice]=useState<Mention|null>(null);
 const [navigation,setNavigation]=useState<{entryId:string;from:number;to:number;content:string}|null>(null);
 function jump(id:string){
  const mentions=sceneMentions(scene,world).filter(item=>item.entryIds.length===1&&item.entryIds[0]===id);
  const previous=navigation?.entryId===id&&navigation.content===scene.content?navigation:undefined;
  const next=nextMention(mentions,previous);if(!next||!onJump)return;
  setNavigation({entryId:id,from:next.from,to:next.to,content:scene.content});onJump(next);
 }
 const currentMentions=navigation?sceneMentions(scene,world).filter(item=>item.entryIds.length===1&&item.entryIds[0]===navigation.entryId):[];
 const currentIndex=navigation?.content===scene.content?currentMentions.findIndex(item=>item.from===navigation.from&&item.to===navigation.to):-1;
 return <section className="scene-reference-priority" aria-label={t('Current scene references')}>
  {choice&&<MentionChoiceDialog world={world} ids={choice.entryIds} label={choice.label} onClose={()=>setChoice(null)} onChoose={id=>{onCommand?.({kind:'resolve',from:choice.from,to:choice.to,text:choice.label,entryId:id});setChoice(null);onOpen(id);}}/>}
  <div className="linked-entries-heading"><h3>{t('Scene references')}</h3>{onChange&&<button type="button" onClick={onLink}><Plus size={14}/>{buttonLabel('Link entry…')}</button>}</div>
  <p className="world-hint">{scene.title||t('Untitled scene')}</p>
  <p className="scene-reference-counts">{t('{0} entries · {1} text mentions',references.length,mentionCount)}</p>
  <div className="scene-reference-list">{references.map(reference=>{
   const entry=world.entries.find(entry=>entry.id===reference.id);
   return <div className={`scene-reference-row${selectedEntryId===reference.id?' is-selected':''}`} key={reference.id}>
    {entry?<button type="button" className="scene-reference-open" data-reference-id={reference.id} aria-pressed={selectedEntryId===reference.id} title={t('Open entry {0}',referenceLabel(world,entry.id))} onClick={()=>onOpen(entry.id)}><span className="scene-reference-icon" aria-hidden="true"><LibraryBig size={16}/></span><span className="scene-reference-identity"><span className="scene-reference-name">{referenceLabel(world,entry.id)}</span><small><span className="scene-reference-template">{world.templates.find(template=>template.id===entry.templateId)?.title||t('Untitled template')}</span>{reference.manual&&<span className="scene-reference-manual" title={t('Manual link')} aria-label={t('Manual link')}><Pin size={10} aria-hidden="true"/></span>}</small></span></button>:<span className="reference-missing scene-reference-identity">{t('Missing entry')}</span>}
    <button type="button" className="scene-mention-counter" disabled={!onJump||reference.count===0} aria-label={t('Go to next mention of {0} ({1} total)',referenceLabel(world,reference.id),reference.count)} title={t('Click to cycle through mentions')} onClick={()=>jump(reference.id)}>{reference.count===1?t('1 mention'):t('{0} mentions',reference.count)}</button>
    {onChange&&(reference.manual||!entry?.archived)&&<button type="button" className="icon-button" aria-label={reference.manual?t('Unlink {0} from scene',referenceLabel(world,reference.id)):t('Keep {0} linked manually',referenceLabel(world,reference.id))} title={reference.manual?t('Remove manual link (text mentions remain)'):t('Keep linked even without text mentions')} onClick={()=>onChange(reference.manual?unlinkSceneEntry(scene,reference.id):linkSceneEntry(scene,world,reference.id))}>{reference.manual?<Unlink size={14}/>:<Pin size={14}/>}</button>}
   </div>;
  })}</div>
  <p className="world-hint mention-navigation-status" role="status">{currentIndex>=0&&navigation?t('{0} · mention {1} of {2}',referenceLabel(world,navigation.entryId),currentIndex+1,currentMentions.length):''}</p>
  {!references.length&&!ambiguous.length&&<p className="world-hint">{t('Names in the text appear here automatically. You can also link an entry manually.')}</p>}
  {ambiguous.length>0&&<details className="scene-mention-review" open><summary>{t('{0} ambiguous mentions · choose an entry',ambiguous.length)}</summary><div>{ambiguous.map(mention=><div className="scene-mention-review-row" key={`${mention.from}:${mention.to}`}><button type="button" className="mention-context" disabled={!onJump} onClick={()=>onJump?.(mention)} title={t('Locate this mention')}>{mentionContext(scene,mention.from,mention.to)}</button><button type="button" disabled={!onCommand} onClick={()=>setChoice(mention)}>{t('Choose entry')}</button></div>)}</div></details>}
  {excluded.length>0&&<details className="scene-mention-review"><summary>{t('{0} excluded mentions',excluded.length)}</summary><div>{excluded.map(mention=><div className="scene-mention-review-row" key={`${mention.from}:${mention.to}`}><button type="button" className="mention-context" disabled={!onJump} onClick={()=>onJump?.(mention)} title={t('Locate this mention')}>{mentionContext(scene,mention.from,mention.to)}</button><button type="button" disabled={!onCommand} aria-label={t('Restore link for “{0}”',mention.label)} onClick={()=>onCommand?.({from:mention.from,to:mention.to,text:mention.label,ignored:true})}><RotateCcw size={13}/>{t('Restore link')}</button></div>)}</div></details>}
 </section>;
}
