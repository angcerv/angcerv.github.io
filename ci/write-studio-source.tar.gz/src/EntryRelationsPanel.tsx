import {familyOverview} from './familyOverview';
import {partnershipLabel} from './partnership';
import {LineageMembership} from './FamilyLineages';
import {statusTone} from './semanticStatus';
import {relationshipStatus,relationshipStatusText} from './relationshipTime';
import type {StoryDate} from './timeline';
import {useState} from 'react';
import {Network,GitBranch,Plus,Unlink,Pencil,Settings,ArrowRight} from 'lucide-react';
import {t} from './i18n';
import RelationDialog from './RelationDialog';
import EntryConnectionDialog from './EntryConnectionDialog';
import {emptyEntryRelations,normalizeEntryRelations,entryConnections,relationTypeName,removeEntryConnection,connectionProblem,connectionDateLabel,isFormerPartner,hasAncestryCycle} from './entryRelations';
import type {EntryRelations} from './entryRelations';
import type {Worldbuilding,Entry} from './worldbuilding';
export default function EntryRelationsPanel({world,entry,relations:input=emptyEntryRelations,onChange,onNavigate,onManage,onView,onOpenLineage,compact=false,at,visibleLinkIds}:{world:Worldbuilding;entry:Entry;relations?:EntryRelations;onChange:(relations:EntryRelations)=>void;onNavigate:(id:string)=>void;onManage?:()=>void;onView?:()=>void;onOpenLineage?:(id:string)=>void;compact?:boolean;at?:StoryDate;visibleLinkIds?:string[]}){
 const relations=normalizeEntryRelations(input),[editing,setEditing]=useState<string|null>(null),[removing,setRemoving]=useState(''),connections=entryConnections(relations,entry.id).filter(item=>!visibleLinkIds||visibleLinkIds.includes(item.link.id));
 const family=familyOverview(relations,entry.id);
 const typeOrder=new Map<string,number>(),typeCounts=new Map<string,number>();for(const item of connections){if(!typeOrder.has(item.type.id))typeOrder.set(item.type.id,typeOrder.size);typeCounts.set(item.type.id,(typeCounts.get(item.type.id)??0)+1);}connections.sort((a,b)=>typeOrder.get(a.type.id)!-typeOrder.get(b.type.id)!);
 return <section className="entry-relationships"><header><h3><GitBranch size={15}/>{t('Entry relationships')}</h3><div>{onView&&<button type="button" className="relation-icon-action" aria-label={t('Open network for this entry')} title={t('Open network for this entry')} onClick={onView}><Network size={18}/></button>}{!compact&&onManage&&<button type="button" className="relation-icon-action" aria-label={t('Manage relationship types')} title={t('Manage relationship types')} onClick={onManage}><Settings size={17}/></button>}<button type="button" className="primary-button entry-relationship-create" disabled={entry.archived} onClick={()=>setEditing('')}><Plus size={16}/>{t('New connection')}</button></div></header>
  {!compact&&<LineageMembership relations={relations} entryId={entry.id} onChange={onChange} onOpen={onOpenLineage}/>}
  {Object.values(family).some(ids=>ids.length>0)&&<section className="entry-family-overview" aria-label={t('Family review')}><h4>{t('Family review')} <small>· {t('All recorded connections')}</small></h4>{(['parents','partners','children'] as const).map(group=><div key={group}><span>{t(group==='parents'?'Parents':group==='partners'?'Partners':'Children')}</span><div>{family[group].length?family[group].map(id=><button type="button" className="entry-connection-link" key={id} disabled={!world.entries.some(item=>item.id===id)} onClick={()=>onNavigate(id)}>{world.entries.find(item=>item.id===id)?.title||t('Missing entry')}</button>):<small>{t('Not recorded')}</small>}</div></div>)}</section>}
  {hasAncestryCycle(relations)&&<p className="relation-review-notice" role="alert" data-semantic-tone="attention">{t('Recorded ancestry contains a cycle. Review genealogy.')}</p>}
  {!connections.length&&<p className="world-hint">{t(at?'No connections match this date.':visibleLinkIds?'No connections in the current view.':'This entry has no connections yet.')}</p>}
  <div className="entry-connection-list">{connections.map(({link,type,entryId,currentRole,relatedRole},index)=>{
   const other=world.entries.find(other=>other.id===entryId),problem=connectionProblem(relations,world,link),name=relationTypeName(type);
   const repeated=(typeCounts.get(type.id)??0)>1;
   const first=index===0||connections[index-1].type.id!==type.id;
   return <article className="entry-connection-card" key={link.id}>
    <div className="entry-connection-identity">
     {repeated&&first&&name!==currentRole&&name!==relatedRole&&<small className="entry-connection-type">{name}</small>}
     <button type="button" className="entry-connection-link" disabled={!other} onClick={()=>onNavigate(entryId)}>{other?.title||t('Missing entry')}</button>
     <div className="entry-connection-context">
      {type.needsRoleReview?<span className="relation-review-badge">{t('Roles pending review')}</span>:type.symmetric?<span>{currentRole}</span>:<span className="entry-connection-roles" aria-label={t('Current entry: {0}; related entry: {1}',currentRole,relatedRole)}><span>{currentRole}</span><ArrowRight size={13} aria-hidden="true"/><span>{relatedRole}</span></span>}
      {!repeated&&name!==currentRole&&name!==relatedRole&&<small>{name}</small>}
      {type.genealogy?.kind==='partner'&&isFormerPartner(type,link,at)&&<span>{t('Former partners')}</span>}
      {partnershipLabel(link)&&<small>{t(partnershipLabel(link)!)}</small>}
      {other?.archived&&<span className="semantic-status" data-semantic-tone="neutral">{t('Archived')}</span>}
      {at&&<span className="semantic-label" data-semantic-tone={statusTone('relationship',relationshipStatus(link,at))}>{t(relationshipStatusText(relationshipStatus(link,at)))}</span>}
      {connectionDateLabel(link)&&<small>{connectionDateLabel(link)}</small>}
     </div>
     {problem&&problem!=='ancestry'&&problem!=='review'&&<small className="relation-review-badge">{t(problem==='incompatible'?'Review template compatibility':problem==='dates'?'Review the connection dates.':problem==='duplicate'?'This connection already exists.':problem==='self'?'An entry cannot be connected to itself.':'Choose an available entry.')}</small>}
    </div>
    <div className="entry-connection-actions"><button type="button" className="relation-icon-action" title={type.needsRoleReview?t('Confirm the legacy roles in Relationships first.'):t('Edit connection')} aria-label={t('Edit connection with {0}',other?.title||t('Missing entry'))} disabled={!!type.needsRoleReview} onClick={()=>setEditing(link.id)}><Pencil size={18}/></button><button type="button" className="relation-icon-action" aria-label={t('Remove connection with {0}',other?.title||t('Missing entry'))} title={t('Remove connection; keep both entries')} onClick={()=>setRemoving(link.id)}><Unlink size={18}/></button></div>
   </article>;
  })}</div>
  {relations.types.some(type=>type.needsRoleReview)&&<button type="button" className="relation-review-link" onClick={onManage}>{t('Review legacy relationship roles')}</button>}
  {editing!==null&&<EntryConnectionDialog key={editing||'new'} entry={entry} world={world} relations={relations} connection={relations.links.find(link=>link.id===editing)} onSave={next=>{onChange(next);setEditing(null);}} onCancel={()=>setEditing(null)}/>}
  {removing&&<RelationDialog variant="confirmation" title={t('Unlink entries?')} onClose={()=>setRemoving('')}><p>{t('Only this connection is removed. Both entries are kept.')}</p><div className="relation-connection-footer"><button type="button" onClick={()=>setRemoving('')} className="quick-action quick-action-text">{t('Cancel')}</button><button type="button" className="danger-button" onClick={()=>{onChange(removeEntryConnection(relations,removing));setRemoving('');}}>{t('Unlink entries')}</button></div></RelationDialog>}
 </section>;
}
