import {message,locale,t,buttonLabel} from './i18n';
import { BookOpen, MoreHorizontal, ListX, Trash2, LoaderCircle } from 'lucide-react';
import ActionMenu from './ActionMenu';
import {useId} from 'react';
import type { RecentProject } from './storage';
export default function RecentProjects({ projects, loading, error, onOpen, onForget,onDelete, onRetry, local=false, libraryTitle,openingPath,disabled=false,variant='cards' }: { projects: RecentProject[]; loading: boolean; error: string; onOpen: (path: string,title:string) => void; onDelete?:(project:RecentProject)=>void;onForget?: (path: string) => void; local?:boolean; libraryTitle?:string;openingPath?:string;disabled?:boolean;variant?:'cards'|'selector'; onRetry: () => void }) {
  const selector=variant==='selector';
  const id=useId(),openingStatus=t("Opening project…");
  return <section className={`recent-projects${selector?' recent-projects-selector':''}`} aria-labelledby={id}>
    <div className="recent-heading"><h2 id={id}>{libraryTitle??t(local?"Projects on this device":"Recent projects")}</h2><span>{selector?(!loading&&!error&&<><span aria-hidden="true">· </span>{t("{0} projects",projects.length)}</>):projects.length ? t("{0} projects", projects.length) : t("Your library")}</span></div>
    {loading && <p className="ui-loading-inline" role="status"><LoaderCircle className="ui-loading-spinner" size={18} aria-hidden="true"/>{t(local?"Loading projects…":"Loading recent projects…")}</p>}
    {error && <div className="recent-error prompt-error" role="alert"><p>{message(error)}</p><button type="button" onClick={onRetry}>{t("Retry")}</button></div>}
    <ul>{projects.map(project => {
      const title=project.title || t("Untitled project"), date=new Date(project.lastOpened*1000);
      const pathParts=project.path.split(/[\\/]/).filter(Boolean),pathLabel=`${selector&&pathParts.length>2?'…/':''}${pathParts.slice(-2).join('/')}`;
      const validDate=Number.isFinite(date.getTime());
      return <li key={project.path}>
        <button type="button" className="recent-open" disabled={disabled||!!openingPath} aria-busy={openingPath===project.path||undefined} onClick={() => onOpen(project.path,title)} title={selector||!local?project.path:undefined}>
          <span className="recent-book-icon">{openingPath===project.path?<LoaderCircle className="ui-loading-spinner" size={selector?18:24} aria-hidden="true"/>:<BookOpen size={selector?18:24} aria-hidden="true"/>}</span>
          <span className="recent-project-info"><strong>{title}</strong><small className="recent-project-path" role={openingPath===project.path?'status':undefined}>{openingPath===project.path?openingStatus:pathLabel}</small>{!local&&<small className="recent-project-date">{t("Last opened") + " "}{validDate ? <time dateTime={date.toISOString()}>{date.toLocaleDateString(locale(),{day:'numeric',month:'short',year:'numeric'})}</time> : t("Unknown")}</small>}</span>
        </button>
        {onForget&&<div className="recent-menu"><ActionMenu disabled={disabled||!!openingPath} label={t("Options for {0}", title)} actions={[...(onDelete ? [{label:buttonLabel("Delete project…"),icon:<Trash2 size={14}/>,danger:true,onClick:()=>onDelete(project)}] : []),{label:t("Remove from recent projects"),icon:<ListX size={14}/>,onClick:()=>onForget?.(project.path)}]}><MoreHorizontal size={18}/></ActionMenu></div>}
      </li>;
    })}</ul>
    {!projects.length && !loading && !error && (selector?<p className="ui-empty-state ui-empty-state-compact">{t("No local projects yet. Create a project to get started.")}</p>:<div className="recent-empty"><span className="recent-empty-art" aria-hidden="true"><BookOpen size={36}/></span><h3>{t("Your next story starts here")}</h3><p>{t(local?"No local projects yet. Create a project to get started.":"No recent projects yet. Create your first story or open an existing project to build your library.")}</p></div>)}
    {!local&&projects.length>0 && <p className="recent-library-note">{t("Choose “Remove from recent projects” to hide a card; files are kept. “Delete project…” moves the entire folder to the Trash.")}</p>}
  </section>;
}
