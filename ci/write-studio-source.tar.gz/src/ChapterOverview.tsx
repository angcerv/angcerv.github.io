import {ReferenceText} from './TextReferenceUI';
import {textReferencePlainText} from './textReferenceTokens';
import { t } from './i18n';
import SceneWritingStatus from './SceneWritingStatus';
import type { Chapter } from './model';
export default function ChapterOverview({ chapter, onOpenScene }: { chapter: Chapter; onOpenScene: (id: string) => void }) {
  return <section className="chapter-overview" aria-label={t("Chapter overview")}><h1>{chapter.title || t("Untitled chapter")}</h1>{chapter.synopsis && <p className="chapter-synopsis"><ReferenceText value={chapter.synopsis}/></p>}<h2>{t("Scenes ·") + " "}{chapter.scenes.length}</h2><div className="chapter-scene-overview">{chapter.scenes.map((scene, index) => <button type="button" key={scene.id} onClick={() => onOpenScene(scene.id)}><div className="scene-overview-heading"><strong>{index + 1}. {scene.title || t("Untitled scene")}</strong><SceneWritingStatus scene={scene} /></div>{scene.synopsis && <span>{textReferencePlainText(scene.synopsis)}</span>}</button>)}</div></section>;
}
