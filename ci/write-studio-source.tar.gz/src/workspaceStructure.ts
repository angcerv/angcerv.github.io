import type {WorkspaceView} from './workspaceNavigation';
export const primaryWorkspaces=['manuscript','planning','worldbuilding','timeline','pending'] as const;
export type PrimaryWorkspace=typeof primaryWorkspaces[number];
export function primaryWorkspace(view:WorkspaceView,mode:string):PrimaryWorkspace|'home'{
 if(view==='home')return 'home';
 if(view==='canvas'||view==='plots'||view==='arcs'||view==='manuscript'&&(mode==='planning'||mode==='board'))return 'planning';
 if(view==='maps')return 'worldbuilding';
 return view;
}
