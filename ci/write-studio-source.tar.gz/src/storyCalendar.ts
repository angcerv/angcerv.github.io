import type {StoryDate,TimelineEvent} from './timeline';
import {t} from './i18n';
export type CalendarSeason={name:string;month:number;day:number;description?:string};
export type CalendarHoliday=CalendarSeason&{duration:number};
export type StoryCalendar={seasons?:CalendarSeason[];holidays?:CalendarHoliday[];schemaVersion:1|2;name:string;mode:'gregorian'|'fixed';months:{name:string;days:number}[];weekdays:string[];epochYear:number;epochWeekday:number;eras:{name:string;startYear:number;description?:string}[]};
const normalDays=[31,28,31,30,31,30,31,31,30,31,30,31];
export function defaultStoryCalendar():StoryCalendar{return {schemaVersion:1,name:t('World calendar'),mode:'gregorian',months:['January','February','March','April','May','June','July','August','September','October','November','December'].map((name,index)=>({name:t(name),days:normalDays[index]})),weekdays:['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday'].map(name=>t(name)),epochYear:0,epochWeekday:5,eras:[]};}
const integer=(value:number,min:number,max:number)=>Number.isInteger(value)&&value>=min&&value<=max;
export function validateStoryCalendar(calendar:StoryCalendar){
 const names=(items:string[],max:number)=>items.length>0&&items.length<=max&&items.every(name=>name.trim().length>0&&name.length<=80)&&new Set(items.map(name=>name.trim().toLocaleLowerCase())).size===items.length;
 if(![1,2].includes(calendar.schemaVersion)||!calendar.name.trim()||calendar.name.length>120||!['gregorian','fixed'].includes(calendar.mode)||!names(calendar.months.map(month=>month.name),24)||calendar.months.some(month=>!integer(month.days,1,1000))||!names(calendar.weekdays,20)||!integer(calendar.epochWeekday,0,calendar.weekdays.length-1)||!integer(calendar.epochYear,-999999,999999)||calendar.eras.length>32||calendar.eras.some(era=>!era.name.trim()||era.name.length>80||(era.description?.length??0)>4000||!integer(era.startYear,-999999,999999))||new Set(calendar.eras.map(era=>era.startYear)).size!==calendar.eras.length||new Set(calendar.eras.map(era=>era.name.trim().toLocaleLowerCase())).size!==calendar.eras.length)throw new Error(t('Check the calendar names, lengths and reference date. Names and era start years must be unique.'));
 const seasons=calendar.seasons??[],holidays=calendar.holidays??[];
 const validNames=(items:CalendarSeason[],max:number)=>items.length<=max&&items.every(item=>item.name.trim().length>0&&item.name.length<=80&&(item.description?.length??0)<=4000)&&new Set(items.map(item=>item.name.trim().toLocaleLowerCase())).size===items.length;
 if((calendar.schemaVersion<2&&(seasons.length>0||holidays.length>0))||!validNames(seasons,32)||!validNames(holidays,256)||seasons.some(item=>!validCalendarOccurrence(item,calendar))||new Set(seasons.map(item=>`${item.month}-${item.day}`)).size!==seasons.length||holidays.some(item=>!validCalendarOccurrence(item,calendar,true)||!integer(item.duration,1,calendar.months.reduce((sum,month)=>sum+month.days,0))))throw new Error(t('Check season and holiday names, dates and durations. Season start dates must be unique.'));
 if(calendar.mode==='gregorian'&&(calendar.months.length!==12||calendar.months.some((month,index)=>month.days!==normalDays[index])))throw new Error(t('Gregorian calendars keep the twelve standard month lengths and leap-year rules.'));
}
const leap=(year:number)=>year%4===0&&(year%100!==0||year%400===0);
const gregorianDays=(year:number,month:number)=>normalDays[month-1]+Number(month===2&&leap(year));
const yearStart=(year:number)=>365*year+Math.floor((year+3)/4)-Math.floor((year+99)/100)+Math.floor((year+399)/400);
function completeDate(date:StoryDate,calendar?:StoryCalendar){
 if(!integer(date.year,-999999,999999)||date.month===undefined||date.day===undefined||!integer(date.month,1,calendar?.months.length??12)||!integer(date.day,1,calendar?.mode==='fixed'?calendar.months[date.month-1].days:gregorianDays(date.year,date.month)))throw new Error(t('Enter a complete, valid date.'));
 return {year:date.year,month:date.month,day:date.day};
}
function gregorianOrdinal(date:StoryDate){const value=completeDate(date);return yearStart(value.year)+Array.from({length:value.month-1},(_,i)=>gregorianDays(value.year,i+1)).reduce((a,b)=>a+b,0)+value.day-1;}
function gregorianFromOrdinal(ordinal:number):StoryDate{
 if(ordinal<yearStart(-999999)||ordinal>=yearStart(1000000))throw new Error(t('The converted date is outside the supported year range.'));
 let low=-999999,high=1000000;while(low+1<high){const middle=Math.floor((low+high)/2);if(yearStart(middle)<=ordinal)low=middle;else high=middle;}
 let day=ordinal-yearStart(low),month=1;while(day>=gregorianDays(low,month)){day-=gregorianDays(low,month);month++;}return {year:low,month,day:day+1};
}
export function calendarFromStoryDate(date:StoryDate,calendar:StoryCalendar):StoryDate{
 validateStoryCalendar(calendar);const ordinal=gregorianOrdinal(date)-yearStart(calendar.epochYear);
 if(calendar.mode==='gregorian')return gregorianFromOrdinal(ordinal);
 const length=calendar.months.reduce((sum,month)=>sum+month.days,0),year=Math.floor(ordinal/length);let rest=ordinal-year*length,month=1;
 if(!integer(year,-999999,999999))throw new Error(t('The converted date is outside the supported year range.'));
 while(rest>=calendar.months[month-1].days){rest-=calendar.months[month-1].days;month++;}return {year,month,day:rest+1};
}
export function storyDateFromCalendar(date:StoryDate,calendar:StoryCalendar):StoryDate{
 validateStoryCalendar(calendar);const value=completeDate(date,calendar);
 const ordinal=calendarOrdinal(value,calendar);
 return gregorianFromOrdinal(ordinal+yearStart(calendar.epochYear));
}
export function parseCalendarDate(value:string,calendar:StoryCalendar):StoryDate{
 const match=/^(-?\d{1,6})-(\d{1,2})-(\d{1,4})$/.exec(value.trim());if(!match)throw new Error(t('Enter a complete, valid date.'));
 const date={year:Number(match[1]),month:Number(match[2]),day:Number(match[3])};completeDate(date,calendar);return date;
}
export function calendarMonthDays(calendar:StoryCalendar,year:number,month:number):number{
 if(!integer(year,-999999,999999)||!integer(month,1,calendar.months.length))throw new Error(t('Enter a complete, valid date.'));
 return calendar.mode==='gregorian'?gregorianDays(year,month):calendar.months[month-1].days;
}
export function calendarOrdinal(date:StoryDate,calendar:StoryCalendar):number{
 const value=completeDate(date,calendar);
 return calendar.mode==='gregorian'?gregorianOrdinal(value):value.year*calendar.months.reduce((sum,month)=>sum+month.days,0)+calendar.months.slice(0,value.month-1).reduce((sum,month)=>sum+month.days,0)+value.day-1;
}
export function calendarWeekday(date:StoryDate,calendar:StoryCalendar):number{
 const ordinal=calendarOrdinal(date,calendar);return ((ordinal+calendar.epochWeekday)%calendar.weekdays.length+calendar.weekdays.length)%calendar.weekdays.length;
}
export function calendarYearLabel(year:number,calendar:StoryCalendar):string{
 const era=[...calendar.eras].sort((a,b)=>b.startYear-a.startYear).find(era=>era.startYear<=year);return era?`${year-era.startYear+1} ${era.name}`:String(year);
}
export function calendarWorldDateLabel(date:StoryDate,calendar:StoryCalendar):string{
 const value=completeDate(date,calendar);return `${calendar.weekdays[calendarWeekday(value,calendar)]}, ${value.day} ${calendar.months[value.month-1].name} · ${calendarYearLabel(value.year,calendar)}`;
}
export function calendarDateLabel(date:StoryDate,calendar?:StoryCalendar):string{
 if(!calendar||date.month===undefined||date.day===undefined)return '';
 try{return calendarWorldDateLabel(calendarFromStoryDate(date,calendar),calendar);}catch{return '';}
}
export function calendarEventDateLabel(event:Pick<TimelineEvent,'start'|'end'>,calendar?:StoryCalendar):string{
 if(!event.start)return '';const start=calendarDateLabel(event.start,calendar),end=event.end?calendarDateLabel(event.end,calendar):'';return start&&(!event.end||end)?`${start}${end?` → ${end}`:''}`:'';
}

/** Annual boundaries use the shortest year; Feb 29 holidays skip ordinary years. */
export function validCalendarOccurrence(value:Pick<CalendarSeason,'month'|'day'>,calendar:StoryCalendar,holiday=false){
 return integer(value.month,1,calendar.months.length)&&integer(value.day,1,calendar.months[value.month-1].days+Number(holiday&&calendar.mode==='gregorian'&&value.month===2));
}
export function calendarDateContext(date:StoryDate,calendar?:StoryCalendar):{season?:CalendarSeason;holidays:CalendarHoliday[]}{
 if(!calendar||date.month===undefined||date.day===undefined)return {holidays:[]};
 try{return calendarWorldDateContext(calendarFromStoryDate(date,calendar),calendar);}catch{return {holidays:[]};}
}
export function calendarWorldDateContext(date:StoryDate,calendar:StoryCalendar):{season?:CalendarSeason;holidays:CalendarHoliday[]}{
 validateStoryCalendar(calendar);const converted=completeDate(date,calendar),point=converted.month*1001+converted.day,seasons=[...(calendar.seasons??[])].sort((a,b)=>a.month-b.month||a.day-b.day);
 const season=[...seasons].reverse().find(item=>item.month*1001+item.day<=point)??seasons[seasons.length-1],current=calendarOrdinal(converted,calendar);
 const holidays=(calendar.holidays??[]).filter(item=>[converted.year,converted.year-1].some(year=>{
  if(calendar.mode==='gregorian'&&item.month===2&&item.day===29&&!leap(year))return false;
  // Annual windows can start in the preceding year, including before the display range.
  const start=calendar.mode==='gregorian'?yearStart(year)+Array.from({length:item.month-1},(_,i)=>gregorianDays(year,i+1)).reduce((a,b)=>a+b,0)+item.day-1:year*calendar.months.reduce((sum,month)=>sum+month.days,0)+calendar.months.slice(0,item.month-1).reduce((sum,month)=>sum+month.days,0)+item.day-1;
  return current>=start&&current<start+item.duration;
 }));
 return {season,holidays};
}
export function removeCalendarMonth(calendar:StoryCalendar,index:number):Partial<StoryCalendar>{
 const remap=<T extends CalendarSeason>(item:T):T=>({...item,month:item.month===index+1?0:item.month>index+1?item.month-1:item.month});
 return {months:calendar.months.filter((_,i)=>i!==index),...(calendar.seasons?{seasons:calendar.seasons.map(remap)}:{}),...(calendar.holidays?{holidays:calendar.holidays.map(remap)}:{})};
}
