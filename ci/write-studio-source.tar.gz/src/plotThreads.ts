import type {CharacterArc} from './characterArcs';
import {longTextPlainText} from './longText';
import type { Project } from './model';
import type { MapColor } from './maps';
export type PlotBeat={sceneId:string;note:string};
export type PlotThread={id:string;title:string;color:MapColor;status:'planned'|'active'|'resolved';notes:string;beats:PlotBeat[]};
export type ProjectPlots={schemaVersion:1|2;threads:PlotThread[];arcs?:CharacterArc[]};
export const emptyPlots:ProjectPlots={schemaVersion:1,threads:[]};
export function updatePlot(plots:ProjectPlots,thread:PlotThread):ProjectPlots{return {...plots,threads:plots.threads.map(p=>p.id===thread.id?thread:p)};}
export function linkPlotScene(plots:ProjectPlots,plotId:string,sceneId:string,linked:boolean):ProjectPlots{
 const plot=plots.threads.find(p=>p.id===plotId);if(!plot||plot.beats.some(b=>b.sceneId===sceneId)===linked)return plots;
 return updatePlot(plots,{...plot,beats:linked?[...plot.beats,{sceneId,note:''}]:plot.beats.filter(b=>b.sceneId!==sceneId)});
}
export function orderedPlotBeats(project:Project,plot:PlotThread){
 const locations=project.chapters.flatMap(chapter=>chapter.scenes.map(scene=>({chapter,scene}))),byId=new Map(locations.map((l,i)=>[l.scene.id,{...l,index:i}]));
 return plot.beats.map(beat=>({beat,location:byId.get(beat.sceneId)})).sort((a,b)=>(a.location?.index??Infinity)-(b.location?.index??Infinity));
}
export function plotChapterCounts(project:Project,plot:PlotThread){const ids=new Set(plot.beats.map(b=>b.sceneId));return project.chapters.map(chapter=>({chapter,count:chapter.scenes.filter(scene=>ids.has(scene.id)).length}));}

export function filterPlotThreads(plots:ProjectPlots,status:PlotThread['status']|'all',query:string):PlotThread[]{
 const needle=query.trim().toLocaleLowerCase();return plots.threads.filter(plot=>(status==='all'||plot.status===status)&&(!needle||[plot.title,longTextPlainText(plot.notes)].some(value=>value.toLocaleLowerCase().includes(needle))));
}
export function plotSummary(project:Project,plot:PlotThread){
 const chapters=plotChapterCounts(project,plot),ordered=orderedPlotBeats(project,plot);
 const occupied=chapters.flatMap((item,index)=>item.count?[index]:[]);
 let longestPause=0;for(let i=1;i<occupied.length;i++)longestPause=Math.max(longestPause,occupied[i]-occupied[i-1]-1);
 return {linkedScenes:ordered.filter(item=>item.location).length,deletedScenes:ordered.filter(item=>!item.location).length,chaptersWithScenes:occupied.length,chaptersWithoutScenes:chapters.filter(item=>!item.count).map(item=>item.chapter),longestPause,chaptersSinceLast:occupied.length?chapters.length-1-occupied[occupied.length-1]:0};
}

// Scene slots line up across plots; rails only span the first to last appearance.
export function plotChapterTracks(project:Project,plot:PlotThread){
 const beats=new Map(plot.beats.map(beat=>[beat.sceneId,beat]));
 const occupied=project.chapters.map(chapter=>chapter.scenes.some(scene=>beats.has(scene.id)));
 const first=occupied.indexOf(true),last=occupied.lastIndexOf(true);
 return project.chapters.map((chapter,index)=>{
  const slots=chapter.scenes.map((scene,sceneIndex)=>({scene,sceneIndex,beat:beats.get(scene.id)}));
  const linked=slots.filter(slot=>slot.beat),active=first>=0&&index>=first&&index<=last;
  const count=Math.max(1,slots.length);
  const start=index===first?(linked[0].sceneIndex+.5)/count*100:0;
  const end=index===last?(linked[linked.length-1].sceneIndex+.5)/count*100:100;
  return {chapter,slots,active,gap:active&&!linked.length,start,end};
 });
}
