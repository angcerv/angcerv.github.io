/** Fit the browser inside its actual workspace, excluding its top offset and a bottom gap. */
export function worldBrowserHeight(viewport:{top:number;bottom:number},browserTop:number,paddingTop:number,bottomGap=12):number|undefined{
 if(!Number.isFinite(viewport.top)||!Number.isFinite(viewport.bottom)||!Number.isFinite(browserTop)||viewport.bottom<=viewport.top)return;
 return Math.max(0,Math.floor(viewport.bottom-Math.max(browserTop,viewport.top+paddingTop)-bottomGap));
}
