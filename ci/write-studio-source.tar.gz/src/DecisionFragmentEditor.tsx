import {useMemo,useState} from 'react';
import {ArrowUpRight,Plus,Unlink} from 'lucide-react';
import Dropdown from './Dropdown';
import type {WorldIdea} from './worldIdeas';
import {fragmentSources,sourceForFragment,locateFragment,makeFragment} from './decisionFragments';
import type {DecisionFragment} from './decisionFragments';
import type {Worldbuilding} from './worldbuilding';
import type {Chapter} from './model';
import type {ProjectPlots} from './plotThreads';
import {t,buttonLabel} from './i18n';
export default function DecisionFragments({idea,world,chapters,plots,onChange,onOpen}:{idea:WorldIdea;world:Worldbuilding;chapters:Chapter[];plots?:ProjectPlots;onChange:(fragments:DecisionFragment[])=>void;onOpen?:(fragment:DecisionFragment)=>void}){
 const sources=useMemo(()=>fragmentSources(world,chapters,plots),[world,chapters,plots]);
 const [sourceKey,setSourceKey]=useState(''),[selection,setSelection]=useState<{from:number;to:number}|null>(null);
 const choices=sources.filter(source=>(source.kind==='entry'?idea.entryIds:source.kind==='scene'?idea.sceneIds:idea.plotIds)?.includes(source.targetId));
 const source=choices.find(item=>item.key===sourceKey);
 return <section className="decision-fragments"><h3>{t('Affected fragments')}</h3>
 {(idea.fragments??[]).map(fragment=>{const current=sourceForFragment(sources,fragment),found=current&&locateFragment(current.text,fragment);return <div className="decision-fragment" key={fragment.id}><strong>{current?.title??t('Source unavailable')}</strong><blockquote>{fragment.quote}</blockquote>{!found&&<p className="semantic-label" data-semantic-tone="attention">{t(current?'Fragment changed or ambiguous. Relink it before relying on its location.':'Source unavailable. The original quote has been kept.')}</p>}<div className="world-form-actions">{onOpen&&current&&<button type="button" className="quick-action quick-action-text" onClick={()=>onOpen(fragment)}><ArrowUpRight size={16}/>{buttonLabel(found?'Save and open fragment':'Save and open source')}</button>}<button type="button" className="quick-action" aria-label={t('Unlink fragment')} title={t('Unlink fragment')} onClick={()=>onChange((idea.fragments??[]).filter(item=>item.id!==fragment.id))}><Unlink size={16}/></button></div></div>;})}
 <div className="ui-form-field"><label htmlFor="decision-fragment-source">{t('Fragment source')}</label><Dropdown id="decision-fragment-source" searchable value={source?.key??''} placeholder={t('Choose linked text')} options={choices.map(item=>({value:item.key,label:item.title}))} onChange={key=>{setSourceKey(key);setSelection(null);}}/></div>
 {source?<><label htmlFor="decision-fragment-selection">{t('Select the affected text')}</label><textarea id="decision-fragment-selection" readOnly rows={7} value={source.text} onSelect={event=>setSelection({from:event.currentTarget.selectionStart,to:event.currentTarget.selectionEnd})}/><button type="button" className="quick-action quick-action-text" disabled={!selection||!source.text.slice(selection.from,selection.to).trim()||selection.to-selection.from>10000} onClick={()=>{if(!selection)return;const fragment=makeFragment(source,selection.from,selection.to);if(fragment){onChange([...(idea.fragments??[]),fragment]);setSelection(null);}}}><Plus size={16}/>{t('Link selected fragment')}</button></>:!choices.length&&<p className="world-hint">{t('Link an entry, scene or plot with text to choose a fragment.')}</p>}
 </section>;
}
