import {visualResourceUsage,visualRemovalProblem} from './visualResourceUsage';
import type {VisualUsageContext} from './visualResourceUsage';
import type {Entry,Worldbuilding} from './worldbuilding';
import {t} from './i18n';
export const visualCategoryLabels={wardrobe:'Clothing',emblem:'Emblems',architecture:'Architecture',map:'Maps',creature:'Creatures',portrait:'Portraits',object:'Objects',landscape:'Landscapes',other:'Other visual references'};
export type VisualCategory=keyof typeof visualCategoryLabels;
export type VisualResource={id:string;title:string;notes:string;category?:VisualCategory;caption?:string;variantOf?:string;variantLabel?:string;originalFilename?:string;deletedAt?:number};
export function visualFamilyId(resource:VisualResource){return resource.variantOf??resource.id;}
export function visualResourceDescription(resource:VisualResource,baseTitle?:string){return [...new Set([resource.caption,resource.variantLabel!==resource.title?resource.variantLabel:undefined,baseTitle?t('Variant of: {0}',baseTitle):undefined,resource.notes].filter((value):value is string=>!!value?.trim()))].join(' · ');}
export function filterVisualResources(resources:VisualResource[],query:string,category='',family=''){
 const normalize=(value:string)=>value.normalize('NFD').replace(/\p{M}/gu,'').toLocaleLowerCase().trim(),needle=normalize(query),byId=new Map(resources.map(resource=>[resource.id,resource]));
 return resources.filter(resource=>(!category||(category==='unclassified'?!resource.category:resource.category===category))&&(!family||visualFamilyId(resource)===family)&&(!needle||normalize([resource.title,resource.originalFilename,resource.notes,resource.caption,resource.variantLabel,resource.category?t(visualCategoryLabels[resource.category]):'',byId.get(resource.variantOf??'')?.title].filter(Boolean).join(' ')).includes(needle)));
}
export function validateVisualResource(resource:VisualResource,resources:VisualResource[]):string{
 if(resource.originalFilename!==undefined&&(!resource.originalFilename.trim()||resource.originalFilename.length>1024||/[\\/\0]/.test(resource.originalFilename)))return 'Invalid original filename.';
 if(resource.deletedAt!==undefined&&(!Number.isSafeInteger(resource.deletedAt)||resource.deletedAt<0))return 'Invalid image deletion date.';
 if(!resource.title.trim())return 'An image needs a title.';
 if(resource.notes.length>20000||(resource.caption?.length??0)>2000||(resource.variantLabel?.length??0)>120)return 'Image details are too long.';
 if(resource.category&&!Object.prototype.hasOwnProperty.call(visualCategoryLabels,resource.category))return 'Invalid image category.';
 if(resource.variantOf){const base=resources.find(item=>item.id===resource.variantOf&&item.deletedAt===undefined);if(!base||base.id===resource.id||base.variantOf)return 'Choose an original image as the base of this variant.';if(resources.some(item=>item.variantOf===resource.id))return 'Unlink this image’s variants before making it a variant.';}
 return '';
}
export function entryImageIds(entry:Entry):string[]{return [...new Set([...(entry.imageId?[entry.imageId]:[]),...(entry.imageIds??[])])];}
export function visualResources(world:Worldbuilding,includeDeleted=false):VisualResource[]{
 const resources=new Map((world.visualResources??[]).map(item=>[item.id,item]));
 for(const entry of world.entries)for(const id of entryImageIds(entry))if(!resources.has(id))resources.set(id,{id,title:entry.title||t('Untitled image'),notes:''});
 return [...resources.values()].filter(resource=>includeDeleted||resource.deletedAt===undefined);
}
export function upgradeVisualResources(world:Worldbuilding):Worldbuilding{const version=world.schemaVersion>=12||world.visualResources?.some(resource=>resource.originalFilename!==undefined||resource.deletedAt!==undefined)?12:11;return {...world,schemaVersion:version,templates:world.templates.map(template=>({...template,schemaVersion:version})),entries:world.entries.map(entry=>({...entry,schemaVersion:version})),visualResources:visualResources(world,true)};}
export function saveVisualResource(world:Worldbuilding,resource:VisualResource):Worldbuilding{
 const problem=validateVisualResource(resource,visualResources(world,true));if(problem)throw new Error(t(problem));
 const next=upgradeVisualResources(world),saved={...resource,title:Array.from(resource.title.trim()).slice(0,300).join('')},resources=next.visualResources??[];for(const key of ['caption','variantLabel'] as const){if(saved[key]?.trim())saved[key]=saved[key]!.trim();else delete saved[key];}if(!saved.category)delete saved.category;if(!saved.variantOf)delete saved.variantOf;return upgradeVisualResources({...next,visualResources:resources.some(item=>item.id===resource.id)?resources.map(item=>item.id===resource.id?saved:item):[...resources,saved]});
}
export function attachEntryImage(world:Worldbuilding,entryId:string,imageId:string):Worldbuilding{
 if(!world.entries.some(entry=>entry.id===entryId)||!visualResources(world).some(item=>item.id===imageId))return world;
 const existing=world.entries.find(entry=>entry.id===entryId)!;if(entryImageIds(existing).length>=256&&!entryImageIds(existing).includes(imageId))throw new Error(t('A gallery can contain up to 256 images.'));
 const next=upgradeVisualResources(world);return {...next,entries:next.entries.map(entry=>entry.id===entryId?{...entry,imageId:entry.imageId??imageId,imageIds:[...new Set([...entryImageIds(entry),imageId])]}:entry)};
}
export function mainEntryImage(world:Worldbuilding,entryId:string,imageId:string):Worldbuilding{
 const entry=world.entries.find(entry=>entry.id===entryId);if(!entry||!entryImageIds(entry).includes(imageId))return world;
 return {...world,entries:world.entries.map(entry=>entry.id===entryId?{...entry,imageId}:entry)};
}
export function detachEntryImage(world:Worldbuilding,entryId:string,imageId:string):Worldbuilding{
 const next=upgradeVisualResources(world);return {...next,entries:next.entries.map(entry=>{if(entry.id!==entryId)return entry;const imageIds=entryImageIds(entry).filter(id=>id!==imageId),result={...entry,imageIds};if(entry.imageId===imageId){if(imageIds.length)result.imageId=imageIds[0];else delete result.imageId;}return result;})};
}
export function removeVisualResource(world:Worldbuilding,id:string,context:VisualUsageContext={}):Worldbuilding{
 const problem=visualRemovalProblem(visualResourceUsage(world,id,context));if(problem)throw new Error(problem);
 const resource=visualResources(world).find(item=>item.id===id);return resource?saveVisualResource(world,{...resource,deletedAt:Date.now()}):world;
}

/** Repair snapshots affected by older timestamp stamping without changing project content. */
export function ensureVisualResourceSchema(world:Worldbuilding):Worldbuilding {
 return world.schemaVersion<11&&((world.visualResources?.length??0)>0||world.entries.some(entry=>entry.imageIds?.length))?upgradeVisualResources(world):world;
}

export const visualTrashLifetime=30*24*60*60*1000;
export function visualTrashDays(resource:Pick<VisualResource,'deletedAt'>,now=Date.now()){return Math.max(0,Math.ceil(((resource.deletedAt??now)+visualTrashLifetime-now)/86400000));}
export function restoreVisualResource(world:Worldbuilding,id:string){
 const resource=visualResources(world,true).find(item=>item.id===id);if(!resource||resource.deletedAt===undefined)return world;
 const restored={...resource};delete restored.deletedAt;return saveVisualResource(world,restored);
}
export function permanentlyRemoveVisualResource(world:Worldbuilding,id:string,context:VisualUsageContext={}){
 const resource=world.visualResources?.find(item=>item.id===id);if(resource?.deletedAt===undefined)return world;
 const problem=visualRemovalProblem(visualResourceUsage(world,id,context));if(problem)throw new Error(problem);
 return {...world,visualResources:world.visualResources?.filter(item=>item.id!==id)};
}
