import {mapColors} from './maps';
import {sortedEvents,formatStoryDate,eventDateLabel} from './timeline';
import type {TimelineEvent,TimelineTrack} from './timeline';
import type {StoryCalendar} from './storyCalendar';
import {calendarFromStoryDate,calendarYearLabel} from './storyCalendar';
import {eventRange,storyDay} from './timelineChartLayout';
export type TimeWindow={start:number;end:number};
export const minimumDay=storyDay({year:-999999}),maximumDay=storyDay({year:999999,month:12,day:31});
export function constrainWindow(window:TimeWindow):TimeWindow{
 const span=Math.max(1,Math.min(maximumDay-minimumDay,window.end-window.start));
 const start=Math.max(minimumDay,Math.min(maximumDay-span,window.start));return {start,end:start+span};
}
export function zoomWindow(window:TimeWindow,factor:number,anchor=.5):TimeWindow{
 const fraction=Math.max(0,Math.min(1,anchor)),span=(window.end-window.start)/factor,at=window.start+(window.end-window.start)*fraction;
 return constrainWindow({start:at-span*fraction,end:at+span*(1-fraction)});
}
export function panWindow(window:TimeWindow,fraction:number):TimeWindow{
 const delta=(window.end-window.start)*fraction;return constrainWindow({start:window.start+delta,end:window.end+delta});
}
export function trackColor(track:TimelineTrack,_index=0){const hash=Array.from(track.id).reduce((value,character)=>(value*31+character.charCodeAt(0))>>>0,0);return mapColors[track.color??(['teal','blue','amber','violet','rose','stone'] as const)[hash%6]];}
export type PlotItem={key:string;events:TimelineEvent[];start:number;end:number;x:number;width:number;label:boolean;lane:number;partial:boolean;period:boolean;labelX:number;labelWidth:number;y:number;height:number};
/** Stable chronological rows; only nearby screen-space markers may share a cluster. */
export function layoutTrack(events:TimelineEvent[],window:TimeWindow,width:number,selectedId:string,expanded:boolean,minimumHeight=48){
 const span=window.end-window.start,items:PlotItem[]=[],threshold=Math.min(110,Math.max(48,width/8));
 for(const event of sortedEvents({schemaVersion:1,events},'date')){
  const range=eventRange(event);if(!range||range.end<window.start||range.start>window.end)continue;
  const anchor=range.kind==='point'?(range.start+range.end)/2:range.start,x=Math.max(0,(anchor-window.start)/span*width);
  const eventWidth=range.kind==='period'?Math.max(8,(Math.min(window.end,range.end)-Math.max(window.start,range.start))/span*width):14;
  const previous=items[items.length-1],clusterable=range.kind==='point'||eventWidth<48;
  if(!expanded&&clusterable&&event.id!==selectedId&&previous&&previous.key!==selectedId&&(!previous.period||previous.width<48)&&x-previous.x<threshold){
   previous.events.push(event);previous.end=Math.max(previous.end,range.end);previous.width=32;previous.label=false;previous.period=false;continue;
  }
  const labelWidth=Math.max(40,Math.min(320,width-16)),labelX=Math.max(8,Math.min(width-labelWidth-8,x+12));
  items.push({key:event.id,events:[event],start:range.start,end:range.end,x,width:range.kind==='period'?Math.max(0,Math.min(width-x,eventWidth)):14,label:true,lane:0,partial:range.partial,period:range.kind==='period',labelX,labelWidth,y:0,height:0});
 }
 let height=0;
 items.forEach((item,index)=>{const lines=item.events.length>1?0:item.events[0].title.split('\n').reduce((sum,line)=>sum+Math.max(1,Math.ceil(line.length/Math.max(1,Math.floor(item.labelWidth/9)))),0);const dateLines=Math.max(1,Math.ceil(eventDateLabel(item.events[0]).length/Math.max(1,Math.floor(item.labelWidth/7))));item.lane=index;item.y=height;item.height=item.events.length>1?minimumHeight:Math.max(minimumHeight,lines*17+dateLines*14+24);height+=item.height;});
 return {items,lanes:Math.max(1,items.length),height};
}
/** Complete dates use the world calendar; partial dates retain their canonical precision. */
export function timelineGroups(events:TimelineEvent[],calendar?:StoryCalendar){
 const groups=new Map<string,{key:string;label:string;events:TimelineEvent[]}>();
 for(const event of events){
  let key='undated',label='undated';
  if(event.start){
   const date=event.start;
   if(calendar&&date.month!==undefined&&date.day!==undefined){const world=calendarFromStoryDate(date,calendar);key=`world:${world.year}:${world.month}`;label=`${calendar.months[world.month!-1].name} · ${calendarYearLabel(world.year,calendar)}`;}
   else{key=`date:${date.year}:${date.month??''}`;label=formatStoryDate({year:date.year,...(date.month!==undefined?{month:date.month}:{})});}
  }
  if(!groups.has(key))groups.set(key,{key,label,events:[]});groups.get(key)!.events.push(event);
 }
 return [...groups.values()];
}

/** Native saves may reorder keys and omit empty optional collections; neither invalidates Undo. */
export function timelineContentSignature(timeline:import('./timeline').Timeline){
 const optionalCollections=new Set(['tracks','relationTypes','relations','plotIds','seasons','holidays']);
 return JSON.stringify(timeline,(_key,value)=>{
  if(!value||typeof value!=='object'||Array.isArray(value))return value;
  return Object.fromEntries(Object.keys(value).sort().filter(key=>value[key]!==undefined&&!(optionalCollections.has(key)&&Array.isArray(value[key])&&!value[key].length)).map(key=>[key,value[key]]));
 });
}
