import type {DrawingObject,DrawingPoint,DrawingSymbol,SymbolPlacementSettings} from './mapDrawing';
export type SymbolPlacementOptions=Pick<SymbolPlacementSettings,'continuous'|'density'|'sizeVariation'|'rotationVariation'>;
export const defaultSymbolPlacement:SymbolPlacementOptions={continuous:false,density:.5,sizeVariation:0,rotationVariation:0};
export type SymbolBrush={kind:DrawingSymbol;size:number;rotation:number;color?:string;layerId?:string;density:number;sizeVariation:number;rotationVariation:number};
export type SymbolPlacementGesture={brush:SymbolBrush;last:DrawingPoint;carry:number;index:number;seed:number;width:number;height:number;capacity:number;objects:DrawingObject[];truncated:boolean;id:()=>string};
function random(seed:number,index:number,channel:number){let value=(seed^Math.imul(index+1,0x9e3779b9)^Math.imul(channel+1,0x85ebca6b))>>>0;value=Math.imul(value^(value>>>16),0x7feb352d);value=Math.imul(value^(value>>>15),0x846ca68b);return ((value^(value>>>16))>>>0)/4294967296;}
function place(gesture:SymbolPlacementGesture,point:DrawingPoint){
 if(gesture.objects.length>=gesture.capacity){gesture.truncated=true;return;}
 const {brush}=gesture,index=gesture.index++;
 const stamp:SymbolPlacementSettings={continuous:true,density:brush.density,sizeVariation:brush.sizeVariation,rotationVariation:brush.rotationVariation,baseSize:brush.size,baseRotation:brush.rotation};
 const size=Math.max(.0000001,Math.min(.25,brush.size*(1+(random(gesture.seed,index,0)*2-1)*brush.sizeVariation)));
 const rotation=((brush.rotation+(random(gesture.seed,index,1)*2-1)*brush.rotationVariation)%360+360)%360;
 gesture.objects.push({id:gesture.id(),kind:brush.kind,x:Math.max(0,Math.min(1,point.x)),y:Math.max(0,Math.min(1,point.y)),size,rotation,stamp,...(brush.color?{color:brush.color}:{}),...(brush.layerId?{layerId:brush.layerId}:{})});
}
/** Map-space arc-length placement: event frequency never changes spacing or seeded variation. */
export function beginSymbolPlacement(brush:SymbolBrush,start:DrawingPoint,width:number,height:number,capacity:number,seed=Math.floor(Math.random()*4294967296),id=()=>crypto.randomUUID()):SymbolPlacementGesture{
 const gesture:SymbolPlacementGesture={brush:{...brush},last:{...start},carry:0,index:0,seed,width,height,capacity:Math.max(0,Math.min(500,capacity)),objects:[],truncated:false,id};place(gesture,start);return gesture;
}
export function extendSymbolPlacement(gesture:SymbolPlacementGesture,point:DrawingPoint){
 const dx=(point.x-gesture.last.x)*gesture.width,dy=(point.y-gesture.last.y)*gesture.height,length=Math.hypot(dx,dy);
 const spacing=Math.max(2,gesture.brush.size*gesture.width*(1.8-1.5*gesture.brush.density));
 let distance=spacing-gesture.carry;
 while(distance<=length+1e-8){
  if(gesture.objects.length>=gesture.capacity){gesture.truncated=true;break;}
  const fraction=length?distance/length:0;place(gesture,{x:gesture.last.x+dx/gesture.width*fraction,y:gesture.last.y+dy/gesture.height*fraction});distance+=spacing;
 }
 const carry=(gesture.carry+length)%spacing;gesture.carry=carry<1e-8||spacing-carry<1e-8?0:carry;gesture.last={...point};return gesture;
}
