import EntrySection from './EntrySection';
import {useContext} from 'react';
import {TextReferenceContext} from './textReferenceContext';
import {consultationSource} from './SourceConsultation';
import {bookChapters,selectionBook,bookChapterLabel} from './books';
import SceneContextPanel from './SceneContextPanel';
import type {Project} from './model';
import type {PendingItem} from './pendingItems';
import {TextReferenceTools} from './TextReferenceUI';
import RelatedIdeas from './RelatedIdeas';
import type {WorldIdea} from './worldIdeas';
import ManuscriptRoutesPanel from './ManuscriptRoutesPanel';
import type { ProjectMaps } from './maps';
import SceneArcsPanel from './SceneArcsPanel';
import ScenePlotsPanel from './ScenePlotsPanel';
import type { ProjectPlots } from './plotThreads';
import ReviewCommentsPanel from './ReviewCommentsPanel';
import type { ReviewComment } from './reviewComments';
import { t } from './i18n';
import { useEffect, useState, useRef } from 'react';
import { ArrowDown, ArrowUp, Trash2, X } from 'lucide-react';
import Dropdown from './Dropdown';
import { WritingStatusSelector } from './SceneWritingStatus';
import { getSceneStatus } from './model';
import type { WritingStatus, Chapter, Scene } from './model';

type Props = {
  onOpenMap?:(mapId:string,markerId:string)=>void;
  onCommentsHandled?:()=>void;commentsRequest?:number;openRequest?:number;onSceneTitle?:(title:string)=>void;
  project?:Project;onProjectChange?:(project:Project)=>void;onOpenEvent?:(id:string)=>void;onOpenEntry?:(id:string)=>void;onOpenScene?:(id:string)=>void;onOpenChapterPlan?:(id:string)=>void;onOpenPending?:(item:PendingItem)=>void;
  worldIdeas?:WorldIdea[];onOpenIdea?:(id:string)=>void;
  maps?:ProjectMaps;onMapsChange?:(maps:ProjectMaps)=>void;onOpenRoute?:(mapId:string,routeId:string)=>void;
  onOpenArc?:(id:string)=>void;plots?:ProjectPlots;onPlotsChange?:(plots:ProjectPlots)=>void;onOpenPlot?:(id:string)=>void;
  onCommentsChange?:(id:string,comments:ReviewComment[])=>void;onJumpComment?:(id:string,comment:ReviewComment)=>void;
  initialTab?: 'scene' | 'chapter' | 'context';onTabChange?:(tab:'scene'|'chapter'|'context')=>void; inactive?:boolean;
  chapter: Chapter; scene?: Scene; chapters: Chapter[];
  onWritingStatus: (value: WritingStatus) => void;
  onSceneSynopsis: (value: string) => void; onChapterSynopsis: (value: string) => void;
  onClose: () => void; onChapterTitle: (title: string) => void;
   onMoveToChapter: (id: string) => void;
  onMoveChapter: (direction: -1 | 1) => void; onMoveScene: (direction: -1 | 1) => void;
  onDelete: (kind: 'scene' | 'chapter') => void;
};
export default function ManuscriptTools({onCommentsHandled,commentsRequest=0,openRequest=0,onSceneTitle,onOpenMap,project,onProjectChange,onOpenEvent,onOpenEntry,onOpenScene,onOpenChapterPlan,onOpenPending,onOpenArc, worldIdeas,onOpenIdea,inactive=false,onTabChange, initialTab = 'scene', chapter, scene, chapters, onWritingStatus, onSceneSynopsis, onChapterSynopsis, onClose, onChapterTitle, onMoveToChapter, onMoveChapter, onMoveScene, onDelete, onCommentsChange, onJumpComment, plots, onPlotsChange, onOpenPlot, maps,onMapsChange,onOpenRoute }: Props) {
  const references=useContext(TextReferenceContext);
  const consult=(kind:'plot'|'arc'|'idea',id:string,fallback?:((id:string)=>void))=>{
    if(id&&references?.consultSource)references.consultSource(consultationSource(kind,id));
    else fallback?.(id);
  };
  const [tab, setTab] = useState<'scene' | 'chapter' | 'context'>(initialTab);
  useEffect(() => setTab(initialTab), [initialTab]);
  const panel=useRef<HTMLElement>(null);
  useEffect(()=>{if(!openRequest||tab!==initialTab)return;const content=panel.current?.querySelector<HTMLElement>('.manuscript-tools-content');if(content)content.scrollTop=0;panel.current?.querySelector<HTMLInputElement>(tab==='scene'?'#manuscript-scene-title':'#manuscript-chapter-title')?.focus({preventScroll:true});},[openRequest,tab,initialTab]);
  useEffect(()=>{if(!commentsRequest)return;const frame=requestAnimationFrame(()=>{const heading=panel.current?.querySelector<HTMLElement>('.review-comments-heading h3');heading?.scrollIntoView({block:'start'});heading?.focus({preventScroll:true});onCommentsHandled?.();});return()=>cancelAnimationFrame(frame);},[commentsRequest]);
  function changeTab(next:'scene'|'chapter'|'context'){setTab(next);onTabChange?.(next);}
  const orderedChapters=project?bookChapters(project,selectionBook(project,chapter.id)?.id??''):chapters;
  const chapterIndex = orderedChapters.findIndex(item => item.id === chapter.id);
  const sceneIndex = chapter.scenes.findIndex(item => item.id === scene?.id);
  return <section ref={panel} inert={inactive} id="manuscript-tools" className={`manuscript-tools${project?' manuscript-context-tools':''}`} aria-label={t("Manuscript tools")} onKeyDown={event => { if (event.key === 'Escape' && !(event.target as HTMLElement|undefined)?.closest?.('dialog')) { event.stopPropagation(); onClose(); } }}>
    <div className="manuscript-tools-heading"><div role="group" aria-label={t("Manuscript tools view")}>{project&&<button type="button" aria-pressed={tab==='context'} onClick={()=>changeTab('context')}>{t('Context')}</button>}<button type="button" disabled={!scene} aria-pressed={tab === 'scene'} onClick={() => changeTab('scene')}>{t("Scene")}</button><button type="button" aria-pressed={tab === 'chapter'} onClick={() => changeTab('chapter')}>{t("Chapter")}</button></div><button type="button" className="icon-button ui-close-button" aria-label={t("Close manuscript tools")} title={t("Close manuscript tools")} onClick={onClose}><X size={16} /></button></div>
    <div className="manuscript-tools-content">
      {tab==='context'&&(scene&&project&&onProjectChange?<SceneContextPanel onOpenMap={onOpenMap} onOpenRoute={onOpenRoute} onSceneDetails={()=>changeTab('scene')} key={scene.id} project={project} sceneId={scene.id} onChange={onProjectChange} onOpenPlot={onOpenPlot??(()=>{})} onOpenArc={onOpenArc??(()=>{})} onOpenEvent={onOpenEvent??(()=>{})} onOpenEntry={onOpenEntry??(()=>{})} onOpenScene={onOpenScene??(()=>{})} onOpenChapterPlan={onOpenChapterPlan??(()=>{})} onOpenPending={onOpenPending??(()=>{})}/>:<p className="world-hint">{t('Choose a scene to see its writing context.')}</p>)}
      {tab === 'scene' && (scene ? <>{onSceneTitle&&<><label htmlFor="manuscript-scene-title">{t('Scene title')}</label><input id="manuscript-scene-title" value={scene.title} placeholder={t('Untitled scene')} onChange={event=>onSceneTitle(event.target.value)}/></>}<WritingStatusSelector value={getSceneStatus(scene)} onChange={onWritingStatus}/><label htmlFor="scene-synopsis">{t("Scene synopsis")}</label><><textarea id="scene-synopsis" rows={4} value={scene.synopsis ?? ''} placeholder={t("What happens in this scene?")} onChange={event => onSceneSynopsis(event.target.value)} /><TextReferenceTools targetId="scene-synopsis" value={scene.synopsis ?? ''} onChange={event => onSceneSynopsis(event.target.value)}/></></> : <p className="world-hint">{t("Add a scene to start writing.")}</p>)}
      {tab === 'chapter' && <><label htmlFor="manuscript-chapter-title">{t("Chapter name")}</label><input id="manuscript-chapter-title" value={chapter.title} placeholder={t("Untitled chapter")} onChange={event => onChapterTitle(event.target.value)} /><label htmlFor="chapter-synopsis">{t("Chapter synopsis")}</label><><textarea id="chapter-synopsis" rows={4} value={chapter.synopsis ?? ''} placeholder={t("What does this chapter cover?")} onChange={event => onChapterSynopsis(event.target.value)} /><TextReferenceTools targetId="chapter-synopsis" value={chapter.synopsis ?? ''} onChange={event => onChapterSynopsis(event.target.value)}/></></>}


      {tab!=='context'&&<EntrySection key={`links-${tab}-${scene?.id??chapter.id}`} variant="compact" title={t('Linked content')} defaultOpen={false}>
      {tab==='scene'&&scene&&<RelatedIdeas ideas={worldIdeas} kind="scene" id={scene.id} onOpen={id=>consult('idea',id,onOpenIdea)}/>}
      {tab==='scene'&&scene&&plots&&onPlotsChange&&onOpenPlot&&<ScenePlotsPanel plots={plots} sceneId={scene.id} onChange={onPlotsChange} onOpen={id=>consult('plot',id,onOpenPlot)}/>}
      {tab==='scene'&&scene&&plots&&onPlotsChange&&onOpenArc&&<SceneArcsPanel plots={plots} sceneId={scene.id} onChange={onPlotsChange} onOpen={id=>consult('arc',id,onOpenArc)}/>}
      {maps&&onMapsChange&&onOpenRoute&&(tab==='chapter'||scene)&&<ManuscriptRoutesPanel maps={maps} chapterId={chapter.id} sceneId={tab==='scene'?scene?.id:undefined} onChange={onMapsChange} onOpen={onOpenRoute}/>}
      </EntrySection>}
      {tab!=='context'&&onCommentsChange&&onJumpComment&&<ReviewCommentsPanel scenes={tab==='chapter'?chapter.scenes:scene?[scene]:[]} onChange={onCommentsChange} onJump={onJumpComment}/>}
      {tab==='scene'&&scene&&<EntrySection key={`organize-${scene.id}`} variant="compact" title={t('Organize scene')} defaultOpen={false}><div className="manuscript-tool-row"><span>{t("Scene") + " "}{sceneIndex + 1}{" " + t("of") + " "}{chapter.scenes.length}</span><div><button type="button" aria-label={t("Move scene up")} title={t("Move scene up")} disabled={sceneIndex <= 0} onClick={() => onMoveScene(-1)}><ArrowUp size={14} /></button><button type="button" aria-label={t("Move scene down")} title={t("Move scene down")} disabled={sceneIndex >= chapter.scenes.length - 1} onClick={() => onMoveScene(1)}><ArrowDown size={14} /></button></div></div>{chapters.length > 1 && <div className="manuscript-transfer"><label id="scene-chapter-label" htmlFor="scene-chapter">{t("Move to chapter")}</label><Dropdown id="scene-chapter" aria-labelledby="scene-chapter-label" value={chapter.id} onChange={onMoveToChapter} options={chapters.map((item, index) => ({ value: item.id, label: project?.books?.length?bookChapterLabel(project,item.id):`${index + 1}. ${item.title || t("Untitled chapter")}` }))} /></div>}</EntrySection>}
      {tab==='chapter'&&<EntrySection key={`organize-${chapter.id}`} variant="compact" title={t('Organize chapter')} defaultOpen={false}><div className="manuscript-tool-row"><span>{t("Chapter") + " "}{chapterIndex + 1}{" " + t("of") + " "}{orderedChapters.length}</span><div><button type="button" aria-label={t("Move chapter up")} title={t("Move chapter up")} disabled={chapterIndex <= 0} onClick={() => onMoveChapter(-1)}><ArrowUp size={14} /></button><button type="button" aria-label={t("Move chapter down")} title={t("Move chapter down")} disabled={chapterIndex >= orderedChapters.length - 1} onClick={() => onMoveChapter(1)}><ArrowDown size={14} /></button></div></div></EntrySection>}
      {tab==='chapter'&&<div className="manuscript-details-actions"><button type="button" className="manuscript-delete destructive-action" onClick={()=>onDelete('chapter')}><Trash2 size={14} aria-hidden="true"/>{t('Delete chapter')}</button></div>}
    </div>
  </section>;
}
