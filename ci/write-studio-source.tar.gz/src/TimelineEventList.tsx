import {calendarEventDateLabel} from './storyCalendar';
import type {StoryCalendar} from './storyCalendar';
import {useWorkspaceState} from './useWorkspaceState';
import {useEffect,useMemo,useRef,useState} from 'react';
import {Check,ChevronDown,ChevronRight,ArrowUp,ArrowDown} from 'lucide-react';
import {timelineGroups} from './timelineWorkspace';
import {eventDateLabel,formatStoryDate} from './timeline';
import type {TimelineEvent,TimelineTrack} from './timeline';
import {t} from './i18n';
type ListRow={key:string;top:number;height:number;label?:string;groupKey?:string;count?:number;day?:boolean;event?:TimelineEvent};
export default function TimelineEventList({calendar,events,tracks=[],selectedId,selectedIds,onSelect,onToggle,onEdit,onMove,manual=false}:{calendar?:StoryCalendar;events:TimelineEvent[];tracks?:TimelineTrack[];selectedId:string;selectedIds:string[];onSelect:(id:string)=>void;onToggle:(id:string)=>void;onEdit:(event:TimelineEvent)=>void;onMove?:(id:string,direction:-1|1)=>void;manual?:boolean}){
 const [collapsed,setCollapsed]=useWorkspaceState<string[]>('timelineList.collapsed',[]),[scroll,setScroll]=useState(0),[height,setHeight]=useState(600),[width,setWidth]=useState(700),[measured,setMeasured]=useState<Record<string,number>>({}),root=useRef<HTMLDivElement>(null),observer=useRef<ResizeObserver|null>(null),pendingFocus=useRef(false);
 useEffect(()=>{
  const node=root.current;if(!node)return;
  const resize=new ResizeObserver(()=>{if(node.clientWidth>0&&node.clientHeight>0){setWidth(node.clientWidth);setHeight(node.clientHeight);}});resize.observe(node);
  observer.current=new ResizeObserver(entries=>{setMeasured(previous=>{const next={...previous};let changed=false;for(const entry of entries){const id=(entry.target as HTMLElement).dataset.eventId,size=Math.ceil(entry.target.getBoundingClientRect().height);if(id&&size>0&&next[id]!==size){next[id]=size;changed=true;}}return changed?next:previous;});});
  node.querySelectorAll('[data-event-id]').forEach(row=>observer.current?.observe(row));
  return()=>{resize.disconnect();observer.current?.disconnect();observer.current=null;};
 },[]);
 useEffect(()=>{setMeasured({});},[width]);
 const memberships=useMemo(()=>{const map=new Map<string,string[]>();for(const track of tracks)for(const id of track.eventIds){if(!map.has(id))map.set(id,[]);map.get(id)!.push(track.title);}return map;},[tracks]);
 const groups=useMemo(()=>manual?[{key:'manual',label:t('Manual order'),events}]:timelineGroups(events,calendar),[manual,events,calendar]);
 useEffect(()=>{const group=groups.find(group=>group.events.some(event=>event.id===selectedId));if(group)setCollapsed(previous=>previous.includes(group.key)?previous.filter(key=>key!==group.key):previous);},[selectedId]);
 const {rows,offset}=useMemo(()=>{let offset=0;const rows:ListRow[]=[];
 function add(row:Omit<ListRow,'top'>){rows.push({...row,top:offset});offset+=row.height;}
 for(const group of groups){
  add({key:`group:${group.key}`,height:38,label:group.label,groupKey:group.key,count:group.events.length});if(collapsed.includes(group.key))continue;
  const dayCounts=new Map<string,number>();if(!manual)for(const event of group.events)if(event.start?.day!==undefined){const key=formatStoryDate(event.start);dayCounts.set(key,(dayCounts.get(key)??0)+1);}
  let lastDay='';
  for(const event of group.events){
   const day=event.start?.day!==undefined?formatStoryDate(event.start):'';
   if(day&&day!==lastDay&&(dayCounts.get(day)??0)>1)add({key:`day:${day}`,height:32,label:t('Same start date · {0}',calendarEventDateLabel({start:event.start},calendar)||day),day:true});lastDay=day;
   const titleWidth=Math.max(80,width-(width<600?170:220)),lines=Math.ceil((event.title.length+(memberships.get(event.id)?.join(' · ').length??0))/Math.max(10,titleWidth/7));
   const dateLines=Math.ceil((eventDateLabel({...event,dateLabel:''})+' '+calendarEventDateLabel(event,calendar)).length/(width<600?15:22));
   add({key:event.id,height:measured[event.id]??Math.max(72,lines*20+28,dateLines*17+20),event});
  }
 }
 return {rows,offset};},[groups,collapsed,measured,width,memberships,calendar,manual]);
 useEffect(()=>{const row=rows.find(row=>row.event?.id===selectedId),node=root.current;if(row&&node){if(row.height>node.clientHeight||row.top<node.scrollTop)node.scrollTop=row.top;else if(row.top+row.height>node.scrollTop+node.clientHeight)node.scrollTop=Math.max(0,row.top+row.height-node.clientHeight);setScroll(node.scrollTop);}},[selectedId,collapsed.join('|')]);
 useEffect(()=>{if(!pendingFocus.current)return;const button=root.current?.querySelector<HTMLButtonElement>('.timeline-table-title[aria-pressed=true]');if(button){pendingFocus.current=false;button.focus({preventScroll:true});}},[selectedId,scroll,collapsed.join('|')]);
 return <div ref={root} className="timeline-event-table" role="region" aria-label={t('Timeline events')} tabIndex={0} onScroll={event=>setScroll(event.currentTarget.scrollTop)}><div className="timeline-event-table-inner" style={{height:offset}}>{rows.filter(row=>row.top+row.height>=scroll-120&&row.top<=scroll+height+120).map(row=>row.event?<div key={row.key} data-event-id={row.event.id} ref={node=>{if(!node)return;observer.current?.observe(node);return()=>observer.current?.unobserve(node);}} className="timeline-table-row" data-selected={row.event.id===selectedId} style={{top:row.top,minHeight:72}}><input type="checkbox" aria-label={t('Select {0}',row.event.title)} checked={selectedIds.includes(row.event.id)} onChange={()=>onToggle(row.event!.id)}/><span className="timeline-table-date">{eventDateLabel({...row.event,dateLabel:''})}{calendarEventDateLabel(row.event,calendar)&&<small className="calendar-event-equivalent">{calendarEventDateLabel(row.event,calendar)}</small>}{row.event.end&&<small>{t('Period')}</small>}</span><button type="button" className="timeline-table-title" aria-pressed={row.event.id===selectedId} tabIndex={selectedId===row.event.id||!events.some(event=>event.id===selectedId)&&events[0]?.id===row.event.id?0:-1} onClick={()=>onSelect(row.event!.id)} onDoubleClick={()=>onEdit(row.event!)} onKeyDown={event=>{if(!['ArrowDown','ArrowUp','Home','End'].includes(event.key))return;event.preventDefault();const position=events.findIndex(item=>item.id===row.event!.id),next=events[event.key==='Home'?0:event.key==='End'?events.length-1:position+(event.key==='ArrowDown'?1:-1)];if(next){pendingFocus.current=true;onSelect(next.id);}}}><strong>{row.event.id===selectedId&&<Check size={14} aria-hidden="true"/>}{row.event.title||t('Untitled event')}</strong><small>{memberships.get(row.event.id)?.join(' · ')||t('Unassigned events')}</small>{row.event.dateLabel&&<small>{row.event.dateLabel}</small>}</button>{manual&&onMove&&<div className="event-order"><button type="button" title={t('Move event up')} aria-label={t('Move event up')} disabled={events[0]?.id===row.event.id} onClick={()=>onMove(row.event!.id,-1)}><ArrowUp size={12}/></button><button type="button" title={t('Move event down')} aria-label={t('Move event down')} disabled={events[events.length-1]?.id===row.event.id} onClick={()=>onMove(row.event!.id,1)}><ArrowDown size={12}/></button></div>}</div>:row.day?<div key={row.key} className="timeline-table-day" style={{top:row.top,height:row.height}} role="heading" aria-level={4}>{row.label}</div>:<button key={row.key} type="button" className="timeline-table-group" style={{top:row.top,height:row.height}} aria-expanded={!collapsed.includes(row.groupKey!)} onClick={()=>setCollapsed(collapsed.includes(row.groupKey!)?collapsed.filter(key=>key!==row.groupKey):[...collapsed,row.groupKey!])}>{collapsed.includes(row.groupKey!)?<ChevronRight size={14}/>:<ChevronDown size={14}/>}<span>{row.label==='undated'?t('Undated events'):row.label}</span><small>{row.count}</small></button>)}</div></div>;
}
