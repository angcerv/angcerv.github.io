import type {Project} from './model';
import type {EncyclopediaOptions,EncyclopediaFormat} from './encyclopediaExport';
// Load the worker client only when requested; never fall back to blocking the UI.
export async function prepareEncyclopedia(project:Project,options:EncyclopediaOptions,format:EncyclopediaFormat,path:string,signal:AbortSignal){
 const {runEncyclopediaWorker}=await import('./encyclopediaWorkerClient');
 signal.throwIfAborted();
 return runEncyclopediaWorker(project,options,format,path,signal);
}
