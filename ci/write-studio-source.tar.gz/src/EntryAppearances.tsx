import Dropdown from './Dropdown';
import {TextReferenceContext} from './textReferenceContext';
import { useContext, useId, useMemo, useState } from 'react';
import { ArrowUpRight, Pin } from 'lucide-react';
import { t } from './i18n';
import type { Chapter } from './model';
import type { Worldbuilding } from './worldbuilding';
import { entryAppearances } from './entryAppearanceIndex';
import { mentionContext } from './mentionDetection';

type Props={embedded?:boolean;chapters:Chapter[];world:Worldbuilding;entryId:string;onOpenScene?:(id:string)=>void;onOpenMention?:(sceneId:string,range:{from:number;to:number})=>void};
export default function EntryAppearances({embedded=false,chapters,world,entryId,onOpenScene,onOpenMention}:Props){
 const titleId=useId(),context=useContext(TextReferenceContext),[bookId,setBookId]=useState('');
 const books=context?.project.books;
 const activeBook=books?.find(book=>book.id===bookId);
 const scopedChapters=useMemo(()=>activeBook?chapters.filter(chapter=>activeBook.chapterIds.includes(chapter.id)):chapters,[chapters,activeBook]);
 const {groups,chapterCount,sceneCount,mentionCount}=useMemo(()=>entryAppearances(scopedChapters,world,entryId),[scopedChapters,world,entryId]);
 return <section className="entry-appearances" aria-labelledby={embedded?undefined:titleId} aria-label={embedded?t('Manuscript appearances'):undefined}>
  {!embedded&&<h3 id={titleId}>{t('Manuscript appearances')}</h3>}
  {!!books?.length&&<div className="ui-form-field"><label htmlFor={`${titleId}-book`}>{t('Book')}</label><Dropdown id={`${titleId}-book`} value={activeBook?.id??''} options={[{value:'',label:t('All books')},...books.map(book=>({value:book.id,label:book.title}))]} onChange={setBookId}/></div>}
  <p className="world-hint">{t('{0} chapters · {1} scenes · {2} text mentions',chapterCount,sceneCount,mentionCount)}</p>
  {!groups.length&&<p className="world-hint">{t('No appearances yet. Mentions and manual scene links will appear here.')}</p>}
  <div className="entry-appearance-chapters">{groups.map(({chapter,scenes})=><details className="entry-appearance-chapter" key={chapter.id}>
   <summary><span>{[books?.find(book=>book.chapterIds.includes(chapter.id))?.title,chapter.title||t('Untitled chapter')].filter(Boolean).join(' · ')}</span><small>{t('{0} scenes · {1} mentions',scenes.length,scenes.reduce((sum,item)=>sum+item.mentions.length,0))}</small></summary>
   {scenes.map(({scene,manual,mentions})=><div className="entry-appearance-scene" key={scene.id}>
    <div className="entry-appearance-scene-heading"><button type="button" disabled={!onOpenScene&&!(mentions.length&&onOpenMention)} onClick={()=>{if(mentions.length&&onOpenMention)onOpenMention(scene.id,mentions[0]);else onOpenScene?.(scene.id);}}><span>{scene.title||t('Untitled scene')}</span><ArrowUpRight size={13}/></button>{manual&&<small className="entry-appearance-manual"><Pin size={11}/>{t('Manual link')}</small>}</div>
    {mentions.length?<details className="entry-appearance-mentions"><summary>{mentions.length===1?t('1 text mention'):t('{0} text mentions',mentions.length)}</summary><ol>{mentions.map((mention,index)=><li key={`${mention.from}:${mention.to}`}><button type="button" disabled={!onOpenMention} aria-label={t('Go to mention {0} of {1} in {2}',index+1,mentions.length,scene.title||t('Untitled scene'))} onClick={()=>onOpenMention?.(scene.id,mention)}><strong>{mention.label}</strong><span>{mentionContext(scene,mention.from,mention.to)}</span></button></li>)}</ol></details>:<p className="world-hint">{t('Linked manually · no text mentions')}</p>}
   </div>)}
  </details>)}</div>
 </section>;
}
