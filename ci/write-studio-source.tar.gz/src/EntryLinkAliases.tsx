import FieldHelp from './FieldHelp';
import { useState } from 'react';
import { X, Plus } from 'lucide-react';
import { t } from './i18n';
import { setEntryLinkAliases } from './worldbuilding';
import type { Entry, Worldbuilding } from './worldbuilding';

export default function EntryLinkAliases({world,entry,onChange,embedded=false}:{embedded?:boolean;world:Worldbuilding;entry:Entry;onChange:(world:Worldbuilding)=>void}) {
 const [draft,setDraft]=useState('');
 const aliases=entry.linkAliases??[];
 function add(){if(!draft.trim())return;onChange(setEntryLinkAliases(world,entry.id,[...aliases,...draft.split(/\r?\n/)]));setDraft('');}
 return <section className="entry-link-aliases" aria-label={embedded?t('Link aliases'):undefined} aria-labelledby={embedded?undefined:"entry-link-aliases-title"}>
  {!embedded&&<div className="entry-link-aliases-heading"><h3 id="entry-link-aliases-title">{t('Link aliases')}</h3><FieldHelp label={t('Link aliases')} description={t('Names and variants that help identify this entry when writing.')}/></div>}
  <span id="entry-link-aliases-help" className="visually-hidden">{t('Names and variants that help identify this entry when writing.')}</span>
  {aliases.length>0&&<ul>{aliases.map(alias=><li key={alias}><span>{alias}</span><button type="button" className="icon-button" aria-label={t('Remove link alias {0}',alias)} onClick={()=>onChange(setEntryLinkAliases(world,entry.id,aliases.filter(value=>value!==alias)))}><X size={13}/></button></li>)}</ul>}
  <div className="entry-link-alias-add"><input aria-label={t('Add a link alias')} aria-describedby="entry-link-aliases-help" placeholder={t('Press Enter to add a name.')} value={draft} onChange={event=>setDraft(event.target.value)} onBlur={add} onKeyDown={event=>{if(event.key==='Enter'&&!event.nativeEvent.isComposing){event.preventDefault();add();}}}/><button type="button" disabled={!draft.trim()} onClick={add}><Plus size={14}/>{t('Add alias')}</button>{embedded&&<FieldHelp label={t('Link aliases')} description={t('Names and variants that help identify this entry when writing.')}/>}</div>
 </section>;
}
