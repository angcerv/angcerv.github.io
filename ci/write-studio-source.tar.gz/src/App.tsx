import {scrollManuscriptRange} from './manuscriptRangeScroll';
import {ManuscriptCaret} from './manuscriptCaret';
import {EditorFormattingShortcuts,formattingShortcut,formattingAriaShortcut} from './editorFormatting';
import type {FormattingAction} from './editorFormatting';
import {useProjectResume} from './useProjectResume';
import {clearProjectResume} from './projectResume';
import type {ProjectResume} from './projectResume';
import LocalProjectsDialog from './LocalProjectsDialog';
import type {MapLocationRequest} from './mapNavigation';
import {deferPanel} from './DeferredPanel';
import BookNavigation from './BookNavigation';
const IdeaCanvasEditor=deferPanel(()=>import('./IdeaCanvasEditor'));
const BooksDialog=deferPanel(()=>import('./BooksDialog'));
import {bookChapters,bookProject,bookOrganization,applyBookOrganization,bookSelection,bookSelectionAfterOrganization,selectionBook,mergeBookProject,pruneBookChapters} from './books';
import type {ProjectExportRequest} from './projectExport';
const ProjectTrash=deferPanel(()=>import('./ProjectTrash'));
const ProjectExportDialog=deferPanel(()=>import('./ProjectExportDialog'));
import ProjectOverview from './ProjectOverview';
import PlanningNavigation from './PlanningNavigation';
import WorldNavigation from './WorldNavigation';
import PrimaryNavigation from './PrimaryNavigation';
import {primaryWorkspace} from './workspaceStructure';
import type {PrimaryWorkspace} from './workspaceStructure';
import ReviewFollowup from './ReviewFollowup';
import {continuityReviewSubject,currentReview,reviewReturnVisit} from './reviewWorkflow';
import type {ReviewSubject} from './reviewWorkflow';
import {continuityEvidence,loadContinuityDismissals,saveContinuityDismissals,continuityReviewRevision,subscribeContinuityReview} from './narrativeContinuity';
import type {WorkspacePosition} from './workspaceNavigation';
import {closeHistory} from '@tiptap/pm/history';
import ManuscriptSearch from './ManuscriptFindDialog';
import {replaceManuscript,replacementTransaction} from './manuscriptSearch';
import {ManuscriptHistory} from './manuscriptHistory';
const EntryHistoryDialog=deferPanel(()=>import('./EntryHistoryDialog'));
import {recoverEntry} from './entryHistory';
import type {EntryRecoveryRequest} from './entryHistory';
import {fragmentSources,sourceForFragment,fragmentRange} from './decisionFragments';
import type {DecisionFragment,FragmentRequest} from './decisionFragments';
import {attachEntryImage,saveVisualResource,entryImageIds,mainEntryImage} from './visualResources';
import {importVisualImages,storeEntryImage} from './entryImages';
import ProjectModal from './ProjectModal';
import SaveProgressDialog, {ProjectLoadingDialog} from './SaveProgressDialog';
import type {ProjectLoadPhase} from './SaveProgressDialog';
import {cloneWorkspaceMemory,captureWorkspacePosition,workspaceRouteExists,recordWorkspaceVisit} from './workspaceNavigation';
import {useWorkspaceNavigation} from './useWorkspaceNavigation';
import {workspaceVisitLabel} from './workspaceVisitLabel';
import type {WorkspaceVisit} from './workspaceNavigation';
import {prepareLoreNavigation} from './worldLore';
import {ArrowLeft,ArrowRight} from 'lucide-react';
import TextReferenceProvider from './TextReferenceProvider';
import type {TextReferenceSource} from './textReferenceIndex';
import {saveWorldIdea} from './worldIdeas';
import {stampPendingDates} from './pendingDates';
import {stampEntryModifications} from './entryOrdering';
import {removeDeletedEntryRelations} from './entryRelations';
import {createEntryPackage,importEntries} from './entryTransfer';
import type {EntryPackage} from './entryTransfer';
const CharacterArcsEditor=deferPanel(()=>import('./CharacterArcsEditor'));

const PlotsEditor=deferPanel(()=>import('./PlotsEditor'));
import { emptyPlots } from './plotThreads';

const ProjectPending=deferPanel(()=>import('./ProjectPending'));
import type { PendingItem } from './pendingItems';

import SceneBoard from './SceneBoard';
import { commentKey, createCommentPlugin } from './reviewComments';
import type { ReviewComment, CommentDraft } from './reviewComments';
import ReviewCommentDialog from './ReviewCommentDialog';
import { MessageSquarePlus } from 'lucide-react';
import { recoverScene } from './sceneRecovery';
import type { SceneRecoveryRequest } from './sceneRecovery';
import ContinuityReview from './ContinuityReview';
import { reviewContinuity,resolveContinuityMention } from './continuity';
import type { ContinuityIssue } from './continuity';
import { ClipboardCheck } from 'lucide-react';
import ChapterManuscript from './ChapterManuscript';
import { patchScene } from './manuscript';
import ManuscriptActions from './ManuscriptActions';
import MentionActionDialog from './MentionActionDialog';
import type { MentionAction, MentionCommand } from './manuscriptMentions';
import type { IgnoredMention, ResolvedMention } from './model';
import { createMentionPlugin, mentionPluginKey } from './manuscriptMentions';
import MentionChoiceDialog from './MentionChoiceDialog';
import type { Worldbuilding } from './worldbuilding';
import { createTemplatePackage, templateFilename } from './templateTransfer';
import { nameCheckpoint, loadTemplatePackage, exportTemplatePackage, loadEntryPackage, exportEntryPackage } from './storage';
import {message,t,useLanguage,buttonLabel} from './i18n';
const MapsEditor=deferPanel(()=>import('./MapsEditor'));
import { emptyMaps } from './maps';
import ProjectDeletionDialog from './ProjectDeletionDialog';
import { inspectProjectDeletion, deleteProject } from './storage';
import type { ProjectDeletionTarget } from './storage';
import WritingGoalsDialog, { WritingGoalsButton } from './WritingGoalsDialog';
import { countPlainWords, createManuscriptCounter } from './writingGoals';
import type { WritingGoals } from './writingGoals';
import FocusModeControls from './FocusModeControls';
import { defaultFocusPreferences, focusPreferencesKey, parseFocusPreferences, focusWritingStyle, isFocusShortcut } from './focusMode';
import type { FocusPreferences } from './focusMode';
import { backupFilename } from './projectBackup';

import { createMapBaseImage, importEntryImage } from './entryImages';
import {useProjectPersistence} from './useProjectPersistence';
import ManuscriptDeletionDialog from './ManuscriptDeletionDialog';
const TimelineEditor=deferPanel(()=>import('./TimelineEditor'));
import ManuscriptNavigation from './ManuscriptNavigation';
import ChapterPlanning from './ChapterPlanner';
import ChapterOverview from './ChapterOverview';
import ActionMenu from './ActionMenu';
import SaveStatus from './SaveStatus';
import ProjectSearch from './ProjectSearch';
const VersionHistory=deferPanel(()=>import('./VersionHistory'));
import AppMenu from './AppMenu';
import WelcomeScreen from './WelcomeScreen';
import type { RecentProject } from './storage';
import SidebarResize from './SidebarResize';
import ManuscriptTools from './ManuscriptTools';
import { useEffect, useLayoutEffect, useMemo, useRef, useState, useSyncExternalStore, useDeferredValue } from 'react';
import type { Editor } from '@tiptap/react';
import type { ReactNode } from 'react';
import { EditorContent, useEditor, useEditorState } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import { listen } from '@tauri-apps/api/event';
import { House, Plus, Bold, Italic, Undo2, Redo2, PanelLeftClose, PanelLeftOpen, Feather, Save, Settings as SettingsIcon, Pencil, X, Download, Search, History, Archive, Trash2 } from 'lucide-react';
import { fromMarkdown, toMarkdown, newProject, newScene, suggestFolderName } from './model';
import type { Project, Scene } from './model';
import { chooseFolder, openProject, saveProject, exitApp, readSettings, setProjectsDirectory, createProject, restoreVersion, readRecentProjects, rememberRecentProject, forgetRecentProject, createProjectBackup, restoreProjectBackup } from './storage';
import type { Settings } from './storage';
import ProjectDialogs from './ProjectDialogs';
import { moveChapter, moveScene, transferScene } from './manuscript';
import WorldPanel from './WorldPanel';
const WorldbuildingEditor=deferPanel(()=>import('./WorldbuildingEditor'));
import { emptyWorld } from './worldbuilding';
import './WorldPanel.css';
import './App.css';
import './interactions.css';
import './Dropdown.css';
import './workspace.css';
import './styles/navigation.css';
import './styles/controls.css';
import './styles/long-text.css';
import './styles/books.css';

type IconButtonProps = { shortcut?:FormattingAction;label: string; children: ReactNode; onClick: () => void; active?: boolean; disabled?: boolean; className?: string };
function IconButton({ shortcut,label, children, onClick, active, disabled, className = '' }: IconButtonProps) {
  return <button type="button" className={`icon-button${active ? ' active' : ''} ${className}`} aria-label={label} title={shortcut?`${label} (${formattingShortcut(shortcut)})`:label} aria-keyshortcuts={shortcut?formattingAriaShortcut(shortcut):undefined} aria-pressed={active} disabled={disabled} onClick={onClick}>{children}</button>;
}
function SceneFormattingToolbar({editor,focused=false,goals,manuscriptWords,onOpenGoals}:{editor:Editor|null;focused?:boolean;goals?:WritingGoals;manuscriptWords:number;onOpenGoals:()=>void}){
 const state=useEditorState({editor,selector:({editor:e})=>({bold:e?.isActive('bold'),italic:e?.isActive('italic'),undo:e?.can().undo(),redo:e?.can().redo(),selected:!!e&&!e.state.selection.empty,words:countPlainWords(e?.getText()??'')})});
 return <div className="editor-toolbar" inert={focused} role="toolbar" aria-label={t("Text formatting")}>
    <IconButton label={t("Bold")} shortcut="bold" disabled={!editor} active={state?.bold} onClick={() => { editor?.chain().focus().toggleBold().run(); }}><Bold /></IconButton>
    <IconButton label={t("Italic")} shortcut="italic" disabled={!editor} active={state?.italic} onClick={() => { editor?.chain().focus().toggleItalic().run(); }}><Italic /></IconButton>
    <span className="divider" />
    <IconButton label={t("Undo (⌘Z)")} disabled={!state?.undo} onClick={() => { editor?.chain().focus().undo().run(); }}><Undo2 /></IconButton>
    <IconButton label={t("Redo (⇧⌘Z)")} disabled={!state?.redo} onClick={() => { editor?.chain().focus().redo().run(); }}><Redo2 /></IconButton>
    <IconButton label={t('Add comment (⌘⌥M / Ctrl+Alt+M)')} disabled={!editor||!state?.selected} onClick={()=>{if(editor)editor.view.dispatch(editor.state.tr.setMeta(commentKey,{kind:'compose'}));}}><MessageSquarePlus/></IconButton>
    <span className="word-count">{state?.words ?? 0}{" " + t("words")}</span><WritingGoalsButton goals={goals} words={manuscriptWords} onClick={onOpenGoals}/>
  </div>;
}
function SceneEditor({ history, embedded=false,active=true,onActivate,onDispose,onReady,world,onOpenEntry,scene, onChange, editorRef, scrollRef, focused, focusPreferences, onFocusPreferences, onExitFocus, goals, manuscriptWords, onOpenGoals }: { history:ManuscriptHistory;embedded?:boolean;active?:boolean;onActivate?:(id:string,editor:Editor)=>void;onDispose?:(id:string,editor:Editor)=>void;onReady?:(sceneId:string,editor:Editor)=>void;world:Worldbuilding;onOpenEntry:(id:string)=>void;goals?:WritingGoals;manuscriptWords:number;onOpenGoals:()=>void;focused:boolean;focusPreferences:FocusPreferences;onFocusPreferences:(next:FocusPreferences)=>void;onExitFocus:()=>void; scene: Scene; onChange: (content: string,ignoredMentions:IgnoredMention[],resolvedMentions:ResolvedMention[],reviewComments:ReviewComment[]) => void; editorRef: { current: Editor | null }; scrollRef: { current: HTMLDivElement | null } }) {
  const [commentDraft,setCommentDraft]=useState<CommentDraft|null>(null);
  const commentsRef=useRef(scene.reviewComments??[]);commentsRef.current=scene.reviewComments??[];
  const [mentionChoice,setMentionChoice]=useState<{ids:string[];label:string;from:number;to:number}|null>(null);
  const [mentionAction,setMentionAction]=useState<MentionAction|null>(null);
  const ignoredRef=useRef(scene.ignoredMentions??[]);ignoredRef.current=scene.ignoredMentions??[];
  const resolvedRef=useRef(scene.resolvedMentions??[]);resolvedRef.current=scene.resolvedMentions??[];
  const saveScene=useRef(onChange);saveScene.current=onChange;
  const activateCallback=useRef(onActivate);activateCallback.current=onActivate;
  const disposeCallback=useRef(onDispose);disposeCallback.current=onDispose;
  const readyCallback=useRef(onReady);readyCallback.current=onReady;
  const openEntry=useRef(onOpenEntry);openEntry.current=onOpenEntry;
  const editor = useEditor({
    extensions: [ManuscriptCaret,EditorFormattingShortcuts,StarterKit.configure({ heading: false, blockquote: false, bulletList: false, orderedList: false, listItem: false, listKeymap: false, code: false, codeBlock: false, strike: false, underline: false, link: false, horizontalRule: false, trailingNode: false })],
    content: fromMarkdown(scene.content),
    editorProps: { attributes: { 'aria-label': embedded?t('Scene text · {0}',scene.title||t('Untitled scene')):t("Scene text"), role: 'textbox', 'aria-multiline': 'true', spellcheck: 'true' } },
    onFocus:({editor:current})=>activateCallback.current?.(scene.id,current),
    onUpdate: ({ editor: current }) => {if(embedded)activateCallback.current?.(scene.id,current);saveScene.current(toMarkdown(current.getJSON()),mentionPluginKey.getState(current.state)?.ignored??ignoredRef.current,mentionPluginKey.getState(current.state)?.resolved??resolvedRef.current,commentKey.getState(current.state)?.comments??commentsRef.current);},
  });
  useLayoutEffect(()=>{if(editor)return history.attach(scene.id,editor);},[editor,history,scene.id]);
  useEffect(()=>{
    if(!editor)return;
    editor.registerPlugin(createCommentPlugin(commentsRef.current,setCommentDraft));
    return()=>{if(!editor.isDestroyed)editor.unregisterPlugin(commentKey);};
  },[editor]);
  useEffect(()=>{if(!editor||editor.isDestroyed)return;const current=commentKey.getState(editor.state);if(current&&JSON.stringify(current.comments)!==JSON.stringify(scene.reviewComments??[]))editor.view.dispatch(editor.state.tr.setMeta(commentKey,{kind:'sync',comments:scene.reviewComments??[]}));},[editor,scene.reviewComments]);
  useEffect(() => { if(active)editorRef.current=editor;return () => { if(editorRef.current===editor)editorRef.current=null; }; }, [editor,editorRef,active]);
  useEffect(()=>{
    if(!editor)return;
    editor.registerPlugin(createMentionPlugin(world,(ids,label,range)=>{if(ids.length===1)openEntry.current(ids[0]);else if(range)setMentionChoice({ids,label,...range});},ignoredRef.current,setMentionAction,resolvedRef.current));
    return ()=>{if(!editor.isDestroyed)editor.unregisterPlugin(mentionPluginKey);};
  },[editor,world]);
  useEffect(()=>{
    if(!editor||editor.isDestroyed)return;
    const current=mentionPluginKey.getState(editor.state);if(!current)return;
    const ignored=scene.ignoredMentions??[],resolved=scene.resolvedMentions??[];
    if(JSON.stringify(current.ignored)!==JSON.stringify(ignored)||JSON.stringify(current.resolved)!==JSON.stringify(resolved))editor.view.dispatch(editor.state.tr.setMeta(mentionPluginKey,{kind:'sync',ignored,resolved}));
  },[editor,world,scene.ignoredMentions,scene.resolvedMentions]);
  useEffect(()=>{if(editor)readyCallback.current?.(scene.id,editor);return()=>{if(editor)disposeCallback.current?.(scene.id,editor);};},[editor,scene.id]);
  function applyMentionCommand(command:MentionCommand){
    if(!editor)return;
    editor.view.dispatch(editor.state.tr.setMeta(mentionPluginKey,command));
    const data=mentionPluginKey.getState(editor.state);
    saveScene.current(toMarkdown(editor.getJSON()),data?.ignored??[],data?.resolved??[],commentKey.getState(editor.state)?.comments??[]);
  }
  const state = useEditorState({ editor, selector: ({ editor: e }) => ({ bold: e?.isActive('bold'), italic: e?.isActive('italic'), undo: e?.can().undo(), redo: e?.can().redo(), words: countPlainWords(e?.getText() ?? '') }) });
  return <>{commentDraft&&<ReviewCommentDialog draft={commentDraft} onClose={()=>{setCommentDraft(null);editor?.commands.focus();}} onSave={comment=>{if(editor){editor.view.dispatch(editor.state.tr.setMeta(commentKey,{kind:'upsert',comment}));const mentions=mentionPluginKey.getState(editor.state);saveScene.current(toMarkdown(editor.getJSON()),mentions?.ignored??[],mentions?.resolved??[],commentKey.getState(editor.state)?.comments??[]);}setCommentDraft(null);editor?.commands.focus();}}/>}{mentionAction&&<MentionActionDialog action={mentionAction} onClose={()=>setMentionAction(null)} onApply={()=>{applyMentionCommand(mentionAction);setMentionAction(null);}} onReset={mentionAction.resolved?()=>{applyMentionCommand({kind:'clearResolution',from:mentionAction.from,to:mentionAction.to});setMentionAction(null);}:undefined}/>}{mentionChoice&&<MentionChoiceDialog world={world} ids={mentionChoice.ids} label={mentionChoice.label} onClose={()=>setMentionChoice(null)} onChoose={id=>{applyMentionCommand({kind:'resolve',from:mentionChoice.from,to:mentionChoice.to,text:mentionChoice.label,entryId:id});setMentionChoice(null);openEntry.current(id);}}/>}{focused && <FocusModeControls title={scene.title || t("Untitled scene")} preferences={focusPreferences} onChange={onFocusPreferences} onExit={onExitFocus} onGoals={onOpenGoals}/>}{!embedded&&<SceneFormattingToolbar editor={editor} focused={focused} goals={goals} manuscriptWords={manuscriptWords} onOpenGoals={onOpenGoals}/>}{embedded?<EditorContent editor={editor}/>:<div className="writing-scroll" ref={scrollRef}><div className="writing-page"><EditorContent editor={editor}/></div></div>}{focused && <div className="focus-word-count"><span aria-label={t("Scene word count")}>{state?.words ?? 0}{" " + t("words")}</span>{(goals?.projectTarget || goals?.activeSession) && <WritingGoalsButton goals={goals} words={manuscriptWords} onClick={onOpenGoals}/>}</div>}</>;
}
type Pending = 'new' | 'open' | 'close' | 'exit' | 'restore';
export default function App() {
  const language=useLanguage();
  useEffect(()=>{document.documentElement.lang=language;},[language]);
  const [theme, setTheme] = useState(() => { try { return localStorage.getItem('write-studio.theme') === 'light' ? 'light' : 'dark'; } catch { return 'dark'; } });
  const [deletionTarget, setDeletionTarget] = useState<ProjectDeletionTarget | null>(null);
  const [recents, setRecents] = useState<RecentProject[]>([]);
  const [recentsLoading, setRecentsLoading] = useState(true);
  const [recentsError, setRecentsError] = useState('');
  const [project, setProject] = useState<Project | null>(null);
  const [settings, setSettings] = useState<Settings | null>(null);
  const [projectOpenFailure,setProjectOpenFailure]=useState<{path:string;error:string}|null>(null);
  const openingProjectTitle=useRef<{path:string;title:string}|null>(null);
  const [loadingProject,setLoadingProject]=useState<{path:string;title:string}|null>(null);
  const [projectLoadPhase,setProjectLoadPhase]=useState<ProjectLoadPhase|null>(null);
  const [localProjectsOpen,setLocalProjectsOpen]=useState(false);
  const [dialog, setDialog] = useState<'new' | 'settings' | null>(null);
  const [projectName, setProjectName] = useState('');
  const [folderName, setFolderName] = useState('project');
  const [folderEdited, setFolderEdited] = useState(false);
  const [path, setPath] = useState('');
  const [selectedId, setSelectedId] = useState('');
  const [selectedBook,setSelectedBook]=useState(''),[booksOpen,setBooksOpen]=useState<false|'manage'|'create'>(false);
  const [manuscriptMode,setManuscriptMode]=useState<'scene'|'chapter'|'board'|'planning'>('scene');
  const [chapterActiveEditor,setChapterActiveEditor]=useState<Editor|null>(null);
  const chapterEditors=useRef(new Map<string,Editor>());
  const [session, setSession] = useState(0);

  useEffect(()=>{setSelectedBook('');setBooksOpen(false);},[session]);

  const manuscriptHistory=useMemo(()=>new ManuscriptHistory(),[session]);
  const [manuscriptSearchOpen,setManuscriptSearchOpen]=useState(false);
  useEffect(()=>setManuscriptSearchOpen(false),[session]);
  const [renaming, setRenaming] = useState(false);
  const [renameValue, setRenameValue] = useState('');
  const [sidebarWidth, setSidebarWidth] = useState(230);
  const [toolsTab, setToolsTab] = useState<'scene' | 'chapter' | 'context'>('context');
  const [manuscriptCommentsRequest,setManuscriptCommentsRequest]=useState(0);
  const [toolsOpen, setToolsOpen] = useState(false);
  const [toolsOpenRequest,setToolsOpenRequest]=useState(0);
  const toolsTrigger = useRef<HTMLButtonElement>(null);
  const [sidebar, setSidebar] = useState(true);
  const [worldOpen, setWorldOpen] = useState(false);
  const [focusMode,setFocusMode]=useState(false);
  const [focusPreferences,setFocusPreferences]=useState<FocusPreferences>(()=>{try{return parseFocusPreferences(localStorage.getItem(focusPreferencesKey));}catch{return {...defaultFocusPreferences};}});
  useEffect(()=>{try{localStorage.setItem(focusPreferencesKey,JSON.stringify(focusPreferences));}catch{/* Appearance preferences are optional. */}},[focusPreferences]);
  const [worldTemplateRequest,setWorldTemplateRequest]=useState<{id:string;token:number}>();
  const [pendingIdeaId,setPendingIdeaId]=useState('');
  const [plotId,setPlotId]=useState('');
  const [activeView, setActiveView] = useState<'home' | 'manuscript' | 'worldbuilding' | 'timeline' | 'maps' | 'pending' | 'plots' | 'arcs' | 'canvas'>('manuscript');
  const [worldSection, setWorldSection] = useState<'entries' | 'templates'>('entries');
  const [mapId,setMapId]=useState('');
  const [mapMarkerId,setMapMarkerId]=useState('');
  const [timelineEventId, setTimelineEventId] = useState('');
  const [timelineOpenRequest,setTimelineOpenRequest]=useState<{id:string;token:number}>();
  useEffect(()=>setTimelineOpenRequest(undefined),[session]);
  const [worldEntryId, setWorldEntryId] = useState('');
  const [fragmentRequest,setFragmentRequest]=useState<FragmentRequest|undefined>();
  const [worldNavigationRequest, setWorldNavigationRequest] = useState(0);
  const [exportOpen, setExportOpen] = useState<ProjectExportRequest|null>(null);
  const [searchOpen, setSearchOpen] = useState(false);
  const [trashOpen,setTrashOpen]=useState(false);
  useEffect(()=>setTrashOpen(false),[session]);
  const searchMatch=useRef<{kind:'plot'|'arc';sceneId:string}|undefined>(undefined);
  const [arcId,setArcId]=useState('');
  const [continuityOpen,setContinuityOpen]=useState(false);
  const continuityReturnPosition=useRef<WorkspacePosition|undefined>(undefined);
  const [reviewTrail,setReviewTrail]=useState<{subject:ReviewSubject;origin:WorkspaceVisit;continuityPosition?:WorkspacePosition}|null>(null);
  const reviewRevision=useSyncExternalStore(subscribeContinuityReview,continuityReviewRevision,continuityReviewRevision);
  const reviewProject=useDeferredValue(project),reviewChecking=reviewProject!==project;
  const activeReview=useMemo(()=>reviewProject&&reviewTrail?currentReview(reviewProject,reviewTrail.subject):null,[reviewProject,reviewTrail,reviewRevision,language]);
  useEffect(()=>{setReviewTrail(null);setContinuityOpen(false);continuityReturnPosition.current=undefined;},[session]);
  const [goalsOpen,setGoalsOpen]=useState(false);
  const [countManuscript]=useState(()=>createManuscriptCounter());
  const manuscriptWords=useMemo(()=>countManuscript(project?.chapters ?? []),[project?.chapters,countManuscript]);
  const [entryHistoryId,setEntryHistoryId]=useState('');
  useEffect(()=>setEntryHistoryId(''),[session]);
  const [historyOpen, setHistoryOpen] = useState(false);
  const pendingRecentPath = useRef<string | undefined>(undefined);
  const [pending, setPending] = useState<Pending | null>(null);
  const {ready,recoverable,setRecoverable,recoveryReadError,setRecoveryReadError,recoveryStatus,setRecoveryStatus,
    autosaving,autosaveError,setAutosaveError,dirty,setDirty,busy,saveProgress,setSaveProgress,operation,error,setError,
    state,locked,run,save,protectDraft,clearDraft}=useProjectPersistence({project,path,selectedId,session,setProject,setPath,remember,
      isAutosaveBlocked:()=>!!(deletionTarget||historyOpen||entryHistoryId||dialog||pending||localProjectsOpen)});
  useProjectResume({enabled:!!settings?.localProjects,ready,blocked:busy||!!recoverable||recoveryReadError||!!dialog||!!pending||!!projectOpenFailure,
    projectId:project?.id,path,selectedId,view:activeView,onResume:resume=>{if(!locked.current)void perform('open',resume.path,resume);}});
  const [backupNotice,setBackupNotice]=useState('');
  const [announcement, setAnnouncement] = useState('');
  useEffect(() => { if (!announcement) return; const timer = window.setTimeout(() => setAnnouncement(''), 6000); return () => window.clearTimeout(timer); }, [announcement]);
  useEffect(() => setAnnouncement(''), [session, selectedId]);
  const [deleting, setDeleting] = useState<'scene' | 'chapter' | null>(null);
  const [routeRequest,setRouteRequest]=useState<{mapId:string;routeId:string}|undefined>(undefined);
  const [mapLocationRequest,setMapLocationRequest]=useState<MapLocationRequest>();
  useEffect(()=>{if(activeView!=='maps')setMapLocationRequest(undefined);},[activeView]);
  const sceneEditorRef = useRef<Editor | null>(null);
  const appearanceDestination=useRef<{sceneId:string;from:number;to:number;focus?:boolean}|null>(null);
  useEffect(()=>{appearanceDestination.current=null;},[session]);
  const mentionFlashTimer=useRef<ReturnType<typeof setTimeout>|undefined>(undefined);
  useEffect(()=>()=>clearTimeout(mentionFlashTimer.current),[]);
  const writingScrollRef = useRef<HTMLDivElement | null>(null);
  const writingScrollPosition = useRef(0);
  const activeBookId=project?(selectionBook(project,selectedId)?.id??project.books?.find(b=>b.id===selectedBook)?.id??project.books?.[0]?.id??''):'';
  const manuscriptProject=useMemo(()=>project?bookProject(project,activeBookId):null,[project,activeBookId]);
  const manuscriptChapters=manuscriptProject?.chapters??[];
  const chapter = project?.chapters.find(c => c.id === selectedId || c.scenes.some(s => s.id === selectedId)) ?? manuscriptChapters[0];
  const scene=chapter?.scenes.find(s=>s.id===selectedId)??(manuscriptMode==='chapter'?chapter?.scenes[0]:undefined);
  const primaryView=primaryWorkspace(activeView,manuscriptMode);
  const lastPlanning=useRef<'chapters'|'plots'|'arcs'|'canvas'>('chapters'),lastWorld=useRef<'worldbuilding'|'maps'>('worldbuilding'),lastWriting=useRef<'scene'|'chapter'>('scene');
  if(primaryView==='planning')lastPlanning.current=activeView==='canvas'?'canvas':activeView==='plots'?'plots':activeView==='arcs'?'arcs':'chapters';
  if(primaryView==='worldbuilding')lastWorld.current=activeView==='maps'?'maps':'worldbuilding';
  if(primaryView==='manuscript'&&(manuscriptMode==='scene'||manuscriptMode==='chapter'))lastWriting.current=manuscriptMode;
  useEffect(()=>{lastPlanning.current='chapters';lastWorld.current='worldbuilding';lastWriting.current='scene';},[session]);
  const focusActive=focusMode && activeView==='manuscript' && manuscriptMode!=='board' && manuscriptMode!=='planning' && !!scene;
  useEffect(()=>{if(!scene || activeView!=='manuscript')setFocusMode(false);},[scene?.id,activeView]);
  useEffect(()=>{setFocusMode(false);setGoalsOpen(false);setToolsOpen(false);setManuscriptMode('scene');setMapLocationRequest(undefined);},[session]);
  function toggleFocusMode() {
    if(!scene || (manuscriptMode==='board'||manuscriptMode==='planning') || activeView!=='manuscript' || busy || document.querySelector('dialog[open], [aria-modal="true"]'))return;
    setFocusMode(current=>!current);
    requestAnimationFrame(()=>sceneEditorRef.current?.commands.focus(undefined,{scrollIntoView:false}));
  }
  const chapterIndex = manuscriptChapters.findIndex(c => c.id === chapter?.id);
  const sceneIndex = chapter?.scenes.findIndex(s => s.id === scene?.id) ?? -1;
  const inspectingSelection = useRef(false);
  const {viewMemory,navigationHistory,navigationCurrent,restoringNavigation,navigationEpoch,setNavigationEpoch,
    navigationRevision,refreshWorkspaceNavigation,panelReady,navigationBackLabel,captureWorkspaceVisit,
    captureNavigation,captureNavigationScroll,navigateWorkspace,restoreWorkspaceVisit}=useWorkspaceNavigation({project,session,ready,busy,sceneId:scene?.id,sceneEditorRef,
      route:{bookId:activeBookId,view:activeView,selectedId,chapterId:chapter?.id??'',manuscriptMode,worldSection,worldEntryId,plotId,arcId,timelineEventId,mapId,mapMarkerId,routeRequest,pendingIdeaId,toolsOpen,toolsTab,worldOpen,sidebar,worldTemplateRequest},
      onRestoreRoute:route=>{
        appearanceDestination.current=null;inspectingSelection.current=true;
        setActiveView(route.view);setSelectedBook(route.bookId??'');setSelectedId(route.selectedId);
        setManuscriptMode(route.manuscriptMode);setWorldSection(route.worldSection);setWorldEntryId(route.worldEntryId);
        setPlotId(route.plotId);setArcId(route.arcId);setTimelineEventId(route.timelineEventId);
        setMapId(route.mapId);setMapMarkerId(route.mapMarkerId);setRouteRequest(route.routeRequest);
        setPendingIdeaId(route.pendingIdeaId);setToolsOpen(route.toolsOpen);setToolsTab(route.toolsTab);
        setWorldOpen(route.worldOpen);setSidebar(route.sidebar);setWorldTemplateRequest(route.worldTemplateRequest);setFocusMode(false);
      }
    });

  useEffect(() => { if (inspectingSelection.current) { inspectingSelection.current = false; return; } if(toolsTab!=='context')setToolsOpen(false); }, [selectedId, session]);
  function inspect(kind: 'scene' | 'chapter', id: string) { setFocusMode(false);setToolsOpenRequest(value=>value+1);setManuscriptMode('scene'); inspectingSelection.current = id !== selectedId; setSelectedId(id); setToolsTab(kind); setWorldOpen(false); setToolsOpen(true); }
  function closeTools() { setToolsOpen(false); toolsTrigger.current?.focus(); }
  useEffect(() => { document.documentElement.dataset.theme = theme; try { localStorage.setItem('write-studio.theme', theme); } catch { /* Theme persistence is optional. */ } }, [theme]);
  async function loadRecents() {
    setRecentsLoading(true); setRecentsError('');
    try { setRecents(await readRecentProjects()); } catch (e) { setRecentsError(t("Recent projects could not be read: {0}", String(e))); } finally { setRecentsLoading(false); }
  }
  useEffect(() => { void loadRecents(); }, []);
  async function remember(path: string, saved: Project, opened: boolean) {
    await rememberRecentProject(path, saved, opened).then(value => { setRecents(value); setRecentsError(''); }).catch(e => setRecentsError(t("Project kept, but recent projects could not be updated: {0}", String(e))));
  }
  async function requestProjectDeletion(targetPath: string, expectedId: string) {
    if (locked.current) return;
    if (state.current.project && state.current.dirty && !(await save())) return;
    await run(async () => {
      const target = await inspectProjectDeletion(targetPath);
      if (target.projectId !== expectedId) throw new Error(t("This folder contains a different project. Open it again before deleting."));
      setDeletionTarget(target);
    }, t("Checking project…"));
  }
  async function confirmProjectDeletion(confirmation: string) {
    if (!deletionTarget) return;
    await run(async () => {
      const active = state.current.path === deletionTarget.path;
      if (active) await clearDraft(); // Drain queued recovery writes before moving the folder.
      const result = await deleteProject(deletionTarget, confirmation);
      if (active) {
        state.current = { project: null, path: '', dirty: false, busy: true };
        clearProjectResume();setProject(null); setPath(''); setDirty(false); setSelectedId(''); setFocusMode(false);
        setAutosaveError(''); setSession(value => value + 1);
      }
      setRecents(current => current.filter(item => item.path !== deletionTarget.path));
      setDeletionTarget(null);
      setBackupNotice(t("Project moved to Trash.{0}", result.warning ? ` ${result.warning}` : ''));
    }, t("Moving project to Trash…"));
  }
  async function forgetRecent(path: string) {
    await run(async () => { setRecents(await forgetRecentProject(path)); setRecentsError(''); });
  }
  useEffect(() => {
    let disposed = false;
    void readSettings().then(value => { if (!disposed) setSettings(value); })
      .catch(e => { if (!disposed) setError(t("Settings could not be read: {0}", String(e))); });
    return () => { disposed = true; };
  }, []);
  useEffect(() => {
    let disposed = false;
    const subscription = listen('request-exit', () => { if (!locked.current) { const modal=document.querySelector<HTMLDialogElement>('dialog[open]');if(modal){modal.dispatchEvent(new Event('cancel',{cancelable:true}));return;}setGoalsOpen(false);if (state.current.dirty) { setDialog(null); setPending('exit'); } else void exitApp().catch(e => setError(String(e))); } });
    void subscription.then(unlisten => { if (disposed) unlisten(); }).catch(e => setError(String(e)));
    const warn = (e: BeforeUnloadEvent) => { if (state.current.dirty || locked.current) { e.preventDefault(); e.returnValue = ''; } };
    window.addEventListener('beforeunload', warn);
    return () => { disposed = true; void subscription.then(f => f()); window.removeEventListener('beforeunload', warn); };
  }, []);
  function changeView(view: 'home' | 'manuscript' | 'worldbuilding' | 'timeline' | 'maps' | 'pending' | 'plots' | 'arcs' | 'canvas', focusEditor = false) {
    if (activeView === 'manuscript' && writingScrollRef.current) writingScrollPosition.current = writingScrollRef.current.scrollTop;
    if(view!=='manuscript')setFocusMode(false);
    setActiveView(view);
    if (view === 'manuscript') requestAnimationFrame(() => {
      if (writingScrollRef.current) writingScrollRef.current.scrollTop = writingScrollPosition.current;
      if (focusEditor) sceneEditorRef.current?.commands.focus(undefined, { scrollIntoView: false });
    });
  }

  function selectPlanning(section:'chapters'|'plots'|'arcs'|'canvas'){
    setFocusMode(false);setToolsOpen(false);setWorldOpen(false);
    if(section==='chapters'){setManuscriptMode(manuscriptMode==='board'?'board':'planning');changeView('manuscript');}
    else changeView(section);
  }
  function openPrimary(view:PrimaryWorkspace){
    if(!prepareLoreNavigation(document.getElementById(`${activeView}-view`)))return;
    if(view==='planning'){selectPlanning(lastPlanning.current);return;}
    if(view==='worldbuilding'){changeView(lastWorld.current);return;}
    if(view==='manuscript')setManuscriptMode(lastWriting.current);
    changeView(view);
  }
  function openPendingSection(section:'ideas'|'review',kind='all',status='active'){
    viewMemory.current.values['pending.chapter']='';viewMemory.current.values['pending.query']='';viewMemory.current.values['pending.section']=section;viewMemory.current.values['pending.kind']=kind;viewMemory.current.values['pending.ideaStatus']=status;
    setPendingIdeaId('');changeView('pending');setNavigationEpoch(value=>value+1);
  }
  function openTimelineEvent(id:string){setTimelineEventId(id);setTimelineOpenRequest(previous=>({id,token:(previous?.token??0)+1}));changeView('timeline');}
  function goToScene(id: string) { setManuscriptMode('scene');appearanceDestination.current=null;setSelectedId(id); changeView('manuscript'); writingScrollPosition.current = 0; }
  useEffect(() => {
    const shortcut = (event: KeyboardEvent) => {
      const unblocked=project && ready && !busy && !dialog && !pending && !recoverable && !historyOpen && !recoveryReadError && !exportOpen && !searchOpen && !document.querySelector('dialog[open], [aria-modal="true"]');
      if(!event.isComposing && event.key==='Escape' && focusActive && unblocked && !event.defaultPrevented){event.preventDefault();toggleFocusMode();return;}

      if(unblocked&&!event.defaultPrevented&&!event.isComposing&&(event.metaKey||event.ctrlKey)&&!event.altKey&&!event.shiftKey&&event.key.toLowerCase()==='f'&&activeView==='manuscript'){event.preventDefault();setManuscriptSearchOpen(true);return;}
      if ((event.metaKey || event.ctrlKey) && !event.shiftKey && event.key.toLowerCase() === 's') {
        event.preventDefault();
        if (project && ready && !locked.current && !dialog && !pending && !recoverable && !historyOpen && !recoveryReadError && !document.querySelector('dialog[open], [aria-modal="true"]')) void save();
        return;
      }
      if ((event.metaKey || event.ctrlKey) && event.shiftKey && event.key.toLowerCase() === 'f' && project && ready && !busy && !dialog && !pending && !recoverable && !historyOpen && !recoveryReadError && !document.querySelector('dialog[open], [aria-modal="true"]')) { event.preventDefault(); setSearchOpen(true); }
    };
    const focusShortcut=(event:KeyboardEvent)=>{
      if(event.isComposing || !isFocusShortcut(event) || activeView!=='manuscript' || !scene || !ready || busy || dialog || pending || recoverable || historyOpen || recoveryReadError || exportOpen || searchOpen || document.querySelector('dialog[open], [aria-modal="true"]'))return;
      event.preventDefault();event.stopPropagation();if(!event.repeat)toggleFocusMode();
    };
    window.addEventListener('keydown',focusShortcut,true);window.addEventListener('keydown', shortcut);
    return () => {window.removeEventListener('keydown',focusShortcut,true);window.removeEventListener('keydown', shortcut);};
  }, [project, ready, busy, dialog, pending, recoverable, historyOpen, recoveryReadError, exportOpen, searchOpen, activeView, scene?.id, focusActive]);
  function editWorldEntry(id:string){
    if(!state.current.project?.worldbuilding?.entries.some(entry=>entry.id===id))return;
    viewMemory.current.values['world.reading']=false;
    setWorldEntryId(id);setWorldSection('entries');setWorldNavigationRequest(value=>value+1);changeView('worldbuilding');setNavigationEpoch(value=>value+1);
  }
  function openWorldEditor() { if(worldEntryId){editWorldEntry(worldEntryId);return;}setWorldSection('entries');setWorldNavigationRequest(value=>value+1);changeView('worldbuilding'); }

  function closeWorld() { setWorldOpen(false); sceneEditorRef.current?.commands.focus(undefined, { scrollIntoView: false }); }
  function toggleSidebar() {
    setSidebar(!sidebar);
  }
  function restoreDraft() {
    if (!recoverable) return;
    if (recoverable.path) void remember(recoverable.path, recoverable.project, true);
    setActiveView('manuscript'); setWorldEntryId(''); writingScrollPosition.current = 0;
    setProject(recoverable.project); setPath(recoverable.path); setSelectedId(recoverable.selectedId);
    setAutosaveError(''); setDirty(true); setSession(current => current + 1); setRecoverable(null); setRecoveryStatus(t("Recovered draft · Save project to keep it"));
  }
  function update(next: Project, selected = selectedId) { next=pruneBookChapters(next); const entryRelations=removeDeletedEntryRelations(next.entryRelations,state.current.project?.worldbuilding,next.worldbuilding);if(entryRelations!==next.entryRelations)next={...next,entryRelations};const worldbuilding=stampEntryModifications(state.current.project?.worldbuilding,next.worldbuilding,state.current.project?.entryRelations,next.entryRelations);if(worldbuilding!==next.worldbuilding)next={...next,worldbuilding};next=stampPendingDates(state.current.project??undefined,next);state.current.project = next; state.current.dirty = true; setProject(next); setDirty(true); setError(''); setAutosaveError(''); protectDraft(next, selected); }
  function updateVisualResources(worldbuilding:Worldbuilding,maps?:Project['maps']){
    const current=state.current.project;if(current)update({...current,worldbuilding,maps:maps??current.maps});
  }

  function updateSceneById(id:string,patch:Partial<Omit<Scene,'id'>>){const current=state.current.project;if(!current)return;const next=patchScene(current,id,patch);if(next!==current)update(next,id);}
  function updateScene(patch:Partial<Omit<Scene,'id'>>){if(scene)updateSceneById(scene.id,patch);}
  function activateChapterScene(id:string,editor?:Editor){
    const current=editor??chapterEditors.current.get(id);if(current&&!current.isDestroyed){sceneEditorRef.current=current;setChapterActiveEditor(current);}setSelectedId(id);
  }
  function registerChapterEditor(id:string,editor:Editor){chapterEditors.current.set(id,editor);if(id===scene?.id){sceneEditorRef.current=editor;setChapterActiveEditor(editor);}finishAppearanceNavigation(id,editor);}
  function unregisterChapterEditor(id:string,editor:Editor){if(chapterEditors.current.get(id)===editor)chapterEditors.current.delete(id);setChapterActiveEditor(current=>current===editor?null:current);}
  function openChapterPlan(id:string){setManuscriptMode('planning');setSelectedId(id);setFocusMode(false);setToolsOpen(false);setWorldOpen(false);changeView('manuscript');}
  function openChapter(id:string){setManuscriptMode('chapter');setSelectedId(id);setToolsOpen(false);writingScrollPosition.current=0;requestAnimationFrame(()=>{if(writingScrollRef.current)writingScrollRef.current.scrollTop=0;});}
  function changeManuscriptMode(mode:'scene'|'chapter'|'board'|'planning'){setManuscriptMode(mode);if(mode==='board'||mode==='planning'){setFocusMode(false);setToolsOpen(false);setWorldOpen(false);}const id=scene?.id??chapter?.scenes[0]?.id;if(id)setSelectedId(id);if(mode==='chapter'&&id)requestAnimationFrame(()=>document.getElementById(`chapter-scene-${id}`)?.scrollIntoView({block:'start'}));}
  useEffect(()=>{if(manuscriptMode!=='chapter')return;const editor=scene?chapterEditors.current.get(scene.id):undefined;sceneEditorRef.current=editor??null;setChapterActiveEditor(editor??null);},[manuscriptMode,scene?.id,chapter?.id,session]);

  function applySceneMentionCommand(command:MentionCommand){
    const editor=sceneEditorRef.current;if(!editor||editor.isDestroyed)return;
    editor.view.dispatch(editor.state.tr.setMeta(mentionPluginKey,command));
    const data=mentionPluginKey.getState(editor.state);
    updateScene({content:toMarkdown(editor.getJSON()),ignoredMentions:data?.ignored??[],resolvedMentions:data?.resolved??[]});
  }
  function finishAppearanceNavigation(sceneId:string,editor:Editor){
    const destination=appearanceDestination.current;
    if(!destination||destination.sceneId!==sceneId)return;
    requestAnimationFrame(()=>{
      if(appearanceDestination.current!==destination||sceneEditorRef.current!==editor||editor.isDestroyed)return;
      appearanceDestination.current=null;
      jumpToMention(destination);
      if(destination.focus!==false)editor.commands.focus(undefined,{scrollIntoView:false});
    });
  }
  function openDecisionFragment(fragment:DecisionFragment){
    const current=state.current.project;if(!current)return;
    const source=sourceForFragment(fragmentSources(current.worldbuilding??emptyWorld,current.chapters,current.plots),fragment);
    if(!source)return;
    if(fragment.kind==='scene'){const range=fragmentRange(source,fragment);if(range)openEntryAppearance(fragment.targetId,range);else goToScene(fragment.targetId);}
    else {setFragmentRequest({fragment,token:Date.now()});if(fragment.kind==='entry'){openEntryFromMap(fragment.targetId);}else{setPlotId(fragment.targetId);changeView('plots');}}
  }
  function openEntryAppearance(sceneId:string,range:{from:number;to:number},focus=true){
    if(!project?.chapters.some(chapter=>chapter.scenes.some(scene=>scene.id===sceneId)))return;
    goToScene(sceneId);
    appearanceDestination.current={sceneId,...range,focus};
    if(manuscriptMode==='scene'&&scene?.id===sceneId&&sceneEditorRef.current)finishAppearanceNavigation(sceneId,sceneEditorRef.current);
  }
  function jumpToMention(range:{from:number;to:number}){
    const editor=sceneEditorRef.current;if(!editor||editor.isDestroyed||range.from<1||range.to>editor.state.doc.content.size)return;
    editor.chain().setTextSelection(range).run();
    scrollManuscriptRange(editor,writingScrollRef.current,range);
    editor.view.dispatch(editor.state.tr.setMeta(mentionPluginKey,{kind:'flash',...range}));
    clearTimeout(mentionFlashTimer.current);
    mentionFlashTimer.current=setTimeout(()=>{if(!editor.isDestroyed)editor.view.dispatch(editor.state.tr.setMeta(mentionPluginKey,{kind:'clearFlash'}));},1400);
  }

  async function createRevisionCheckpoint(name:string):Promise<{revision:number;path:string}> {
    if (!await save()) throw new Error(t("Save the project to create a revision checkpoint."));
    const current=state.current;
    if (!current.project) throw new Error(t("No project open."));
    const revision=current.project.revision;
    const result=await run(async()=>{await nameCheckpoint(current.path,current.project!.id,revision,name);return true;},t("Saving revision checkpoint…"));
    if(!result)throw new Error(t("The checkpoint could not be named. Your saved version is kept. Try again."));
    return {revision,path:current.path};
  }
  async function recoverHistoricalScene(request:SceneRecoveryRequest):Promise<void>{
    if(!state.current.project)throw new Error(t('No project open.'));
    recoverScene(state.current.project,request); // Validate before creating a safety checkpoint.
    const title=request.source.chapters.flatMap(c=>c.scenes).find(s=>s.id===request.sceneId)?.title||t('Untitled scene');
    await createRevisionCheckpoint(Array.from(t('Before recovering scene: {0}',title)).slice(0,160).join(''));
    const completed=await run(async()=>{
      const current=state.current;
      if(!current.project)throw new Error(t('No project open.'));
      const recovered=recoverScene(current.project,request);
      const saved=await saveProject(current.path,recovered.project);
      state.current={...current,project:saved,dirty:false};
      setProject(saved);setDirty(false);setAutosaveError('');setSession(value=>value+1);
      await clearDraft();remember(current.path,saved,false);setHistoryOpen(false);goToScene(recovered.sceneId);
      return true;
    },t('Recovering scene…'));
    if(!completed)throw new Error(t('Scene recovery could not be completed. The safety checkpoint is available in version history.'));
  }
  async function recoverHistoricalEntry(request:EntryRecoveryRequest):Promise<void>{
    if(!state.current.project)throw new Error(t('No project open.'));
    recoverEntry(state.current.project,request);
    const title=state.current.project.worldbuilding?.entries.find(entry=>entry.id===request.entryId)?.title||t('Untitled entry');
    await createRevisionCheckpoint(Array.from(t('Before recovering entry: {0}',title)).slice(0,160).join(''));
    const completed=await run(async()=>{
      const current=state.current;if(!current.project)throw new Error(t('No project open.'));
      const recovered=recoverEntry(current.project,request),saved=await saveProject(current.path,recovered);
      state.current={...current,project:saved,dirty:false};setProject(saved);setDirty(false);setAutosaveError('');
      await clearDraft();remember(current.path,saved,false);setEntryHistoryId('');openEntryFromMap(request.entryId);
      return true;
    },t('Recovering entry…'));
    if(!completed)throw new Error(t('Entry recovery could not be completed. The safety checkpoint is available in version history.'));
  }
  async function restoreHistoricalVersion(revision: number) {
    if (state.current.dirty && !await save()) throw new Error(t("Save current changes before restoring."));
    const restored = await run(async () => {
      const current = state.current;
      if (!current.project) throw new Error(t("No project open."));
      await clearDraft();
      const result = await restoreVersion(current.path, revision, current.project.revision);
      remember(current.path, result, false);
      state.current = { ...current, project: result, dirty: false };
      setProject(result); setDirty(false); setSession(value => value + 1); setSelectedId(result.chapters[0]?.scenes[0]?.id ?? ''); setWorldEntryId(''); setAutosaveError(''); setHistoryOpen(false);
      return true;
    }, t("Restoring version…"));
    if (!restored) throw new Error(t("Restoration failed. Your current project has been kept; see the error message."));
  }
  async function perform(action: Pending, recentPath?: string, resume?:ProjectResume) {
    recentPath ??= action === 'open' ? pendingRecentPath.current : undefined;
    pendingRecentPath.current = undefined;
    setPending(null); setDeleting(null); setAutosaveError('');
    if (action === 'exit') { await run(async () => { await clearDraft(); clearProjectResume(); await exitApp(); }); return; }
    if (action === 'close') { await run(async () => { await clearDraft(); clearProjectResume(); setProject(null); setPath(''); setDirty(false); }); return; }
    await run(async () => {
      let result;
      try {
        if (action === 'new') {setProjectLoadPhase('creating');result = await createProject(newProject(projectName.trim()), folderName);}
        else if(action==='restore') { setProjectLoadPhase('restoring');const restored=await restoreProjectBackup();if(!restored)return;result=restored; }
        else {
          const folder = recentPath || await chooseFolder(); if (!folder) return;
          setLoadingProject({path:folder,title:openingProjectTitle.current?.path===folder?openingProjectTitle.current.title:recents.find(item=>item.path===folder)?.title??''});
          setProjectLoadPhase('opening');
          // Let React paint immediate card feedback before native loading.
          await new Promise<void>(resolve=>requestAnimationFrame(()=>requestAnimationFrame(()=>resolve())));
          try { result = await openProject(folder,setProjectLoadPhase); }
          catch (e) { setProjectOpenFailure({path:folder,error:message(String(e))});throw new Error(recentPath ? t("Could not open this recent project. Its folder may have moved or be unavailable. Use Open project to locate it, or remove it from the recent list. {0}", String(e)) : String(e)); }
        }
        setLoadingProject({path:result.path,title:result.project.title});
        if(action==='open')setProjectLoadPhase('preparing');
        if(resume&&result.project.id!==resume.projectId){clearProjectResume();throw new Error(t('The project at this location changed. Open it manually.'));}
        await clearDraft();
        await remember(result.path, result.project, true);
        if(action==='restore')setBackupNotice(t("Backup restored into a new folder: {0}", result.path));
        setActiveView(resume?.view??'home'); setWorldEntryId(''); writingScrollPosition.current = 0;
        setDialog(null); setSession(current => current + 1); setProject(result.project); setPath(result.path); setDirty(false); setSelectedId(resume?.selectedId&&result.project.chapters.some(chapter=>chapter.scenes.some(scene=>scene.id===resume.selectedId))?resume.selectedId:result.project.chapters[0]?.scenes[0]?.id ?? '');
        requestAnimationFrame(() => document.getElementById('project-overview-heading')?.focus());
      } finally {setProjectLoadPhase(null);setLoadingProject(null);openingProjectTitle.current=null;}
    },action==='restore' ? t("Restoring backup…") : action==='new'?t("Creating project…"):t("Opening project…"));
  }
  function request(action: Pending, recentPath?: string, browseFolder=false) {
    if (locked.current) return;
    if(action==='open'&&!recentPath&&!browseFolder&&settings?.projectsDirectory){setLocalProjectsOpen(true);return;}
    pendingRecentPath.current = action === 'open' ? recentPath : undefined;
    if (action === 'new') { setError(''); setProjectName(''); setFolderName('project'); setFolderEdited(false); setDialog('new'); return; }
    if (state.current.dirty) setPending(action); else void perform(action);
  }
  function confirmCreate() {
    if (locked.current) return;
    if (state.current.dirty) setPending('new'); else void perform('new');
  }
  async function chooseDefaultDirectory() {
    await run(async () => {
      const directory = await chooseFolder();
      if (directory) setSettings(await setProjectsDirectory(directory));
    });
  }
  async function createBackup() {
    if(locked.current)return;
    if(state.current.dirty && !await save())return;
    await run(async()=>{
      const current=state.current;if(!current.project || !current.path)return;
      const destination=await createProjectBackup(current.path,current.project.id,current.project.revision,backupFilename(current.project.title));
      if(destination)setBackupNotice(t("Backup created and verified: {0}", destination));
    },t("Creating and verifying backup…"));
  }
  function openProjectExport(request:ProjectExportRequest={}){setError('');setExportOpen(request);}
  async function exportWorldEntries(ids:string[]){
    const current=state.current;if(!current.project||!current.path)return false;
    return (await run(async()=>{const packet=createEntryPackage(current.project!.worldbuilding??emptyWorld,ids,current.project!.entryRelations);const filename=templateFilename(current.project!.title).replace('.write-templates.json','.write-entries.json');const destination=await exportEntryPackage(packet,current.path,current.project!.id,filename,language);if(destination)setBackupNotice(t('Entries exported to {0}',destination));return !!destination;},t('Exporting entries…')))===true;
  }
  async function loadWorldEntries(){return (await run(()=>loadEntryPackage(language),t('Reading entries…')))??null;}
  async function importWorldEntries(packet:EntryPackage,ids:string[]){
    const origin=state.current;if(!origin.project||!origin.path)return false;
    return (await run(async()=>{const result=importEntries(origin.project!.worldbuilding??emptyWorld,packet,ids,origin.project!.entryRelations);for(const asset of result.images){if(state.current.project?.id!==origin.project!.id||state.current.path!==origin.path)return false;await storeEntryImage(origin.path,origin.project!.id,asset.id,asset.image,asset.thumbnail);}const latest=state.current.project;if(!latest||latest.id!==origin.project!.id||state.current.path!==origin.path)return false;update({...latest,worldbuilding:result.world,entryRelations:result.entryRelations});setWorldEntryId(result.entryId);setWorldSection('entries');setWorldNavigationRequest(value=>value+1);return true;},t('Importing entries…')))===true;
  }
  async function exportWorldTemplates(ids:string[],all=false) {
    const world=state.current.project?.worldbuilding;if(!world)return false;
    return (await run(async()=>{
      const packet=createTemplatePackage(world,ids);
      const filename=templateFilename(all||ids.length>1?'All':packet.templates.find(template=>template.id===ids[0])?.title || 'templates');
      const exported=await exportTemplatePackage(packet,filename,language);
      if(exported)setBackupNotice(t('Templates exported to {0}',exported));return !!exported;
    },t('Exporting templates…')))===true;
  }
  async function loadWorldTemplates(source:'file'|'project',sourcePath?:string){
    if(locked.current)throw new Error(t('Wait for the current operation to finish, then try again.'));
    return (await run(()=>loadTemplatePackage(source,language,sourcePath),t('Reading templates…'))) ?? null;
  }
  async function createDrawnMap() {
    const current=state.current.project,folder=state.current.path;if(!current||!folder)return;
    return run(async()=>{
      const imageId=await createMapBaseImage(folder,current.id),latest=state.current.project;
      if(!latest||latest.id!==current.id||state.current.path!==folder)return;
      const maps=latest.maps??emptyMaps,map={id:crypto.randomUUID(),title:t('Map {0}',maps.maps.length+1),notes:'',imageId,markers:[]};
      update({...latest,maps:{...maps,maps:[...maps.maps,map]}});setMapId(map.id);setMapMarkerId('');setRouteRequest(undefined);return map.id;
    },t('Creating map…'));
  }
  async function importMapImage(existingId?:string) {
    const current=state.current.project,folder=state.current.path;
    if(!current || !folder)return;
    await run(async()=>{
      const imageId=await importEntryImage(folder,current.id,()=>state.current.project?.id===current.id && state.current.path===folder);
      const latest=state.current.project;
      if(!imageId || !latest || latest.id!==current.id || state.current.path!==folder)return;
      const maps=latest.maps ?? emptyMaps;
      if(existingId){
        if(!maps.maps.some(map=>map.id===existingId))return;
        update({...latest,maps:{...maps,maps:maps.maps.map(map=>map.id===existingId?{...map,imageId,scale:undefined}:map)}});
      }else{
        const map={id:crypto.randomUUID(),title:t("Map {0}", maps.maps.length+1),notes:'',imageId,markers:[]};
        update({...latest,maps:{...maps,maps:[...maps.maps,map]}});setMapId(map.id);setMapMarkerId('');
      }
    },t("Importing map image…"));
  }
  useEffect(()=>{
    const target=searchMatch.current;if(!target||searchOpen||activeView!==(target.kind==='plot'?'plots':'arcs')||document.getElementById(`${activeView}-view`)?.querySelector('[data-panel-loading]'))return;
    let frame=requestAnimationFrame(()=>{frame=requestAnimationFrame(()=>{const element=document.getElementById(`${target.kind}-scene-${target.sceneId}`);if(element){element.scrollIntoView({block:'center',behavior:'instant'});element.focus({preventScroll:true});}searchMatch.current=undefined;});});return()=>cancelAnimationFrame(frame);
  },[activeView,plotId,arcId,searchOpen,session,navigationRevision]);
  function openTextReferenceSource(source:TextReferenceSource){
    if(source.kind==='entry'){openEntryFromMap(source.id);return;}
    if(source.kind==='scenePlan'){goToScene(source.id);setToolsTab('context');setToolsOpen(true);return;}
    if(source.kind==='scene'){if(source.range)openEntryAppearance(source.id,source.range);else goToScene(source.id);setToolsTab('scene');setToolsOpen(true);return;}
    if(source.kind==='chapterPlan'){openChapterPlan(source.id);return;}
    if(source.kind==='chapter'){openChapter(source.id);changeView('manuscript');setToolsTab('chapter');setToolsOpen(true);return;}
    if(source.kind==='arc'){setArcId(source.id);changeView('arcs');return;}
    if(source.kind==='plot'){setPlotId(source.id);changeView('plots');return;}
    if(source.kind==='event'){openTimelineEvent(source.id);return;}
    if(source.kind==='idea'){openRelatedIdea(source.id);return;}
    if(source.kind==='map'){if(source.routeId){setMapId(source.id);setMapMarkerId('');setRouteRequest({mapId:source.id,routeId:source.routeId});changeView('maps');}else openMapLocation(source.id,source.markerId??'');return;}
    if(source.kind==='template'){setWorldTemplateRequest(previous=>({id:source.id,token:(previous?.token??0)+1}));setWorldSection('templates');changeView('worldbuilding');}
  }
  function openRelatedIdea(id:string){const idea=state.current.project?.worldIdeas?.find(item=>item.id===id);Object.assign(viewMemory.current.values,{'pending.section':'ideas','pending.kind':'all','pending.query':'','pending.chapter':'','pending.ideaStatus':idea&&['idea','deciding','decided'].includes(idea.status)?'active':'all'});setPendingIdeaId(id);changeView('pending');setNavigationEpoch(value=>value+1);}
  function beginReview(subject:ReviewSubject,continuityPosition?:WorkspacePosition){
    const origin=captureWorkspaceVisit(),root=document.getElementById(`${activeView}-view`);
    if(root)origin.position.focusFallback={id:root.id,tag:root.tagName,path:[]};
    // Capture before navigation replaces the list or remounts a manuscript panel.
    navigationCurrent.current=origin;
    setReviewTrail({subject,origin,continuityPosition});
  }
  function returnToReview(){
    if(!reviewTrail||!project||locked.current||document.querySelector('dialog[open]'))return;
    if(!prepareLoreNavigation(document.getElementById(`${activeView}-view`)))return;
    const origin=reviewTrail.origin;
    const visit=reviewReturnVisit(project,origin);
    navigationHistory.current=recordWorkspaceVisit(navigationHistory.current,captureWorkspaceVisit());
    restoreWorkspaceVisit(visit);
    continuityReturnPosition.current=reviewTrail.continuityPosition;
    setContinuityOpen(!!reviewTrail.continuityPosition);setReviewTrail(null);
  }
  function dismissActiveReview(){
    const current=state.current.project;if(!current||!reviewTrail||locked.current)return;
    const review=currentReview(current,reviewTrail.subject),issue=review.issue;
    if(!issue||review.status!=='pending')return;
    saveContinuityDismissals(current.id,{...loadContinuityDismissals(current.id),[issue.id]:continuityEvidence(current,issue)});
  }
  function openContinuityFromSummary(){
    Object.assign(viewMemory.current.values,{'continuity.query':'','continuity.kind':'all','continuity.context':'','continuity.dismissed':false});openContinuityReview();
  }
  function openContinuityReview(){continuityReturnPosition.current=undefined;setContinuityOpen(true);}
  function openPendingItem(item:PendingItem){
    if(item.issue){openContinuityIssue(item.issue);return;}
    if(!item.sceneId)return;
    beginReview(item.comment?{kind:'comment',sceneId:item.sceneId,commentId:item.comment.id}:{kind:item.kind==='review'?'review':'develop',sceneId:item.sceneId});
    inspectingSelection.current=item.sceneId!==selectedId;
    const review=item.comment&&project?currentReview(project,{kind:'comment',sceneId:item.sceneId,commentId:item.comment.id}):undefined;
    if(review?.range)openEntryAppearance(item.sceneId,review.range);else goToScene(item.sceneId);
    setWorldOpen(false);setToolsTab('scene');setToolsOpen(true);
  }
  function resolvePendingComment(sceneId:string,commentId:string){
    const current=state.current.project;if(!current)return;
    const target=current.chapters.flatMap(c=>c.scenes).find(s=>s.id===sceneId);
    if(!target?.reviewComments?.some(c=>c.id===commentId&&!c.resolved))return;
    update(patchScene(current,sceneId,{reviewComments:target.reviewComments.map(c=>c.id===commentId?{...c,resolved:true}:c)}));
  }
  function openContinuityIssue(issue:ContinuityIssue,position?:WorkspacePosition){
    const current=state.current.project;if(!current)return;
    const canonical=reviewContinuity(current).find(candidate=>candidate.id===issue.id);
    if(canonical)beginReview(continuityReviewSubject(current,canonical),continuityOpen?position??captureWorkspacePosition(document.getElementById('continuity-review-dialog')):undefined);
    inspectingSelection.current=!!issue.sceneId&&issue.sceneId!==selectedId;
    setContinuityOpen(false);setToolsOpen(false);
    if(issue.kind==='age'&&issue.eventId){openTimelineEvent(issue.eventId);}
    else if(issue.sceneId&&(issue.kind==='travel'||issue.kind==='chronology')){setWorldOpen(false);goToScene(issue.sceneId);setToolsTab('scene');setToolsOpen(true);}
    else if(issue.sceneId){setWorldEntryId('');setWorldOpen(true);if(issue.range)openEntryAppearance(issue.sceneId,issue.range);else goToScene(issue.sceneId);}
    else if(issue.entryId)openEntryFromMap(issue.entryId);
    else if(issue.mapId&&issue.routeId){setMapId(issue.mapId);setMapMarkerId('');setRouteRequest({mapId:issue.mapId,routeId:issue.routeId});changeView('maps');}
    else if(issue.mapId)openMapLocation(issue.mapId,issue.markerId??'');
    else if(issue.eventId){openTimelineEvent(issue.eventId);}
  }
  function resolveReviewMention(sceneId:string,range:{from:number;to:number},entryId:string){const current=state.current.project;if(!current)return;const next=resolveContinuityMention(current,sceneId,range,entryId);if(next!==current)update(next);}
  function openEntryFromMap(id:string){setWorldEntryId(id);setWorldSection('entries');setWorldNavigationRequest(value=>value+1);changeView('worldbuilding');}
  function openMapLocation(id:string,markerId:string){setRouteRequest(undefined);setMapId(id);setMapMarkerId(markerId);changeView('maps');}
  async function importVisualResource(entryId?:string):Promise<string|null> {
    const origin=state.current;if(!origin.project||!origin.path)return null;
    const entry=origin.project.worldbuilding?.entries.find(item=>item.id===entryId);
    const resources=await importVisualImages(origin.path,origin.project.id,()=>state.current.project?.id===origin.project!.id&&state.current.path===origin.path,entry?256-entryImageIds(entry).length:256);
    const latest=state.current.project;
    if(!resources.length||!latest||latest.id!==origin.project.id||state.current.path!==origin.path)return null;
    let world=latest.worldbuilding??emptyWorld;
    for(const resource of resources){world=saveVisualResource(world,{...resource,notes:''});if(entryId)world=attachEntryImage(world,entryId,resource.id);}
    if(entryId)world=mainEntryImage(world,entryId,resources[0].id);
    update({...latest,worldbuilding:world});return resources[0].id;
  }
  async function addEntryImage(entryId:string){await importVisualResource(entryId);}
  async function saveAndContinue() { const action = pending; if (action && await save()) await perform(action); }
  function selectBook(id:string,remembered?:string){
    const current=state.current.project;if(!current?.books?.some(book=>book.id===id))return;
    setSelectedBook(id);setSelectedId(bookSelection(current,id,remembered));setToolsOpen(false);
  }
  function saveBooks(next:Project){
    const current=state.current.project;
    const organized=current?.id===next.id?applyBookOrganization(current,bookOrganization(next,'')):undefined;
    if(!organized)return false;
    const {bookId,selectedId:selection}=bookSelectionAfterOrganization(organized,selectedId,activeBookId);
    update(organized,selection);setSelectedId(selection);setSelectedBook(bookId);setBooksOpen(false);return true;
  }
  function updateBookManuscript(next:Project){if(project)update(mergeBookProject(project,next,activeBookId));}
  function addChapter() {
    if (!project||!manuscriptProject) return;
    const c={id:crypto.randomUUID(),title:t('Chapter {0}',manuscriptChapters.length+1),scenes:[newScene()]};
    update(mergeBookProject(project,{...manuscriptProject,chapters:[...manuscriptChapters,c]},activeBookId),c.scenes[0].id);setSelectedId(c.scenes[0].id);
  }
  function addScene() { if (!project || !chapter) return; const s = { ...newScene(), title: t("Scene {0}", chapter.scenes.length + 1) }; update({ ...project, chapters: project.chapters.map(c => c.id === chapter.id ? { ...c, scenes: [...c.scenes, s] } : c) }, s.id); setSelectedId(s.id); }
  function remove() {
    if (!project || !chapter) return;
    const chapters = deleting === 'chapter' ? project.chapters.filter(c => c.id !== chapter.id) : project.chapters.map(c => c.id === chapter.id ? { ...c, scenes: c.scenes.filter(s => s.id !== selectedId) } : c);
    const remaining=bookChapters({...project,chapters},activeBookId);
    const nextSelection = remaining.find(c => c.id === chapter.id)?.scenes[0]?.id ?? remaining.find(c => c.id === chapter.id)?.id ?? remaining[0]?.scenes[0]?.id ?? remaining[0]?.id ?? '';
    setSelectedBook(activeBookId);
    update({ ...project, chapters }, nextSelection); setSelectedId(nextSelection); setDeleting(null);
  }
  function reorderChapter(direction: -1 | 1) {
    if (!project || !chapter || locked.current) return;
    const moved=manuscriptProject?moveChapter(manuscriptProject,chapter.id,direction):null;
    const next=moved&&moved!==manuscriptProject?mergeBookProject(project,moved,activeBookId):project;
    if (next === project) return;
    update(next); setDeleting(null);
    setAnnouncement(t("Chapter moved to position {0}.", chapterIndex + direction + 1));
  }
  function reorderScene(direction: -1 | 1) {
    if (!project || !scene || locked.current) return;
    const next = moveScene(project, scene.id, direction);
    if (next === project) return;
    update(next); setDeleting(null);
    setAnnouncement(t("Moved to {0} · Scene {1}", chapter?.title || t("Untitled chapter"), sceneIndex + direction + 1));
  }
  function moveToChapter(chapterId: string) {
    if (!project || !scene || locked.current) return;
    const next = transferScene(project, scene.id, chapterId);
    if (next === project) return;
    update(next); setDeleting(null);
    const target = next.chapters.find(c => c.id === chapterId);
    setAnnouncement(t("Moved to {0} · Scene {1}", target?.title || t("Untitled chapter"), (target?.scenes.findIndex(item => item.id === scene.id) ?? -1) + 1));
  }
  return <TextReferenceProvider project={project} onOpenSource={openTextReferenceSource}><div onClickCapture={captureNavigation} onKeyDownCapture={captureNavigation} onScrollCapture={captureNavigationScroll} className={`app-shell${focusActive ? ' focus-mode' : ''}`} style={focusActive ? focusWritingStyle(focusPreferences) : undefined}>
    <header className="app-header" inert={focusActive}><div className="brand"><Feather /><span>Write Studio</span><AppMenu disabled={autosaving || historyOpen || busy || !ready || !!recoverable || recoveryReadError || !!dialog || !!pending} onNew={() => request('new')} onOpen={() => request('open')} onRestore={()=>request('restore')} recents={recents} recentsLoading={recentsLoading} recentsError={message(recentsError)} onRetryRecents={() => { void loadRecents(); }} onOpenRecent={path => request('open', path)} /></div>{project && <div className="compact-project"><IconButton label={t('Project overview')} disabled={busy||historyOpen||recoveryReadError||!ready||!!dialog||!!pending||!!recoverable} onClick={()=>changeView('home')}><House size={16}/></IconButton>{renaming ? <form onSubmit={event => { event.preventDefault(); if (locked.current) return; if (renameValue.trim()) update({ ...project, title: renameValue.trim() }); setRenaming(false); }}><input disabled={busy || historyOpen || !!dialog} aria-label={t("Project title")} value={renameValue} onChange={event => setRenameValue(event.target.value)} onKeyDown={event => { if (event.key === 'Escape') setRenaming(false); }} /><button type="submit" disabled={busy || historyOpen || !!dialog}>{t("Rename")}</button><button type="button" aria-label={t("Cancel rename")} title={t("Cancel rename")} onClick={() => setRenaming(false)}><X size={14} /></button></form> : <ActionMenu label={t("Project actions")} disabled={busy || !!dialog || historyOpen || !!pending || !!recoverable} actions={[
        { label: t("Rename project"), icon: <Pencil size={15} />, onClick: () => { setRenameValue(project.title); setRenaming(true); } },
        { label: t("Save project"), icon: <Save size={15} />, disabled: autosaving || !dirty, onClick: () => { void save(); } },
        { label:buttonLabel('Export…'),icon:<Download size={15}/>,onClick:()=>openProjectExport() },
        { label: buttonLabel("Create backup…"), icon: <Archive size={15}/>, disabled: autosaving || !path, onClick:()=>{void createBackup();} },
        { label: t("Version history"), icon: <History size={15} />, disabled: autosaving, onClick: () => setHistoryOpen(true) },
        { label: buttonLabel("Delete project…"), icon: <Trash2 size={15}/>, danger: true, disabled: autosaving || !path, onClick: () => { void requestProjectDeletion(path, project.id); } },
        { label: t("Close project"), icon: <X size={15} />, disabled: autosaving, onClick: () => request('close') },
      ]}><span className="project-menu-name">{project.title || t("Untitled project")}</span></ActionMenu>}</div>}<div className="header-actions">
      {project && <><IconButton label={t("Search project (⌘⇧F / Ctrl+Shift+F)")} disabled={!project || busy || !ready || !!dialog || !!pending || !!recoverable || historyOpen || recoveryReadError} onClick={() => setSearchOpen(true)}><Search /></IconButton>
      <IconButton label={t("Trash")} disabled={busy || !ready || !!dialog || !!pending || !!recoverable || historyOpen || recoveryReadError} onClick={()=>setTrashOpen(true)}><Trash2/></IconButton>
      <IconButton label={t("Continuity review")} disabled={busy || !ready || !!dialog || !!pending || !!recoverable || historyOpen || recoveryReadError} onClick={openContinuityReview}><ClipboardCheck/></IconButton>
      <IconButton label={t("Save project")} disabled={autosaving || historyOpen || busy || !ready || !!recoverable || recoveryReadError || !!dialog || !dirty} onClick={() => { void save(); }}><Save /></IconButton></>}
      <IconButton label={t("Settings")} disabled={autosaving || historyOpen || busy || !ready || !!recoverable || recoveryReadError || !!dialog} onClick={() => { setError(''); setDialog('settings'); }}><SettingsIcon /></IconButton>
</div></header>
    {error && <div className="error-banner prompt-error" role="alert">{message(error)}</div>}
    {project&&<nav className="workspace-navigation-history" aria-label={t('Workspace navigation')} inert={focusActive}><button type="button" className="icon-button" aria-label={t('Go back')} title={t('Go back')} disabled={busy||!ready||restoringNavigation.current||!navigationHistory.current.past.some(visit=>workspaceRouteExists(project,visit.route))} onClick={()=>navigateWorkspace('back')}><ArrowLeft size={16}/></button><button type="button" className="icon-button" aria-label={t('Go forward')} title={t('Go forward')} disabled={busy||!ready||restoringNavigation.current||!navigationHistory.current.future.some(visit=>workspaceRouteExists(project,visit.route))} onClick={()=>navigateWorkspace('forward')}><ArrowRight size={16}/></button><span>{navigationBackLabel(project)}</span></nav>}
    <fieldset key={`${session}:${navigationEpoch}`} className="project-workspace" inert={historyOpen || busy || !ready || !!pending || !!recoverable || recoveryReadError || !!dialog} disabled={historyOpen || busy || !ready || !!pending || !!recoverable || recoveryReadError || !!dialog}>
      {project ? <>
      <PrimaryNavigation selected={primaryView} onSelect={openPrimary} inactive={focusActive}/>
      {primaryView==='planning'&&<div id="planning-navigation"><PlanningNavigation selected={activeView==='canvas'?'canvas':activeView==='plots'?'plots':activeView==='arcs'?'arcs':'chapters'} onSelect={selectPlanning}/></div>}
      {activeView==='home'&&<section id="home-view" className="project-overview-scroll" aria-label={t('Project overview')}><ProjectOverview project={project} onWorld={()=>openPrimary('worldbuilding')} onPlanning={()=>openPrimary('planning')} onWrite={()=>openPrimary('manuscript')} onPending={()=>openPendingSection('review','comment')} onContinuity={openContinuityFromSummary} onDecisions={()=>openPendingSection('ideas','all','decided')}/></section>}
      {reviewTrail&&activeReview&&!focusActive&&<ReviewFollowup checking={reviewChecking} review={activeReview} returnLabel={reviewTrail.continuityPosition?t('Return to continuity review'):reviewTrail.origin.route.view==='pending'?t('Return to pending items'):reviewTrail.origin.route.view==='manuscript'&&reviewTrail.origin.route.manuscriptMode==='planning'?t('Return to chapter planning'):reviewTrail.origin.route.view==='manuscript'&&reviewTrail.origin.route.toolsOpen?t(reviewTrail.origin.route.toolsTab==='context'?'Return to writing context':'Return to comments'):t('Return to {0}',workspaceVisitLabel(project,reviewTrail.origin.route))} onReturn={returnToReview} onClose={()=>setReviewTrail(null)} onResolve={activeReview.comment&&!activeReview.comment.resolved&&activeReview.sceneId?()=>resolvePendingComment(activeReview.sceneId!,activeReview.comment!.id):undefined} onDismiss={activeReview.issue&&activeReview.status==='pending'?dismissActiveReview:undefined} onOpen={activeReview.range&&activeReview.sceneId&&activeReview.status!=='missing'&&activeReview.status!=='unavailable'?()=>openEntryAppearance(activeReview.sceneId!,activeReview.range!):undefined}/>}
      <div className="workspace" tabIndex={-1} id="manuscript-view" role="tabpanel" aria-labelledby={primaryView==='planning'?'planning-tab':'manuscript-tab'} hidden={activeView !== 'manuscript'}>{sidebar&&manuscriptMode!=='board' && <aside id="manuscript-navigation" className="sidebar" inert={focusActive} style={{ width: sidebarWidth, flexBasis: sidebarWidth }} aria-label={t("Manuscript navigation")}><div className="sidebar-heading"><BookNavigation project={project} bookId={activeBookId} selectedId={selectedId} onSelect={selectBook} onManage={create=>setBooksOpen(create?'create':'manage')} labelAction={<button type="button" className="sidebar-collapse" title={t("Hide sidebar")} aria-label={t("Hide sidebar")} aria-controls="manuscript-navigation" aria-expanded={true} onClick={toggleSidebar}><PanelLeftClose size={15}/></button>} selectorAction={<button type="button" className="nav-create" title={t("New chapter")} aria-label={t("New chapter")} onClick={addChapter}><Plus size={14} /></button>}/></div><ManuscriptNavigation onDeleteScene={id=>{setSelectedId(id);setDeleting('scene');}} key={session} chapters={manuscriptChapters} selectedId={selectedId} onChapter={id=>manuscriptMode==='planning'?setSelectedId(id):openChapter(id)} onChapterTools={id=>inspect('chapter',id)} onScene={id=>{setManuscriptMode('scene');setSelectedId(id);setDeleting(null);}} onSceneTools={id=>inspect('scene',id)} onAddScene={c=>{const next={...newScene(),title:t("Scene {0}", c.scenes.length+1)};update({...project,chapters:project.chapters.map(item=>item.id===c.id ? {...item,scenes:[...item.scenes,next]} : item)},next.id);setSelectedId(next.id);}}/></aside>}{sidebar&&manuscriptMode!=='board' && <SidebarResize width={sidebarWidth} onChange={setSidebarWidth} />}
      <main className="editor-panel"><div className="manuscript-heading" data-mode={manuscriptMode} inert={focusActive}>{(!sidebar||manuscriptMode==='board')&&!focusActive&&<BookNavigation inline labelAction={!sidebar?<IconButton label={t("Show sidebar")} onClick={toggleSidebar}><PanelLeftOpen /></IconButton>:undefined} project={project} bookId={activeBookId} selectedId={selectedId} onSelect={selectBook} onManage={create=>setBooksOpen(create?'create':'manage')}/>}<div className="manuscript-titles">{manuscriptMode!=='board'&&<p className="manuscript-location">{chapter ? t("Chapter {0} · {1}", chapterIndex + 1, chapter.title || t("Untitled chapter")) : t("Manuscript")}</p>}{manuscriptMode==='planning'?<h1 className="manuscript-view-title">{t('Chapter planning')}</h1>:manuscriptMode==='board'?<h1 className="manuscript-view-title">{t('Scene board')}</h1>:manuscriptMode==='chapter'&&chapter?<input className="chapter-title" aria-label={t('Chapter title')} value={chapter.title} onChange={event=>update({...project,chapters:project.chapters.map(item=>item.id===chapter.id?{...item,title:event.target.value}:item)})}/>:scene ? <input className="chapter-title" aria-label={t("Scene title")} value={scene.title} placeholder={t("Untitled scene")} onChange={event => updateScene({ title: event.target.value })} /> : <span>{chapter?.title || t("Your manuscript")}</span>}</div><ManuscriptActions onFind={()=>setManuscriptSearchOpen(true)} commentCount={(manuscriptMode==='chapter'?chapter?.scenes??[]:scene?[scene]:[]).reduce((n,s)=>n+(s.reviewComments?.filter(c=>!c.resolved).length??0),0)} onComments={()=>{setManuscriptCommentsRequest(value=>value+1);setToolsTab(manuscriptMode==='chapter'?'chapter':'scene');setToolsOpen(true);setWorldOpen(false);}} onCheckpoints={()=>setHistoryOpen(true)} mode={manuscriptMode} onMode={changeManuscriptMode} hasChapter={!!chapter} hasScene={!!scene} toolsOpen={toolsOpen} worldOpen={worldOpen} toolsTrigger={toolsTrigger} onAddScene={addScene} onToggleTools={()=>{setToolsTab(scene?'context':'chapter');setWorldOpen(false);setToolsOpen(!toolsOpen);}} onFocus={toggleFocusMode} onToggleWorld={()=>{setToolsOpen(false);setWorldOpen(!worldOpen);}}/></div>
    {manuscriptSearchOpen && activeView==='manuscript' && project && <ManuscriptSearch key={session} bookId={activeBookId} project={project} sceneId={scene?.id} chapterId={chapter?.id} onClose={()=>setManuscriptSearchOpen(false)} onOpen={match=>openEntryAppearance(match.sceneId,match,false)} onReplace={(matches,replacement)=>{
      if(locked.current)throw new Error(t('Project is busy. Try again.'));
      const current=state.current.project;if(!current)return;
      const next=replaceManuscript(current,matches,replacement,manuscriptHistory);
      for(const id of new Set(matches.map(m=>m.sceneId))){
        const editor=chapterEditors.current.get(id)??(scene?.id===id?sceneEditorRef.current:null);
        if(editor&&!editor.isDestroyed){editor.view.dispatch(closeHistory(replacementTransaction(editor.state,matches.filter(m=>m.sceneId===id),replacement)));editor.view.dispatch(closeHistory(editor.state.tr));}
      }
      update(next);
    }}/>}

      {deleting && <ManuscriptDeletionDialog kind={deleting} title={(deleting === 'chapter' ? chapter?.title : scene?.title) || t("Untitled {0}", deleting)} hasTimelineLinks={!!project.timeline?.events.some(event => event.sceneIds.some(id => deleting === 'chapter' ? chapter?.scenes.some(scene => scene.id === id) : id === scene?.id))} onCancel={()=>setDeleting(null)} onConfirm={remove}/>}

      {manuscriptMode==='planning'?<ChapterPlanning embedded fullProject={project} key={`${session}:${activeBookId}`} project={manuscriptProject!} chapterId={chapter?.id??''} onSelectChapter={setSelectedId} onChange={updateBookManuscript} onOpenScene={goToScene} onOpenPlot={id=>{setPlotId(id);changeView('plots');}} onOpenArc={id=>{setArcId(id);changeView('arcs');}} onOpenPending={item=>item.idea?openRelatedIdea(item.idea.id):openPendingItem(item)} onAddScene={addScene} onAddChapter={addChapter}/>:manuscriptMode==='board'?<SceneBoard embedded key={`${session}:${activeBookId}`} onOpenPlot={id=>{setPlotId(id);changeView('plots');}} project={manuscriptProject!} onChange={updateBookManuscript} onOpenScene={goToScene} onAddChapter={addChapter} onAddScene={chapterId=>{const current=state.current.project;const target=current?.chapters.find(c=>c.id===chapterId);if(!current||!target)return;const next={...newScene(),title:t('Scene {0}',target.scenes.length+1)};update({...current,chapters:current.chapters.map(c=>c.id===chapterId?{...c,scenes:[...c.scenes,next]}:c)});}}/>:manuscriptMode==='chapter'&&chapter?<>
        {focusActive&&<FocusModeControls title={chapter.title||t('Untitled chapter')} preferences={focusPreferences} onChange={setFocusPreferences} onExit={toggleFocusMode} onGoals={()=>setGoalsOpen(true)}/>}
        <SceneFormattingToolbar editor={chapterActiveEditor} focused={focusActive} goals={project.writingGoals} manuscriptWords={manuscriptWords} onOpenGoals={()=>setGoalsOpen(true)}/>
        <ChapterManuscript key={`${session}:chapter:${chapter.id}`} chapter={chapter} activeSceneId={scene?.id} scrollRef={writingScrollRef} onActivate={activateChapterScene} onAddScene={addScene} renderScene={item=><SceneEditor history={manuscriptHistory} key={item.id} embedded active={item.id===scene?.id} onReady={registerChapterEditor} onDispose={unregisterChapterEditor} onActivate={activateChapterScene} world={project.worldbuilding??emptyWorld} onOpenEntry={id=>{setWorldEntryId(id);setWorldOpen(true);setFocusMode(false);}} goals={project.writingGoals} manuscriptWords={manuscriptWords} onOpenGoals={()=>setGoalsOpen(true)} focused={false} focusPreferences={focusPreferences} onFocusPreferences={setFocusPreferences} onExitFocus={toggleFocusMode} editorRef={sceneEditorRef} scrollRef={writingScrollRef} scene={item} onChange={(content,ignoredMentions,resolvedMentions,reviewComments)=>updateSceneById(item.id,{content,ignoredMentions,resolvedMentions,reviewComments})}/>}/>
      </>:scene ? <SceneEditor history={manuscriptHistory} onReady={finishAppearanceNavigation} world={project.worldbuilding??emptyWorld} onOpenEntry={id=>{setWorldEntryId(id);setWorldOpen(true);setFocusMode(false);}} goals={project.writingGoals} manuscriptWords={manuscriptWords} onOpenGoals={()=>setGoalsOpen(true)} focused={focusActive} focusPreferences={focusPreferences} onFocusPreferences={setFocusPreferences} onExitFocus={toggleFocusMode} key={`${session}:${scene.id}`} editorRef={sceneEditorRef} scrollRef={writingScrollRef} scene={scene} onChange={(content,ignoredMentions,resolvedMentions,reviewComments) => updateScene({ content,ignoredMentions,resolvedMentions,reviewComments })} /> : <div className="chapter-overview-scroll">{chapter ? <ChapterOverview chapter={chapter} onOpenScene={id => setSelectedId(id)} /> : <div className="empty-state"><h1>{t("Add your first chapter.")}</h1></div>}<button className="primary-button chapter-overview-add" onClick={chapter ? addScene : addChapter}><Plus />{chapter ? t("New scene") : t("New chapter")}</button></div>}</main>      {toolsOpen && chapter && <ManuscriptTools onCommentsHandled={()=>setManuscriptCommentsRequest(0)} commentsRequest={manuscriptCommentsRequest} onOpenMap={(mapId,markerId)=>{setMapLocationRequest({mapId,markerId,token:Date.now()});openMapLocation(mapId,markerId);}} openRequest={toolsOpenRequest} onSceneTitle={title=>updateScene({title})} onTabChange={setToolsTab} project={project} onProjectChange={next=>update(next)} onOpenEvent={openTimelineEvent} onOpenEntry={openEntryFromMap} onOpenScene={goToScene} onOpenChapterPlan={openChapterPlan} onOpenPending={item=>item.idea?openRelatedIdea(item.idea.id):openPendingItem(item)} onOpenArc={id=>{setArcId(id);changeView('arcs');}} worldIdeas={project.worldIdeas} onOpenIdea={openRelatedIdea} maps={project.maps??emptyMaps} onMapsChange={maps=>update({...project,maps})} onOpenRoute={(mapId,routeId)=>{setMapLocationRequest({mapId,routeId,token:Date.now()});setMapId(mapId);setMapMarkerId('');setRouteRequest({mapId,routeId});changeView('maps');}} plots={project.plots??emptyPlots} onPlotsChange={plots=>update({...project,plots})} onOpenPlot={id=>{setPlotId(id);changeView('plots');}} onCommentsChange={(id,reviewComments)=>updateSceneById(id,{reviewComments})} onJumpComment={(id,comment)=>{const subject:ReviewSubject={kind:'comment',sceneId:id,commentId:comment.id};beginReview(subject);const review=currentReview(project,subject);if(review.range)openEntryAppearance(id,review.range);}} inactive={focusActive} initialTab={toolsTab} chapter={chapter} scene={scene} chapters={project.chapters} onWritingStatus={writingStatus => updateScene({ writingStatus })} onSceneSynopsis={synopsis => updateScene({ synopsis })} onChapterSynopsis={synopsis => update({ ...project, chapters: project.chapters.map(item => item.id === chapter.id ? { ...item, synopsis } : item) })} onClose={closeTools} onChapterTitle={title => update({ ...project, chapters: project.chapters.map(item => item.id === chapter.id ? { ...item, title } : item) })} onMoveToChapter={moveToChapter} onMoveChapter={reorderChapter} onMoveScene={reorderScene} onDelete={kind => { setDeleting(kind); closeTools(); }} />}<aside id="scene-world-reference-panel" className="world-panel world-surface" inert={focusActive} aria-label={t("World reference")} hidden={!worldOpen}><WorldPanel chapters={project.chapters} onOpenScene={goToScene} onOpenMention={openEntryAppearance} onJumpToMention={jumpToMention} onMentionCommand={applySceneMentionCommand} projectPath={path} projectId={project.id} key={session} world={project.worldbuilding ?? emptyWorld} scene={scene} onSceneChange={next => updateScene({ entryIds: next.entryIds })} entryId={worldEntryId} onSelectEntry={setWorldEntryId} onOpenEditor={openWorldEditor} onClose={closeWorld} /></aside></div><section className="world-editor world-surface world-workspace" id="worldbuilding-view" role="tabpanel" aria-labelledby="worldbuilding-tab" hidden={activeView !== 'worldbuilding'}><WorldbuildingEditor ideaCanvases={project.ideaCanvases} onResourcesChange={updateVisualResources} onPanelReady={panelReady} deferUntil={activeView!=='worldbuilding'} onMapsChange={maps=>update({...project,maps})} onOpenMaps={()=>changeView('maps')} onWorkspaceChange={refreshWorkspaceNavigation} onEntryHistory={id=>setEntryHistoryId(id)} fragmentRequest={activeView==='worldbuilding'&&fragmentRequest?.fragment.kind==='entry'?fragmentRequest:undefined} onImportVisualResource={()=>importVisualResource()} templateRequest={worldTemplateRequest} worldIdeas={project.worldIdeas} onOpenIdea={openRelatedIdea} saveState={{dirty,busy:autosaving||busy,error:autosaveError}} onRetrySave={save} plots={project.plots} entryRelations={project.entryRelations} onRelationsChange={entryRelations=>update({...project,entryRelations})} onExportEntries={exportWorldEntries} onLoadEntries={loadWorldEntries} onImportEntries={importWorldEntries} onOpenMention={openEntryAppearance} recentProjects={recents} transferError={error} onExportTemplates={async ids=>{openProjectExport({kind:'templates',ids});}} onRequestEntryExport={id=>openProjectExport({kind:'entries',ids:[id]})} onLoadTemplates={loadWorldTemplates} maps={project.maps} onOpenMap={openMapLocation} onImportEntryImage={addEntryImage} projectPath={path} projectId={project.id} timeline={project.timeline} chapters={project.chapters} onOpenScene={goToScene} key={session} world={project.worldbuilding ?? emptyWorld} onChange={worldbuilding => update({ ...project, worldbuilding })} openRequest={worldNavigationRequest} entryId={worldEntryId} setEntryId={setWorldEntryId} tab={worldSection} setTab={setWorldSection} onReturn={() => changeView('manuscript', true)} /></section><section className="timeline-view" id="timeline-view" role="tabpanel" aria-labelledby="timeline-tab" hidden={activeView !== 'timeline'}><TimelineEditor onPanelReady={panelReady} deferUntil={activeView!=='timeline'} active={activeView==='timeline'} openRequest={timelineOpenRequest} onOpenPlot={id=>{setPlotId(id);changeView('plots');}} key={session} project={project} eventId={timelineEventId} onSelectEvent={setTimelineEventId} onChange={timeline => update({ ...project, timeline })} onOpenScene={goToScene} onOpenEntry={id => { setWorldEntryId(id); setWorldSection('entries'); setWorldNavigationRequest(value => value + 1); changeView('worldbuilding'); }} /></section><section className="maps-view world-workspace" id="maps-view" role="tabpanel" aria-labelledby="worldbuilding-tab" hidden={activeView!=='maps'} inert={activeView!=='maps'}><header className="world-module-header world-surface ui-workspace-heading"><h2>{t('World')}</h2><WorldNavigation selected="maps" onSelect={section=>{viewMemory.current.values['world.relationsOpen']=section==='relations'||section==='types';viewMemory.current.values['world.relationSection']=section==='types'?'types':'network';viewMemory.current.values['world.resourcesOpen']=section==='resources';setWorldSection(section==='templates'?'templates':'entries');changeView('worldbuilding');setNavigationEpoch(value=>value+1);}}/></header><MapsEditor ideaCanvases={project.ideaCanvases} onResourcesChange={updateVisualResources} active={activeView==='maps'} locationRequest={mapLocationRequest} onPanelReady={panelReady} deferUntil={activeView!=='maps'} onWorldChange={worldbuilding=>update({...project,worldbuilding})} onEditEntry={editWorldEntry} onCreate={createDrawnMap} routeRequest={routeRequest} onOpenChapter={id=>{openChapter(id);changeView('manuscript');}} chapters={project.chapters} onOpenScene={goToScene} onOpenMention={openEntryAppearance} key={session} maps={project.maps ?? emptyMaps} world={project.worldbuilding ?? emptyWorld} path={path} projectId={project.id} mapId={mapId} markerId={mapMarkerId} onSelectMap={id=>{setRouteRequest(undefined);setMapId(id);}} onSelectMarker={setMapMarkerId} onChange={maps=>update({...project,maps})} onImport={importMapImage} onOpenEntry={openEntryFromMap}/></section><section className="plots-view" id="plots-view" role="tabpanel" aria-labelledby="planning-tab" hidden={activeView!=='plots'} inert={activeView!=='plots'}><PlotsEditor active={activeView==='plots'} deferUntil={activeView!=='plots'} onPanelReady={panelReady} fragmentRequest={activeView==='plots'&&fragmentRequest?.fragment.kind==='plot'?fragmentRequest:undefined} sceneRequest={searchMatch.current?.kind==='plot'?searchMatch.current.sceneId:undefined} onOpenIdea={openRelatedIdea} onOpenEvent={openTimelineEvent} onOpenChapter={id=>{openChapter(id);changeView('manuscript');}} key={session} project={project} plotId={plotId} onSelect={setPlotId} onChange={plots=>update({...project,plots})} onOpenScene={goToScene}/></section><section className="arcs-view" id="arcs-view" role="tabpanel" aria-labelledby="planning-tab" hidden={activeView!=='arcs'} inert={activeView!=='arcs'}><CharacterArcsEditor active={activeView==='arcs'} deferUntil={activeView!=='arcs'} onPanelReady={panelReady} key={session} project={project} arcId={arcId} onSelect={setArcId} onChange={plots=>update({...project,plots})} onOpenEntry={openEntryFromMap} onOpenScene={goToScene}/></section><section className="canvas-view" id="canvas-view" role="tabpanel" aria-labelledby="planning-tab" hidden={activeView!=='canvas'}><IdeaCanvasEditor active={activeView==='canvas'} key={session} deferUntil={activeView!=='canvas'} onPanelReady={panelReady} project={project} path={path} onChange={update}/></section><section className="pending-view"  tabIndex={-1} id="pending-view" role="tabpanel" aria-labelledby="pending-tab" hidden={activeView!=='pending'} inert={activeView!=='pending'}><ProjectPending active={activeView==='pending'} deferUntil={activeView!=='pending'} onPanelReady={panelReady} onReviewContinuity={openContinuityReview} onOpenFragment={openDecisionFragment} ideaId={pendingIdeaId} onCloseIdea={()=>setPendingIdeaId('')} onOpenScene={goToScene} onOpenPlot={id=>{setPlotId(id);changeView('plots');}} key={session} project={project} onSaveIdea={idea=>{const current=state.current.project;if(current)update(saveWorldIdea(current,idea));}} onOpenEntry={openEntryFromMap} onOpen={openPendingItem} onResolveComment={resolvePendingComment} onResolveMention={resolveReviewMention}/></section></> : <WelcomeScreen openingPath={loadingProject?.path} onDelete={recent => { void requestProjectDeletion(recent.path, recent.projectId); }} onRestore={()=>request('restore')} onNew={()=>request('new')} onBrowse={()=>request('open')} projects={recents} loading={recentsLoading} error={message(recentsError)} onOpen={path => { if (!state.current.project && !locked.current) void perform('open', path); }} onForget={path => { void forgetRecent(path); }} onRetry={() => { void loadRecents(); }}  />}
    </fieldset>
    {booksOpen&&project&&<BooksDialog key={session} project={project} bookId={activeBookId} createOnOpen={booksOpen==='create'} onClose={()=>setBooksOpen(false)} onSave={saveBooks}/>}
    {backupNotice && <div className="backup-notice"><span role="status">{backupNotice}</span><button type="button" className="icon-button" aria-label={t("Dismiss project notification")} onClick={()=>setBackupNotice('')}><X size={14}/></button></div>}
    {announcement && <div className="movement-feedback"><span role="status" aria-live="polite" aria-atomic="true">{announcement}</span><button type="button" className="icon-button" aria-label={t("Dismiss notification")} title={t("Dismiss notification")} onClick={() => setAnnouncement('')}><X size={14} /></button></div>}
    <footer className="status-bar"><span title={path}>{path ? t("Folder") : t("No project open")}</span><SaveStatus ready={ready} busy={busy} operation={operation} autosaving={autosaving} error={autosaveError} dirty={dirty} recovery={recoveryStatus} hasProject={!!project} /></footer>
    {exportOpen&&project&&<ProjectExportDialog key={session} onClearError={()=>setError('')} request={exportOpen} project={project} path={path} initialBookId={activeBookId} onExportEntries={exportWorldEntries} onExportTemplates={ids=>exportWorldTemplates(ids,ids.length>1)} onLoadEntries={loadWorldEntries} onImportEntries={importWorldEntries} externalError={error} onClose={()=>setExportOpen(null)}/>}
    {continuityOpen&&project&&<ContinuityReview returnPosition={continuityReturnPosition.current} key={session} project={project} onClose={()=>setContinuityOpen(false)} onOpen={openContinuityIssue} onResolve={resolveReviewMention}/>}
    {trashOpen&&project&&<ProjectTrash key={session} world={project.worldbuilding??emptyWorld} maps={project.maps} ideaCanvases={project.ideaCanvases} projectPath={path} projectId={project.id} onChange={world=>updateVisualResources(world)} onResourcesChange={updateVisualResources} onClose={()=>setTrashOpen(false)}/>}
    {searchOpen && project && <ProjectSearch key={session} project={project} onClose={() => setSearchOpen(false)} onOpen={result => {
      if(navigationCurrent.current)navigationCurrent.current={...navigationCurrent.current,memory:cloneWorkspaceMemory(viewMemory.current)};
      setSearchOpen(false); setToolsOpen(false);
      searchMatch.current=undefined;
      if(result.kind==='plot'){if(result.sceneId)searchMatch.current={kind:'plot',sceneId:result.sceneId};setPlotId(result.id);changeView('plots');}
      else if(result.kind==='arc'){if(result.sceneId)searchMatch.current={kind:'arc',sceneId:result.sceneId};setArcId(result.id);changeView('arcs');}
      else if(result.kind==='idea')openRelatedIdea(result.id);
      else if(result.kind==='pending'&&result.pending)openPendingItem(result.pending);
      else if(result.kind==='map')openMapLocation(result.id,'');
      else if(result.kind==='marker'&&result.mapId)openMapLocation(result.mapId,result.id);
      else if(result.kind==='route'&&result.mapId){setMapId(result.mapId);setMapMarkerId('');setRouteRequest({mapId:result.mapId,routeId:result.id});changeView('maps');}
      else if(result.kind==='scenePlan'){goToScene(result.id);setToolsTab('context');setToolsOpen(true);}
      else if(result.kind==='chapterPlan')openChapterPlan(result.id);
      else if(result.kind==='event'){openTimelineEvent(result.id);}
      else if(result.kind==='chapter'){changeView('manuscript');if(result.synopsis)inspect('chapter',result.id);else openChapter(result.id);}
      else if(result.kind==='scene'){if(result.synopsis){changeView('manuscript');inspect('scene',result.id);}else goToScene(result.id);}
      else if(result.kind==='entry'){setWorldEntryId(result.id);setWorldSection('entries');setWorldNavigationRequest(value=>value+1);changeView('worldbuilding');}
    }} />}
    {goalsOpen && project && <WritingGoalsDialog key={session} goals={project.writingGoals} words={manuscriptWords} onChange={writingGoals=>update({...project,writingGoals})} onClose={()=>{setGoalsOpen(false);if(activeView==='manuscript')requestAnimationFrame(()=>sceneEditorRef.current?.commands.focus(undefined,{scrollIntoView:false}));}}/>}
    {entryHistoryId&&project&&<EntryHistoryDialog key={`${session}:${entryHistoryId}`} project={project} entryId={entryHistoryId} path={path} busy={busy} onRecover={recoverHistoricalEntry} onClose={()=>setEntryHistoryId('')}/>}
    {historyOpen && <VersionHistory onRecoverScene={recoverHistoricalScene} currentProject={project??undefined} onCreate={createRevisionCheckpoint} path={path} currentRevision={project?.revision ?? 0} busy={busy} onClose={() => setHistoryOpen(false)} onRestore={restoreHistoricalVersion} />}
    {localProjectsOpen&&<LocalProjectsDialog directory={settings?.projectsDirectory} onBrowse={settings?.localProjects?undefined:(path)=>{setLocalProjectsOpen(false);request('open',path);}} onClose={()=>setLocalProjectsOpen(false)} onOpen={(path,title)=>{openingProjectTitle.current={path,title};setLocalProjectsOpen(false);request('open',path);}}/>}
    {dialog && !pending && <ProjectDialogs onExport={project?()=>{setDialog(null);openProjectExport();}:undefined} kind={dialog} theme={theme} onTheme={setTheme} settings={settings} busy={busy} error={message(error)} name={projectName} folderName={folderName}
      onName={value => { setProjectName(value); if (!folderEdited) setFolderName(suggestFolderName(value)); }}
      onFolderName={value => { setFolderEdited(true); setFolderName(value); }}
      onChooseDirectory={() => { void chooseDefaultDirectory(); }} onCreate={confirmCreate} onClose={() => { if (!locked.current) { setDialog(null); setError(''); } }} />}
    {!projectLoadPhase&&projectOpenFailure&&<SaveProgressDialog phase="opening" error={projectOpenFailure.error} onClose={()=>setProjectOpenFailure(null)} onRetry={()=>{const path=projectOpenFailure.path;setProjectOpenFailure(null);request('open',path);}}/>}
    {projectLoadPhase&&<ProjectLoadingDialog phase={projectLoadPhase} projectName={loadingProject?.title}/>}
    {saveProgress && <SaveProgressDialog phase={saveProgress.phase} error={saveProgress.error} onClose={()=>setSaveProgress(null)}/>}
    {deletionTarget && <ProjectDeletionDialog target={deletionTarget} busy={busy} error={message(error)} onCancel={()=>{setDeletionTarget(null);setError('');}} onConfirm={value=>{void confirmProjectDeletion(value);}}/>}
    {recoveryReadError && <ProjectModal title={t("Recovery copy could not be read")} busy={busy}><p role="alert">{message(error)}</p><p>{t("Keep the file for manual recovery, or explicitly discard it to continue.")}</p><div className="welcome-actions"><button disabled={busy} onClick={() => { void run(exitApp); }} className="quick-action quick-action-text">{t("Keep and exit")}</button><button className="danger-button" disabled={busy} onClick={() => { void run(async () => { await clearDraft(); setRecoveryReadError(false); }); }}>{t("Discard recovery")}</button></div></ProjectModal>}
    {recoverable && <ProjectModal title={t("Recover unsaved writing?")} busy={busy}><p>{t("A recovery copy of “")}{recoverable.project.title || t("Untitled project")}{t("” is available. Your project files will only change when you save.")}</p>{error && <p role="alert" className="prompt-error">{message(error)}</p>}<div className="welcome-actions"><button className="danger-button" disabled={busy} onClick={() => { void run(async () => { await clearDraft(); setRecoverable(null); }); }}>{t("Discard recovery")}</button><button className="primary-button" disabled={busy} onClick={restoreDraft}>{t("Recover draft")}</button></div></ProjectModal>}
    {pending && <ProjectModal title={t("Save your changes?")} busy={autosaving || historyOpen || busy || !ready || !!recoverable || recoveryReadError} onClose={() => setPending(null)}><p>{t("Unsaved changes will be lost if you discard them.")}</p>{error && <p role="alert" className="prompt-error">{message(error)}</p>}<div className="welcome-actions"><button disabled={autosaving || historyOpen || busy || !ready || !!recoverable || recoveryReadError} onClick={() => setPending(null)} className="quick-action quick-action-text">{t("Cancel")}</button><button className="danger-button" disabled={autosaving || historyOpen || busy || !ready || !!recoverable || recoveryReadError} onClick={() => { void perform(pending); }}>{t("Discard changes")}</button><button className="primary-button" disabled={autosaving || historyOpen || busy || !ready || !!recoverable || recoveryReadError} onClick={() => { void saveAndContinue(); }}>{t("Save")}</button></div></ProjectModal>}
  </div></TextReferenceProvider>;
}
