import { t } from './i18n';
import type { Template, Worldbuilding } from './worldbuilding';
export type TemplatePackage={format:'write-studio-templates';schemaVersion:1;rootTemplateIds:string[];templates:Template[]};
export function requiredTemplates(packet:TemplatePackage,roots:string[]):Template[]{
 const found=new Set<string>(),lookup=new Map(packet.templates.map(template=>[template.id,template]));
 function include(id:string){if(found.has(id))return;const template=lookup.get(id);if(!template)return;found.add(id);for(const field of template.fields)if(field.targetTemplateId)include(field.targetTemplateId);}
 for(const root of roots){if(!lookup.has(root))throw new Error(t('The selected template is no longer available.'));include(root);}
 return packet.templates.filter(template=>found.has(template.id));
}
export function createTemplatePackage(world:Worldbuilding,roots:string[]):TemplatePackage{
 if(!roots.length)throw new Error(t('Select at least one template.'));
 const packet:TemplatePackage={format:'write-studio-templates',schemaVersion:1,rootTemplateIds:[...new Set(roots)],templates:world.templates};
 return {...packet,templates:requiredTemplates(packet,packet.rootTemplateIds)};
}
export function missingTemplateTargets(templates:Template[]):string[]{
 const included=new Set(templates.map(template=>template.id));return [...new Set(templates.flatMap(template=>template.fields.flatMap(field=>field.targetTemplateId&&!included.has(field.targetTemplateId)?[field.targetTemplateId]:[])))];
}
export function importNames(world:Worldbuilding,templates:Template[],overrides:Record<string,string>={}):Record<string,string>{
 const used=new Set(world.templates.map(template=>template.title.trim().toLocaleLowerCase())),names:Record<string,string>={};
 // Reserve explicit names first so automatic suggestions adapt around them.
 for(const template of templates)if(Object.prototype.hasOwnProperty.call(overrides,template.id)){
  const name=overrides[template.id].trim();if(!name)throw new Error(t('Template names cannot be empty.'));
  if(used.has(name.toLocaleLowerCase()))throw new Error(t('A template with this name already exists. Choose another name.'));
  names[template.id]=name;used.add(name.toLocaleLowerCase());
 }
 for(const template of templates)if(!Object.prototype.hasOwnProperty.call(names,template.id)){
  const original=template.title.trim()||t('Untitled template');let name=original,index=1;
  while(used.has(name.toLocaleLowerCase()))name=t('{0} (copy {1})',original,index++);
  names[template.id]=name;used.add(name.toLocaleLowerCase());
 }
 return names;
}
export function importTemplates(world:Worldbuilding,packet:TemplatePackage,roots:string[],overrides:Record<string,string>={}):{world:Worldbuilding;templateId:string;count:number}{
 if(!roots.length)throw new Error(t('Select at least one template.'));
 const templates=requiredTemplates(packet,roots),names=importNames(world,templates,overrides);
 const reserved=new Set(world.templates.flatMap(template=>[template.id,...(template.sections??[]).map(section=>section.id),...template.fields.flatMap(field=>[field.id,...(field.options ?? []).map(option=>option.id)])]).concat(world.entries.map(entry=>entry.id)));
 for(const template of packet.templates){reserved.add(template.id);for(const section of template.sections??[])reserved.add(section.id);for(const field of template.fields){reserved.add(field.id);if(field.targetTemplateId)reserved.add(field.targetTemplateId);for(const option of field.options ?? [])reserved.add(option.id);}}
 function fresh(){let id:string;do{id=crypto.randomUUID();}while(reserved.has(id));reserved.add(id);return id;}
 const ids=new Map(templates.map(template=>[template.id,fresh()]));
 for(const template of templates)for(const section of template.sections??[])ids.set(section.id,fresh());
 for(const missing of missingTemplateTargets(templates))ids.set(missing,fresh());
 const schemaVersion=Math.max(world.schemaVersion,...templates.map(template=>template.schemaVersion)) as Worldbuilding['schemaVersion'];
 const copies=templates.map(template=>({...template,id:ids.get(template.id)!,title:names[template.id],schemaVersion,...(template.sections?{sections:template.sections.map(section=>({...section,id:ids.get(section.id)!}))}:{}),fields:template.fields.map(field=>({...field,id:fresh(),...(field.sectionId?{sectionId:ids.get(field.sectionId)!}:{}),...(field.targetTemplateId?{targetTemplateId:ids.get(field.targetTemplateId)!}:{}),...(field.options?{options:field.options.map(option=>({...option,id:fresh()}))}:{})}))}));
 return {world:{...world,schemaVersion,templates:[...world.templates.map(template=>({...template,schemaVersion})),...copies],entries:world.entries.map(entry=>({...entry,schemaVersion}))},templateId:ids.get(roots[0])!,count:copies.length};
}
export function templateFilename(title:string){
 let safe=title.normalize('NFKC').replace(/[<>:"/\\|?*\u0000-\u001f]/g,'-').replace(/[. ]+$/,'').trim()||'templates';
 safe=Array.from(safe).slice(0,80).join('');
 if(/^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(safe))safe=`template-${safe}`;
 return `${safe}.write-templates.json`;
}
