import {Step} from '@tiptap/pm/transform';
import type {Schema} from '@tiptap/pm/model';
import {Plugin} from '@tiptap/pm/state';
import type {EditorState} from '@tiptap/pm/state';
import type {Editor} from '@tiptap/react';
// Session-only, bounded by scene count. Never persisted with project content.
export class ManuscriptHistory {
 private states=new Map<string,EditorState>();
 remember(id:string,state:EditorState){this.states.delete(id);this.states.set(id,state);if(this.states.size>60)this.states.delete(this.states.keys().next().value!);}
 restore(id:string,state:EditorState):EditorState{
  const previous=this.states.get(id);if(!previous||JSON.stringify(previous.doc.toJSON())!==JSON.stringify(state.doc.toJSON()))return state;
  const old=previous.plugins.find(p=>p.spec.key&&String((p.spec.key as unknown as {key:string}).key).startsWith('history$'));
  const plugin=state.plugins.find(p=>p.spec.key&&String((p.spec.key as unknown as {key:string}).key).startsWith('history$'));
  if(!old||!plugin?.spec.state)return state;
  const value=rebindHistory(old.getState(previous),state.schema);
  const restored=new Plugin({...plugin.spec,state:{...plugin.spec.state,init:()=>value}});
  // Removing first ensures reconfigure initializes the restored history field.
  return state.reconfigure({plugins:state.plugins.filter(p=>p!==plugin)}).reconfigure({plugins:state.plugins.map(p=>p===plugin?restored:p)});
 }
 attach(id:string,editor:Editor){
  editor.view.updateState(this.restore(id,editor.state));
  const remember=()=>this.remember(id,editor.state);remember();editor.on('transaction',remember);
  return ()=>{editor.off('transaction',remember);};
 }
}

// History retains inverse steps with schema-bound slices. Recreate those steps when
// Tiptap mounts a fresh schema, preserving ProseMirror's grouping and bookmarks.
// Keep this adapter covered by cross-schema undo/redo tests when updating Tiptap.
type HistoryItem={step?:Step};
type HistoryBranch={items:{map:(fn:(item:HistoryItem)=>HistoryItem)=>HistoryItem[];slice:(from:number,to:number)=>HistoryBranch['items'];append:(items:HistoryItem[])=>HistoryBranch['items']}};
function rebindHistory(value:{done:HistoryBranch;undone:HistoryBranch},schema:Schema){
 const copy=<T extends object>(object:T,changes:Partial<T>):T=>Object.assign(Object.create(Object.getPrototypeOf(object)),object,changes);
 const branch=(source:HistoryBranch)=>copy(source,{items:source.items.slice(0,0).append(source.items.map(item=>item.step?copy(item,{step:Step.fromJSON(schema,item.step.toJSON())}):item))});
 return copy(value,{done:branch(value.done),undone:branch(value.undone)});
}
