import type {VisualResource} from './visualResources';
import {textReferences,textReferencePlainText} from './textReferenceTokens';
import {longTextPlainText} from './longText';
import { isStoryDate } from './ages';
import { formatStoryDate } from './timeline';
import type { StoryDate } from './timeline';
import { t } from './i18n';
export type FieldType = 'shortText' | 'longText' | 'number' | 'boolean' | 'reference' | 'picklist' | 'multiPicklist' | 'date';
export type PickOption = { id:string; label:string; archived:boolean };
export type Field = { id: string; label: string; fieldType: FieldType; archived: boolean; targetTemplateId?: string; options?:PickOption[]; isBirthDate?:boolean; sectionId?:string; description?:string };
export type TemplateSection = { id:string; title:string };
export type Template = { schemaVersion: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12; id: string; title: string; fields: Field[]; sections?:TemplateSection[] };
export type EntryReference = { entryId: string };
export type EntryValue = string | string[] | number | boolean | EntryReference | StoryDate | null;
export type Entry = { canonStatus?:import('./entryEditorial').CanonStatus; editorialStatus?:import('./entryEditorial').EditorialStatus; schemaVersion: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12; id: string; templateId: string; title: string; modifiedAt?:number;values: Record<string, EntryValue>; archived: boolean; imageId?: string; imageIds?:string[]; linkAliases?: string[] };
export type Worldbuilding = { schemaVersion: 1 | 2 | 3 | 4 | 5 | 6 | 7 | 8 | 9 | 10 | 11 | 12; templates: Template[]; entries: Entry[]; visualResources?:VisualResource[] };
export const emptyWorld: Worldbuilding = { schemaVersion: 1, templates: [], entries: [] };
export const fieldLabels: Record<FieldType, string> = { shortText: 'Short text', longText: 'Long text', number: 'Number', boolean: 'Checkbox', reference: 'Reference', picklist:'Picklist', multiPicklist:'Multi-picklist', date:'Date' };
export function addTemplate(world: Worldbuilding, title: string): { world: Worldbuilding; templateId: string } {
  const template: Template = { schemaVersion: world.schemaVersion, id: crypto.randomUUID(), title: title.trim(), fields: [] };
  return { world: { ...world, templates: [...world.templates, template] }, templateId: template.id };
}
export function updateTemplate(world: Worldbuilding, template: Template): Worldbuilding {
  return { ...world, templates: world.templates.map(item => item.id === template.id ? template : item) };
}
export function addField(world: Worldbuilding, templateId: string, label: string, fieldType: FieldType, targetTemplateId?: string, options?:PickOption[], birthDate=false, sectionId?:string, description?:string): Worldbuilding {
  if (!world.templates.some(t => t.id === templateId)) return world;
  if(sectionId&&!world.templates.find(template=>template.id===templateId)?.sections?.some(section=>section.id===sectionId))return world;
  const base=description?.trim()?enableFieldDescriptions(world):world;
  const updated = sectionId ? enableSections(base) : fieldType==='date' ? enableDates(base) : isPicklist(fieldType) ? enablePicklists(base) : fieldType === 'reference' ? targetTemplateId ? enableReferenceRestrictions(base) : enableReferences(base) : base;
  const template = updated.templates.find(t => t.id === templateId)!;
  const field:Field={...(description?.trim()?{description:description.trim()}:{}),...(sectionId?{sectionId}:{}),id:crypto.randomUUID(),label:label.trim(),fieldType,archived:false,...(isPicklist(fieldType)?{options:options??[]} : {}),...(fieldType==='reference'&&targetTemplateId?{targetTemplateId}:{})};
  const next=updateTemplate(updated,{...template,fields:[...template.fields,field]});
  return fieldType==='date'&&birthDate?setBirthDateField(next,templateId,field.id):next;
}
export function updateField(world: Worldbuilding, templateId: string, fieldId: string, patch: Partial<Pick<Field, 'label' | 'archived' | 'targetTemplateId' | 'options' | 'description'>>): Worldbuilding {
  const current = world.templates.find(t => t.id === templateId)?.fields.find(field => field.id === fieldId);
  if (!current || (patch.targetTemplateId && current.fieldType !== 'reference')) return world;
  const base=patch.description?.trim()?enableFieldDescriptions(world):world;
  const updated = patch.targetTemplateId ? enableReferenceRestrictions(base) : base;
  const template = updated.templates.find(t => t.id === templateId)!;
  return updateTemplate(updated, { ...template, fields: template.fields.map(field => {
    if (field.id !== fieldId) return field;
    const next = { ...field, ...patch };
    if (!next.targetTemplateId) delete next.targetTemplateId;
    if(!next.description?.trim())delete next.description;
    return next;
  }) });
}
export function moveField(world: Worldbuilding, templateId: string, fieldId: string, direction: -1 | 1): Worldbuilding {
  const template = world.templates.find(t => t.id === templateId);
  if (!template) return world;
  const index = template.fields.findIndex(f => f.id === fieldId), next = index + direction;
  if (index < 0 || next < 0 || next >= template.fields.length) return world;
  const fields = [...template.fields];
  [fields[index], fields[next]] = [fields[next], fields[index]];
  return updateTemplate(world, { ...template, fields });
}
export function addEntry(world: Worldbuilding, templateId: string, title: string): { world: Worldbuilding; entryId: string } | null {
  if (!world.templates.some(t => t.id === templateId)) return null;
  const entry: Entry = { schemaVersion: world.schemaVersion, id: crypto.randomUUID(), templateId, title: title.trim(), values: {}, archived: false };
  return { world: { ...world, entries: [...world.entries, entry] }, entryId: entry.id };
}
export function updateEntry(world: Worldbuilding, entry: Entry): Worldbuilding {
  return { ...world, entries: world.entries.map(item => item.id === entry.id ? entry : item) };
}
// Match readable text regardless of accents, Unicode composition or layout whitespace.
function entrySearchText(value:string):string {
  return value.normalize('NFD').replace(/\p{M}/gu,'').toLocaleLowerCase().replace(/\s+/gu,' ').trim();
}
export function searchEntries(world: Worldbuilding, query: string, templateId = '', archived = false, scope:'content'|'name'='content'): Entry[] {
  const search = entrySearchText(query);
  return world.entries.filter(entry => entry.archived === archived && (!templateId || entry.templateId === templateId) && (!search || (scope==='name'?[entry.title]:[entry.title, ...(entry.linkAliases??[]), ...(world.templates.find(template=>template.id===entry.templateId)?.fields ?? []).map(field=>displayFieldValue(field,entry.values[field.id],world))]).some(value => entrySearchText(String(value)).includes(search))));
}

export function isEntryReference(value: EntryValue | undefined): value is EntryReference {
  return typeof value === 'object' && value !== null && 'entryId' in value;
}
export function enableReferences(world: Worldbuilding): Worldbuilding {
  if (world.schemaVersion >= 2) return world;
  return { ...world, schemaVersion: 2, templates: world.templates.map(template => ({ ...template, schemaVersion: 2 })), entries: world.entries.map(entry => ({ ...entry, schemaVersion: 2 })) };
}
export function referenceLabel(world: Worldbuilding, id: string): string {
  const target = world.entries.find(entry => entry.id === id);
  return target ? `${target.title || t("Untitled entry")}${target.archived ? t(" · Archived") : ''}` : t("Missing entry");
}
export function referenceChoices(world: Worldbuilding, query: string, targetTemplateId?: string): { value: string; label: string }[] {
  const search = query.trim().toLocaleLowerCase();
  const labels = world.entries.filter(entry => !entry.archived && (!targetTemplateId || entry.templateId === targetTemplateId)).map(entry => ({ value: entry.id, label: `${entry.title || t("Untitled entry")} · ${world.templates.find(template => template.id === entry.templateId)?.title || t("Untitled template")}` }));
  const counts = new Map<string, number>();
  for (const option of labels) counts.set(option.label, (counts.get(option.label) ?? 0) + 1);
  return [{ value: '', label: t("None") }, ...labels.filter(option => !search || option.label.toLocaleLowerCase().includes(search)).map(option => ({ ...option, label: (counts.get(option.label) ?? 0) > 1 ? `${option.label} · ${option.value}` : option.label }))];
}

export function enableReferenceRestrictions(world: Worldbuilding): Worldbuilding {
  if (world.schemaVersion >= 3) return world;
  return { ...world, schemaVersion: 3, templates: world.templates.map(template => ({ ...template, schemaVersion: 3 })), entries: world.entries.map(entry => ({ ...entry, schemaVersion: 3 })) };
}
export function referenceReviewMessage(world: Worldbuilding, targetTemplateId?: string, reference?: EntryReference | null): string | null {
  if (!targetTemplateId) return null;
  const allowed = world.templates.find(template => template.id === targetTemplateId);
  if (!allowed) return t("Needs review · Allowed template is missing.");
  const target = world.entries.find(entry => entry.id === reference?.entryId);
  return target && target.templateId !== targetTemplateId ? t("Needs review · Expected {0}.", allowed.title || t("Untitled template")) : null;
}
export function referenceReviewCount(world: Worldbuilding, templateId: string, field: Field): number {
  return world.entries.filter(entry => {
    const value = entry.values[field.id];
    return entry.templateId === templateId && isEntryReference(value) && referenceReviewMessage(world, field.targetTemplateId, value);
  }).length;
}

// Archived entries also prevent deleting their template.
export function templateEntryCount(world: Worldbuilding, templateId: string): number {
  return world.entries.filter(entry => entry.templateId === templateId).length;
}
export function deleteTemplate(world: Worldbuilding, templateId: string): Worldbuilding {
  if (templateEntryCount(world, templateId) || !world.templates.some(template => template.id === templateId)) return world;
  return { ...world, templates: world.templates.filter(template => template.id !== templateId) };
}
export function deleteEntry(world: Worldbuilding, entryId: string): Worldbuilding {
  if (!world.entries.some(entry => entry.id === entryId)) return world;
  return { ...world, entries: world.entries.filter(entry => entry.id !== entryId) };
}
export function incomingEntryLinks(world: Worldbuilding, entryId: string): string[] {
  return world.entries.filter(entry => entry.id !== entryId).flatMap(entry =>
    Object.entries(entry.values).flatMap(([fieldId, value]) => (isEntryReference(value) && value.entryId === entryId || typeof value==='string'&&textReferences(value).some(ref=>ref.entryId===entryId))
      ? [`${entry.title || t("Untitled entry")}${entry.archived ? t(" · Archived") : ''} / ${world.templates.find(template => template.id === entry.templateId)?.fields.find(field => field.id === fieldId)?.label || t("Untitled field")}`] : []));
}

/** Move a field to a final index without modifying values or field identities. */
export function reorderField(world: Worldbuilding, templateId: string, fieldId: string, index: number): Worldbuilding {
 const template=world.templates.find(item=>item.id===templateId);
 const from=template?.fields.findIndex(field=>field.id===fieldId) ?? -1;
 if(!template || from<0 || !Number.isInteger(index) || index<0 || index>=template.fields.length || from===index) return world;
 const fields=[...template.fields]; const [field]=fields.splice(from,1);fields.splice(index,0,field);
 return updateTemplate(world,{...template,fields});
}

export function setEntryImage(world: Worldbuilding, entryId: string, imageId?: string): Worldbuilding {
 if (!world.entries.some(entry=>entry.id===entryId)) return world;
 const upgraded:Worldbuilding=imageId && world.schemaVersion<4 ? {...world,schemaVersion:4,templates:world.templates.map(template=>({...template,schemaVersion:4})),entries:world.entries.map(entry=>({...entry,schemaVersion:4}))} : world;
 return {...upgraded,entries:upgraded.entries.map(entry=>{if(entry.id!==entryId)return entry;const next={...entry};if(imageId)next.imageId=imageId;else delete next.imageId;return next;})};
}

export function isPicklist(type:FieldType){return type==='picklist' || type==='multiPicklist';}
export function enablePicklists(world:Worldbuilding):Worldbuilding {
 return world.schemaVersion>=5 ? world : {...world,schemaVersion:5,templates:world.templates.map(item=>({...item,schemaVersion:5})),entries:world.entries.map(item=>({...item,schemaVersion:5}))};
}
export function displayFieldValue(field:Field,value:EntryValue|undefined,world?:Worldbuilding):string {
 if(field.fieldType==='date')return isStoryDate(value)?formatStoryDate(value):'—';
 if(isPicklist(field.fieldType)) {
  const ids=Array.isArray(value)?value:typeof value==='string'?[value]:[];
  return ids.map(id=>{const option=field.options?.find(item=>item.id===id);return option?`${option.label}${option.archived?t(" · Archived"):''}`:t("Missing option");}).join(', ');
 }
 if(field.fieldType==='longText'&&typeof value==='string')return longTextPlainText(value)||'—';
 if(isEntryReference(value))return world?referenceLabel(world,value.entryId):t("Linked entry");
 if(value===null || value===undefined || value==='')return '—';
 return typeof value==='boolean'?(value?t("Yes"):t("No")):typeof value==='string'?textReferencePlainText(value):String(value);
}

function fieldHasValue(field:Field,value:EntryValue|undefined):boolean {
 if(value===undefined||value===null)return false;
 if(typeof value==='string')return !!(field.fieldType==='longText'?longTextPlainText(value):value).trim()||textReferences(value).length>0;
 if(Array.isArray(value))return value.length>0;
 // Zero, false, dates and references are explicit values, including missing targets.
 return true;
}
export function fieldUsageCount(world:Worldbuilding,templateId:string,fieldId:string):number {
 const field=world.templates.find(template=>template.id===templateId)?.fields.find(field=>field.id===fieldId);
 if(!field)return 0;
 return world.entries.filter(entry=>entry.templateId===templateId&&fieldHasValue(field,entry.values[fieldId])).length;
}
export function deleteField(world:Worldbuilding,templateId:string,fieldId:string):Worldbuilding {
 const template=world.templates.find(template=>template.id===templateId);
 if(!template||!template.fields.some(field=>field.id===fieldId)||fieldUsageCount(world,templateId,fieldId))return world;
 const updated=updateTemplate(world,{...template,fields:template.fields.filter(field=>field.id!==fieldId)});
 // Native storage rejects orphan value keys, even when their values are empty.
 let changed=false;
 const entries=world.entries.map(entry=>{
  if(entry.templateId!==templateId||!Object.prototype.hasOwnProperty.call(entry.values,fieldId))return entry;
  const values={...entry.values};delete values[fieldId];changed=true;return {...entry,values};
 });
 return changed?{...updated,entries}:updated;
}

export function enableDates(world:Worldbuilding):Worldbuilding {
 return world.schemaVersion>=6?world:{...world,schemaVersion:6,templates:world.templates.map(template=>({...template,schemaVersion:6})),entries:world.entries.map(entry=>({...entry,schemaVersion:6}))};
}
export function setBirthDateField(world:Worldbuilding,templateId:string,fieldId?:string):Worldbuilding {
 const template=world.templates.find(template=>template.id===templateId);
 if(!template||(fieldId&&!template.fields.some(field=>field.id===fieldId&&field.fieldType==='date')))return world;
 const updated=enableDates(world),current=updated.templates.find(template=>template.id===templateId)!;
 return updateTemplate(updated,{...current,fields:current.fields.map(field=>{const {isBirthDate:_,...rest}=field;return field.id===fieldId?{...rest,isBirthDate:true}:rest;})});
}

export function enableSections(world:Worldbuilding):Worldbuilding {
 return world.schemaVersion>=7?world:{...world,schemaVersion:7,templates:world.templates.map(template=>({...template,schemaVersion:7})),entries:world.entries.map(entry=>({...entry,schemaVersion:7}))};
}

/** Link aliases belong to the entry, independently of user-defined fields. */
export function setEntryLinkAliases(world:Worldbuilding,entryId:string,aliases:string[]):Worldbuilding {
 if(!world.entries.some(entry=>entry.id===entryId))return world;
 const seen=new Set<string>(),clean=aliases.map(alias=>alias.trim()).filter(alias=>{const key=alias.normalize('NFC').toLocaleLowerCase();if(!key||seen.has(key))return false;seen.add(key);return true;});
 const upgraded:Worldbuilding=clean.length&&world.schemaVersion<8?{...world,schemaVersion:8,templates:world.templates.map(template=>({...template,schemaVersion:8})),entries:world.entries.map(entry=>({...entry,schemaVersion:8}))}:world;
 return {...upgraded,entries:upgraded.entries.map(entry=>{if(entry.id!==entryId)return entry;const next={...entry};if(clean.length)next.linkAliases=clean;else delete next.linkAliases;return next;})};
}

export function enableFieldDescriptions(world:Worldbuilding):Worldbuilding {
 return world.schemaVersion>=9?world:{...world,schemaVersion:9,templates:world.templates.map(template=>({...template,schemaVersion:9})),entries:world.entries.map(entry=>({...entry,schemaVersion:9}))};
}

export function entryCopyName(world:Worldbuilding,entry:Entry):string {
 const used=new Set(world.entries.filter(item=>item.templateId===entry.templateId).map(item=>item.title.trim().toLocaleLowerCase()));
 const original=entry.title.trim()||t('Untitled entry');let number=1,name:string;
 do{name=t('{0} (copy {1})',original,number++);}while(used.has(name.toLocaleLowerCase()));
 return name;
}
export function duplicateEntry(world:Worldbuilding,entryId:string,title:string,copyLinkAliases=false):{world:Worldbuilding;entryId:string}|null {
 const source=world.entries.find(entry=>entry.id===entryId);
 if(!source||!title.trim()||!world.templates.some(template=>template.id===source.templateId))return null;
 const copy:Entry={...source,id:crypto.randomUUID(),schemaVersion:world.schemaVersion,title:title.trim(),archived:false,values:structuredClone(source.values),...(source.imageIds?{imageIds:[...source.imageIds]}:{})};
 if(copyLinkAliases&&source.linkAliases?.length)copy.linkAliases=[...source.linkAliases];else delete copy.linkAliases;
 return {world:{...world,entries:[...world.entries,copy]},entryId:copy.id};
}

// Safe widening only: stable IDs, references, archives and all entry values are retained.
export function convertToLongText(world:Worldbuilding,templateId:string,fieldId:string):Worldbuilding{
 const template=world.templates.find(item=>item.id===templateId);
 if(!template?.fields.some(field=>field.id===fieldId&&field.fieldType==='shortText'))return world;
 return updateTemplate(world,{...template,fields:template.fields.map(field=>field.id===fieldId?{...field,fieldType:'longText'}:field)});
}
