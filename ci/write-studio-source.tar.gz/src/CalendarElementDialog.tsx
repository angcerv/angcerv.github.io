import {useId,useState} from 'react';
import ProjectModal from './ProjectModal';
import Dropdown from './Dropdown';
import {calendarElementPatch,newCalendarElementDraft} from './calendarElementDraft';
import type {CalendarElementDraft,CalendarElementRequest} from './calendarElementDraft';
import type {StoryCalendar} from './storyCalendar';
import {t,message} from './i18n';
export default function CalendarElementDialog({calendar,request,onSave,onClose}:{calendar:StoryCalendar;request:CalendarElementRequest;onSave:(patch:Partial<StoryCalendar>)=>void;onClose:()=>void}){
 const id=useId(),[draft,setDraft]=useState(()=>newCalendarElementDraft(calendar,request)),[error,setError]=useState('');
 const {kind,index}=request,recurring=kind==='seasons'||kind==='holidays';
 const titles={months:['Add month','Edit month'],weekdays:['Add weekday','Edit weekday'],eras:['Add era','Edit era'],seasons:['Add season','Edit season'],holidays:['Add holiday','Edit holiday']};
 function change(key:keyof CalendarElementDraft,value:string){setDraft({...draft,[key]:value});setError('');}
 function number(key:keyof CalendarElementDraft,label:string,min:number,max:number,disabled=false){return <label className="ui-form-field">{t(label)}<input type="number" min={min} max={max} step={1} disabled={disabled} value={draft[key]} onChange={event=>change(key,event.target.value)}/></label>;}
 return <ProjectModal title={t(titles[kind][index===undefined?0:1])} className="calendar-element-dialog" onClose={onClose}><form noValidate onSubmit={event=>{event.preventDefault();event.stopPropagation();try{onSave(calendarElementPatch(calendar,request,draft));}catch(reason){setError(message(String(reason)));}}}><label className="ui-form-field" htmlFor={`${id}-name`}>{t('Name')}<input id={`${id}-name`} maxLength={80} value={draft.name} onChange={event=>change('name',event.target.value)} aria-describedby={error?`${id}-error`:undefined}/></label>
 {kind==='months'&&<>{number('days','Days',1,1000,calendar.mode==='gregorian')}{calendar.mode==='fixed'&&index!==undefined&&<p className="field-hint">{t('Changing month lengths may invalidate season or holiday dates. Review them before saving the calendar.')}</p>}</>}
 {kind==='eras'&&number('startYear','First world year',-999999,999999)}
 {recurring&&<><label className="ui-form-field">{t(kind==='holidays'?'Month':'Starting month')}<Dropdown id={`${id}-month`} aria-label={t(kind==='holidays'?'Holiday month':'Season starting month')} value={draft.month} options={calendar.months.map((month,i)=>({value:String(i+1),label:month.name}))} onChange={value=>change('month',value)}/></label>{number('day',kind==='holidays'?'Day':'Starting day',1,(calendar.months[Number(draft.month)-1]?.days??1000)+Number(kind==='holidays'&&calendar.mode==='gregorian'&&Number(draft.month)===2))}{kind==='holidays'&&number('duration','Duration (days)',1,calendar.months.reduce((sum,month)=>sum+month.days,0))}</>}
 {(recurring||kind==='eras')&&<label className="ui-form-field">{t('Description (optional)')}<textarea rows={3} maxLength={4000} value={draft.description} onChange={event=>change('description',event.target.value)}/></label>}
 {error&&<p className="prompt-error" role="alert" id={`${id}-error`}>{error}</p>}<footer className="welcome-actions"><button type="button" onClick={onClose} className="quick-action quick-action-text">{t('Cancel')}</button><button type="submit" className="primary-button">{t(index===undefined?'Add':'Save changes')}</button></footer></form></ProjectModal>;
}
