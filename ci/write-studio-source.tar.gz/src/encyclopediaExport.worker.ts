import {encyclopediaImageData,exportEncyclopedia} from './encyclopediaExport';
import {setLanguage} from './i18n';
import type {Language} from './i18n';
import type {Project} from './model';
import type {EncyclopediaOptions,EncyclopediaFormat} from './encyclopediaExport';
self.onmessage=async({data}:{data:{project:Project;options:EncyclopediaOptions;format:EncyclopediaFormat;images:Record<string,Blob>;language:Language}})=>{
 try{
  setLanguage(data.language);
  const images=data.format==='html'?await encyclopediaImageData(data.project,data.options,async id=>{if(!data.images[id])throw new Error('Missing image');return data.images[id];}):{};
  self.postMessage({source:exportEncyclopedia(data.project,data.options,data.format,images)});
 }catch(error){self.postMessage({error:error instanceof Error?error.message:String(error)});}
};
