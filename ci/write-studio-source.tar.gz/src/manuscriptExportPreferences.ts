export type ManuscriptExportPreferences={
 format:'docx'|'md';sceneTitles:boolean;coverPage:boolean;chapterPageBreaks:boolean;
 font:'georgia'|'times'|'arial';fontSize:11|12|14;lineSpacing:1|1.5|2;paperSize:'a4'|'letter';margins:'standard'|'compact'|'wide';
};
export const defaultManuscriptExportPreferences:ManuscriptExportPreferences={format:'docx',sceneTitles:true,coverPage:false,chapterPageBreaks:true,font:'georgia',fontSize:12,lineSpacing:1.5,paperSize:'a4',margins:'standard'};
export function normalizeManuscriptExportPreferences(value:unknown):ManuscriptExportPreferences{
 const source=value&&typeof value==='object'&&!Array.isArray(value)?value as Record<string,unknown>:{};
 const defaults=defaultManuscriptExportPreferences;
 return {
  format:source.format==='md'?'md':'docx',
  sceneTitles:typeof source.sceneTitles==='boolean'?source.sceneTitles:defaults.sceneTitles,
  coverPage:typeof source.coverPage==='boolean'?source.coverPage:defaults.coverPage,
  chapterPageBreaks:typeof source.chapterPageBreaks==='boolean'?source.chapterPageBreaks:defaults.chapterPageBreaks,
  font:source.font==='times'||source.font==='arial'?source.font:'georgia',
  fontSize:source.fontSize===11||source.fontSize===14?source.fontSize:12,
  lineSpacing:source.lineSpacing===1||source.lineSpacing===2?source.lineSpacing:1.5,
  paperSize:source.paperSize==='letter'?'letter':'a4',
  margins:source.margins==='compact'||source.margins==='wide'?source.margins:'standard',
 };
}
const key=(id:string)=>`write-studio.manuscript-export.${id}`;
const sessionPreferences=new Map<string,ManuscriptExportPreferences>();
export function loadManuscriptExportPreferences(id:string):ManuscriptExportPreferences{
 if(sessionPreferences.has(id))return {...sessionPreferences.get(id)!};
 try{const stored=JSON.parse(localStorage.getItem(key(id))??'null');return normalizeManuscriptExportPreferences(stored?.version===1?stored.options:null);}catch{return {...defaultManuscriptExportPreferences};}
}
export function storeManuscriptExportPreferences(id:string,value:ManuscriptExportPreferences){
 const options=normalizeManuscriptExportPreferences(value);
 sessionPreferences.delete(id);sessionPreferences.set(id,options);
 if(sessionPreferences.size>50)sessionPreferences.delete(sessionPreferences.keys().next().value!);
 try{localStorage.setItem(key(id),JSON.stringify({version:1,options}));}catch{/* Keep the selected layout usable during this session. */}
}
