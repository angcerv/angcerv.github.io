import {VisualResourceDetails} from './VisualLibrary';
import {EntryStatuses} from './EntryEditorialControl';
import {ReferenceText} from './TextReferenceUI';
import EntryUsageSummary from './EntryUsageSummary';
import {LongTextView} from './LongTextEditor';
import FieldHelp from './FieldHelp';

import type { Chapter } from './model';
import type { MentionCommand } from './manuscriptMentions';
import SceneReferences from './SceneReferences';
import EntrySection from './EntrySection';
import { fieldGroups } from './templateSections';
import { isStoryDate } from './ages';
import { formatStoryDate } from './timeline';
import { t } from './i18n';
import { displayFieldValue } from './worldbuilding';
import { EntryPortrait } from './EntryImage';
import type { Scene } from './model';
import Dropdown from './Dropdown';
import { useEffect, useRef, useState } from 'react';
import SceneEntries from './SceneEntries';
import { ArrowUpRight, ArrowLeft, X, Plus, Unlink } from 'lucide-react';
import { searchEntries, isEntryReference, referenceLabel } from './worldbuilding';
import type { EntryValue, Worldbuilding } from './worldbuilding';
import { linkSceneEntry, unlinkSceneEntry } from './sceneLinks';
import { ReferenceLink } from './EntryReference';

export function displayValue(value: EntryValue | undefined, world?: Worldbuilding): string {
  if (isStoryDate(value))return formatStoryDate(value);
  if (isEntryReference(value)) return world ? referenceLabel(world, value.entryId) : t("Linked entry");
  if (value === undefined || value === null || value === '') return '—';
  if (typeof value === 'boolean') return value ? t("Yes") : t("No");
  return Array.isArray(value)?value.join(', '):String(value);
}
// World values are read-only; the optional callback only changes scene associations.
export default function WorldPanel({ projectPath, projectId, world, scene, onSceneChange, onJumpToMention,onMentionCommand,chapters=[],onOpenScene,onOpenMention, entryId, onSelectEntry, onOpenEditor, onClose }: {
  chapters?:Chapter[];onOpenScene?:(id:string)=>void;onOpenMention?:(sceneId:string,range:{from:number;to:number})=>void;onJumpToMention?:(range:{from:number;to:number})=>void;onMentionCommand?:(command:MentionCommand)=>void;projectPath?:string; projectId?:string; onSceneChange?: (scene: Scene) => void; scene?: Scene; world: Worldbuilding; entryId: string; onSelectEntry: (id: string) => void; onOpenEditor: () => void; onClose: () => void;
}) {
  const scroll = useRef<HTMLDivElement>(null);
  const listScroll = useRef(0);
  const listFocus = useRef('');
  const backButton = useRef<HTMLButtonElement>(null);
  const [linking, setLinking] = useState(false);
  const [query, setQuery] = useState('');
  const [filter, setFilter] = useState('');
  const [history, setHistory] = useState<string[]>([]);
  const availableHistory = history.filter(id => world.entries.some(entry => entry.id === id));
  const entries = searchEntries(world, query, world.templates.some(template => template.id === filter) ? filter : '');
  const entry = world.entries.find(item => item.id === entryId);
  const template = world.templates.find(item => item.id === entry?.templateId);
  useEffect(() => {
    const container=scroll.current;if(!container)return;
    const detail=container.querySelector<HTMLElement>('.world-reference-detail');
    if(entry&&detail)container.scrollTop+=detail.getBoundingClientRect().top-container.getBoundingClientRect().top-12;
    else container.scrollTop=listScroll.current;
  }, [entryId]);
  function selectEntry(id: string) { listFocus.current=id; listScroll.current = scroll.current?.scrollTop ?? 0; setHistory([]); onSelectEntry(id); requestAnimationFrame(() => backButton.current?.focus({ preventScroll: true })); }
  function returnToList() { setHistory([]); onSelectEntry(''); requestAnimationFrame(() => {const previous=Array.from(scroll.current?.querySelectorAll<HTMLElement>('[data-reference-id]')??[]).find(button=>button.dataset.referenceId===listFocus.current);(previous??scroll.current?.querySelector<HTMLInputElement>('input[type="search"]'))?.focus({preventScroll:true});}); }
  function followReference(id: string) { if (id === entryId) return; setHistory(previous => [...previous, entryId]); onSelectEntry(id); requestAnimationFrame(() => backButton.current?.focus({ preventScroll: true })); }
  function goBack() { const id = availableHistory[availableHistory.length - 1]; if (!id) return; setHistory(availableHistory.slice(0, -1)); onSelectEntry(id); }
  return <>
    <div className="world-heading"><h2>{t("Worldbuilding")}</h2><button type="button" className="icon-button ui-close-button" aria-label={t("Return to writing")} title={t("Return to writing")} onClick={onClose}><X /></button></div>
    <div ref={scroll} className="world-scroll world-reference-content">
      {linking && scene && onSceneChange ? <><button type="button" onClick={() => setLinking(false)}><ArrowLeft size={14} />{t("Linked entries")}</button><SceneEntries key={scene.id} scene={scene} world={world} onChange={onSceneChange} onOpen={id => { setLinking(false); selectEntry(id); }} /></> : <>
      {!entry&&scene&&<SceneReferences selectedEntryId={entryId} key={scene.id} onJump={onJumpToMention} onCommand={onMentionCommand} scene={scene} world={world} onChange={onSceneChange} onOpen={selectEntry} onLink={()=>setLinking(true)}/>}
      {!entry && <>
      <label className="visually-hidden" htmlFor="reference-search">{t("Search world reference")}</label><input id="reference-search" type="search" placeholder={t("Search entries…")} value={query} onChange={event => setQuery(event.target.value)} />
      <label id="reference-template-filter-label" className="visually-hidden" htmlFor="reference-template-filter">{t("Filter world reference by template")}</label><Dropdown id="reference-template-filter" aria-labelledby="reference-template-filter-label" value={world.templates.some(template => template.id === filter) ? filter : ''} onChange={setFilter} options={[{ value: '', label: t("All templates") }, ...world.templates.map(item => ({ value: item.id, label: item.title || t("Untitled template") }))]} />
      <div className="world-entry-list" aria-label={t("Reference entries")}>{entries.map(item => <button key={item.id} data-reference-id={item.id} type="button" className={item.id === entryId ? 'selected' : ''} aria-pressed={item.id === entryId} onClick={() => selectEntry(item.id)}><span>{item.title || t("Untitled entry")}</span><small>{world.templates.find(t => t.id === item.templateId)?.title || t("Untitled template")}</small></button>)}{entries.length === 0 && <p className="world-hint">{query || filter ? t("No matching entries.") : t("Create templates and entries in the Worldbuilding tab.")}</p>}</div>
      </>}
      {entry && template && <section className="world-reference-detail" aria-label={t("Reference entry")}><div className="reference-detail-navigation"><button ref={backButton} type="button" className="reference-back" onClick={returnToList}><ArrowLeft size={14} />{t("All references")}</button>{availableHistory.length > 0 && <button type="button" className="reference-back" onClick={goBack}>{t("Previous entry")}</button>}</div><EntryPortrait key={entry.id} projectPath={projectPath} projectId={projectId} imageId={entry.imageId} title={entry.title || t("Untitled entry")}/>{world.visualResources?.find(resource=>resource.id===entry.imageId)&&<VisualResourceDetails compact resource={world.visualResources.find(resource=>resource.id===entry.imageId)!} resources={world.visualResources}/>}<h3>{entry.title || t("Untitled entry")}</h3><div className="entry-status-controls"><EntryStatuses entry={entry}/></div><p className="world-hint">{template.title || t("Untitled template")}{entry.archived&&<> · <span className="semantic-status" data-semantic-tone="neutral">{t("Archived entry")}</span></>}</p><div className="world-reference-sections">{fieldGroups(template,true).filter(group=>group.fields.length).map((group,index)=><EntrySection defaultOpen={index===0} key={group.id} title={group.title} count={group.fields.length}><dl>{group.fields.map(field => { const value = entry.values[field.id]; return <div key={field.id}><dt><span className="entry-field-label">{field.label || t("Untitled field")}<FieldHelp label={field.label||t("Untitled field")} description={field.description}/></span></dt><dd>{isEntryReference(value) ? <ReferenceLink world={world} reference={value} onNavigate={followReference} targetTemplateId={field.targetTemplateId} /> : field.fieldType==='longText'&&typeof value==='string'&&value?<LongTextView value={value}/>:typeof value==='string'&&field.fieldType==='shortText'?<ReferenceText value={value}/>:displayFieldValue(field,value,world)}</dd></div>; })}</dl></EntrySection>)}</div><EntryUsageSummary chapters={chapters} world={world} entryId={entry.id} onOpenScene={onOpenScene} onOpenMention={onOpenMention}/></section>}
      <div className="world-consultation-actions">{entry && scene && onSceneChange && <button type="button" className="world-link-toggle" onClick={() => {
        const ids = scene.entryIds ?? [];
        onSceneChange(ids.includes(entry.id) ? unlinkSceneEntry(scene, entry.id) : linkSceneEntry(scene, world, entry.id));
      }} disabled={!scene.entryIds?.includes(entry.id) && entry.archived}>{scene.entryIds?.includes(entry.id) ? <><Unlink size={14} />{t("Unlink from scene")}</> : <><Plus size={14} />{t("Link to scene")}</>}</button>}
      <button type="button" className="world-open-editor" onClick={onOpenEditor}><ArrowUpRight size={15} />{entry ? t("Edit entry") : t("Open Worldbuilding")}</button></div>
      </>}
    </div>
  </>;
}
