import {openWhenAvailable} from './projectOpen';
import { invoke } from '@tauri-apps/api/core';
import type { OpenProject, Project } from './model';
import type {EntryPackage} from './entryTransfer';
import { fromMarkdown } from './model';
import {ensureVisualResourceSchema} from './visualResources';
export const chooseFolder = () => invoke<string | null>('choose_folder');
export async function openProject(path: string,onProgress?:(phase:'opening'|'downloading')=>void): Promise<OpenProject> {
  const result = await openWhenAvailable({check:()=>invoke<'ready'|'downloading'>('prepare_project_open',{path}),open:()=>invoke<OpenProject>('open_project', { path }),onProgress});
  for (const chapter of result.project.chapters) for (const scene of chapter.scenes) fromMarkdown(scene.content);
  return result;
}
export const saveProject = (path: string, project: Project, automatic=false) => {
 const worldbuilding=project.worldbuilding?ensureVisualResourceSchema(project.worldbuilding):undefined;
 return invoke<Project>('save_project', { path, project:worldbuilding!==project.worldbuilding?{...project,worldbuilding}:project, automatic });
};
export const exitApp = () => invoke('exit_app');

export type Settings = { schemaVersion: 1; projectsDirectory: string | null; localProjects?:boolean; externalProjects?:boolean };
export const readSettings = () => invoke<Settings>('read_settings');
export const setProjectsDirectory = (directory: string) => invoke<Settings>('set_projects_directory', { directory });
export const createProject = (project: Project, folderName: string) => invoke<OpenProject>('create_project', { project, folderName });

export type ProjectVersion = { revision: number; savedAt: number; title: string; checkpointName?: string | null };
export const listVersions = (path: string) => invoke<ProjectVersion[]>('list_versions', { path });
export async function readVersion(path: string, revision: number): Promise<Project> {
  const project = await invoke<Project>('read_version', { path, revision });
  for (const chapter of project.chapters) for (const scene of chapter.scenes) fromMarkdown(scene.content);
  return project;
}
export const restoreVersion = (path: string, revision: number, expectedRevision: number) => invoke<Project>('restore_version', { path, revision, expectedRevision });

export type RecentProject = { path: string; projectId: string; title: string; lastOpened: number };
export const readRecentProjects = () => invoke<RecentProject[]>('read_recent_projects');
export const rememberRecentProject = (path: string, project: Project, opened: boolean) => invoke<RecentProject[]>('remember_recent_project', { path, title: project.title, projectId: project.id, opened });
export const forgetRecentProject = (path: string) => invoke<RecentProject[]>('forget_recent_project', { path });

export const saveManuscriptExport = (filename: string, format: 'docx' | 'md' | 'html', bytes: Uint8Array) => invoke<string | null>('export_manuscript', { filename, format, bytes: Array.from(bytes) });

export const createProjectBackup = (path:string,projectId:string,revision:number,filename:string) => invoke<string|null>('create_project_backup',{path,projectId,revision,filename});
export async function restoreProjectBackup():Promise<OpenProject|null> {
 const result=await invoke<OpenProject|null>('restore_project_backup');
 if(result)for(const chapter of result.project.chapters)for(const scene of chapter.scenes)fromMarkdown(scene.content);
 return result;
}

export type ProjectDeletionTarget = { path:string; projectId:string; title:string; revision:number };
export const inspectProjectDeletion = (path:string) => invoke<ProjectDeletionTarget>('inspect_project_deletion',{path});
export const deleteProject = (target:ProjectDeletionTarget,confirmation:string) => invoke<{warning:string}>('delete_project',{target,confirmation});

export const loadTemplatePackage = (source:'file'|'project',language:string,path?:string) => invoke<import('./templateTransfer').TemplatePackage|null>('load_template_package',{source,path:path ?? null,language});
export const exportTemplatePackage = (packet:import('./templateTransfer').TemplatePackage,filename:string,language:string) => invoke<string|null>('export_template_package',{package:packet,filename,language});

export const nameCheckpoint = (path:string,projectId:string,revision:number,name:string) => invoke<void>('name_checkpoint',{path,projectId,revision,name});

export const saveMapExport = (filename: string, bytes: Uint8Array) => invoke<string | null>('export_manuscript', { filename, format: 'png', bytes: Array.from(bytes) });

export const saveTextExport = (filename:string,format:'md'|'html',text:string) => invoke<string|null>('export_manuscript',{filename,format,text});

export const saveEncyclopediaPackage = (filename:string,path:string,projectId:string,html:string,imageIds:string[]) => invoke<string|null>('export_encyclopedia',{filename,path,projectId,html,imageIds});

export const loadEntryPackage = (language:string) => invoke<EntryPackage|null>('load_entry_package',{language});
export const exportEntryPackage = (packet:EntryPackage,path:string,projectId:string,filename:string,language:string) => invoke<string|null>('export_entry_package',{package:packet,path,projectId,filename,language});

export const listLocalProjects = () => invoke<RecentProject[]>('list_local_projects');
