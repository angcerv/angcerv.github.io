import {useEffect,useMemo,useState} from 'react';
import {previewSvgSource,rasterizeSvgPreview} from './mapRasterPreview';
export function useSvgPreview(source:string,width:number,height:number,pixels=2_000_000){
 const [cached,setCached]=useState<{source:string;pixels:number;url:string}|null>(null);
 useEffect(()=>{
  if(!source)return;let disposed=false,owned:string|undefined;const controller=new AbortController();
  void rasterizeSvgPreview(source,width,height,controller.signal,pixels).then(url=>{if(!url)return;if(disposed){URL.revokeObjectURL(url);return;}owned=url;setCached({source,pixels,url});});
  return()=>{disposed=true;controller.abort();if(owned)URL.revokeObjectURL(owned);};
 },[source,width,height,pixels]);
 return cached?.source===source&&cached.pixels===pixels?cached.url:source;
}
/** Terrain is decorative; symbols/handles remain native interactive SVG above it. */
export default function MapTerrainPreview({markup,patterns,width,height,pixels}:{markup:string;patterns:string;width:number;height:number;pixels:number}){
 const source=useMemo(()=>markup?previewSvgSource(patterns+markup,width,height,pixels):'',[markup,patterns,width,height,pixels]);
 const url=useSvgPreview(source,width,height,pixels);
 return url?<image href={url} x={0} y={0} width={width} height={height} pointerEvents="none"/>:null;
}
