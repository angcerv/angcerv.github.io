import { invoke } from '@tauri-apps/api/core';
import { fromMarkdown } from './model';
import type { Project } from './model';
export type Draft = { project: Project; path: string; selectedId: string };
export async function readDraft(): Promise<Draft | null> {
  const draft = await invoke<Draft | null>('read_draft');
  if (draft) for (const c of draft.project.chapters) for (const s of c.scenes) fromMarkdown(s.content);
  return draft;
}
// One writer, with intermediate pending snapshots coalesced. Null is an explicit discard.
export class RecoveryWriter {
  private pending: Draft | null | undefined;
  private running: Promise<void> | undefined;
  constructor(private write: (draft: Draft | null) => Promise<void>) {}
  enqueue(draft: Draft | null): Promise<void> {
    this.pending = draft;
    if (!this.running) this.running = Promise.resolve().then(() => this.drain());
    return this.running;
  }
  private async drain() {
    try {
      while (this.pending !== undefined) {
        const snapshot = this.pending;
        this.pending = undefined;
        try { await this.write(snapshot); }
        catch (error) {
          // A newer draft (or explicit discard) may already be queued while a
          // provider/disk write fails. Drain it before reporting the outcome.
          // Never retry the same failed snapshot without a new request.
          if (this.pending === undefined) throw error;
        }
      }
    } finally { this.running = undefined; }
  }
}
export const recoveryWriter = new RecoveryWriter(draft => invoke('write_draft', { draft }));
