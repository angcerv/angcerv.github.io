import {BookOpen,ClipboardList,LibraryBig,CalendarDays,ListTodo} from 'lucide-react';
import {primaryWorkspaces} from './workspaceStructure';
import type {PrimaryWorkspace} from './workspaceStructure';
import {t,buttonLabel} from './i18n';
export default function PrimaryNavigation({selected,onSelect,inactive=false}:{selected:PrimaryWorkspace|'home';onSelect:(view:PrimaryWorkspace)=>void;inactive?:boolean}){
 return <div className="workspace-tabs" inert={inactive} role="tablist" aria-label={t('Project views')} onKeyDown={event=>{
  if(event.defaultPrevented||event.nativeEvent.isComposing||!['ArrowLeft','ArrowRight','Home','End'].includes(event.key))return;
  event.preventDefault();const focused=(event.target as HTMLElement).closest<HTMLButtonElement>('[data-workspace]')?.dataset.workspace;
  const index=Math.max(0,primaryWorkspaces.indexOf((focused??selected) as PrimaryWorkspace)),next=event.key==='Home'?primaryWorkspaces[0]:event.key==='End'?primaryWorkspaces[primaryWorkspaces.length-1]:primaryWorkspaces[(index+(event.key==='ArrowLeft'?-1:1)+primaryWorkspaces.length)%primaryWorkspaces.length];
  onSelect(next);event.currentTarget.querySelector<HTMLButtonElement>(`#${next}-tab`)?.focus();
 }}>{([{id:'manuscript',label:'Manuscript',Icon:BookOpen},{id:'planning',label:'Story planning',Icon:ClipboardList},{id:'worldbuilding',label:'World',Icon:LibraryBig},{id:'timeline',label:'Timeline',Icon:CalendarDays},{id:'pending',label:'Pending',Icon:ListTodo}] as const).map(({id,label,Icon})=><button type="button" key={id} id={`${id}-tab`} data-workspace={id} role="tab" aria-selected={selected===id} aria-controls={id==='planning'?'manuscript-view plots-view arcs-view':id==='worldbuilding'?'worldbuilding-view maps-view':`${id}-view`} tabIndex={selected===id||selected==='home'&&id==='manuscript'?0:-1} onClick={()=>onSelect(id)}><Icon size={16}/>{buttonLabel(label)}</button>)}</div>;
}
