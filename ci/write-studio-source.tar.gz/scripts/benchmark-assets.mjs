// Reuse existing PNGs unchanged. This builds metadata, never image pixels.
const id=value=>`00000000-0000-0000-0000-${value.toString(16).padStart(12,'0')}`;
export function withBenchmarkAssets(original,sourceNames){
 if(!sourceNames.length)throw Error('Existing PNG sources are required.');
 const project=structuredClone(original),assets=Array.from({length:200},(_,i)=>({id:id(40000+i),source:sourceNames[i%sourceNames.length]}));
 project.worldbuilding.visualResources=assets.map((asset,i)=>({id:asset.id,title:`Existing icon ${i}`,notes:'Benchmark resource copied without changes.'}));
 project.worldbuilding.entries=project.worldbuilding.entries.map((entry,i)=>({...entry,imageId:assets[i].id,imageIds:[assets[i].id,assets[(i+1)%assets.length].id]}));
 const scenes=project.chapters.flatMap(chapter=>chapter.scenes);
 project.maps={schemaVersion:17,maps:Array.from({length:20},(_,i)=>{
  const layers=[{id:id(90000+i*2),title:'Places',visible:true},{id:id(90001+i*2),title:'Routes',visible:true}];
  const markers=Array.from({length:100},(_,j)=>({id:id(60000+i*100+j),title:`Place ${j}`,notes:'Synthetic map annotation.',x:(j%10+.5)/10,y:(Math.floor(j/10)+.5)/10,color:'teal',icon:'city',entryId:project.worldbuilding.entries[j%200].id,layerId:layers[0].id}));
  return {id:id(50000+i),title:`Synthetic map ${i}`,notes:'Existing icon reused as the background; not a geographic image.',imageId:assets[i].id,layers,markers,
   routes:Array.from({length:10},(_,j)=>({id:id(70000+i*10+j),title:`Route ${j}`,notes:'Synthetic route.',color:'teal',markerIds:markers.slice(j*10,j*10+10).map(marker=>marker.id),sceneIds:[scenes[(i*10+j)%scenes.length].id],layerId:layers[1].id})),
   regions:Array.from({length:10},(_,j)=>({id:id(80000+i*10+j),title:`Region ${j}`,color:'teal',points:[{x:.02+j*.09,y:.02},{x:.08+j*.09,y:.02},{x:.08+j*.09,y:.08},{x:.02+j*.09,y:.08}],entryId:project.worldbuilding.entries[j].id,layerId:layers[0].id}))};
 })};
 return {project,assets};
}
