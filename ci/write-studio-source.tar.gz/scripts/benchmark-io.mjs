// End-to-end domain/file measurements; never starts Tauri, a browser or a picker.
import assert from 'node:assert/strict';
import {mkdtemp,writeFile,rm,readFile,readdir,copyFile} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
import {spawn} from 'node:child_process';
import {performance} from 'node:perf_hooks';
import {withBenchmarkAssets} from './benchmark-assets.mjs';
import {createBenchmarkProject} from './benchmark-fixture.mjs';
import {loadLocal} from '../tests/load-local.mjs';
const {exportManuscript}=loadLocal('../src/manuscriptExport.ts');
const {exportEncyclopedia,defaultEncyclopediaOptions,encyclopediaPackageImages}=loadLocal('../src/encyclopediaExport.ts');
const args=process.argv.slice(2),release=args.includes('--release'),withAssets=args.includes('--assets'),counts=args.filter(value=>!['--release','--assets'].includes(value));
if(counts.length>1)throw Error('Usage: node scripts/benchmark-io.mjs [scenes] [--release] [--assets]');
const count=Number(counts[0]??1000);
if(!Number.isInteger(count)||count<1||count>10000)throw Error('Use a scene count between 1 and 10000.');
const root=dirname(dirname(fileURLToPath(import.meta.url))),scratch=await mkdtemp(join(tmpdir(),'write-studio-benchmark-input-'));
function summary(samples){const sorted=[...samples].sort((a,b)=>a-b);return {samplesMs:samples.map(value=>+value.toFixed(3)),medianMs:+sorted[Math.floor(sorted.length/2)].toFixed(3),maxMs:+sorted.at(-1).toFixed(3)};}
try{
 let project=createBenchmarkProject(count),assets=[],assetBytes=0,thumbnailBytes=0,sourceNames=[],imageData={};
 if(withAssets){
  sourceNames=(await readdir(join(root,'src-tauri/icons'))).filter(name=>name.endsWith('.png')).sort();
  ({project,assets}=withBenchmarkAssets(project,sourceNames));
  for(let i=0;i<sourceNames.length;i++)await copyFile(join(root,'src-tauri/icons',sourceNames[i]),join(scratch,`source-${i}.png`));
  await copyFile(join(root,'src-tauri/icons/128x128.png'),join(scratch,'thumbnail.png'));
  thumbnailBytes=(await readFile(join(scratch,'thumbnail.png'))).length*assets.length;
  const sources=new Map();for(const name of sourceNames)sources.set(name,await readFile(join(root,'src-tauri/icons',name)));
  for(const asset of assets){const bytes=sources.get(asset.source);assetBytes+=bytes.length;imageData[asset.id]=`data:image/png;base64,${bytes.toString('base64')}`;}
  await writeFile(join(scratch,'assets.json'),JSON.stringify(assets.map(asset=>({id:asset.id,source:`source-${sourceNames.indexOf(asset.source)}.png`}))));
 }
 const before=JSON.stringify(project),chapters=project.chapters.map(chapter=>chapter.id);
 const options={...defaultEncyclopediaOptions(project),images:withAssets};
 await writeFile(join(scratch,'encyclopedia.images.json'),JSON.stringify(encyclopediaPackageImages(project,options).map(image=>image.id)));
 await writeFile(join(scratch,'project.json'),before);
 const preparation={};
 for(const [name,generate] of [['manuscript.md',()=>exportManuscript(project,chapters,'md')],['manuscript.docx',()=>exportManuscript(project,chapters,'docx')],['encyclopedia.html',()=>exportEncyclopedia(project,options,'html',imageData)],['encyclopedia.zip.html',()=>exportEncyclopedia(project,options,'zip')]]){
  const samples=[];let result;
  for(let i=0;i<3;i++){const start=performance.now();result=generate();samples.push(performance.now()-start);}
  const bytes=typeof result==='string'?Buffer.from(result):result;
  assert(bytes.byteLength>0);preparation[name]={...summary(samples),bytes:bytes.byteLength};
  await writeFile(join(scratch,name),bytes);
 }
 assert.equal(JSON.stringify(project),before,'Export preparation must not mutate the project');
 // Use native modules via an ignored Rust test, with no production command/API changes.
 const result=await new Promise((resolve,reject)=>{
  const child=spawn('cargo',['test',...(release?['--release']:[]),'--manifest-path','src-tauri/Cargo.toml','--lib','benchmark::project_io','--','--ignored','--exact','--nocapture'],{cwd:root,env:{...process.env,WRITE_STUDIO_BENCH_INPUT:scratch},stdio:['ignore','pipe','pipe']});
  let stdout='';child.stdout.on('data',chunk=>stdout+=chunk);child.stderr.on('data',chunk=>process.stderr.write(chunk));
  child.on('error',reject);child.on('close',code=>code===0?resolve(stdout):reject(Error(`Native benchmark failed (${code}):\n${stdout}`)));
 });
 const line=result.split('\n').find(line=>line.startsWith('BENCHMARK_JSON:'));assert(line,'Missing native results');
 const disk=Object.fromEntries(Object.entries(JSON.parse(line.slice('BENCHMARK_JSON:'.length))).map(([name,samples])=>[name,summary(samples)]));
 console.log(JSON.stringify({fixture:{scenes:count,entries:200,ideas:100,projectJsonBytes:Buffer.byteLength(before),images:assets.length,uniqueSourceFiles:sourceNames.length,imageBytes:assetBytes,thumbnailBytes,maps:project.maps?.maps.length??0,markers:project.maps?.maps.reduce((sum,map)=>sum+map.markers.length,0)??0,routes:project.maps?.maps.reduce((sum,map)=>sum+map.routes.length,0)??0,regions:project.maps?.maps.reduce((sum,map)=>sum+map.regions.length,0)??0},environment:{node:process.version,platform:process.platform,arch:process.arch,rustProfile:release?'release (optimized)':'test (debug, unoptimized)'},limits:[withAssets?'200 logical assets reuse existing small app icons unchanged; no high-resolution images, canvas drawings or long-lived history.':'Synthetic text-only fixture; no images, maps or long-lived history.','Export preparation and disk writes are measured separately, excluding IPC and worker startup.','Filesystem caches are not cleared. Compilation, fixtures, assertions and cleanup are outside measured intervals.','Initial save and asset import have one sample; other operations have three sequential samples. No timing pass/fail thresholds.'],preparation,disk},null,2));
}finally{await rm(scratch,{recursive:true,force:true});}
