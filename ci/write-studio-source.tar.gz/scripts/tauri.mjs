import { spawn } from 'node:child_process';
import { createRequire } from 'node:module';
const require = createRequire(import.meta.url);
const args = process.argv.slice(2);
// Writing sessions should not restart when development files change.
if (args[0] === 'dev' && process.env.WRITE_STUDIO_LIVE_RELOAD !== '1' && !args.includes('--no-watch')) args.push('--no-watch');
const child = spawn(process.execPath, [require.resolve('@tauri-apps/cli/tauri.js'), ...args], { stdio: 'inherit' });
child.on('error', error => { console.error(error); process.exitCode = 1; });
child.on('exit', code => { process.exitCode = code ?? 1; });
