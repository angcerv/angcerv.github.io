import assert from 'node:assert/strict';
import {readFileSync,readdirSync,statSync} from 'node:fs';
import {resolve,dirname,join} from 'node:path';
import ts from 'typescript';

// Inspect the actual emitted module graph without launching an app or browser.
const dist=resolve('dist'),html=readFileSync(join(dist,'index.html'),'utf8');
const entry=html.match(/<script[^>]*src="([^"]+)"/)?.[1];
assert(entry?.startsWith('/assets/'),'Run npm run build first to produce the local entry module.');
const entryFile=join(dist,entry.slice(1)),initial=new Set();
function visit(file){
 if(initial.has(file))return;
 initial.add(file);
 const ast=ts.createSourceFile(file,readFileSync(file,'utf8'),ts.ScriptTarget.ESNext,true,ts.ScriptKind.JS);
 for(const node of ast.statements){
  if(!(ts.isImportDeclaration(node)||ts.isExportDeclaration(node))||!node.moduleSpecifier||!ts.isStringLiteral(node.moduleSpecifier))continue;
  const id=node.moduleSpecifier.text;
  if(id.startsWith('.'))visit(resolve(dirname(file),id));
 }
}
visit(entryFile);
const assets=join(dist,'assets'),files=readdirSync(assets).filter(file=>file.endsWith('.js'));
const deferred=['IdeaCanvasEditor','BooksDialog','MapsEditor','TimelineEditor','WorldbuildingEditor','PlotsEditor','CharacterArcsEditor','ProjectPending','EncyclopediaExportDialog','PlanningExportDialog','ExportDialog','VersionHistory','EntryHistoryDialog'];
for(const name of deferred){
 const file=files.find(file=>file.startsWith(name+'-'));
 assert(file,`${name} must have a separate local chunk.`);
 assert(!initial.has(join(assets,file)),`${name} must not be in the initial module graph.`);
}
const sizes=files.map(file=>statSync(join(assets,file)).size);
assert(Math.max(...sizes)<=500000,'A JavaScript chunk exceeds the default 500 kB build warning threshold.');
const kb=bytes=>(bytes/1000).toFixed(1);
console.log(`Bundle verified: ${kb([...initial].reduce((sum,file)=>sum+statSync(file).size,0))} kB initial JavaScript, ${kb(statSync(entryFile).size)} kB entry, ${kb(Math.max(...sizes))} kB largest chunk; ${deferred.length} panels remain deferred.`);
