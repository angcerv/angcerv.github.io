// Synthetic data only; IDs satisfy native project validation.
const id=value=>`00000000-0000-0000-0000-${value.toString(16).padStart(12,'0')}`;
export function createBenchmarkProject(count){
 const entries=Array.from({length:200},(_,i)=>({id:id(1000+i),schemaVersion:11,templateId:id(100),title:`Person${i}`,archived:false,values:{[id(101)]:'A fictional character.'}}));
 const scenes=Array.from({length:count},(_,i)=>({id:id(100000+i),title:`Scene ${i}`,content:Array.from({length:30},()=>`Person${i%200} crosses the harbor and meets Person${(i+1)%200} beside the old tower.`).join(' '),synopsis:'An encounter at the harbor.',writingStatus:i%5===0?'inReview':'draft',entryIds:[id(1000+i%200)]}));
 return {schemaVersion:1,id:id(1),title:'Synthetic project',revision:0,chapters:Array.from({length:Math.ceil(count/20)},(_,i)=>({id:id(10000+i),title:`Chapter ${i}`,scenes:scenes.slice(i*20,(i+1)*20)})),worldbuilding:{schemaVersion:11,templates:[{schemaVersion:11,id:id(100),title:'People',fields:[{id:id(101),label:'Description',fieldType:'shortText',archived:false}]}],entries},worldIdeas:Array.from({length:100},(_,i)=>({id:id(20000+i),title:`Idea ${i}`,description:'An optional development.',status:'idea',category:'worldbuilding',entryIds:[id(1000+i%200)],sceneIds:[id(100000+i%count)]}))};
}
