// Synthetic domain benchmark: no browser, app, project files or image generation.
import {createBenchmarkProject} from './benchmark-fixture.mjs';
import {performance} from 'node:perf_hooks';
import {loadLocal} from '../tests/load-local.mjs';
const {projectPendingItems}=loadLocal('../src/pendingItems.ts');
const {projectSummary}=loadLocal('../src/projectSummary.ts');
const {indexProjectTextReferences}=loadLocal('../src/textReferenceIndex.ts');
const {reviewContinuity}=loadLocal('../src/continuity.ts');
const count=Number(process.argv[2]??500);
if(!Number.isInteger(count)||count<1||count>10000)throw Error('Use a scene count between 1 and 10000.');

function measure(run){const start=performance.now();run();return performance.now()-start;}
const operations=[['Summary',projectSummary],['Reference index',indexProjectTextReferences],['Continuity',reviewContinuity],['All pending',projectPendingItems],['Ideas only',project=>projectPendingItems(project,'ideas')]];
const results=[];
for(const [operation,run] of operations){
 // Each first run has a separate immutable project to avoid identity-cache reuse.
 const project=createBenchmarkProject(count),first=measure(()=>run(project)),samples=[];
 for(let i=0;i<7;i++)samples.push(measure(()=>run(project)));
 samples.sort((a,b)=>a-b);
 results.push({operation,firstMs:+first.toFixed(2),warmMedianMs:+samples[3].toFixed(2),warmMaxMs:+samples[6].toFixed(2)});
}
console.log(`Synthetic project: ${count} scenes, 200 entries, 100 ideas. Domain timings only; no UI, disk saves or exports. First runs may still reuse content-based module caches; warm runs reuse the same project. No pass/fail timing thresholds.`);
console.table(results);
